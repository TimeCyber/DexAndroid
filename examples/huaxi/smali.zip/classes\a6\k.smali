.class public La6/k;
.super Ljava/lang/Object;
.source "LottieCompositionFactory.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "La6/s<",
        "La6/g;",
        ">;>;"
    }
.end annotation


# instance fields
.field public final synthetic a:Ljava/lang/ref/WeakReference;

.field public final synthetic b:Landroid/content/Context;

.field public final synthetic c:I

.field public final synthetic d:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/ref/WeakReference;Landroid/content/Context;ILjava/lang/String;)V
    .registers 5

    .line 1
    iput-object p1, p0, La6/k;->a:Ljava/lang/ref/WeakReference;

    iput-object p2, p0, La6/k;->b:Landroid/content/Context;

    iput p3, p0, La6/k;->c:I

    iput-object p4, p0, La6/k;->d:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public call()Ljava/lang/Object;
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 1
    iget-object v0, p0, La6/k;->a:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/Context;

    if-eqz v0, :cond_b

    goto :goto_d

    .line 2
    :cond_b
    iget-object v0, p0, La6/k;->b:Landroid/content/Context;

    .line 3
    :goto_d
    iget v1, p0, La6/k;->c:I

    iget-object v2, p0, La6/k;->d:Ljava/lang/String;

    invoke-static {v0, v1, v2}, La6/h;->e(Landroid/content/Context;ILjava/lang/String;)La6/s;

    move-result-object v0

    return-object v0
.end method
