.class public final La0/n0;
.super Ljava/lang/Object;
.source "AnimationSpec.kt"

# interfaces
.implements La0/y;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "La0/y<",
        "TT;>;"
    }
.end annotation


# instance fields
.field public final a:F

.field public final b:F

.field public final c:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 4

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p0, v0, v0, v1, v2}, La0/n0;-><init>(FFLjava/lang/Object;I)V

    return-void
.end method

.method public constructor <init>(FFLjava/lang/Object;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(FFTT;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput p1, p0, La0/n0;->a:F

    .line 3
    iput p2, p0, La0/n0;->b:F

    .line 4
    iput-object p3, p0, La0/n0;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(FFLjava/lang/Object;I)V
    .registers 6

    and-int/lit8 v0, p4, 0x1

    if-eqz v0, :cond_6

    const/high16 p1, 0x3f800000    # 1.0f

    :cond_6
    and-int/lit8 v0, p4, 0x2

    if-eqz v0, :cond_d

    const p2, 0x44bb8000    # 1500.0f

    :cond_d
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_12

    const/4 p3, 0x0

    .line 5
    :cond_12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    iput p1, p0, La0/n0;->a:F

    .line 7
    iput p2, p0, La0/n0;->b:F

    .line 8
    iput-object p3, p0, La0/n0;->c:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public a(La0/u0;)La0/y0;
    .registers 6

    .line 1
    new-instance v0, La0/i1;

    iget v1, p0, La0/n0;->a:F

    iget v2, p0, La0/n0;->b:F

    iget-object v3, p0, La0/n0;->c:Ljava/lang/Object;

    if-nez v3, :cond_c

    const/4 p1, 0x0

    goto :goto_16

    .line 2
    :cond_c
    invoke-interface {p1}, La0/u0;->a()Lvg/l;

    move-result-object p1

    invoke-interface {p1, v3}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La0/n;

    .line 3
    :goto_16
    invoke-direct {v0, v1, v2, p1}, La0/i1;-><init>(FFLa0/n;)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    instance-of v0, p1, La0/n0;

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_2d

    .line 2
    check-cast p1, La0/n0;

    iget v0, p1, La0/n0;->a:F

    iget v3, p0, La0/n0;->a:F

    cmpg-float v0, v0, v3

    if-nez v0, :cond_12

    const/4 v0, 0x1

    goto :goto_13

    :cond_12
    const/4 v0, 0x0

    :goto_13
    if-eqz v0, :cond_2d

    .line 3
    iget v0, p1, La0/n0;->b:F

    iget v3, p0, La0/n0;->b:F

    cmpg-float v0, v0, v3

    if-nez v0, :cond_1f

    const/4 v0, 0x1

    goto :goto_20

    :cond_1f
    const/4 v0, 0x0

    :goto_20
    if-eqz v0, :cond_2d

    .line 4
    iget-object p1, p1, La0/n0;->c:Ljava/lang/Object;

    iget-object v0, p0, La0/n0;->c:Ljava/lang/Object;

    invoke-static {p1, v0}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2d

    goto :goto_2e

    :cond_2d
    const/4 v1, 0x0

    :goto_2e
    return v1
.end method

.method public hashCode()I
    .registers 4

    .line 1
    iget-object v0, p0, La0/n0;->c:Ljava/lang/Object;

    if-eqz v0, :cond_9

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    goto :goto_a

    :cond_9
    const/4 v0, 0x0

    :goto_a
    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, La0/n0;->a:F

    const/16 v2, 0x1f

    invoke-static {v1, v0, v2}, Lc0/a0;->c(FII)I

    move-result v0

    iget v1, p0, La0/n0;->b:F

    invoke-static {v1}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v1

    add-int/2addr v1, v0

    return v1
.end method
