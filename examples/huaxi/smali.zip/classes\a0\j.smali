.class public La0/j;
.super Ljava/lang/Object;
.source "AnimationState.kt"

# interfaces
.implements Le2/y;


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static c(FFI)Lp2/b;
    .registers 3

    and-int/lit8 p2, p2, 0x2

    if-eqz p2, :cond_6

    const/high16 p1, 0x3f800000    # 1.0f

    .line 1
    :cond_6
    new-instance p2, Lp2/c;

    invoke-direct {p2, p0, p1}, Lp2/c;-><init>(FF)V

    return-object p2
.end method

.method public static final d(ZZ)I
    .registers 2

    if-eqz p1, :cond_4

    const/4 p1, 0x2

    goto :goto_5

    :cond_4
    const/4 p1, 0x0

    :goto_5
    or-int/2addr p0, p1

    return p0
.end method

.method public static final e(FF)J
    .registers 6

    .line 1
    invoke-static {p0}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result p0

    int-to-long v0, p0

    .line 2
    invoke-static {p1}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result p0

    int-to-long p0, p0

    const/16 v2, 0x20

    shl-long/2addr v0, v2

    const-wide v2, 0xffffffffL

    and-long/2addr p0, v2

    or-long/2addr p0, v0

    .line 3
    sget v0, Lr1/r0;->b:I

    return-wide p0
.end method

.method public static final f(J)I
    .registers 8

    const-wide v0, 0xffffffffL

    and-long/2addr v0, p0

    const/16 v2, 0x20

    const-wide/16 v3, 0x0

    cmp-long v5, v0, v3

    if-nez v5, :cond_10

    shr-long/2addr p0, v2

    goto :goto_11

    :cond_10
    const/4 v2, 0x0

    :goto_11
    const-wide/32 v0, 0xffff

    and-long/2addr v0, p0

    cmp-long v5, v0, v3

    if-nez v5, :cond_1e

    add-int/lit8 v2, v2, 0x10

    const/16 v0, 0x10

    shr-long/2addr p0, v0

    :cond_1e
    const-wide/16 v0, 0xff

    and-long/2addr v0, p0

    cmp-long v5, v0, v3

    if-nez v5, :cond_2a

    add-int/lit8 v2, v2, 0x8

    const/16 v0, 0x8

    shr-long/2addr p0, v0

    :cond_2a
    const-wide/16 v0, 0xf

    and-long/2addr v0, p0

    cmp-long v5, v0, v3

    if-nez v5, :cond_35

    add-int/lit8 v2, v2, 0x4

    const/4 v0, 0x4

    shr-long/2addr p0, v0

    :cond_35
    const-wide/16 v0, 0x1

    and-long/2addr v0, p0

    cmp-long v5, v0, v3

    if-eqz v5, :cond_3d

    goto :goto_5c

    :cond_3d
    const-wide/16 v0, 0x2

    and-long/2addr v0, p0

    cmp-long v5, v0, v3

    if-eqz v5, :cond_47

    add-int/lit8 v2, v2, 0x1

    goto :goto_5c

    :cond_47
    const-wide/16 v0, 0x4

    and-long/2addr v0, p0

    cmp-long v5, v0, v3

    if-eqz v5, :cond_51

    add-int/lit8 v2, v2, 0x2

    goto :goto_5c

    :cond_51
    const-wide/16 v0, 0x8

    and-long/2addr p0, v0

    cmp-long v0, p0, v3

    if-eqz v0, :cond_5b

    add-int/lit8 v2, v2, 0x3

    goto :goto_5c

    :cond_5b
    const/4 v2, -0x1

    :goto_5c
    return v2
.end method

.method public static final g(Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    .registers 3

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "exception"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    if-eq p0, p1, :cond_11

    .line 1
    sget-object v0, Lrg/b;->a:Lrg/a;

    invoke-virtual {v0, p0, p1}, Lrg/a;->a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    :cond_11
    return-void
.end method

.method public static final h([II)I
    .registers 6

    .line 1
    array-length v0, p0

    add-int/lit8 v0, v0, -0x1

    const/4 v1, 0x0

    :goto_4
    if-gt v1, v0, :cond_17

    add-int v2, v1, v0

    ushr-int/lit8 v2, v2, 0x1

    .line 2
    aget v3, p0, v2

    if-le p1, v3, :cond_11

    add-int/lit8 v1, v2, 0x1

    goto :goto_4

    :cond_11
    if-ge p1, v3, :cond_16

    add-int/lit8 v0, v2, -0x1

    goto :goto_4

    :cond_16
    return v2

    :cond_17
    add-int/lit8 v1, v1, 0x1

    neg-int p0, v1

    return p0
.end method

.method public static final i(F)I
    .registers 3

    float-to-double v0, p0

    .line 1
    invoke-static {v0, v1}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v0

    double-to-float p0, v0

    float-to-int p0, p0

    return p0
.end method

.method public static final j(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .registers 2

    if-eqz p0, :cond_10

    if-nez p1, :cond_8

    .line 1
    invoke-interface {p0}, Ljava/io/Closeable;->close()V

    goto :goto_10

    .line 2
    :cond_8
    :try_start_8
    invoke-interface {p0}, Ljava/io/Closeable;->close()V
    :try_end_b
    .catchall {:try_start_8 .. :try_end_b} :catchall_c

    goto :goto_10

    :catchall_c
    move-exception p0

    .line 3
    invoke-static {p1, p0}, La0/j;->g(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    :cond_10
    :goto_10
    return-void
.end method

.method public static l(FFFF)F
    .registers 4

    sub-float/2addr p2, p0

    sub-float/2addr p3, p1

    float-to-double p0, p2

    float-to-double p2, p3

    .line 1
    invoke-static {p0, p1, p2, p3}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide p0

    double-to-float p0, p0

    return p0
.end method

.method public static m(FFFFFF)F
    .registers 7

    .line 1
    invoke-static {p0, p1, p2, p3}, La0/j;->l(FFFF)F

    move-result v0

    .line 2
    invoke-static {p0, p1, p4, p3}, La0/j;->l(FFFF)F

    move-result p3

    .line 3
    invoke-static {p0, p1, p4, p5}, La0/j;->l(FFFF)F

    move-result p4

    .line 4
    invoke-static {p0, p1, p2, p5}, La0/j;->l(FFFF)F

    move-result p0

    cmpl-float p1, v0, p3

    if-lez p1, :cond_1d

    cmpl-float p1, v0, p4

    if-lez p1, :cond_1d

    cmpl-float p1, v0, p0

    if-lez p1, :cond_1d

    goto :goto_2e

    :cond_1d
    cmpl-float p1, p3, p4

    if-lez p1, :cond_27

    cmpl-float p1, p3, p0

    if-lez p1, :cond_27

    move v0, p3

    goto :goto_2e

    :cond_27
    cmpl-float p1, p4, p0

    if-lez p1, :cond_2d

    move v0, p4

    goto :goto_2e

    :cond_2d
    move v0, p0

    :goto_2e
    return v0
.end method

.method public static final n(Landroid/view/ViewGroup;I)Landroid/view/View;
    .registers 5

    .line 1
    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_7

    return-object v0

    :cond_7
    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    const-string v1, "Index: "

    const-string v2, ", Size: "

    invoke-static {v1, p1, v2}, Landroidx/appcompat/widget/l0;->e(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static o(Ljava/lang/String;)I
    .registers 4

    .line 1
    invoke-static {}, Lcom/blankj/utilcode/util/l;->a()Landroid/app/Application;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/Application;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-static {}, Lcom/blankj/utilcode/util/l;->a()Landroid/app/Application;

    move-result-object v1

    invoke-virtual {v1}, Landroid/app/Application;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const-string v2, "drawable"

    invoke-virtual {v0, p0, v2, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static final p(Log/f;)Lm0/t0;
    .registers 2

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    sget v0, Lm0/t0;->T:I

    sget-object v0, Lm0/t0$b;->a:Lm0/t0$b;

    invoke-interface {p0, v0}, Log/f;->get(Log/f$b;)Log/f$a;

    move-result-object p0

    check-cast p0, Lm0/t0;

    if-eqz p0, :cond_12

    return-object p0

    :cond_12
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "A MonotonicFrameClock is not available in this CoroutineContext. Callers should supply an appropriate MonotonicFrameClock using withContext."

    .line 2
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static final q([F[F)Z
    .registers 48

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const-string v2, "$this$invertTo"

    invoke-static {v0, v2}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "other"

    invoke-static {v1, v2}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    .line 1
    aget v3, v0, v2

    const/4 v4, 0x1

    .line 2
    aget v5, v0, v4

    const/4 v6, 0x2

    .line 3
    aget v7, v0, v6

    const/4 v8, 0x3

    .line 4
    aget v9, v0, v8

    const/4 v10, 0x4

    .line 5
    aget v11, v0, v10

    const/4 v12, 0x5

    .line 6
    aget v13, v0, v12

    const/4 v14, 0x6

    .line 7
    aget v15, v0, v14

    const/16 v16, 0x7

    .line 8
    aget v17, v0, v16

    const/16 v18, 0x8

    .line 9
    aget v14, v0, v18

    const/16 v19, 0x9

    .line 10
    aget v12, v0, v19

    const/16 v21, 0xa

    .line 11
    aget v22, v0, v21

    const/16 v23, 0xb

    .line 12
    aget v24, v0, v23

    const/16 v25, 0xc

    .line 13
    aget v10, v0, v25

    const/16 v26, 0xd

    .line 14
    aget v27, v0, v26

    const/16 v28, 0xe

    .line 15
    aget v29, v0, v28

    const/16 v30, 0xf

    .line 16
    aget v0, v0, v30

    mul-float v31, v3, v13

    mul-float v32, v5, v11

    sub-float v31, v31, v32

    mul-float v32, v3, v15

    mul-float v33, v7, v11

    sub-float v32, v32, v33

    mul-float v33, v3, v17

    mul-float v34, v9, v11

    sub-float v33, v33, v34

    mul-float v34, v5, v15

    mul-float v35, v7, v13

    sub-float v34, v34, v35

    mul-float v35, v5, v17

    mul-float v36, v9, v13

    sub-float v35, v35, v36

    mul-float v36, v7, v17

    mul-float v37, v9, v15

    sub-float v36, v36, v37

    mul-float v37, v14, v27

    mul-float v38, v12, v10

    sub-float v37, v37, v38

    mul-float v38, v14, v29

    mul-float v39, v22, v10

    sub-float v38, v38, v39

    mul-float v39, v14, v0

    mul-float v40, v24, v10

    sub-float v39, v39, v40

    mul-float v40, v12, v29

    mul-float v41, v22, v27

    sub-float v40, v40, v41

    mul-float v41, v12, v0

    mul-float v42, v24, v27

    sub-float v41, v41, v42

    mul-float v42, v22, v0

    mul-float v43, v24, v29

    sub-float v42, v42, v43

    mul-float v43, v31, v42

    mul-float v44, v32, v41

    sub-float v43, v43, v44

    mul-float v44, v33, v40

    add-float v44, v44, v43

    mul-float v43, v34, v39

    add-float v43, v43, v44

    mul-float v44, v35, v38

    sub-float v43, v43, v44

    mul-float v44, v36, v37

    add-float v44, v44, v43

    const/16 v43, 0x0

    cmpg-float v43, v44, v43

    if-nez v43, :cond_ae

    const/16 v43, 0x1

    goto :goto_b0

    :cond_ae
    const/16 v43, 0x0

    :goto_b0
    if-eqz v43, :cond_b3

    return v2

    :cond_b3
    const/high16 v43, 0x3f800000    # 1.0f

    div-float v43, v43, v44

    mul-float v44, v13, v42

    mul-float v45, v15, v41

    sub-float v44, v44, v45

    mul-float v45, v17, v40

    add-float v45, v45, v44

    mul-float v45, v45, v43

    .line 17
    aput v45, v1, v2

    neg-float v2, v5

    mul-float v2, v2, v42

    mul-float v44, v7, v41

    add-float v44, v44, v2

    mul-float v2, v9, v40

    sub-float v44, v44, v2

    mul-float v44, v44, v43

    .line 18
    aput v44, v1, v4

    mul-float v2, v27, v36

    mul-float v44, v29, v35

    sub-float v2, v2, v44

    mul-float v44, v0, v34

    add-float v44, v44, v2

    mul-float v44, v44, v43

    .line 19
    aput v44, v1, v6

    neg-float v2, v12

    mul-float v2, v2, v36

    mul-float v6, v22, v35

    add-float/2addr v6, v2

    mul-float v2, v24, v34

    sub-float/2addr v6, v2

    mul-float v6, v6, v43

    .line 20
    aput v6, v1, v8

    neg-float v2, v11

    mul-float v6, v2, v42

    mul-float v8, v15, v39

    add-float/2addr v8, v6

    mul-float v6, v17, v38

    sub-float/2addr v8, v6

    mul-float v8, v8, v43

    const/4 v6, 0x4

    .line 21
    aput v8, v1, v6

    mul-float v42, v42, v3

    mul-float v6, v7, v39

    sub-float v42, v42, v6

    mul-float v6, v9, v38

    add-float v6, v6, v42

    mul-float v6, v6, v43

    const/4 v8, 0x5

    .line 22
    aput v6, v1, v8

    neg-float v6, v10

    mul-float v8, v6, v36

    mul-float v20, v29, v33

    add-float v20, v20, v8

    mul-float v8, v0, v32

    sub-float v20, v20, v8

    mul-float v20, v20, v43

    const/4 v8, 0x6

    .line 23
    aput v20, v1, v8

    mul-float v36, v36, v14

    mul-float v8, v22, v33

    sub-float v36, v36, v8

    mul-float v8, v24, v32

    add-float v8, v8, v36

    mul-float v8, v8, v43

    .line 24
    aput v8, v1, v16

    mul-float v11, v11, v41

    mul-float v8, v13, v39

    sub-float/2addr v11, v8

    mul-float v17, v17, v37

    add-float v17, v17, v11

    mul-float v17, v17, v43

    .line 25
    aput v17, v1, v18

    neg-float v8, v3

    mul-float v8, v8, v41

    mul-float v39, v39, v5

    add-float v39, v39, v8

    mul-float v9, v9, v37

    sub-float v39, v39, v9

    mul-float v39, v39, v43

    .line 26
    aput v39, v1, v19

    mul-float v10, v10, v35

    mul-float v8, v27, v33

    sub-float/2addr v10, v8

    mul-float v0, v0, v31

    add-float/2addr v0, v10

    mul-float v0, v0, v43

    .line 27
    aput v0, v1, v21

    neg-float v0, v14

    mul-float v0, v0, v35

    mul-float v33, v33, v12

    add-float v33, v33, v0

    mul-float v24, v24, v31

    sub-float v33, v33, v24

    mul-float v33, v33, v43

    .line 28
    aput v33, v1, v23

    mul-float v2, v2, v40

    mul-float v13, v13, v38

    add-float/2addr v13, v2

    mul-float v15, v15, v37

    sub-float/2addr v13, v15

    mul-float v13, v13, v43

    .line 29
    aput v13, v1, v25

    mul-float v3, v3, v40

    mul-float v5, v5, v38

    sub-float/2addr v3, v5

    mul-float v7, v7, v37

    add-float/2addr v7, v3

    mul-float v7, v7, v43

    .line 30
    aput v7, v1, v26

    mul-float v6, v6, v34

    mul-float v27, v27, v32

    add-float v27, v27, v6

    mul-float v29, v29, v31

    sub-float v27, v27, v29

    mul-float v27, v27, v43

    .line 31
    aput v27, v1, v28

    mul-float v14, v14, v34

    mul-float v12, v12, v32

    sub-float/2addr v14, v12

    mul-float v22, v22, v31

    add-float v22, v22, v14

    mul-float v22, v22, v43

    .line 32
    aput v22, v1, v30

    return v4
.end method

.method public static r(FFF)F
    .registers 4

    const/high16 v0, 0x3f800000    # 1.0f

    sub-float/2addr v0, p2

    mul-float v0, v0, p0

    mul-float p2, p2, p1

    add-float/2addr p2, v0

    return p2
.end method

.method public static s(Ljava/lang/String;)Ljava/lang/String;
    .registers 6

    :try_start_0
    const-string v0, "MD5"

    .line 1
    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    const-string v1, "UTF-8"

    .line 2
    invoke-virtual {p0, v1}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p0

    .line 3
    invoke-virtual {v0, p0}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object p0
    :try_end_10
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_10} :catch_41
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_10} :catch_38

    .line 4
    new-instance v0, Ljava/lang/StringBuilder;

    array-length v1, p0

    mul-int/lit8 v1, v1, 0x2

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 5
    array-length v1, p0

    const/4 v2, 0x0

    :goto_1a
    if-ge v2, v1, :cond_33

    aget-byte v3, p0, v2

    and-int/lit16 v3, v3, 0xff

    const/16 v4, 0x10

    if-ge v3, v4, :cond_29

    const-string v4, "0"

    .line 6
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 7
    :cond_29
    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v2, v2, 0x1

    goto :goto_1a

    .line 8
    :cond_33
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :catch_38
    move-exception p0

    .line 9
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "Huh, UTF-8 should be supported?"

    invoke-direct {v0, v1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    :catch_41
    move-exception p0

    .line 10
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "Huh, MD5 should be supported?"

    invoke-direct {v0, v1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public static final t(Ljava/lang/Object;)[Ljava/lang/Object;
    .registers 3

    const/16 v0, 0x20

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v1, 0x0

    aput-object p0, v0, v1

    return-object v0
.end method

.method public static final u(JJ)J
    .registers 13

    .line 1
    invoke-static {p0, p1}, Lc1/f;->e(J)F

    move-result v0

    .line 2
    sget-wide v1, Lr1/r0;->a:J

    const/4 v3, 0x1

    const/4 v4, 0x0

    cmp-long v5, p2, v1

    if-eqz v5, :cond_e

    const/4 v5, 0x1

    goto :goto_f

    :cond_e
    const/4 v5, 0x0

    :goto_f
    const-string v6, "ScaleFactor is unspecified"

    if-eqz v5, :cond_47

    const/16 v5, 0x20

    shr-long v7, p2, v5

    long-to-int v5, v7

    .line 3
    invoke-static {v5}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v5

    mul-float v0, v0, v5

    .line 4
    invoke-static {p0, p1}, Lc1/f;->c(J)F

    move-result p0

    cmp-long p1, p2, v1

    if-eqz p1, :cond_27

    goto :goto_28

    :cond_27
    const/4 v3, 0x0

    :goto_28
    if-eqz v3, :cond_3d

    const-wide v1, 0xffffffffL

    and-long p1, p2, v1

    long-to-int p2, p1

    .line 5
    invoke-static {p2}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p1

    mul-float p0, p0, p1

    .line 6
    invoke-static {v0, p0}, Landroidx/appcompat/widget/m;->j(FF)J

    move-result-wide p0

    return-wide p0

    .line 7
    :cond_3d
    new-instance p0, Ljava/lang/IllegalStateException;

    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 8
    :cond_47
    new-instance p0, Ljava/lang/IllegalStateException;

    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static final v(Lg2/c;)Ljava/util/Locale;
    .registers 2

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object p0, p0, Lg2/c;->a:Lg2/e;

    .line 2
    check-cast p0, Lg2/a;

    .line 3
    iget-object p0, p0, Lg2/a;->a:Ljava/util/Locale;

    return-object p0
.end method

.method public static final w(Log/f;Ljava/lang/Object;Ljava/lang/Object;Lvg/p;Log/d;)Ljava/lang/Object;
    .registers 7

    .line 1
    invoke-static {p0, p2}, Llh/t;->c(Log/f;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    .line 2
    :try_start_4
    new-instance v0, Lkh/u;

    invoke-direct {v0, p4, p0}, Lkh/u;-><init>(Log/d;Log/f;)V

    const/4 v1, 0x2

    invoke-static {p3, v1}, Lwg/z;->c(Ljava/lang/Object;I)Ljava/lang/Object;

    check-cast p3, Lvg/p;

    invoke-interface {p3, p1, v0}, Lvg/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_13
    .catchall {:try_start_4 .. :try_end_13} :catchall_20

    .line 3
    invoke-static {p0, p2}, Llh/t;->a(Log/f;Ljava/lang/Object;)V

    .line 4
    sget-object p0, Lpg/a;->a:Lpg/a;

    if-ne p1, p0, :cond_1f

    const-string p0, "frame"

    .line 5
    invoke-static {p4, p0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_1f
    return-object p1

    :catchall_20
    move-exception p1

    .line 6
    invoke-static {p0, p2}, Llh/t;->a(Log/f;Ljava/lang/Object;)V

    throw p1
.end method


# virtual methods
.method public a(Le2/t;I)Landroid/graphics/Typeface;
    .registers 4

    const-string v0, "fontWeight"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x0

    .line 1
    invoke-virtual {p0, v0, p1, p2}, La0/j;->k(Ljava/lang/String;Le2/t;I)Landroid/graphics/Typeface;

    move-result-object p1

    return-object p1
.end method

.method public b(Le2/u;Le2/t;I)Landroid/graphics/Typeface;
    .registers 5

    const-string v0, "name"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "fontWeight"

    invoke-static {p2, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object p1, p1, Le2/u;->g:Ljava/lang/String;

    .line 2
    invoke-virtual {p0, p1, p2, p3}, La0/j;->k(Ljava/lang/String;Le2/t;I)Landroid/graphics/Typeface;

    move-result-object p1

    return-object p1
.end method

.method public k(Ljava/lang/String;Le2/t;I)Landroid/graphics/Typeface;
    .registers 7

    const/4 v0, 0x0

    .line 1
    invoke-static {p3, v0}, Le2/r;->a(II)Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_28

    .line 2
    sget-object v1, Le2/t;->b:Le2/t$a;

    .line 3
    sget-object v1, Le2/t;->n:Le2/t;

    .line 4
    invoke-static {p2, v1}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_28

    if-eqz p1, :cond_1d

    .line 5
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    if-nez v1, :cond_1b

    goto :goto_1d

    :cond_1b
    const/4 v1, 0x0

    goto :goto_1e

    :cond_1d
    :goto_1d
    const/4 v1, 0x1

    :goto_1e
    if-eqz v1, :cond_28

    .line 6
    sget-object p1, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    const-string p2, "DEFAULT"

    invoke-static {p1, p2}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p1

    :cond_28
    if-nez p1, :cond_2d

    .line 7
    sget-object p1, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    goto :goto_31

    .line 8
    :cond_2d
    invoke-static {p1, v0}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object p1

    .line 9
    :goto_31
    iget p2, p2, Le2/t;->a:I

    .line 10
    invoke-static {p3, v2}, Le2/r;->a(II)Z

    move-result p3

    .line 11
    invoke-static {p1, p2, p3}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;IZ)Landroid/graphics/Typeface;

    move-result-object p1

    const-string p2, "create(\n            fami\u2026ontStyle.Italic\n        )"

    invoke-static {p1, p2}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p1
.end method
