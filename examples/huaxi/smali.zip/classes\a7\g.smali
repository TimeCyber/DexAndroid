.class public final La7/g;
.super La7/h;
.source "ClickUtils.java"


# instance fields
.field public final synthetic e:Landroid/view/View$OnClickListener;


# direct methods
.method public constructor <init>(ZJLandroid/view/View$OnClickListener;)V
    .registers 5

    .line 1
    iput-object p4, p0, La7/g;->e:Landroid/view/View$OnClickListener;

    invoke-direct {p0, p1, p2, p3}, La7/h;-><init>(ZJ)V

    return-void
.end method
