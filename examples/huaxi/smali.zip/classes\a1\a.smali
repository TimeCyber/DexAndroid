.class public interface abstract La1/a;
.super Ljava/lang/Object;
.source "DrawModifier.kt"


# virtual methods
.method public abstract c()J
.end method

.method public abstract getDensity()Lp2/b;
.end method

.method public abstract getLayoutDirection()Lp2/j;
.end method
