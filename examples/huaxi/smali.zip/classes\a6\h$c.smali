.class public La6/h$c;
.super Ljava/lang/Object;
.source "LottieCompositionFactory.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La6/h;->a(Ljava/lang/String;Ljava/util/concurrent/Callable;)La6/u;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "La6/s<",
        "La6/g;",
        ">;>;"
    }
.end annotation


# instance fields
.field public final synthetic a:La6/g;


# direct methods
.method public constructor <init>(La6/g;)V
    .registers 2

    .line 1
    iput-object p1, p0, La6/h$c;->a:La6/g;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public call()Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 1
    new-instance v0, La6/s;

    iget-object v1, p0, La6/h$c;->a:La6/g;

    invoke-direct {v0, v1}, La6/s;-><init>(Ljava/lang/Object;)V

    return-object v0
.end method
