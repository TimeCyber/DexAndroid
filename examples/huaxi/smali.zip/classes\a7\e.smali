.class public final La7/e;
.super Ljava/lang/Object;
.source "CacheDiskUtils.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La7/e$b;,
        La7/e$c;
    }
.end annotation


# static fields
.field public static final f:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "La7/e;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/io/File;

.field public final c:J

.field public final d:I

.field public e:La7/e$c;


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, La7/e;->f:Ljava/util/Map;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/io/File;JI)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, La7/e;->a:Ljava/lang/String;

    .line 3
    iput-object p2, p0, La7/e;->b:Ljava/io/File;

    .line 4
    iput-wide p3, p0, La7/e;->c:J

    .line 5
    iput p5, p0, La7/e;->d:I

    return-void
.end method


# virtual methods
.method public final a()La7/e$c;
    .registers 8

    .line 1
    iget-object v0, p0, La7/e;->b:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_1c

    .line 2
    iget-object v0, p0, La7/e;->e:La7/e$c;

    if-nez v0, :cond_4c

    .line 3
    new-instance v0, La7/e$c;

    iget-object v2, p0, La7/e;->b:Ljava/io/File;

    iget-wide v3, p0, La7/e;->c:J

    iget v5, p0, La7/e;->d:I

    const/4 v6, 0x0

    move-object v1, v0

    invoke-direct/range {v1 .. v6}, La7/e$c;-><init>(Ljava/io/File;JILa7/e$a;)V

    iput-object v0, p0, La7/e;->e:La7/e$c;

    goto :goto_4c

    .line 4
    :cond_1c
    iget-object v0, p0, La7/e;->b:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    move-result v0

    if-eqz v0, :cond_34

    .line 5
    new-instance v0, La7/e$c;

    iget-object v2, p0, La7/e;->b:Ljava/io/File;

    iget-wide v3, p0, La7/e;->c:J

    iget v5, p0, La7/e;->d:I

    const/4 v6, 0x0

    move-object v1, v0

    invoke-direct/range {v1 .. v6}, La7/e$c;-><init>(Ljava/io/File;JILa7/e$a;)V

    iput-object v0, p0, La7/e;->e:La7/e$c;

    goto :goto_4c

    :cond_34
    const-string v0, "can\'t make dirs in "

    .line 6
    invoke-static {v0}, Landroid/support/v4/media/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, La7/e;->b:Ljava/io/File;

    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "CacheDiskUtils"

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 7
    :cond_4c
    :goto_4c
    iget-object v0, p0, La7/e;->e:La7/e$c;

    return-object v0
.end method

.method public final b(Ljava/lang/String;)[B
    .registers 14

    .line 1
    invoke-virtual {p0}, La7/e;->a()La7/e$c;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_9

    goto/16 :goto_c2

    .line 2
    :cond_9
    invoke-virtual {v0, p1}, La7/e$c;->c(Ljava/lang/String;)Ljava/io/File;

    move-result-object v2

    if-nez v2, :cond_11

    goto/16 :goto_c2

    .line 3
    :cond_11
    invoke-static {v2}, Lcom/blankj/utilcode/util/p;->f(Ljava/io/File;)Z

    move-result v3

    const/4 v4, 0x0

    if-nez v3, :cond_19

    goto :goto_5d

    .line 4
    :cond_19
    :try_start_19
    new-instance v3, Ljava/io/RandomAccessFile;

    const-string v5, "r"

    invoke-direct {v3, v2, v5}, Ljava/io/RandomAccessFile;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/io/RandomAccessFile;->getChannel()Ljava/nio/channels/FileChannel;

    move-result-object v3
    :try_end_24
    .catch Ljava/io/IOException; {:try_start_19 .. :try_end_24} :catch_4b
    .catchall {:try_start_19 .. :try_end_24} :catchall_48

    if-nez v3, :cond_32

    :try_start_26
    const-string v5, "FileIOUtils"

    const-string v6, "fc is null."

    .line 5
    invoke-static {v5, v6}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    new-array v5, v4, [B

    if-eqz v3, :cond_5e

    goto :goto_54

    .line 6
    :cond_32
    invoke-virtual {v3}, Ljava/nio/channels/FileChannel;->size()J

    move-result-wide v5

    long-to-int v6, v5

    invoke-static {v6}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v5

    .line 7
    :cond_3b
    invoke-virtual {v3, v5}, Ljava/nio/channels/FileChannel;->read(Ljava/nio/ByteBuffer;)I

    move-result v6

    if-gtz v6, :cond_3b

    .line 8
    invoke-virtual {v5}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v5
    :try_end_45
    .catch Ljava/io/IOException; {:try_start_26 .. :try_end_45} :catch_46
    .catchall {:try_start_26 .. :try_end_45} :catchall_c3

    goto :goto_54

    :catch_46
    move-exception v5

    goto :goto_4e

    :catchall_48
    move-exception p1

    goto/16 :goto_c5

    :catch_4b
    move-exception v3

    move-object v5, v3

    move-object v3, v1

    .line 9
    :goto_4e
    :try_start_4e
    invoke-virtual {v5}, Ljava/io/IOException;->printStackTrace()V
    :try_end_51
    .catchall {:try_start_4e .. :try_end_51} :catchall_c3

    if-eqz v3, :cond_5d

    move-object v5, v1

    .line 10
    :goto_54
    :try_start_54
    invoke-virtual {v3}, Ljava/nio/channels/FileChannel;->close()V
    :try_end_57
    .catch Ljava/io/IOException; {:try_start_54 .. :try_end_57} :catch_58

    goto :goto_5e

    :catch_58
    move-exception v3

    .line 11
    invoke-virtual {v3}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_5e

    :cond_5d
    :goto_5d
    move-object v5, v1

    .line 12
    :cond_5e
    :goto_5e
    invoke-static {v5}, La7/e$b;->b([B)Z

    move-result v3

    const-wide/16 v6, -0x1

    if-eqz v3, :cond_7b

    .line 13
    new-instance v3, Ljava/lang/String;

    const/4 v8, 0x2

    const/16 v9, 0xc

    invoke-static {v5, v8, v9}, La7/e$b;->a([BII)[B

    move-result-object v8

    invoke-direct {v3, v8}, Ljava/lang/String;-><init>([B)V

    .line 14
    :try_start_72
    invoke-static {v3}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v8
    :try_end_76
    .catch Ljava/lang/NumberFormatException; {:try_start_72 .. :try_end_76} :catch_7b

    const-wide/16 v10, 0x3e8

    mul-long v8, v8, v10

    goto :goto_7c

    :catch_7b
    :cond_7b
    move-wide v8, v6

    :goto_7c
    cmp-long v3, v8, v6

    if-eqz v3, :cond_89

    .line 15
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    cmp-long v3, v6, v8

    if-lez v3, :cond_89

    const/4 v4, 0x1

    :cond_89
    if-eqz v4, :cond_af

    .line 16
    invoke-virtual {v0, p1}, La7/e$c;->c(Ljava/lang/String;)Ljava/io/File;

    move-result-object p1

    if-nez p1, :cond_92

    goto :goto_c2

    .line 17
    :cond_92
    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    move-result v2

    if-nez v2, :cond_99

    goto :goto_c2

    .line 18
    :cond_99
    iget-object v2, v0, La7/e$c;->a:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {p1}, Ljava/io/File;->length()J

    move-result-wide v3

    neg-long v3, v3

    invoke-virtual {v2, v3, v4}, Ljava/util/concurrent/atomic/AtomicLong;->addAndGet(J)J

    .line 19
    iget-object v2, v0, La7/e$c;->b:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v3, -0x1

    invoke-virtual {v2, v3}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    .line 20
    iget-object v0, v0, La7/e$c;->e:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_c2

    .line 21
    :cond_af
    invoke-static {v0, v2}, La7/e$c;->a(La7/e$c;Ljava/io/File;)V

    .line 22
    invoke-static {v5}, La7/e$b;->b([B)Z

    move-result p1

    if-eqz p1, :cond_c1

    const/16 p1, 0xe

    .line 23
    array-length v0, v5

    invoke-static {v5, p1, v0}, La7/e$b;->a([BII)[B

    move-result-object p1

    move-object v1, p1

    goto :goto_c2

    :cond_c1
    move-object v1, v5

    :goto_c2
    return-object v1

    :catchall_c3
    move-exception p1

    move-object v1, v3

    :goto_c5
    if-eqz v1, :cond_cf

    .line 24
    :try_start_c7
    invoke-virtual {v1}, Ljava/nio/channels/FileChannel;->close()V
    :try_end_ca
    .catch Ljava/io/IOException; {:try_start_c7 .. :try_end_ca} :catch_cb

    goto :goto_cf

    :catch_cb
    move-exception v0

    .line 25
    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    .line 26
    :cond_cf
    :goto_cf
    throw p1
.end method

.method public final c(Ljava/lang/String;[BI)V
    .registers 21

    move-object/from16 v0, p2

    move/from16 v1, p3

    if-nez v0, :cond_7

    return-void

    .line 1
    :cond_7
    invoke-virtual/range {p0 .. p0}, La7/e;->a()La7/e$c;

    move-result-object v2

    if-nez v2, :cond_e

    return-void

    :cond_e
    const/4 v3, 0x0

    const/4 v4, 0x1

    if-ltz v1, :cond_40

    .line 2
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v5

    new-array v6, v4, [Ljava/lang/Object;

    .line 3
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v7

    const-wide/16 v9, 0x3e8

    div-long/2addr v7, v9

    int-to-long v9, v1

    add-long/2addr v7, v9

    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    aput-object v1, v6, v3

    const-string v1, "_$%010d$_"

    .line 4
    invoke-static {v5, v1, v6}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    .line 5
    invoke-virtual {v1}, Ljava/lang/String;->getBytes()[B

    move-result-object v1

    .line 6
    array-length v5, v1

    array-length v6, v0

    add-int/2addr v5, v6

    new-array v5, v5, [B

    .line 7
    array-length v6, v1

    invoke-static {v1, v3, v5, v3, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 8
    array-length v1, v1

    array-length v6, v0

    invoke-static {v0, v3, v5, v1, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    goto :goto_41

    :cond_40
    move-object v5, v0

    .line 9
    :goto_41
    :try_start_41
    iget-object v0, v2, La7/e$c;->g:Ljava/lang/Thread;

    invoke-virtual {v0}, Ljava/lang/Thread;->join()V
    :try_end_46
    .catch Ljava/lang/InterruptedException; {:try_start_41 .. :try_end_46} :catch_47

    goto :goto_4b

    :catch_47
    move-exception v0

    .line 10
    invoke-virtual {v0}, Ljava/lang/InterruptedException;->printStackTrace()V

    .line 11
    :goto_4b
    new-instance v1, Ljava/io/File;

    iget-object v0, v2, La7/e$c;->f:Ljava/io/File;

    move-object/from16 v6, p1

    invoke-virtual {v2, v6}, La7/e$c;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v1, v0, v6}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 12
    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v0

    const/4 v6, -0x1

    if-eqz v0, :cond_6e

    .line 13
    iget-object v0, v2, La7/e$c;->b:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0, v6}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    .line 14
    iget-object v0, v2, La7/e$c;->a:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v1}, Ljava/io/File;->length()J

    move-result-wide v7

    neg-long v7, v7

    invoke-virtual {v0, v7, v8}, Ljava/util/concurrent/atomic/AtomicLong;->addAndGet(J)J

    :cond_6e
    const-string v0, "FileIOUtils"

    .line 15
    invoke-static {v1}, Lcom/blankj/utilcode/util/p;->a(Ljava/io/File;)Z

    move-result v7

    const/4 v8, 0x0

    if-nez v7, :cond_91

    .line 16
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "create file <"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v5, "> failed."

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v0, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_cf

    .line 17
    :cond_91
    :try_start_91
    new-instance v7, Ljava/io/FileOutputStream;

    invoke-direct {v7, v1, v3}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;Z)V

    invoke-virtual {v7}, Ljava/io/FileOutputStream;->getChannel()Ljava/nio/channels/FileChannel;

    move-result-object v3
    :try_end_9a
    .catch Ljava/io/IOException; {:try_start_91 .. :try_end_9a} :catch_c5
    .catchall {:try_start_91 .. :try_end_9a} :catchall_c1

    if-nez v3, :cond_a4

    :try_start_9c
    const-string v5, "fc is null."

    .line 18
    invoke-static {v0, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    if-eqz v3, :cond_cf

    goto :goto_cc

    .line 19
    :cond_a4
    invoke-virtual {v3}, Ljava/nio/channels/FileChannel;->size()J

    move-result-wide v9

    invoke-virtual {v3, v9, v10}, Ljava/nio/channels/FileChannel;->position(J)Ljava/nio/channels/FileChannel;

    .line 20
    invoke-static {v5}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/nio/channels/FileChannel;->write(Ljava/nio/ByteBuffer;)I

    .line 21
    invoke-virtual {v3, v4}, Ljava/nio/channels/FileChannel;->force(Z)V
    :try_end_b5
    .catch Ljava/io/IOException; {:try_start_9c .. :try_end_b5} :catch_bf
    .catchall {:try_start_9c .. :try_end_b5} :catchall_165

    .line 22
    :try_start_b5
    invoke-virtual {v3}, Ljava/nio/channels/FileChannel;->close()V
    :try_end_b8
    .catch Ljava/io/IOException; {:try_start_b5 .. :try_end_b8} :catch_b9

    goto :goto_cf

    :catch_b9
    move-exception v0

    move-object v3, v0

    .line 23
    invoke-virtual {v3}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_cf

    :catch_bf
    move-exception v0

    goto :goto_c7

    :catchall_c1
    move-exception v0

    move-object v1, v0

    goto/16 :goto_168

    :catch_c5
    move-exception v0

    move-object v3, v8

    .line 24
    :goto_c7
    :try_start_c7
    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V
    :try_end_ca
    .catchall {:try_start_c7 .. :try_end_ca} :catchall_165

    if-eqz v3, :cond_cf

    .line 25
    :goto_cc
    :try_start_cc
    invoke-virtual {v3}, Ljava/nio/channels/FileChannel;->close()V
    :try_end_cf
    .catch Ljava/io/IOException; {:try_start_cc .. :try_end_cf} :catch_b9

    .line 26
    :cond_cf
    :goto_cf
    invoke-static {v2, v1}, La7/e$c;->a(La7/e$c;Ljava/io/File;)V

    .line 27
    iget-object v0, v2, La7/e$c;->b:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0, v4}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    .line 28
    iget-object v0, v2, La7/e$c;->a:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v1}, Ljava/io/File;->length()J

    move-result-wide v3

    invoke-virtual {v0, v3, v4}, Ljava/util/concurrent/atomic/AtomicLong;->addAndGet(J)J

    .line 29
    :goto_e0
    iget-object v0, v2, La7/e$c;->b:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    iget v1, v2, La7/e$c;->d:I

    if-gt v0, v1, :cond_f8

    iget-object v0, v2, La7/e$c;->a:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v0

    iget-wide v3, v2, La7/e$c;->c:J

    cmp-long v5, v0, v3

    if-lez v5, :cond_f7

    goto :goto_f8

    :cond_f7
    return-void

    .line 30
    :cond_f8
    :goto_f8
    iget-object v0, v2, La7/e$c;->a:Ljava/util/concurrent/atomic/AtomicLong;

    .line 31
    iget-object v1, v2, La7/e$c;->e:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->isEmpty()Z

    move-result v1

    const-wide/16 v3, 0x0

    if-eqz v1, :cond_105

    goto :goto_157

    :cond_105
    const-wide v9, 0x7fffffffffffffffL

    .line 32
    invoke-static {v9, v10}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    .line 33
    iget-object v5, v2, La7/e$c;->e:Ljava/util/Map;

    invoke-interface {v5}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v5

    .line 34
    iget-object v7, v2, La7/e$c;->e:Ljava/util/Map;

    monitor-enter v7

    .line 35
    :try_start_117
    invoke-interface {v5}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v5

    move-object v9, v8

    :cond_11c
    :goto_11c
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_143

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/Map$Entry;

    .line 36
    invoke-interface {v10}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/Long;

    .line 37
    invoke-virtual {v11}, Ljava/lang/Long;->longValue()J

    move-result-wide v12

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v14

    cmp-long v16, v12, v14

    if-gez v16, :cond_11c

    .line 38
    invoke-interface {v10}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    move-object v9, v1

    check-cast v9, Ljava/io/File;

    move-object v1, v11

    goto :goto_11c

    .line 39
    :cond_143
    monitor-exit v7
    :try_end_144
    .catchall {:try_start_117 .. :try_end_144} :catchall_162

    if-nez v9, :cond_147

    goto :goto_157

    .line 40
    :cond_147
    invoke-virtual {v9}, Ljava/io/File;->length()J

    move-result-wide v10

    .line 41
    invoke-virtual {v9}, Ljava/io/File;->delete()Z

    move-result v1

    if-eqz v1, :cond_157

    .line 42
    iget-object v1, v2, La7/e$c;->e:Ljava/util/Map;

    invoke-interface {v1, v9}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-wide v3, v10

    :cond_157
    :goto_157
    neg-long v3, v3

    .line 43
    invoke-virtual {v0, v3, v4}, Ljava/util/concurrent/atomic/AtomicLong;->addAndGet(J)J

    .line 44
    iget-object v0, v2, La7/e$c;->b:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0, v6}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    goto/16 :goto_e0

    :catchall_162
    move-exception v0

    .line 45
    :try_start_163
    monitor-exit v7
    :try_end_164
    .catchall {:try_start_163 .. :try_end_164} :catchall_162

    throw v0

    :catchall_165
    move-exception v0

    move-object v1, v0

    move-object v8, v3

    :goto_168
    if-eqz v8, :cond_173

    .line 46
    :try_start_16a
    invoke-virtual {v8}, Ljava/nio/channels/FileChannel;->close()V
    :try_end_16d
    .catch Ljava/io/IOException; {:try_start_16a .. :try_end_16d} :catch_16e

    goto :goto_173

    :catch_16e
    move-exception v0

    move-object v2, v0

    .line 47
    invoke-virtual {v2}, Ljava/io/IOException;->printStackTrace()V

    .line 48
    :cond_173
    :goto_173
    throw v1
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, La7/e;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "@"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
