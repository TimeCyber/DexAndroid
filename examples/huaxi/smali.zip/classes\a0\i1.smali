.class public final La0/i1;
.super Ljava/lang/Object;
.source "VectorizedAnimationSpec.kt"

# interfaces
.implements La0/y0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<V:",
        "La0/n;",
        ">",
        "Ljava/lang/Object;",
        "La0/y0;"
    }
.end annotation


# instance fields
.field public final synthetic a:La0/e1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/e1<",
            "TV;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(FFLa0/n;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(FFTV;)V"
        }
    .end annotation

    if-eqz p3, :cond_8

    .line 1
    new-instance v0, La0/z0;

    invoke-direct {v0, p3, p1, p2}, La0/z0;-><init>(La0/n;FF)V

    goto :goto_d

    .line 2
    :cond_8
    new-instance v0, La0/a1;

    invoke-direct {v0, p1, p2}, La0/a1;-><init>(FF)V

    .line 3
    :goto_d
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance p1, La0/e1;

    invoke-direct {p1, v0}, La0/e1;-><init>(La0/o;)V

    iput-object p1, p0, La0/i1;->a:La0/e1;

    return-void
.end method


# virtual methods
.method public a()Z
    .registers 2

    iget-object v0, p0, La0/i1;->a:La0/e1;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v0, 0x0

    return v0
.end method

.method public b(La0/n;La0/n;La0/n;)J
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;TV;TV;)J"
        }
    .end annotation

    const-string v0, "initialValue"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "targetValue"

    invoke-static {p2, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "initialVelocity"

    invoke-static {p3, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, La0/i1;->a:La0/e1;

    invoke-virtual {v0, p1, p2, p3}, La0/e1;->b(La0/n;La0/n;La0/n;)J

    move-result-wide p1

    return-wide p1
.end method

.method public c(JLa0/n;La0/n;La0/n;)La0/n;
    .registers 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JTV;TV;TV;)TV;"
        }
    .end annotation

    const-string v0, "initialValue"

    invoke-static {p3, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "targetValue"

    invoke-static {p4, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "initialVelocity"

    invoke-static {p5, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, p0, La0/i1;->a:La0/e1;

    move-wide v2, p1

    move-object v4, p3

    move-object v5, p4

    move-object v6, p5

    invoke-virtual/range {v1 .. v6}, La0/e1;->c(JLa0/n;La0/n;La0/n;)La0/n;

    move-result-object p1

    return-object p1
.end method

.method public d(La0/n;La0/n;La0/n;)La0/n;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;TV;TV;)TV;"
        }
    .end annotation

    const-string v0, "initialValue"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "targetValue"

    invoke-static {p2, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "initialVelocity"

    invoke-static {p3, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, La0/i1;->a:La0/e1;

    invoke-virtual {v0, p1, p2, p3}, La0/e1;->d(La0/n;La0/n;La0/n;)La0/n;

    move-result-object p1

    return-object p1
.end method

.method public e(JLa0/n;La0/n;La0/n;)La0/n;
    .registers 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JTV;TV;TV;)TV;"
        }
    .end annotation

    const-string v0, "initialValue"

    invoke-static {p3, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "targetValue"

    invoke-static {p4, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "initialVelocity"

    invoke-static {p5, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, p0, La0/i1;->a:La0/e1;

    move-wide v2, p1

    move-object v4, p3

    move-object v5, p4

    move-object v6, p5

    invoke-virtual/range {v1 .. v6}, La0/e1;->e(JLa0/n;La0/n;La0/n;)La0/n;

    move-result-object p1

    return-object p1
.end method
