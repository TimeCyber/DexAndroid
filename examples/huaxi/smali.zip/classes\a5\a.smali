.class public La5/a;
.super Ljava/lang/Object;
.source "Taobao"


# static fields
.field public static final a:[Ljava/util/concurrent/ExecutorService;

.field public static b:Ljava/util/concurrent/atomic/AtomicInteger;


# direct methods
.method public static constructor <clinit>()V
    .registers 4

    const/4 v0, 0x2

    new-array v1, v0, [Ljava/util/concurrent/ExecutorService;

    .line 1
    sput-object v1, La5/a;->a:[Ljava/util/concurrent/ExecutorService;

    .line 2
    new-instance v1, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x0

    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    sput-object v1, La5/a;->b:Ljava/util/concurrent/atomic/AtomicInteger;

    :goto_d
    if-ge v2, v0, :cond_1f

    .line 3
    sget-object v1, La5/a;->a:[Ljava/util/concurrent/ExecutorService;

    new-instance v3, La5/b;

    invoke-direct {v3}, La5/b;-><init>()V

    invoke-static {v3}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor(Ljava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;

    move-result-object v3

    aput-object v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_d

    :cond_1f
    return-void
.end method
