.class public final La7/l;
.super Ljava/lang/Object;
.source "GsonUtils.java"


# static fields
.field public static final a:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lw9/j;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    sput-object v0, La7/l;->a:Ljava/util/Map;

    return-void
.end method

.method public static a(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/String;",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation

    .line 1
    invoke-static {}, La7/l;->b()Lw9/j;

    move-result-object v0

    .line 2
    invoke-virtual {v0, p0, p1}, Lw9/j;->b(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static b()Lw9/j;
    .registers 4

    .line 1
    sget-object v0, La7/l;->a:Ljava/util/Map;

    move-object v1, v0

    check-cast v1, Ljava/util/concurrent/ConcurrentHashMap;

    const-string v2, "delegateGson"

    invoke-virtual {v1, v2}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lw9/j;

    if-eqz v1, :cond_10

    return-object v1

    .line 2
    :cond_10
    move-object v1, v0

    check-cast v1, Ljava/util/concurrent/ConcurrentHashMap;

    const-string v2, "defaultGson"

    invoke-virtual {v1, v2}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lw9/j;

    if-nez v1, :cond_31

    .line 3
    new-instance v1, Lw9/k;

    invoke-direct {v1}, Lw9/k;-><init>()V

    const/4 v3, 0x1

    .line 4
    iput-boolean v3, v1, Lw9/k;->g:Z

    const/4 v3, 0x0

    .line 5
    iput-boolean v3, v1, Lw9/k;->j:Z

    .line 6
    invoke-virtual {v1}, Lw9/k;->a()Lw9/j;

    move-result-object v1

    .line 7
    check-cast v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v0, v2, v1}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_31
    return-object v1
.end method

.method public static c(Ljava/lang/Object;)Ljava/lang/String;
    .registers 2

    .line 1
    invoke-static {}, La7/l;->b()Lw9/j;

    move-result-object v0

    .line 2
    invoke-virtual {v0, p0}, Lw9/j;->f(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
