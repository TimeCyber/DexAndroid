.class public La6/h$b;
.super Ljava/lang/Object;
.source "LottieCompositionFactory.java"

# interfaces
.implements La6/o;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La6/h;->a(Ljava/lang/String;Ljava/util/concurrent/Callable;)La6/u;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "La6/o<",
        "Ljava/lang/Throwable;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic a:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .registers 2

    .line 1
    iput-object p1, p0, La6/h$b;->a:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onResult(Ljava/lang/Object;)V
    .registers 3

    .line 1
    check-cast p1, Ljava/lang/Throwable;

    .line 2
    sget-object p1, La6/h;->a:Ljava/util/Map;

    .line 3
    iget-object v0, p0, La6/h$b;->a:Ljava/lang/String;

    check-cast p1, Ljava/util/HashMap;

    invoke-virtual {p1, v0}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method
