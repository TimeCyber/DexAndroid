.class public final La2/c$c;
.super Lwg/j;
.source "LayoutIntrinsics.kt"

# interfaces
.implements Lvg/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La2/c;-><init>(Ljava/lang/CharSequence;Landroid/text/TextPaint;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lwg/j;",
        "Lvg/a<",
        "Ljava/lang/Float;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic a:Ljava/lang/CharSequence;

.field public final synthetic b:Landroid/text/TextPaint;


# direct methods
.method public constructor <init>(Ljava/lang/CharSequence;Landroid/text/TextPaint;)V
    .registers 3

    iput-object p1, p0, La2/c$c;->a:Ljava/lang/CharSequence;

    iput-object p2, p0, La2/c$c;->b:Landroid/text/TextPaint;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lwg/j;-><init>(I)V

    return-void
.end method


# virtual methods
.method public invoke()Ljava/lang/Object;
    .registers 11

    .line 1
    iget-object v0, p0, La2/c$c;->a:Ljava/lang/CharSequence;

    iget-object v1, p0, La2/c$c;->b:Landroid/text/TextPaint;

    const-string v2, "text"

    .line 2
    invoke-static {v0, v2}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "paint"

    invoke-static {v1, v2}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    invoke-virtual {v1}, Landroid/text/TextPaint;->getTextLocale()Ljava/util/Locale;

    move-result-object v2

    invoke-static {v2}, Ljava/text/BreakIterator;->getLineInstance(Ljava/util/Locale;)Ljava/text/BreakIterator;

    move-result-object v2

    .line 4
    new-instance v3, La2/a;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v4

    const/4 v5, 0x0

    invoke-direct {v3, v0, v5, v4}, La2/a;-><init>(Ljava/lang/CharSequence;II)V

    invoke-virtual {v2, v3}, Ljava/text/BreakIterator;->setText(Ljava/text/CharacterIterator;)V

    .line 5
    new-instance v3, Ljava/util/PriorityQueue;

    .line 6
    sget-object v4, Lt1/g;->c:Lt1/g;

    const/16 v6, 0xa

    .line 7
    invoke-direct {v3, v6, v4}, Ljava/util/PriorityQueue;-><init>(ILjava/util/Comparator;)V

    .line 8
    invoke-virtual {v2}, Ljava/text/BreakIterator;->next()I

    move-result v4

    move v5, v4

    const/4 v4, 0x0

    :goto_32
    const/4 v7, -0x1

    if-eq v5, v7, :cond_84

    .line 9
    invoke-virtual {v3}, Ljava/util/PriorityQueue;->size()I

    move-result v7

    if-ge v7, v6, :cond_4c

    .line 10
    new-instance v7, Lkg/e;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-direct {v7, v4, v8}, Lkg/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v3, v7}, Ljava/util/PriorityQueue;->add(Ljava/lang/Object;)Z

    goto :goto_7c

    .line 11
    :cond_4c
    invoke-virtual {v3}, Ljava/util/PriorityQueue;->peek()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lkg/e;

    if-eqz v7, :cond_7c

    .line 12
    iget-object v8, v7, Lkg/e;->b:Ljava/lang/Object;

    .line 13
    check-cast v8, Ljava/lang/Number;

    invoke-virtual {v8}, Ljava/lang/Number;->intValue()I

    move-result v8

    .line 14
    iget-object v7, v7, Lkg/e;->a:Ljava/lang/Object;

    .line 15
    check-cast v7, Ljava/lang/Number;

    invoke-virtual {v7}, Ljava/lang/Number;->intValue()I

    move-result v7

    sub-int/2addr v8, v7

    sub-int v7, v5, v4

    if-ge v8, v7, :cond_7c

    .line 16
    invoke-virtual {v3}, Ljava/util/PriorityQueue;->poll()Ljava/lang/Object;

    .line 17
    new-instance v7, Lkg/e;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-direct {v7, v4, v8}, Lkg/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v3, v7}, Ljava/util/PriorityQueue;->add(Ljava/lang/Object;)Z

    .line 18
    :cond_7c
    :goto_7c
    invoke-virtual {v2}, Ljava/text/BreakIterator;->next()I

    move-result v4

    move v9, v5

    move v5, v4

    move v4, v9

    goto :goto_32

    :cond_84
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v3}, Ljava/util/PriorityQueue;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_89
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_ae

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lkg/e;

    .line 20
    iget-object v5, v4, Lkg/e;->a:Ljava/lang/Object;

    .line 21
    check-cast v5, Ljava/lang/Number;

    invoke-virtual {v5}, Ljava/lang/Number;->intValue()I

    move-result v5

    .line 22
    iget-object v4, v4, Lkg/e;->b:Ljava/lang/Object;

    .line 23
    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    move-result v4

    .line 24
    invoke-static {v0, v5, v4, v1}, Landroid/text/Layout;->getDesiredWidth(Ljava/lang/CharSequence;IILandroid/text/TextPaint;)F

    move-result v4

    .line 25
    invoke-static {v2, v4}, Ljava/lang/Math;->max(FF)F

    move-result v2

    goto :goto_89

    .line 26
    :cond_ae
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    return-object v0
.end method
