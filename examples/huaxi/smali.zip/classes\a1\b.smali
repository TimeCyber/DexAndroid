.class public final La1/b;
.super Ljava/lang/Object;
.source "DrawModifier.kt"

# interfaces
.implements Lp2/b;


# instance fields
.field public a:La1/a;

.field public b:La1/h;


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    sget-object v0, La1/j;->a:La1/j;

    iput-object v0, p0, La1/b;->a:La1/a;

    return-void
.end method


# virtual methods
.method public synthetic J(F)J
    .registers 4

    invoke-static {p0, p1}, Landroidx/fragment/app/n;->f(Lp2/b;F)J

    move-result-wide v0

    return-wide v0
.end method

.method public N(I)F
    .registers 3

    int-to-float p1, p1

    .line 1
    invoke-virtual {p0}, La1/b;->getDensity()F

    move-result v0

    div-float/2addr p1, v0

    return p1
.end method

.method public P(F)F
    .registers 3

    .line 1
    invoke-virtual {p0}, La1/b;->getDensity()F

    move-result v0

    div-float/2addr p1, v0

    return p1
.end method

.method public T()F
    .registers 2

    .line 1
    iget-object v0, p0, La1/b;->a:La1/a;

    invoke-interface {v0}, La1/a;->getDensity()Lp2/b;

    move-result-object v0

    invoke-interface {v0}, Lp2/b;->T()F

    move-result v0

    return v0
.end method

.method public Z(F)F
    .registers 3

    .line 1
    invoke-virtual {p0}, La1/b;->getDensity()F

    move-result v0

    mul-float v0, v0, p1

    return v0
.end method

.method public final c()J
    .registers 3

    .line 1
    iget-object v0, p0, La1/b;->a:La1/a;

    invoke-interface {v0}, La1/a;->c()J

    move-result-wide v0

    return-wide v0
.end method

.method public final e(Lvg/l;)La1/h;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lvg/l<",
            "-",
            "Lf1/d;",
            "Lkg/l;",
            ">;)",
            "La1/h;"
        }
    .end annotation

    const-string v0, "block"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    new-instance v0, La1/h;

    invoke-direct {v0, p1}, La1/h;-><init>(Lvg/l;)V

    iput-object v0, p0, La1/b;->b:La1/h;

    return-object v0
.end method

.method public getDensity()F
    .registers 2

    .line 1
    iget-object v0, p0, La1/b;->a:La1/a;

    invoke-interface {v0}, La1/a;->getDensity()Lp2/b;

    move-result-object v0

    invoke-interface {v0}, Lp2/b;->getDensity()F

    move-result v0

    return v0
.end method

.method public final getLayoutDirection()Lp2/j;
    .registers 2

    .line 1
    iget-object v0, p0, La1/b;->a:La1/a;

    invoke-interface {v0}, La1/a;->getLayoutDirection()Lp2/j;

    move-result-object v0

    return-object v0
.end method

.method public synthetic j0(F)I
    .registers 2

    invoke-static {p0, p1}, Landroidx/fragment/app/n;->a(Lp2/b;F)I

    move-result p1

    return p1
.end method

.method public synthetic o0(J)J
    .registers 3

    invoke-static {p0, p1, p2}, Landroidx/fragment/app/n;->e(Lp2/b;J)J

    move-result-wide p1

    return-wide p1
.end method

.method public synthetic q0(J)F
    .registers 3

    invoke-static {p0, p1, p2}, Landroidx/fragment/app/n;->d(Lp2/b;J)F

    move-result p1

    return p1
.end method

.method public synthetic t(J)J
    .registers 3

    invoke-static {p0, p1, p2}, Landroidx/fragment/app/n;->c(Lp2/b;J)J

    move-result-wide p1

    return-wide p1
.end method
