.class public final La0/p0$b;
.super Lwg/j;
.source "SuspendAnimation.kt"

# interfaces
.implements Lvg/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La0/p0;->a(La0/h;La0/c;JLvg/l;Log/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lwg/j;",
        "Lvg/l<",
        "Ljava/lang/Long;",
        "Lkg/l;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic a:Lwg/w;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lwg/w<",
            "La0/f<",
            "TT;TV;>;>;"
        }
    .end annotation
.end field

.field public final synthetic b:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field

.field public final synthetic c:La0/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/c<",
            "TT;TV;>;"
        }
    .end annotation
.end field

.field public final synthetic d:La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field

.field public final synthetic e:La0/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/h<",
            "TT;TV;>;"
        }
    .end annotation
.end field

.field public final synthetic f:F

.field public final synthetic g:Lvg/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lvg/l<",
            "La0/f<",
            "TT;TV;>;",
            "Lkg/l;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lwg/w;Ljava/lang/Object;La0/c;La0/n;La0/h;FLvg/l;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwg/w<",
            "La0/f<",
            "TT;TV;>;>;TT;",
            "La0/c<",
            "TT;TV;>;TV;",
            "La0/h<",
            "TT;TV;>;F",
            "Lvg/l<",
            "-",
            "La0/f<",
            "TT;TV;>;",
            "Lkg/l;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La0/p0$b;->a:Lwg/w;

    iput-object p2, p0, La0/p0$b;->b:Ljava/lang/Object;

    iput-object p3, p0, La0/p0$b;->c:La0/c;

    iput-object p4, p0, La0/p0$b;->d:La0/n;

    iput-object p5, p0, La0/p0$b;->e:La0/h;

    iput p6, p0, La0/p0$b;->f:F

    iput-object p7, p0, La0/p0$b;->g:Lvg/l;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lwg/j;-><init>(I)V

    return-void
.end method


# virtual methods
.method public invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 16

    .line 1
    check-cast p1, Ljava/lang/Number;

    invoke-virtual {p1}, Ljava/lang/Number;->longValue()J

    move-result-wide v11

    .line 2
    iget-object p1, p0, La0/p0$b;->a:Lwg/w;

    new-instance v13, La0/f;

    .line 3
    iget-object v1, p0, La0/p0$b;->b:Ljava/lang/Object;

    .line 4
    iget-object v0, p0, La0/p0$b;->c:La0/c;

    invoke-interface {v0}, La0/c;->c()La0/u0;

    move-result-object v2

    .line 5
    iget-object v3, p0, La0/p0$b;->d:La0/n;

    .line 6
    iget-object v0, p0, La0/p0$b;->c:La0/c;

    invoke-interface {v0}, La0/c;->g()Ljava/lang/Object;

    move-result-object v6

    .line 7
    new-instance v10, La0/q0;

    iget-object v0, p0, La0/p0$b;->e:La0/h;

    invoke-direct {v10, v0}, La0/q0;-><init>(La0/h;)V

    const/4 v9, 0x1

    move-object v0, v13

    move-wide v4, v11

    move-wide v7, v11

    .line 8
    invoke-direct/range {v0 .. v10}, La0/f;-><init>(Ljava/lang/Object;La0/u0;La0/n;JLjava/lang/Object;JZLvg/a;)V

    .line 9
    iget v3, p0, La0/p0$b;->f:F

    iget-object v4, p0, La0/p0$b;->c:La0/c;

    iget-object v5, p0, La0/p0$b;->e:La0/h;

    iget-object v6, p0, La0/p0$b;->g:Lvg/l;

    move-wide v1, v11

    .line 10
    invoke-static/range {v0 .. v6}, La0/p0;->c(La0/f;JFLa0/c;La0/h;Lvg/l;)V

    .line 11
    iput-object v13, p1, Lwg/w;->a:Ljava/lang/Object;

    .line 12
    sget-object p1, Lkg/l;->a:Lkg/l;

    return-object p1
.end method
