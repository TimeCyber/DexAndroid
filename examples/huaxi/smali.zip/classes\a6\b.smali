.class public interface abstract La6/b;
.super Ljava/lang/Object;
.source "ImageAssetDelegate.java"


# virtual methods
.method public abstract a(La6/n;)Landroid/graphics/Bitmap;
.end method
