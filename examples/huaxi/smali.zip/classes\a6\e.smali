.class public La6/e;
.super Ljava/lang/Object;
.source "LottieAnimationView.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "La6/s<",
        "La6/g;",
        ">;>;"
    }
.end annotation


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/airbnb/lottie/LottieAnimationView;


# direct methods
.method public constructor <init>(Lcom/airbnb/lottie/LottieAnimationView;I)V
    .registers 3

    .line 1
    iput-object p1, p0, La6/e;->b:Lcom/airbnb/lottie/LottieAnimationView;

    iput p2, p0, La6/e;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public call()Ljava/lang/Object;
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 1
    iget-object v0, p0, La6/e;->b:Lcom/airbnb/lottie/LottieAnimationView;

    .line 2
    iget-boolean v1, v0, Lcom/airbnb/lottie/LottieAnimationView;->n:Z

    if-eqz v1, :cond_15

    .line 3
    invoke-virtual {v0}, Landroid/widget/ImageView;->getContext()Landroid/content/Context;

    move-result-object v0

    iget v1, p0, La6/e;->a:I

    .line 4
    invoke-static {v0, v1}, La6/h;->h(Landroid/content/Context;I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, La6/h;->e(Landroid/content/Context;ILjava/lang/String;)La6/s;

    move-result-object v0

    goto :goto_20

    .line 5
    :cond_15
    invoke-virtual {v0}, Landroid/widget/ImageView;->getContext()Landroid/content/Context;

    move-result-object v0

    iget v1, p0, La6/e;->a:I

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, La6/h;->e(Landroid/content/Context;ILjava/lang/String;)La6/s;

    move-result-object v0

    :goto_20
    return-object v0
.end method
