.class public final La0/w0$r;
.super Lwg/j;
.source "VectorConverters.kt"

# interfaces
.implements Lvg/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La0/w0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lwg/j;",
        "Lvg/l<",
        "La0/l;",
        "Lc1/f;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:La0/w0$r;


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    new-instance v0, La0/w0$r;

    invoke-direct {v0}, La0/w0$r;-><init>()V

    sput-object v0, La0/w0$r;->a:La0/w0$r;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lwg/j;-><init>(I)V

    return-void
.end method


# virtual methods
.method public invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 1
    check-cast p1, La0/l;

    const-string v0, "it"

    .line 2
    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    iget v0, p1, La0/l;->a:F

    .line 4
    iget p1, p1, La0/l;->b:F

    .line 5
    invoke-static {v0, p1}, Landroidx/appcompat/widget/m;->j(FF)J

    move-result-wide v0

    .line 6
    new-instance p1, Lc1/f;

    invoke-direct {p1, v0, v1}, Lc1/f;-><init>(J)V

    return-object p1
.end method
