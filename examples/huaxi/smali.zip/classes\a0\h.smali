.class public final La0/h;
.super Ljava/lang/Object;
.source "AnimationState.kt"

# interfaces
.implements Lm0/g2;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "V:",
        "La0/n;",
        ">",
        "Ljava/lang/Object;",
        "Lm0/g2<",
        "TT;>;"
    }
.end annotation


# instance fields
.field public final a:La0/u0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/u0<",
            "TT;TV;>;"
        }
    .end annotation
.end field

.field public final b:Lm0/x0;

.field public c:La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field

.field public d:J

.field public e:J

.field public f:Z


# direct methods
.method public constructor <init>(La0/u0;Ljava/lang/Object;La0/n;JJZ)V
    .registers 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La0/u0<",
            "TT;TV;>;TT;TV;JJZ)V"
        }
    .end annotation

    const-string v0, "typeConverter"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, La0/h;->a:La0/u0;

    const/4 v0, 0x0

    const/4 v1, 0x2

    .line 3
    invoke-static {p2, v0, v1, v0}, Landroidx/appcompat/widget/m;->L(Ljava/lang/Object;Lm0/c2;ILjava/lang/Object;)Lm0/x0;

    move-result-object v0

    iput-object v0, p0, La0/h;->b:Lm0/x0;

    if-eqz p3, :cond_19

    .line 4
    invoke-static {p3}, Landroidx/appcompat/widget/m;->s(La0/n;)La0/n;

    move-result-object p1

    goto :goto_27

    .line 5
    :cond_19
    invoke-interface {p1}, La0/u0;->a()Lvg/l;

    move-result-object p1

    invoke-interface {p1, p2}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La0/n;

    invoke-static {p1}, Landroidx/appcompat/widget/m;->M(La0/n;)La0/n;

    move-result-object p1

    .line 6
    :goto_27
    iput-object p1, p0, La0/h;->c:La0/n;

    .line 7
    iput-wide p4, p0, La0/h;->d:J

    .line 8
    iput-wide p6, p0, La0/h;->e:J

    .line 9
    iput-boolean p8, p0, La0/h;->f:Z

    return-void
.end method

.method public synthetic constructor <init>(La0/u0;Ljava/lang/Object;La0/n;JJZI)V
    .registers 20

    and-int/lit8 v0, p9, 0x4

    if-eqz v0, :cond_7

    const/4 v0, 0x0

    move-object v4, v0

    goto :goto_8

    :cond_7
    move-object v4, p3

    :goto_8
    and-int/lit8 v0, p9, 0x8

    const-wide/high16 v1, -0x8000000000000000L

    if-eqz v0, :cond_10

    move-wide v5, v1

    goto :goto_11

    :cond_10
    move-wide v5, p4

    :goto_11
    and-int/lit8 v0, p9, 0x10

    if-eqz v0, :cond_17

    move-wide v7, v1

    goto :goto_19

    :cond_17
    move-wide/from16 v7, p6

    :goto_19
    and-int/lit8 v0, p9, 0x20

    if-eqz v0, :cond_20

    const/4 v0, 0x0

    const/4 v9, 0x0

    goto :goto_22

    :cond_20
    move/from16 v9, p8

    :goto_22
    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    .line 10
    invoke-direct/range {v1 .. v9}, La0/h;-><init>(La0/u0;Ljava/lang/Object;La0/n;JJZ)V

    return-void
.end method


# virtual methods
.method public getValue()Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La0/h;->b:Lm0/x0;

    .line 2
    invoke-interface {v0}, Lm0/g2;->getValue()Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .registers 4

    const-string v0, "AnimationState(value="

    .line 1
    invoke-static {v0}, Landroid/support/v4/media/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 2
    invoke-virtual {p0}, La0/h;->getValue()Ljava/lang/Object;

    move-result-object v1

    .line 3
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", velocity="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4
    iget-object v1, p0, La0/h;->a:La0/u0;

    invoke-interface {v1}, La0/u0;->b()Lvg/l;

    move-result-object v1

    iget-object v2, p0, La0/h;->c:La0/n;

    invoke-interface {v1, v2}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    .line 5
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", isRunning="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 6
    iget-boolean v1, p0, La0/h;->f:Z

    .line 7
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ", lastFrameTimeNanos="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 8
    iget-wide v1, p0, La0/h;->d:J

    .line 9
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, ", finishedTimeNanos="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 10
    iget-wide v1, p0, La0/h;->e:J

    .line 11
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/16 v1, 0x29

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
