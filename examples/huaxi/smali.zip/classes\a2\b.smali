.class public final La2/b;
.super Ljava/lang/Object;
.source "LayoutHelper.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La2/b$a;
    }
.end annotation


# instance fields
.field public final a:Landroid/text/Layout;

.field public final b:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public final c:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/text/Bidi;",
            ">;"
        }
    .end annotation
.end field

.field public final d:[Z

.field public e:[C


# direct methods
.method public constructor <init>(Landroid/text/Layout;)V
    .registers 7

    const-string v0, "layout"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, La2/b;->a:Landroid/text/Layout;

    .line 3
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/4 v0, 0x0

    const/4 v1, 0x0

    .line 4
    :cond_11
    iget-object v2, p0, La2/b;->a:Landroid/text/Layout;

    invoke-virtual {v2}, Landroid/text/Layout;->getText()Ljava/lang/CharSequence;

    move-result-object v2

    const-string v3, "layout.text"

    invoke-static {v2, v3}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/16 v3, 0xa

    const/4 v4, 0x4

    invoke-static {v2, v3, v1, v0, v4}, Lfh/q;->v0(Ljava/lang/CharSequence;CIZI)I

    move-result v1

    if-gez v1, :cond_30

    .line 5
    iget-object v1, p0, La2/b;->a:Landroid/text/Layout;

    invoke-virtual {v1}, Landroid/text/Layout;->getText()Ljava/lang/CharSequence;

    move-result-object v1

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    goto :goto_32

    :cond_30
    add-int/lit8 v1, v1, 0x1

    .line 6
    :goto_32
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {p1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 7
    iget-object v2, p0, La2/b;->a:Landroid/text/Layout;

    invoke-virtual {v2}, Landroid/text/Layout;->getText()Ljava/lang/CharSequence;

    move-result-object v2

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v2

    if-lt v1, v2, :cond_11

    .line 8
    iput-object p1, p0, La2/b;->b:Ljava/util/List;

    .line 9
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1, p1}, Ljava/util/ArrayList;-><init>(I)V

    :goto_50
    if-ge v0, p1, :cond_59

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_50

    :cond_59
    iput-object v1, p0, La2/b;->c:Ljava/util/List;

    .line 10
    iget-object p1, p0, La2/b;->b:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    new-array p1, p1, [Z

    iput-object p1, p0, La2/b;->d:[Z

    .line 11
    iget-object p1, p0, La2/b;->b:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->size()I

    return-void
.end method


# virtual methods
.method public final a(IZ)F
    .registers 3

    if-eqz p2, :cond_9

    .line 1
    iget-object p2, p0, La2/b;->a:Landroid/text/Layout;

    invoke-virtual {p2, p1}, Landroid/text/Layout;->getPrimaryHorizontal(I)F

    move-result p1

    goto :goto_f

    .line 2
    :cond_9
    iget-object p2, p0, La2/b;->a:Landroid/text/Layout;

    invoke-virtual {p2, p1}, Landroid/text/Layout;->getSecondaryHorizontal(I)F

    move-result p1

    :goto_f
    return p1
.end method

.method public final b(IZZ)F
    .registers 25

    move-object/from16 v0, p0

    move/from16 v1, p1

    if-nez p3, :cond_b

    .line 1
    invoke-virtual/range {p0 .. p2}, La2/b;->a(IZ)F

    move-result v1

    return v1

    .line 2
    :cond_b
    iget-object v2, v0, La2/b;->a:Landroid/text/Layout;

    const-string v3, "<this>"

    .line 3
    invoke-static {v2, v3}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, -0x1

    const/4 v4, 0x0

    if-gtz v1, :cond_18

    const/4 v2, 0x0

    goto :goto_47

    .line 4
    :cond_18
    invoke-virtual {v2}, Landroid/text/Layout;->getText()Ljava/lang/CharSequence;

    move-result-object v5

    invoke-interface {v5}, Ljava/lang/CharSequence;->length()I

    move-result v5

    if-lt v1, v5, :cond_28

    invoke-virtual {v2}, Landroid/text/Layout;->getLineCount()I

    move-result v2

    add-int/2addr v2, v3

    goto :goto_47

    .line 5
    :cond_28
    invoke-virtual {v2, v1}, Landroid/text/Layout;->getLineForOffset(I)I

    move-result v5

    .line 6
    invoke-virtual {v2, v5}, Landroid/text/Layout;->getLineStart(I)I

    move-result v6

    .line 7
    invoke-virtual {v2, v5}, Landroid/text/Layout;->getLineEnd(I)I

    move-result v2

    if-eq v6, v1, :cond_39

    if-eq v2, v1, :cond_39

    goto :goto_42

    :cond_39
    if-ne v6, v1, :cond_40

    if-eqz p3, :cond_42

    add-int/lit8 v5, v5, -0x1

    goto :goto_42

    :cond_40
    if-eqz p3, :cond_44

    :cond_42
    :goto_42
    move v2, v5

    goto :goto_47

    :cond_44
    add-int/lit8 v5, v5, 0x1

    goto :goto_42

    .line 8
    :goto_47
    iget-object v5, v0, La2/b;->a:Landroid/text/Layout;

    invoke-virtual {v5, v2}, Landroid/text/Layout;->getLineStart(I)I

    move-result v5

    .line 9
    iget-object v6, v0, La2/b;->a:Landroid/text/Layout;

    invoke-virtual {v6, v2}, Landroid/text/Layout;->getLineEnd(I)I

    move-result v6

    if-eq v1, v5, :cond_5c

    if-eq v1, v6, :cond_5c

    .line 10
    invoke-virtual/range {p0 .. p2}, La2/b;->a(IZ)F

    move-result v1

    return v1

    :cond_5c
    if-eqz v1, :cond_273

    .line 11
    iget-object v7, v0, La2/b;->a:Landroid/text/Layout;

    invoke-virtual {v7}, Landroid/text/Layout;->getText()Ljava/lang/CharSequence;

    move-result-object v7

    invoke-interface {v7}, Ljava/lang/CharSequence;->length()I

    move-result v7

    if-ne v1, v7, :cond_6c

    goto/16 :goto_273

    .line 12
    :cond_6c
    iget-object v7, v0, La2/b;->b:Ljava/util/List;

    invoke-static/range {p1 .. p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    const/4 v9, 0x6

    invoke-static {v7, v8, v4, v4, v9}, Lp/h;->i(Ljava/util/List;Ljava/lang/Comparable;III)I

    move-result v7

    const/4 v8, 0x1

    if-gez v7, :cond_7d

    add-int/2addr v7, v8

    neg-int v7, v7

    goto :goto_7e

    :cond_7d
    add-int/2addr v7, v8

    :goto_7e
    if-eqz p3, :cond_93

    if-lez v7, :cond_93

    .line 13
    iget-object v9, v0, La2/b;->b:Ljava/util/List;

    add-int/lit8 v10, v7, -0x1

    invoke-interface {v9, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/Number;

    invoke-virtual {v9}, Ljava/lang/Number;->intValue()I

    move-result v9

    if-ne v1, v9, :cond_93

    move v7, v10

    .line 14
    :cond_93
    invoke-virtual {v0, v7}, La2/b;->d(I)Z

    move-result v9

    :goto_97
    if-lez v6, :cond_d2

    .line 15
    iget-object v10, v0, La2/b;->a:Landroid/text/Layout;

    invoke-virtual {v10}, Landroid/text/Layout;->getText()Ljava/lang/CharSequence;

    move-result-object v10

    add-int/lit8 v11, v6, -0x1

    invoke-interface {v10, v11}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v10

    const/16 v12, 0x20

    if-eq v10, v12, :cond_cd

    const/16 v12, 0xa

    if-eq v10, v12, :cond_cd

    const/16 v12, 0x1680

    if-eq v10, v12, :cond_cd

    const/16 v12, 0x2000

    if-gt v12, v10, :cond_bb

    const/16 v12, 0x200b

    if-ge v10, v12, :cond_bb

    const/4 v12, 0x1

    goto :goto_bc

    :cond_bb
    const/4 v12, 0x0

    :goto_bc
    if-eqz v12, :cond_c2

    const/16 v12, 0x2007

    if-ne v10, v12, :cond_cd

    :cond_c2
    const/16 v12, 0x205f

    if-eq v10, v12, :cond_cd

    const/16 v12, 0x3000

    if-ne v10, v12, :cond_cb

    goto :goto_cd

    :cond_cb
    const/4 v10, 0x0

    goto :goto_ce

    :cond_cd
    :goto_cd
    const/4 v10, 0x1

    :goto_ce
    if-eqz v10, :cond_d2

    move v6, v11

    goto :goto_97

    .line 16
    :cond_d2
    invoke-virtual {v0, v7}, La2/b;->c(I)I

    move-result v10

    sub-int v11, v5, v10

    sub-int/2addr v6, v10

    .line 17
    iget-object v10, v0, La2/b;->d:[Z

    aget-boolean v10, v10, v7

    const/4 v12, 0x0

    if-eqz v10, :cond_ea

    .line 18
    iget-object v10, v0, La2/b;->c:Ljava/util/List;

    invoke-interface {v10, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/text/Bidi;

    goto/16 :goto_153

    :cond_ea
    if-nez v7, :cond_ee

    const/4 v10, 0x0

    goto :goto_fc

    .line 19
    :cond_ee
    iget-object v10, v0, La2/b;->b:Ljava/util/List;

    add-int/lit8 v13, v7, -0x1

    invoke-interface {v10, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/Number;

    invoke-virtual {v10}, Ljava/lang/Number;->intValue()I

    move-result v10

    .line 20
    :goto_fc
    iget-object v13, v0, La2/b;->b:Ljava/util/List;

    invoke-interface {v13, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/Number;

    invoke-virtual {v13}, Ljava/lang/Number;->intValue()I

    move-result v13

    sub-int v15, v13, v10

    .line 21
    iget-object v14, v0, La2/b;->e:[C

    if-eqz v14, :cond_111

    .line 22
    array-length v3, v14

    if-ge v3, v15, :cond_113

    .line 23
    :cond_111
    new-array v14, v15, [C

    :cond_113
    move-object v3, v14

    .line 24
    iget-object v14, v0, La2/b;->a:Landroid/text/Layout;

    invoke-virtual {v14}, Landroid/text/Layout;->getText()Ljava/lang/CharSequence;

    move-result-object v14

    invoke-static {v14, v10, v13, v3, v4}, Landroid/text/TextUtils;->getChars(Ljava/lang/CharSequence;II[CI)V

    .line 25
    invoke-static {v3, v4, v15}, Ljava/text/Bidi;->requiresBidi([CII)Z

    move-result v10

    if-eqz v10, :cond_13d

    .line 26
    invoke-virtual {v0, v7}, La2/b;->d(I)Z

    move-result v20

    .line 27
    new-instance v10, Ljava/text/Bidi;

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    move-object v14, v10

    move v13, v15

    move-object v15, v3

    move/from16 v19, v13

    invoke-direct/range {v14 .. v20}, Ljava/text/Bidi;-><init>([CI[BIII)V

    .line 28
    invoke-virtual {v10}, Ljava/text/Bidi;->getRunCount()I

    move-result v13

    if-ne v13, v8, :cond_13e

    :cond_13d
    move-object v10, v12

    .line 29
    :cond_13e
    iget-object v13, v0, La2/b;->c:Ljava/util/List;

    invoke-interface {v13, v7, v10}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 30
    iget-object v13, v0, La2/b;->d:[Z

    aput-boolean v8, v13, v7

    if-eqz v10, :cond_150

    .line 31
    iget-object v7, v0, La2/b;->e:[C

    if-ne v3, v7, :cond_14f

    move-object v3, v12

    goto :goto_150

    :cond_14f
    move-object v3, v7

    .line 32
    :cond_150
    :goto_150
    iput-object v3, v0, La2/b;->e:[C

    move-object v7, v10

    :goto_153
    if-eqz v7, :cond_159

    .line 33
    invoke-virtual {v7, v11, v6}, Ljava/text/Bidi;->createLineBidi(II)Ljava/text/Bidi;

    move-result-object v12

    :cond_159
    if-eqz v12, :cond_24f

    .line 34
    invoke-virtual {v12}, Ljava/text/Bidi;->getRunCount()I

    move-result v3

    if-ne v3, v8, :cond_163

    goto/16 :goto_24f

    .line 35
    :cond_163
    invoke-virtual {v12}, Ljava/text/Bidi;->getRunCount()I

    move-result v3

    new-array v6, v3, [La2/b$a;

    const/4 v7, 0x0

    :goto_16a
    if-ge v7, v3, :cond_18b

    .line 36
    new-instance v10, La2/b$a;

    .line 37
    invoke-virtual {v12, v7}, Ljava/text/Bidi;->getRunStart(I)I

    move-result v11

    add-int/2addr v11, v5

    .line 38
    invoke-virtual {v12, v7}, Ljava/text/Bidi;->getRunLimit(I)I

    move-result v13

    add-int/2addr v13, v5

    .line 39
    invoke-virtual {v12, v7}, Ljava/text/Bidi;->getRunLevel(I)I

    move-result v14

    rem-int/lit8 v14, v14, 0x2

    if-ne v14, v8, :cond_182

    const/4 v14, 0x1

    goto :goto_183

    :cond_182
    const/4 v14, 0x0

    .line 40
    :goto_183
    invoke-direct {v10, v11, v13, v14}, La2/b$a;-><init>(IIZ)V

    aput-object v10, v6, v7

    add-int/lit8 v7, v7, 0x1

    goto :goto_16a

    .line 41
    :cond_18b
    invoke-virtual {v12}, Ljava/text/Bidi;->getRunCount()I

    move-result v7

    new-array v10, v7, [B

    const/4 v11, 0x0

    :goto_192
    if-ge v11, v7, :cond_19e

    invoke-virtual {v12, v11}, Ljava/text/Bidi;->getRunLevel(I)I

    move-result v13

    int-to-byte v13, v13

    aput-byte v13, v10, v11

    add-int/lit8 v11, v11, 0x1

    goto :goto_192

    .line 42
    :cond_19e
    invoke-static {v10, v4, v6, v4, v3}, Ljava/text/Bidi;->reorderVisually([BI[Ljava/lang/Object;II)V

    if-ne v1, v5, :cond_1f9

    const/4 v5, 0x0

    :goto_1a4
    if-ge v5, v3, :cond_1b6

    .line 43
    aget-object v7, v6, v5

    .line 44
    iget v7, v7, La2/b$a;->a:I

    if-ne v7, v1, :cond_1ae

    const/4 v7, 0x1

    goto :goto_1af

    :cond_1ae
    const/4 v7, 0x0

    :goto_1af
    if-eqz v7, :cond_1b3

    move v3, v5

    goto :goto_1b7

    :cond_1b3
    add-int/lit8 v5, v5, 0x1

    goto :goto_1a4

    :cond_1b6
    const/4 v3, -0x1

    .line 45
    :goto_1b7
    aget-object v1, v6, v3

    if-nez p2, :cond_1c2

    .line 46
    iget-boolean v1, v1, La2/b$a;->c:Z

    if-ne v9, v1, :cond_1c0

    goto :goto_1c2

    :cond_1c0
    move v4, v9

    goto :goto_1c5

    :cond_1c2
    :goto_1c2
    if-nez v9, :cond_1c5

    const/4 v4, 0x1

    :cond_1c5
    :goto_1c5
    if-nez v3, :cond_1d0

    if-eqz v4, :cond_1d0

    .line 47
    iget-object v1, v0, La2/b;->a:Landroid/text/Layout;

    invoke-virtual {v1, v2}, Landroid/text/Layout;->getLineLeft(I)F

    move-result v1

    return v1

    .line 48
    :cond_1d0
    invoke-static {v6}, Llg/j;->l0([Ljava/lang/Object;)I

    move-result v1

    if-ne v3, v1, :cond_1df

    if-nez v4, :cond_1df

    .line 49
    iget-object v1, v0, La2/b;->a:Landroid/text/Layout;

    invoke-virtual {v1, v2}, Landroid/text/Layout;->getLineRight(I)F

    move-result v1

    return v1

    :cond_1df
    if-eqz v4, :cond_1ed

    .line 50
    iget-object v1, v0, La2/b;->a:Landroid/text/Layout;

    sub-int/2addr v3, v8

    aget-object v2, v6, v3

    .line 51
    iget v2, v2, La2/b$a;->a:I

    .line 52
    invoke-virtual {v1, v2}, Landroid/text/Layout;->getPrimaryHorizontal(I)F

    move-result v1

    return v1

    .line 53
    :cond_1ed
    iget-object v1, v0, La2/b;->a:Landroid/text/Layout;

    add-int/2addr v3, v8

    aget-object v2, v6, v3

    .line 54
    iget v2, v2, La2/b$a;->a:I

    .line 55
    invoke-virtual {v1, v2}, Landroid/text/Layout;->getPrimaryHorizontal(I)F

    move-result v1

    return v1

    :cond_1f9
    const/4 v5, 0x0

    :goto_1fa
    if-ge v5, v3, :cond_20c

    .line 56
    aget-object v7, v6, v5

    .line 57
    iget v7, v7, La2/b$a;->b:I

    if-ne v7, v1, :cond_204

    const/4 v7, 0x1

    goto :goto_205

    :cond_204
    const/4 v7, 0x0

    :goto_205
    if-eqz v7, :cond_209

    move v3, v5

    goto :goto_20d

    :cond_209
    add-int/lit8 v5, v5, 0x1

    goto :goto_1fa

    :cond_20c
    const/4 v3, -0x1

    .line 58
    :goto_20d
    aget-object v1, v6, v3

    if-nez p2, :cond_21a

    .line 59
    iget-boolean v1, v1, La2/b$a;->c:Z

    if-ne v9, v1, :cond_216

    goto :goto_21a

    :cond_216
    if-nez v9, :cond_21b

    const/4 v4, 0x1

    goto :goto_21b

    :cond_21a
    :goto_21a
    move v4, v9

    :cond_21b
    :goto_21b
    if-nez v3, :cond_226

    if-eqz v4, :cond_226

    .line 60
    iget-object v1, v0, La2/b;->a:Landroid/text/Layout;

    invoke-virtual {v1, v2}, Landroid/text/Layout;->getLineLeft(I)F

    move-result v1

    return v1

    .line 61
    :cond_226
    invoke-static {v6}, Llg/j;->l0([Ljava/lang/Object;)I

    move-result v1

    if-ne v3, v1, :cond_235

    if-nez v4, :cond_235

    .line 62
    iget-object v1, v0, La2/b;->a:Landroid/text/Layout;

    invoke-virtual {v1, v2}, Landroid/text/Layout;->getLineRight(I)F

    move-result v1

    return v1

    :cond_235
    if-eqz v4, :cond_243

    .line 63
    iget-object v1, v0, La2/b;->a:Landroid/text/Layout;

    sub-int/2addr v3, v8

    aget-object v2, v6, v3

    .line 64
    iget v2, v2, La2/b$a;->b:I

    .line 65
    invoke-virtual {v1, v2}, Landroid/text/Layout;->getPrimaryHorizontal(I)F

    move-result v1

    return v1

    .line 66
    :cond_243
    iget-object v1, v0, La2/b;->a:Landroid/text/Layout;

    add-int/2addr v3, v8

    aget-object v2, v6, v3

    .line 67
    iget v2, v2, La2/b$a;->b:I

    .line 68
    invoke-virtual {v1, v2}, Landroid/text/Layout;->getPrimaryHorizontal(I)F

    move-result v1

    return v1

    .line 69
    :cond_24f
    :goto_24f
    iget-object v3, v0, La2/b;->a:Landroid/text/Layout;

    invoke-virtual {v3, v5}, Landroid/text/Layout;->isRtlCharAt(I)Z

    move-result v3

    if-nez p2, :cond_259

    if-ne v9, v3, :cond_25e

    :cond_259
    if-nez v9, :cond_25d

    const/4 v9, 0x1

    goto :goto_25e

    :cond_25d
    const/4 v9, 0x0

    :cond_25e
    :goto_25e
    if-ne v1, v5, :cond_262

    move v4, v9

    goto :goto_265

    :cond_262
    if-nez v9, :cond_265

    const/4 v4, 0x1

    .line 70
    :cond_265
    :goto_265
    iget-object v1, v0, La2/b;->a:Landroid/text/Layout;

    if-eqz v4, :cond_26e

    invoke-virtual {v1, v2}, Landroid/text/Layout;->getLineLeft(I)F

    move-result v1

    goto :goto_272

    :cond_26e
    invoke-virtual {v1, v2}, Landroid/text/Layout;->getLineRight(I)F

    move-result v1

    :goto_272
    return v1

    .line 71
    :cond_273
    :goto_273
    invoke-virtual/range {p0 .. p2}, La2/b;->a(IZ)F

    move-result v1

    return v1
.end method

.method public final c(I)I
    .registers 3

    if-nez p1, :cond_4

    const/4 p1, 0x0

    goto :goto_12

    .line 1
    :cond_4
    iget-object v0, p0, La2/b;->b:Ljava/util/List;

    add-int/lit8 p1, p1, -0x1

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Number;

    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    move-result p1

    :goto_12
    return p1
.end method

.method public final d(I)Z
    .registers 3

    .line 1
    iget-object v0, p0, La2/b;->a:Landroid/text/Layout;

    invoke-virtual {p0, p1}, La2/b;->c(I)I

    move-result p1

    invoke-virtual {v0, p1}, Landroid/text/Layout;->getLineForOffset(I)I

    move-result p1

    .line 2
    iget-object v0, p0, La2/b;->a:Landroid/text/Layout;

    invoke-virtual {v0, p1}, Landroid/text/Layout;->getParagraphDirection(I)I

    move-result p1

    const/4 v0, -0x1

    if-ne p1, v0, :cond_15

    const/4 p1, 0x1

    goto :goto_16

    :cond_15
    const/4 p1, 0x0

    :goto_16
    return p1
.end method
