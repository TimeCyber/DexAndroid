.class public La0/u;
.super Ljava/lang/Object;
.source "DecayAnimationSpec.kt"

# interfaces
.implements Lr1/z0;


# static fields
.field public static a:Landroid/content/Context;

.field public static final b:La0/u;

.field public static final c:[I

.field public static final d:[J

.field public static final e:[Ljava/lang/Object;


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, La0/u;

    invoke-direct {v0}, La0/u;-><init>()V

    sput-object v0, La0/u;->b:La0/u;

    const/4 v0, 0x0

    new-array v1, v0, [I

    .line 2
    sput-object v1, La0/u;->c:[I

    new-array v1, v0, [J

    .line 3
    sput-object v1, La0/u;->d:[J

    new-array v0, v0, [Ljava/lang/Object;

    .line 4
    sput-object v0, La0/u;->e:[Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final A(Lb1/l;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lb1/l;->d:Lb1/b0;

    .line 2
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    if-eqz v0, :cond_2d

    const/4 v1, 0x1

    if-eq v0, v1, :cond_2d

    const/4 v1, 0x2

    if-eq v0, v1, :cond_2a

    const/4 v1, 0x3

    if-eq v0, v1, :cond_1e

    const/4 v1, 0x4

    if-eq v0, v1, :cond_1e

    const/4 v1, 0x5

    if-ne v0, v1, :cond_18

    goto :goto_2d

    :cond_18
    new-instance p0, Lq6/a;

    invoke-direct {p0}, Lq6/a;-><init>()V

    throw p0

    .line 3
    :cond_1e
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "Granting focus to a deactivated node."

    .line 4
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 5
    :cond_2a
    sget-object v0, Lb1/b0;->c:Lb1/b0;

    goto :goto_2f

    .line 6
    :cond_2d
    :goto_2d
    sget-object v0, Lb1/b0;->a:Lb1/b0;

    .line 7
    :goto_2f
    invoke-virtual {p0, v0}, Lb1/l;->b(Lb1/b0;)V

    return-void
.end method

.method public static B(I)I
    .registers 3

    const/4 v0, 0x4

    :goto_1
    const/16 v1, 0x20

    if-ge v0, v1, :cond_f

    const/4 v1, 0x1

    shl-int/2addr v1, v0

    add-int/lit8 v1, v1, -0xc

    if-gt p0, v1, :cond_c

    return v1

    :cond_c
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_f
    return p0
.end method

.method public static C(I)I
    .registers 1

    mul-int/lit8 p0, p0, 0x4

    .line 1
    invoke-static {p0}, La0/u;->B(I)I

    move-result p0

    div-int/lit8 p0, p0, 0x4

    return p0
.end method

.method public static D(I)I
    .registers 1

    mul-int/lit8 p0, p0, 0x8

    .line 1
    invoke-static {p0}, La0/u;->B(I)I

    move-result p0

    div-int/lit8 p0, p0, 0x8

    return p0
.end method

.method public static E(Ljava/lang/CharSequence;)Z
    .registers 1

    if-eqz p0, :cond_b

    .line 1
    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result p0

    if-nez p0, :cond_9

    goto :goto_b

    :cond_9
    const/4 p0, 0x0

    goto :goto_c

    :cond_b
    :goto_b
    const/4 p0, 0x1

    :goto_c
    return p0
.end method

.method public static final F(J)Z
    .registers 4

    const-wide v0, 0xffffffffL

    and-long/2addr p0, v0

    long-to-int p1, p0

    if-eqz p1, :cond_b

    const/4 p0, 0x1

    goto :goto_c

    :cond_b
    const/4 p0, 0x0

    :goto_c
    return p0
.end method

.method public static final G([Ljava/lang/Object;)Ljava/util/Iterator;
    .registers 2

    const-string v0, "array"

    invoke-static {p0, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    new-instance v0, Llg/x;

    invoke-direct {v0, p0}, Llg/x;-><init>([Ljava/lang/Object;)V

    return-object v0
.end method

.method public static H(DD)Z
    .registers 7

    const-wide v0, 0x4052004189374bc7L    # 72.004

    cmpg-double v2, p0, v0

    if-ltz v2, :cond_27

    const-wide v0, 0x40613ab5dcc63f14L    # 137.8347

    cmpl-double v2, p0, v0

    if-gtz v2, :cond_27

    const-wide p0, 0x3fea89a027525461L    # 0.8293

    cmpg-double v0, p2, p0

    if-ltz v0, :cond_27

    const-wide p0, 0x404be9de69ad42c4L    # 55.8271

    cmpl-double v0, p2, p0

    if-lez v0, :cond_25

    goto :goto_27

    :cond_25
    const/4 p0, 0x0

    goto :goto_28

    :cond_27
    :goto_27
    const/4 p0, 0x1

    :goto_28
    return p0
.end method

.method public static final I(ILm0/g;I)Lg1/b;
    .registers 54

    move/from16 v0, p0

    move-object/from16 v7, p1

    const v1, 0x1c403a8f

    invoke-interface {v7, v1}, Lm0/g;->e(I)V

    .line 1
    sget-object v1, Landroidx/compose/ui/platform/v;->b:Lm0/e1;

    .line 2
    invoke-interface {v7, v1}, Lm0/g;->C(Lm0/w;)Ljava/lang/Object;

    move-result-object v1

    .line 3
    check-cast v1, Landroid/content/Context;

    .line 4
    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const v3, -0x1d58f75c

    .line 5
    invoke-interface {v7, v3}, Lm0/g;->e(I)V

    .line 6
    invoke-interface/range {p1 .. p1}, Lm0/g;->f()Ljava/lang/Object;

    move-result-object v4

    .line 7
    sget-object v5, Lm0/g$a;->b:Ljava/lang/Object;

    if-ne v4, v5, :cond_2c

    .line 8
    new-instance v4, Landroid/util/TypedValue;

    invoke-direct {v4}, Landroid/util/TypedValue;-><init>()V

    .line 9
    invoke-interface {v7, v4}, Lm0/g;->H(Ljava/lang/Object;)V

    .line 10
    :cond_2c
    invoke-interface/range {p1 .. p1}, Lm0/g;->L()V

    .line 11
    check-cast v4, Landroid/util/TypedValue;

    const/4 v6, 0x1

    .line 12
    invoke-virtual {v2, v0, v4, v6}, Landroid/content/res/Resources;->getValue(ILandroid/util/TypedValue;Z)V

    .line 13
    iget-object v4, v4, Landroid/util/TypedValue;->string:Ljava/lang/CharSequence;

    const/4 v8, 0x2

    const/4 v9, 0x0

    if-eqz v4, :cond_45

    const-string v10, ".xml"

    .line 14
    invoke-static {v4, v10, v9, v8}, Lfh/q;->q0(Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZI)Z

    move-result v10

    if-ne v10, v6, :cond_45

    const/4 v10, 0x1

    goto :goto_46

    :cond_45
    const/4 v10, 0x0

    :goto_46
    const-string v11, "Only VectorDrawables and rasterized asset types are supported ex. PNG, JPG"

    if-eqz v10, :cond_5d6

    const v4, -0x2c0108e9

    invoke-interface {v7, v4}, Lm0/g;->e(I)V

    .line 15
    invoke-virtual {v1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v1

    const-string v4, "context.theme"

    invoke-static {v1, v4}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const v4, 0x7dea3d4c

    .line 16
    invoke-interface {v7, v4}, Lm0/g;->e(I)V

    .line 17
    sget-object v4, Landroidx/compose/ui/platform/v;->c:Lm0/e1;

    .line 18
    invoke-interface {v7, v4}, Lm0/g;->C(Lm0/w;)Ljava/lang/Object;

    move-result-object v4

    .line 19
    check-cast v4, Lw1/b;

    .line 20
    new-instance v5, Lw1/b$b;

    invoke-direct {v5, v1, v0}, Lw1/b$b;-><init>(Landroid/content/res/Resources$Theme;I)V

    .line 21
    invoke-static {v4}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 22
    iget-object v10, v4, Lw1/b;->a:Ljava/util/HashMap;

    invoke-virtual {v10, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/ref/WeakReference;

    if-eqz v10, :cond_80

    invoke-virtual {v10}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lw1/b$a;

    goto :goto_81

    :cond_80
    const/4 v10, 0x0

    :goto_81
    if-nez v10, :cond_4d9

    .line 23
    invoke-virtual {v2, v0}, Landroid/content/res/Resources;->getXml(I)Landroid/content/res/XmlResourceParser;

    move-result-object v0

    const-string v10, "res.getXml(id)"

    invoke-static {v0, v10}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    invoke-interface {v0}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v10

    :goto_90
    if-eq v10, v8, :cond_99

    if-eq v10, v6, :cond_99

    .line 25
    invoke-interface {v0}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v10

    goto :goto_90

    :cond_99
    if-ne v10, v8, :cond_4d1

    .line 26
    invoke-interface {v0}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v10

    const-string v14, "vector"

    invoke-static {v10, v14}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_4cb

    .line 27
    invoke-static {v0}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    move-result-object v10

    .line 28
    new-instance v11, Li1/a;

    invoke-direct {v11, v0, v9, v8}, Li1/a;-><init>(Lorg/xmlpull/v1/XmlPullParser;II)V

    const-string v14, "attrs"

    .line 29
    invoke-static {v10, v14}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    sget-object v14, Le0/q0;->a:[I

    .line 31
    invoke-virtual {v11, v2, v1, v10, v14}, Li1/a;->c(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v14

    const-string v15, "autoMirrored"

    .line 32
    invoke-static {v0, v15}, Ld3/l;->f(Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;)Z

    move-result v15

    const/4 v13, 0x5

    if-nez v15, :cond_c7

    const/16 v25, 0x0

    goto :goto_cd

    .line 33
    :cond_c7
    invoke-virtual {v14, v13, v9}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v15

    move/from16 v25, v15

    .line 34
    :goto_cd
    invoke-virtual {v14}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v15

    invoke-virtual {v11, v15}, Li1/a;->d(I)V

    const-string v15, "viewportWidth"

    const/4 v3, 0x7

    const/4 v12, 0x0

    .line 35
    invoke-static {v14, v0, v15, v3, v12}, Ld3/l;->c(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v20

    .line 36
    invoke-virtual {v14}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v15

    invoke-virtual {v11, v15}, Li1/a;->d(I)V

    const-string v15, "viewportHeight"

    const/16 v9, 0x8

    .line 37
    invoke-static {v14, v0, v15, v9, v12}, Ld3/l;->c(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v21

    .line 38
    invoke-virtual {v14}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v15

    invoke-virtual {v11, v15}, Li1/a;->d(I)V

    cmpg-float v15, v20, v12

    if-lez v15, :cond_4b0

    cmpg-float v15, v21, v12

    if-lez v15, :cond_495

    const/4 v15, 0x3

    .line 39
    invoke-virtual {v14, v15, v12}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v16

    .line 40
    invoke-virtual {v14}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v9

    invoke-virtual {v11, v9}, Li1/a;->d(I)V

    .line 41
    invoke-virtual {v14, v8, v12}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v9

    .line 42
    invoke-virtual {v14}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v3

    invoke-virtual {v11, v3}, Li1/a;->d(I)V

    .line 43
    invoke-virtual {v14, v6}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v3

    if-eqz v3, :cond_145

    .line 44
    new-instance v3, Landroid/util/TypedValue;

    invoke-direct {v3}, Landroid/util/TypedValue;-><init>()V

    .line 45
    invoke-virtual {v14, v6, v3}, Landroid/content/res/TypedArray;->getValue(ILandroid/util/TypedValue;)Z

    .line 46
    iget v3, v3, Landroid/util/TypedValue;->type:I

    if-ne v3, v8, :cond_128

    .line 47
    sget-object v3, Ld1/s;->b:Ld1/s$a;

    .line 48
    sget-wide v17, Ld1/s;->h:J

    goto :goto_149

    :cond_128
    const-string v3, "tint"

    .line 49
    invoke-static {v14, v0, v1, v3, v6}, Ld3/l;->a(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Landroid/content/res/Resources$Theme;Ljava/lang/String;I)Landroid/content/res/ColorStateList;

    move-result-object v3

    .line 50
    invoke-virtual {v14}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v12

    invoke-virtual {v11, v12}, Li1/a;->d(I)V

    if-eqz v3, :cond_140

    .line 51
    invoke-virtual {v3}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    move-result v3

    invoke-static {v3}, Landroidx/appcompat/widget/m;->d(I)J

    move-result-wide v17

    goto :goto_149

    .line 52
    :cond_140
    sget-object v3, Ld1/s;->b:Ld1/s$a;

    .line 53
    sget-wide v17, Ld1/s;->h:J

    goto :goto_149

    .line 54
    :cond_145
    sget-object v3, Ld1/s;->b:Ld1/s$a;

    .line 55
    sget-wide v17, Ld1/s;->h:J

    :goto_149
    move-wide/from16 v22, v17

    const/4 v3, 0x6

    const/4 v12, -0x1

    .line 56
    invoke-virtual {v14, v3, v12}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v8

    .line 57
    invoke-virtual {v14}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v3

    invoke-virtual {v11, v3}, Li1/a;->d(I)V

    const/16 v3, 0x9

    if-eq v8, v12, :cond_177

    if-eq v8, v15, :cond_174

    if-eq v8, v13, :cond_177

    if-eq v8, v3, :cond_171

    packed-switch v8, :pswitch_data_632

    goto :goto_177

    :pswitch_166
    const/16 v24, 0xc

    goto :goto_179

    :pswitch_169
    const/16 v8, 0xe

    const/16 v24, 0xe

    goto :goto_179

    :pswitch_16e
    const/16 v24, 0xd

    goto :goto_179

    :cond_171
    const/16 v24, 0x9

    goto :goto_179

    :cond_174
    const/16 v24, 0x3

    goto :goto_179

    :cond_177
    :goto_177
    const/16 v24, 0x5

    .line 58
    :goto_179
    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v8

    iget v8, v8, Landroid/util/DisplayMetrics;->density:F

    div-float v18, v16, v8

    .line 59
    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v8

    iget v8, v8, Landroid/util/DisplayMetrics;->density:F

    div-float v19, v9, v8

    .line 60
    invoke-virtual {v14}, Landroid/content/res/TypedArray;->recycle()V

    .line 61
    new-instance v8, Lh1/c$a;

    const/16 v17, 0x0

    const/16 v26, 0x1

    move-object/from16 v16, v8

    invoke-direct/range {v16 .. v26}, Lh1/c$a;-><init>(Ljava/lang/String;FFFFJIZI)V

    const/4 v9, 0x0

    .line 62
    :goto_198
    invoke-interface {v0}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I

    move-result v14

    if-eq v14, v6, :cond_1ad

    .line 63
    invoke-interface {v0}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v14

    if-ge v14, v6, :cond_1ab

    invoke-interface {v0}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I

    move-result v14

    if-ne v14, v15, :cond_1ab

    goto :goto_1ad

    :cond_1ab
    const/4 v14, 0x0

    goto :goto_1ae

    :cond_1ad
    :goto_1ad
    const/4 v14, 0x1

    :goto_1ae
    if-nez v14, :cond_441

    .line 64
    iget-object v14, v11, Li1/a;->a:Lorg/xmlpull/v1/XmlPullParser;

    .line 65
    invoke-interface {v14}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I

    move-result v14

    const-string v3, "group"

    const/4 v12, 0x2

    if-eq v14, v12, :cond_1db

    if-eq v14, v15, :cond_1bf

    goto/16 :goto_42e

    .line 66
    :cond_1bf
    iget-object v12, v11, Li1/a;->a:Lorg/xmlpull/v1/XmlPullParser;

    .line 67
    invoke-interface {v12}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v12

    invoke-static {v3, v12}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_42e

    add-int/lit8 v9, v9, 0x1

    const/4 v3, 0x0

    :goto_1ce
    if-ge v3, v9, :cond_1d6

    .line 68
    invoke-virtual {v8}, Lh1/c$a;->c()Lh1/c$a;

    add-int/lit8 v3, v3, 0x1

    goto :goto_1ce

    :cond_1d6
    const/4 v6, 0x0

    const/4 v7, -0x1

    const/4 v9, 0x0

    goto/16 :goto_430

    .line 69
    :cond_1db
    iget-object v12, v11, Li1/a;->a:Lorg/xmlpull/v1/XmlPullParser;

    .line 70
    invoke-interface {v12}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v12

    if-eqz v12, :cond_42e

    invoke-virtual {v12}, Ljava/lang/String;->hashCode()I

    move-result v14

    const v15, -0x624e8b7e

    const-string v17, ""

    if-eq v14, v15, :cond_3eb

    const v15, 0x346425

    const/high16 v6, 0x3f800000    # 1.0f

    if-eq v14, v15, :cond_28d

    const v15, 0x5e0f67f

    if-eq v14, v15, :cond_1fc

    goto/16 :goto_42e

    :cond_1fc
    invoke-virtual {v12, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_204

    goto/16 :goto_42e

    .line 71
    :cond_204
    sget-object v3, Le0/q0;->b:[I

    .line 72
    invoke-virtual {v11, v2, v1, v10, v3}, Li1/a;->c(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v3

    .line 73
    iget-object v12, v11, Li1/a;->a:Lorg/xmlpull/v1/XmlPullParser;

    const-string v14, "rotation"

    const/4 v15, 0x0

    .line 74
    invoke-static {v3, v12, v14, v13, v15}, Ld3/l;->c(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v36

    .line 75
    invoke-virtual {v3}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v12

    invoke-virtual {v11, v12}, Li1/a;->d(I)V

    const/4 v12, 0x1

    .line 76
    invoke-virtual {v3, v12, v15}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v37

    .line 77
    invoke-virtual {v3}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v12

    invoke-virtual {v11, v12}, Li1/a;->d(I)V

    const/4 v12, 0x2

    .line 78
    invoke-virtual {v3, v12, v15}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v38

    .line 79
    invoke-virtual {v3}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v12

    invoke-virtual {v11, v12}, Li1/a;->d(I)V

    .line 80
    iget-object v12, v11, Li1/a;->a:Lorg/xmlpull/v1/XmlPullParser;

    const-string v14, "scaleX"

    const/4 v15, 0x3

    .line 81
    invoke-static {v3, v12, v14, v15, v6}, Ld3/l;->c(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v39

    .line 82
    invoke-virtual {v3}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v12

    invoke-virtual {v11, v12}, Li1/a;->d(I)V

    .line 83
    iget-object v12, v11, Li1/a;->a:Lorg/xmlpull/v1/XmlPullParser;

    const-string v14, "scaleY"

    const/4 v15, 0x4

    .line 84
    invoke-static {v3, v12, v14, v15, v6}, Ld3/l;->c(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v40

    .line 85
    invoke-virtual {v3}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v6

    invoke-virtual {v11, v6}, Li1/a;->d(I)V

    .line 86
    iget-object v6, v11, Li1/a;->a:Lorg/xmlpull/v1/XmlPullParser;

    const-string v12, "translateX"

    const/4 v14, 0x6

    const/4 v15, 0x0

    .line 87
    invoke-static {v3, v6, v12, v14, v15}, Ld3/l;->c(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v41

    .line 88
    invoke-virtual {v3}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v6

    invoke-virtual {v11, v6}, Li1/a;->d(I)V

    .line 89
    iget-object v6, v11, Li1/a;->a:Lorg/xmlpull/v1/XmlPullParser;

    const-string v12, "translateY"

    const/4 v14, 0x7

    .line 90
    invoke-static {v3, v6, v12, v14, v15}, Ld3/l;->c(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v42

    .line 91
    invoke-virtual {v3}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v6

    invoke-virtual {v11, v6}, Li1/a;->d(I)V

    const/4 v6, 0x0

    .line 92
    invoke-virtual {v11, v3, v6}, Li1/a;->b(Landroid/content/res/TypedArray;I)Ljava/lang/String;

    move-result-object v12

    if-nez v12, :cond_27d

    move-object/from16 v35, v17

    goto :goto_27f

    :cond_27d
    move-object/from16 v35, v12

    .line 93
    :goto_27f
    invoke-virtual {v3}, Landroid/content/res/TypedArray;->recycle()V

    .line 94
    sget v3, Lh1/n;->a:I

    sget-object v43, Llg/s;->a:Llg/s;

    move-object/from16 v34, v8

    .line 95
    invoke-virtual/range {v34 .. v43}, Lh1/c$a;->a(Ljava/lang/String;FFFFFFFLjava/util/List;)Lh1/c$a;

    goto/16 :goto_42e

    :cond_28d
    const-string v3, "path"

    .line 96
    invoke-virtual {v12, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_297

    goto/16 :goto_42e

    .line 97
    :cond_297
    sget-object v3, Le0/q0;->c:[I

    .line 98
    invoke-virtual {v11, v2, v1, v10, v3}, Li1/a;->c(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v3

    .line 99
    iget-object v12, v11, Li1/a;->a:Lorg/xmlpull/v1/XmlPullParser;

    const-string v15, "pathData"

    .line 100
    invoke-static {v12, v15}, Ld3/l;->f(Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_3e3

    const/4 v12, 0x0

    .line 101
    invoke-virtual {v11, v3, v12}, Li1/a;->b(Landroid/content/res/TypedArray;I)Ljava/lang/String;

    move-result-object v14

    if-nez v14, :cond_2b1

    move-object/from16 v35, v17

    goto :goto_2b3

    :cond_2b1
    move-object/from16 v35, v14

    :goto_2b3
    const/4 v12, 0x2

    .line 102
    invoke-virtual {v11, v3, v12}, Li1/a;->b(Landroid/content/res/TypedArray;I)Ljava/lang/String;

    move-result-object v14

    .line 103
    invoke-static {v14}, Lh1/n;->a(Ljava/lang/String;)Ljava/util/List;

    move-result-object v12

    const/16 v18, 0x1

    const/16 v19, 0x0

    const-string v17, "fillColor"

    move-object v14, v11

    move-object/from16 v50, v15

    const/16 v24, 0x3

    move-object v15, v3

    move-object/from16 v16, v1

    .line 104
    invoke-virtual/range {v14 .. v19}, Li1/a;->a(Landroid/content/res/TypedArray;Landroid/content/res/Resources$Theme;Ljava/lang/String;II)Ld3/d;

    move-result-object v25

    .line 105
    iget-object v14, v11, Li1/a;->a:Lorg/xmlpull/v1/XmlPullParser;

    const-string v15, "fillAlpha"

    const/16 v13, 0xc

    .line 106
    invoke-static {v3, v14, v15, v13, v6}, Ld3/l;->c(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v39

    .line 107
    invoke-virtual {v3}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v14

    invoke-virtual {v11, v14}, Li1/a;->d(I)V

    .line 108
    iget-object v14, v11, Li1/a;->a:Lorg/xmlpull/v1/XmlPullParser;

    const-string v15, "strokeLineCap"

    const/4 v6, -0x1

    const/16 v13, 0x8

    .line 109
    invoke-static {v3, v14, v15, v13, v6}, Ld3/l;->d(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;II)I

    move-result v14

    .line 110
    invoke-virtual {v3}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v6

    invoke-virtual {v11, v6}, Li1/a;->d(I)V

    if-eqz v14, :cond_301

    const/4 v6, 0x1

    if-eq v14, v6, :cond_2fd

    const/4 v6, 0x2

    if-eq v14, v6, :cond_2fa

    goto :goto_302

    :cond_2fa
    const/16 v43, 0x2

    goto :goto_304

    :cond_2fd
    const/4 v6, 0x2

    const/16 v43, 0x1

    goto :goto_304

    :cond_301
    const/4 v6, 0x2

    :goto_302
    const/16 v43, 0x0

    .line 111
    :goto_304
    iget-object v14, v11, Li1/a;->a:Lorg/xmlpull/v1/XmlPullParser;

    const-string v15, "strokeLineJoin"

    const/16 v6, 0x9

    const/4 v13, -0x1

    .line 112
    invoke-static {v3, v14, v15, v6, v13}, Ld3/l;->d(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;II)I

    move-result v14

    .line 113
    invoke-virtual {v3}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v13

    invoke-virtual {v11, v13}, Li1/a;->d(I)V

    if-eqz v14, :cond_321

    const/4 v13, 0x1

    if-eq v14, v13, :cond_31e

    const/16 v44, 0x2

    goto :goto_323

    :cond_31e
    const/16 v44, 0x1

    goto :goto_323

    :cond_321
    const/16 v44, 0x0

    :goto_323
    const/16 v13, 0xa

    .line 114
    iget-object v14, v11, Li1/a;->a:Lorg/xmlpull/v1/XmlPullParser;

    const-string v15, "strokeMiterLimit"

    const/high16 v6, 0x3f800000    # 1.0f

    .line 115
    invoke-static {v3, v14, v15, v13, v6}, Ld3/l;->c(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v45

    .line 116
    invoke-virtual {v3}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v6

    invoke-virtual {v11, v6}, Li1/a;->d(I)V

    const/16 v18, 0x3

    const/16 v19, 0x0

    const-string v17, "strokeColor"

    move-object v14, v11

    move-object v15, v3

    move-object/from16 v16, v1

    .line 117
    invoke-virtual/range {v14 .. v19}, Li1/a;->a(Landroid/content/res/TypedArray;Landroid/content/res/Resources$Theme;Ljava/lang/String;II)Ld3/d;

    move-result-object v6

    const/16 v13, 0xb

    .line 118
    iget-object v14, v11, Li1/a;->a:Lorg/xmlpull/v1/XmlPullParser;

    const-string v15, "strokeAlpha"

    const/high16 v7, 0x3f800000    # 1.0f

    .line 119
    invoke-static {v3, v14, v15, v13, v7}, Ld3/l;->c(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v41

    .line 120
    invoke-virtual {v3}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v13

    invoke-virtual {v11, v13}, Li1/a;->d(I)V

    .line 121
    iget-object v13, v11, Li1/a;->a:Lorg/xmlpull/v1/XmlPullParser;

    const-string v14, "strokeWidth"

    const/4 v15, 0x4

    .line 122
    invoke-static {v3, v13, v14, v15, v7}, Ld3/l;->c(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v42

    .line 123
    invoke-virtual {v3}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v13

    invoke-virtual {v11, v13}, Li1/a;->d(I)V

    .line 124
    iget-object v13, v11, Li1/a;->a:Lorg/xmlpull/v1/XmlPullParser;

    const-string v14, "trimPathEnd"

    const/4 v15, 0x6

    .line 125
    invoke-static {v3, v13, v14, v15, v7}, Ld3/l;->c(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v47

    .line 126
    invoke-virtual {v3}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v7

    invoke-virtual {v11, v7}, Li1/a;->d(I)V

    .line 127
    iget-object v7, v11, Li1/a;->a:Lorg/xmlpull/v1/XmlPullParser;

    const-string v13, "trimPathOffset"

    const/4 v14, 0x0

    const/4 v15, 0x7

    .line 128
    invoke-static {v3, v7, v13, v15, v14}, Ld3/l;->c(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v48

    .line 129
    invoke-virtual {v3}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v7

    invoke-virtual {v11, v7}, Li1/a;->d(I)V

    .line 130
    iget-object v7, v11, Li1/a;->a:Lorg/xmlpull/v1/XmlPullParser;

    const-string v13, "trimPathStart"

    const/4 v15, 0x5

    .line 131
    invoke-static {v3, v7, v13, v15, v14}, Ld3/l;->c(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v46

    .line 132
    invoke-virtual {v3}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v7

    invoke-virtual {v11, v7}, Li1/a;->d(I)V

    .line 133
    iget-object v7, v11, Li1/a;->a:Lorg/xmlpull/v1/XmlPullParser;

    const-string v13, "fillType"

    const/16 v14, 0xd

    const/4 v15, 0x0

    .line 134
    invoke-static {v3, v7, v13, v14, v15}, Ld3/l;->d(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;II)I

    move-result v7

    .line 135
    invoke-virtual {v3}, Landroid/content/res/TypedArray;->getChangingConfigurations()I

    move-result v13

    invoke-virtual {v11, v13}, Li1/a;->d(I)V

    .line 136
    invoke-virtual {v3}, Landroid/content/res/TypedArray;->recycle()V

    .line 137
    invoke-static/range {v25 .. v25}, Li1/b;->b(Ld3/d;)Ld1/m;

    move-result-object v38

    .line 138
    invoke-static {v6}, Li1/b;->b(Ld3/d;)Ld1/m;

    move-result-object v40

    move-object/from16 v3, v50

    if-nez v7, :cond_3bc

    const/16 v37, 0x0

    goto :goto_3be

    :cond_3bc
    const/16 v37, 0x1

    .line 139
    :goto_3be
    invoke-static {v12, v3}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 140
    invoke-virtual {v8}, Lh1/c$a;->d()V

    .line 141
    iget-object v3, v8, Lh1/c$a;->i:Ljava/util/ArrayList;

    .line 142
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v6

    const/4 v7, -0x1

    add-int/2addr v6, v7

    .line 143
    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    .line 144
    check-cast v3, Lh1/c$a$a;

    .line 145
    iget-object v3, v3, Lh1/c$a$a;->j:Ljava/util/List;

    .line 146
    new-instance v6, Lh1/u;

    const/16 v49, 0x0

    move-object/from16 v34, v6

    move-object/from16 v36, v12

    invoke-direct/range {v34 .. v49}, Lh1/u;-><init>(Ljava/lang/String;Ljava/util/List;ILd1/m;FLd1/m;FFIIFFFFLwg/e;)V

    .line 147
    invoke-interface {v3, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_3f8

    .line 148
    :cond_3e3
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "No path data available"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_3eb
    const/4 v7, -0x1

    const/16 v14, 0xd

    const/16 v24, 0x3

    const-string v3, "clip-path"

    .line 149
    invoke-virtual {v12, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_3fa

    :goto_3f8
    const/4 v6, 0x0

    goto :goto_434

    .line 150
    :cond_3fa
    sget-object v3, Le0/q0;->d:[I

    .line 151
    invoke-virtual {v11, v2, v1, v10, v3}, Li1/a;->c(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v3

    const/4 v6, 0x0

    .line 152
    invoke-virtual {v11, v3, v6}, Li1/a;->b(Landroid/content/res/TypedArray;I)Ljava/lang/String;

    move-result-object v12

    if-nez v12, :cond_40a

    move-object/from16 v35, v17

    goto :goto_40c

    :cond_40a
    move-object/from16 v35, v12

    :goto_40c
    const/4 v12, 0x1

    .line 153
    invoke-virtual {v11, v3, v12}, Li1/a;->b(Landroid/content/res/TypedArray;I)Ljava/lang/String;

    move-result-object v13

    .line 154
    invoke-static {v13}, Lh1/n;->a(Ljava/lang/String;)Ljava/util/List;

    move-result-object v43

    .line 155
    invoke-virtual {v3}, Landroid/content/res/TypedArray;->recycle()V

    const/16 v36, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const/high16 v39, 0x3f800000    # 1.0f

    const/high16 v40, 0x3f800000    # 1.0f

    const/16 v41, 0x0

    const/16 v42, 0x0

    move-object/from16 v34, v8

    .line 156
    invoke-virtual/range {v34 .. v43}, Lh1/c$a;->a(Ljava/lang/String;FFFFFFFLjava/util/List;)Lh1/c$a;

    add-int/lit8 v9, v9, 0x1

    goto :goto_434

    :cond_42e
    :goto_42e
    const/4 v6, 0x0

    const/4 v7, -0x1

    :goto_430
    const/16 v14, 0xd

    const/16 v24, 0x3

    .line 157
    :goto_434
    invoke-interface {v0}, Landroid/content/res/XmlResourceParser;->next()I

    move-object/from16 v7, p1

    const/16 v3, 0x9

    const/4 v6, 0x1

    const/4 v12, -0x1

    const/4 v13, 0x5

    const/4 v15, 0x3

    goto/16 :goto_198

    .line 158
    :cond_441
    new-instance v10, Lw1/b$a;

    .line 159
    invoke-virtual {v8}, Lh1/c$a;->d()V

    .line 160
    :goto_446
    iget-object v0, v8, Lh1/c$a;->i:Ljava/util/ArrayList;

    .line 161
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x1

    if-le v0, v1, :cond_453

    .line 162
    invoke-virtual {v8}, Lh1/c$a;->c()Lh1/c$a;

    goto :goto_446

    .line 163
    :cond_453
    new-instance v0, Lh1/c;

    .line 164
    iget-object v1, v8, Lh1/c$a;->a:Ljava/lang/String;

    .line 165
    iget v2, v8, Lh1/c$a;->b:F

    .line 166
    iget v3, v8, Lh1/c$a;->c:F

    .line 167
    iget v6, v8, Lh1/c$a;->d:F

    .line 168
    iget v7, v8, Lh1/c$a;->e:F

    .line 169
    iget-object v9, v8, Lh1/c$a;->j:Lh1/c$a$a;

    invoke-virtual {v8, v9}, Lh1/c$a;->b(Lh1/c$a$a;)Lh1/m;

    move-result-object v33

    .line 170
    iget-wide v12, v8, Lh1/c$a;->f:J

    .line 171
    iget v9, v8, Lh1/c$a;->g:I

    .line 172
    iget-boolean v14, v8, Lh1/c$a;->h:Z

    const/16 v38, 0x0

    move-object/from16 v27, v0

    move-object/from16 v28, v1

    move/from16 v29, v2

    move/from16 v30, v3

    move/from16 v31, v6

    move/from16 v32, v7

    move-wide/from16 v34, v12

    move/from16 v36, v9

    move/from16 v37, v14

    .line 173
    invoke-direct/range {v27 .. v38}, Lh1/c;-><init>(Ljava/lang/String;FFFFLh1/m;JIZLwg/e;)V

    const/4 v1, 0x1

    .line 174
    iput-boolean v1, v8, Lh1/c$a;->k:Z

    .line 175
    iget v1, v11, Li1/a;->b:I

    .line 176
    invoke-direct {v10, v0, v1}, Lw1/b$a;-><init>(Lh1/c;I)V

    .line 177
    iget-object v0, v4, Lw1/b;->a:Ljava/util/HashMap;

    new-instance v1, Ljava/lang/ref/WeakReference;

    invoke-direct {v1, v10}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    invoke-interface {v0, v5, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_4d9

    .line 178
    :cond_495
    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    .line 179
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v14}, Landroid/content/res/TypedArray;->getPositionDescription()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "<VectorGraphic> tag requires viewportHeight > 0"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 180
    invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 181
    :cond_4b0
    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    .line 182
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v14}, Landroid/content/res/TypedArray;->getPositionDescription()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "<VectorGraphic> tag requires viewportWidth > 0"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 183
    invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 184
    :cond_4cb
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0, v11}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 185
    :cond_4d1
    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    const-string v1, "No start tag found"

    invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 186
    :cond_4d9
    :goto_4d9
    iget-object v0, v10, Lw1/b$a;->a:Lh1/c;

    .line 187
    invoke-interface/range {p1 .. p1}, Lm0/g;->L()V

    const-string v1, "image"

    .line 188
    invoke-static {v0, v1}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const v1, 0x544566b0

    move-object/from16 v7, p1

    invoke-interface {v7, v1}, Lm0/g;->e(I)V

    .line 189
    iget v1, v0, Lh1/c;->b:F

    .line 190
    iget v2, v0, Lh1/c;->c:F

    .line 191
    iget v3, v0, Lh1/c;->d:F

    .line 192
    iget v4, v0, Lh1/c;->e:F

    .line 193
    iget-object v5, v0, Lh1/c;->a:Ljava/lang/String;

    .line 194
    iget-wide v8, v0, Lh1/c;->g:J

    .line 195
    iget v6, v0, Lh1/c;->h:I

    .line 196
    iget-boolean v10, v0, Lh1/c;->i:Z

    const v11, 0x6fa7e78e

    .line 197
    new-instance v12, Lh1/t;

    invoke-direct {v12, v0}, Lh1/t;-><init>(Lh1/c;)V

    const/4 v0, 0x1

    invoke-static {v7, v11, v0, v12}, Lgh/m1;->n(Lm0/g;IZLjava/lang/Object;)Lt0/a;

    move-result-object v11

    const v0, 0x3fb166c2

    .line 198
    invoke-interface {v7, v0}, Lm0/g;->e(I)V

    .line 199
    sget-object v0, Landroidx/compose/ui/platform/o0;->e:Lm0/e1;

    .line 200
    invoke-interface {v7, v0}, Lm0/g;->C(Lm0/w;)Ljava/lang/Object;

    move-result-object v0

    .line 201
    check-cast v0, Lp2/b;

    .line 202
    invoke-interface {v0, v1}, Lp2/b;->Z(F)F

    move-result v1

    .line 203
    invoke-interface {v0, v2}, Lp2/b;->Z(F)F

    move-result v0

    .line 204
    invoke-static {v3}, Ljava/lang/Float;->isNaN(F)Z

    move-result v2

    if-eqz v2, :cond_526

    move v2, v1

    goto :goto_527

    :cond_526
    move v2, v3

    .line 205
    :goto_527
    invoke-static {v4}, Ljava/lang/Float;->isNaN(F)Z

    move-result v3

    if-eqz v3, :cond_52f

    move v3, v0

    goto :goto_530

    :cond_52f
    move v3, v4

    .line 206
    :goto_530
    new-instance v4, Ld1/s;

    invoke-direct {v4, v8, v9}, Ld1/s;-><init>(J)V

    .line 207
    new-instance v12, Ld1/j;

    invoke-direct {v12, v6}, Ld1/j;-><init>(I)V

    const v13, 0x1e7b2b64

    .line 208
    invoke-interface {v7, v13}, Lm0/g;->e(I)V

    .line 209
    invoke-interface {v7, v4}, Lm0/g;->O(Ljava/lang/Object;)Z

    move-result v4

    invoke-interface {v7, v12}, Lm0/g;->O(Ljava/lang/Object;)Z

    move-result v12

    or-int/2addr v4, v12

    .line 210
    invoke-interface/range {p1 .. p1}, Lm0/g;->f()Ljava/lang/Object;

    move-result-object v12

    if-nez v4, :cond_553

    .line 211
    sget-object v4, Lm0/g$a;->b:Ljava/lang/Object;

    if-ne v12, v4, :cond_582

    .line 212
    :cond_553
    sget-object v4, Ld1/s;->b:Ld1/s$a;

    .line 213
    sget-wide v12, Ld1/s;->h:J

    .line 214
    invoke-static {v8, v9, v12, v13}, Ld1/s;->b(JJ)Z

    move-result v4

    if-nez v4, :cond_57d

    .line 215
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v12, 0x1d

    if-lt v4, v12, :cond_56a

    .line 216
    sget-object v4, Ld1/k;->a:Ld1/k;

    invoke-virtual {v4, v8, v9, v6}, Ld1/k;->a(JI)Landroid/graphics/BlendModeColorFilter;

    move-result-object v4

    goto :goto_577

    .line 217
    :cond_56a
    new-instance v4, Landroid/graphics/PorterDuffColorFilter;

    invoke-static {v8, v9}, Landroidx/appcompat/widget/m;->U(J)I

    move-result v8

    invoke-static {v6}, Landroidx/activity/n;->J(I)Landroid/graphics/PorterDuff$Mode;

    move-result-object v6

    invoke-direct {v4, v8, v6}, Landroid/graphics/PorterDuffColorFilter;-><init>(ILandroid/graphics/PorterDuff$Mode;)V

    .line 218
    :goto_577
    new-instance v13, Ld1/t;

    invoke-direct {v13, v4}, Ld1/t;-><init>(Landroid/graphics/ColorFilter;)V

    goto :goto_57e

    :cond_57d
    const/4 v13, 0x0

    .line 219
    :goto_57e
    invoke-interface {v7, v13}, Lm0/g;->H(Ljava/lang/Object;)V

    move-object v12, v13

    .line 220
    :cond_582
    invoke-interface/range {p1 .. p1}, Lm0/g;->L()V

    .line 221
    check-cast v12, Ld1/t;

    const v4, -0x1d58f75c

    .line 222
    invoke-interface {v7, v4}, Lm0/g;->e(I)V

    .line 223
    invoke-interface/range {p1 .. p1}, Lm0/g;->f()Ljava/lang/Object;

    move-result-object v4

    .line 224
    sget-object v6, Lm0/g$a;->b:Ljava/lang/Object;

    if-ne v4, v6, :cond_59d

    .line 225
    new-instance v4, Lh1/q;

    invoke-direct {v4}, Lh1/q;-><init>()V

    .line 226
    invoke-interface {v7, v4}, Lm0/g;->H(Ljava/lang/Object;)V

    .line 227
    :cond_59d
    invoke-interface/range {p1 .. p1}, Lm0/g;->L()V

    .line 228
    move-object v8, v4

    check-cast v8, Lh1/q;

    .line 229
    invoke-static {v1, v0}, Landroidx/appcompat/widget/m;->j(FF)J

    move-result-wide v0

    .line 230
    iget-object v4, v8, Lh1/q;->f:Lm0/x0;

    .line 231
    new-instance v6, Lc1/f;

    invoke-direct {v6, v0, v1}, Lc1/f;-><init>(J)V

    .line 232
    invoke-interface {v4, v6}, Lm0/x0;->setValue(Ljava/lang/Object;)V

    .line 233
    iget-object v0, v8, Lh1/q;->g:Lm0/x0;

    invoke-static {v10}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    .line 234
    invoke-interface {v0, v1}, Lm0/x0;->setValue(Ljava/lang/Object;)V

    .line 235
    iget-object v0, v8, Lh1/q;->h:Lh1/j;

    .line 236
    iget-object v0, v0, Lh1/j;->f:Lm0/x0;

    .line 237
    invoke-interface {v0, v12}, Lm0/x0;->setValue(Ljava/lang/Object;)V

    const v6, 0x8c00

    move-object v0, v8

    move-object v1, v5

    move-object v4, v11

    move-object/from16 v5, p1

    .line 238
    invoke-virtual/range {v0 .. v6}, Lh1/q;->f(Ljava/lang/String;FFLvg/r;Lm0/g;I)V

    .line 239
    invoke-interface/range {p1 .. p1}, Lm0/g;->L()V

    .line 240
    invoke-interface/range {p1 .. p1}, Lm0/g;->L()V

    .line 241
    invoke-interface/range {p1 .. p1}, Lm0/g;->L()V

    goto :goto_628

    :cond_5d6
    const v1, -0x2c01086c

    .line 242
    invoke-interface {v7, v1}, Lm0/g;->e(I)V

    invoke-static/range {p0 .. p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const v3, 0x1e7b2b64

    .line 243
    invoke-interface {v7, v3}, Lm0/g;->e(I)V

    .line 244
    invoke-interface {v7, v4}, Lm0/g;->O(Ljava/lang/Object;)Z

    move-result v3

    invoke-interface {v7, v1}, Lm0/g;->O(Ljava/lang/Object;)Z

    move-result v1

    or-int/2addr v1, v3

    .line 245
    invoke-interface/range {p1 .. p1}, Lm0/g;->f()Ljava/lang/Object;

    move-result-object v3

    if-nez v1, :cond_5f7

    if-ne v3, v5, :cond_614

    :cond_5f7
    const/4 v1, 0x0

    .line 246
    :try_start_5f8
    invoke-virtual {v2, v0, v1}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type android.graphics.drawable.BitmapDrawable"

    invoke-static {v0, v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    check-cast v0, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    move-result-object v0

    const-string v1, "res.getDrawable(id, null\u2026as BitmapDrawable).bitmap"

    invoke-static {v0, v1}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    .line 247
    new-instance v3, Ld1/c;

    invoke-direct {v3, v0}, Ld1/c;-><init>(Landroid/graphics/Bitmap;)V
    :try_end_611
    .catchall {:try_start_5f8 .. :try_end_611} :catchall_62c

    .line 248
    invoke-interface {v7, v3}, Lm0/g;->H(Ljava/lang/Object;)V

    .line 249
    :cond_614
    invoke-interface/range {p1 .. p1}, Lm0/g;->L()V

    .line 250
    move-object v9, v3

    check-cast v9, Ld1/y;

    .line 251
    new-instance v0, Lg1/a;

    const-wide/16 v10, 0x0

    const-wide/16 v12, 0x0

    const/4 v14, 0x6

    move-object v8, v0

    invoke-direct/range {v8 .. v14}, Lg1/a;-><init>(Ld1/y;JJI)V

    .line 252
    invoke-interface/range {p1 .. p1}, Lm0/g;->L()V

    .line 253
    :goto_628
    invoke-interface/range {p1 .. p1}, Lm0/g;->L()V

    return-object v8

    .line 254
    :catchall_62c
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0, v11}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_data_632
    .packed-switch 0xe
        :pswitch_16e
        :pswitch_169
        :pswitch_166
    .end packed-switch
.end method

.method public static final J(Lb1/l;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lb1/l;->m:Lt1/q;

    if-eqz v0, :cond_b

    .line 2
    iget-object v0, v0, Lt1/q;->e:Lt1/h;

    if-eqz v0, :cond_b

    .line 3
    iget-object v0, v0, Lt1/h;->g:Lt1/b0;

    goto :goto_c

    :cond_b
    const/4 v0, 0x0

    :goto_c
    const/4 v1, 0x1

    if-nez v0, :cond_12

    .line 4
    iput-boolean v1, p0, Lb1/l;->n:Z

    return-void

    .line 5
    :cond_12
    iget-object v0, p0, Lb1/l;->d:Lb1/b0;

    .line 6
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    if-eqz v0, :cond_45

    if-eq v0, v1, :cond_3b

    const/4 v1, 0x2

    if-eq v0, v1, :cond_45

    const/4 v1, 0x3

    if-eq v0, v1, :cond_45

    const/4 v1, 0x4

    if-eq v0, v1, :cond_45

    const/4 v1, 0x5

    if-eq v0, v1, :cond_29

    goto :goto_48

    .line 7
    :cond_29
    iget-object v0, p0, Lb1/l;->b:Lb1/l;

    if-eqz v0, :cond_31

    .line 8
    invoke-static {v0, p0}, La0/u;->K(Lb1/l;Lb1/l;)Z

    goto :goto_48

    .line 9
    :cond_31
    invoke-static {p0}, La0/u;->L(Lb1/l;)Z

    move-result v0

    if-eqz v0, :cond_48

    .line 10
    invoke-static {p0}, La0/u;->A(Lb1/l;)V

    goto :goto_48

    .line 11
    :cond_3b
    invoke-static {p0}, La0/u;->o(Lb1/l;)Z

    move-result v0

    if-eqz v0, :cond_48

    invoke-static {p0}, La0/u;->A(Lb1/l;)V

    goto :goto_48

    .line 12
    :cond_45
    invoke-static {p0}, La0/u;->M(Lb1/l;)V

    :cond_48
    :goto_48
    return-void
.end method

.method public static final K(Lb1/l;Lb1/l;)Z
    .registers 6

    .line 1
    iget-object v0, p0, Lb1/l;->c:Ln0/e;

    .line 2
    invoke-virtual {v0, p1}, Ln0/e;->g(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_84

    .line 3
    iget-object v0, p0, Lb1/l;->d:Lb1/b0;

    .line 4
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_76

    if-eq v0, v2, :cond_6a

    const/4 v3, 0x2

    if-eq v0, v3, :cond_83

    const/4 v3, 0x3

    if-eq v0, v3, :cond_5f

    const/4 v3, 0x4

    if-eq v0, v3, :cond_49

    const/4 v2, 0x5

    if-ne v0, v2, :cond_43

    .line 5
    iget-object v0, p0, Lb1/l;->b:Lb1/l;

    if-nez v0, :cond_36

    .line 6
    invoke-static {p0}, La0/u;->L(Lb1/l;)Z

    move-result v2

    if-eqz v2, :cond_36

    .line 7
    sget-object v0, Lb1/b0;->a:Lb1/b0;

    .line 8
    iput-object v0, p0, Lb1/l;->d:Lb1/b0;

    .line 9
    invoke-static {p0}, La0/u;->M(Lb1/l;)V

    .line 10
    invoke-static {p0, p1}, La0/u;->K(Lb1/l;Lb1/l;)Z

    move-result v1

    goto :goto_83

    :cond_36
    if-eqz v0, :cond_83

    .line 11
    invoke-static {v0, p0}, La0/u;->K(Lb1/l;Lb1/l;)Z

    move-result v0

    if-eqz v0, :cond_83

    .line 12
    invoke-static {p0, p1}, La0/u;->K(Lb1/l;Lb1/l;)Z

    move-result v1

    goto :goto_83

    .line 13
    :cond_43
    new-instance p0, Lq6/a;

    invoke-direct {p0}, Lq6/a;-><init>()V

    throw p0

    .line 14
    :cond_49
    iget-object v0, p0, Lb1/l;->e:Lb1/l;

    if-nez v0, :cond_53

    .line 15
    iput-object p1, p0, Lb1/l;->e:Lb1/l;

    .line 16
    invoke-static {p1}, La0/u;->A(Lb1/l;)V

    goto :goto_82

    .line 17
    :cond_53
    invoke-static {p0}, La0/u;->o(Lb1/l;)Z

    move-result v0

    if-eqz v0, :cond_83

    .line 18
    iput-object p1, p0, Lb1/l;->e:Lb1/l;

    .line 19
    invoke-static {p1}, La0/u;->A(Lb1/l;)V

    goto :goto_82

    .line 20
    :cond_5f
    invoke-static {p0}, La0/u;->h(Lb1/l;)V

    .line 21
    invoke-static {p0, p1}, La0/u;->K(Lb1/l;Lb1/l;)Z

    move-result v1

    .line 22
    invoke-static {p0}, La0/u;->r(Lb1/l;)V

    goto :goto_83

    .line 23
    :cond_6a
    invoke-static {p0}, La0/u;->o(Lb1/l;)Z

    move-result v0

    if-eqz v0, :cond_83

    .line 24
    iput-object p1, p0, Lb1/l;->e:Lb1/l;

    .line 25
    invoke-static {p1}, La0/u;->A(Lb1/l;)V

    goto :goto_82

    .line 26
    :cond_76
    sget-object v0, Lb1/b0;->b:Lb1/b0;

    .line 27
    iput-object v0, p0, Lb1/l;->d:Lb1/b0;

    .line 28
    invoke-static {p0}, La0/u;->M(Lb1/l;)V

    .line 29
    iput-object p1, p0, Lb1/l;->e:Lb1/l;

    .line 30
    invoke-static {p1}, La0/u;->A(Lb1/l;)V

    :goto_82
    const/4 v1, 0x1

    :cond_83
    :goto_83
    return v1

    .line 31
    :cond_84
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Non child node cannot request focus."

    .line 32
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static final L(Lb1/l;)Z
    .registers 2

    .line 1
    iget-object p0, p0, Lb1/l;->m:Lt1/q;

    if-eqz p0, :cond_11

    .line 2
    iget-object p0, p0, Lt1/q;->e:Lt1/h;

    if-eqz p0, :cond_11

    .line 3
    iget-object p0, p0, Lt1/h;->g:Lt1/b0;

    if-eqz p0, :cond_11

    .line 4
    invoke-interface {p0}, Lt1/b0;->requestFocus()Z

    move-result p0

    return p0

    :cond_11
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "Owner not initialized."

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static final M(Lb1/l;)V
    .registers 2

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object p0, p0, Lb1/l;->f:Lb1/h;

    if-eqz p0, :cond_c

    .line 2
    invoke-virtual {p0}, Lb1/h;->c()V

    :cond_c
    return-void
.end method

.method public static N(Landroid/net/Uri;)Ljava/util/Map;
    .registers 6

    .line 1
    invoke-virtual {p0}, Landroid/net/Uri;->getEncodedQuery()Ljava/lang/String;

    move-result-object p0

    if-nez p0, :cond_b

    .line 2
    invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;

    move-result-object p0

    return-object p0

    .line 3
    :cond_b
    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    const/4 v1, 0x0

    :cond_11
    const/16 v2, 0x26

    .line 4
    invoke-virtual {p0, v2, v1}, Ljava/lang/String;->indexOf(II)I

    move-result v2

    const/4 v3, -0x1

    if-ne v2, v3, :cond_1e

    .line 5
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    :cond_1e
    const/16 v4, 0x3d

    .line 6
    invoke-virtual {p0, v4, v1}, Ljava/lang/String;->indexOf(II)I

    move-result v4

    if-gt v4, v2, :cond_28

    if-ne v4, v3, :cond_29

    :cond_28
    move v4, v2

    .line 7
    :cond_29
    invoke-virtual {p0, v1, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    .line 8
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_49

    if-ne v4, v2, :cond_38

    const-string v3, ""

    goto :goto_3e

    :cond_38
    add-int/lit8 v4, v4, 0x1

    .line 9
    invoke-virtual {p0, v4, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    .line 10
    :goto_3e
    invoke-static {v1}, Landroid/net/Uri;->decode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v3}, Landroid/net/Uri;->decode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0, v1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_49
    add-int/lit8 v1, v2, 0x1

    .line 11
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    if-lt v1, v2, :cond_11

    .line 12
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object p0

    return-object p0
.end method

.method public static O(Ljava/lang/String;[CIIII)V
    .registers 8

    and-int/lit8 v0, p5, 0x2

    const/4 v1, 0x0

    if-eqz v0, :cond_6

    const/4 p2, 0x0

    :cond_6
    and-int/lit8 v0, p5, 0x4

    if-eqz v0, :cond_b

    const/4 p3, 0x0

    :cond_b
    and-int/lit8 p5, p5, 0x8

    if-eqz p5, :cond_13

    .line 1
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p4

    :cond_13
    move p5, p3

    :goto_14
    if-ge p5, p4, :cond_22

    add-int v0, p2, p5

    sub-int/2addr v0, p3

    .line 2
    invoke-virtual {p0, p5}, Ljava/lang/String;->charAt(I)C

    move-result v1

    aput-char v1, p1, v0

    add-int/lit8 p5, p5, 0x1

    goto :goto_14

    :cond_22
    return-void
.end method

.method public static P(DD)[D
    .registers 12

    const-wide v0, 0x3f7a9fbe76c8b439L    # 0.0065

    sub-double/2addr p0, v0

    const-wide v0, 0x3f789374bc6a7efaL    # 0.006

    sub-double/2addr p2, v0

    mul-double v0, p0, p0

    mul-double v2, p2, p2

    add-double/2addr v2, v0

    .line 1
    invoke-static {v2, v3}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v0

    const-wide v2, 0x404a2e1077c7044eL    # 52.35987755982988

    mul-double v4, p2, v2

    invoke-static {v4, v5}, Ljava/lang/Math;->sin(D)D

    move-result-wide v4

    const-wide v6, 0x3ef4f8b588e368f1L    # 2.0E-5

    mul-double v4, v4, v6

    sub-double/2addr v0, v4

    .line 2
    invoke-static {p2, p3, p0, p1}, Ljava/lang/Math;->atan2(DD)D

    move-result-wide p2

    mul-double p0, p0, v2

    invoke-static {p0, p1}, Ljava/lang/Math;->cos(D)D

    move-result-wide p0

    const-wide v2, 0x3ec92a737110e454L    # 3.0E-6

    mul-double p0, p0, v2

    sub-double/2addr p2, p0

    .line 3
    invoke-static {p2, p3}, Ljava/lang/Math;->cos(D)D

    move-result-wide p0

    mul-double p0, p0, v0

    .line 4
    invoke-static {p2, p3}, Ljava/lang/Math;->sin(D)D

    move-result-wide p2

    mul-double p2, p2, v0

    const/4 v0, 0x2

    new-array v0, v0, [D

    const/4 v1, 0x0

    aput-wide p0, v0, v1

    const/4 p0, 0x1

    aput-wide p2, v0, p0

    return-object v0
.end method

.method public static Q(DD)D
    .registers 20

    const-wide/high16 v0, 0x4000000000000000L    # 2.0

    mul-double v2, p0, v0

    const-wide/high16 v4, -0x3fa7000000000000L    # -100.0

    add-double/2addr v4, v2

    const-wide/high16 v6, 0x4008000000000000L    # 3.0

    mul-double v8, p2, v6

    add-double/2addr v8, v4

    const-wide v4, 0x3fc999999999999aL    # 0.2

    mul-double v10, p2, v4

    mul-double v10, v10, p2

    add-double/2addr v10, v8

    const-wide v8, 0x3fb999999999999aL    # 0.1

    mul-double v8, v8, p0

    mul-double v8, v8, p2

    add-double/2addr v8, v10

    .line 1
    invoke-static/range {p0 .. p1}, Ljava/lang/Math;->abs(D)D

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v10

    mul-double v10, v10, v4

    add-double/2addr v10, v8

    const-wide/high16 v4, 0x4018000000000000L    # 6.0

    mul-double v4, v4, p0

    const-wide v8, 0x400921fb54442d18L    # Math.PI

    mul-double v4, v4, v8

    .line 2
    invoke-static {v4, v5}, Ljava/lang/Math;->sin(D)D

    move-result-wide v4

    const-wide/high16 v12, 0x4034000000000000L    # 20.0

    mul-double v4, v4, v12

    mul-double v2, v2, v8

    invoke-static {v2, v3}, Ljava/lang/Math;->sin(D)D

    move-result-wide v2

    mul-double v2, v2, v12

    add-double/2addr v2, v4

    mul-double v2, v2, v0

    div-double/2addr v2, v6

    add-double/2addr v2, v10

    mul-double v4, p2, v8

    .line 3
    invoke-static {v4, v5}, Ljava/lang/Math;->sin(D)D

    move-result-wide v10

    mul-double v10, v10, v12

    div-double v12, p2, v6

    mul-double v12, v12, v8

    invoke-static {v12, v13}, Ljava/lang/Math;->sin(D)D

    move-result-wide v12

    const-wide/high16 v14, 0x4044000000000000L    # 40.0

    mul-double v12, v12, v14

    add-double/2addr v12, v10

    mul-double v12, v12, v0

    div-double/2addr v12, v6

    add-double/2addr v12, v2

    const-wide/high16 v2, 0x4028000000000000L    # 12.0

    div-double v2, p2, v2

    mul-double v2, v2, v8

    .line 4
    invoke-static {v2, v3}, Ljava/lang/Math;->sin(D)D

    move-result-wide v2

    const-wide/high16 v8, 0x4064000000000000L    # 160.0

    mul-double v2, v2, v8

    const-wide/high16 v8, 0x403e000000000000L    # 30.0

    div-double/2addr v4, v8

    invoke-static {v4, v5}, Ljava/lang/Math;->sin(D)D

    move-result-wide v4

    const-wide/high16 v8, 0x4074000000000000L    # 320.0

    mul-double v4, v4, v8

    add-double/2addr v4, v2

    mul-double v4, v4, v0

    div-double/2addr v4, v6

    add-double/2addr v4, v12

    return-wide v4
.end method

.method public static R(DD)D
    .registers 20

    const-wide v0, 0x4072c00000000000L    # 300.0

    add-double v2, p0, v0

    const-wide/high16 v4, 0x4000000000000000L    # 2.0

    mul-double v6, p2, v4

    add-double/2addr v6, v2

    const-wide v2, 0x3fb999999999999aL    # 0.1

    mul-double v8, p0, v2

    mul-double v10, v8, p0

    add-double/2addr v10, v6

    mul-double v8, v8, p2

    add-double/2addr v8, v10

    .line 1
    invoke-static/range {p0 .. p1}, Ljava/lang/Math;->abs(D)D

    move-result-wide v6

    invoke-static {v6, v7}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v6

    mul-double v6, v6, v2

    add-double/2addr v6, v8

    const-wide/high16 v2, 0x4018000000000000L    # 6.0

    mul-double v2, v2, p0

    const-wide v8, 0x400921fb54442d18L    # Math.PI

    mul-double v2, v2, v8

    .line 2
    invoke-static {v2, v3}, Ljava/lang/Math;->sin(D)D

    move-result-wide v2

    const-wide/high16 v10, 0x4034000000000000L    # 20.0

    mul-double v2, v2, v10

    mul-double v12, p0, v4

    mul-double v12, v12, v8

    invoke-static {v12, v13}, Ljava/lang/Math;->sin(D)D

    move-result-wide v12

    mul-double v12, v12, v10

    add-double/2addr v12, v2

    mul-double v12, v12, v4

    const-wide/high16 v2, 0x4008000000000000L    # 3.0

    div-double/2addr v12, v2

    add-double/2addr v12, v6

    mul-double v6, p0, v8

    .line 3
    invoke-static {v6, v7}, Ljava/lang/Math;->sin(D)D

    move-result-wide v6

    mul-double v6, v6, v10

    div-double v10, p0, v2

    mul-double v10, v10, v8

    invoke-static {v10, v11}, Ljava/lang/Math;->sin(D)D

    move-result-wide v10

    const-wide/high16 v14, 0x4044000000000000L    # 40.0

    mul-double v10, v10, v14

    add-double/2addr v10, v6

    mul-double v10, v10, v4

    div-double/2addr v10, v2

    add-double/2addr v10, v12

    const-wide/high16 v6, 0x4028000000000000L    # 12.0

    div-double v6, p0, v6

    mul-double v6, v6, v8

    .line 4
    invoke-static {v6, v7}, Ljava/lang/Math;->sin(D)D

    move-result-wide v6

    const-wide v12, 0x4062c00000000000L    # 150.0

    mul-double v6, v6, v12

    const-wide/high16 v12, 0x403e000000000000L    # 30.0

    div-double v12, p0, v12

    mul-double v12, v12, v8

    invoke-static {v12, v13}, Ljava/lang/Math;->sin(D)D

    move-result-wide v8

    mul-double v8, v8, v0

    add-double/2addr v8, v6

    mul-double v8, v8, v4

    div-double/2addr v8, v2

    add-double/2addr v8, v10

    return-wide v8
.end method

.method public static final c()Ld1/c0;
    .registers 2

    .line 1
    new-instance v0, Ld1/f;

    .line 2
    new-instance v1, Landroid/graphics/Path;

    invoke-direct {v1}, Landroid/graphics/Path;-><init>()V

    .line 3
    invoke-direct {v0, v1}, Ld1/f;-><init>(Landroid/graphics/Path;)V

    return-object v0
.end method

.method public static d(Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    const-string v0, "SecurityComp10200300: "

    .line 1
    invoke-static {v0, p0}, Lhd/a;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static final e([Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;)[Ljava/lang/Object;
    .registers 11

    .line 1
    array-length v0, p0

    add-int/lit8 v0, v0, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x6

    move-object v1, p0

    move-object v2, v0

    move v5, p1

    .line 2
    invoke-static/range {v1 .. v6}, Llg/j;->g0([Ljava/lang/Object;[Ljava/lang/Object;IIII)[Ljava/lang/Object;

    add-int/lit8 v1, p1, 0x2

    .line 3
    array-length v2, p0

    invoke-static {p0, v0, v1, p1, v2}, Llg/j;->d0([Ljava/lang/Object;[Ljava/lang/Object;III)[Ljava/lang/Object;

    .line 4
    aput-object p2, v0, p1

    add-int/lit8 p1, p1, 0x1

    .line 5
    aput-object p3, v0, p1

    return-object v0
.end method

.method public static final f([Ljava/lang/Object;I)[Ljava/lang/Object;
    .registers 9

    .line 1
    array-length v0, p0

    add-int/lit8 v0, v0, -0x2

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x6

    move-object v1, p0

    move-object v2, v0

    move v5, p1

    .line 2
    invoke-static/range {v1 .. v6}, Llg/j;->g0([Ljava/lang/Object;[Ljava/lang/Object;IIII)[Ljava/lang/Object;

    add-int/lit8 v1, p1, 0x2

    .line 3
    array-length v2, p0

    invoke-static {p0, v0, p1, v1, v2}, Llg/j;->d0([Ljava/lang/Object;[Ljava/lang/Object;III)[Ljava/lang/Object;

    return-object v0
.end method

.method public static final g([Ljava/lang/Object;I)[Ljava/lang/Object;
    .registers 9

    .line 1
    array-length v0, p0

    add-int/lit8 v0, v0, -0x1

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x6

    move-object v1, p0

    move-object v2, v0

    move v5, p1

    .line 2
    invoke-static/range {v1 .. v6}, Llg/j;->g0([Ljava/lang/Object;[Ljava/lang/Object;IIII)[Ljava/lang/Object;

    add-int/lit8 v1, p1, 0x1

    .line 3
    array-length v2, p0

    invoke-static {p0, v0, p1, v1, v2}, Llg/j;->d0([Ljava/lang/Object;[Ljava/lang/Object;III)[Ljava/lang/Object;

    return-object v0
.end method

.method public static final h(Lb1/l;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lb1/l;->d:Lb1/b0;

    .line 2
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    const/4 v1, 0x3

    if-eq v0, v1, :cond_15

    const/4 v1, 0x4

    if-eq v0, v1, :cond_d

    goto :goto_1c

    .line 3
    :cond_d
    sget-object v0, Lb1/b0;->b:Lb1/b0;

    .line 4
    iput-object v0, p0, Lb1/l;->d:Lb1/b0;

    .line 5
    invoke-static {p0}, La0/u;->M(Lb1/l;)V

    goto :goto_1c

    .line 6
    :cond_15
    sget-object v0, Lb1/b0;->f:Lb1/b0;

    .line 7
    iput-object v0, p0, Lb1/l;->d:Lb1/b0;

    .line 8
    invoke-static {p0}, La0/u;->M(Lb1/l;)V

    :goto_1c
    return-void
.end method

.method public static i(Ljava/lang/String;Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-static {p0}, La0/u;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public static final j(Ly0/h;JLd1/k0;)Ly0/h;
    .registers 12

    const-string v0, "$this$background"

    invoke-static {p0, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "shape"

    invoke-static {p3, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    new-instance v0, Lb0/f;

    .line 2
    new-instance v2, Ld1/s;

    invoke-direct {v2, p1, p2}, Ld1/s;-><init>(J)V

    const/4 v3, 0x0

    const/4 v4, 0x0

    .line 3
    sget-object p1, Landroidx/compose/ui/platform/b1;->a:Lvg/l;

    .line 4
    sget-object v6, Landroidx/compose/ui/platform/b1;->a:Lvg/l;

    const/4 v7, 0x6

    move-object v1, v0

    move-object v5, p3

    .line 5
    invoke-direct/range {v1 .. v7}, Lb0/f;-><init>(Ld1/s;Ld1/m;FLd1/k0;Lvg/l;I)V

    .line 6
    invoke-interface {p0, v0}, Ly0/h;->p0(Ly0/h;)Ly0/h;

    move-result-object p0

    return-object p0
.end method

.method public static k([III)I
    .registers 6

    add-int/lit8 p1, p1, -0x1

    const/4 v0, 0x0

    :goto_3
    if-gt v0, p1, :cond_18

    add-int v1, v0, p1

    ushr-int/lit8 v1, v1, 0x1

    .line 1
    aget v2, p0, v1

    if-ge v2, p2, :cond_11

    add-int/lit8 v1, v1, 0x1

    move v0, v1

    goto :goto_3

    :cond_11
    if-le v2, p2, :cond_17

    add-int/lit8 v1, v1, -0x1

    move p1, v1

    goto :goto_3

    :cond_17
    return v1

    :cond_18
    not-int p0, v0

    return p0
.end method

.method public static l([JIJ)I
    .registers 9

    add-int/lit8 p1, p1, -0x1

    const/4 v0, 0x0

    :goto_3
    if-gt v0, p1, :cond_1a

    add-int v1, v0, p1

    ushr-int/lit8 v1, v1, 0x1

    .line 1
    aget-wide v2, p0, v1

    cmp-long v4, v2, p2

    if-gez v4, :cond_13

    add-int/lit8 v1, v1, 0x1

    move v0, v1

    goto :goto_3

    :cond_13
    if-lez v4, :cond_19

    add-int/lit8 v1, v1, -0x1

    move p1, v1

    goto :goto_3

    :cond_19
    return v1

    :cond_1a
    not-int p0, v0

    return p0
.end method

.method public static m(Ljava/lang/String;Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-static {p0}, La0/u;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public static n(Ljava/lang/String;)V
    .registers 4

    .line 1
    sget-object v0, Linfo/cd120/utils/a$c;->a:Linfo/cd120/utils/a;

    invoke-virtual {v0}, Linfo/cd120/utils/a;->a()Landroid/app/Activity;

    move-result-object v0

    if-eqz v0, :cond_9

    goto :goto_b

    .line 2
    :cond_9
    sget-object v0, La0/u;->a:Landroid/content/Context;

    :goto_b
    const/16 v1, 0x11

    const/4 v2, 0x0

    .line 3
    invoke-static {v0, p0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    .line 4
    invoke-virtual {p0, v1, v2, v2}, Landroid/widget/Toast;->setGravity(III)V

    .line 5
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method public static final o(Lb1/l;)Z
    .registers 3

    .line 1
    iget-object v0, p0, Lb1/l;->e:Lb1/l;

    if-eqz v0, :cond_10

    const/4 v1, 0x0

    .line 2
    invoke-static {v0, v1}, La0/u;->p(Lb1/l;Z)Z

    move-result v0

    if-eqz v0, :cond_f

    const/4 v0, 0x0

    .line 3
    iput-object v0, p0, Lb1/l;->e:Lb1/l;

    const/4 v1, 0x1

    :cond_f
    return v1

    .line 4
    :cond_10
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "Required value was null."

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static final p(Lb1/l;Z)Z
    .registers 7

    sget-object v0, Lb1/b0;->f:Lb1/b0;

    const-string v1, "<this>"

    invoke-static {p0, v1}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object v1, p0, Lb1/l;->d:Lb1/b0;

    .line 2
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_44

    if-eq v1, v3, :cond_3a

    const/4 v4, 0x2

    if-eq v1, v4, :cond_34

    const/4 p1, 0x3

    if-eq v1, p1, :cond_47

    const/4 p1, 0x4

    if-eq v1, p1, :cond_26

    const/4 p0, 0x5

    if-ne v1, p0, :cond_20

    goto :goto_47

    .line 3
    :cond_20
    new-instance p0, Lq6/a;

    invoke-direct {p0}, Lq6/a;-><init>()V

    throw p0

    .line 4
    :cond_26
    invoke-static {p0}, La0/u;->o(Lb1/l;)Z

    move-result p1

    if-eqz p1, :cond_32

    .line 5
    sget-object p1, Lb1/b0;->d:Lb1/b0;

    invoke-virtual {p0, p1}, Lb1/l;->b(Lb1/b0;)V

    goto :goto_47

    :cond_32
    const/4 p1, 0x0

    goto :goto_48

    :cond_34
    if-eqz p1, :cond_48

    .line 6
    invoke-virtual {p0, v0}, Lb1/l;->b(Lb1/b0;)V

    goto :goto_48

    .line 7
    :cond_3a
    invoke-static {p0}, La0/u;->o(Lb1/l;)Z

    move-result p1

    if-eqz p1, :cond_32

    .line 8
    invoke-virtual {p0, v0}, Lb1/l;->b(Lb1/b0;)V

    goto :goto_47

    .line 9
    :cond_44
    invoke-virtual {p0, v0}, Lb1/l;->b(Lb1/b0;)V

    :cond_47
    :goto_47
    const/4 p1, 0x1

    :cond_48
    :goto_48
    return p1
.end method

.method public static final q(JJ)I
    .registers 6

    .line 1
    invoke-static {p0, p1}, La0/u;->F(J)Z

    move-result v0

    .line 2
    invoke-static {p2, p3}, La0/u;->F(J)Z

    move-result v1

    if-eq v0, v1, :cond_10

    if-eqz v0, :cond_e

    const/4 p0, -0x1

    goto :goto_f

    :cond_e
    const/4 p0, 0x1

    :goto_f
    return p0

    .line 3
    :cond_10
    invoke-static {p0, p1}, La0/u;->x(J)F

    move-result p0

    invoke-static {p2, p3}, La0/u;->x(J)F

    move-result p1

    sub-float/2addr p0, p1

    .line 4
    invoke-static {p0}, Ljava/lang/Math;->signum(F)F

    move-result p0

    float-to-int p0, p0

    return p0
.end method

.method public static final r(Lb1/l;)V
    .registers 5

    sget-object v0, Lb1/b0;->d:Lb1/b0;

    .line 1
    iget-object v1, p0, Lb1/l;->d:Lb1/b0;

    .line 2
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_22

    if-eq v1, v2, :cond_1a

    const/4 v3, 0x2

    if-eq v1, v3, :cond_22

    const/4 v2, 0x5

    if-eq v1, v2, :cond_14

    goto :goto_3c

    .line 3
    :cond_14
    iput-object v0, p0, Lb1/l;->d:Lb1/b0;

    .line 4
    invoke-static {p0}, La0/u;->M(Lb1/l;)V

    goto :goto_3c

    .line 5
    :cond_1a
    sget-object v0, Lb1/b0;->e:Lb1/b0;

    .line 6
    iput-object v0, p0, Lb1/l;->d:Lb1/b0;

    .line 7
    invoke-static {p0}, La0/u;->M(Lb1/l;)V

    goto :goto_3c

    .line 8
    :cond_22
    iget-object v1, p0, Lb1/l;->m:Lt1/q;

    if-eqz v1, :cond_37

    .line 9
    iget-object v1, v1, Lt1/q;->e:Lt1/h;

    if-eqz v1, :cond_37

    .line 10
    iget-object v1, v1, Lt1/h;->g:Lt1/b0;

    if-eqz v1, :cond_37

    .line 11
    invoke-interface {v1}, Lt1/b0;->getFocusManager()Lb1/i;

    move-result-object v1

    if-eqz v1, :cond_37

    invoke-interface {v1, v2}, Lb1/i;->b(Z)V

    .line 12
    :cond_37
    iput-object v0, p0, Lb1/l;->d:Lb1/b0;

    .line 13
    invoke-static {p0}, La0/u;->M(Lb1/l;)V

    :goto_3c
    return-void
.end method

.method public static final s(Lz1/d;Ld1/p;Ld1/m;Ld1/j0;Lk2/f;)V
    .registers 9

    .line 1
    iget-object p0, p0, Lz1/d;->h:Ljava/util/List;

    .line 2
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_7
    if-ge v1, v0, :cond_21

    .line 3
    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    .line 4
    check-cast v2, Lz1/g;

    .line 5
    iget-object v3, v2, Lz1/g;->a:Lz1/f;

    .line 6
    invoke-interface {v3, p1, p2, p3, p4}, Lz1/f;->l(Ld1/p;Ld1/m;Ld1/j0;Lk2/f;)V

    const/4 v3, 0x0

    .line 7
    iget-object v2, v2, Lz1/g;->a:Lz1/f;

    .line 8
    invoke-interface {v2}, Lz1/f;->getHeight()F

    move-result v2

    invoke-interface {p1, v3, v2}, Ld1/p;->c(FF)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_7

    :cond_21
    return-void
.end method

.method public static t(Ljava/lang/Object;Ljava/lang/Object;)Z
    .registers 2

    if-eq p0, p1, :cond_d

    if-eqz p0, :cond_b

    .line 1
    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_b

    goto :goto_d

    :cond_b
    const/4 p0, 0x0

    goto :goto_e

    :cond_d
    :goto_d
    const/4 p0, 0x1

    :goto_e
    return p0
.end method

.method public static u(Landroid/view/View;I)Landroid/view/View;
    .registers 6

    .line 1
    instance-of v0, p0, Landroid/view/ViewGroup;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return-object v1

    .line 2
    :cond_6
    check-cast p0, Landroid/view/ViewGroup;

    .line 3
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v2, 0x0

    :goto_d
    if-ge v2, v0, :cond_1d

    .line 4
    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v3, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    if-eqz v3, :cond_1a

    return-object v3

    :cond_1a
    add-int/lit8 v2, v2, 0x1

    goto :goto_d

    :cond_1d
    return-object v1
.end method

.method public static v([Ljava/lang/StackTraceElement;)Ljava/lang/String;
    .registers 6

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 2
    array-length v1, p0

    const/4 v2, 0x0

    :goto_7
    if-ge v2, v1, :cond_1f

    aget-object v3, p0, v2

    const-string v4, "    at "

    .line 3
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StackTraceElement;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "\n"

    .line 4
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v2, v2, 0x1

    goto :goto_7

    .line 5
    :cond_1f
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static final w(I)Z
    .registers 2

    const/4 v0, 0x1

    and-int/2addr p0, v0

    if-eqz p0, :cond_5

    goto :goto_6

    :cond_5
    const/4 v0, 0x0

    :goto_6
    return v0
.end method

.method public static final x(J)F
    .registers 3

    const/16 v0, 0x20

    shr-long/2addr p0, v0

    long-to-int p1, p0

    .line 1
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p0

    return p0
.end method

.method public static final y(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    .registers 3

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-static {p0, p1}, Lg/a;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    if-eqz p0, :cond_c

    return-object p0

    :cond_c
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const-string p1, "Invalid resource ID: "

    invoke-static {p1, p0}, Lp/h;->Y(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public static final z(ILm0/g;)Ljava/lang/String;
    .registers 4

    const v0, -0x2b4f9f6b

    invoke-interface {p1, v0}, Lm0/g;->e(I)V

    .line 1
    sget-object v0, Landroidx/compose/ui/platform/v;->a:Lm0/e1;

    .line 2
    invoke-interface {p1, v0}, Lm0/g;->C(Lm0/w;)Ljava/lang/Object;

    .line 3
    sget-object v0, Landroidx/compose/ui/platform/v;->b:Lm0/e1;

    .line 4
    invoke-interface {p1, v0}, Lm0/g;->C(Lm0/w;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/Context;

    .line 5
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v1, 0x0

    .line 6
    invoke-static {p0, v1}, Lk0/l2;->a(II)Z

    move-result v1

    if-eqz v1, :cond_2b

    sget p0, Landroidx/compose/ui/R$string;->navigation_menu:I

    invoke-virtual {v0, p0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    const-string v0, "resources.getString(R.string.navigation_menu)"

    invoke-static {p0, v0}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    goto/16 :goto_9f

    :cond_2b
    const/4 v1, 0x1

    .line 7
    invoke-static {p0, v1}, Lk0/l2;->a(II)Z

    move-result v1

    if-eqz v1, :cond_3e

    sget p0, Landroidx/compose/ui/R$string;->close_drawer:I

    invoke-virtual {v0, p0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    const-string v0, "resources.getString(R.string.close_drawer)"

    invoke-static {p0, v0}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_9f

    :cond_3e
    const/4 v1, 0x2

    .line 8
    invoke-static {p0, v1}, Lk0/l2;->a(II)Z

    move-result v1

    if-eqz v1, :cond_51

    sget p0, Landroidx/compose/ui/R$string;->close_sheet:I

    invoke-virtual {v0, p0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    const-string v0, "resources.getString(R.string.close_sheet)"

    invoke-static {p0, v0}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_9f

    :cond_51
    const/4 v1, 0x3

    .line 9
    invoke-static {p0, v1}, Lk0/l2;->a(II)Z

    move-result v1

    if-eqz v1, :cond_64

    sget p0, Landroidx/compose/ui/R$string;->default_error_message:I

    invoke-virtual {v0, p0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    const-string v0, "resources.getString(R.st\u2026ng.default_error_message)"

    invoke-static {p0, v0}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_9f

    :cond_64
    const/4 v1, 0x4

    .line 10
    invoke-static {p0, v1}, Lk0/l2;->a(II)Z

    move-result v1

    if-eqz v1, :cond_77

    sget p0, Landroidx/compose/ui/R$string;->dropdown_menu:I

    invoke-virtual {v0, p0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    const-string v0, "resources.getString(R.string.dropdown_menu)"

    invoke-static {p0, v0}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_9f

    :cond_77
    const/4 v1, 0x5

    .line 11
    invoke-static {p0, v1}, Lk0/l2;->a(II)Z

    move-result v1

    if-eqz v1, :cond_8a

    sget p0, Landroidx/compose/ui/R$string;->range_start:I

    invoke-virtual {v0, p0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    const-string v0, "resources.getString(R.string.range_start)"

    invoke-static {p0, v0}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_9f

    :cond_8a
    const/4 v1, 0x6

    .line 12
    invoke-static {p0, v1}, Lk0/l2;->a(II)Z

    move-result p0

    if-eqz p0, :cond_9d

    sget p0, Landroidx/compose/ui/R$string;->range_end:I

    invoke-virtual {v0, p0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    const-string v0, "resources.getString(R.string.range_end)"

    invoke-static {p0, v0}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_9f

    :cond_9d
    const-string p0, ""

    .line 13
    :goto_9f
    invoke-interface {p1}, Lm0/g;->L()V

    return-object p0
.end method


# virtual methods
.method public a(Ljava/lang/Object;Ljava/lang/Object;)Z
    .registers 3

    const/4 p1, 0x0

    return p1
.end method

.method public b(Lr1/z0$a;)V
    .registers 3

    const-string v0, "slotIds"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object p1, p1, Lr1/z0$a;->a:Ljava/util/Set;

    invoke-interface {p1}, Ljava/util/Set;->clear()V

    return-void
.end method
