.class public Lac/c;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .registers 5

    const-string v0, "h"

    .line 1
    sget-object v1, Lp/h;->b:Landroid/content/Context;

    const-string v2, ""

    if-nez v1, :cond_9

    return-object v2

    .line 2
    :cond_9
    :try_start_9
    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v3, 0x0

    .line 3
    invoke-virtual {v1, p0, v3}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    .line 4
    iget-object p0, p0, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;
    :try_end_14
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_9 .. :try_end_14} :catch_31
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_14} :catch_1b
    .catchall {:try_start_9 .. :try_end_14} :catchall_15

    return-object p0

    :catchall_15
    const-string p0, "throwable"

    .line 5
    invoke-static {v0, p0}, La0/u;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_46

    :catch_1b
    move-exception p0

    const-string v1, "getVersion: "

    .line 6
    invoke-static {v1}, Landroid/support/v4/media/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v0, p0}, La0/u;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_46

    :catch_31
    move-exception p0

    const-string v1, "getVersion NameNotFoundException : "

    .line 7
    invoke-static {v1}, Landroid/support/v4/media/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p0}, Landroid/content/pm/PackageManager$NameNotFoundException;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v0, p0}, La0/u;->i(Ljava/lang/String;Ljava/lang/String;)V

    :goto_46
    return-object v2
.end method
