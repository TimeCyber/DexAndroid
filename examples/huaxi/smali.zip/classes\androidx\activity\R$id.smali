.class public final Landroidx/activity/R$id;
.super Ljava/lang/Object;


# static fields
.field public static final view_tree_on_back_pressed_dispatcher_owner:I = 0x7f080531


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
