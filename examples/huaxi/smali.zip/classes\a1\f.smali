.class public interface abstract La1/f;
.super Ljava/lang/Object;
.source "DrawModifier.kt"

# interfaces
.implements Ly0/h$b;


# virtual methods
.method public abstract K(Lf1/d;)V
.end method
