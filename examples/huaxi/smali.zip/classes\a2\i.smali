.class public interface abstract La2/i;
.super Ljava/lang/Object;
.source "StaticLayoutFactory.kt"


# virtual methods
.method public abstract a(La2/k;)Landroid/text/StaticLayout;
.end method
