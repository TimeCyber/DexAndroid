.class public final synthetic Landroidx/activity/m;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"


# direct methods
.method public static a(Ld1/c0;Ld1/c0;JILjava/lang/Object;)V
    .registers 6

    and-int/lit8 p4, p4, 0x2

    if-eqz p4, :cond_8

    .line 1
    sget-object p2, Lc1/c;->b:Lc1/c$a;

    .line 2
    sget-wide p2, Lc1/c;->c:J

    .line 3
    :cond_8
    invoke-interface {p0, p1, p2, p3}, Ld1/c0;->n(Ld1/c0;J)V

    return-void
.end method

.method public static b(Lm0/g;Landroidx/compose/ui/platform/a2;Lvg/p;Lm0/g;)Lm0/w1;
    .registers 4

    invoke-static {p0, p1, p2}, Landroidx/appcompat/widget/m;->R(Lm0/g;Ljava/lang/Object;Lvg/p;)V

    invoke-interface {p0}, Lm0/g;->h()V

    new-instance p0, Lm0/w1;

    invoke-direct {p0, p3}, Lm0/w1;-><init>(Lm0/g;)V

    return-object p0
.end method
