.class public La6/j;
.super Ljava/lang/Object;
.source "LottieCompositionFactory.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "La6/s<",
        "La6/g;",
        ">;>;"
    }
.end annotation


# instance fields
.field public final synthetic a:Landroid/content/Context;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    .line 1
    iput-object p1, p0, La6/j;->a:Landroid/content/Context;

    iput-object p2, p0, La6/j;->b:Ljava/lang/String;

    iput-object p3, p0, La6/j;->c:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public call()Ljava/lang/Object;
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 1
    iget-object v0, p0, La6/j;->a:Landroid/content/Context;

    iget-object v1, p0, La6/j;->b:Ljava/lang/String;

    iget-object v2, p0, La6/j;->c:Ljava/lang/String;

    invoke-static {v0, v1, v2}, La6/h;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)La6/s;

    move-result-object v0

    return-object v0
.end method
