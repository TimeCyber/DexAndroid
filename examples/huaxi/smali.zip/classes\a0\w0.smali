.class public final La0/w0;
.super Ljava/lang/Object;
.source "VectorConverters.kt"


# static fields
.field public static final a:La0/u0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/u0<",
            "Ljava/lang/Float;",
            "La0/k;",
            ">;"
        }
    .end annotation
.end field

.field public static final b:La0/u0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/u0<",
            "Ljava/lang/Integer;",
            "La0/k;",
            ">;"
        }
    .end annotation
.end field

.field public static final c:La0/u0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/u0<",
            "Lp2/d;",
            "La0/k;",
            ">;"
        }
    .end annotation
.end field

.field public static final d:La0/u0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/u0<",
            "Lp2/e;",
            "La0/l;",
            ">;"
        }
    .end annotation
.end field

.field public static final e:La0/u0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/u0<",
            "Lc1/f;",
            "La0/l;",
            ">;"
        }
    .end annotation
.end field

.field public static final f:La0/u0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/u0<",
            "Lc1/c;",
            "La0/l;",
            ">;"
        }
    .end annotation
.end field

.field public static final g:La0/u0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/u0<",
            "Lp2/g;",
            "La0/l;",
            ">;"
        }
    .end annotation
.end field

.field public static final h:La0/u0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/u0<",
            "Lp2/i;",
            "La0/l;",
            ">;"
        }
    .end annotation
.end field

.field public static final i:La0/u0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/u0<",
            "Lc1/d;",
            "La0/m;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .registers 2

    .line 1
    sget-object v0, La0/w0$e;->a:La0/w0$e;

    sget-object v1, La0/w0$f;->a:La0/w0$f;

    invoke-static {v0, v1}, La0/w0;->a(Lvg/l;Lvg/l;)La0/u0;

    move-result-object v0

    sput-object v0, La0/w0;->a:La0/u0;

    .line 2
    sget-object v0, La0/w0$k;->a:La0/w0$k;

    sget-object v1, La0/w0$l;->a:La0/w0$l;

    invoke-static {v0, v1}, La0/w0;->a(Lvg/l;Lvg/l;)La0/u0;

    move-result-object v0

    sput-object v0, La0/w0;->b:La0/u0;

    .line 3
    sget-object v0, La0/w0$c;->a:La0/w0$c;

    sget-object v1, La0/w0$d;->a:La0/w0$d;

    invoke-static {v0, v1}, La0/w0;->a(Lvg/l;Lvg/l;)La0/u0;

    move-result-object v0

    sput-object v0, La0/w0;->c:La0/u0;

    .line 4
    sget-object v0, La0/w0$a;->a:La0/w0$a;

    sget-object v1, La0/w0$b;->a:La0/w0$b;

    invoke-static {v0, v1}, La0/w0;->a(Lvg/l;Lvg/l;)La0/u0;

    move-result-object v0

    sput-object v0, La0/w0;->d:La0/u0;

    .line 5
    sget-object v0, La0/w0$q;->a:La0/w0$q;

    sget-object v1, La0/w0$r;->a:La0/w0$r;

    invoke-static {v0, v1}, La0/w0;->a(Lvg/l;Lvg/l;)La0/u0;

    move-result-object v0

    sput-object v0, La0/w0;->e:La0/u0;

    .line 6
    sget-object v0, La0/w0$m;->a:La0/w0$m;

    sget-object v1, La0/w0$n;->a:La0/w0$n;

    invoke-static {v0, v1}, La0/w0;->a(Lvg/l;Lvg/l;)La0/u0;

    move-result-object v0

    sput-object v0, La0/w0;->f:La0/u0;

    .line 7
    sget-object v0, La0/w0$g;->a:La0/w0$g;

    sget-object v1, La0/w0$h;->a:La0/w0$h;

    invoke-static {v0, v1}, La0/w0;->a(Lvg/l;Lvg/l;)La0/u0;

    move-result-object v0

    sput-object v0, La0/w0;->g:La0/u0;

    .line 8
    sget-object v0, La0/w0$i;->a:La0/w0$i;

    sget-object v1, La0/w0$j;->a:La0/w0$j;

    invoke-static {v0, v1}, La0/w0;->a(Lvg/l;Lvg/l;)La0/u0;

    move-result-object v0

    sput-object v0, La0/w0;->h:La0/u0;

    .line 9
    sget-object v0, La0/w0$o;->a:La0/w0$o;

    sget-object v1, La0/w0$p;->a:La0/w0$p;

    invoke-static {v0, v1}, La0/w0;->a(Lvg/l;Lvg/l;)La0/u0;

    move-result-object v0

    sput-object v0, La0/w0;->i:La0/u0;

    return-void
.end method

.method public static final a(Lvg/l;Lvg/l;)La0/u0;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "V:",
            "La0/n;",
            ">(",
            "Lvg/l<",
            "-TT;+TV;>;",
            "Lvg/l<",
            "-TV;+TT;>;)",
            "La0/u0<",
            "TT;TV;>;"
        }
    .end annotation

    const-string v0, "convertToVector"

    invoke-static {p0, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "convertFromVector"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    new-instance v0, La0/v0;

    invoke-direct {v0, p0, p1}, La0/v0;-><init>(Lvg/l;Lvg/l;)V

    return-object v0
.end method

.method public static final b(Lm/d;)La0/u0;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lm/d;",
            ")",
            "La0/u0<",
            "Ljava/lang/Float;",
            "La0/k;",
            ">;"
        }
    .end annotation

    .line 1
    sget-object p0, La0/w0;->a:La0/u0;

    return-object p0
.end method
