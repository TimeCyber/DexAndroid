.class public final La2/f;
.super Ljava/lang/Object;
.source "StaticLayoutFactory.kt"


# static fields
.field public static final a:La2/f;


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    new-instance v0, La2/f;

    invoke-direct {v0}, La2/f;-><init>()V

    sput-object v0, La2/f;->a:La2/f;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/text/StaticLayout$Builder;I)V
    .registers 4

    const-string v0, "builder"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-virtual {p1, p2}, Landroid/text/StaticLayout$Builder;->setJustificationMode(I)Landroid/text/StaticLayout$Builder;

    return-void
.end method
