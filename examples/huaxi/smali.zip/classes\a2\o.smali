.class public final La2/o;
.super Ljava/lang/Object;
.source "TextLayout.kt"


# static fields
.field public static final a:Lkg/e;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkg/e<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lkg/e;

    const/4 v1, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-direct {v0, v1, v1}, Lkg/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    sput-object v0, La2/o;->a:Lkg/e;

    return-void
.end method

.method public static final a(I)Landroid/text/TextDirectionHeuristic;
    .registers 3

    if-eqz p0, :cond_3f

    const/4 v0, 0x1

    if-eq p0, v0, :cond_37

    const/4 v0, 0x2

    const-string v1, "FIRSTSTRONG_LTR"

    if-eq p0, v0, :cond_31

    const/4 v0, 0x3

    if-eq p0, v0, :cond_29

    const/4 v0, 0x4

    if-eq p0, v0, :cond_21

    const/4 v0, 0x5

    if-eq p0, v0, :cond_19

    .line 1
    sget-object p0, Landroid/text/TextDirectionHeuristics;->FIRSTSTRONG_LTR:Landroid/text/TextDirectionHeuristic;

    invoke-static {p0, v1}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_46

    .line 2
    :cond_19
    sget-object p0, Landroid/text/TextDirectionHeuristics;->LOCALE:Landroid/text/TextDirectionHeuristic;

    const-string v0, "LOCALE"

    invoke-static {p0, v0}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_46

    .line 3
    :cond_21
    sget-object p0, Landroid/text/TextDirectionHeuristics;->ANYRTL_LTR:Landroid/text/TextDirectionHeuristic;

    const-string v0, "ANYRTL_LTR"

    invoke-static {p0, v0}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_46

    .line 4
    :cond_29
    sget-object p0, Landroid/text/TextDirectionHeuristics;->FIRSTSTRONG_RTL:Landroid/text/TextDirectionHeuristic;

    const-string v0, "FIRSTSTRONG_RTL"

    invoke-static {p0, v0}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_46

    .line 5
    :cond_31
    sget-object p0, Landroid/text/TextDirectionHeuristics;->FIRSTSTRONG_LTR:Landroid/text/TextDirectionHeuristic;

    invoke-static {p0, v1}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_46

    .line 6
    :cond_37
    sget-object p0, Landroid/text/TextDirectionHeuristics;->RTL:Landroid/text/TextDirectionHeuristic;

    const-string v0, "RTL"

    invoke-static {p0, v0}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_46

    .line 7
    :cond_3f
    sget-object p0, Landroid/text/TextDirectionHeuristics;->LTR:Landroid/text/TextDirectionHeuristic;

    const-string v0, "LTR"

    invoke-static {p0, v0}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    :goto_46
    return-object p0
.end method
