.class public final La7/u$b;
.super Ljava/util/concurrent/ThreadPoolExecutor;
.source "ThreadUtils.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La7/u;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field public final a:Ljava/util/concurrent/atomic/AtomicInteger;

.field public b:La7/u$a;


# direct methods
.method public constructor <init>(IIJLjava/util/concurrent/TimeUnit;La7/u$a;Ljava/util/concurrent/ThreadFactory;)V
    .registers 8

    .line 1
    invoke-direct/range {p0 .. p7}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V

    .line 2
    new-instance p1, Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    iput-object p1, p0, La7/u$b;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 3
    iput-object p0, p6, La7/u$a;->a:La7/u$b;

    .line 4
    iput-object p6, p0, La7/u$b;->b:La7/u$a;

    return-void
.end method

.method public static a(II)Ljava/util/concurrent/ExecutorService;
    .registers 26

    move/from16 v2, p0

    move/from16 v0, p1

    const/4 v1, -0x8

    const/4 v3, 0x1

    if-eq v2, v1, :cond_8e

    const/4 v1, -0x4

    if-eq v2, v1, :cond_6e

    const/4 v1, -0x2

    if-eq v2, v1, :cond_4e

    const/4 v1, -0x1

    if-eq v2, v1, :cond_33

    .line 1
    new-instance v8, La7/u$b;

    const-wide/16 v3, 0x0

    sget-object v5, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    new-instance v6, La7/u$a;

    invoke-direct {v6}, La7/u$a;-><init>()V

    new-instance v7, La7/u$c;

    const-string v1, "fixed("

    const-string v9, ")"

    invoke-static {v1, v2, v9}, Landroidx/activity/j;->a(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v7, v1, v0}, La7/u$c;-><init>(Ljava/lang/String;I)V

    move-object v0, v8

    move/from16 v1, p0

    move/from16 v2, p0

    invoke-direct/range {v0 .. v7}, La7/u$b;-><init>(IIJLjava/util/concurrent/TimeUnit;La7/u$a;Ljava/util/concurrent/ThreadFactory;)V

    goto/16 :goto_b1

    .line 2
    :cond_33
    new-instance v8, La7/u$b;

    const/4 v10, 0x1

    const/4 v11, 0x1

    const-wide/16 v12, 0x0

    sget-object v14, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    new-instance v15, La7/u$a;

    invoke-direct {v15}, La7/u$a;-><init>()V

    new-instance v1, La7/u$c;

    const-string v2, "single"

    invoke-direct {v1, v2, v0}, La7/u$c;-><init>(Ljava/lang/String;I)V

    move-object v9, v8

    move-object/from16 v16, v1

    invoke-direct/range {v9 .. v16}, La7/u$b;-><init>(IIJLjava/util/concurrent/TimeUnit;La7/u$a;Ljava/util/concurrent/ThreadFactory;)V

    goto :goto_b1

    .line 3
    :cond_4e
    new-instance v8, La7/u$b;

    const/16 v17, 0x0

    const/16 v18, 0x80

    const-wide/16 v19, 0x3c

    sget-object v21, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    new-instance v1, La7/u$a;

    invoke-direct {v1, v3}, La7/u$a;-><init>(Z)V

    new-instance v2, La7/u$c;

    const-string v3, "cached"

    invoke-direct {v2, v3, v0}, La7/u$c;-><init>(Ljava/lang/String;I)V

    move-object/from16 v16, v8

    move-object/from16 v22, v1

    move-object/from16 v23, v2

    invoke-direct/range {v16 .. v23}, La7/u$b;-><init>(IIJLjava/util/concurrent/TimeUnit;La7/u$a;Ljava/util/concurrent/ThreadFactory;)V

    goto :goto_b1

    .line 4
    :cond_6e
    new-instance v8, La7/u$b;

    .line 5
    sget v1, La7/u;->c:I

    mul-int/lit8 v1, v1, 0x2

    add-int/lit8 v11, v1, 0x1

    const-wide/16 v12, 0x1e

    .line 6
    sget-object v14, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    new-instance v15, La7/u$a;

    invoke-direct {v15}, La7/u$a;-><init>()V

    new-instance v1, La7/u$c;

    const-string v2, "io"

    invoke-direct {v1, v2, v0}, La7/u$c;-><init>(Ljava/lang/String;I)V

    move-object v9, v8

    move v10, v11

    move-object/from16 v16, v1

    invoke-direct/range {v9 .. v16}, La7/u$b;-><init>(IIJLjava/util/concurrent/TimeUnit;La7/u$a;Ljava/util/concurrent/ThreadFactory;)V

    goto :goto_b1

    .line 7
    :cond_8e
    new-instance v8, La7/u$b;

    .line 8
    sget v1, La7/u;->c:I

    add-int/lit8 v17, v1, 0x1

    mul-int/lit8 v1, v1, 0x2

    add-int/lit8 v18, v1, 0x1

    const-wide/16 v19, 0x1e

    .line 9
    sget-object v21, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    new-instance v1, La7/u$a;

    invoke-direct {v1, v3}, La7/u$a;-><init>(Z)V

    new-instance v2, La7/u$c;

    const-string v3, "cpu"

    invoke-direct {v2, v3, v0}, La7/u$c;-><init>(Ljava/lang/String;I)V

    move-object/from16 v16, v8

    move-object/from16 v22, v1

    move-object/from16 v23, v2

    invoke-direct/range {v16 .. v23}, La7/u$b;-><init>(IIJLjava/util/concurrent/TimeUnit;La7/u$a;Ljava/util/concurrent/ThreadFactory;)V

    :goto_b1
    return-object v8
.end method


# virtual methods
.method public afterExecute(Ljava/lang/Runnable;Ljava/lang/Throwable;)V
    .registers 4

    .line 1
    iget-object v0, p0, La7/u$b;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    .line 2
    invoke-super {p0, p1, p2}, Ljava/util/concurrent/ThreadPoolExecutor;->afterExecute(Ljava/lang/Runnable;Ljava/lang/Throwable;)V

    return-void
.end method

.method public execute(Ljava/lang/Runnable;)V
    .registers 4

    .line 1
    invoke-virtual {p0}, Ljava/util/concurrent/ThreadPoolExecutor;->isShutdown()Z

    move-result v0

    if-eqz v0, :cond_7

    return-void

    .line 2
    :cond_7
    iget-object v0, p0, La7/u$b;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    .line 3
    :try_start_c
    invoke-super {p0, p1}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V
    :try_end_f
    .catch Ljava/util/concurrent/RejectedExecutionException; {:try_start_c .. :try_end_f} :catch_16
    .catchall {:try_start_c .. :try_end_f} :catchall_10

    goto :goto_22

    .line 4
    :catchall_10
    iget-object p1, p0, La7/u$b;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    goto :goto_22

    :catch_16
    const-string v0, "ThreadUtils"

    const-string v1, "This will not happen!"

    .line 5
    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 6
    iget-object v0, p0, La7/u$b;->b:La7/u$a;

    invoke-virtual {v0, p1}, La7/u$a;->b(Ljava/lang/Runnable;)Z

    :goto_22
    return-void
.end method
