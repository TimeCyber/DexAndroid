.class public abstract Landroidx/activity/f;
.super Ljava/lang/Object;
.source "OnBackPressedCallback.java"


# instance fields
.field public a:Z

.field public b:Ljava/util/concurrent/CopyOnWriteArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/CopyOnWriteArrayList<",
            "Landroidx/activity/a;",
            ">;"
        }
    .end annotation
.end field

.field public c:Lk3/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lk3/a<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Z)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-direct {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    iput-object v0, p0, Landroidx/activity/f;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 3
    iput-boolean p1, p0, Landroidx/activity/f;->a:Z

    return-void
.end method


# virtual methods
.method public abstract a()V
.end method

.method public final b(Z)V
    .registers 3

    .line 1
    iput-boolean p1, p0, Landroidx/activity/f;->a:Z

    .line 2
    iget-object v0, p0, Landroidx/activity/f;->c:Lk3/a;

    if-eqz v0, :cond_d

    .line 3
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    invoke-interface {v0, p1}, Lk3/a;->a(Ljava/lang/Object;)V

    :cond_d
    return-void
.end method
