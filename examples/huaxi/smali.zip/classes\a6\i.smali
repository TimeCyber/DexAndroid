.class public La6/i;
.super Ljava/lang/Object;
.source "LottieCompositionFactory.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "La6/s<",
        "La6/g;",
        ">;>;"
    }
.end annotation


# instance fields
.field public final synthetic a:Landroid/content/Context;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    .line 1
    iput-object p1, p0, La6/i;->a:Landroid/content/Context;

    iput-object p2, p0, La6/i;->b:Ljava/lang/String;

    iput-object p3, p0, La6/i;->c:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public call()Ljava/lang/Object;
    .registers 12
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 1
    iget-object v0, p0, La6/i;->a:Landroid/content/Context;

    .line 2
    sget-object v1, La6/d;->b:Lj6/f;

    if-nez v1, :cond_3f

    .line 3
    const-class v2, Lj6/f;

    monitor-enter v2

    .line 4
    :try_start_9
    sget-object v1, La6/d;->b:Lj6/f;

    if-nez v1, :cond_3a

    .line 5
    new-instance v1, Lj6/f;

    .line 6
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    .line 7
    sget-object v3, La6/d;->c:Lj6/e;

    if-nez v3, :cond_30

    .line 8
    const-class v3, Lj6/e;

    monitor-enter v3
    :try_end_1a
    .catchall {:try_start_9 .. :try_end_1a} :catchall_3c

    .line 9
    :try_start_1a
    sget-object v4, La6/d;->c:Lj6/e;

    if-nez v4, :cond_2a

    .line 10
    new-instance v4, Lj6/e;

    new-instance v5, La6/c;

    invoke-direct {v5, v0}, La6/c;-><init>(Landroid/content/Context;)V

    invoke-direct {v4, v5}, Lj6/e;-><init>(Lj6/d;)V

    sput-object v4, La6/d;->c:Lj6/e;

    .line 11
    :cond_2a
    monitor-exit v3

    move-object v3, v4

    goto :goto_30

    :catchall_2d
    move-exception v0

    monitor-exit v3
    :try_end_2f
    .catchall {:try_start_1a .. :try_end_2f} :catchall_2d

    :try_start_2f
    throw v0

    .line 12
    :cond_30
    :goto_30
    new-instance v0, Lj6/b;

    invoke-direct {v0}, Lj6/b;-><init>()V

    invoke-direct {v1, v3, v0}, Lj6/f;-><init>(Lj6/e;Lj6/b;)V

    sput-object v1, La6/d;->b:Lj6/f;

    .line 13
    :cond_3a
    monitor-exit v2

    goto :goto_3f

    :catchall_3c
    move-exception v0

    monitor-exit v2
    :try_end_3e
    .catchall {:try_start_2f .. :try_end_3e} :catchall_3c

    throw v0

    .line 14
    :cond_3f
    :goto_3f
    iget-object v0, p0, La6/i;->b:Ljava/lang/String;

    iget-object v2, p0, La6/i;->c:Ljava/lang/String;

    .line 15
    sget-object v3, Lj6/c;->c:Lj6/c;

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-nez v2, :cond_4b

    goto/16 :goto_c1

    .line 16
    :cond_4b
    iget-object v6, v1, Lj6/f;->a:Lj6/e;

    invoke-static {v6}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    :try_start_50
    new-instance v7, Ljava/io/File;

    invoke-virtual {v6}, Lj6/e;->b()Ljava/io/File;

    move-result-object v8

    sget-object v9, Lj6/c;->b:Lj6/c;

    invoke-static {v0, v9, v4}, Lj6/e;->a(Ljava/lang/String;Lj6/c;Z)Ljava/lang/String;

    move-result-object v10

    invoke-direct {v7, v8, v10}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 18
    invoke-virtual {v7}, Ljava/io/File;->exists()Z

    move-result v8

    if-eqz v8, :cond_66

    goto :goto_7b

    .line 19
    :cond_66
    new-instance v7, Ljava/io/File;

    invoke-virtual {v6}, Lj6/e;->b()Ljava/io/File;

    move-result-object v6

    invoke-static {v0, v3, v4}, Lj6/e;->a(Ljava/lang/String;Lj6/c;Z)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v7, v6, v8}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 20
    invoke-virtual {v7}, Ljava/io/File;->exists()Z

    move-result v6

    if-eqz v6, :cond_7a

    goto :goto_7b

    :cond_7a
    move-object v7, v5

    :goto_7b
    if-nez v7, :cond_7e

    goto :goto_9e

    .line 21
    :cond_7e
    new-instance v6, Ljava/io/FileInputStream;

    invoke-direct {v6, v7}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    :try_end_83
    .catch Ljava/io/FileNotFoundException; {:try_start_50 .. :try_end_83} :catch_9e

    .line 22
    invoke-virtual {v7}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v8

    const-string v10, ".zip"

    invoke-virtual {v8, v10}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_90

    move-object v9, v3

    .line 23
    :cond_90
    invoke-virtual {v7}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 24
    sget-object v7, Lm6/c;->a:La6/p;

    invoke-static {v7}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    new-instance v7, Landroid/util/Pair;

    invoke-direct {v7, v9, v6}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_9f

    :catch_9e
    :goto_9e
    move-object v7, v5

    :goto_9f
    if-nez v7, :cond_a2

    goto :goto_c1

    .line 26
    :cond_a2
    iget-object v6, v7, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v6, Lj6/c;

    .line 27
    iget-object v7, v7, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v7, Ljava/io/InputStream;

    if-ne v6, v3, :cond_b6

    .line 28
    new-instance v3, Ljava/util/zip/ZipInputStream;

    invoke-direct {v3, v7}, Ljava/util/zip/ZipInputStream;-><init>(Ljava/io/InputStream;)V

    invoke-static {v3, v0}, La6/h;->f(Ljava/util/zip/ZipInputStream;Ljava/lang/String;)La6/s;

    move-result-object v3

    goto :goto_ba

    .line 29
    :cond_b6
    invoke-static {v7, v0}, La6/h;->c(Ljava/io/InputStream;Ljava/lang/String;)La6/s;

    move-result-object v3

    .line 30
    :goto_ba
    iget-object v3, v3, La6/s;->a:Ljava/lang/Object;

    if-eqz v3, :cond_c1

    .line 31
    check-cast v3, La6/g;

    goto :goto_c2

    :cond_c1
    :goto_c1
    move-object v3, v5

    :goto_c2
    if-eqz v3, :cond_ca

    .line 32
    new-instance v0, La6/s;

    invoke-direct {v0, v3}, La6/s;-><init>(Ljava/lang/Object;)V

    goto :goto_131

    .line 33
    :cond_ca
    sget-object v3, Lm6/c;->a:La6/p;

    invoke-static {v3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const-string v3, "LottieFetchResult close failed "

    .line 34
    sget-object v6, Lm6/c;->a:La6/p;

    invoke-static {v6}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    :try_start_d6
    iget-object v6, v1, Lj6/f;->b:Lj6/b;

    invoke-virtual {v6, v0}, Lj6/b;->a(Ljava/lang/String;)Lj6/a;

    move-result-object v5
    :try_end_dc
    .catch Ljava/lang/Exception; {:try_start_d6 .. :try_end_dc} :catch_11e
    .catchall {:try_start_d6 .. :try_end_dc} :catchall_11c

    .line 36
    :try_start_dc
    iget-object v6, v5, Lj6/a;->a:Ljava/net/HttpURLConnection;

    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v6

    div-int/lit8 v6, v6, 0x64
    :try_end_e4
    .catch Ljava/io/IOException; {:try_start_dc .. :try_end_e4} :catch_e9
    .catch Ljava/lang/Exception; {:try_start_dc .. :try_end_e4} :catch_11e
    .catchall {:try_start_dc .. :try_end_e4} :catchall_11c

    const/4 v7, 0x2

    if-ne v6, v7, :cond_ea

    const/4 v4, 0x1

    goto :goto_ea

    :catch_e9
    nop

    :cond_ea
    :goto_ea
    if-eqz v4, :cond_104

    .line 37
    :try_start_ec
    iget-object v4, v5, Lj6/a;->a:Ljava/net/HttpURLConnection;

    invoke-virtual {v4}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v4

    .line 38
    iget-object v6, v5, Lj6/a;->a:Ljava/net/HttpURLConnection;

    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->getContentType()Ljava/lang/String;

    move-result-object v6

    .line 39
    invoke-virtual {v1, v0, v4, v6, v2}, Lj6/f;->a(Ljava/lang/String;Ljava/io/InputStream;Ljava/lang/String;Ljava/lang/String;)La6/s;

    move-result-object v0

    .line 40
    sget-object v1, Lm6/c;->a:La6/p;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_101
    .catch Ljava/lang/Exception; {:try_start_ec .. :try_end_101} :catch_11e
    .catchall {:try_start_ec .. :try_end_101} :catchall_11c

    .line 41
    :goto_101
    :try_start_101
    iget-object v1, v5, Lj6/a;->a:Ljava/net/HttpURLConnection;
    :try_end_103
    .catch Ljava/io/IOException; {:try_start_101 .. :try_end_103} :catch_117

    goto :goto_113

    .line 42
    :cond_104
    :try_start_104
    new-instance v0, La6/s;

    new-instance v1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v5}, Lj6/a;->a()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    invoke-direct {v0, v1}, La6/s;-><init>(Ljava/lang/Throwable;)V
    :try_end_112
    .catch Ljava/lang/Exception; {:try_start_104 .. :try_end_112} :catch_11e
    .catchall {:try_start_104 .. :try_end_112} :catchall_11c

    goto :goto_101

    .line 43
    :goto_113
    :try_start_113
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_116
    .catch Ljava/io/IOException; {:try_start_113 .. :try_end_116} :catch_117

    goto :goto_131

    :catch_117
    move-exception v1

    .line 44
    invoke-static {v3, v1}, Lm6/c;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_131

    :catchall_11c
    move-exception v0

    goto :goto_141

    :catch_11e
    move-exception v0

    .line 45
    :try_start_11f
    new-instance v1, La6/s;

    invoke-direct {v1, v0}, La6/s;-><init>(Ljava/lang/Throwable;)V
    :try_end_124
    .catchall {:try_start_11f .. :try_end_124} :catchall_11c

    if-eqz v5, :cond_130

    .line 46
    :try_start_126
    iget-object v0, v5, Lj6/a;->a:Ljava/net/HttpURLConnection;

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_12b
    .catch Ljava/io/IOException; {:try_start_126 .. :try_end_12b} :catch_12c

    goto :goto_130

    :catch_12c
    move-exception v0

    .line 47
    invoke-static {v3, v0}, Lm6/c;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_130
    :goto_130
    move-object v0, v1

    .line 48
    :goto_131
    iget-object v1, p0, La6/i;->c:Ljava/lang/String;

    if-eqz v1, :cond_140

    .line 49
    iget-object v2, v0, La6/s;->a:Ljava/lang/Object;

    if-eqz v2, :cond_140

    .line 50
    sget-object v3, Lf6/g;->b:Lf6/g;

    .line 51
    check-cast v2, La6/g;

    invoke-virtual {v3, v1, v2}, Lf6/g;->a(Ljava/lang/String;La6/g;)V

    :cond_140
    return-object v0

    :goto_141
    if-eqz v5, :cond_14d

    .line 52
    :try_start_143
    iget-object v1, v5, Lj6/a;->a:Ljava/net/HttpURLConnection;

    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_148
    .catch Ljava/io/IOException; {:try_start_143 .. :try_end_148} :catch_149

    goto :goto_14d

    :catch_149
    move-exception v1

    .line 53
    invoke-static {v3, v1}, Lm6/c;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 54
    :cond_14d
    :goto_14d
    throw v0
.end method
