.class public final synthetic La0/d;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"


# direct methods
.method public static a(Lr1/y;Lr1/k;Ljava/util/List;I)I
    .registers 11

    const-string v0, "<this>"

    .line 1
    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "measurables"

    invoke-static {p2, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    new-instance v0, Ljava/util/ArrayList;

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 3
    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_19
    if-ge v3, v1, :cond_2d

    .line 4
    invoke-interface {p2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    .line 5
    check-cast v4, Lr1/j;

    .line 6
    new-instance v5, Lr1/g;

    const/4 v6, 0x2

    invoke-direct {v5, v4, v6, v6}, Lr1/g;-><init>(Lr1/j;II)V

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_19

    :cond_2d
    const/16 p2, 0xd

    .line 7
    invoke-static {v2, p3, v2, v2, p2}, Le2/z;->d(IIIII)J

    move-result-wide p2

    .line 8
    new-instance v1, Lr1/l;

    invoke-interface {p1}, Lr1/k;->getLayoutDirection()Lp2/j;

    move-result-object v2

    invoke-direct {v1, p1, v2}, Lr1/l;-><init>(Lp2/b;Lp2/j;)V

    .line 9
    invoke-interface {p0, v1, v0, p2, p3}, Lr1/y;->e(Lr1/b0;Ljava/util/List;J)Lr1/z;

    move-result-object p0

    .line 10
    invoke-interface {p0}, Lr1/z;->getHeight()I

    move-result p0

    return p0
.end method

.method public static b(Lr1/y;Lr1/k;Ljava/util/List;I)I
    .registers 12

    const-string v0, "<this>"

    .line 1
    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "measurables"

    invoke-static {p2, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    new-instance v0, Ljava/util/ArrayList;

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 3
    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_19
    if-ge v3, v1, :cond_2e

    .line 4
    invoke-interface {p2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    .line 5
    check-cast v4, Lr1/j;

    .line 6
    new-instance v5, Lr1/g;

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-direct {v5, v4, v6, v7}, Lr1/g;-><init>(Lr1/j;II)V

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_19

    :cond_2e
    const/4 p2, 0x7

    .line 7
    invoke-static {v2, v2, v2, p3, p2}, Le2/z;->d(IIIII)J

    move-result-wide p2

    .line 8
    new-instance v1, Lr1/l;

    invoke-interface {p1}, Lr1/k;->getLayoutDirection()Lp2/j;

    move-result-object v2

    invoke-direct {v1, p1, v2}, Lr1/l;-><init>(Lp2/b;Lp2/j;)V

    .line 9
    invoke-interface {p0, v1, v0, p2, p3}, Lr1/y;->e(Lr1/b0;Ljava/util/List;J)Lr1/z;

    move-result-object p0

    .line 10
    invoke-interface {p0}, Lr1/z;->getWidth()I

    move-result p0

    return p0
.end method

.method public static c(Lr1/y;Lr1/k;Ljava/util/List;I)I
    .registers 12

    const-string v0, "<this>"

    .line 1
    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "measurables"

    invoke-static {p2, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    new-instance v0, Ljava/util/ArrayList;

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 3
    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_19
    if-ge v3, v1, :cond_2e

    .line 4
    invoke-interface {p2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    .line 5
    check-cast v4, Lr1/j;

    .line 6
    new-instance v5, Lr1/g;

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-direct {v5, v4, v7, v6}, Lr1/g;-><init>(Lr1/j;II)V

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_19

    :cond_2e
    const/16 p2, 0xd

    .line 7
    invoke-static {v2, p3, v2, v2, p2}, Le2/z;->d(IIIII)J

    move-result-wide p2

    .line 8
    new-instance v1, Lr1/l;

    invoke-interface {p1}, Lr1/k;->getLayoutDirection()Lp2/j;

    move-result-object v2

    invoke-direct {v1, p1, v2}, Lr1/l;-><init>(Lp2/b;Lp2/j;)V

    .line 9
    invoke-interface {p0, v1, v0, p2, p3}, Lr1/y;->e(Lr1/b0;Ljava/util/List;J)Lr1/z;

    move-result-object p0

    .line 10
    invoke-interface {p0}, Lr1/z;->getHeight()I

    move-result p0

    return p0
.end method

.method public static d(Lr1/y;Lr1/k;Ljava/util/List;I)I
    .registers 11

    const-string v0, "<this>"

    .line 1
    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "measurables"

    invoke-static {p2, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    new-instance v0, Ljava/util/ArrayList;

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 3
    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_19
    if-ge v3, v1, :cond_2d

    .line 4
    invoke-interface {p2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    .line 5
    check-cast v4, Lr1/j;

    .line 6
    new-instance v5, Lr1/g;

    const/4 v6, 0x1

    invoke-direct {v5, v4, v6, v6}, Lr1/g;-><init>(Lr1/j;II)V

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_19

    :cond_2d
    const/4 p2, 0x7

    .line 7
    invoke-static {v2, v2, v2, p3, p2}, Le2/z;->d(IIIII)J

    move-result-wide p2

    .line 8
    new-instance v1, Lr1/l;

    invoke-interface {p1}, Lr1/k;->getLayoutDirection()Lp2/j;

    move-result-object v2

    invoke-direct {v1, p1, v2}, Lr1/l;-><init>(Lp2/b;Lp2/j;)V

    .line 9
    invoke-interface {p0, v1, v0, p2, p3}, Lr1/y;->e(Lr1/b0;Ljava/util/List;J)Lr1/z;

    move-result-object p0

    .line 10
    invoke-interface {p0}, Lr1/z;->getWidth()I

    move-result p0

    return p0
.end method

.method public static e(Ljava/lang/StringBuilder;Ljava/lang/String;Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;I)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;
    .registers 4

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p2, p3, p0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setText(ILjava/lang/CharSequence;)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic f(I)Ljava/lang/String;
    .registers 2

    const/4 v0, 0x1

    if-ne p0, v0, :cond_6

    const-string p0, "BoundReached"

    return-object p0

    :cond_6
    const/4 v0, 0x2

    if-ne p0, v0, :cond_c

    const-string p0, "Finished"

    return-object p0

    :cond_c
    const-string p0, "null"

    return-object p0
.end method
