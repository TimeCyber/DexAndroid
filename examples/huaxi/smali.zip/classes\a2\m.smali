.class public final La2/m;
.super Lwg/j;
.source "TextLayout.kt"

# interfaces
.implements Lvg/a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lwg/j;",
        "Lvg/a<",
        "La2/b;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic a:La2/n;


# direct methods
.method public constructor <init>(La2/n;)V
    .registers 2

    iput-object p1, p0, La2/m;->a:La2/n;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lwg/j;-><init>(I)V

    return-void
.end method


# virtual methods
.method public invoke()Ljava/lang/Object;
    .registers 3

    .line 1
    new-instance v0, La2/b;

    iget-object v1, p0, La2/m;->a:La2/n;

    .line 2
    iget-object v1, v1, La2/n;->d:Landroid/text/Layout;

    .line 3
    invoke-direct {v0, v1}, La2/b;-><init>(Landroid/text/Layout;)V

    return-object v0
.end method
