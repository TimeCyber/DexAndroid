.class public interface abstract La0/u0;
.super Ljava/lang/Object;
.source "VectorConverters.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "V:",
        "La0/n;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()Lvg/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lvg/l<",
            "TT;TV;>;"
        }
    .end annotation
.end method

.method public abstract b()Lvg/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lvg/l<",
            "TV;TT;>;"
        }
    .end annotation
.end method
