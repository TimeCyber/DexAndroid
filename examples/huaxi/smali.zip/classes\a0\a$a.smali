.class public final La0/a$a;
.super Lwg/j;
.source "Animatable.kt"

# interfaces
.implements Lvg/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La0/a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lwg/j;",
        "Lvg/l<",
        "La0/f<",
        "Ljava/lang/Object;",
        "La0/n;",
        ">;",
        "Lkg/l;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic a:La0/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/b<",
            "Ljava/lang/Object;",
            "La0/n;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic b:La0/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/h<",
            "Ljava/lang/Object;",
            "La0/n;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic c:Lvg/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lvg/l<",
            "La0/b<",
            "Ljava/lang/Object;",
            "La0/n;",
            ">;",
            "Lkg/l;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic d:Lwg/s;


# direct methods
.method public constructor <init>(La0/b;La0/h;Lvg/l;Lwg/s;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La0/b<",
            "Ljava/lang/Object;",
            "La0/n;",
            ">;",
            "La0/h<",
            "Ljava/lang/Object;",
            "La0/n;",
            ">;",
            "Lvg/l<",
            "-",
            "La0/b<",
            "Ljava/lang/Object;",
            "La0/n;",
            ">;",
            "Lkg/l;",
            ">;",
            "Lwg/s;",
            ")V"
        }
    .end annotation

    iput-object p1, p0, La0/a$a;->a:La0/b;

    iput-object p2, p0, La0/a$a;->b:La0/h;

    iput-object p3, p0, La0/a$a;->c:Lvg/l;

    iput-object p4, p0, La0/a$a;->d:Lwg/s;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lwg/j;-><init>(I)V

    return-void
.end method


# virtual methods
.method public invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 1
    check-cast p1, La0/f;

    const-string v0, "$this$animate"

    .line 2
    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    iget-object v0, p0, La0/a$a;->a:La0/b;

    .line 4
    iget-object v0, v0, La0/b;->c:La0/h;

    .line 5
    invoke-static {p1, v0}, La0/p0;->e(La0/f;La0/h;)V

    .line 6
    iget-object v0, p0, La0/a$a;->a:La0/b;

    invoke-virtual {p1}, La0/f;->a()Ljava/lang/Object;

    move-result-object v1

    invoke-static {v0, v1}, La0/b;->a(La0/b;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    .line 7
    invoke-virtual {p1}, La0/f;->a()Ljava/lang/Object;

    move-result-object v1

    invoke-static {v0, v1}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4a

    .line 8
    iget-object v1, p0, La0/a$a;->a:La0/b;

    .line 9
    iget-object v1, v1, La0/b;->c:La0/h;

    .line 10
    iget-object v1, v1, La0/h;->b:Lm0/x0;

    .line 11
    invoke-interface {v1, v0}, Lm0/x0;->setValue(Ljava/lang/Object;)V

    .line 12
    iget-object v1, p0, La0/a$a;->b:La0/h;

    .line 13
    iget-object v1, v1, La0/h;->b:Lm0/x0;

    .line 14
    invoke-interface {v1, v0}, Lm0/x0;->setValue(Ljava/lang/Object;)V

    .line 15
    iget-object v0, p0, La0/a$a;->c:Lvg/l;

    if-eqz v0, :cond_3b

    iget-object v1, p0, La0/a$a;->a:La0/b;

    invoke-interface {v0, v1}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_3b
    const/4 v0, 0x0

    .line 16
    invoke-virtual {p1, v0}, La0/f;->b(Z)V

    .line 17
    iget-object p1, p1, La0/f;->d:Lvg/a;

    invoke-interface {p1}, Lvg/a;->invoke()Ljava/lang/Object;

    .line 18
    iget-object p1, p0, La0/a$a;->d:Lwg/s;

    const/4 v0, 0x1

    iput-boolean v0, p1, Lwg/s;->a:Z

    goto :goto_53

    .line 19
    :cond_4a
    iget-object p1, p0, La0/a$a;->c:Lvg/l;

    if-eqz p1, :cond_53

    iget-object v0, p0, La0/a$a;->a:La0/b;

    invoke-interface {p1, v0}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    :cond_53
    :goto_53
    sget-object p1, Lkg/l;->a:Lkg/l;

    return-object p1
.end method
