.class public final La0/e1;
.super Ljava/lang/Object;
.source "VectorizedAnimationSpec.kt"

# interfaces
.implements La0/y0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<V:",
        "La0/n;",
        ">",
        "Ljava/lang/Object;",
        "La0/y0;"
    }
.end annotation


# instance fields
.field public final a:La0/o;

.field public b:La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field

.field public c:La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field

.field public d:La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(La0/o;)V
    .registers 3

    const-string v0, "anims"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, La0/e1;->a:La0/o;

    return-void
.end method

.method public constructor <init>(La0/z;)V
    .registers 3

    const-string v0, "anim"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    new-instance v0, La0/e1$a;

    invoke-direct {v0, p1}, La0/e1$a;-><init>(La0/z;)V

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    iput-object v0, p0, La0/e1;->a:La0/o;

    return-void
.end method


# virtual methods
.method public synthetic a()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public b(La0/n;La0/n;La0/n;)J
    .registers 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;TV;TV;)J"
        }
    .end annotation

    const-string v0, "initialValue"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "targetValue"

    invoke-static {p2, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "initialVelocity"

    invoke-static {p3, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-virtual {p1}, La0/n;->b()I

    move-result v0

    const/4 v1, 0x0

    invoke-static {v1, v0}, Li0/z0;->X(II)Lch/f;

    move-result-object v0

    .line 2
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const-wide/16 v1, 0x0

    :goto_1e
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_46

    move-object v3, v0

    check-cast v3, Llg/y;

    invoke-virtual {v3}, Llg/y;->b()I

    move-result v3

    .line 3
    iget-object v4, p0, La0/e1;->a:La0/o;

    invoke-interface {v4, v3}, La0/o;->get(I)La0/z;

    move-result-object v4

    invoke-virtual {p1, v3}, La0/n;->a(I)F

    move-result v5

    invoke-virtual {p2, v3}, La0/n;->a(I)F

    move-result v6

    invoke-virtual {p3, v3}, La0/n;->a(I)F

    move-result v3

    invoke-interface {v4, v5, v6, v3}, La0/z;->c(FFF)J

    move-result-wide v3

    invoke-static {v1, v2, v3, v4}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v1

    goto :goto_1e

    :cond_46
    return-wide v1
.end method

.method public c(JLa0/n;La0/n;La0/n;)La0/n;
    .registers 22
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JTV;TV;TV;)TV;"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v1, p3

    move-object/from16 v2, p4

    move-object/from16 v3, p5

    const-string v4, "initialValue"

    invoke-static {v1, v4}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "targetValue"

    invoke-static {v2, v4}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "initialVelocity"

    invoke-static {v3, v4}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object v4, v0, La0/e1;->c:La0/n;

    if-nez v4, :cond_21

    .line 2
    invoke-static/range {p5 .. p5}, Landroidx/appcompat/widget/m;->M(La0/n;)La0/n;

    move-result-object v4

    iput-object v4, v0, La0/e1;->c:La0/n;

    :cond_21
    const/4 v4, 0x0

    .line 3
    iget-object v5, v0, La0/e1;->c:La0/n;

    const/4 v6, 0x0

    const-string v7, "velocityVector"

    if-eqz v5, :cond_5e

    invoke-virtual {v5}, La0/n;->b()I

    move-result v5

    :goto_2d
    if-ge v4, v5, :cond_55

    .line 4
    iget-object v8, v0, La0/e1;->c:La0/n;

    if-eqz v8, :cond_51

    .line 5
    iget-object v9, v0, La0/e1;->a:La0/o;

    invoke-interface {v9, v4}, La0/o;->get(I)La0/z;

    move-result-object v10

    .line 6
    invoke-virtual {v1, v4}, La0/n;->a(I)F

    move-result v13

    .line 7
    invoke-virtual {v2, v4}, La0/n;->a(I)F

    move-result v14

    .line 8
    invoke-virtual {v3, v4}, La0/n;->a(I)F

    move-result v15

    move-wide/from16 v11, p1

    .line 9
    invoke-interface/range {v10 .. v15}, La0/z;->b(JFFF)F

    move-result v9

    .line 10
    invoke-virtual {v8, v4, v9}, La0/n;->e(IF)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_2d

    :cond_51
    invoke-static {v7}, Lp/h;->b0(Ljava/lang/String;)V

    throw v6

    .line 11
    :cond_55
    iget-object v1, v0, La0/e1;->c:La0/n;

    if-eqz v1, :cond_5a

    return-object v1

    :cond_5a
    invoke-static {v7}, Lp/h;->b0(Ljava/lang/String;)V

    throw v6

    .line 12
    :cond_5e
    invoke-static {v7}, Lp/h;->b0(Ljava/lang/String;)V

    throw v6
.end method

.method public d(La0/n;La0/n;La0/n;)La0/n;
    .registers 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;TV;TV;)TV;"
        }
    .end annotation

    const-string v0, "initialValue"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "targetValue"

    invoke-static {p2, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "initialVelocity"

    invoke-static {p3, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object v0, p0, La0/e1;->d:La0/n;

    if-nez v0, :cond_19

    .line 2
    invoke-static {p3}, Landroidx/appcompat/widget/m;->M(La0/n;)La0/n;

    move-result-object v0

    iput-object v0, p0, La0/e1;->d:La0/n;

    :cond_19
    const/4 v0, 0x0

    .line 3
    iget-object v1, p0, La0/e1;->d:La0/n;

    const/4 v2, 0x0

    const-string v3, "endVelocityVector"

    if-eqz v1, :cond_54

    invoke-virtual {v1}, La0/n;->b()I

    move-result v1

    :goto_25
    if-ge v0, v1, :cond_4b

    .line 4
    iget-object v4, p0, La0/e1;->d:La0/n;

    if-eqz v4, :cond_47

    .line 5
    iget-object v5, p0, La0/e1;->a:La0/o;

    invoke-interface {v5, v0}, La0/o;->get(I)La0/z;

    move-result-object v5

    invoke-virtual {p1, v0}, La0/n;->a(I)F

    move-result v6

    invoke-virtual {p2, v0}, La0/n;->a(I)F

    move-result v7

    invoke-virtual {p3, v0}, La0/n;->a(I)F

    move-result v8

    invoke-interface {v5, v6, v7, v8}, La0/z;->d(FFF)F

    move-result v5

    .line 6
    invoke-virtual {v4, v0, v5}, La0/n;->e(IF)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_25

    :cond_47
    invoke-static {v3}, Lp/h;->b0(Ljava/lang/String;)V

    throw v2

    .line 7
    :cond_4b
    iget-object p1, p0, La0/e1;->d:La0/n;

    if-eqz p1, :cond_50

    return-object p1

    :cond_50
    invoke-static {v3}, Lp/h;->b0(Ljava/lang/String;)V

    throw v2

    .line 8
    :cond_54
    invoke-static {v3}, Lp/h;->b0(Ljava/lang/String;)V

    throw v2
.end method

.method public e(JLa0/n;La0/n;La0/n;)La0/n;
    .registers 22
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JTV;TV;TV;)TV;"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v1, p3

    move-object/from16 v2, p4

    move-object/from16 v3, p5

    const-string v4, "initialValue"

    invoke-static {v1, v4}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "targetValue"

    invoke-static {v2, v4}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "initialVelocity"

    invoke-static {v3, v4}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object v4, v0, La0/e1;->b:La0/n;

    if-nez v4, :cond_21

    .line 2
    invoke-static/range {p3 .. p3}, Landroidx/appcompat/widget/m;->M(La0/n;)La0/n;

    move-result-object v4

    iput-object v4, v0, La0/e1;->b:La0/n;

    :cond_21
    const/4 v4, 0x0

    .line 3
    iget-object v5, v0, La0/e1;->b:La0/n;

    const/4 v6, 0x0

    const-string v7, "valueVector"

    if-eqz v5, :cond_5e

    invoke-virtual {v5}, La0/n;->b()I

    move-result v5

    :goto_2d
    if-ge v4, v5, :cond_55

    .line 4
    iget-object v8, v0, La0/e1;->b:La0/n;

    if-eqz v8, :cond_51

    iget-object v9, v0, La0/e1;->a:La0/o;

    invoke-interface {v9, v4}, La0/o;->get(I)La0/z;

    move-result-object v10

    .line 5
    invoke-virtual {v1, v4}, La0/n;->a(I)F

    move-result v13

    .line 6
    invoke-virtual {v2, v4}, La0/n;->a(I)F

    move-result v14

    .line 7
    invoke-virtual {v3, v4}, La0/n;->a(I)F

    move-result v15

    move-wide/from16 v11, p1

    .line 8
    invoke-interface/range {v10 .. v15}, La0/z;->e(JFFF)F

    move-result v9

    invoke-virtual {v8, v4, v9}, La0/n;->e(IF)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_2d

    :cond_51
    invoke-static {v7}, Lp/h;->b0(Ljava/lang/String;)V

    throw v6

    .line 9
    :cond_55
    iget-object v1, v0, La0/e1;->b:La0/n;

    if-eqz v1, :cond_5a

    return-object v1

    :cond_5a
    invoke-static {v7}, Lp/h;->b0(Ljava/lang/String;)V

    throw v6

    .line 10
    :cond_5e
    invoke-static {v7}, Lp/h;->b0(Ljava/lang/String;)V

    throw v6
.end method
