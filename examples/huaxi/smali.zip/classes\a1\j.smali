.class public final La1/j;
.super Ljava/lang/Object;
.source "DrawModifier.kt"

# interfaces
.implements La1/a;


# static fields
.field public static final a:La1/j;

.field public static final b:J

.field public static final c:Lp2/j;

.field public static final d:Lp2/b;


# direct methods
.method public static constructor <clinit>()V
    .registers 2

    new-instance v0, La1/j;

    invoke-direct {v0}, La1/j;-><init>()V

    sput-object v0, La1/j;->a:La1/j;

    .line 1
    sget-object v0, Lc1/f;->b:Lc1/f$a;

    .line 2
    sget-wide v0, Lc1/f;->d:J

    .line 3
    sput-wide v0, La1/j;->b:J

    .line 4
    sget-object v0, Lp2/j;->a:Lp2/j;

    sput-object v0, La1/j;->c:Lp2/j;

    .line 5
    new-instance v0, Lp2/c;

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-direct {v0, v1, v1}, Lp2/c;-><init>(FF)V

    .line 6
    sput-object v0, La1/j;->d:Lp2/b;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public c()J
    .registers 3

    .line 1
    sget-wide v0, La1/j;->b:J

    return-wide v0
.end method

.method public getDensity()Lp2/b;
    .registers 2

    .line 1
    sget-object v0, La1/j;->d:Lp2/b;

    return-object v0
.end method

.method public getLayoutDirection()Lp2/j;
    .registers 2

    .line 1
    sget-object v0, La1/j;->c:Lp2/j;

    return-object v0
.end method
