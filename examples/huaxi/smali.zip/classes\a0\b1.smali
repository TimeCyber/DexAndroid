.class public interface abstract La0/b1;
.super Ljava/lang/Object;
.source "VectorizedDecayAnimationSpec.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<V:",
        "La0/n;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()F
.end method

.method public abstract b(JLa0/n;La0/n;)La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JTV;TV;)TV;"
        }
    .end annotation
.end method

.method public abstract c(La0/n;La0/n;)J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;TV;)J"
        }
    .end annotation
.end method

.method public abstract d(JLa0/n;La0/n;)La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JTV;TV;)TV;"
        }
    .end annotation
.end method

.method public abstract e(La0/n;La0/n;)La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;TV;)TV;"
        }
    .end annotation
.end method
