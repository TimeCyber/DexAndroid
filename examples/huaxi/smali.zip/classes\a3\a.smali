.class public La3/a;
.super Lc3/b;
.source "ActivityCompat.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La3/a$d;,
        La3/a$c;,
        La3/a$b;,
        La3/a$f;,
        La3/a$e;
    }
.end annotation


# static fields
.field public static final synthetic b:I


# direct methods
.method public static e(Landroid/app/Activity;[Ljava/lang/String;I)V
    .registers 6

    .line 1
    array-length v0, p1

    const/4 v1, 0x0

    :goto_2
    if-ge v1, v0, :cond_25

    aget-object v2, p1, v1

    .line 2
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_f

    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    .line 3
    :cond_f
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p2, "Permission request for permissions "

    invoke-static {p2}, Landroid/support/v4/media/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    .line 4
    invoke-static {p1}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const-string v0, " must not contain null or empty values"

    invoke-static {p2, p1, v0}, Lcom/huawei/hms/adapter/a;->a(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 5
    :cond_25
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x17

    if-lt v0, v1, :cond_39

    .line 6
    instance-of v0, p0, La3/a$f;

    if-eqz v0, :cond_35

    .line 7
    move-object v0, p0

    check-cast v0, La3/a$f;

    .line 8
    invoke-interface {v0, p2}, La3/a$f;->validateRequestPermissionsRequestCode(I)V

    .line 9
    :cond_35
    invoke-static {p0, p1, p2}, La3/a$d;->b(Landroid/app/Activity;[Ljava/lang/String;I)V

    goto :goto_4e

    .line 10
    :cond_39
    instance-of v0, p0, La3/a$e;

    if-eqz v0, :cond_4e

    .line 11
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 12
    new-instance v1, La3/a$a;

    invoke-direct {v1, p1, p0, p2}, La3/a$a;-><init>([Ljava/lang/String;Landroid/app/Activity;I)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_4e
    :goto_4e
    return-void
.end method
