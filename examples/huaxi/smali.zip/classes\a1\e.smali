.class public final La1/e;
.super Ljava/lang/Object;
.source "DrawModifier.kt"

# interfaces
.implements La1/d;


# instance fields
.field public final a:La1/b;

.field public final b:Lvg/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lvg/l<",
            "La1/b;",
            "La1/h;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(La1/b;Lvg/l;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La1/b;",
            "Lvg/l<",
            "-",
            "La1/b;",
            "La1/h;",
            ">;)V"
        }
    .end annotation

    const-string v0, "cacheDrawScope"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onBuildDrawCache"

    invoke-static {p2, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, La1/e;->a:La1/b;

    .line 3
    iput-object p2, p0, La1/e;->b:Lvg/l;

    return-void
.end method


# virtual methods
.method public K(Lf1/d;)V
    .registers 3

    .line 1
    iget-object v0, p0, La1/e;->a:La1/b;

    .line 2
    iget-object v0, v0, La1/b;->b:La1/h;

    .line 3
    invoke-static {v0}, Lp/h;->m(Ljava/lang/Object;)V

    .line 4
    iget-object v0, v0, La1/h;->a:Lvg/l;

    .line 5
    invoke-interface {v0, p1}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public synthetic Q(Ljava/lang/Object;Lvg/p;)Ljava/lang/Object;
    .registers 3

    invoke-static {p0, p1, p2}, Lv7/d;->b(Ly0/h$b;Ljava/lang/Object;Lvg/p;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    .line 1
    :cond_4
    instance-of v1, p1, La1/e;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    .line 2
    :cond_a
    iget-object v1, p0, La1/e;->a:La1/b;

    check-cast p1, La1/e;

    iget-object v3, p1, La1/e;->a:La1/b;

    invoke-static {v1, v3}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_17

    return v2

    .line 3
    :cond_17
    iget-object v1, p0, La1/e;->b:Lvg/l;

    iget-object p1, p1, La1/e;->b:Lvg/l;

    invoke-static {v1, p1}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_22

    return v2

    :cond_22
    return v0
.end method

.method public h0(La1/a;)V
    .registers 3

    const-string v0, "params"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object v0, p0, La1/e;->a:La1/b;

    .line 2
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 3
    iput-object p1, v0, La1/b;->a:La1/a;

    const/4 p1, 0x0

    .line 4
    iput-object p1, v0, La1/b;->b:La1/h;

    .line 5
    iget-object p1, p0, La1/e;->b:Lvg/l;

    invoke-interface {p1, v0}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    iget-object p1, v0, La1/b;->b:La1/h;

    if-eqz p1, :cond_19

    return-void

    .line 7
    :cond_19
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "DrawResult not defined, did you forget to call onDraw?"

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public hashCode()I
    .registers 3

    .line 1
    iget-object v0, p0, La1/e;->a:La1/b;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    .line 2
    iget-object v1, p0, La1/e;->b:Lvg/l;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    return v1
.end method

.method public synthetic p0(Ly0/h;)Ly0/h;
    .registers 2

    invoke-static {p0, p1}, Landroidx/fragment/app/n;->b(Ly0/h;Ly0/h;)Ly0/h;

    move-result-object p1

    return-object p1
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    const-string v0, "DrawContentCacheModifier(cacheDrawScope="

    invoke-static {v0}, Landroid/support/v4/media/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, La1/e;->a:La1/b;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", onBuildDrawCache="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, La1/e;->b:Lvg/l;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v1, 0x29

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public synthetic v0(Ljava/lang/Object;Lvg/p;)Ljava/lang/Object;
    .registers 3

    invoke-static {p0, p1, p2}, Lv7/d;->c(Ly0/h$b;Ljava/lang/Object;Lvg/p;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public synthetic x(Lvg/l;)Z
    .registers 2

    invoke-static {p0, p1}, Lv7/d;->a(Ly0/h$b;Lvg/l;)Z

    move-result p1

    return p1
.end method
