.class public final La0/x;
.super Ljava/lang/Object;
.source "Easing.kt"


# static fields
.field public static final a:La0/w;


# direct methods
.method public static constructor <clinit>()V
    .registers 5

    .line 1
    new-instance v0, La0/q;

    const v1, 0x3ecccccd    # 0.4f

    const/4 v2, 0x0

    const v3, 0x3e4ccccd    # 0.2f

    const/high16 v4, 0x3f800000    # 1.0f

    invoke-direct {v0, v1, v2, v3, v4}, La0/q;-><init>(FFFF)V

    sput-object v0, La0/x;->a:La0/w;

    return-void
.end method
