.class public final La0/m;
.super La0/n;
.source "AnimationVectors.kt"


# instance fields
.field public a:F

.field public b:F

.field public c:F

.field public d:F


# direct methods
.method public constructor <init>(FFFF)V
    .registers 6

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, La0/n;-><init>(Lwg/e;)V

    .line 2
    iput p1, p0, La0/m;->a:F

    .line 3
    iput p2, p0, La0/m;->b:F

    .line 4
    iput p3, p0, La0/m;->c:F

    .line 5
    iput p4, p0, La0/m;->d:F

    return-void
.end method


# virtual methods
.method public a(I)F
    .registers 3

    if-eqz p1, :cond_16

    const/4 v0, 0x1

    if-eq p1, v0, :cond_13

    const/4 v0, 0x2

    if-eq p1, v0, :cond_10

    const/4 v0, 0x3

    if-eq p1, v0, :cond_d

    const/4 p1, 0x0

    goto :goto_18

    .line 1
    :cond_d
    iget p1, p0, La0/m;->d:F

    goto :goto_18

    .line 2
    :cond_10
    iget p1, p0, La0/m;->c:F

    goto :goto_18

    .line 3
    :cond_13
    iget p1, p0, La0/m;->b:F

    goto :goto_18

    .line 4
    :cond_16
    iget p1, p0, La0/m;->a:F

    :goto_18
    return p1
.end method

.method public b()I
    .registers 2

    const/4 v0, 0x4

    return v0
.end method

.method public c()La0/n;
    .registers 3

    .line 1
    new-instance v0, La0/m;

    const/4 v1, 0x0

    invoke-direct {v0, v1, v1, v1, v1}, La0/m;-><init>(FFFF)V

    return-object v0
.end method

.method public d()V
    .registers 2

    const/4 v0, 0x0

    .line 1
    iput v0, p0, La0/m;->a:F

    .line 2
    iput v0, p0, La0/m;->b:F

    .line 3
    iput v0, p0, La0/m;->c:F

    .line 4
    iput v0, p0, La0/m;->d:F

    return-void
.end method

.method public e(IF)V
    .registers 4

    if-eqz p1, :cond_15

    const/4 v0, 0x1

    if-eq p1, v0, :cond_12

    const/4 v0, 0x2

    if-eq p1, v0, :cond_f

    const/4 v0, 0x3

    if-eq p1, v0, :cond_c

    goto :goto_17

    .line 1
    :cond_c
    iput p2, p0, La0/m;->d:F

    goto :goto_17

    .line 2
    :cond_f
    iput p2, p0, La0/m;->c:F

    goto :goto_17

    .line 3
    :cond_12
    iput p2, p0, La0/m;->b:F

    goto :goto_17

    .line 4
    :cond_15
    iput p2, p0, La0/m;->a:F

    :goto_17
    return-void
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    instance-of v0, p1, La0/m;

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_3d

    .line 2
    check-cast p1, La0/m;

    iget v0, p1, La0/m;->a:F

    iget v3, p0, La0/m;->a:F

    cmpg-float v0, v0, v3

    if-nez v0, :cond_12

    const/4 v0, 0x1

    goto :goto_13

    :cond_12
    const/4 v0, 0x0

    :goto_13
    if-eqz v0, :cond_3d

    .line 3
    iget v0, p1, La0/m;->b:F

    iget v3, p0, La0/m;->b:F

    cmpg-float v0, v0, v3

    if-nez v0, :cond_1f

    const/4 v0, 0x1

    goto :goto_20

    :cond_1f
    const/4 v0, 0x0

    :goto_20
    if-eqz v0, :cond_3d

    .line 4
    iget v0, p1, La0/m;->c:F

    iget v3, p0, La0/m;->c:F

    cmpg-float v0, v0, v3

    if-nez v0, :cond_2c

    const/4 v0, 0x1

    goto :goto_2d

    :cond_2c
    const/4 v0, 0x0

    :goto_2d
    if-eqz v0, :cond_3d

    .line 5
    iget p1, p1, La0/m;->d:F

    iget v0, p0, La0/m;->d:F

    cmpg-float p1, p1, v0

    if-nez p1, :cond_39

    const/4 p1, 0x1

    goto :goto_3a

    :cond_39
    const/4 p1, 0x0

    :goto_3a
    if-eqz p1, :cond_3d

    goto :goto_3e

    :cond_3d
    const/4 v1, 0x0

    :goto_3e
    return v1
.end method

.method public hashCode()I
    .registers 4

    .line 1
    iget v0, p0, La0/m;->a:F

    invoke-static {v0}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, La0/m;->b:F

    const/16 v2, 0x1f

    invoke-static {v1, v0, v2}, Lc0/a0;->c(FII)I

    move-result v0

    iget v1, p0, La0/m;->c:F

    invoke-static {v1, v0, v2}, Lc0/a0;->c(FII)I

    move-result v0

    iget v1, p0, La0/m;->d:F

    invoke-static {v1}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v1

    add-int/2addr v1, v0

    return v1
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    const-string v0, "AnimationVector4D: v1 = "

    .line 1
    invoke-static {v0}, Landroid/support/v4/media/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, La0/m;->a:F

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v1, ", v2 = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La0/m;->b:F

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v1, ", v3 = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La0/m;->c:F

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v1, ", v4 = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La0/m;->d:F

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
