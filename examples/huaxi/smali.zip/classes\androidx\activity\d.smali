.class public final synthetic Landroidx/activity/d;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .registers 3

    .line 1
    iput p2, p0, Landroidx/activity/d;->a:I

    iput-object p1, p0, Landroidx/activity/d;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 31

    move-object/from16 v1, p0

    iget v0, v1, Landroidx/activity/d;->a:I

    const/4 v2, 0x0

    .line 1
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/16 v6, 0x8

    const/4 v7, 0x1

    const/4 v8, 0x0

    packed-switch v0, :pswitch_data_81a

    goto/16 :goto_7de

    .line 2
    :pswitch_14
    iget-object v0, v1, Landroidx/activity/d;->b:Ljava/lang/Object;

    check-cast v0, Landroid/widget/EditText;

    sget v2, Linfo/cd120/two/ui/online/SearchActivity;->m:I

    const-string v2, "$input"

    .line 3
    invoke-static {v0, v2}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    invoke-static {v0}, La7/o;->c(Landroid/view/View;)V

    return-void

    .line 5
    :pswitch_23
    iget-object v0, v1, Landroidx/activity/d;->b:Ljava/lang/Object;

    check-cast v0, Linfo/cd120/two/ui/online/ChattingActivity;

    sget v3, Linfo/cd120/two/ui/online/ChattingActivity;->m:I

    const-string v3, "this$0"

    .line 6
    invoke-static {v0, v3}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 7
    invoke-virtual {v0}, Linfo/cd120/two/ui/online/ChattingActivity;->y()Lmf/v;

    move-result-object v0

    .line 8
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x1e

    if-lt v3, v4, :cond_3e

    .line 9
    iget-object v2, v0, Lmf/v;->b:Landroid/view/View;

    invoke-virtual {v2, v0}, Landroid/view/View;->setOnApplyWindowInsetsListener(Landroid/view/View$OnApplyWindowInsetsListener;)V

    goto :goto_68

    .line 10
    :cond_3e
    iget-object v3, v0, Lmf/v;->c:Landroid/widget/PopupWindow;

    invoke-virtual {v3}, Landroid/widget/PopupWindow;->isShowing()Z

    move-result v3

    if-nez v3, :cond_68

    iget-object v3, v0, Lmf/v;->d:Landroid/view/ViewGroup;

    invoke-virtual {v3}, Landroid/view/ViewGroup;->getWindowToken()Landroid/os/IBinder;

    move-result-object v3

    if-eqz v3, :cond_68

    .line 11
    iget-object v3, v0, Lmf/v;->c:Landroid/widget/PopupWindow;

    new-instance v4, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {v4, v2}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {v3, v4}, Landroid/widget/PopupWindow;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 12
    iget-object v3, v0, Lmf/v;->c:Landroid/widget/PopupWindow;

    iget-object v4, v0, Lmf/v;->d:Landroid/view/ViewGroup;

    invoke-virtual {v3, v4, v2, v2, v2}, Landroid/widget/PopupWindow;->showAtLocation(Landroid/view/View;III)V

    .line 13
    iget-object v2, v0, Lmf/v;->b:Landroid/view/View;

    invoke-virtual {v2}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v2

    invoke-virtual {v2, v0}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    :cond_68
    :goto_68
    return-void

    .line 14
    :pswitch_69
    iget-object v0, v1, Landroidx/activity/d;->b:Ljava/lang/Object;

    check-cast v0, Lue/x;

    sget v2, Lue/x;->i:I

    const-string v2, "this$0"

    .line 15
    invoke-static {v0, v2}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    invoke-virtual {v0}, Lue/x;->o()V

    return-void

    .line 17
    :pswitch_78
    iget-object v0, v1, Landroidx/activity/d;->b:Ljava/lang/Object;

    check-cast v0, Linfo/cd120/two/registration/doctor/ScheduleFragment;

    sget v2, Linfo/cd120/two/registration/doctor/ScheduleFragment;->m:I

    const-string v2, "this$0"

    .line 18
    invoke-static {v0, v2}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    invoke-virtual {v0}, Lxd/e;->c()Lq4/a;

    move-result-object v2

    check-cast v2, Linfo/cd120/two/registration/databinding/RegLibFragmentScheduleBinding;

    iget-object v2, v2, Linfo/cd120/two/registration/databinding/RegLibFragmentScheduleBinding;->u:Linfo/cd120/two/base/view/RecyclerView2;

    invoke-virtual {v0}, Lxd/e;->c()Lq4/a;

    move-result-object v3

    check-cast v3, Linfo/cd120/two/registration/databinding/RegLibFragmentScheduleBinding;

    .line 20
    iget-object v3, v3, Landroidx/databinding/ViewDataBinding;->e:Landroid/view/View;

    .line 21
    invoke-virtual {v3}, Landroid/view/View;->getMeasuredHeight()I

    move-result v3

    invoke-virtual {v0}, Lxd/e;->c()Lq4/a;

    move-result-object v0

    check-cast v0, Linfo/cd120/two/registration/databinding/RegLibFragmentScheduleBinding;

    iget-object v0, v0, Linfo/cd120/two/registration/databinding/RegLibFragmentScheduleBinding;->s:Landroid/widget/FrameLayout;

    invoke-virtual {v0}, Landroid/widget/FrameLayout;->getMeasuredHeight()I

    move-result v0

    sub-int/2addr v3, v0

    invoke-virtual {v2, v3}, Linfo/cd120/two/base/view/RecyclerView2;->setMaxHeight(I)V

    return-void

    .line 22
    :pswitch_a8
    iget-object v0, v1, Landroidx/activity/d;->b:Ljava/lang/Object;

    check-cast v0, Linfo/cd120/two/SplashActivity;

    const-string v3, "this$0"

    .line 23
    invoke-static {v0, v3}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    invoke-static {}, La7/r;->a()La7/r;

    move-result-object v3

    .line 25
    iget-object v3, v3, La7/r;->a:Landroid/content/SharedPreferences;

    const-string v5, "guide_activity_sp_key"

    invoke-interface {v3, v5, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v2

    if-nez v2, :cond_d6

    .line 26
    invoke-static {}, La7/r;->a()La7/r;

    move-result-object v2

    .line 27
    iget-object v2, v2, La7/r;->a:Landroid/content/SharedPreferences;

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2, v5, v7}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 28
    const-class v2, Linfo/cd120/two/GuideActivity;

    invoke-static {v0, v2, v8, v4}, Lee/k;->l(Landroid/app/Activity;Ljava/lang/Class;Landroid/os/Bundle;I)V

    goto :goto_db

    .line 29
    :cond_d6
    const-class v2, Linfo/cd120/two/MainActivity;

    invoke-static {v0, v2, v8, v4}, Lee/k;->l(Landroid/app/Activity;Ljava/lang/Class;Landroid/os/Bundle;I)V

    :goto_db
    return-void

    .line 30
    :pswitch_dc
    iget-object v0, v1, Landroidx/activity/d;->b:Ljava/lang/Object;

    check-cast v0, Le4/n;

    .line 31
    iget-object v2, v0, Le4/n;->a:Le4/p$d;

    iget-object v3, v0, Le4/n;->b:Ljava/lang/String;

    iget-object v0, v0, Le4/n;->c:Ljava/util/List;

    invoke-interface {v2, v3, v0}, Le4/p$d;->a(Ljava/lang/String;Ljava/util/List;)V

    return-void

    .line 32
    :pswitch_ea
    iget-object v0, v1, Landroidx/activity/d;->b:Ljava/lang/Object;

    check-cast v0, Le4/l;

    .line 33
    iget-object v0, v0, Le4/l;->a:Le4/p$d;

    .line 34
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v2

    const-string v3, "TRANSACTION SUCCESSFUL"

    .line 35
    invoke-interface {v0, v3, v2}, Le4/p$d;->a(Ljava/lang/String;Ljava/util/List;)V

    return-void

    .line 36
    :pswitch_fa
    iget-object v0, v1, Landroidx/activity/d;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/emoji2/text/k$b;

    invoke-virtual {v0}, Landroidx/emoji2/text/k$b;->c()V

    return-void

    :pswitch_102
    iget-object v0, v1, Landroidx/activity/d;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/core/widget/ContentLoadingProgressBar;

    sget v2, Landroidx/core/widget/ContentLoadingProgressBar;->c:I

    .line 37
    invoke-virtual {v0, v6}, Landroid/widget/ProgressBar;->setVisibility(I)V

    return-void

    .line 38
    :pswitch_10c
    iget-object v0, v1, Landroidx/activity/d;->b:Ljava/lang/Object;

    move-object v9, v0

    check-cast v9, Landroid/app/Activity;

    sget v0, La3/a;->b:I

    .line 39
    invoke-virtual {v9}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_1aa

    sget-object v0, La3/f;->a:Ljava/lang/Class;

    .line 40
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v10, 0x1c

    if-lt v0, v10, :cond_126

    .line 41
    invoke-virtual {v9}, Landroid/app/Activity;->recreate()V

    goto/16 :goto_196

    .line 42
    :cond_126
    invoke-static {}, La3/f;->a()Z

    move-result v0

    if-eqz v0, :cond_132

    sget-object v0, La3/f;->f:Ljava/lang/reflect/Method;

    if-nez v0, :cond_132

    goto/16 :goto_1a5

    .line 43
    :cond_132
    sget-object v0, La3/f;->e:Ljava/lang/reflect/Method;

    if-nez v0, :cond_13b

    sget-object v0, La3/f;->d:Ljava/lang/reflect/Method;

    if-nez v0, :cond_13b

    goto :goto_1a5

    .line 44
    :cond_13b
    :try_start_13b
    sget-object v0, La3/f;->c:Ljava/lang/reflect/Field;

    invoke-virtual {v0, v9}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_144

    goto :goto_1a5

    .line 45
    :cond_144
    sget-object v10, La3/f;->b:Ljava/lang/reflect/Field;

    invoke-virtual {v10, v9}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    if-nez v10, :cond_14d

    goto :goto_1a5

    .line 46
    :cond_14d
    invoke-virtual {v9}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v11

    .line 47
    new-instance v12, La3/f$a;

    invoke-direct {v12, v9}, La3/f$a;-><init>(Landroid/app/Activity;)V

    .line 48
    invoke-virtual {v11, v12}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    .line 49
    sget-object v13, La3/f;->g:Landroid/os/Handler;

    new-instance v14, La3/c;

    invoke-direct {v14, v12, v0}, La3/c;-><init>(La3/f$a;Ljava/lang/Object;)V

    invoke-virtual {v13, v14}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_163
    .catchall {:try_start_13b .. :try_end_163} :catchall_1a4

    .line 50
    :try_start_163
    invoke-static {}, La3/f;->a()Z

    move-result v14

    if-eqz v14, :cond_18b

    .line 51
    sget-object v14, La3/f;->f:Ljava/lang/reflect/Method;

    const/16 v15, 0x9

    new-array v15, v15, [Ljava/lang/Object;

    aput-object v0, v15, v2

    aput-object v8, v15, v7

    aput-object v8, v15, v4

    const/4 v0, 0x3

    aput-object v3, v15, v0

    .line 52
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    aput-object v0, v15, v5

    const/4 v3, 0x5

    aput-object v8, v15, v3

    const/4 v3, 0x6

    aput-object v8, v15, v3

    const/4 v3, 0x7

    aput-object v0, v15, v3

    aput-object v0, v15, v6

    .line 53
    invoke-virtual {v14, v10, v15}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_18e

    .line 54
    :cond_18b
    invoke-virtual {v9}, Landroid/app/Activity;->recreate()V
    :try_end_18e
    .catchall {:try_start_163 .. :try_end_18e} :catchall_198

    .line 55
    :goto_18e
    :try_start_18e
    new-instance v0, La3/d;

    invoke-direct {v0, v11, v12}, La3/d;-><init>(Landroid/app/Application;La3/f$a;)V

    invoke-virtual {v13, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :goto_196
    const/4 v2, 0x1

    goto :goto_1a5

    :catchall_198
    move-exception v0

    sget-object v3, La3/f;->g:Landroid/os/Handler;

    new-instance v4, La3/d;

    invoke-direct {v4, v11, v12}, La3/d;-><init>(Landroid/app/Application;La3/f$a;)V

    invoke-virtual {v3, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 56
    throw v0
    :try_end_1a4
    .catchall {:try_start_18e .. :try_end_1a4} :catchall_1a4

    :catchall_1a4
    nop

    :goto_1a5
    if-nez v2, :cond_1aa

    .line 57
    invoke-virtual {v9}, Landroid/app/Activity;->recreate()V

    :cond_1aa
    return-void

    .line 58
    :pswitch_1ab
    iget-object v0, v1, Landroidx/activity/d;->b:Ljava/lang/Object;

    check-cast v0, Lvg/a;

    const-string v2, "$tmp0"

    .line 59
    invoke-static {v0, v2}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 60
    invoke-interface {v0}, Lvg/a;->invoke()Ljava/lang/Object;

    return-void

    .line 61
    :pswitch_1b8
    iget-object v0, v1, Landroidx/activity/d;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/compose/ui/platform/p;

    sget-object v4, Landroidx/compose/ui/platform/p;->z:[I

    const-string v4, "this$0"

    .line 62
    invoke-static {v0, v4}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 63
    iget-object v4, v0, Landroidx/compose/ui/platform/p;->d:Landroidx/compose/ui/platform/AndroidComposeView;

    invoke-static {v4, v2, v7, v8}, Lt1/a0;->a(Lt1/b0;ZILjava/lang/Object;)V

    .line 64
    iget-object v2, v0, Landroidx/compose/ui/platform/p;->d:Landroidx/compose/ui/platform/AndroidComposeView;

    invoke-virtual {v2}, Landroidx/compose/ui/platform/AndroidComposeView;->getSemanticsOwner()Lx1/s;

    move-result-object v2

    invoke-virtual {v2}, Lx1/s;->a()Lx1/r;

    move-result-object v2

    .line 65
    iget-object v4, v0, Landroidx/compose/ui/platform/p;->u:Landroidx/compose/ui/platform/p$f;

    .line 66
    invoke-virtual {v0, v2, v4}, Landroidx/compose/ui/platform/p;->F(Lx1/r;Landroidx/compose/ui/platform/p$f;)V

    .line 67
    invoke-virtual {v0}, Landroidx/compose/ui/platform/p;->p()Ljava/util/Map;

    move-result-object v2

    const-string v4, "newSemanticsNodes"

    .line 68
    invoke-static {v2, v4}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 69
    new-instance v4, Ljava/util/ArrayList;

    iget-object v5, v0, Landroidx/compose/ui/platform/p;->x:Ljava/util/List;

    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 70
    iget-object v5, v0, Landroidx/compose/ui/platform/p;->x:Ljava/util/List;

    invoke-interface {v5}, Ljava/util/List;->clear()V

    .line 71
    invoke-interface {v2}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_1f4
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_67d

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Number;

    invoke-virtual {v7}, Ljava/lang/Number;->intValue()I

    move-result v7

    .line 72
    iget-object v9, v0, Landroidx/compose/ui/platform/p;->t:Ljava/util/Map;

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-interface {v9, v10}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    move-object v15, v9

    check-cast v15, Landroidx/compose/ui/platform/p$f;

    if-nez v15, :cond_214

    goto :goto_1f4

    .line 73
    :cond_214
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-interface {v2, v9}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Landroidx/compose/ui/platform/q1;

    if-eqz v9, :cond_224

    .line 74
    iget-object v9, v9, Landroidx/compose/ui/platform/q1;->a:Lx1/r;

    move-object v14, v9

    goto :goto_225

    :cond_224
    move-object v14, v8

    .line 75
    :goto_225
    invoke-static {v14}, Lp/h;->m(Ljava/lang/Object;)V

    .line 76
    iget-object v9, v14, Lx1/r;->e:Lx1/k;

    .line 77
    invoke-virtual {v9}, Lx1/k;->iterator()Ljava/util/Iterator;

    move-result-object v16

    const/4 v9, 0x0

    const/16 v17, 0x0

    :goto_231
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    const/16 v13, 0x800

    if-eqz v9, :cond_639

    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    move-object/from16 v18, v9

    check-cast v18, Ljava/util/Map$Entry;

    .line 78
    invoke-interface/range {v18 .. v18}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v9

    sget-object v10, Lx1/t;->a:Lx1/t;

    .line 79
    sget-object v12, Lx1/t;->n:Lx1/y;

    .line 80
    invoke-static {v9, v12}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_265

    .line 81
    invoke-interface/range {v18 .. v18}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v9

    .line 82
    sget-object v10, Lx1/t;->o:Lx1/y;

    .line 83
    invoke-static {v9, v10}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_25c

    goto :goto_265

    :cond_25c
    const/4 v9, 0x0

    move-object/from16 v21, v2

    move-object/from16 v24, v12

    move-object/from16 v20, v14

    move-object v2, v15

    goto :goto_29f

    .line 84
    :cond_265
    :goto_265
    invoke-static {v4, v7}, Landroidx/compose/ui/platform/q;->g(Ljava/util/List;I)Landroidx/compose/ui/platform/p1;

    move-result-object v9

    if-eqz v9, :cond_274

    const/4 v10, 0x0

    move-object/from16 v21, v2

    move-object/from16 v24, v12

    move-object/from16 v20, v14

    move-object v2, v15

    goto :goto_299

    .line 85
    :cond_274
    new-instance v19, Landroidx/compose/ui/platform/p1;

    .line 86
    iget-object v11, v0, Landroidx/compose/ui/platform/p;->x:Ljava/util/List;

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    move-object/from16 v9, v19

    move v10, v7

    move-object/from16 v24, v12

    move-object/from16 v12, v20

    move-object/from16 v13, v21

    move-object/from16 v20, v14

    move-object/from16 v14, v22

    move-object/from16 v21, v2

    move-object v2, v15

    move-object/from16 v15, v23

    .line 87
    invoke-direct/range {v9 .. v15}, Landroidx/compose/ui/platform/p1;-><init>(ILjava/util/List;Ljava/lang/Float;Ljava/lang/Float;Lx1/i;Lx1/i;)V

    const/4 v9, 0x1

    move-object/from16 v9, v19

    const/4 v10, 0x1

    .line 88
    :goto_299
    iget-object v11, v0, Landroidx/compose/ui/platform/p;->x:Ljava/util/List;

    invoke-interface {v11, v9}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move v9, v10

    :goto_29f
    if-nez v9, :cond_2b8

    .line 89
    invoke-interface/range {v18 .. v18}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v9

    .line 90
    iget-object v10, v2, Landroidx/compose/ui/platform/p$f;->a:Lx1/k;

    .line 91
    invoke-interface/range {v18 .. v18}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lx1/y;

    invoke-static {v10, v11}, Lmb/b;->d(Lx1/k;Lx1/y;)Ljava/lang/Object;

    move-result-object v10

    invoke-static {v9, v10}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_2b8

    goto :goto_2dc

    .line 92
    :cond_2b8
    invoke-interface/range {v18 .. v18}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lx1/y;

    .line 93
    sget-object v10, Lx1/t;->e:Lx1/y;

    .line 94
    invoke-static {v9, v10}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_2e0

    .line 95
    invoke-interface/range {v18 .. v18}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v8

    const-string v9, "null cannot be cast to non-null type kotlin.String"

    invoke-static {v8, v9}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    check-cast v8, Ljava/lang/String;

    .line 96
    iget-object v9, v2, Landroidx/compose/ui/platform/p$f;->a:Lx1/k;

    invoke-virtual {v9, v10}, Lx1/k;->d(Lx1/y;)Z

    move-result v9

    if-eqz v9, :cond_2dc

    .line 97
    invoke-virtual {v0, v7, v6, v8}, Landroidx/compose/ui/platform/p;->C(IILjava/lang/String;)V

    :cond_2dc
    :goto_2dc
    move-object/from16 v15, v20

    goto/16 :goto_402

    .line 98
    :cond_2e0
    sget-object v6, Lx1/t;->c:Lx1/y;

    .line 99
    invoke-static {v9, v6}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_2ea

    const/4 v6, 0x1

    goto :goto_2f0

    .line 100
    :cond_2ea
    sget-object v6, Lx1/t;->x:Lx1/y;

    .line 101
    invoke-static {v9, v6}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    :goto_2f0
    const/16 v10, 0x40

    if-eqz v6, :cond_309

    .line 102
    invoke-virtual {v0, v7}, Landroidx/compose/ui/platform/p;->y(I)I

    move-result v6

    .line 103
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    const/16 v11, 0x800

    .line 104
    invoke-virtual {v0, v6, v11, v9, v8}, Landroidx/compose/ui/platform/p;->A(IILjava/lang/Integer;Ljava/util/List;)Z

    .line 105
    invoke-virtual {v0, v7}, Landroidx/compose/ui/platform/p;->y(I)I

    move-result v6

    .line 106
    invoke-virtual {v0, v6, v11, v3, v8}, Landroidx/compose/ui/platform/p;->A(IILjava/lang/Integer;Ljava/util/List;)Z

    goto :goto_2dc

    :cond_309
    const/16 v11, 0x800

    .line 107
    sget-object v6, Lx1/t;->d:Lx1/y;

    .line 108
    invoke-static {v9, v6}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_326

    .line 109
    invoke-virtual {v0, v7}, Landroidx/compose/ui/platform/p;->y(I)I

    move-result v6

    .line 110
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    .line 111
    invoke-virtual {v0, v6, v11, v9, v8}, Landroidx/compose/ui/platform/p;->A(IILjava/lang/Integer;Ljava/util/List;)Z

    .line 112
    invoke-virtual {v0, v7}, Landroidx/compose/ui/platform/p;->y(I)I

    move-result v6

    .line 113
    invoke-virtual {v0, v6, v11, v3, v8}, Landroidx/compose/ui/platform/p;->A(IILjava/lang/Integer;Ljava/util/List;)Z

    goto :goto_2dc

    .line 114
    :cond_326
    sget-object v6, Lx1/t;->w:Lx1/y;

    .line 115
    invoke-static {v9, v6}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_3e1

    .line 116
    invoke-virtual/range {v20 .. v20}, Lx1/r;->f()Lx1/k;

    move-result-object v9

    .line 117
    sget-object v12, Lx1/t;->q:Lx1/y;

    .line 118
    invoke-static {v9, v12}, Lmb/b;->d(Lx1/k;Lx1/y;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lx1/h;

    if-nez v9, :cond_33f

    const/4 v9, 0x0

    const/4 v12, 0x4

    goto :goto_346

    .line 119
    :cond_33f
    iget v9, v9, Lx1/h;->a:I

    const/4 v12, 0x4

    .line 120
    invoke-static {v9, v12}, Lx1/h;->a(II)Z

    move-result v9

    :goto_346
    if-eqz v9, :cond_3cc

    .line 121
    invoke-virtual/range {v20 .. v20}, Lx1/r;->f()Lx1/k;

    move-result-object v9

    invoke-static {v9, v6}, Lmb/b;->d(Lx1/k;Lx1/y;)Ljava/lang/Object;

    move-result-object v6

    sget-object v9, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {v6, v9}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3c2

    .line 122
    invoke-virtual {v0, v7}, Landroidx/compose/ui/platform/p;->y(I)I

    move-result v6

    .line 123
    invoke-virtual {v0, v6, v12}, Landroidx/compose/ui/platform/p;->l(II)Landroid/view/accessibility/AccessibilityEvent;

    move-result-object v6

    .line 124
    new-instance v9, Lx1/r;

    move-object/from16 v15, v20

    .line 125
    iget-object v10, v15, Lx1/r;->a:Lx1/l;

    const/4 v11, 0x1

    .line 126
    invoke-direct {v9, v10, v11}, Lx1/r;-><init>(Lx1/l;Z)V

    .line 127
    invoke-virtual {v9}, Lx1/r;->f()Lx1/k;

    move-result-object v10

    .line 128
    sget-object v11, Lx1/t;->b:Lx1/y;

    .line 129
    invoke-static {v10, v11}, Lmb/b;->d(Lx1/k;Lx1/y;)Ljava/lang/Object;

    move-result-object v10

    move-object/from16 v22, v10

    check-cast v22, Ljava/util/List;

    if-eqz v22, :cond_38d

    const/16 v24, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x3e

    const-string v23, ","

    .line 130
    invoke-static/range {v22 .. v29}, La6/d;->n(Ljava/util/List;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lvg/l;I)Ljava/lang/String;

    move-result-object v10

    goto :goto_38e

    :cond_38d
    move-object v10, v8

    .line 131
    :goto_38e
    invoke-virtual {v9}, Lx1/r;->f()Lx1/k;

    move-result-object v9

    .line 132
    sget-object v11, Lx1/t;->s:Lx1/y;

    .line 133
    invoke-static {v9, v11}, Lmb/b;->d(Lx1/k;Lx1/y;)Ljava/lang/Object;

    move-result-object v9

    move-object/from16 v22, v9

    check-cast v22, Ljava/util/List;

    if-eqz v22, :cond_3b0

    const/16 v24, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x3e

    const-string v23, ","

    .line 134
    invoke-static/range {v22 .. v29}, La6/d;->n(Ljava/util/List;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lvg/l;I)Ljava/lang/String;

    move-result-object v8

    :cond_3b0
    if-eqz v10, :cond_3b5

    .line 135
    invoke-virtual {v6, v10}, Landroid/view/accessibility/AccessibilityEvent;->setContentDescription(Ljava/lang/CharSequence;)V

    :cond_3b5
    if-eqz v8, :cond_3be

    .line 136
    invoke-virtual {v6}, Landroid/view/accessibility/AccessibilityEvent;->getText()Ljava/util/List;

    move-result-object v9

    invoke-interface {v9, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 137
    :cond_3be
    invoke-virtual {v0, v6}, Landroidx/compose/ui/platform/p;->z(Landroid/view/accessibility/AccessibilityEvent;)Z

    goto :goto_402

    :cond_3c2
    move-object/from16 v15, v20

    .line 138
    invoke-virtual {v0, v7}, Landroidx/compose/ui/platform/p;->y(I)I

    move-result v6

    .line 139
    invoke-virtual {v0, v6, v11, v3, v8}, Landroidx/compose/ui/platform/p;->A(IILjava/lang/Integer;Ljava/util/List;)Z

    goto :goto_402

    :cond_3cc
    move-object/from16 v15, v20

    .line 140
    invoke-virtual {v0, v7}, Landroidx/compose/ui/platform/p;->y(I)I

    move-result v6

    .line 141
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    .line 142
    invoke-virtual {v0, v6, v11, v9, v8}, Landroidx/compose/ui/platform/p;->A(IILjava/lang/Integer;Ljava/util/List;)Z

    .line 143
    invoke-virtual {v0, v7}, Landroidx/compose/ui/platform/p;->y(I)I

    move-result v6

    .line 144
    invoke-virtual {v0, v6, v11, v3, v8}, Landroidx/compose/ui/platform/p;->A(IILjava/lang/Integer;Ljava/util/List;)Z

    goto :goto_402

    :cond_3e1
    move-object/from16 v15, v20

    .line 145
    sget-object v6, Lx1/t;->b:Lx1/y;

    .line 146
    invoke-static {v9, v6}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_406

    .line 147
    invoke-virtual {v0, v7}, Landroidx/compose/ui/platform/p;->y(I)I

    move-result v6

    const/4 v8, 0x4

    .line 148
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    .line 149
    invoke-interface/range {v18 .. v18}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v9

    const-string v10, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>"

    invoke-static {v9, v10}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    check-cast v9, Ljava/util/List;

    .line 150
    invoke-virtual {v0, v6, v11, v8, v9}, Landroidx/compose/ui/platform/p;->A(IILjava/lang/Integer;Ljava/util/List;)Z

    :goto_402
    move-object/from16 v19, v4

    goto/16 :goto_62e

    .line 151
    :cond_406
    sget-object v6, Lx1/t;->t:Lx1/y;

    .line 152
    invoke-static {v9, v6}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    const-string v8, ""

    if-eqz v6, :cond_4ab

    .line 153
    iget-object v6, v15, Lx1/r;->e:Lx1/k;

    .line 154
    sget-object v9, Lx1/j;->a:Lx1/j;

    .line 155
    sget-object v9, Lx1/j;->h:Lx1/y;

    .line 156
    invoke-virtual {v6, v9}, Lx1/k;->d(Lx1/y;)Z

    move-result v6

    if-eqz v6, :cond_49a

    .line 157
    iget-object v6, v2, Landroidx/compose/ui/platform/p$f;->a:Lx1/k;

    .line 158
    invoke-virtual {v0, v6}, Landroidx/compose/ui/platform/p;->r(Lx1/k;)Lz1/a;

    move-result-object v6

    if-eqz v6, :cond_425

    goto :goto_426

    :cond_425
    move-object v6, v8

    .line 159
    :goto_426
    iget-object v9, v15, Lx1/r;->e:Lx1/k;

    .line 160
    invoke-virtual {v0, v9}, Landroidx/compose/ui/platform/p;->r(Lx1/k;)Lz1/a;

    move-result-object v9

    if-eqz v9, :cond_42f

    move-object v8, v9

    .line 161
    :cond_42f
    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    move-result v9

    .line 162
    invoke-interface {v8}, Ljava/lang/CharSequence;->length()I

    move-result v10

    if-le v9, v10, :cond_43b

    move v11, v10

    goto :goto_43c

    :cond_43b
    move v11, v9

    :goto_43c
    const/4 v12, 0x0

    :goto_43d
    if-ge v12, v11, :cond_44d

    .line 163
    invoke-interface {v6, v12}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v13

    invoke-interface {v8, v12}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v14

    if-eq v13, v14, :cond_44a

    goto :goto_44d

    :cond_44a
    add-int/lit8 v12, v12, 0x1

    goto :goto_43d

    :cond_44d
    :goto_44d
    const/4 v13, 0x0

    :goto_44e
    sub-int v14, v11, v12

    if-ge v13, v14, :cond_46b

    add-int/lit8 v14, v9, -0x1

    sub-int/2addr v14, v13

    .line 164
    invoke-interface {v6, v14}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v14

    add-int/lit8 v18, v10, -0x1

    move-object/from16 v19, v4

    sub-int v4, v18, v13

    .line 165
    invoke-interface {v8, v4}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v4

    if-eq v14, v4, :cond_466

    goto :goto_46d

    :cond_466
    add-int/lit8 v13, v13, 0x1

    move-object/from16 v4, v19

    goto :goto_44e

    :cond_46b
    move-object/from16 v19, v4

    :goto_46d
    sub-int/2addr v9, v13

    sub-int/2addr v9, v12

    sub-int/2addr v10, v13

    sub-int/2addr v10, v12

    .line 166
    invoke-virtual {v0, v7}, Landroidx/compose/ui/platform/p;->y(I)I

    move-result v4

    const/16 v11, 0x10

    .line 167
    invoke-virtual {v0, v4, v11}, Landroidx/compose/ui/platform/p;->l(II)Landroid/view/accessibility/AccessibilityEvent;

    move-result-object v4

    .line 168
    invoke-virtual {v4, v12}, Landroid/view/accessibility/AccessibilityEvent;->setFromIndex(I)V

    .line 169
    invoke-virtual {v4, v9}, Landroid/view/accessibility/AccessibilityEvent;->setRemovedCount(I)V

    .line 170
    invoke-virtual {v4, v10}, Landroid/view/accessibility/AccessibilityEvent;->setAddedCount(I)V

    .line 171
    invoke-virtual {v4, v6}, Landroid/view/accessibility/AccessibilityEvent;->setBeforeText(Ljava/lang/CharSequence;)V

    .line 172
    invoke-virtual {v4}, Landroid/view/accessibility/AccessibilityEvent;->getText()Ljava/util/List;

    move-result-object v6

    const v9, 0x186a0

    invoke-virtual {v0, v8, v9}, Landroidx/compose/ui/platform/p;->I(Ljava/lang/CharSequence;I)Ljava/lang/CharSequence;

    move-result-object v8

    invoke-interface {v6, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 173
    invoke-virtual {v0, v4}, Landroidx/compose/ui/platform/p;->z(Landroid/view/accessibility/AccessibilityEvent;)Z

    goto/16 :goto_62e

    :cond_49a
    move-object/from16 v19, v4

    .line 174
    invoke-virtual {v0, v7}, Landroidx/compose/ui/platform/p;->y(I)I

    move-result v4

    const/4 v6, 0x2

    .line 175
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const/4 v8, 0x0

    .line 176
    invoke-virtual {v0, v4, v11, v6, v8}, Landroidx/compose/ui/platform/p;->A(IILjava/lang/Integer;Ljava/util/List;)Z

    goto/16 :goto_62e

    :cond_4ab
    move-object/from16 v19, v4

    .line 177
    sget-object v4, Lx1/t;->u:Lx1/y;

    .line 178
    invoke-static {v9, v4}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_503

    .line 179
    iget-object v6, v15, Lx1/r;->e:Lx1/k;

    .line 180
    invoke-virtual {v0, v6}, Landroidx/compose/ui/platform/p;->r(Lx1/k;)Lz1/a;

    move-result-object v6

    if-eqz v6, :cond_4c3

    .line 181
    iget-object v6, v6, Lz1/a;->a:Ljava/lang/String;

    if-nez v6, :cond_4c2

    goto :goto_4c3

    :cond_4c2
    move-object v8, v6

    .line 182
    :cond_4c3
    :goto_4c3
    iget-object v6, v15, Lx1/r;->e:Lx1/k;

    .line 183
    invoke-virtual {v6, v4}, Lx1/k;->e(Lx1/y;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lz1/s;

    .line 184
    iget-wide v9, v4, Lz1/s;->a:J

    .line 185
    invoke-virtual {v0, v7}, Landroidx/compose/ui/platform/p;->y(I)I

    move-result v4

    .line 186
    invoke-static {v9, v10}, Lz1/s;->i(J)I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    .line 187
    invoke-static {v9, v10}, Lz1/s;->d(J)I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    .line 188
    invoke-virtual {v8}, Ljava/lang/String;->length()I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    const v6, 0x186a0

    .line 189
    invoke-virtual {v0, v8, v6}, Landroidx/compose/ui/platform/p;->I(Ljava/lang/CharSequence;I)Ljava/lang/CharSequence;

    move-result-object v6

    move-object v14, v6

    check-cast v14, Ljava/lang/String;

    move-object v9, v0

    move v10, v4

    .line 190
    invoke-virtual/range {v9 .. v14}, Landroidx/compose/ui/platform/p;->m(ILjava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/String;)Landroid/view/accessibility/AccessibilityEvent;

    move-result-object v4

    .line 191
    invoke-virtual {v0, v4}, Landroidx/compose/ui/platform/p;->z(Landroid/view/accessibility/AccessibilityEvent;)Z

    .line 192
    iget v4, v15, Lx1/r;->f:I

    .line 193
    invoke-virtual {v0, v4}, Landroidx/compose/ui/platform/p;->D(I)V

    goto/16 :goto_62e

    :cond_503
    move-object/from16 v4, v24

    .line 194
    invoke-static {v9, v4}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_50d

    const/4 v6, 0x1

    goto :goto_513

    .line 195
    :cond_50d
    sget-object v6, Lx1/t;->o:Lx1/y;

    .line 196
    invoke-static {v9, v6}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    :goto_513
    if-eqz v6, :cond_53e

    .line 197
    iget-object v6, v15, Lx1/r;->g:Lt1/h;

    .line 198
    invoke-virtual {v0, v6}, Landroidx/compose/ui/platform/p;->t(Lt1/h;)V

    .line 199
    iget-object v6, v0, Landroidx/compose/ui/platform/p;->x:Ljava/util/List;

    invoke-static {v6, v7}, Landroidx/compose/ui/platform/q;->g(Ljava/util/List;I)Landroidx/compose/ui/platform/p1;

    move-result-object v6

    invoke-static {v6}, Lp/h;->m(Ljava/lang/Object;)V

    .line 200
    iget-object v8, v15, Lx1/r;->e:Lx1/k;

    .line 201
    invoke-static {v8, v4}, Lmb/b;->d(Lx1/k;Lx1/y;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lx1/i;

    .line 202
    iput-object v4, v6, Landroidx/compose/ui/platform/p1;->e:Lx1/i;

    .line 203
    iget-object v4, v15, Lx1/r;->e:Lx1/k;

    .line 204
    sget-object v8, Lx1/t;->o:Lx1/y;

    .line 205
    invoke-static {v4, v8}, Lmb/b;->d(Lx1/k;Lx1/y;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lx1/i;

    .line 206
    iput-object v4, v6, Landroidx/compose/ui/platform/p1;->f:Lx1/i;

    .line 207
    invoke-virtual {v0, v6}, Landroidx/compose/ui/platform/p;->E(Landroidx/compose/ui/platform/p1;)V

    goto/16 :goto_62e

    .line 208
    :cond_53e
    sget-object v4, Lx1/t;->l:Lx1/y;

    .line 209
    invoke-static {v9, v4}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_572

    .line 210
    invoke-interface/range {v18 .. v18}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    const-string v6, "null cannot be cast to non-null type kotlin.Boolean"

    invoke-static {v4, v6}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    check-cast v4, Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-eqz v4, :cond_566

    .line 211
    iget v4, v15, Lx1/r;->f:I

    .line 212
    invoke-virtual {v0, v4}, Landroidx/compose/ui/platform/p;->y(I)I

    move-result v4

    const/16 v6, 0x8

    .line 213
    invoke-virtual {v0, v4, v6}, Landroidx/compose/ui/platform/p;->l(II)Landroid/view/accessibility/AccessibilityEvent;

    move-result-object v4

    .line 214
    invoke-virtual {v0, v4}, Landroidx/compose/ui/platform/p;->z(Landroid/view/accessibility/AccessibilityEvent;)Z

    .line 215
    :cond_566
    iget v4, v15, Lx1/r;->f:I

    .line 216
    invoke-virtual {v0, v4}, Landroidx/compose/ui/platform/p;->y(I)I

    move-result v4

    const/4 v6, 0x0

    .line 217
    invoke-virtual {v0, v4, v11, v3, v6}, Landroidx/compose/ui/platform/p;->A(IILjava/lang/Integer;Ljava/util/List;)Z

    goto/16 :goto_62e

    .line 218
    :cond_572
    sget-object v4, Lx1/j;->a:Lx1/j;

    .line 219
    sget-object v4, Lx1/j;->p:Lx1/y;

    .line 220
    invoke-static {v9, v4}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_5e0

    .line 221
    iget-object v6, v15, Lx1/r;->e:Lx1/k;

    .line 222
    invoke-virtual {v6, v4}, Lx1/k;->e(Lx1/y;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/util/List;

    .line 223
    iget-object v8, v2, Landroidx/compose/ui/platform/p$f;->a:Lx1/k;

    .line 224
    invoke-static {v8, v4}, Lmb/b;->d(Lx1/k;Lx1/y;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/List;

    if-eqz v4, :cond_5d7

    .line 225
    new-instance v8, Ljava/util/LinkedHashSet;

    invoke-direct {v8}, Ljava/util/LinkedHashSet;-><init>()V

    .line 226
    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v9

    const/4 v10, 0x0

    :goto_598
    if-ge v10, v9, :cond_5aa

    .line 227
    invoke-interface {v6, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    .line 228
    check-cast v11, Lx1/d;

    .line 229
    invoke-static {v11}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x0

    invoke-interface {v8, v11}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    add-int/lit8 v10, v10, 0x1

    goto :goto_598

    .line 230
    :cond_5aa
    new-instance v6, Ljava/util/LinkedHashSet;

    invoke-direct {v6}, Ljava/util/LinkedHashSet;-><init>()V

    .line 231
    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v9

    const/4 v10, 0x0

    :goto_5b4
    if-ge v10, v9, :cond_5c6

    .line 232
    invoke-interface {v4, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    .line 233
    check-cast v11, Lx1/d;

    .line 234
    invoke-static {v11}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x0

    invoke-interface {v6, v11}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    add-int/lit8 v10, v10, 0x1

    goto :goto_5b4

    .line 235
    :cond_5c6
    invoke-interface {v8, v6}, Ljava/util/Set;->containsAll(Ljava/util/Collection;)Z

    move-result v4

    if-eqz v4, :cond_62b

    invoke-interface {v6, v8}, Ljava/util/Set;->containsAll(Ljava/util/Collection;)Z

    move-result v4

    if-nez v4, :cond_5d3

    goto :goto_62b

    :cond_5d3
    const/4 v4, 0x0

    const/16 v17, 0x0

    goto :goto_62e

    .line 236
    :cond_5d7
    invoke-interface {v6}, Ljava/util/Collection;->isEmpty()Z

    move-result v4

    xor-int/lit8 v4, v4, 0x1

    if-eqz v4, :cond_62e

    goto :goto_62b

    .line 237
    :cond_5e0
    invoke-interface/range {v18 .. v18}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    instance-of v4, v4, Lx1/a;

    if-eqz v4, :cond_62b

    .line 238
    invoke-interface/range {v18 .. v18}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    const-string v6, "null cannot be cast to non-null type androidx.compose.ui.semantics.AccessibilityAction<*>"

    invoke-static {v4, v6}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    check-cast v4, Lx1/a;

    .line 239
    iget-object v6, v2, Landroidx/compose/ui/platform/p$f;->a:Lx1/k;

    .line 240
    invoke-interface/range {v18 .. v18}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lx1/y;

    invoke-static {v6, v8}, Lmb/b;->d(Lx1/k;Lx1/y;)Ljava/lang/Object;

    move-result-object v6

    if-ne v4, v6, :cond_602

    goto :goto_625

    .line 241
    :cond_602
    instance-of v8, v6, Lx1/a;

    if-nez v8, :cond_607

    goto :goto_623

    .line 242
    :cond_607
    iget-object v8, v4, Lx1/a;->a:Ljava/lang/String;

    .line 243
    check-cast v6, Lx1/a;

    .line 244
    iget-object v9, v6, Lx1/a;->a:Ljava/lang/String;

    .line 245
    invoke-static {v8, v9}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_614

    goto :goto_623

    .line 246
    :cond_614
    iget-object v4, v4, Lx1/a;->b:Lkg/a;

    if-nez v4, :cond_61d

    iget-object v8, v6, Lx1/a;->b:Lkg/a;

    if-eqz v8, :cond_61d

    goto :goto_623

    :cond_61d
    if-eqz v4, :cond_625

    .line 247
    iget-object v4, v6, Lx1/a;->b:Lkg/a;

    if-nez v4, :cond_625

    :goto_623
    const/4 v4, 0x0

    goto :goto_626

    :cond_625
    :goto_625
    const/4 v4, 0x1

    :goto_626
    xor-int/lit8 v4, v4, 0x1

    move/from16 v17, v4

    goto :goto_62e

    :cond_62b
    :goto_62b
    const/4 v4, 0x1

    const/16 v17, 0x1

    :cond_62e
    :goto_62e
    const/16 v6, 0x8

    const/4 v8, 0x0

    move-object v14, v15

    move-object/from16 v4, v19

    move-object v15, v2

    move-object/from16 v2, v21

    goto/16 :goto_231

    :cond_639
    move-object/from16 v21, v2

    move-object/from16 v19, v4

    move-object v2, v15

    const/16 v11, 0x800

    move-object v15, v14

    if-nez v17, :cond_66a

    .line 248
    iget-object v2, v2, Landroidx/compose/ui/platform/p$f;->a:Lx1/k;

    .line 249
    invoke-virtual {v2}, Lx1/k;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_649
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_668

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/Map$Entry;

    .line 250
    invoke-virtual {v15}, Lx1/r;->f()Lx1/k;

    move-result-object v6

    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lx1/y;

    invoke-virtual {v6, v4}, Lx1/k;->d(Lx1/y;)Z

    move-result v4

    if-nez v4, :cond_649

    const/16 v17, 0x1

    goto :goto_66a

    :cond_668
    const/16 v17, 0x0

    :cond_66a
    :goto_66a
    if-eqz v17, :cond_674

    .line 251
    invoke-virtual {v0, v7}, Landroidx/compose/ui/platform/p;->y(I)I

    move-result v2

    const/4 v4, 0x0

    .line 252
    invoke-virtual {v0, v2, v11, v3, v4}, Landroidx/compose/ui/platform/p;->A(IILjava/lang/Integer;Ljava/util/List;)Z

    :cond_674
    const/16 v6, 0x8

    const/4 v8, 0x0

    move-object/from16 v4, v19

    move-object/from16 v2, v21

    goto/16 :goto_1f4

    :cond_67d
    const/16 v2, 0x10

    .line 253
    iget-object v3, v0, Landroidx/compose/ui/platform/p;->s:Ly/c;

    invoke-virtual {v3}, Ly/c;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_685
    :goto_685
    move-object v4, v3

    check-cast v4, Ly/f$a;

    invoke-virtual {v4}, Ly/f$a;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_6e2

    invoke-virtual {v4}, Ly/f$a;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    .line 254
    invoke-virtual {v0}, Landroidx/compose/ui/platform/p;->p()Ljava/util/Map;

    move-result-object v5

    invoke-interface {v5, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroidx/compose/ui/platform/q1;

    if-eqz v5, :cond_6a3

    .line 255
    iget-object v5, v5, Landroidx/compose/ui/platform/q1;->a:Lx1/r;

    goto :goto_6a4

    :cond_6a3
    const/4 v5, 0x0

    :goto_6a4
    if-eqz v5, :cond_6b4

    .line 256
    invoke-virtual {v5}, Lx1/r;->f()Lx1/k;

    move-result-object v5

    sget-object v6, Lx1/t;->a:Lx1/t;

    .line 257
    sget-object v6, Lx1/t;->e:Lx1/y;

    .line 258
    invoke-virtual {v5, v6}, Lx1/k;->d(Lx1/y;)Z

    move-result v5

    if-nez v5, :cond_685

    .line 259
    :cond_6b4
    iget-object v5, v0, Landroidx/compose/ui/platform/p;->s:Ly/c;

    invoke-virtual {v5, v4}, Ly/c;->remove(Ljava/lang/Object;)Z

    const-string v5, "id"

    .line 260
    invoke-static {v4, v5}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v5

    const/16 v6, 0x20

    .line 261
    iget-object v7, v0, Landroidx/compose/ui/platform/p;->t:Ljava/util/Map;

    invoke-interface {v7, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroidx/compose/ui/platform/p$f;

    if-eqz v4, :cond_6dd

    .line 262
    iget-object v4, v4, Landroidx/compose/ui/platform/p$f;->a:Lx1/k;

    if-eqz v4, :cond_6dd

    .line 263
    sget-object v7, Lx1/t;->a:Lx1/t;

    .line 264
    sget-object v7, Lx1/t;->e:Lx1/y;

    .line 265
    invoke-static {v4, v7}, Lmb/b;->d(Lx1/k;Lx1/y;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    goto :goto_6de

    :cond_6dd
    const/4 v4, 0x0

    .line 266
    :goto_6de
    invoke-virtual {v0, v5, v6, v4}, Landroidx/compose/ui/platform/p;->C(IILjava/lang/String;)V

    goto :goto_685

    .line 267
    :cond_6e2
    iget-object v3, v0, Landroidx/compose/ui/platform/p;->t:Ljava/util/Map;

    invoke-interface {v3}, Ljava/util/Map;->clear()V

    .line 268
    invoke-virtual {v0}, Landroidx/compose/ui/platform/p;->p()Ljava/util/Map;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_6f3
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_759

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/Map$Entry;

    .line 269
    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroidx/compose/ui/platform/q1;

    .line 270
    iget-object v5, v5, Landroidx/compose/ui/platform/q1;->a:Lx1/r;

    .line 271
    invoke-virtual {v5}, Lx1/r;->f()Lx1/k;

    move-result-object v5

    sget-object v6, Lx1/t;->a:Lx1/t;

    .line 272
    sget-object v6, Lx1/t;->e:Lx1/y;

    .line 273
    invoke-virtual {v5, v6}, Lx1/k;->d(Lx1/y;)Z

    move-result v5

    if-eqz v5, :cond_73e

    .line 274
    iget-object v5, v0, Landroidx/compose/ui/platform/p;->s:Ly/c;

    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v5, v7}, Ly/c;->add(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_73e

    .line 275
    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Number;

    invoke-virtual {v5}, Ljava/lang/Number;->intValue()I

    move-result v5

    .line 276
    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroidx/compose/ui/platform/q1;

    .line 277
    iget-object v7, v7, Landroidx/compose/ui/platform/q1;->a:Lx1/r;

    .line 278
    iget-object v7, v7, Lx1/r;->e:Lx1/k;

    .line 279
    invoke-virtual {v7, v6}, Lx1/k;->e(Lx1/y;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    .line 280
    invoke-virtual {v0, v5, v2, v6}, Landroidx/compose/ui/platform/p;->C(IILjava/lang/String;)V

    .line 281
    :cond_73e
    iget-object v5, v0, Landroidx/compose/ui/platform/p;->t:Ljava/util/Map;

    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    .line 282
    new-instance v7, Landroidx/compose/ui/platform/p$f;

    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroidx/compose/ui/platform/q1;

    .line 283
    iget-object v4, v4, Landroidx/compose/ui/platform/q1;->a:Lx1/r;

    .line 284
    invoke-virtual {v0}, Landroidx/compose/ui/platform/p;->p()Ljava/util/Map;

    move-result-object v8

    invoke-direct {v7, v4, v8}, Landroidx/compose/ui/platform/p$f;-><init>(Lx1/r;Ljava/util/Map;)V

    invoke-interface {v5, v6, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_6f3

    .line 285
    :cond_759
    new-instance v2, Landroidx/compose/ui/platform/p$f;

    iget-object v3, v0, Landroidx/compose/ui/platform/p;->d:Landroidx/compose/ui/platform/AndroidComposeView;

    invoke-virtual {v3}, Landroidx/compose/ui/platform/AndroidComposeView;->getSemanticsOwner()Lx1/s;

    move-result-object v3

    invoke-virtual {v3}, Lx1/s;->a()Lx1/r;

    move-result-object v3

    invoke-virtual {v0}, Landroidx/compose/ui/platform/p;->p()Ljava/util/Map;

    move-result-object v4

    invoke-direct {v2, v3, v4}, Landroidx/compose/ui/platform/p$f;-><init>(Lx1/r;Ljava/util/Map;)V

    .line 286
    iput-object v2, v0, Landroidx/compose/ui/platform/p;->u:Landroidx/compose/ui/platform/p$f;

    const/4 v2, 0x0

    .line 287
    iput-boolean v2, v0, Landroidx/compose/ui/platform/p;->v:Z

    return-void

    .line 288
    :pswitch_772
    iget-object v0, v1, Landroidx/activity/d;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/compose/material/ripple/RippleHostView;

    invoke-static {v0}, Landroidx/compose/material/ripple/RippleHostView;->a(Landroidx/compose/material/ripple/RippleHostView;)V

    return-void

    :pswitch_77a
    iget-object v0, v1, Landroidx/activity/d;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/camera/view/d;

    .line 289
    iget-object v2, v0, Landroidx/camera/view/d;->g:Landroidx/camera/view/c$a;

    if-eqz v2, :cond_78a

    .line 290
    check-cast v2, Lu/c;

    invoke-virtual {v2}, Lu/c;->a()V

    const/4 v2, 0x0

    .line 291
    iput-object v2, v0, Landroidx/camera/view/d;->g:Landroidx/camera/view/c$a;

    :cond_78a
    return-void

    .line 292
    :pswitch_78b
    iget-object v0, v1, Landroidx/activity/d;->b:Ljava/lang/Object;

    check-cast v0, Landroid/view/Surface;

    invoke-virtual {v0}, Landroid/view/Surface;->release()V

    return-void

    :pswitch_793
    iget-object v0, v1, Landroidx/activity/d;->b:Ljava/lang/Object;

    check-cast v0, Lv9/a;

    sget-object v2, Lm/h0;->D:Lm/h0$e;

    const/4 v2, 0x1

    .line 293
    invoke-interface {v0, v2}, Ljava/util/concurrent/Future;->cancel(Z)Z

    return-void

    .line 294
    :pswitch_79e
    iget-object v0, v1, Landroidx/activity/d;->b:Ljava/lang/Object;

    check-cast v0, Lm/c1;

    invoke-virtual {v0}, Lm/c1;->d()V

    return-void

    :pswitch_7a6
    iget-object v0, v1, Landroidx/activity/d;->b:Ljava/lang/Object;

    check-cast v0, Lm/x;

    .line 295
    iget-object v2, v0, Lm/x;->d:Ljava/lang/Object;

    monitor-enter v2

    const/4 v3, 0x0

    .line 296
    :try_start_7ae
    iput-object v3, v0, Lm/x;->f:Lm/x$b;

    .line 297
    iget-object v4, v0, Lm/x;->e:Lm/r0;

    if-eqz v4, :cond_7b9

    .line 298
    iput-object v3, v0, Lm/x;->e:Lm/r0;

    .line 299
    invoke-virtual {v0, v4}, Lm/x;->d(Lm/r0;)V

    .line 300
    :cond_7b9
    monitor-exit v2

    return-void

    :catchall_7bb
    move-exception v0

    monitor-exit v2
    :try_end_7bd
    .catchall {:try_start_7ae .. :try_end_7bd} :catchall_7bb

    throw v0

    .line 301
    :pswitch_7be
    iget-object v0, v1, Landroidx/activity/d;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {v0}, Landroidx/appcompat/widget/Toolbar;->o()V

    return-void

    :pswitch_7c6
    iget-object v0, v1, Landroidx/activity/d;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/activity/OnBackPressedDispatcher;

    invoke-virtual {v0}, Landroidx/activity/OnBackPressedDispatcher;->c()V

    return-void

    :pswitch_7ce
    iget-object v0, v1, Landroidx/activity/d;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/activity/e;

    invoke-static {v0}, Landroidx/activity/e;->a(Landroidx/activity/e;)V

    return-void

    :pswitch_7d6
    iget-object v0, v1, Landroidx/activity/d;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/activity/ComponentActivity;

    invoke-virtual {v0}, Landroidx/activity/ComponentActivity;->invalidateMenu()V

    return-void

    :goto_7de
    iget-object v0, v1, Landroidx/activity/d;->b:Ljava/lang/Object;

    check-cast v0, Linfo/cd120/two/ui/online/TeamActivity;

    sget v2, Linfo/cd120/two/ui/online/TeamActivity;->l:I

    const-string v2, "this$0"

    .line 302
    invoke-static {v0, v2}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 303
    invoke-virtual {v0}, Lxd/a;->l()Lq4/a;

    move-result-object v2

    check-cast v2, Linfo/cd120/two/databinding/ActivityTeamBinding;

    iget-object v2, v2, Linfo/cd120/two/databinding/ActivityTeamBinding;->r:Landroid/widget/ImageView;

    invoke-virtual {v2}, Landroid/widget/ImageView;->getBottom()I

    move-result v2

    const/16 v3, 0xa

    invoke-static {v3}, Lee/k;->d(I)I

    move-result v3

    add-int/2addr v3, v2

    .line 304
    invoke-virtual {v0}, Lxd/a;->l()Lq4/a;

    move-result-object v0

    check-cast v0, Linfo/cd120/two/databinding/ActivityTeamBinding;

    iget-object v0, v0, Linfo/cd120/two/databinding/ActivityTeamBinding;->y:Lcn/gavinliu/android/lib/shapedimageview/ShapedImageView;

    const-string v2, "binding.ivPortrait"

    invoke-static {v0, v2}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    .line 305
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    const-string v4, "null cannot be cast to non-null type android.view.ViewGroup.MarginLayoutParams"

    invoke-static {v2, v4}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    check-cast v2, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 306
    iput v3, v2, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 307
    invoke-virtual {v0, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-void

    :pswitch_data_81a
    .packed-switch 0x0
        :pswitch_7d6
        :pswitch_7ce
        :pswitch_7c6
        :pswitch_7be
        :pswitch_7a6
        :pswitch_79e
        :pswitch_793
        :pswitch_78b
        :pswitch_77a
        :pswitch_772
        :pswitch_1b8
        :pswitch_1ab
        :pswitch_10c
        :pswitch_102
        :pswitch_fa
        :pswitch_ea
        :pswitch_dc
        :pswitch_a8
        :pswitch_78
        :pswitch_69
        :pswitch_23
        :pswitch_14
    .end packed-switch
.end method
