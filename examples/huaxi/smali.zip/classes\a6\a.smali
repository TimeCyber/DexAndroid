.class public La6/a;
.super Ljava/lang/Object;
.source "FontAssetDelegate.java"
