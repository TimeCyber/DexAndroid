.class public La3/o;
.super Ljava/lang/Object;
.source "NotificationCompatJellybean.java"


# static fields
.field public static final a:Ljava/lang/Object;


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, La3/o;->a:Ljava/lang/Object;

    return-void
.end method

.method public static a([La3/s;)[Landroid/os/Bundle;
    .registers 1

    const/4 p0, 0x0

    return-object p0
.end method
