.class public final La0/r0;
.super Ljava/lang/Object;
.source "Animation.kt"

# interfaces
.implements La0/c;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "V:",
        "La0/n;",
        ">",
        "Ljava/lang/Object;",
        "La0/c<",
        "TT;TV;>;"
    }
.end annotation


# instance fields
.field public final a:La0/y0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/y0<",
            "TV;>;"
        }
    .end annotation
.end field

.field public final b:La0/u0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/u0<",
            "TT;TV;>;"
        }
    .end annotation
.end field

.field public final c:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field

.field public final d:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field

.field public final e:La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field

.field public final f:La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field

.field public final g:La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field

.field public final h:J

.field public final i:La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(La0/g;La0/u0;Ljava/lang/Object;Ljava/lang/Object;La0/n;)V
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La0/g<",
            "TT;>;",
            "La0/u0<",
            "TT;TV;>;TT;TT;TV;)V"
        }
    .end annotation

    const-string v0, "animationSpec"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "typeConverter"

    invoke-static {p2, v1}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-interface {p1, p2}, La0/g;->a(La0/u0;)La0/y0;

    move-result-object p1

    .line 2
    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La0/r0;->a:La0/y0;

    .line 5
    iput-object p2, p0, La0/r0;->b:La0/u0;

    .line 6
    iput-object p3, p0, La0/r0;->c:Ljava/lang/Object;

    .line 7
    iput-object p4, p0, La0/r0;->d:Ljava/lang/Object;

    .line 8
    invoke-interface {p2}, La0/u0;->a()Lvg/l;

    move-result-object v0

    invoke-interface {v0, p3}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La0/n;

    iput-object v0, p0, La0/r0;->e:La0/n;

    .line 9
    invoke-interface {p2}, La0/u0;->a()Lvg/l;

    move-result-object v1

    invoke-interface {v1, p4}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p4

    check-cast p4, La0/n;

    iput-object p4, p0, La0/r0;->f:La0/n;

    if-eqz p5, :cond_3b

    .line 10
    invoke-static {p5}, Landroidx/appcompat/widget/m;->s(La0/n;)La0/n;

    move-result-object p2

    goto :goto_49

    :cond_3b
    invoke-interface {p2}, La0/u0;->a()Lvg/l;

    move-result-object p2

    invoke-interface {p2, p3}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, La0/n;

    .line 11
    invoke-static {p2}, Landroidx/appcompat/widget/m;->M(La0/n;)La0/n;

    move-result-object p2

    .line 12
    :goto_49
    iput-object p2, p0, La0/r0;->g:La0/n;

    .line 13
    invoke-interface {p1, v0, p4, p2}, La0/y0;->b(La0/n;La0/n;La0/n;)J

    move-result-wide v1

    iput-wide v1, p0, La0/r0;->h:J

    .line 14
    invoke-interface {p1, v0, p4, p2}, La0/y0;->d(La0/n;La0/n;La0/n;)La0/n;

    move-result-object p1

    iput-object p1, p0, La0/r0;->i:La0/n;

    return-void
.end method


# virtual methods
.method public a()Z
    .registers 2

    .line 1
    iget-object v0, p0, La0/r0;->a:La0/y0;

    invoke-interface {v0}, La0/y0;->a()Z

    move-result v0

    return v0
.end method

.method public b()J
    .registers 3

    .line 1
    iget-wide v0, p0, La0/r0;->h:J

    return-wide v0
.end method

.method public c()La0/u0;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "La0/u0<",
            "TT;TV;>;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La0/r0;->b:La0/u0;

    return-object v0
.end method

.method public d(J)La0/n;
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J)TV;"
        }
    .end annotation

    .line 1
    invoke-virtual {p0, p1, p2}, La0/r0;->e(J)Z

    move-result v0

    if-nez v0, :cond_14

    .line 2
    iget-object v1, p0, La0/r0;->a:La0/y0;

    .line 3
    iget-object v4, p0, La0/r0;->e:La0/n;

    .line 4
    iget-object v5, p0, La0/r0;->f:La0/n;

    .line 5
    iget-object v6, p0, La0/r0;->g:La0/n;

    move-wide v2, p1

    .line 6
    invoke-interface/range {v1 .. v6}, La0/y0;->c(JLa0/n;La0/n;La0/n;)La0/n;

    move-result-object p1

    goto :goto_16

    .line 7
    :cond_14
    iget-object p1, p0, La0/r0;->i:La0/n;

    :goto_16
    return-object p1
.end method

.method public e(J)Z
    .registers 6

    .line 1
    iget-wide v0, p0, La0/r0;->h:J

    cmp-long v2, p1, v0

    if-ltz v2, :cond_8

    const/4 p1, 0x1

    goto :goto_9

    :cond_8
    const/4 p1, 0x0

    :goto_9
    return p1
.end method

.method public f(J)Ljava/lang/Object;
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J)TT;"
        }
    .end annotation

    .line 1
    invoke-virtual {p0, p1, p2}, La0/r0;->e(J)Z

    move-result v0

    if-nez v0, :cond_1e

    .line 2
    iget-object v0, p0, La0/r0;->b:La0/u0;

    .line 3
    invoke-interface {v0}, La0/u0;->b()Lvg/l;

    move-result-object v0

    .line 4
    iget-object v1, p0, La0/r0;->a:La0/y0;

    .line 5
    iget-object v4, p0, La0/r0;->e:La0/n;

    .line 6
    iget-object v5, p0, La0/r0;->f:La0/n;

    iget-object v6, p0, La0/r0;->g:La0/n;

    move-wide v2, p1

    .line 7
    invoke-interface/range {v1 .. v6}, La0/y0;->e(JLa0/n;La0/n;La0/n;)La0/n;

    move-result-object p1

    .line 8
    invoke-interface {v0, p1}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    goto :goto_20

    .line 9
    :cond_1e
    iget-object p1, p0, La0/r0;->d:Ljava/lang/Object;

    :goto_20
    return-object p1
.end method

.method public g()Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La0/r0;->d:Ljava/lang/Object;

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .registers 6

    const-string v0, "TargetBasedAnimation: "

    .line 1
    invoke-static {v0}, Landroid/support/v4/media/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, La0/r0;->c:Ljava/lang/Object;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " -> "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2
    iget-object v1, p0, La0/r0;->d:Ljava/lang/Object;

    .line 3
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ",initial velocity: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4
    iget-object v1, p0, La0/r0;->g:La0/n;

    .line 5
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", duration: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 6
    invoke-interface {p0}, La0/c;->b()J

    move-result-wide v1

    const-wide/32 v3, 0xf4240

    div-long/2addr v1, v3

    .line 7
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, " ms"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
