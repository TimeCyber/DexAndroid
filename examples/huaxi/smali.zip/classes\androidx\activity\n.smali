.class public Landroidx/activity/n;
.super Ljava/lang/Object;
.source "ViewTreeOnBackPressedDispatcherOwner.kt"


# direct methods
.method public static final A(JZJLz1/r;)Lj0/l;
    .registers 11

    .line 1
    new-instance v0, Lj0/l;

    .line 2
    new-instance v1, Lj0/l$a;

    .line 3
    invoke-static {p0, p1}, Lz1/s;->i(J)I

    move-result v2

    invoke-virtual {p5, v2}, Lz1/r;->a(I)Lk2/d;

    move-result-object v2

    .line 4
    invoke-static {p0, p1}, Lz1/s;->i(J)I

    move-result v3

    .line 5
    invoke-direct {v1, v2, v3, p3, p4}, Lj0/l$a;-><init>(Lk2/d;IJ)V

    .line 6
    new-instance v2, Lj0/l$a;

    .line 7
    invoke-static {p0, p1}, Lz1/s;->d(J)I

    move-result v3

    add-int/lit8 v3, v3, -0x1

    const/4 v4, 0x0

    invoke-static {v3, v4}, Ljava/lang/Math;->max(II)I

    move-result v3

    invoke-virtual {p5, v3}, Lz1/r;->a(I)Lk2/d;

    move-result-object p5

    .line 8
    invoke-static {p0, p1}, Lz1/s;->d(J)I

    move-result p0

    .line 9
    invoke-direct {v2, p5, p0, p3, p4}, Lj0/l$a;-><init>(Lk2/d;IJ)V

    .line 10
    invoke-direct {v0, v1, v2, p2}, Lj0/l;-><init>(Lj0/l$a;Lj0/l$a;Z)V

    return-object v0
.end method

.method public static final B(Lz1/r;Lc1/d;J)I
    .registers 7

    .line 1
    iget-object v0, p0, Lz1/r;->a:Lz1/q;

    .line 2
    iget-object v0, v0, Lz1/q;->a:Lz1/a;

    .line 3
    invoke-virtual {v0}, Lz1/a;->length()I

    move-result v0

    .line 4
    invoke-virtual {p1, p2, p3}, Lc1/d;->a(J)Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_18

    .line 5
    invoke-virtual {p0, p2, p3}, Lz1/r;->l(J)I

    move-result p0

    invoke-static {p0, v2, v0}, Li0/z0;->m(III)I

    move-result v0

    goto :goto_21

    .line 6
    :cond_18
    sget-object p0, Lj0/m0;->a:Lj0/m0;

    invoke-virtual {p0, p2, p3, p1}, Lj0/m0;->a(JLc1/d;)I

    move-result p0

    if-gez p0, :cond_21

    const/4 v0, 0x0

    :cond_21
    :goto_21
    return v0
.end method

.method public static final C(Landroid/text/Spanned;Ljava/lang/Class;)Z
    .registers 4

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-interface {p0}, Landroid/text/Spanned;->length()I

    move-result v0

    const/4 v1, -0x1

    invoke-interface {p0, v1, v0, p1}, Landroid/text/Spanned;->nextSpanTransition(IILjava/lang/Class;)I

    move-result p1

    invoke-interface {p0}, Landroid/text/Spanned;->length()I

    move-result p0

    if-eq p1, p0, :cond_16

    const/4 p0, 0x1

    goto :goto_17

    :cond_16
    const/4 p0, 0x0

    :goto_17
    return p0
.end method

.method public static final D(FFF)F
    .registers 4

    const/4 v0, 0x1

    int-to-float v0, v0

    sub-float/2addr v0, p2

    mul-float v0, v0, p0

    mul-float p2, p2, p1

    add-float/2addr p2, v0

    return p2
.end method

.method public static final E(Ly0/h;Lvg/l;)Ly0/h;
    .registers 4

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    new-instance v0, Lr1/k0;

    .line 2
    sget-object v1, Landroidx/compose/ui/platform/b1;->a:Lvg/l;

    .line 3
    sget-object v1, Landroidx/compose/ui/platform/b1;->a:Lvg/l;

    .line 4
    invoke-direct {v0, p1, v1}, Lr1/k0;-><init>(Lvg/l;Lvg/l;)V

    .line 5
    invoke-interface {p0, v0}, Ly0/h;->p0(Ly0/h;)Ly0/h;

    move-result-object p0

    return-object p0
.end method

.method public static final F(Ljava/util/ArrayList;II)I
    .registers 7

    .line 1
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    const/4 v1, 0x0

    :goto_7
    if-gt v1, v0, :cond_27

    add-int v2, v1, v0

    ushr-int/lit8 v2, v2, 0x1

    .line 2
    invoke-virtual {p0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lm0/c;

    .line 3
    iget v3, v3, Lm0/c;->a:I

    if-gez v3, :cond_18

    add-int/2addr v3, p2

    .line 4
    :cond_18
    invoke-static {v3, p1}, Lp/h;->s(II)I

    move-result v3

    if-gez v3, :cond_21

    add-int/lit8 v1, v2, 0x1

    goto :goto_7

    :cond_21
    if-lez v3, :cond_26

    add-int/lit8 v0, v2, -0x1

    goto :goto_7

    :cond_26
    return v2

    :cond_27
    add-int/lit8 v1, v1, 0x1

    neg-int p0, v1

    return p0
.end method

.method public static G(FFLjava/lang/Object;I)La0/n0;
    .registers 4

    and-int/lit8 p2, p3, 0x1

    if-eqz p2, :cond_6

    const/high16 p0, 0x3f800000    # 1.0f

    :cond_6
    and-int/lit8 p2, p3, 0x2

    if-eqz p2, :cond_d

    const p1, 0x44bb8000    # 1500.0f

    :cond_d
    const/4 p2, 0x0

    .line 1
    new-instance p3, La0/n0;

    invoke-direct {p3, p0, p1, p2}, La0/n0;-><init>(FFLjava/lang/Object;)V

    return-object p3
.end method

.method public static final H(Lz1/a;Lp2/b;Le2/j$a;)Landroid/text/SpannableString;
    .registers 24

    move-object/from16 v0, p0

    const-string v1, "density"

    move-object/from16 v8, p1

    invoke-static {v8, v1}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "fontFamilyResolver"

    move-object/from16 v2, p2

    invoke-static {v2, v1}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    new-instance v1, Landroid/text/SpannableString;

    .line 2
    iget-object v2, v0, Lz1/a;->a:Ljava/lang/String;

    .line 3
    invoke-direct {v1, v2}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    .line 4
    iget-object v9, v0, Lz1/a;->b:Ljava/util/List;

    .line 5
    invoke-interface {v9}, Ljava/util/List;->size()I

    move-result v10

    const/4 v12, 0x0

    :goto_1e
    if-ge v12, v10, :cond_ea

    .line 6
    invoke-interface {v9, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    .line 7
    check-cast v2, Lz1/a$b;

    .line 8
    iget-object v3, v2, Lz1/a$b;->a:Ljava/lang/Object;

    .line 9
    check-cast v3, Lz1/n;

    .line 10
    iget v15, v2, Lz1/a$b;->b:I

    .line 11
    iget v7, v2, Lz1/a$b;->c:I

    .line 12
    invoke-virtual {v3}, Lz1/n;->b()J

    move-result-wide v4

    move/from16 v16, v12

    .line 13
    iget-wide v11, v3, Lz1/n;->b:J

    .line 14
    iget-object v6, v3, Lz1/n;->c:Le2/t;

    .line 15
    iget-object v2, v3, Lz1/n;->d:Le2/r;

    .line 16
    iget-object v14, v3, Lz1/n;->j:Lk2/j;

    .line 17
    iget-object v13, v3, Lz1/n;->k:Lg2/d;

    move-object/from16 v17, v9

    .line 18
    iget-wide v8, v3, Lz1/n;->l:J

    move/from16 v18, v10

    .line 19
    iget-object v10, v3, Lz1/n;->m:Lk2/f;

    move-wide/from16 v19, v8

    .line 20
    invoke-virtual {v3}, Lz1/n;->b()J

    move-result-wide v8

    invoke-static {v4, v5, v8, v9}, Ld1/s;->b(JJ)Z

    move-result v8

    if-eqz v8, :cond_55

    iget-object v3, v3, Lz1/n;->a:Lk2/i;

    goto :goto_6b

    .line 21
    :cond_55
    sget-object v3, Ld1/s;->b:Ld1/s$a;

    .line 22
    sget-wide v8, Ld1/s;->h:J

    cmp-long v3, v4, v8

    if-eqz v3, :cond_5f

    const/4 v3, 0x1

    goto :goto_60

    :cond_5f
    const/4 v3, 0x0

    :goto_60
    if-eqz v3, :cond_69

    .line 23
    new-instance v3, Lk2/b;

    const/4 v8, 0x0

    invoke-direct {v3, v4, v5, v8}, Lk2/b;-><init>(JLwg/e;)V

    goto :goto_6b

    :cond_69
    sget-object v3, Lk2/i$a;->b:Lk2/i$a;

    .line 24
    :goto_6b
    invoke-interface {v3}, Lk2/i;->a()J

    move-result-wide v3

    .line 25
    invoke-static {v1, v3, v4, v15, v7}, Li2/d;->e(Landroid/text/Spannable;JII)V

    move-object v8, v2

    move-object v2, v1

    move-wide v3, v11

    move-object/from16 v5, p1

    move-object v9, v6

    move v6, v15

    move v11, v7

    .line 26
    invoke-static/range {v2 .. v7}, Li2/d;->f(Landroid/text/Spannable;JLp2/b;II)V

    if-nez v9, :cond_81

    if-eqz v8, :cond_9d

    :cond_81
    if-nez v9, :cond_88

    .line 27
    sget-object v2, Le2/t;->b:Le2/t$a;

    .line 28
    sget-object v6, Le2/t;->n:Le2/t;

    goto :goto_89

    :cond_88
    move-object v6, v9

    :goto_89
    if-eqz v8, :cond_8e

    .line 29
    iget v2, v8, Le2/r;->a:I

    goto :goto_8f

    :cond_8e
    const/4 v2, 0x0

    .line 30
    :goto_8f
    new-instance v3, Landroid/text/style/StyleSpan;

    invoke-static {v6, v2}, Le2/z;->z(Le2/t;I)I

    move-result v2

    invoke-direct {v3, v2}, Landroid/text/style/StyleSpan;-><init>(I)V

    const/16 v2, 0x21

    .line 31
    invoke-virtual {v1, v3, v15, v11, v2}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    :cond_9d
    if-eqz v10, :cond_ca

    .line 32
    iget v2, v10, Lk2/f;->a:I

    const/4 v3, 0x1

    or-int v4, v3, v2

    if-ne v4, v2, :cond_a8

    const/4 v2, 0x1

    goto :goto_a9

    :cond_a8
    const/4 v2, 0x0

    :goto_a9
    if-eqz v2, :cond_b5

    .line 33
    new-instance v2, Landroid/text/style/UnderlineSpan;

    invoke-direct {v2}, Landroid/text/style/UnderlineSpan;-><init>()V

    const/16 v4, 0x21

    .line 34
    invoke-virtual {v1, v2, v15, v11, v4}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 35
    :cond_b5
    iget v2, v10, Lk2/f;->a:I

    const/4 v4, 0x2

    or-int/2addr v4, v2

    if-ne v4, v2, :cond_bc

    goto :goto_bd

    :cond_bc
    const/4 v3, 0x0

    :goto_bd
    if-eqz v3, :cond_ca

    .line 36
    new-instance v2, Landroid/text/style/StrikethroughSpan;

    invoke-direct {v2}, Landroid/text/style/StrikethroughSpan;-><init>()V

    const/16 v3, 0x21

    .line 37
    invoke-virtual {v1, v2, v15, v11, v3}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    goto :goto_cc

    :cond_ca
    const/16 v3, 0x21

    :goto_cc
    if-eqz v14, :cond_d8

    .line 38
    new-instance v2, Landroid/text/style/ScaleXSpan;

    .line 39
    iget v4, v14, Lk2/j;->a:F

    .line 40
    invoke-direct {v2, v4}, Landroid/text/style/ScaleXSpan;-><init>(F)V

    .line 41
    invoke-virtual {v1, v2, v15, v11, v3}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 42
    :cond_d8
    invoke-static {v1, v13, v15, v11}, Li2/d;->g(Landroid/text/Spannable;Lg2/d;II)V

    move-wide/from16 v2, v19

    .line 43
    invoke-static {v1, v2, v3, v15, v11}, Li2/d;->d(Landroid/text/Spannable;JII)V

    add-int/lit8 v12, v16, 0x1

    move-object/from16 v8, p1

    move-object/from16 v9, v17

    move/from16 v10, v18

    goto/16 :goto_1e

    :cond_ea
    const/4 v3, 0x1

    .line 44
    invoke-virtual/range {p0 .. p0}, Lz1/a;->length()I

    move-result v2

    .line 45
    iget-object v0, v0, Lz1/a;->d:Ljava/util/List;

    .line 46
    new-instance v4, Ljava/util/ArrayList;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v5

    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 47
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v5

    const/4 v6, 0x0

    :goto_ff
    if-ge v6, v5, :cond_125

    .line 48
    invoke-interface {v0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    .line 49
    move-object v8, v7

    check-cast v8, Lz1/a$b;

    .line 50
    iget-object v9, v8, Lz1/a$b;->a:Ljava/lang/Object;

    .line 51
    instance-of v9, v9, Lz1/u;

    if-eqz v9, :cond_11b

    .line 52
    iget v9, v8, Lz1/a$b;->b:I

    .line 53
    iget v8, v8, Lz1/a$b;->c:I

    const/4 v10, 0x0

    .line 54
    invoke-static {v10, v2, v9, v8}, Lz1/b;->c(IIII)Z

    move-result v8

    if-eqz v8, :cond_11c

    const/4 v8, 0x1

    goto :goto_11d

    :cond_11b
    const/4 v10, 0x0

    :cond_11c
    const/4 v8, 0x0

    :goto_11d
    if-eqz v8, :cond_122

    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_122
    add-int/lit8 v6, v6, 0x1

    goto :goto_ff

    :cond_125
    const/4 v10, 0x0

    .line 55
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v11, 0x0

    :goto_12b
    if-ge v11, v0, :cond_164

    .line 56
    invoke-virtual {v4, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    .line 57
    check-cast v2, Lz1/a$b;

    .line 58
    iget-object v3, v2, Lz1/a$b;->a:Ljava/lang/Object;

    .line 59
    check-cast v3, Lz1/u;

    .line 60
    iget v5, v2, Lz1/a$b;->b:I

    .line 61
    iget v2, v2, Lz1/a$b;->c:I

    const-string v6, "<this>"

    .line 62
    invoke-static {v3, v6}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 63
    instance-of v6, v3, Lz1/v;

    if-eqz v6, :cond_15e

    check-cast v3, Lz1/v;

    .line 64
    new-instance v6, Landroid/text/style/TtsSpan$VerbatimBuilder;

    .line 65
    iget-object v3, v3, Lz1/v;->a:Ljava/lang/String;

    .line 66
    invoke-direct {v6, v3}, Landroid/text/style/TtsSpan$VerbatimBuilder;-><init>(Ljava/lang/String;)V

    .line 67
    invoke-virtual {v6}, Landroid/text/style/TtsSpan$VerbatimBuilder;->build()Landroid/text/style/TtsSpan;

    move-result-object v3

    const-string v6, "builder.build()"

    invoke-static {v3, v6}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/16 v6, 0x21

    .line 68
    invoke-virtual {v1, v3, v5, v2, v6}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    add-int/lit8 v11, v11, 0x1

    goto :goto_12b

    .line 69
    :cond_15e
    new-instance v0, Lq6/a;

    invoke-direct {v0}, Lq6/a;-><init>()V

    throw v0

    :cond_164
    return-object v1
.end method

.method public static final I(I)Landroid/graphics/BlendMode;
    .registers 2

    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_b

    sget-object p0, Landroid/graphics/BlendMode;->CLEAR:Landroid/graphics/BlendMode;

    goto/16 :goto_14d

    :cond_b
    const/4 v0, 0x1

    .line 2
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_16

    sget-object p0, Landroid/graphics/BlendMode;->SRC:Landroid/graphics/BlendMode;

    goto/16 :goto_14d

    :cond_16
    const/4 v0, 0x2

    .line 3
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_21

    sget-object p0, Landroid/graphics/BlendMode;->DST:Landroid/graphics/BlendMode;

    goto/16 :goto_14d

    :cond_21
    const/4 v0, 0x3

    .line 4
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_2c

    sget-object p0, Landroid/graphics/BlendMode;->SRC_OVER:Landroid/graphics/BlendMode;

    goto/16 :goto_14d

    :cond_2c
    const/4 v0, 0x4

    .line 5
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_37

    sget-object p0, Landroid/graphics/BlendMode;->DST_OVER:Landroid/graphics/BlendMode;

    goto/16 :goto_14d

    :cond_37
    const/4 v0, 0x5

    .line 6
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_42

    sget-object p0, Landroid/graphics/BlendMode;->SRC_IN:Landroid/graphics/BlendMode;

    goto/16 :goto_14d

    :cond_42
    const/4 v0, 0x6

    .line 7
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_4d

    sget-object p0, Landroid/graphics/BlendMode;->DST_IN:Landroid/graphics/BlendMode;

    goto/16 :goto_14d

    :cond_4d
    const/4 v0, 0x7

    .line 8
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_58

    sget-object p0, Landroid/graphics/BlendMode;->SRC_OUT:Landroid/graphics/BlendMode;

    goto/16 :goto_14d

    :cond_58
    const/16 v0, 0x8

    .line 9
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_64

    sget-object p0, Landroid/graphics/BlendMode;->DST_OUT:Landroid/graphics/BlendMode;

    goto/16 :goto_14d

    :cond_64
    const/16 v0, 0x9

    .line 10
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_70

    sget-object p0, Landroid/graphics/BlendMode;->SRC_ATOP:Landroid/graphics/BlendMode;

    goto/16 :goto_14d

    :cond_70
    const/16 v0, 0xa

    .line 11
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_7c

    sget-object p0, Landroid/graphics/BlendMode;->DST_ATOP:Landroid/graphics/BlendMode;

    goto/16 :goto_14d

    :cond_7c
    const/16 v0, 0xb

    .line 12
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_88

    sget-object p0, Landroid/graphics/BlendMode;->XOR:Landroid/graphics/BlendMode;

    goto/16 :goto_14d

    :cond_88
    const/16 v0, 0xc

    .line 13
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_94

    sget-object p0, Landroid/graphics/BlendMode;->PLUS:Landroid/graphics/BlendMode;

    goto/16 :goto_14d

    :cond_94
    const/16 v0, 0xd

    .line 14
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_a0

    sget-object p0, Landroid/graphics/BlendMode;->MODULATE:Landroid/graphics/BlendMode;

    goto/16 :goto_14d

    :cond_a0
    const/16 v0, 0xe

    .line 15
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_ac

    sget-object p0, Landroid/graphics/BlendMode;->SCREEN:Landroid/graphics/BlendMode;

    goto/16 :goto_14d

    :cond_ac
    const/16 v0, 0xf

    .line 16
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_b8

    sget-object p0, Landroid/graphics/BlendMode;->OVERLAY:Landroid/graphics/BlendMode;

    goto/16 :goto_14d

    :cond_b8
    const/16 v0, 0x10

    .line 17
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_c4

    sget-object p0, Landroid/graphics/BlendMode;->DARKEN:Landroid/graphics/BlendMode;

    goto/16 :goto_14d

    :cond_c4
    const/16 v0, 0x11

    .line 18
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_d0

    sget-object p0, Landroid/graphics/BlendMode;->LIGHTEN:Landroid/graphics/BlendMode;

    goto/16 :goto_14d

    :cond_d0
    const/16 v0, 0x12

    .line 19
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_dc

    sget-object p0, Landroid/graphics/BlendMode;->COLOR_DODGE:Landroid/graphics/BlendMode;

    goto/16 :goto_14d

    :cond_dc
    const/16 v0, 0x13

    .line 20
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_e8

    sget-object p0, Landroid/graphics/BlendMode;->COLOR_BURN:Landroid/graphics/BlendMode;

    goto/16 :goto_14d

    :cond_e8
    const/16 v0, 0x14

    .line 21
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_f3

    sget-object p0, Landroid/graphics/BlendMode;->HARD_LIGHT:Landroid/graphics/BlendMode;

    goto :goto_14d

    :cond_f3
    const/16 v0, 0x15

    .line 22
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_fe

    sget-object p0, Landroid/graphics/BlendMode;->SOFT_LIGHT:Landroid/graphics/BlendMode;

    goto :goto_14d

    :cond_fe
    const/16 v0, 0x16

    .line 23
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_109

    sget-object p0, Landroid/graphics/BlendMode;->DIFFERENCE:Landroid/graphics/BlendMode;

    goto :goto_14d

    :cond_109
    const/16 v0, 0x17

    .line 24
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_114

    sget-object p0, Landroid/graphics/BlendMode;->EXCLUSION:Landroid/graphics/BlendMode;

    goto :goto_14d

    :cond_114
    const/16 v0, 0x18

    .line 25
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_11f

    sget-object p0, Landroid/graphics/BlendMode;->MULTIPLY:Landroid/graphics/BlendMode;

    goto :goto_14d

    :cond_11f
    const/16 v0, 0x19

    .line 26
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_12a

    sget-object p0, Landroid/graphics/BlendMode;->HUE:Landroid/graphics/BlendMode;

    goto :goto_14d

    :cond_12a
    const/16 v0, 0x1a

    .line 27
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_135

    sget-object p0, Landroid/graphics/BlendMode;->SATURATION:Landroid/graphics/BlendMode;

    goto :goto_14d

    :cond_135
    const/16 v0, 0x1b

    .line 28
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_140

    sget-object p0, Landroid/graphics/BlendMode;->COLOR:Landroid/graphics/BlendMode;

    goto :goto_14d

    :cond_140
    const/16 v0, 0x1c

    .line 29
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result p0

    if-eqz p0, :cond_14b

    sget-object p0, Landroid/graphics/BlendMode;->LUMINOSITY:Landroid/graphics/BlendMode;

    goto :goto_14d

    .line 30
    :cond_14b
    sget-object p0, Landroid/graphics/BlendMode;->SRC_OVER:Landroid/graphics/BlendMode;

    :goto_14d
    return-object p0
.end method

.method public static final J(I)Landroid/graphics/PorterDuff$Mode;
    .registers 2

    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_b

    sget-object p0, Landroid/graphics/PorterDuff$Mode;->CLEAR:Landroid/graphics/PorterDuff$Mode;

    goto/16 :goto_c9

    :cond_b
    const/4 v0, 0x1

    .line 2
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_16

    sget-object p0, Landroid/graphics/PorterDuff$Mode;->SRC:Landroid/graphics/PorterDuff$Mode;

    goto/16 :goto_c9

    :cond_16
    const/4 v0, 0x2

    .line 3
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_21

    sget-object p0, Landroid/graphics/PorterDuff$Mode;->DST:Landroid/graphics/PorterDuff$Mode;

    goto/16 :goto_c9

    :cond_21
    const/4 v0, 0x3

    .line 4
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_2c

    sget-object p0, Landroid/graphics/PorterDuff$Mode;->SRC_OVER:Landroid/graphics/PorterDuff$Mode;

    goto/16 :goto_c9

    :cond_2c
    const/4 v0, 0x4

    .line 5
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_37

    sget-object p0, Landroid/graphics/PorterDuff$Mode;->DST_OVER:Landroid/graphics/PorterDuff$Mode;

    goto/16 :goto_c9

    :cond_37
    const/4 v0, 0x5

    .line 6
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_42

    sget-object p0, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    goto/16 :goto_c9

    :cond_42
    const/4 v0, 0x6

    .line 7
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_4d

    sget-object p0, Landroid/graphics/PorterDuff$Mode;->DST_IN:Landroid/graphics/PorterDuff$Mode;

    goto/16 :goto_c9

    :cond_4d
    const/4 v0, 0x7

    .line 8
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_58

    sget-object p0, Landroid/graphics/PorterDuff$Mode;->SRC_OUT:Landroid/graphics/PorterDuff$Mode;

    goto/16 :goto_c9

    :cond_58
    const/16 v0, 0x8

    .line 9
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_64

    sget-object p0, Landroid/graphics/PorterDuff$Mode;->DST_OUT:Landroid/graphics/PorterDuff$Mode;

    goto/16 :goto_c9

    :cond_64
    const/16 v0, 0x9

    .line 10
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_6f

    sget-object p0, Landroid/graphics/PorterDuff$Mode;->SRC_ATOP:Landroid/graphics/PorterDuff$Mode;

    goto :goto_c9

    :cond_6f
    const/16 v0, 0xa

    .line 11
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_7a

    sget-object p0, Landroid/graphics/PorterDuff$Mode;->DST_ATOP:Landroid/graphics/PorterDuff$Mode;

    goto :goto_c9

    :cond_7a
    const/16 v0, 0xb

    .line 12
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_85

    sget-object p0, Landroid/graphics/PorterDuff$Mode;->XOR:Landroid/graphics/PorterDuff$Mode;

    goto :goto_c9

    :cond_85
    const/16 v0, 0xc

    .line 13
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_90

    sget-object p0, Landroid/graphics/PorterDuff$Mode;->ADD:Landroid/graphics/PorterDuff$Mode;

    goto :goto_c9

    :cond_90
    const/16 v0, 0xe

    .line 14
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_9b

    sget-object p0, Landroid/graphics/PorterDuff$Mode;->SCREEN:Landroid/graphics/PorterDuff$Mode;

    goto :goto_c9

    :cond_9b
    const/16 v0, 0xf

    .line 15
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_a6

    sget-object p0, Landroid/graphics/PorterDuff$Mode;->OVERLAY:Landroid/graphics/PorterDuff$Mode;

    goto :goto_c9

    :cond_a6
    const/16 v0, 0x10

    .line 16
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_b1

    sget-object p0, Landroid/graphics/PorterDuff$Mode;->DARKEN:Landroid/graphics/PorterDuff$Mode;

    goto :goto_c9

    :cond_b1
    const/16 v0, 0x11

    .line 17
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result v0

    if-eqz v0, :cond_bc

    sget-object p0, Landroid/graphics/PorterDuff$Mode;->LIGHTEN:Landroid/graphics/PorterDuff$Mode;

    goto :goto_c9

    :cond_bc
    const/16 v0, 0xd

    .line 18
    invoke-static {p0, v0}, Ld1/j;->a(II)Z

    move-result p0

    if-eqz p0, :cond_c7

    .line 19
    sget-object p0, Landroid/graphics/PorterDuff$Mode;->MULTIPLY:Landroid/graphics/PorterDuff$Mode;

    goto :goto_c9

    .line 20
    :cond_c7
    sget-object p0, Landroid/graphics/PorterDuff$Mode;->SRC_OVER:Landroid/graphics/PorterDuff$Mode;

    :goto_c9
    return-object p0
.end method

.method public static final K(FI)Ljava/lang/String;
    .registers 6

    const/4 v0, 0x0

    .line 1
    invoke-static {p1, v0}, Ljava/lang/Math;->max(II)I

    move-result p1

    const/high16 v0, 0x41200000    # 10.0f

    float-to-double v0, v0

    int-to-double v2, p1

    .line 2
    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v0

    double-to-float v0, v0

    mul-float p0, p0, v0

    float-to-int v1, p0

    int-to-float v2, v1

    sub-float/2addr p0, v2

    const/high16 v2, 0x3f000000    # 0.5f

    cmpl-float p0, p0, v2

    if-ltz p0, :cond_1b

    add-int/lit8 v1, v1, 0x1

    :cond_1b
    int-to-float p0, v1

    div-float/2addr p0, v0

    if-lez p1, :cond_24

    .line 3
    invoke-static {p0}, Ljava/lang/String;->valueOf(F)Ljava/lang/String;

    move-result-object p0

    goto :goto_29

    :cond_24
    float-to-int p0, p0

    .line 4
    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    :goto_29
    return-object p0
.end method

.method public static final L(IILa0/w;)La0/t0;
    .registers 4

    const-string v0, "easing"

    invoke-static {p2, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    new-instance v0, La0/t0;

    invoke-direct {v0, p0, p1, p2}, La0/t0;-><init>(IILa0/w;)V

    return-object v0
.end method

.method public static synthetic M(IILa0/w;I)La0/t0;
    .registers 5

    and-int/lit8 v0, p3, 0x1

    if-eqz v0, :cond_6

    const/16 p0, 0x12c

    :cond_6
    and-int/lit8 v0, p3, 0x2

    if-eqz v0, :cond_b

    const/4 p1, 0x0

    :cond_b
    and-int/lit8 p3, p3, 0x4

    if-eqz p3, :cond_11

    .line 1
    sget-object p2, La0/x;->a:La0/w;

    .line 2
    :cond_11
    invoke-static {p0, p1, p2}, Landroidx/activity/n;->L(IILa0/w;)La0/t0;

    move-result-object p0

    return-object p0
.end method

.method public static a(ILe2/t;III)Le2/i;
    .registers 11

    and-int/lit8 v0, p4, 0x2

    if-eqz v0, :cond_8

    .line 1
    sget-object p1, Le2/t;->b:Le2/t$a;

    .line 2
    sget-object p1, Le2/t;->n:Le2/t;

    :cond_8
    move-object v2, p1

    and-int/lit8 p1, p4, 0x4

    const/4 v0, 0x0

    if-eqz p1, :cond_10

    const/4 v3, 0x0

    goto :goto_11

    :cond_10
    move v3, p2

    :goto_11
    and-int/lit8 p1, p4, 0x8

    if-eqz p1, :cond_17

    const/4 v4, 0x0

    goto :goto_18

    :cond_17
    move v4, p3

    :goto_18
    const-string p1, "weight"

    .line 3
    invoke-static {v2, p1}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    new-instance p1, Le2/a0;

    const/4 v5, 0x0

    move-object v0, p1

    move v1, p0

    invoke-direct/range {v0 .. v5}, Le2/a0;-><init>(ILe2/t;IILwg/e;)V

    return-object p1
.end method

.method public static final b(II)J
    .registers 6

    int-to-long v0, p0

    const/16 p0, 0x20

    shl-long/2addr v0, p0

    int-to-long p0, p1

    const-wide v2, 0xffffffffL

    and-long/2addr p0, v2

    or-long/2addr p0, v0

    .line 1
    sget-object v0, Lp2/g;->b:Lp2/g$a;

    return-wide p0
.end method

.method public static final c(Ly0/h;Lm0/g;I)V
    .registers 9

    const-string v0, "modifier"

    invoke-static {p0, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const v0, -0x4581923

    invoke-interface {p1, v0}, Lm0/g;->e(I)V

    .line 1
    sget-object v0, Le0/b1;->a:Le0/b1;

    shl-int/lit8 p2, p2, 0x3

    and-int/lit8 p2, p2, 0x70

    or-int/lit16 p2, p2, 0x180

    const v1, -0x4ee9b9da

    invoke-interface {p1, v1}, Lm0/g;->e(I)V

    .line 2
    sget-object v1, Landroidx/compose/ui/platform/o0;->e:Lm0/e1;

    .line 3
    invoke-interface {p1, v1}, Lm0/g;->C(Lm0/w;)Ljava/lang/Object;

    move-result-object v1

    .line 4
    check-cast v1, Lp2/b;

    .line 5
    sget-object v2, Landroidx/compose/ui/platform/o0;->k:Lm0/e1;

    .line 6
    invoke-interface {p1, v2}, Lm0/g;->C(Lm0/w;)Ljava/lang/Object;

    move-result-object v2

    .line 7
    check-cast v2, Lp2/j;

    .line 8
    sget-object v3, Landroidx/compose/ui/platform/o0;->o:Lm0/e1;

    .line 9
    invoke-interface {p1, v3}, Lm0/g;->C(Lm0/w;)Ljava/lang/Object;

    move-result-object v3

    .line 10
    check-cast v3, Landroidx/compose/ui/platform/a2;

    .line 11
    sget-object v4, Lt1/a;->W:Lt1/a$a;

    invoke-static {v4}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    sget-object v4, Lt1/a$a;->b:Lvg/a;

    .line 13
    invoke-static {p0}, Lr1/q;->a(Ly0/h;)Lvg/q;

    move-result-object p0

    shl-int/lit8 p2, p2, 0x9

    and-int/lit16 p2, p2, 0x1c00

    or-int/lit8 p2, p2, 0x6

    .line 14
    invoke-interface {p1}, Lm0/g;->v()Lm0/d;

    move-result-object v5

    instance-of v5, v5, Lm0/d;

    if-eqz v5, :cond_a2

    .line 15
    invoke-interface {p1}, Lm0/g;->r()V

    .line 16
    invoke-interface {p1}, Lm0/g;->m()Z

    move-result v5

    if-eqz v5, :cond_57

    .line 17
    invoke-interface {p1, v4}, Lm0/g;->l(Lvg/a;)V

    goto :goto_5a

    .line 18
    :cond_57
    invoke-interface {p1}, Lm0/g;->G()V

    .line 19
    :goto_5a
    invoke-interface {p1}, Lm0/g;->u()V

    .line 20
    sget-object v4, Lt1/a$a;->e:Lvg/p;

    .line 21
    invoke-static {p1, v0, v4}, Landroidx/appcompat/widget/m;->R(Lm0/g;Ljava/lang/Object;Lvg/p;)V

    .line 22
    sget-object v0, Lt1/a$a;->d:Lvg/p;

    .line 23
    invoke-static {p1, v1, v0}, Landroidx/appcompat/widget/m;->R(Lm0/g;Ljava/lang/Object;Lvg/p;)V

    .line 24
    sget-object v0, Lt1/a$a;->f:Lvg/p;

    .line 25
    invoke-static {p1, v2, v0}, Landroidx/appcompat/widget/m;->R(Lm0/g;Ljava/lang/Object;Lvg/p;)V

    .line 26
    sget-object v0, Lt1/a$a;->g:Lvg/p;

    .line 27
    invoke-static {p1, v3, v0, p1}, Landroidx/activity/m;->b(Lm0/g;Landroidx/compose/ui/platform/a2;Lvg/p;Lm0/g;)Lm0/w1;

    move-result-object v0

    shr-int/lit8 v1, p2, 0x3

    and-int/lit8 v1, v1, 0x70

    .line 28
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    check-cast p0, Lt0/b;

    invoke-virtual {p0, v0, p1, v1}, Lt0/b;->w(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const p0, 0x7ab4aae9

    .line 29
    invoke-interface {p1, p0}, Lm0/g;->e(I)V

    shr-int/lit8 p0, p2, 0x9

    and-int/lit8 p0, p0, 0xe

    const p2, 0x44166c46

    .line 30
    invoke-interface {p1, p2}, Lm0/g;->e(I)V

    and-int/lit8 p0, p0, 0xb

    const/4 p2, 0x2

    if-ne p0, p2, :cond_9e

    .line 31
    invoke-interface {p1}, Lm0/g;->s()Z

    move-result p0

    if-nez p0, :cond_9b

    goto :goto_9e

    :cond_9b
    invoke-interface {p1}, Lm0/g;->A()V

    :cond_9e
    :goto_9e
    invoke-static {p1}, La0/x0;->b(Lm0/g;)V

    return-void

    .line 32
    :cond_a2
    invoke-static {}, Lgh/m1;->w()V

    const/4 p0, 0x0

    throw p0
.end method

.method public static final d([II)I
    .registers 3

    mul-int/lit8 p1, p1, 0x5

    .line 1
    array-length v0, p0

    if-lt p1, v0, :cond_7

    array-length p0, p0

    goto :goto_16

    :cond_7
    add-int/lit8 v0, p1, 0x4

    .line 2
    aget v0, p0, v0

    add-int/lit8 p1, p1, 0x1

    .line 3
    aget p0, p0, p1

    shr-int/lit8 p0, p0, 0x1d

    invoke-static {p0}, Landroidx/activity/n;->z(I)I

    move-result p0

    add-int/2addr p0, v0

    :goto_16
    return p0
.end method

.method public static final e(Ljava/util/List;I)V
    .registers 6

    .line 1
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result p0

    if-ltz p1, :cond_9

    if-ge p1, p0, :cond_9

    return-void

    .line 2
    :cond_9
    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    const-string v1, "Index "

    const-string v2, " is out of bounds. The list has "

    const-string v3, " elements."

    invoke-static {v1, p1, v2, p0, v3}, Landroidx/activity/k;->a(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static final f(Ljava/util/List;II)V
    .registers 6

    .line 1
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result p0

    if-gt p1, p2, :cond_3d

    if-ltz p1, :cond_2f

    if-gt p2, p0, :cond_b

    return-void

    .line 2
    :cond_b
    new-instance p1, Ljava/lang/IndexOutOfBoundsException;

    .line 3
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "toIndex ("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, ") is more than than the list size ("

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 p0, 0x29

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    .line 4
    invoke-direct {p1, p0}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 5
    :cond_2f
    new-instance p0, Ljava/lang/IndexOutOfBoundsException;

    const-string p2, "fromIndex ("

    const-string v0, ") is less than 0."

    invoke-static {p2, p1, v0}, Landroidx/activity/j;->a(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 6
    :cond_3d
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "Indices are out of order. fromIndex ("

    const-string v1, ") is greater than toIndex ("

    const-string v2, ")."

    invoke-static {v0, p1, v1, p2, v2}, Landroidx/activity/k;->a(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static final g([II)Z
    .registers 3

    mul-int/lit8 p1, p1, 0x5

    const/4 v0, 0x1

    add-int/2addr p1, v0

    .line 1
    aget p0, p0, p1

    const/high16 p1, 0x4000000

    and-int/2addr p0, p1

    if-eqz p0, :cond_c

    goto :goto_d

    :cond_c
    const/4 v0, 0x0

    :goto_d
    return v0
.end method

.method public static final h([II)I
    .registers 2

    mul-int/lit8 p1, p1, 0x5

    add-int/lit8 p1, p1, 0x4

    .line 1
    aget p0, p0, p1

    return p0
.end method

.method public static final i([II)I
    .registers 2

    mul-int/lit8 p1, p1, 0x5

    add-int/lit8 p1, p1, 0x3

    .line 1
    aget p0, p0, p1

    return p0
.end method

.method public static final j([II)Z
    .registers 3

    mul-int/lit8 p1, p1, 0x5

    const/4 v0, 0x1

    add-int/2addr p1, v0

    .line 1
    aget p0, p0, p1

    const/high16 p1, 0x10000000

    and-int/2addr p0, p1

    if-eqz p0, :cond_c

    goto :goto_d

    :cond_c
    const/4 v0, 0x0

    :goto_d
    return v0
.end method

.method public static final k([II)Z
    .registers 3

    mul-int/lit8 p1, p1, 0x5

    const/4 v0, 0x1

    add-int/2addr p1, v0

    .line 1
    aget p0, p0, p1

    const/high16 p1, 0x20000000

    and-int/2addr p0, p1

    if-eqz p0, :cond_c

    goto :goto_d

    :cond_c
    const/4 v0, 0x0

    :goto_d
    return v0
.end method

.method public static final l([II)Z
    .registers 3

    mul-int/lit8 p1, p1, 0x5

    const/4 v0, 0x1

    add-int/2addr p1, v0

    .line 1
    aget p0, p0, p1

    const/high16 p1, 0x40000000    # 2.0f

    and-int/2addr p0, p1

    if-eqz p0, :cond_c

    goto :goto_d

    :cond_c
    const/4 v0, 0x0

    :goto_d
    return v0
.end method

.method public static final m(Ljava/util/ArrayList;II)I
    .registers 3

    .line 1
    invoke-static {p0, p1, p2}, Landroidx/activity/n;->F(Ljava/util/ArrayList;II)I

    move-result p0

    if-ltz p0, :cond_7

    goto :goto_a

    :cond_7
    add-int/lit8 p0, p0, 0x1

    neg-int p0, p0

    :goto_a
    return p0
.end method

.method public static final n([II)I
    .registers 2

    mul-int/lit8 p1, p1, 0x5

    add-int/lit8 p1, p1, 0x1

    .line 1
    aget p0, p0, p1

    const p1, 0x3ffffff

    and-int/2addr p0, p1

    return p0
.end method

.method public static final o([II)I
    .registers 3

    mul-int/lit8 p1, p1, 0x5

    add-int/lit8 v0, p1, 0x4

    .line 1
    aget v0, p0, v0

    add-int/lit8 p1, p1, 0x1

    .line 2
    aget p0, p0, p1

    shr-int/lit8 p0, p0, 0x1e

    invoke-static {p0}, Landroidx/activity/n;->z(I)I

    move-result p0

    add-int/2addr p0, v0

    return p0
.end method

.method public static final p([II)I
    .registers 2

    mul-int/lit8 p1, p1, 0x5

    add-int/lit8 p1, p1, 0x2

    .line 1
    aget p0, p0, p1

    return p0
.end method

.method public static final q([II)I
    .registers 3

    mul-int/lit8 p1, p1, 0x5

    add-int/lit8 v0, p1, 0x4

    .line 1
    aget v0, p0, v0

    add-int/lit8 p1, p1, 0x1

    .line 2
    aget p0, p0, p1

    shr-int/lit8 p0, p0, 0x1c

    invoke-static {p0}, Landroidx/activity/n;->z(I)I

    move-result p0

    add-int/2addr p0, v0

    return p0
.end method

.method public static final r([III)V
    .registers 3

    mul-int/lit8 p1, p1, 0x5

    add-int/lit8 p1, p1, 0x4

    .line 1
    aput p2, p0, p1

    return-void
.end method

.method public static final s([III)V
    .registers 4

    if-ltz p2, :cond_4

    const/4 v0, 0x1

    goto :goto_5

    :cond_4
    const/4 v0, 0x0

    :goto_5
    if-eqz v0, :cond_e

    mul-int/lit8 p1, p1, 0x5

    add-int/lit8 p1, p1, 0x3

    .line 1
    aput p2, p0, p1

    return-void

    .line 2
    :cond_e
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Failed requirement."

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static final t([III)V
    .registers 5

    const/4 v0, 0x1

    if-ltz p2, :cond_a

    const v1, 0x3ffffff

    if-ge p2, v1, :cond_a

    const/4 v1, 0x1

    goto :goto_b

    :cond_a
    const/4 v1, 0x0

    :goto_b
    if-eqz v1, :cond_19

    mul-int/lit8 p1, p1, 0x5

    add-int/2addr p1, v0

    .line 1
    aget v0, p0, p1

    const/high16 v1, -0x4000000

    and-int/2addr v0, v1

    or-int/2addr p2, v0

    aput p2, p0, p1

    return-void

    .line 2
    :cond_19
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Failed requirement."

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static final u([III)V
    .registers 3

    mul-int/lit8 p1, p1, 0x5

    add-int/lit8 p1, p1, 0x2

    .line 1
    aput p2, p0, p1

    return-void
.end method

.method public static final v(Ly0/h;Ld1/k0;)Ly0/h;
    .registers 22

    move-object/from16 v0, p0

    move-object/from16 v13, p1

    const-string v1, "<this>"

    move-object/from16 v2, p0

    invoke-static {v2, v1}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const-wide/16 v11, 0x0

    const/4 v14, 0x1

    const-wide/16 v15, 0x0

    const-wide/16 v17, 0x0

    const v19, 0xe7ff

    .line 1
    invoke-static/range {v0 .. v19}, La6/d;->s(Ly0/h;FFFFFFFFFFJLd1/k0;ZJJI)Ly0/h;

    move-result-object v0

    return-object v0
.end method

.method public static final w(Ly0/h;)Ly0/h;
    .registers 21

    move-object/from16 v0, p0

    const-string v1, "<this>"

    move-object/from16 v2, p0

    invoke-static {v2, v1}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const-wide/16 v11, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x1

    const-wide/16 v15, 0x0

    const-wide/16 v17, 0x0

    const v19, 0xefff

    .line 1
    invoke-static/range {v0 .. v19}, La6/d;->s(Ly0/h;FFFFFFFFFFJLd1/k0;ZJJI)Ly0/h;

    move-result-object v0

    return-object v0
.end method

.method public static final x(JJ)F
    .registers 4

    .line 1
    invoke-static {p2, p3}, Lc1/f;->c(J)F

    move-result p2

    invoke-static {p0, p1}, Lc1/f;->c(J)F

    move-result p0

    div-float/2addr p2, p0

    return p2
.end method

.method public static final y(JJ)F
    .registers 4

    .line 1
    invoke-static {p2, p3}, Lc1/f;->e(J)F

    move-result p2

    invoke-static {p0, p1}, Lc1/f;->e(J)F

    move-result p0

    div-float/2addr p2, p0

    return p2
.end method

.method public static final z(I)I
    .registers 3

    const/4 v0, 0x2

    const/4 v1, 0x1

    packed-switch p0, :pswitch_data_c

    const/4 v0, 0x3

    goto :goto_a

    :pswitch_7
    const/4 v0, 0x1

    goto :goto_a

    :pswitch_9
    const/4 v0, 0x0

    :goto_a
    :pswitch_a
    return v0

    nop

    :pswitch_data_c
    .packed-switch 0x0
        :pswitch_9
        :pswitch_7
        :pswitch_7
        :pswitch_a
        :pswitch_7
        :pswitch_a
        :pswitch_a
    .end packed-switch
.end method
