.class public final La2/k;
.super Ljava/lang/Object;
.source "StaticLayoutFactory.kt"


# instance fields
.field public final a:Ljava/lang/CharSequence;

.field public final b:I

.field public final c:I

.field public final d:Landroid/text/TextPaint;

.field public final e:I

.field public final f:Landroid/text/TextDirectionHeuristic;

.field public final g:Landroid/text/Layout$Alignment;

.field public final h:I

.field public final i:Landroid/text/TextUtils$TruncateAt;

.field public final j:I

.field public final k:F

.field public final l:F

.field public final m:I

.field public final n:Z

.field public final o:Z

.field public final p:I

.field public final q:I

.field public final r:[I

.field public final s:[I


# direct methods
.method public constructor <init>(Ljava/lang/CharSequence;IILandroid/text/TextPaint;ILandroid/text/TextDirectionHeuristic;Landroid/text/Layout$Alignment;ILandroid/text/TextUtils$TruncateAt;IFFIZZII[I[I)V
    .registers 31

    move-object v0, p0

    move v1, p2

    move v2, p3

    move/from16 v3, p5

    move/from16 v4, p8

    move/from16 v5, p10

    move/from16 v6, p11

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    move-object v7, p1

    .line 2
    iput-object v7, v0, La2/k;->a:Ljava/lang/CharSequence;

    .line 3
    iput v1, v0, La2/k;->b:I

    .line 4
    iput v2, v0, La2/k;->c:I

    move-object v8, p4

    .line 5
    iput-object v8, v0, La2/k;->d:Landroid/text/TextPaint;

    .line 6
    iput v3, v0, La2/k;->e:I

    move-object/from16 v8, p6

    .line 7
    iput-object v8, v0, La2/k;->f:Landroid/text/TextDirectionHeuristic;

    move-object/from16 v8, p7

    .line 8
    iput-object v8, v0, La2/k;->g:Landroid/text/Layout$Alignment;

    .line 9
    iput v4, v0, La2/k;->h:I

    move-object/from16 v8, p9

    .line 10
    iput-object v8, v0, La2/k;->i:Landroid/text/TextUtils$TruncateAt;

    .line 11
    iput v5, v0, La2/k;->j:I

    .line 12
    iput v6, v0, La2/k;->k:F

    move/from16 v8, p12

    .line 13
    iput v8, v0, La2/k;->l:F

    move/from16 v8, p13

    .line 14
    iput v8, v0, La2/k;->m:I

    move/from16 v8, p14

    .line 15
    iput-boolean v8, v0, La2/k;->n:Z

    move/from16 v8, p15

    .line 16
    iput-boolean v8, v0, La2/k;->o:Z

    move/from16 v8, p16

    .line 17
    iput v8, v0, La2/k;->p:I

    move/from16 v8, p17

    .line 18
    iput v8, v0, La2/k;->q:I

    move-object/from16 v8, p18

    .line 19
    iput-object v8, v0, La2/k;->r:[I

    move-object/from16 v8, p19

    .line 20
    iput-object v8, v0, La2/k;->s:[I

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-ltz v1, :cond_54

    if-gt v1, v2, :cond_54

    const/4 v1, 0x1

    goto :goto_55

    :cond_54
    const/4 v1, 0x0

    :goto_55
    const-string v10, "Failed requirement."

    if-eqz v1, :cond_b6

    .line 21
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    if-ltz v2, :cond_63

    if-gt v2, v1, :cond_63

    const/4 v1, 0x1

    goto :goto_64

    :cond_63
    const/4 v1, 0x0

    :goto_64
    if-eqz v1, :cond_ac

    if-ltz v4, :cond_6a

    const/4 v1, 0x1

    goto :goto_6b

    :cond_6a
    const/4 v1, 0x0

    :goto_6b
    if-eqz v1, :cond_a2

    if-ltz v3, :cond_71

    const/4 v1, 0x1

    goto :goto_72

    :cond_71
    const/4 v1, 0x0

    :goto_72
    if-eqz v1, :cond_98

    if-ltz v5, :cond_78

    const/4 v1, 0x1

    goto :goto_79

    :cond_78
    const/4 v1, 0x0

    :goto_79
    if-eqz v1, :cond_8e

    const/4 v1, 0x0

    cmpl-float v1, v6, v1

    if-ltz v1, :cond_81

    const/4 v8, 0x1

    :cond_81
    if-eqz v8, :cond_84

    return-void

    .line 22
    :cond_84
    new-instance v1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 23
    :cond_8e
    new-instance v1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 24
    :cond_98
    new-instance v1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 25
    :cond_a2
    new-instance v1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 26
    :cond_ac
    new-instance v1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 27
    :cond_b6
    new-instance v1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1
.end method
