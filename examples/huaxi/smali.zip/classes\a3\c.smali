.class public La3/c;
.super Ljava/lang/Object;
.source "ActivityRecreator.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:La3/f$a;

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public constructor <init>(La3/f$a;Ljava/lang/Object;)V
    .registers 3

    .line 1
    iput-object p1, p0, La3/c;->a:La3/f$a;

    iput-object p2, p0, La3/c;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 3

    .line 1
    iget-object v0, p0, La3/c;->a:La3/f$a;

    iget-object v1, p0, La3/c;->b:Ljava/lang/Object;

    iput-object v1, v0, La3/f$a;->a:Ljava/lang/Object;

    return-void
.end method
