.class public La6/h;
.super Ljava/lang/Object;
.source "LottieCompositionFactory.java"


# static fields
.field public static final a:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "La6/u<",
            "La6/g;",
            ">;>;"
        }
    .end annotation
.end field

.field public static final b:[B


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, La6/h;->a:Ljava/util/Map;

    const/4 v0, 0x4

    new-array v0, v0, [B

    .line 2
    fill-array-data v0, :array_10

    sput-object v0, La6/h;->b:[B

    return-void

    :array_10
    .array-data 1
        0x50t
        0x4bt
        0x3t
        0x4t
    .end array-data
.end method

.method public static a(Ljava/lang/String;Ljava/util/concurrent/Callable;)La6/u;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/concurrent/Callable<",
            "La6/s<",
            "La6/g;",
            ">;>;)",
            "La6/u<",
            "La6/g;",
            ">;"
        }
    .end annotation

    if-nez p0, :cond_4

    const/4 v0, 0x0

    goto :goto_11

    .line 1
    :cond_4
    sget-object v0, Lf6/g;->b:Lf6/g;

    .line 2
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 3
    iget-object v0, v0, Lf6/g;->a:Ly/e;

    invoke-virtual {v0, p0}, Ly/e;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La6/g;

    :goto_11
    const/4 v1, 0x0

    if-eqz v0, :cond_1f

    .line 4
    new-instance p0, La6/u;

    new-instance p1, La6/h$c;

    invoke-direct {p1, v0}, La6/h$c;-><init>(La6/g;)V

    .line 5
    invoke-direct {p0, p1, v1}, La6/u;-><init>(Ljava/util/concurrent/Callable;Z)V

    return-object p0

    :cond_1f
    if-eqz p0, :cond_32

    .line 6
    sget-object v0, La6/h;->a:Ljava/util/Map;

    check-cast v0, Ljava/util/HashMap;

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_32

    .line 7
    invoke-virtual {v0, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, La6/u;

    return-object p0

    .line 8
    :cond_32
    new-instance v0, La6/u;

    .line 9
    invoke-direct {v0, p1, v1}, La6/u;-><init>(Ljava/util/concurrent/Callable;Z)V

    if-eqz p0, :cond_50

    .line 10
    new-instance p1, La6/h$a;

    invoke-direct {p1, p0}, La6/h$a;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, La6/u;->b(La6/o;)La6/u;

    .line 11
    new-instance p1, La6/h$b;

    invoke-direct {p1, p0}, La6/h$b;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, La6/u;->a(La6/o;)La6/u;

    .line 12
    sget-object p1, La6/h;->a:Ljava/util/Map;

    check-cast p1, Ljava/util/HashMap;

    invoke-virtual {p1, p0, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_50
    return-object v0
.end method

.method public static b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)La6/s;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "La6/s<",
            "La6/g;",
            ">;"
        }
    .end annotation

    :try_start_0
    const-string v0, ".zip"

    .line 1
    invoke-virtual {p1, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_1e

    const-string v0, ".lottie"

    invoke-virtual {p1, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_11

    goto :goto_1e

    .line 2
    :cond_11
    invoke-virtual {p0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object p0

    invoke-static {p0, p2}, La6/h;->c(Ljava/io/InputStream;Ljava/lang/String;)La6/s;

    move-result-object p0

    return-object p0

    .line 3
    :cond_1e
    :goto_1e
    new-instance v0, Ljava/util/zip/ZipInputStream;

    invoke-virtual {p0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/util/zip/ZipInputStream;-><init>(Ljava/io/InputStream;)V

    invoke-static {v0, p2}, La6/h;->f(Ljava/util/zip/ZipInputStream;Ljava/lang/String;)La6/s;

    move-result-object p0
    :try_end_2f
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_2f} :catch_30

    return-object p0

    :catch_30
    move-exception p0

    .line 4
    new-instance p1, La6/s;

    invoke-direct {p1, p0}, La6/s;-><init>(Ljava/lang/Throwable;)V

    return-object p1
.end method

.method public static c(Ljava/io/InputStream;Ljava/lang/String;)La6/s;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/InputStream;",
            "Ljava/lang/String;",
            ")",
            "La6/s<",
            "La6/g;",
            ">;"
        }
    .end annotation

    .line 1
    :try_start_0
    invoke-static {p0}, Lei/q;->h(Ljava/io/InputStream;)Lei/c0;

    move-result-object v0

    invoke-static {v0}, Lei/q;->c(Lei/c0;)Lei/i;

    move-result-object v0

    sget-object v1, Ll6/c;->e:[Ljava/lang/String;

    .line 2
    new-instance v1, Ll6/e;

    invoke-direct {v1, v0}, Ll6/e;-><init>(Lei/i;)V

    const/4 v0, 0x1

    .line 3
    invoke-static {v1, p1, v0}, La6/h;->d(Ll6/c;Ljava/lang/String;Z)La6/s;

    move-result-object p1
    :try_end_14
    .catchall {:try_start_0 .. :try_end_14} :catchall_18

    .line 4
    invoke-static {p0}, Lm6/g;->b(Ljava/io/Closeable;)V

    return-object p1

    :catchall_18
    move-exception p1

    invoke-static {p0}, Lm6/g;->b(Ljava/io/Closeable;)V

    .line 5
    throw p1
.end method

.method public static d(Ll6/c;Ljava/lang/String;Z)La6/s;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ll6/c;",
            "Ljava/lang/String;",
            "Z)",
            "La6/s<",
            "La6/g;",
            ">;"
        }
    .end annotation

    .line 1
    :try_start_0
    invoke-static {p0}, Lk6/w;->a(Ll6/c;)La6/g;

    move-result-object v0

    if-eqz p1, :cond_b

    .line 2
    sget-object v1, Lf6/g;->b:Lf6/g;

    .line 3
    invoke-virtual {v1, p1, v0}, Lf6/g;->a(Ljava/lang/String;La6/g;)V

    .line 4
    :cond_b
    new-instance p1, La6/s;

    invoke-direct {p1, v0}, La6/s;-><init>(Ljava/lang/Object;)V
    :try_end_10
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_10} :catch_18
    .catchall {:try_start_0 .. :try_end_10} :catchall_16

    if-eqz p2, :cond_15

    .line 5
    invoke-static {p0}, Lm6/g;->b(Ljava/io/Closeable;)V

    :cond_15
    return-object p1

    :catchall_16
    move-exception p1

    goto :goto_24

    :catch_18
    move-exception p1

    .line 6
    :try_start_19
    new-instance v0, La6/s;

    invoke-direct {v0, p1}, La6/s;-><init>(Ljava/lang/Throwable;)V
    :try_end_1e
    .catchall {:try_start_19 .. :try_end_1e} :catchall_16

    if-eqz p2, :cond_23

    .line 7
    invoke-static {p0}, Lm6/g;->b(Ljava/io/Closeable;)V

    :cond_23
    return-object v0

    :goto_24
    if-eqz p2, :cond_29

    invoke-static {p0}, Lm6/g;->b(Ljava/io/Closeable;)V

    .line 8
    :cond_29
    throw p1
.end method

.method public static e(Landroid/content/Context;ILjava/lang/String;)La6/s;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "I",
            "Ljava/lang/String;",
            ")",
            "La6/s<",
            "La6/g;",
            ">;"
        }
    .end annotation

    .line 1
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->openRawResource(I)Ljava/io/InputStream;

    move-result-object p0

    invoke-static {p0}, Lei/q;->h(Ljava/io/InputStream;)Lei/c0;

    move-result-object p0

    invoke-static {p0}, Lei/q;->c(Lei/c0;)Lei/i;

    move-result-object p0
    :try_end_10
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_0 .. :try_end_10} :catch_60

    .line 2
    :try_start_10
    move-object p1, p0

    check-cast p1, Lei/w;

    invoke-virtual {p1}, Lei/w;->b()Lei/i;

    move-result-object p1

    .line 3
    sget-object v0, La6/h;->b:[B

    array-length v1, v0

    const/4 v2, 0x0

    :goto_1b
    if-ge v2, v1, :cond_2e

    aget-byte v3, v0, v2

    .line 4
    move-object v4, p1

    check-cast v4, Lei/w;

    invoke-virtual {v4}, Lei/w;->readByte()B

    move-result v4

    if-eq v4, v3, :cond_2b

    .line 5
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    goto :goto_3d

    :cond_2b
    add-int/lit8 v2, v2, 0x1

    goto :goto_1b

    .line 6
    :cond_2e
    check-cast p1, Lei/w;

    invoke-virtual {p1}, Lei/w;->close()V

    .line 7
    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;
    :try_end_35
    .catch Ljava/lang/Exception; {:try_start_10 .. :try_end_35} :catch_36

    goto :goto_3d

    .line 8
    :catch_36
    :try_start_36
    sget-object p1, Lm6/c;->a:La6/p;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 10
    :goto_3d
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_54

    .line 11
    new-instance p1, Ljava/util/zip/ZipInputStream;

    check-cast p0, Lei/w;

    .line 12
    new-instance v0, Lei/w$a;

    invoke-direct {v0, p0}, Lei/w$a;-><init>(Lei/w;)V

    .line 13
    invoke-direct {p1, v0}, Ljava/util/zip/ZipInputStream;-><init>(Ljava/io/InputStream;)V

    invoke-static {p1, p2}, La6/h;->f(Ljava/util/zip/ZipInputStream;Ljava/lang/String;)La6/s;

    move-result-object p0

    return-object p0

    .line 14
    :cond_54
    check-cast p0, Lei/w;

    .line 15
    new-instance p1, Lei/w$a;

    invoke-direct {p1, p0}, Lei/w$a;-><init>(Lei/w;)V

    .line 16
    invoke-static {p1, p2}, La6/h;->c(Ljava/io/InputStream;Ljava/lang/String;)La6/s;

    move-result-object p0
    :try_end_5f
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_36 .. :try_end_5f} :catch_60

    return-object p0

    :catch_60
    move-exception p0

    .line 17
    new-instance p1, La6/s;

    invoke-direct {p1, p0}, La6/s;-><init>(Ljava/lang/Throwable;)V

    return-object p1
.end method

.method public static f(Ljava/util/zip/ZipInputStream;Ljava/lang/String;)La6/s;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/zip/ZipInputStream;",
            "Ljava/lang/String;",
            ")",
            "La6/s<",
            "La6/g;",
            ">;"
        }
    .end annotation

    .line 1
    :try_start_0
    invoke-static {p0, p1}, La6/h;->g(Ljava/util/zip/ZipInputStream;Ljava/lang/String;)La6/s;

    move-result-object p1
    :try_end_4
    .catchall {:try_start_0 .. :try_end_4} :catchall_8

    .line 2
    invoke-static {p0}, Lm6/g;->b(Ljava/io/Closeable;)V

    return-object p1

    :catchall_8
    move-exception p1

    invoke-static {p0}, Lm6/g;->b(Ljava/io/Closeable;)V

    .line 3
    throw p1
.end method

.method public static g(Ljava/util/zip/ZipInputStream;Ljava/lang/String;)La6/s;
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/zip/ZipInputStream;",
            "Ljava/lang/String;",
            ")",
            "La6/s<",
            "La6/g;",
            ">;"
        }
    .end annotation

    .line 1
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 2
    :try_start_5
    invoke-virtual {p0}, Ljava/util/zip/ZipInputStream;->getNextEntry()Ljava/util/zip/ZipEntry;

    move-result-object v1

    const/4 v2, 0x0

    move-object v3, v2

    :goto_b
    if-eqz v1, :cond_90

    .line 3
    invoke-virtual {v1}, Ljava/util/zip/ZipEntry;->getName()Ljava/lang/String;

    move-result-object v4

    const-string v5, "__MACOSX"

    .line 4
    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_1d

    .line 5
    invoke-virtual {p0}, Ljava/util/zip/ZipInputStream;->closeEntry()V

    goto :goto_8a

    .line 6
    :cond_1d
    invoke-virtual {v1}, Ljava/util/zip/ZipEntry;->getName()Ljava/lang/String;

    move-result-object v5

    const-string v6, "manifest.json"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_2d

    .line 7
    invoke-virtual {p0}, Ljava/util/zip/ZipInputStream;->closeEntry()V

    goto :goto_8a

    .line 8
    :cond_2d
    invoke-virtual {v1}, Ljava/util/zip/ZipEntry;->getName()Ljava/lang/String;

    move-result-object v1

    const-string v5, ".json"

    invoke-virtual {v1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_53

    .line 9
    invoke-static {p0}, Lei/q;->h(Ljava/io/InputStream;)Lei/c0;

    move-result-object v1

    invoke-static {v1}, Lei/q;->c(Lei/c0;)Lei/i;

    move-result-object v1

    sget-object v3, Ll6/c;->e:[Ljava/lang/String;

    .line 10
    new-instance v3, Ll6/e;

    invoke-direct {v3, v1}, Ll6/e;-><init>(Lei/i;)V

    const/4 v1, 0x0

    .line 11
    invoke-static {v3, v2, v1}, La6/h;->d(Ll6/c;Ljava/lang/String;Z)La6/s;

    move-result-object v1

    .line 12
    iget-object v1, v1, La6/s;->a:Ljava/lang/Object;

    .line 13
    move-object v3, v1

    check-cast v3, La6/g;

    goto :goto_8a

    :cond_53
    const-string v1, ".png"

    .line 14
    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_78

    const-string v1, ".webp"

    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_78

    const-string v1, ".jpg"

    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_78

    const-string v1, ".jpeg"

    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_74

    goto :goto_78

    .line 15
    :cond_74
    invoke-virtual {p0}, Ljava/util/zip/ZipInputStream;->closeEntry()V

    goto :goto_8a

    :cond_78
    :goto_78
    const-string v1, "/"

    .line 16
    invoke-virtual {v4, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    .line 17
    array-length v4, v1

    add-int/lit8 v4, v4, -0x1

    aget-object v1, v1, v4

    .line 18
    invoke-static {p0}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Bitmap;

    move-result-object v4

    invoke-virtual {v0, v1, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    :goto_8a
    invoke-virtual {p0}, Ljava/util/zip/ZipInputStream;->getNextEntry()Ljava/util/zip/ZipEntry;

    move-result-object v1
    :try_end_8e
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_8e} :catch_139

    goto/16 :goto_b

    :cond_90
    if-nez v3, :cond_9f

    .line 20
    new-instance p0, La6/s;

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "Unable to parse composition"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    invoke-direct {p0, p1}, La6/s;-><init>(Ljava/lang/Throwable;)V

    return-object p0

    .line 21
    :cond_9f
    invoke-virtual {v0}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_a7
    :goto_a7
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_ec

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    .line 22
    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 23
    iget-object v4, v3, La6/g;->d:Ljava/util/Map;

    .line 24
    invoke-interface {v4}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_c3
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_d8

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La6/n;

    .line 25
    iget-object v6, v5, La6/n;->d:Ljava/lang/String;

    .line 26
    invoke-virtual {v6, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_c3

    goto :goto_d9

    :cond_d8
    move-object v5, v2

    :goto_d9
    if-eqz v5, :cond_a7

    .line 27
    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/graphics/Bitmap;

    .line 28
    iget v1, v5, La6/n;->a:I

    .line 29
    iget v4, v5, La6/n;->b:I

    .line 30
    invoke-static {v0, v1, v4}, Lm6/g;->e(Landroid/graphics/Bitmap;II)Landroid/graphics/Bitmap;

    move-result-object v0

    .line 31
    iput-object v0, v5, La6/n;->e:Landroid/graphics/Bitmap;

    goto :goto_a7

    .line 32
    :cond_ec
    iget-object p0, v3, La6/g;->d:Ljava/util/Map;

    .line 33
    invoke-interface {p0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_f6
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_12c

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    .line 34
    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La6/n;

    .line 35
    iget-object v1, v1, La6/n;->e:Landroid/graphics/Bitmap;

    if-nez v1, :cond_f6

    .line 36
    new-instance p0, La6/s;

    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v1, "There is no image for "

    invoke-static {v1}, Landroid/support/v4/media/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La6/n;

    .line 37
    iget-object v0, v0, La6/n;->d:Ljava/lang/String;

    .line 38
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    invoke-direct {p0, p1}, La6/s;-><init>(Ljava/lang/Throwable;)V

    return-object p0

    :cond_12c
    if-eqz p1, :cond_133

    .line 39
    sget-object p0, Lf6/g;->b:Lf6/g;

    .line 40
    invoke-virtual {p0, p1, v3}, Lf6/g;->a(Ljava/lang/String;La6/g;)V

    .line 41
    :cond_133
    new-instance p0, La6/s;

    invoke-direct {p0, v3}, La6/s;-><init>(Ljava/lang/Object;)V

    return-object p0

    :catch_139
    move-exception p0

    .line 42
    new-instance p1, La6/s;

    invoke-direct {p1, p0}, La6/s;-><init>(Ljava/lang/Throwable;)V

    return-object p1
.end method

.method public static h(Landroid/content/Context;I)Ljava/lang/String;
    .registers 4

    const-string v0, "rawRes"

    .line 1
    invoke-static {v0}, Landroid/support/v4/media/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 2
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p0

    iget p0, p0, Landroid/content/res/Configuration;->uiMode:I

    and-int/lit8 p0, p0, 0x30

    const/16 v1, 0x20

    if-ne p0, v1, :cond_18

    const/4 p0, 0x1

    goto :goto_19

    :cond_18
    const/4 p0, 0x0

    :goto_19
    if-eqz p0, :cond_1e

    const-string p0, "_night_"

    goto :goto_20

    :cond_1e
    const-string p0, "_day_"

    .line 3
    :goto_20
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
