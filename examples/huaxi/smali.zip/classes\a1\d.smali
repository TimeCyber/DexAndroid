.class public interface abstract La1/d;
.super Ljava/lang/Object;
.source "DrawModifier.kt"

# interfaces
.implements La1/f;


# virtual methods
.method public abstract h0(La1/a;)V
.end method
