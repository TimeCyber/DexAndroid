.class public final La2/l;
.super Ljava/lang/Object;
.source "TextLayout.kt"


# static fields
.field public static final a:La2/l;

.field public static final b:Landroid/text/Layout$Alignment;

.field public static final c:Landroid/text/Layout$Alignment;


# direct methods
.method public static constructor <clinit>()V
    .registers 8

    .line 1
    invoke-static {}, Landroid/text/Layout$Alignment;->values()[Landroid/text/Layout$Alignment;

    move-result-object v0

    .line 2
    sget-object v1, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    .line 3
    array-length v2, v0

    const/4 v3, 0x0

    move-object v3, v1

    const/4 v4, 0x0

    :goto_a
    if-ge v4, v2, :cond_2c

    aget-object v5, v0, v4

    .line 4
    invoke-virtual {v5}, Landroid/text/Layout$Alignment;->name()Ljava/lang/String;

    move-result-object v6

    const-string v7, "ALIGN_LEFT"

    invoke-static {v6, v7}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_1c

    move-object v1, v5

    goto :goto_29

    .line 5
    :cond_1c
    invoke-virtual {v5}, Landroid/text/Layout$Alignment;->name()Ljava/lang/String;

    move-result-object v6

    const-string v7, "ALIGN_RIGHT"

    invoke-static {v6, v7}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_29

    move-object v3, v5

    :cond_29
    :goto_29
    add-int/lit8 v4, v4, 0x1

    goto :goto_a

    .line 6
    :cond_2c
    sput-object v1, La2/l;->b:Landroid/text/Layout$Alignment;

    .line 7
    sput-object v3, La2/l;->c:Landroid/text/Layout$Alignment;

    return-void
.end method
