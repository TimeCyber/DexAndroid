.class public La7/f;
.super Ljava/lang/Object;
.source "CacheDiskUtils.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Ljava/io/File;

.field public final synthetic b:La7/e$c;


# direct methods
.method public constructor <init>(La7/e$c;Ljava/io/File;)V
    .registers 3

    .line 1
    iput-object p1, p0, La7/f;->b:La7/e$c;

    iput-object p2, p0, La7/f;->a:Ljava/io/File;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 11

    .line 1
    iget-object v0, p0, La7/f;->a:Ljava/io/File;

    new-instance v1, La7/f$a;

    invoke-direct {v1, p0}, La7/f$a;-><init>(La7/f;)V

    invoke-virtual {v0, v1}, Ljava/io/File;->listFiles(Ljava/io/FilenameFilter;)[Ljava/io/File;

    move-result-object v0

    if-eqz v0, :cond_3f

    .line 2
    array-length v1, v0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_11
    if-ge v2, v1, :cond_30

    aget-object v5, v0, v2

    int-to-long v6, v3

    .line 3
    invoke-virtual {v5}, Ljava/io/File;->length()J

    move-result-wide v8

    add-long/2addr v8, v6

    long-to-int v3, v8

    add-int/lit8 v4, v4, 0x1

    .line 4
    iget-object v6, p0, La7/f;->b:La7/e$c;

    .line 5
    iget-object v6, v6, La7/e$c;->e:Ljava/util/Map;

    .line 6
    invoke-virtual {v5}, Ljava/io/File;->lastModified()J

    move-result-wide v7

    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v7

    invoke-interface {v6, v5, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v2, v2, 0x1

    goto :goto_11

    .line 7
    :cond_30
    iget-object v0, p0, La7/f;->b:La7/e$c;

    .line 8
    iget-object v0, v0, La7/e$c;->a:Ljava/util/concurrent/atomic/AtomicLong;

    int-to-long v1, v3

    .line 9
    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicLong;->getAndAdd(J)J

    .line 10
    iget-object v0, p0, La7/f;->b:La7/e$c;

    .line 11
    iget-object v0, v0, La7/e$c;->b:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 12
    invoke-virtual {v0, v4}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndAdd(I)I

    :cond_3f
    return-void
.end method
