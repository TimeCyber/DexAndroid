.class public final La0/h1;
.super Ljava/lang/Object;
.source "VectorizedAnimationSpec.kt"

# interfaces
.implements La0/d1;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<V:",
        "La0/n;",
        ">",
        "Ljava/lang/Object;",
        "La0/d1<",
        "TV;>;"
    }
.end annotation


# instance fields
.field public final a:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Lkg/e<",
            "TV;",
            "La0/w;",
            ">;>;"
        }
    .end annotation
.end field

.field public final b:I

.field public final c:I

.field public d:La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field

.field public e:La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/util/Map;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "+",
            "Lkg/e<",
            "+TV;+",
            "La0/w;",
            ">;>;II)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, La0/h1;->a:Ljava/util/Map;

    .line 3
    iput p2, p0, La0/h1;->b:I

    .line 4
    iput p3, p0, La0/h1;->c:I

    return-void
.end method


# virtual methods
.method public synthetic a()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public synthetic b(La0/n;La0/n;La0/n;)J
    .registers 4

    invoke-static {p0, p1, p2, p3}, La0/c1;->a(La0/d1;La0/n;La0/n;La0/n;)J

    move-result-wide p1

    return-wide p1
.end method

.method public c(JLa0/n;La0/n;La0/n;)La0/n;
    .registers 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JTV;TV;TV;)TV;"
        }
    .end annotation

    const-string v0, "initialValue"

    invoke-static {p3, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "targetValue"

    invoke-static {p4, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "initialVelocity"

    invoke-static {p5, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-wide/32 v0, 0xf4240

    .line 1
    div-long/2addr p1, v0

    .line 2
    invoke-static {p0, p1, p2}, Lm/d;->d(La0/d1;J)J

    move-result-wide v1

    const-wide/16 p1, 0x0

    cmp-long v0, v1, p1

    if-gtz v0, :cond_1e

    return-object p5

    :cond_1e
    const-wide/16 p1, 0x1

    sub-long v4, v1, p1

    move-object v3, p0

    move-object v6, p3

    move-object v7, p4

    move-object v8, p5

    .line 3
    invoke-static/range {v3 .. v8}, Lm/d;->k(La0/y0;JLa0/n;La0/n;La0/n;)La0/n;

    move-result-object p1

    move-object v0, p0

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    .line 4
    invoke-static/range {v0 .. v5}, Lm/d;->k(La0/y0;JLa0/n;La0/n;La0/n;)La0/n;

    move-result-object p2

    .line 5
    iget-object p4, p0, La0/h1;->d:La0/n;

    if-nez p4, :cond_42

    .line 6
    invoke-static {p3}, Landroidx/appcompat/widget/m;->M(La0/n;)La0/n;

    move-result-object p4

    iput-object p4, p0, La0/h1;->d:La0/n;

    .line 7
    invoke-static {p3}, Landroidx/appcompat/widget/m;->M(La0/n;)La0/n;

    move-result-object p3

    iput-object p3, p0, La0/h1;->e:La0/n;

    :cond_42
    const/4 p3, 0x0

    .line 8
    invoke-virtual {p1}, La0/n;->b()I

    move-result p4

    :goto_47
    const-string p5, "velocityVector"

    const/4 v0, 0x0

    if-ge p3, p4, :cond_67

    .line 9
    iget-object v1, p0, La0/h1;->e:La0/n;

    if-eqz v1, :cond_63

    invoke-virtual {p1, p3}, La0/n;->a(I)F

    move-result p5

    invoke-virtual {p2, p3}, La0/n;->a(I)F

    move-result v0

    sub-float/2addr p5, v0

    const/high16 v0, 0x447a0000    # 1000.0f

    mul-float p5, p5, v0

    invoke-virtual {v1, p3, p5}, La0/n;->e(IF)V

    add-int/lit8 p3, p3, 0x1

    goto :goto_47

    :cond_63
    invoke-static {p5}, Lp/h;->b0(Ljava/lang/String;)V

    throw v0

    .line 10
    :cond_67
    iget-object p1, p0, La0/h1;->e:La0/n;

    if-eqz p1, :cond_6c

    return-object p1

    :cond_6c
    invoke-static {p5}, Lp/h;->b0(Ljava/lang/String;)V

    throw v0
.end method

.method public synthetic d(La0/n;La0/n;La0/n;)La0/n;
    .registers 4

    invoke-static {p0, p1, p2, p3}, La0/x0;->a(La0/y0;La0/n;La0/n;La0/n;)La0/n;

    move-result-object p1

    return-object p1
.end method

.method public e(JLa0/n;La0/n;La0/n;)La0/n;
    .registers 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JTV;TV;TV;)TV;"
        }
    .end annotation

    const-string v0, "initialValue"

    invoke-static {p3, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "targetValue"

    invoke-static {p4, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "initialVelocity"

    invoke-static {p5, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-wide/32 v0, 0xf4240

    .line 1
    div-long/2addr p1, v0

    .line 2
    invoke-static {p0, p1, p2}, Lm/d;->d(La0/d1;J)J

    move-result-wide p1

    long-to-int p2, p1

    .line 3
    iget-object p1, p0, La0/h1;->a:Ljava/util/Map;

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p5

    invoke-interface {p1, p5}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_35

    .line 4
    iget-object p1, p0, La0/h1;->a:Ljava/util/Map;

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    invoke-static {p1, p2}, Llg/a0;->Y(Ljava/util/Map;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lkg/e;

    .line 5
    iget-object p1, p1, Lkg/e;->a:Ljava/lang/Object;

    .line 6
    check-cast p1, La0/n;

    return-object p1

    .line 7
    :cond_35
    iget p1, p0, La0/h1;->b:I

    if-lt p2, p1, :cond_3a

    return-object p4

    :cond_3a
    if-gtz p2, :cond_3d

    return-object p3

    .line 8
    :cond_3d
    sget-object p5, La0/x$a;->a:La0/x$a;

    .line 9
    iget-object v0, p0, La0/h1;->a:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v1, 0x0

    move-object v3, p3

    const/4 v2, 0x0

    :cond_4c
    :goto_4c
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_82

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/Map$Entry;

    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Number;

    invoke-virtual {v5}, Ljava/lang/Number;->intValue()I

    move-result v5

    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lkg/e;

    if-le p2, v5, :cond_77

    if-lt v5, v2, :cond_77

    .line 10
    iget-object p5, v4, Lkg/e;->a:Ljava/lang/Object;

    .line 11
    move-object v3, p5

    check-cast v3, La0/n;

    .line 12
    iget-object p5, v4, Lkg/e;->b:Ljava/lang/Object;

    .line 13
    check-cast p5, La0/w;

    move v2, v5

    goto :goto_4c

    :cond_77
    if-ge p2, v5, :cond_4c

    if-gt v5, p1, :cond_4c

    .line 14
    iget-object p1, v4, Lkg/e;->a:Ljava/lang/Object;

    .line 15
    move-object p4, p1

    check-cast p4, La0/n;

    move p1, v5

    goto :goto_4c

    :cond_82
    sub-int/2addr p2, v2

    int-to-float p2, p2

    sub-int/2addr p1, v2

    int-to-float p1, p1

    div-float/2addr p2, p1

    .line 16
    invoke-interface {p5, p2}, La0/w;->a(F)F

    move-result p1

    .line 17
    iget-object p2, p0, La0/h1;->d:La0/n;

    if-nez p2, :cond_9b

    .line 18
    invoke-static {p3}, Landroidx/appcompat/widget/m;->M(La0/n;)La0/n;

    move-result-object p2

    iput-object p2, p0, La0/h1;->d:La0/n;

    .line 19
    invoke-static {p3}, Landroidx/appcompat/widget/m;->M(La0/n;)La0/n;

    move-result-object p2

    iput-object p2, p0, La0/h1;->e:La0/n;

    .line 20
    :cond_9b
    invoke-virtual {v3}, La0/n;->b()I

    move-result p2

    :goto_9f
    const-string p3, "valueVector"

    const/4 p5, 0x0

    if-ge v1, p2, :cond_c4

    .line 21
    iget-object v0, p0, La0/h1;->d:La0/n;

    if-eqz v0, :cond_c0

    invoke-virtual {v3, v1}, La0/n;->a(I)F

    move-result p3

    invoke-virtual {p4, v1}, La0/n;->a(I)F

    move-result p5

    sget-object v2, La0/w0;->a:La0/u0;

    const/4 v2, 0x1

    int-to-float v2, v2

    sub-float/2addr v2, p1

    mul-float v2, v2, p3

    mul-float p5, p5, p1

    add-float/2addr p5, v2

    invoke-virtual {v0, v1, p5}, La0/n;->e(IF)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_9f

    :cond_c0
    invoke-static {p3}, Lp/h;->b0(Ljava/lang/String;)V

    throw p5

    .line 22
    :cond_c4
    iget-object p1, p0, La0/h1;->d:La0/n;

    if-eqz p1, :cond_c9

    return-object p1

    :cond_c9
    invoke-static {p3}, Lp/h;->b0(Ljava/lang/String;)V

    throw p5
.end method

.method public f()I
    .registers 2

    .line 1
    iget v0, p0, La0/h1;->c:I

    return v0
.end method

.method public g()I
    .registers 2

    .line 1
    iget v0, p0, La0/h1;->b:I

    return v0
.end method
