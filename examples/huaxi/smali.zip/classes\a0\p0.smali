.class public final La0/p0;
.super Ljava/lang/Object;
.source "SuspendAnimation.kt"


# direct methods
.method public static final a(La0/h;La0/c;JLvg/l;Log/d;)Ljava/lang/Object;
    .registers 31
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "V:",
            "La0/n;",
            ">(",
            "La0/h<",
            "TT;TV;>;",
            "La0/c<",
            "TT;TV;>;J",
            "Lvg/l<",
            "-",
            "La0/f<",
            "TT;TV;>;",
            "Lkg/l;",
            ">;",
            "Log/d<",
            "-",
            "Lkg/l;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    move-object/from16 v9, p0

    move-object/from16 v0, p1

    move-object/from16 v1, p5

    instance-of v2, v1, La0/p0$a;

    if-eqz v2, :cond_19

    move-object v2, v1

    check-cast v2, La0/p0$a;

    iget v3, v2, La0/p0$a;->f:I

    const/high16 v4, -0x80000000

    and-int v5, v3, v4

    if-eqz v5, :cond_19

    sub-int/2addr v3, v4

    iput v3, v2, La0/p0$a;->f:I

    goto :goto_1e

    :cond_19
    new-instance v2, La0/p0$a;

    invoke-direct {v2, v1}, La0/p0$a;-><init>(Log/d;)V

    :goto_1e
    move-object v10, v2

    iget-object v1, v10, La0/p0$a;->e:Ljava/lang/Object;

    sget-object v11, Lpg/a;->a:Lpg/a;

    .line 1
    iget v2, v10, La0/p0$a;->f:I

    const/4 v12, 0x2

    const/4 v13, 0x1

    if-eqz v2, :cond_50

    if-eq v2, v13, :cond_36

    if-ne v2, v12, :cond_2e

    goto :goto_36

    .line 2
    :cond_2e
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 3
    :cond_36
    :goto_36
    iget-object v0, v10, La0/p0$a;->d:Ljava/lang/Object;

    check-cast v0, Lwg/w;

    iget-object v2, v10, La0/p0$a;->c:Ljava/lang/Object;

    check-cast v2, Lvg/l;

    iget-object v3, v10, La0/p0$a;->b:Ljava/lang/Object;

    check-cast v3, La0/c;

    iget-object v4, v10, La0/p0$a;->a:Ljava/lang/Object;

    check-cast v4, La0/h;

    move-object v5, v0

    :try_start_47
    invoke-static {v1}, Lo1/a0;->H(Ljava/lang/Object;)V
    :try_end_4a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_47 .. :try_end_4a} :catch_4d

    move-object v0, v3

    goto/16 :goto_cd

    :catch_4d
    move-exception v0

    goto/16 :goto_10f

    :cond_50
    invoke-static {v1}, Lo1/a0;->H(Ljava/lang/Object;)V

    const-wide/16 v1, 0x0

    .line 4
    invoke-interface {v0, v1, v2}, La0/c;->f(J)Ljava/lang/Object;

    move-result-object v15

    .line 5
    invoke-interface {v0, v1, v2}, La0/c;->d(J)La0/n;

    move-result-object v17

    .line 6
    new-instance v14, Lwg/w;

    invoke-direct {v14}, Lwg/w;-><init>()V

    const-wide/high16 v1, -0x8000000000000000L

    cmp-long v3, p2, v1

    if-nez v3, :cond_94

    .line 7
    :try_start_68
    invoke-interface {v10}, Log/d;->getContext()Log/f;

    move-result-object v1

    invoke-static {v1}, La0/p0;->d(Log/f;)F

    move-result v7

    .line 8
    new-instance v8, La0/p0$b;

    move-object v1, v8

    move-object v2, v14

    move-object v3, v15

    move-object/from16 v4, p1

    move-object/from16 v5, v17

    move-object/from16 v6, p0

    move-object v15, v8

    move-object/from16 v8, p4

    invoke-direct/range {v1 .. v8}, La0/p0$b;-><init>(Lwg/w;Ljava/lang/Object;La0/c;La0/n;La0/h;FLvg/l;)V

    iput-object v9, v10, La0/p0$a;->a:Ljava/lang/Object;

    iput-object v0, v10, La0/p0$a;->b:Ljava/lang/Object;

    move-object/from16 v8, p4

    iput-object v8, v10, La0/p0$a;->c:Ljava/lang/Object;

    iput-object v14, v10, La0/p0$a;->d:Ljava/lang/Object;

    iput v13, v10, La0/p0$a;->f:I

    invoke-static {v0, v15, v10}, La0/p0;->b(La0/c;Lvg/l;Log/d;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v11, :cond_ca

    return-object v11

    :cond_94
    move-object/from16 v8, p4

    .line 9
    new-instance v7, La0/f;

    .line 10
    invoke-interface/range {p1 .. p1}, La0/c;->c()La0/u0;

    move-result-object v16

    .line 11
    invoke-interface/range {p1 .. p1}, La0/c;->g()Ljava/lang/Object;

    move-result-object v20

    const/16 v23, 0x1

    .line 12
    new-instance v1, La0/p0$c;

    invoke-direct {v1, v9}, La0/p0$c;-><init>(La0/h;)V
    :try_end_a7
    .catch Ljava/util/concurrent/CancellationException; {:try_start_68 .. :try_end_a7} :catch_114

    move-object v6, v14

    move-object v14, v7

    move-wide/from16 v18, p2

    move-wide/from16 v21, p2

    move-object/from16 v24, v1

    .line 13
    :try_start_af
    invoke-direct/range {v14 .. v24}, La0/f;-><init>(Ljava/lang/Object;La0/u0;La0/n;JLjava/lang/Object;JZLvg/a;)V

    .line 14
    invoke-interface {v10}, Log/d;->getContext()Log/f;

    move-result-object v1

    invoke-static {v1}, La0/p0;->d(Log/f;)F

    move-result v4
    :try_end_ba
    .catch Ljava/util/concurrent/CancellationException; {:try_start_af .. :try_end_ba} :catch_111

    move-object v1, v7

    move-wide/from16 v2, p2

    move-object/from16 v5, p1

    move-object v14, v6

    move-object/from16 v6, p0

    move-object v15, v7

    move-object/from16 v7, p4

    .line 15
    :try_start_c5
    invoke-static/range {v1 .. v7}, La0/p0;->c(La0/f;JFLa0/c;La0/h;Lvg/l;)V

    .line 16
    iput-object v15, v14, Lwg/w;->a:Ljava/lang/Object;
    :try_end_ca
    .catch Ljava/util/concurrent/CancellationException; {:try_start_c5 .. :try_end_ca} :catch_114

    :cond_ca
    move-object v2, v8

    move-object v4, v9

    move-object v5, v14

    .line 17
    :cond_cd
    :goto_cd
    :try_start_cd
    iget-object v1, v5, Lwg/w;->a:Ljava/lang/Object;

    invoke-static {v1}, Lp/h;->m(Ljava/lang/Object;)V

    check-cast v1, La0/f;

    .line 18
    iget-object v1, v1, La0/f;->i:Lm0/x0;

    .line 19
    invoke-interface {v1}, Lm0/g2;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_10c

    .line 20
    invoke-interface {v10}, Log/d;->getContext()Log/f;

    move-result-object v1

    invoke-static {v1}, La0/p0;->d(Log/f;)F

    move-result v1

    .line 21
    new-instance v3, La0/p0$d;

    move-object/from16 p0, v3

    move-object/from16 p1, v5

    move/from16 p2, v1

    move-object/from16 p3, v0

    move-object/from16 p4, v4

    move-object/from16 p5, v2

    invoke-direct/range {p0 .. p5}, La0/p0$d;-><init>(Lwg/w;FLa0/c;La0/h;Lvg/l;)V

    iput-object v4, v10, La0/p0$a;->a:Ljava/lang/Object;

    iput-object v0, v10, La0/p0$a;->b:Ljava/lang/Object;

    iput-object v2, v10, La0/p0$a;->c:Ljava/lang/Object;

    iput-object v5, v10, La0/p0$a;->d:Ljava/lang/Object;

    iput v12, v10, La0/p0$a;->f:I

    invoke-static {v0, v3, v10}, La0/p0;->b(La0/c;Lvg/l;Log/d;)Ljava/lang/Object;

    move-result-object v1
    :try_end_109
    .catch Ljava/util/concurrent/CancellationException; {:try_start_cd .. :try_end_109} :catch_4d

    if-ne v1, v11, :cond_cd

    return-object v11

    .line 22
    :cond_10c
    sget-object v0, Lkg/l;->a:Lkg/l;

    return-object v0

    :goto_10f
    move-object v14, v5

    goto :goto_116

    :catch_111
    move-exception v0

    move-object v14, v6

    goto :goto_115

    :catch_114
    move-exception v0

    :goto_115
    move-object v4, v9

    .line 23
    :goto_116
    iget-object v1, v14, Lwg/w;->a:Ljava/lang/Object;

    check-cast v1, La0/f;

    const/4 v2, 0x0

    if-nez v1, :cond_11e

    goto :goto_121

    :cond_11e
    invoke-virtual {v1, v2}, La0/f;->b(Z)V

    .line 24
    :goto_121
    iget-object v1, v14, Lwg/w;->a:Ljava/lang/Object;

    check-cast v1, La0/f;

    if-eqz v1, :cond_130

    .line 25
    iget-wide v5, v1, La0/f;->g:J

    .line 26
    iget-wide v7, v4, La0/h;->d:J

    cmp-long v1, v5, v7

    if-nez v1, :cond_130

    goto :goto_131

    :cond_130
    const/4 v13, 0x0

    :goto_131
    if-eqz v13, :cond_135

    .line 27
    iput-boolean v2, v4, La0/h;->f:Z

    .line 28
    :cond_135
    throw v0
.end method

.method public static final b(La0/c;Lvg/l;Log/d;)Ljava/lang/Object;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R:",
            "Ljava/lang/Object;",
            "T:",
            "Ljava/lang/Object;",
            "V:",
            "La0/n;",
            ">(",
            "La0/c<",
            "TT;TV;>;",
            "Lvg/l<",
            "-",
            "Ljava/lang/Long;",
            "+TR;>;",
            "Log/d<",
            "-TR;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 1
    invoke-interface {p0}, La0/c;->a()Z

    move-result p0

    if-eqz p0, :cond_2f

    .line 2
    move-object p0, p2

    check-cast p0, Lqg/c;

    invoke-virtual {p0}, Lqg/c;->getContext()Log/f;

    move-result-object v0

    sget-object v1, Landroidx/compose/ui/platform/y0$a;->a:Landroidx/compose/ui/platform/y0$a;

    invoke-interface {v0, v1}, Log/f;->get(Log/f$b;)Log/f$a;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/platform/y0;

    if-nez v0, :cond_24

    .line 3
    invoke-virtual {p0}, Lqg/c;->getContext()Log/f;

    move-result-object p0

    invoke-static {p0}, La0/j;->p(Log/f;)Lm0/t0;

    move-result-object p0

    invoke-interface {p0, p1, p2}, Lm0/t0;->s(Lvg/l;Log/d;)Ljava/lang/Object;

    move-result-object p0

    goto :goto_2e

    .line 4
    :cond_24
    new-instance p0, La0/d0;

    const/4 v1, 0x0

    invoke-direct {p0, p1, v1}, La0/d0;-><init>(Lvg/l;Log/d;)V

    invoke-interface {v0, p0, p2}, Landroidx/compose/ui/platform/y0;->A(Lvg/l;Log/d;)Ljava/lang/Object;

    move-result-object p0

    :goto_2e
    return-object p0

    .line 5
    :cond_2f
    new-instance p0, La0/p0$e;

    invoke-direct {p0, p1}, La0/p0$e;-><init>(Lvg/l;)V

    .line 6
    move-object p1, p2

    check-cast p1, Lqg/c;

    invoke-virtual {p1}, Lqg/c;->getContext()Log/f;

    move-result-object p1

    invoke-static {p1}, La0/j;->p(Log/f;)Lm0/t0;

    move-result-object p1

    invoke-interface {p1, p0, p2}, Lm0/t0;->s(Lvg/l;Log/d;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static final c(La0/f;JFLa0/c;La0/h;Lvg/l;)V
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "V:",
            "La0/n;",
            ">(",
            "La0/f<",
            "TT;TV;>;JF",
            "La0/c<",
            "TT;TV;>;",
            "La0/h<",
            "TT;TV;>;",
            "Lvg/l<",
            "-",
            "La0/f<",
            "TT;TV;>;",
            "Lkg/l;",
            ">;)V"
        }
    .end annotation

    const/4 v0, 0x0

    const/4 v1, 0x0

    cmpg-float v1, p3, v1

    if-nez v1, :cond_8

    const/4 v1, 0x1

    goto :goto_9

    :cond_8
    const/4 v1, 0x0

    :goto_9
    if-eqz v1, :cond_10

    .line 1
    invoke-interface {p4}, La0/c;->b()J

    move-result-wide v1

    goto :goto_17

    .line 2
    :cond_10
    iget-wide v1, p0, La0/f;->c:J

    sub-long v1, p1, v1

    long-to-float v1, v1

    div-float/2addr v1, p3

    float-to-long v1, v1

    .line 3
    :goto_17
    iput-wide p1, p0, La0/f;->g:J

    .line 4
    invoke-interface {p4, v1, v2}, La0/c;->f(J)Ljava/lang/Object;

    move-result-object p1

    .line 5
    iget-object p2, p0, La0/f;->e:Lm0/x0;

    .line 6
    invoke-interface {p2, p1}, Lm0/x0;->setValue(Ljava/lang/Object;)V

    .line 7
    invoke-interface {p4, v1, v2}, La0/c;->d(J)La0/n;

    move-result-object p1

    const-string p2, "<set-?>"

    .line 8
    invoke-static {p1, p2}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    iput-object p1, p0, La0/f;->f:La0/n;

    .line 10
    invoke-interface {p4, v1, v2}, La0/c;->e(J)Z

    move-result p1

    if-eqz p1, :cond_3a

    .line 11
    iget-wide p1, p0, La0/f;->g:J

    .line 12
    iput-wide p1, p0, La0/f;->h:J

    .line 13
    invoke-virtual {p0, v0}, La0/f;->b(Z)V

    .line 14
    :cond_3a
    invoke-static {p0, p5}, La0/p0;->e(La0/f;La0/h;)V

    .line 15
    invoke-interface {p6, p0}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public static final d(Log/f;)F
    .registers 2

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    sget v0, Ly0/i;->Z:I

    sget-object v0, Ly0/i$a;->a:Ly0/i$a;

    invoke-interface {p0, v0}, Log/f;->get(Log/f$b;)Log/f$a;

    move-result-object p0

    check-cast p0, Ly0/i;

    if-eqz p0, :cond_16

    invoke-interface {p0}, Ly0/i;->I()F

    move-result p0

    goto :goto_18

    :cond_16
    const/high16 p0, 0x3f800000    # 1.0f

    :goto_18
    const/4 v0, 0x0

    cmpl-float v0, p0, v0

    if-ltz v0, :cond_1f

    const/4 v0, 0x1

    goto :goto_20

    :cond_1f
    const/4 v0, 0x0

    :goto_20
    if-eqz v0, :cond_23

    return p0

    .line 2
    :cond_23
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "Check failed."

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static final e(La0/f;La0/h;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "V:",
            "La0/n;",
            ">(",
            "La0/f<",
            "TT;TV;>;",
            "La0/h<",
            "TT;TV;>;)V"
        }
    .end annotation

    const-string v0, "state"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-virtual {p0}, La0/f;->a()Ljava/lang/Object;

    move-result-object v0

    .line 2
    iget-object v1, p1, La0/h;->b:Lm0/x0;

    .line 3
    invoke-interface {v1, v0}, Lm0/x0;->setValue(Ljava/lang/Object;)V

    .line 4
    iget-object v0, p1, La0/h;->c:La0/n;

    .line 5
    iget-object v1, p0, La0/f;->f:La0/n;

    const-string v2, "<this>"

    .line 6
    invoke-static {v0, v2}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "source"

    invoke-static {v1, v2}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 7
    invoke-virtual {v0}, La0/n;->b()I

    move-result v2

    const/4 v3, 0x0

    :goto_21
    if-ge v3, v2, :cond_2d

    .line 8
    invoke-virtual {v1, v3}, La0/n;->a(I)F

    move-result v4

    invoke-virtual {v0, v3, v4}, La0/n;->e(IF)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_21

    .line 9
    :cond_2d
    iget-wide v0, p0, La0/f;->h:J

    .line 10
    iput-wide v0, p1, La0/h;->e:J

    .line 11
    iget-wide v0, p0, La0/f;->g:J

    .line 12
    iput-wide v0, p1, La0/h;->d:J

    .line 13
    iget-object p0, p0, La0/f;->i:Lm0/x0;

    .line 14
    invoke-interface {p0}, Lm0/g2;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    .line 15
    iput-boolean p0, p1, La0/h;->f:Z

    return-void
.end method
