.class public final La3/r;
.super Ljava/lang/Object;
.source "PictureInPictureModeChangedInfo.java"


# static fields
.field public static final a:Llh/r;

.field public static final b:Llh/r;


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Llh/r;

    const-string v1, "NONE"

    invoke-direct {v0, v1}, Llh/r;-><init>(Ljava/lang/String;)V

    sput-object v0, La3/r;->a:Llh/r;

    .line 2
    new-instance v0, Llh/r;

    const-string v1, "PENDING"

    invoke-direct {v0, v1}, Llh/r;-><init>(Ljava/lang/String;)V

    sput-object v0, La3/r;->b:Llh/r;

    return-void
.end method

.method public synthetic constructor <init>(Z)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(ZLandroid/content/res/Configuration;)V
    .registers 3

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final a(Ljava/lang/Object;)Ljh/x;
    .registers 2

    .line 1
    new-instance v0, Ljh/l0;

    if-nez p0, :cond_6

    sget-object p0, Lyb/d;->b:Llh/r;

    :cond_6
    invoke-direct {v0, p0}, Ljh/l0;-><init>(Ljava/lang/Object;)V

    return-object v0
.end method

.method public static final b(Ljh/k0;Log/f;ILih/e;)Ljh/e;
    .registers 5

    if-ltz p2, :cond_7

    const/4 v0, 0x2

    if-ge p2, v0, :cond_7

    const/4 v0, 0x1

    goto :goto_8

    :cond_7
    const/4 v0, 0x0

    :goto_8
    if-nez v0, :cond_d

    const/4 v0, -0x2

    if-ne p2, v0, :cond_12

    .line 1
    :cond_d
    sget-object v0, Lih/e;->b:Lih/e;

    if-ne p3, v0, :cond_12

    return-object p0

    :cond_12
    if-eqz p2, :cond_17

    const/4 v0, -0x3

    if-ne p2, v0, :cond_1c

    .line 2
    :cond_17
    sget-object v0, Lih/e;->a:Lih/e;

    if-ne p3, v0, :cond_1c

    goto :goto_22

    .line 3
    :cond_1c
    new-instance v0, Lkh/i;

    invoke-direct {v0, p0, p1, p2, p3}, Lkh/i;-><init>(Ljh/e;Log/f;ILih/e;)V

    move-object p0, v0

    :goto_22
    return-object p0
.end method

.method public static final c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;DD)V
    .registers 13

    .line 1
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const v1, 0x374b43b6

    const/16 v2, 0x2c

    if-eq v0, v1, :cond_c3

    const v1, 0x3cf4677f

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eq v0, v1, :cond_79

    const p3, 0x47d589ed

    if-eq v0, p3, :cond_19

    goto/16 :goto_112

    :cond_19
    const-string p3, "\u9ad8\u5fb7\u5730\u56fe"

    invoke-virtual {p1, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_23

    goto/16 :goto_112

    .line 2
    :cond_23
    new-instance p1, Landroid/content/Intent;

    invoke-direct {p1}, Landroid/content/Intent;-><init>()V

    const-string p3, "com.autonavi.minimap"

    .line 3
    invoke-virtual {p1, p3}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const-string p3, "android.intent.action.VIEW"

    .line 4
    invoke-virtual {p1, p3}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const-string p3, "android.intent.category.DEFAULT"

    .line 5
    invoke-virtual {p1, p3}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    .line 6
    invoke-static {p6, p7, p4, p5}, La0/u;->P(DD)[D

    move-result-object p3

    const-string p4, "androidamap://viewMap?sourceApplication="

    .line 7
    invoke-static {p4}, Landroid/support/v4/media/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p4

    invoke-static {}, Lcom/blankj/utilcode/util/a;->c()Ljava/lang/String;

    move-result-object p5

    invoke-virtual {p4, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p5, "&poiname="

    invoke-virtual {p4, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, "&lat="

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 8
    aget-wide p5, p3, v4

    .line 9
    invoke-virtual {p4, p5, p6}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    const-string p2, "&lon="

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 10
    aget-wide p2, p3, v3

    .line 11
    invoke-virtual {p4, p2, p3}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    const-string p2, "&dev=0"

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    .line 12
    invoke-static {p2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 13
    invoke-virtual {p0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_112

    :cond_79
    const-string v0, "\u817e\u8baf\u5730\u56fe"

    .line 14
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_83

    goto/16 :goto_112

    .line 15
    :cond_83
    new-instance p1, Landroid/content/Intent;

    invoke-direct {p1}, Landroid/content/Intent;-><init>()V

    .line 16
    invoke-static {p6, p7, p4, p5}, La0/u;->P(DD)[D

    move-result-object p4

    const-string p5, "qqmap://map/marker?marker=coord:"

    .line 17
    invoke-static {p5}, Landroid/support/v4/media/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p5

    .line 18
    aget-wide p6, p4, v4

    .line 19
    invoke-virtual {p5, p6, p7}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    invoke-virtual {p5, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 20
    aget-wide p6, p4, v3

    .line 21
    invoke-virtual {p5, p6, p7}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    const-string p4, ";title:"

    invoke-virtual {p5, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p5, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, ";addr:"

    invoke-virtual {p5, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p5, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, "&referer=OB4BZ-D4W3U-B7VVO-4PJWW-6TKDJ-WPB77"

    invoke-virtual {p5, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    .line 22
    invoke-static {p2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p2

    .line 23
    invoke-virtual {p1, p2}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 24
    invoke-virtual {p0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto :goto_112

    :cond_c3
    const-string v0, "\u767e\u5ea6\u5730\u56fe"

    .line 25
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_112

    .line 26
    invoke-static {}, Lcom/blankj/utilcode/util/a;->d()Ljava/lang/String;

    move-result-object p1

    const-string v0, "getAppPackageName()"

    invoke-static {p1, v0}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    .line 27
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    .line 28
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "baidumap://map/marker?src="

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "&coord_type=bd09ll&location="

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p4, p5}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p6, p7}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    const-string p1, "&title="

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "&content="

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 29
    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    .line 30
    invoke-virtual {v0, p1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 31
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    :cond_112
    :goto_112
    return-void
.end method

.method public static final d(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;DD)V
    .registers 21

    move-object v9, p0

    .line 1
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const-string v0, "com.baidu.BaiduMap"

    .line 2
    invoke-static {v0}, Lcom/blankj/utilcode/util/a;->g(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_13

    const-string v0, "\u767e\u5ea6\u5730\u56fe"

    .line 3
    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_13
    const-string v0, "com.autonavi.minimap"

    .line 4
    invoke-static {v0}, Lcom/blankj/utilcode/util/a;->g(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_20

    const-string v0, "\u9ad8\u5fb7\u5730\u56fe"

    .line 5
    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_20
    const-string v0, "com.tencent.map"

    .line 6
    invoke-static {v0}, Lcom/blankj/utilcode/util/a;->g(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_2d

    const-string v0, "\u817e\u8baf\u5730\u56fe"

    .line 7
    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 8
    :cond_2d
    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_39

    const-string v0, "\u68c0\u6d4b\u5230\u624b\u673a\u4e0a\u672a\u5b89\u88c5\u5bfc\u822a\u8f6f\u4ef6\uff0c\u8bf7\u5728\u5e94\u7528\u5546\u5e97\u4e0b\u8f7d\u76f8\u5173\u8f6f\u4ef6\u540e\u4f7f\u7528\u8be5\u529f\u80fd\u3002"

    .line 9
    invoke-static {p0, v0}, Linfo/cd120/two/base/dialog/ConfirmPop;->p(Landroid/content/Context;Ljava/lang/CharSequence;)V

    goto :goto_8d

    .line 10
    :cond_39
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x1

    const/4 v10, 0x0

    if-ne v0, v1, :cond_54

    .line 11
    invoke-virtual {v2, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Ljava/lang/String;

    move-object v0, p0

    move-object v2, p1

    move-object/from16 v3, p2

    move-wide/from16 v4, p3

    move-wide/from16 v6, p5

    invoke-static/range {v0 .. v7}, La3/r;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;DD)V

    goto :goto_8d

    .line 12
    :cond_54
    new-instance v11, Llc/c;

    invoke-direct {v11}, Llc/c;-><init>()V

    new-array v0, v10, [Ljava/lang/String;

    .line 13
    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>"

    invoke-static {v0, v1}, Lp/h;->n(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v12, v0

    check-cast v12, [Ljava/lang/String;

    .line 14
    new-instance v13, Lee/u;

    move-object v0, v13

    move-object v1, p0

    move-object v3, p1

    move-object/from16 v4, p2

    move-wide/from16 v5, p3

    move-wide/from16 v7, p5

    invoke-direct/range {v0 .. v8}, Lee/u;-><init>(Landroid/content/Context;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;DD)V

    .line 15
    new-instance v0, Lcom/lxj/xpopup/impl/BottomListPopupView;

    invoke-direct {v0, p0, v10, v10}, Lcom/lxj/xpopup/impl/BottomListPopupView;-><init>(Landroid/content/Context;II)V

    const-string v1, "\u8bf7\u9009\u62e9"

    .line 16
    iput-object v1, v0, Lcom/lxj/xpopup/impl/BottomListPopupView;->y:Ljava/lang/CharSequence;

    .line 17
    iput-object v12, v0, Lcom/lxj/xpopup/impl/BottomListPopupView;->z:[Ljava/lang/String;

    const/4 v1, 0x0

    .line 18
    iput-object v1, v0, Lcom/lxj/xpopup/impl/BottomListPopupView;->A:[I

    const/4 v1, -0x1

    .line 19
    iput v1, v0, Lcom/lxj/xpopup/impl/BottomListPopupView;->C:I

    .line 20
    iput-object v13, v0, Lcom/lxj/xpopup/impl/BottomListPopupView;->B:Loc/e;

    .line 21
    iput-object v11, v0, Lcom/lxj/xpopup/core/BasePopupView;->a:Llc/c;

    .line 22
    invoke-virtual {v0}, Lcom/lxj/xpopup/core/BasePopupView;->m()Lcom/lxj/xpopup/core/BasePopupView;

    :goto_8d
    return-void
.end method
