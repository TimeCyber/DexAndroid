.class public final La2/e;
.super Ljava/lang/Object;
.source "StaticLayoutFactory.kt"

# interfaces
.implements La2/i;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(La2/k;)Landroid/text/StaticLayout;
    .registers 7

    const-string v0, "params"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object v0, p1, La2/k;->a:Ljava/lang/CharSequence;

    .line 2
    iget v1, p1, La2/k;->b:I

    .line 3
    iget v2, p1, La2/k;->c:I

    .line 4
    iget-object v3, p1, La2/k;->d:Landroid/text/TextPaint;

    .line 5
    iget v4, p1, La2/k;->e:I

    .line 6
    invoke-static {v0, v1, v2, v3, v4}, Landroid/text/StaticLayout$Builder;->obtain(Ljava/lang/CharSequence;IILandroid/text/TextPaint;I)Landroid/text/StaticLayout$Builder;

    move-result-object v0

    .line 7
    iget-object v1, p1, La2/k;->f:Landroid/text/TextDirectionHeuristic;

    .line 8
    invoke-virtual {v0, v1}, Landroid/text/StaticLayout$Builder;->setTextDirection(Landroid/text/TextDirectionHeuristic;)Landroid/text/StaticLayout$Builder;

    .line 9
    iget-object v1, p1, La2/k;->g:Landroid/text/Layout$Alignment;

    .line 10
    invoke-virtual {v0, v1}, Landroid/text/StaticLayout$Builder;->setAlignment(Landroid/text/Layout$Alignment;)Landroid/text/StaticLayout$Builder;

    .line 11
    iget v1, p1, La2/k;->h:I

    .line 12
    invoke-virtual {v0, v1}, Landroid/text/StaticLayout$Builder;->setMaxLines(I)Landroid/text/StaticLayout$Builder;

    .line 13
    iget-object v1, p1, La2/k;->i:Landroid/text/TextUtils$TruncateAt;

    .line 14
    invoke-virtual {v0, v1}, Landroid/text/StaticLayout$Builder;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)Landroid/text/StaticLayout$Builder;

    .line 15
    iget v1, p1, La2/k;->j:I

    .line 16
    invoke-virtual {v0, v1}, Landroid/text/StaticLayout$Builder;->setEllipsizedWidth(I)Landroid/text/StaticLayout$Builder;

    .line 17
    iget v1, p1, La2/k;->l:F

    .line 18
    iget v2, p1, La2/k;->k:F

    .line 19
    invoke-virtual {v0, v1, v2}, Landroid/text/StaticLayout$Builder;->setLineSpacing(FF)Landroid/text/StaticLayout$Builder;

    .line 20
    iget-boolean v1, p1, La2/k;->n:Z

    .line 21
    invoke-virtual {v0, v1}, Landroid/text/StaticLayout$Builder;->setIncludePad(Z)Landroid/text/StaticLayout$Builder;

    .line 22
    iget v1, p1, La2/k;->p:I

    .line 23
    invoke-virtual {v0, v1}, Landroid/text/StaticLayout$Builder;->setBreakStrategy(I)Landroid/text/StaticLayout$Builder;

    .line 24
    iget v1, p1, La2/k;->q:I

    .line 25
    invoke-virtual {v0, v1}, Landroid/text/StaticLayout$Builder;->setHyphenationFrequency(I)Landroid/text/StaticLayout$Builder;

    .line 26
    iget-object v1, p1, La2/k;->r:[I

    .line 27
    iget-object v2, p1, La2/k;->s:[I

    .line 28
    invoke-virtual {v0, v1, v2}, Landroid/text/StaticLayout$Builder;->setIndents([I[I)Landroid/text/StaticLayout$Builder;

    .line 29
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1a

    if-lt v1, v2, :cond_56

    .line 30
    sget-object v2, La2/f;->a:La2/f;

    .line 31
    iget v3, p1, La2/k;->m:I

    .line 32
    invoke-virtual {v2, v0, v3}, La2/f;->a(Landroid/text/StaticLayout$Builder;I)V

    :cond_56
    const/16 v2, 0x1c

    if-lt v1, v2, :cond_61

    .line 33
    sget-object v1, La2/g;->a:La2/g;

    .line 34
    iget-boolean p1, p1, La2/k;->o:Z

    .line 35
    invoke-virtual {v1, v0, p1}, La2/g;->a(Landroid/text/StaticLayout$Builder;Z)V

    .line 36
    :cond_61
    invoke-virtual {v0}, Landroid/text/StaticLayout$Builder;->build()Landroid/text/StaticLayout;

    move-result-object p1

    const-string v0, "obtain(params.text, para\u2026  }\n            }.build()"

    invoke-static {p1, v0}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p1
.end method
