.class public La6/l;
.super Ljava/lang/Object;
.source "LottieCompositionFactory.java"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "La6/s<",
        "La6/g;",
        ">;>;"
    }
.end annotation


# instance fields
.field public final synthetic a:Ljava/io/InputStream;

.field public final synthetic b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/io/InputStream;Ljava/lang/String;)V
    .registers 3

    .line 1
    iput-object p1, p0, La6/l;->a:Ljava/io/InputStream;

    iput-object p2, p0, La6/l;->b:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public call()Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 1
    iget-object v0, p0, La6/l;->a:Ljava/io/InputStream;

    iget-object v1, p0, La6/l;->b:Ljava/lang/String;

    invoke-static {v0, v1}, La6/h;->c(Ljava/io/InputStream;Ljava/lang/String;)La6/s;

    move-result-object v0

    return-object v0
.end method
