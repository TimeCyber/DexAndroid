.class public final La7/r;
.super Ljava/lang/Object;
.source "SPUtils.java"


# annotations
.annotation build Landroid/annotation/SuppressLint;
    value = {
        "ApplySharedPref"
    }
.end annotation


# static fields
.field public static final b:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "La7/r;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public a:Landroid/content/SharedPreferences;


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, La7/r;->b:Ljava/util/Map;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    invoke-static {}, Lcom/blankj/utilcode/util/l;->a()Landroid/app/Application;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Landroid/app/Application;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p1

    iput-object p1, p0, La7/r;->a:Landroid/content/SharedPreferences;

    return-void
.end method

.method public static a()La7/r;
    .registers 2

    const-string v0, ""

    const/4 v1, 0x0

    .line 1
    invoke-static {v0, v1}, La7/r;->b(Ljava/lang/String;I)La7/r;

    move-result-object v0

    return-object v0
.end method

.method public static b(Ljava/lang/String;I)La7/r;
    .registers 7

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-nez p0, :cond_6

    :cond_4
    const/4 v0, 0x1

    goto :goto_1b

    .line 1
    :cond_6
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v3, 0x0

    :goto_b
    if-ge v3, v2, :cond_4

    .line 2
    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v4

    invoke-static {v4}, Ljava/lang/Character;->isWhitespace(C)Z

    move-result v4

    if-nez v4, :cond_18

    goto :goto_1b

    :cond_18
    add-int/lit8 v3, v3, 0x1

    goto :goto_b

    :goto_1b
    if-eqz v0, :cond_1f

    const-string p0, "spUtils"

    .line 3
    :cond_1f
    sget-object v0, La7/r;->b:Ljava/util/Map;

    move-object v1, v0

    check-cast v1, Ljava/util/HashMap;

    invoke-virtual {v1, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La7/r;

    if-nez v1, :cond_4a

    .line 4
    const-class v2, La7/r;

    monitor-enter v2

    .line 5
    :try_start_2f
    move-object v1, v0

    check-cast v1, Ljava/util/HashMap;

    invoke-virtual {v1, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La7/r;

    if-nez v1, :cond_44

    .line 6
    new-instance v1, La7/r;

    invoke-direct {v1, p0, p1}, La7/r;-><init>(Ljava/lang/String;I)V

    .line 7
    check-cast v0, Ljava/util/HashMap;

    invoke-virtual {v0, p0, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    :cond_44
    monitor-exit v2

    goto :goto_4a

    :goto_46
    monitor-exit v2
    :try_end_47
    .catchall {:try_start_2f .. :try_end_47} :catchall_48

    throw p0

    :catchall_48
    move-exception p0

    goto :goto_46

    :cond_4a
    :goto_4a
    return-object v1
.end method
