.class public La6/m$g;
.super Ljava/lang/Object;
.source "LottieDrawable.java"

# interfaces
.implements La6/m$o;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La6/m;->k()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:La6/m;


# direct methods
.method public constructor <init>(La6/m;)V
    .registers 2

    .line 1
    iput-object p1, p0, La6/m$g;->a:La6/m;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(La6/g;)V
    .registers 2

    .line 1
    iget-object p1, p0, La6/m$g;->a:La6/m;

    invoke-virtual {p1}, La6/m;->k()V

    return-void
.end method
