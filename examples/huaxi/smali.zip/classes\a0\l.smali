.class public final La0/l;
.super La0/n;
.source "AnimationVectors.kt"


# instance fields
.field public a:F

.field public b:F


# direct methods
.method public constructor <init>(FF)V
    .registers 4

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, La0/n;-><init>(Lwg/e;)V

    .line 2
    iput p1, p0, La0/l;->a:F

    .line 3
    iput p2, p0, La0/l;->b:F

    return-void
.end method


# virtual methods
.method public a(I)F
    .registers 3

    if-eqz p1, :cond_a

    const/4 v0, 0x1

    if-eq p1, v0, :cond_7

    const/4 p1, 0x0

    goto :goto_c

    .line 1
    :cond_7
    iget p1, p0, La0/l;->b:F

    goto :goto_c

    .line 2
    :cond_a
    iget p1, p0, La0/l;->a:F

    :goto_c
    return p1
.end method

.method public b()I
    .registers 2

    const/4 v0, 0x2

    return v0
.end method

.method public c()La0/n;
    .registers 3

    .line 1
    new-instance v0, La0/l;

    const/4 v1, 0x0

    invoke-direct {v0, v1, v1}, La0/l;-><init>(FF)V

    return-object v0
.end method

.method public d()V
    .registers 2

    const/4 v0, 0x0

    .line 1
    iput v0, p0, La0/l;->a:F

    .line 2
    iput v0, p0, La0/l;->b:F

    return-void
.end method

.method public e(IF)V
    .registers 4

    if-eqz p1, :cond_9

    const/4 v0, 0x1

    if-eq p1, v0, :cond_6

    goto :goto_b

    .line 1
    :cond_6
    iput p2, p0, La0/l;->b:F

    goto :goto_b

    .line 2
    :cond_9
    iput p2, p0, La0/l;->a:F

    :goto_b
    return-void
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    instance-of v0, p1, La0/l;

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_23

    check-cast p1, La0/l;

    iget v0, p1, La0/l;->a:F

    iget v3, p0, La0/l;->a:F

    cmpg-float v0, v0, v3

    if-nez v0, :cond_12

    const/4 v0, 0x1

    goto :goto_13

    :cond_12
    const/4 v0, 0x0

    :goto_13
    if-eqz v0, :cond_23

    iget p1, p1, La0/l;->b:F

    iget v0, p0, La0/l;->b:F

    cmpg-float p1, p1, v0

    if-nez p1, :cond_1f

    const/4 p1, 0x1

    goto :goto_20

    :cond_1f
    const/4 p1, 0x0

    :goto_20
    if-eqz p1, :cond_23

    goto :goto_24

    :cond_23
    const/4 v1, 0x0

    :goto_24
    return v1
.end method

.method public hashCode()I
    .registers 3

    .line 1
    iget v0, p0, La0/l;->a:F

    invoke-static {v0}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, La0/l;->b:F

    invoke-static {v1}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v1

    add-int/2addr v1, v0

    return v1
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    const-string v0, "AnimationVector2D: v1 = "

    .line 1
    invoke-static {v0}, Landroid/support/v4/media/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, La0/l;->a:F

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v1, ", v2 = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La0/l;->b:F

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
