.class public La6/m$f;
.super Ljava/lang/Object;
.source "LottieDrawable.java"

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La6/m;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:La6/m;


# direct methods
.method public constructor <init>(La6/m;)V
    .registers 2

    .line 1
    iput-object p1, p0, La6/m$f;->a:La6/m;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .registers 3

    .line 1
    iget-object p1, p0, La6/m$f;->a:La6/m;

    .line 2
    iget-object v0, p1, La6/m;->n:Li6/c;

    if-eqz v0, :cond_f

    .line 3
    iget-object p1, p1, La6/m;->c:Lm6/d;

    .line 4
    invoke-virtual {p1}, Lm6/d;->d()F

    move-result p1

    invoke-virtual {v0, p1}, Li6/c;->t(F)V

    :cond_f
    return-void
.end method
