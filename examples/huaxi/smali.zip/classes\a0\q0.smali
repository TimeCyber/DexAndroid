.class public final La0/q0;
.super Lwg/j;
.source "SuspendAnimation.kt"

# interfaces
.implements Lvg/a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lwg/j;",
        "Lvg/a<",
        "Lkg/l;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic a:La0/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/h<",
            "Ljava/lang/Object;",
            "La0/n;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(La0/h;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La0/h<",
            "Ljava/lang/Object;",
            "La0/n;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La0/q0;->a:La0/h;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lwg/j;-><init>(I)V

    return-void
.end method


# virtual methods
.method public invoke()Ljava/lang/Object;
    .registers 3

    .line 1
    iget-object v0, p0, La0/q0;->a:La0/h;

    const/4 v1, 0x0

    .line 2
    iput-boolean v1, v0, La0/h;->f:Z

    .line 3
    sget-object v0, Lkg/l;->a:Lkg/l;

    return-object v0
.end method
