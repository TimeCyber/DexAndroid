.class public La6/m;
.super Landroid/graphics/drawable/Drawable;
.source "LottieDrawable.java"

# interfaces
.implements Landroid/graphics/drawable/Drawable$Callback;
.implements Landroid/graphics/drawable/Animatable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La6/m$o;
    }
.end annotation


# instance fields
.field public final a:Landroid/graphics/Matrix;

.field public b:La6/g;

.field public final c:Lm6/d;

.field public d:F

.field public e:Z

.field public f:Z

.field public g:Z

.field public final h:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La6/m$o;",
            ">;"
        }
    .end annotation
.end field

.field public i:Le6/b;

.field public j:Ljava/lang/String;

.field public k:La6/b;

.field public l:Le6/a;

.field public m:Z

.field public n:Li6/c;

.field public o:I

.field public p:Z

.field public q:Z

.field public r:Z

.field public s:Z

.field public t:Z


# direct methods
.method public constructor <init>()V
    .registers 6

    .line 1
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    .line 2
    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    iput-object v0, p0, La6/m;->a:Landroid/graphics/Matrix;

    .line 3
    new-instance v0, Lm6/d;

    invoke-direct {v0}, Lm6/d;-><init>()V

    iput-object v0, p0, La6/m;->c:Lm6/d;

    const/high16 v1, 0x3f800000    # 1.0f

    .line 4
    iput v1, p0, La6/m;->d:F

    const/4 v1, 0x1

    .line 5
    iput-boolean v1, p0, La6/m;->e:Z

    const/4 v2, 0x0

    .line 6
    iput-boolean v2, p0, La6/m;->f:Z

    .line 7
    iput-boolean v2, p0, La6/m;->g:Z

    .line 8
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iput-object v3, p0, La6/m;->h:Ljava/util/ArrayList;

    .line 9
    new-instance v3, La6/m$f;

    invoke-direct {v3, p0}, La6/m$f;-><init>(La6/m;)V

    const/16 v4, 0xff

    .line 10
    iput v4, p0, La6/m;->o:I

    .line 11
    iput-boolean v1, p0, La6/m;->s:Z

    .line 12
    iput-boolean v2, p0, La6/m;->t:Z

    .line 13
    iget-object v0, v0, Lm6/a;->a:Ljava/util/Set;

    invoke-interface {v0, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    return-void
.end method


# virtual methods
.method public a(Lf6/e;Ljava/lang/Object;Ls5/i;)V
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lf6/e;",
            "TT;",
            "Ls5/i;",
            ")V"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La6/m;->n:Li6/c;

    if-nez v0, :cond_f

    .line 2
    iget-object v0, p0, La6/m;->h:Ljava/util/ArrayList;

    new-instance v1, La6/m$e;

    invoke-direct {v1, p0, p1, p2, p3}, La6/m$e;-><init>(La6/m;Lf6/e;Ljava/lang/Object;Ls5/i;)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    .line 3
    :cond_f
    sget-object v1, Lf6/e;->c:Lf6/e;

    const/4 v2, 0x1

    if-ne p1, v1, :cond_18

    .line 4
    invoke-virtual {v0, p2, p3}, Li6/c;->h(Ljava/lang/Object;Ls5/i;)V

    goto :goto_58

    .line 5
    :cond_18
    iget-object v1, p1, Lf6/e;->b:Lf6/f;

    if-eqz v1, :cond_20

    .line 6
    invoke-interface {v1, p2, p3}, Lf6/f;->h(Ljava/lang/Object;Ls5/i;)V

    goto :goto_58

    :cond_20
    const/4 v1, 0x0

    if-nez v0, :cond_2d

    const-string p1, "Cannot resolve KeyPath. Composition is not set yet."

    .line 7
    invoke-static {p1}, Lm6/c;->a(Ljava/lang/String;)V

    .line 8
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object p1

    goto :goto_3f

    .line 9
    :cond_2d
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 10
    iget-object v3, p0, La6/m;->n:Li6/c;

    new-instance v4, Lf6/e;

    new-array v5, v1, [Ljava/lang/String;

    invoke-direct {v4, v5}, Lf6/e;-><init>([Ljava/lang/String;)V

    invoke-virtual {v3, p1, v1, v0, v4}, Li6/b;->d(Lf6/e;ILjava/util/List;Lf6/e;)V

    move-object p1, v0

    .line 11
    :goto_3f
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-ge v1, v0, :cond_53

    .line 12
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lf6/e;

    .line 13
    iget-object v0, v0, Lf6/e;->b:Lf6/f;

    .line 14
    invoke-interface {v0, p2, p3}, Lf6/f;->h(Ljava/lang/Object;Ls5/i;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_3f

    .line 15
    :cond_53
    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result p1

    xor-int/2addr v2, p1

    :goto_58
    if-eqz v2, :cond_68

    .line 16
    invoke-virtual {p0}, La6/m;->invalidateSelf()V

    .line 17
    sget-object p1, La6/r;->E:Ljava/lang/Float;

    if-ne p2, p1, :cond_68

    .line 18
    invoke-virtual {p0}, La6/m;->h()F

    move-result p1

    invoke-virtual {p0, p1}, La6/m;->v(F)V

    :cond_68
    return-void
.end method

.method public final b()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, La6/m;->e:Z

    if-nez v0, :cond_b

    iget-boolean v0, p0, La6/m;->f:Z

    if-eqz v0, :cond_9

    goto :goto_b

    :cond_9
    const/4 v0, 0x0

    goto :goto_c

    :cond_b
    :goto_b
    const/4 v0, 0x1

    :goto_c
    return v0
.end method

.method public final c()V
    .registers 31

    move-object/from16 v0, p0

    .line 1
    new-instance v1, Li6/c;

    iget-object v2, v0, La6/m;->b:La6/g;

    move-object v4, v2

    .line 2
    sget-object v3, Lk6/v;->a:Ll6/c$a;

    .line 3
    iget-object v5, v2, La6/g;->j:Landroid/graphics/Rect;

    .line 4
    new-instance v15, Li6/e;

    move-object v2, v15

    .line 5
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v3

    .line 6
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v12

    new-instance v16, Lg6/g;

    move-object/from16 v13, v16

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    .line 7
    invoke-direct/range {v16 .. v25}, Lg6/g;-><init>(Lc6/b;Lg6/h;Lg6/d;Lg6/b;Lg6/d;Lg6/b;Lg6/b;Lg6/b;Lg6/b;)V

    .line 8
    invoke-virtual {v5}, Landroid/graphics/Rect;->width()I

    move-result v19

    invoke-virtual {v5}, Landroid/graphics/Rect;->height()I

    move-result v20

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v23

    const-string v5, "__container"

    const-wide/16 v6, -0x1

    const/4 v8, 0x1

    const-wide/16 v9, -0x1

    const/4 v11, 0x0

    const/4 v14, 0x0

    const/16 v16, 0x0

    move-object/from16 v29, v15

    move/from16 v15, v16

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v24, 0x1

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    invoke-direct/range {v2 .. v28}, Li6/e;-><init>(Ljava/util/List;La6/g;Ljava/lang/String;JIJLjava/lang/String;Ljava/util/List;Lg6/g;IIIFFIILg6/c;Lg6/f;Ljava/util/List;ILg6/b;ZLf/q;Lk6/j;)V

    .line 9
    iget-object v2, v0, La6/m;->b:La6/g;

    .line 10
    iget-object v3, v2, La6/g;->i:Ljava/util/List;

    move-object/from16 v4, v29

    .line 11
    invoke-direct {v1, v0, v4, v3, v2}, Li6/c;-><init>(La6/m;Li6/e;Ljava/util/List;La6/g;)V

    iput-object v1, v0, La6/m;->n:Li6/c;

    .line 12
    iget-boolean v2, v0, La6/m;->q:Z

    if-eqz v2, :cond_6c

    const/4 v2, 0x1

    .line 13
    invoke-virtual {v1, v2}, Li6/c;->s(Z)V

    :cond_6c
    return-void
.end method

.method public d()V
    .registers 3

    .line 1
    iget-object v0, p0, La6/m;->c:Lm6/d;

    .line 2
    iget-boolean v1, v0, Lm6/d;->k:Z

    if-eqz v1, :cond_9

    .line 3
    invoke-virtual {v0}, Lm6/d;->cancel()V

    :cond_9
    const/4 v0, 0x0

    .line 4
    iput-object v0, p0, La6/m;->b:La6/g;

    .line 5
    iput-object v0, p0, La6/m;->n:Li6/c;

    .line 6
    iput-object v0, p0, La6/m;->i:Le6/b;

    .line 7
    iget-object v1, p0, La6/m;->c:Lm6/d;

    .line 8
    iput-object v0, v1, Lm6/d;->j:La6/g;

    const/high16 v0, -0x31000000

    .line 9
    iput v0, v1, Lm6/d;->h:F

    const/high16 v0, 0x4f000000

    .line 10
    iput v0, v1, Lm6/d;->i:F

    .line 11
    invoke-virtual {p0}, La6/m;->invalidateSelf()V

    return-void
.end method

.method public draw(Landroid/graphics/Canvas;)V
    .registers 3

    const/4 v0, 0x0

    .line 1
    iput-boolean v0, p0, La6/m;->t:Z

    .line 2
    iget-boolean v0, p0, La6/m;->g:Z

    if-eqz v0, :cond_11

    .line 3
    :try_start_7
    invoke-virtual {p0, p1}, La6/m;->e(Landroid/graphics/Canvas;)V
    :try_end_a
    .catchall {:try_start_7 .. :try_end_a} :catchall_b

    goto :goto_14

    .line 4
    :catchall_b
    sget-object p1, Lm6/c;->a:La6/p;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_14

    .line 5
    :cond_11
    invoke-virtual {p0, p1}, La6/m;->e(Landroid/graphics/Canvas;)V

    :goto_14
    const-string p1, "Drawable#draw"

    .line 6
    invoke-static {p1}, La6/d;->m(Ljava/lang/String;)F

    return-void
.end method

.method public final e(Landroid/graphics/Canvas;)V
    .registers 11

    .line 1
    iget-object v0, p0, La6/m;->b:La6/g;

    const/4 v1, 0x1

    if-eqz v0, :cond_32

    .line 2
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v2

    invoke-virtual {v2}, Landroid/graphics/Rect;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_10

    goto :goto_32

    .line 3
    :cond_10
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v2

    .line 4
    invoke-virtual {v2}, Landroid/graphics/Rect;->width()I

    move-result v3

    int-to-float v3, v3

    invoke-virtual {v2}, Landroid/graphics/Rect;->height()I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v3, v2

    .line 5
    iget-object v0, v0, La6/g;->j:Landroid/graphics/Rect;

    .line 6
    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v0

    int-to-float v0, v0

    div-float/2addr v2, v0

    cmpl-float v0, v3, v2

    if-nez v0, :cond_31

    goto :goto_32

    :cond_31
    const/4 v1, 0x0

    :cond_32
    :goto_32
    const/high16 v0, 0x40000000    # 2.0f

    const/4 v2, -0x1

    const/high16 v3, 0x3f800000    # 1.0f

    if-nez v1, :cond_ac

    .line 7
    iget-object v1, p0, La6/m;->n:Li6/c;

    .line 8
    iget-object v4, p0, La6/m;->b:La6/g;

    if-eqz v1, :cond_120

    if-nez v4, :cond_43

    goto/16 :goto_120

    .line 9
    :cond_43
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v5

    .line 10
    invoke-virtual {v5}, Landroid/graphics/Rect;->width()I

    move-result v6

    int-to-float v6, v6

    .line 11
    iget-object v7, v4, La6/g;->j:Landroid/graphics/Rect;

    .line 12
    invoke-virtual {v7}, Landroid/graphics/Rect;->width()I

    move-result v7

    int-to-float v7, v7

    div-float/2addr v6, v7

    .line 13
    invoke-virtual {v5}, Landroid/graphics/Rect;->height()I

    move-result v7

    int-to-float v7, v7

    .line 14
    iget-object v4, v4, La6/g;->j:Landroid/graphics/Rect;

    .line 15
    invoke-virtual {v4}, Landroid/graphics/Rect;->height()I

    move-result v4

    int-to-float v4, v4

    div-float/2addr v7, v4

    .line 16
    iget-boolean v4, p0, La6/m;->s:Z

    if-eqz v4, :cond_94

    .line 17
    invoke-static {v6, v7}, Ljava/lang/Math;->min(FF)F

    move-result v4

    cmpg-float v8, v4, v3

    if-gez v8, :cond_72

    div-float v8, v3, v4

    div-float/2addr v6, v8

    div-float/2addr v7, v8

    goto :goto_74

    :cond_72
    const/high16 v8, 0x3f800000    # 1.0f

    :goto_74
    cmpl-float v3, v8, v3

    if-lez v3, :cond_94

    .line 18
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    move-result v2

    .line 19
    invoke-virtual {v5}, Landroid/graphics/Rect;->width()I

    move-result v3

    int-to-float v3, v3

    div-float/2addr v3, v0

    .line 20
    invoke-virtual {v5}, Landroid/graphics/Rect;->height()I

    move-result v5

    int-to-float v5, v5

    div-float/2addr v5, v0

    mul-float v0, v3, v4

    mul-float v4, v4, v5

    sub-float/2addr v3, v0

    sub-float/2addr v5, v4

    .line 21
    invoke-virtual {p1, v3, v5}, Landroid/graphics/Canvas;->translate(FF)V

    .line 22
    invoke-virtual {p1, v8, v8, v0, v4}, Landroid/graphics/Canvas;->scale(FFFF)V

    .line 23
    :cond_94
    iget-object v0, p0, La6/m;->a:Landroid/graphics/Matrix;

    invoke-virtual {v0}, Landroid/graphics/Matrix;->reset()V

    .line 24
    iget-object v0, p0, La6/m;->a:Landroid/graphics/Matrix;

    invoke-virtual {v0, v6, v7}, Landroid/graphics/Matrix;->preScale(FF)Z

    .line 25
    iget-object v0, p0, La6/m;->a:Landroid/graphics/Matrix;

    iget v3, p0, La6/m;->o:I

    invoke-virtual {v1, p1, v0, v3}, Li6/b;->g(Landroid/graphics/Canvas;Landroid/graphics/Matrix;I)V

    if-lez v2, :cond_120

    .line 26
    invoke-virtual {p1, v2}, Landroid/graphics/Canvas;->restoreToCount(I)V

    goto/16 :goto_120

    .line 27
    :cond_ac
    iget-object v1, p0, La6/m;->n:Li6/c;

    .line 28
    iget-object v4, p0, La6/m;->b:La6/g;

    if-eqz v1, :cond_120

    if-nez v4, :cond_b5

    goto :goto_120

    .line 29
    :cond_b5
    iget v5, p0, La6/m;->d:F

    .line 30
    invoke-virtual {p1}, Landroid/graphics/Canvas;->getWidth()I

    move-result v6

    int-to-float v6, v6

    .line 31
    iget-object v7, v4, La6/g;->j:Landroid/graphics/Rect;

    .line 32
    invoke-virtual {v7}, Landroid/graphics/Rect;->width()I

    move-result v7

    int-to-float v7, v7

    div-float/2addr v6, v7

    .line 33
    invoke-virtual {p1}, Landroid/graphics/Canvas;->getHeight()I

    move-result v7

    int-to-float v7, v7

    .line 34
    iget-object v8, v4, La6/g;->j:Landroid/graphics/Rect;

    .line 35
    invoke-virtual {v8}, Landroid/graphics/Rect;->height()I

    move-result v8

    int-to-float v8, v8

    div-float/2addr v7, v8

    .line 36
    invoke-static {v6, v7}, Ljava/lang/Math;->min(FF)F

    move-result v6

    cmpl-float v7, v5, v6

    if-lez v7, :cond_dd

    .line 37
    iget v5, p0, La6/m;->d:F

    div-float/2addr v5, v6

    goto :goto_e0

    :cond_dd
    move v6, v5

    const/high16 v5, 0x3f800000    # 1.0f

    :goto_e0
    cmpl-float v3, v5, v3

    if-lez v3, :cond_10a

    .line 38
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    move-result v2

    .line 39
    iget-object v3, v4, La6/g;->j:Landroid/graphics/Rect;

    .line 40
    invoke-virtual {v3}, Landroid/graphics/Rect;->width()I

    move-result v3

    int-to-float v3, v3

    div-float/2addr v3, v0

    .line 41
    iget-object v4, v4, La6/g;->j:Landroid/graphics/Rect;

    .line 42
    invoke-virtual {v4}, Landroid/graphics/Rect;->height()I

    move-result v4

    int-to-float v4, v4

    div-float/2addr v4, v0

    mul-float v0, v3, v6

    mul-float v7, v4, v6

    .line 43
    iget v8, p0, La6/m;->d:F

    mul-float v3, v3, v8

    sub-float/2addr v3, v0

    mul-float v8, v8, v4

    sub-float/2addr v8, v7

    .line 44
    invoke-virtual {p1, v3, v8}, Landroid/graphics/Canvas;->translate(FF)V

    .line 45
    invoke-virtual {p1, v5, v5, v0, v7}, Landroid/graphics/Canvas;->scale(FFFF)V

    .line 46
    :cond_10a
    iget-object v0, p0, La6/m;->a:Landroid/graphics/Matrix;

    invoke-virtual {v0}, Landroid/graphics/Matrix;->reset()V

    .line 47
    iget-object v0, p0, La6/m;->a:Landroid/graphics/Matrix;

    invoke-virtual {v0, v6, v6}, Landroid/graphics/Matrix;->preScale(FF)Z

    .line 48
    iget-object v0, p0, La6/m;->a:Landroid/graphics/Matrix;

    iget v3, p0, La6/m;->o:I

    invoke-virtual {v1, p1, v0, v3}, Li6/b;->g(Landroid/graphics/Canvas;Landroid/graphics/Matrix;I)V

    if-lez v2, :cond_120

    .line 49
    invoke-virtual {p1, v2}, Landroid/graphics/Canvas;->restoreToCount(I)V

    :cond_120
    :goto_120
    return-void
.end method

.method public f()F
    .registers 2

    .line 1
    iget-object v0, p0, La6/m;->c:Lm6/d;

    invoke-virtual {v0}, Lm6/d;->e()F

    move-result v0

    return v0
.end method

.method public g()F
    .registers 2

    .line 1
    iget-object v0, p0, La6/m;->c:Lm6/d;

    invoke-virtual {v0}, Lm6/d;->f()F

    move-result v0

    return v0
.end method

.method public getAlpha()I
    .registers 2

    .line 1
    iget v0, p0, La6/m;->o:I

    return v0
.end method

.method public getIntrinsicHeight()I
    .registers 3

    .line 1
    iget-object v0, p0, La6/m;->b:La6/g;

    if-nez v0, :cond_6

    const/4 v0, -0x1

    goto :goto_12

    .line 2
    :cond_6
    iget-object v0, v0, La6/g;->j:Landroid/graphics/Rect;

    .line 3
    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v0

    int-to-float v0, v0

    .line 4
    iget v1, p0, La6/m;->d:F

    mul-float v0, v0, v1

    float-to-int v0, v0

    :goto_12
    return v0
.end method

.method public getIntrinsicWidth()I
    .registers 3

    .line 1
    iget-object v0, p0, La6/m;->b:La6/g;

    if-nez v0, :cond_6

    const/4 v0, -0x1

    goto :goto_12

    .line 2
    :cond_6
    iget-object v0, v0, La6/g;->j:Landroid/graphics/Rect;

    .line 3
    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v0

    int-to-float v0, v0

    .line 4
    iget v1, p0, La6/m;->d:F

    mul-float v0, v0, v1

    float-to-int v0, v0

    :goto_12
    return v0
.end method

.method public getOpacity()I
    .registers 2

    const/4 v0, -0x3

    return v0
.end method

.method public h()F
    .registers 2

    .line 1
    iget-object v0, p0, La6/m;->c:Lm6/d;

    invoke-virtual {v0}, Lm6/d;->d()F

    move-result v0

    return v0
.end method

.method public i()I
    .registers 2

    .line 1
    iget-object v0, p0, La6/m;->c:Lm6/d;

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->getRepeatCount()I

    move-result v0

    return v0
.end method

.method public invalidateDrawable(Landroid/graphics/drawable/Drawable;)V
    .registers 2

    .line 1
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object p1

    if-nez p1, :cond_7

    return-void

    .line 2
    :cond_7
    invoke-interface {p1, p0}, Landroid/graphics/drawable/Drawable$Callback;->invalidateDrawable(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public invalidateSelf()V
    .registers 2

    .line 1
    iget-boolean v0, p0, La6/m;->t:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, La6/m;->t:Z

    .line 3
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object v0

    if-eqz v0, :cond_11

    .line 4
    invoke-interface {v0, p0}, Landroid/graphics/drawable/Drawable$Callback;->invalidateDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_11
    return-void
.end method

.method public isRunning()Z
    .registers 2

    .line 1
    invoke-virtual {p0}, La6/m;->j()Z

    move-result v0

    return v0
.end method

.method public j()Z
    .registers 2

    .line 1
    iget-object v0, p0, La6/m;->c:Lm6/d;

    if-nez v0, :cond_6

    const/4 v0, 0x0

    return v0

    .line 2
    :cond_6
    iget-boolean v0, v0, Lm6/d;->k:Z

    return v0
.end method

.method public k()V
    .registers 7

    .line 1
    iget-object v0, p0, La6/m;->n:Li6/c;

    if-nez v0, :cond_f

    .line 2
    iget-object v0, p0, La6/m;->h:Ljava/util/ArrayList;

    new-instance v1, La6/m$g;

    invoke-direct {v1, p0}, La6/m$g;-><init>(La6/m;)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    .line 3
    :cond_f
    invoke-virtual {p0}, La6/m;->b()Z

    move-result v0

    if-nez v0, :cond_1b

    invoke-virtual {p0}, La6/m;->i()I

    move-result v0

    if-nez v0, :cond_62

    .line 4
    :cond_1b
    iget-object v0, p0, La6/m;->c:Lm6/d;

    const/4 v1, 0x1

    .line 5
    iput-boolean v1, v0, Lm6/d;->k:Z

    .line 6
    invoke-virtual {v0}, Lm6/d;->g()Z

    move-result v1

    .line 7
    iget-object v2, v0, Lm6/a;->b:Ljava/util/Set;

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_2a
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_44

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/animation/Animator$AnimatorListener;

    .line 8
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v5, 0x1a

    if-lt v4, v5, :cond_40

    .line 9
    invoke-interface {v3, v0, v1}, Landroid/animation/Animator$AnimatorListener;->onAnimationStart(Landroid/animation/Animator;Z)V

    goto :goto_2a

    .line 10
    :cond_40
    invoke-interface {v3, v0}, Landroid/animation/Animator$AnimatorListener;->onAnimationStart(Landroid/animation/Animator;)V

    goto :goto_2a

    .line 11
    :cond_44
    invoke-virtual {v0}, Lm6/d;->g()Z

    move-result v1

    if-eqz v1, :cond_4f

    invoke-virtual {v0}, Lm6/d;->e()F

    move-result v1

    goto :goto_53

    :cond_4f
    invoke-virtual {v0}, Lm6/d;->f()F

    move-result v1

    :goto_53
    float-to-int v1, v1

    int-to-float v1, v1

    invoke-virtual {v0, v1}, Lm6/d;->j(F)V

    const-wide/16 v1, 0x0

    .line 12
    iput-wide v1, v0, Lm6/d;->e:J

    const/4 v1, 0x0

    .line 13
    iput v1, v0, Lm6/d;->g:I

    .line 14
    invoke-virtual {v0}, Lm6/d;->h()V

    .line 15
    :cond_62
    invoke-virtual {p0}, La6/m;->b()Z

    move-result v0

    if-nez v0, :cond_83

    .line 16
    iget-object v0, p0, La6/m;->c:Lm6/d;

    .line 17
    iget v0, v0, Lm6/d;->c:F

    const/4 v1, 0x0

    cmpg-float v0, v0, v1

    if-gez v0, :cond_76

    .line 18
    invoke-virtual {p0}, La6/m;->g()F

    move-result v0

    goto :goto_7a

    :cond_76
    invoke-virtual {p0}, La6/m;->f()F

    move-result v0

    :goto_7a
    float-to-int v0, v0

    invoke-virtual {p0, v0}, La6/m;->m(I)V

    .line 19
    iget-object v0, p0, La6/m;->c:Lm6/d;

    invoke-virtual {v0}, Lm6/d;->c()V

    :cond_83
    return-void
.end method

.method public l()V
    .registers 4

    .line 1
    iget-object v0, p0, La6/m;->n:Li6/c;

    if-nez v0, :cond_f

    .line 2
    iget-object v0, p0, La6/m;->h:Ljava/util/ArrayList;

    new-instance v1, La6/m$h;

    invoke-direct {v1, p0}, La6/m$h;-><init>(La6/m;)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    .line 3
    :cond_f
    invoke-virtual {p0}, La6/m;->b()Z

    move-result v0

    if-nez v0, :cond_1b

    invoke-virtual {p0}, La6/m;->i()I

    move-result v0

    if-nez v0, :cond_54

    .line 4
    :cond_1b
    iget-object v0, p0, La6/m;->c:Lm6/d;

    const/4 v1, 0x1

    .line 5
    iput-boolean v1, v0, Lm6/d;->k:Z

    .line 6
    invoke-virtual {v0}, Lm6/d;->h()V

    const-wide/16 v1, 0x0

    .line 7
    iput-wide v1, v0, Lm6/d;->e:J

    .line 8
    invoke-virtual {v0}, Lm6/d;->g()Z

    move-result v1

    if-eqz v1, :cond_3e

    .line 9
    iget v1, v0, Lm6/d;->f:F

    .line 10
    invoke-virtual {v0}, Lm6/d;->f()F

    move-result v2

    cmpl-float v1, v1, v2

    if-nez v1, :cond_3e

    .line 11
    invoke-virtual {v0}, Lm6/d;->e()F

    move-result v1

    iput v1, v0, Lm6/d;->f:F

    goto :goto_54

    .line 12
    :cond_3e
    invoke-virtual {v0}, Lm6/d;->g()Z

    move-result v1

    if-nez v1, :cond_54

    .line 13
    iget v1, v0, Lm6/d;->f:F

    .line 14
    invoke-virtual {v0}, Lm6/d;->e()F

    move-result v2

    cmpl-float v1, v1, v2

    if-nez v1, :cond_54

    .line 15
    invoke-virtual {v0}, Lm6/d;->f()F

    move-result v1

    iput v1, v0, Lm6/d;->f:F

    .line 16
    :cond_54
    :goto_54
    invoke-virtual {p0}, La6/m;->b()Z

    move-result v0

    if-nez v0, :cond_75

    .line 17
    iget-object v0, p0, La6/m;->c:Lm6/d;

    .line 18
    iget v0, v0, Lm6/d;->c:F

    const/4 v1, 0x0

    cmpg-float v0, v0, v1

    if-gez v0, :cond_68

    .line 19
    invoke-virtual {p0}, La6/m;->g()F

    move-result v0

    goto :goto_6c

    :cond_68
    invoke-virtual {p0}, La6/m;->f()F

    move-result v0

    :goto_6c
    float-to-int v0, v0

    invoke-virtual {p0, v0}, La6/m;->m(I)V

    .line 20
    iget-object v0, p0, La6/m;->c:Lm6/d;

    invoke-virtual {v0}, Lm6/d;->c()V

    :cond_75
    return-void
.end method

.method public m(I)V
    .registers 4

    .line 1
    iget-object v0, p0, La6/m;->b:La6/g;

    if-nez v0, :cond_f

    .line 2
    iget-object v0, p0, La6/m;->h:Ljava/util/ArrayList;

    new-instance v1, La6/m$c;

    invoke-direct {v1, p0, p1}, La6/m$c;-><init>(La6/m;I)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    .line 3
    :cond_f
    iget-object v0, p0, La6/m;->c:Lm6/d;

    int-to-float p1, p1

    invoke-virtual {v0, p1}, Lm6/d;->j(F)V

    return-void
.end method

.method public n(I)V
    .registers 4

    .line 1
    iget-object v0, p0, La6/m;->b:La6/g;

    if-nez v0, :cond_f

    .line 2
    iget-object v0, p0, La6/m;->h:Ljava/util/ArrayList;

    new-instance v1, La6/m$k;

    invoke-direct {v1, p0, p1}, La6/m$k;-><init>(La6/m;I)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    .line 3
    :cond_f
    iget-object v0, p0, La6/m;->c:Lm6/d;

    int-to-float p1, p1

    const v1, 0x3f7d70a4    # 0.99f

    add-float/2addr p1, v1

    .line 4
    iget v1, v0, Lm6/d;->h:F

    invoke-virtual {v0, v1, p1}, Lm6/d;->k(FF)V

    return-void
.end method

.method public o(Ljava/lang/String;)V
    .registers 5

    .line 1
    iget-object v0, p0, La6/m;->b:La6/g;

    if-nez v0, :cond_f

    .line 2
    iget-object v0, p0, La6/m;->h:Ljava/util/ArrayList;

    new-instance v1, La6/m$n;

    invoke-direct {v1, p0, p1}, La6/m$n;-><init>(La6/m;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    .line 3
    :cond_f
    invoke-virtual {v0, p1}, La6/g;->d(Ljava/lang/String;)Lf6/h;

    move-result-object v0

    if-eqz v0, :cond_1f

    .line 4
    iget p1, v0, Lf6/h;->b:F

    iget v0, v0, Lf6/h;->c:F

    add-float/2addr p1, v0

    float-to-int p1, p1

    invoke-virtual {p0, p1}, La6/m;->n(I)V

    return-void

    .line 5
    :cond_1f
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Cannot find marker with name "

    const-string v2, "."

    invoke-static {v1, p1, v2}, Lp/f;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public p(F)V
    .registers 4

    .line 1
    iget-object v0, p0, La6/m;->b:La6/g;

    if-nez v0, :cond_f

    .line 2
    iget-object v0, p0, La6/m;->h:Ljava/util/ArrayList;

    new-instance v1, La6/m$l;

    invoke-direct {v1, p0, p1}, La6/m$l;-><init>(La6/m;F)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    .line 3
    :cond_f
    iget v1, v0, La6/g;->k:F

    .line 4
    iget v0, v0, La6/g;->l:F

    .line 5
    invoke-static {v1, v0, p1}, Lm6/f;->e(FFF)F

    move-result p1

    float-to-int p1, p1

    invoke-virtual {p0, p1}, La6/m;->n(I)V

    return-void
.end method

.method public q(II)V
    .registers 5

    .line 1
    iget-object v0, p0, La6/m;->b:La6/g;

    if-nez v0, :cond_f

    .line 2
    iget-object v0, p0, La6/m;->h:Ljava/util/ArrayList;

    new-instance v1, La6/m$b;

    invoke-direct {v1, p0, p1, p2}, La6/m$b;-><init>(La6/m;II)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    .line 3
    :cond_f
    iget-object v0, p0, La6/m;->c:Lm6/d;

    int-to-float p1, p1

    int-to-float p2, p2

    const v1, 0x3f7d70a4    # 0.99f

    add-float/2addr p2, v1

    invoke-virtual {v0, p1, p2}, Lm6/d;->k(FF)V

    return-void
.end method

.method public r(Ljava/lang/String;)V
    .registers 5

    .line 1
    iget-object v0, p0, La6/m;->b:La6/g;

    if-nez v0, :cond_f

    .line 2
    iget-object v0, p0, La6/m;->h:Ljava/util/ArrayList;

    new-instance v1, La6/m$a;

    invoke-direct {v1, p0, p1}, La6/m$a;-><init>(La6/m;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    .line 3
    :cond_f
    invoke-virtual {v0, p1}, La6/g;->d(Ljava/lang/String;)Lf6/h;

    move-result-object v0

    if-eqz v0, :cond_20

    .line 4
    iget p1, v0, Lf6/h;->b:F

    float-to-int p1, p1

    .line 5
    iget v0, v0, Lf6/h;->c:F

    float-to-int v0, v0

    add-int/2addr v0, p1

    invoke-virtual {p0, p1, v0}, La6/m;->q(II)V

    return-void

    .line 6
    :cond_20
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Cannot find marker with name "

    const-string v2, "."

    invoke-static {v1, p1, v2}, Lp/f;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public s(I)V
    .registers 4

    .line 1
    iget-object v0, p0, La6/m;->b:La6/g;

    if-nez v0, :cond_f

    .line 2
    iget-object v0, p0, La6/m;->h:Ljava/util/ArrayList;

    new-instance v1, La6/m$i;

    invoke-direct {v1, p0, p1}, La6/m$i;-><init>(La6/m;I)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    .line 3
    :cond_f
    iget-object v0, p0, La6/m;->c:Lm6/d;

    int-to-float p1, p1

    .line 4
    iget v1, v0, Lm6/d;->i:F

    float-to-int v1, v1

    int-to-float v1, v1

    invoke-virtual {v0, p1, v1}, Lm6/d;->k(FF)V

    return-void
.end method

.method public scheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;J)V
    .registers 5

    .line 1
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object p1

    if-nez p1, :cond_7

    return-void

    .line 2
    :cond_7
    invoke-interface {p1, p0, p2, p3, p4}, Landroid/graphics/drawable/Drawable$Callback;->scheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;J)V

    return-void
.end method

.method public setAlpha(I)V
    .registers 2

    .line 1
    iput p1, p0, La6/m;->o:I

    .line 2
    invoke-virtual {p0}, La6/m;->invalidateSelf()V

    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .registers 2

    const-string p1, "Use addColorFilter instead."

    .line 1
    invoke-static {p1}, Lm6/c;->a(Ljava/lang/String;)V

    return-void
.end method

.method public start()V
    .registers 3

    .line 1
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object v0

    .line 2
    instance-of v1, v0, Landroid/view/View;

    if-eqz v1, :cond_13

    check-cast v0, Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->isInEditMode()Z

    move-result v0

    if-nez v0, :cond_13

    .line 3
    invoke-virtual {p0}, La6/m;->k()V

    :cond_13
    return-void
.end method

.method public stop()V
    .registers 2

    .line 1
    iget-object v0, p0, La6/m;->h:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 2
    iget-object v0, p0, La6/m;->c:Lm6/d;

    invoke-virtual {v0}, Lm6/d;->c()V

    return-void
.end method

.method public t(Ljava/lang/String;)V
    .registers 5

    .line 1
    iget-object v0, p0, La6/m;->b:La6/g;

    if-nez v0, :cond_f

    .line 2
    iget-object v0, p0, La6/m;->h:Ljava/util/ArrayList;

    new-instance v1, La6/m$m;

    invoke-direct {v1, p0, p1}, La6/m$m;-><init>(La6/m;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    .line 3
    :cond_f
    invoke-virtual {v0, p1}, La6/g;->d(Ljava/lang/String;)Lf6/h;

    move-result-object v0

    if-eqz v0, :cond_1c

    .line 4
    iget p1, v0, Lf6/h;->b:F

    float-to-int p1, p1

    invoke-virtual {p0, p1}, La6/m;->s(I)V

    return-void

    .line 5
    :cond_1c
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Cannot find marker with name "

    const-string v2, "."

    invoke-static {v1, p1, v2}, Lp/f;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public u(F)V
    .registers 4

    .line 1
    iget-object v0, p0, La6/m;->b:La6/g;

    if-nez v0, :cond_f

    .line 2
    iget-object v0, p0, La6/m;->h:Ljava/util/ArrayList;

    new-instance v1, La6/m$j;

    invoke-direct {v1, p0, p1}, La6/m$j;-><init>(La6/m;F)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    .line 3
    :cond_f
    iget v1, v0, La6/g;->k:F

    .line 4
    iget v0, v0, La6/g;->l:F

    .line 5
    invoke-static {v1, v0, p1}, Lm6/f;->e(FFF)F

    move-result p1

    float-to-int p1, p1

    invoke-virtual {p0, p1}, La6/m;->s(I)V

    return-void
.end method

.method public unscheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;)V
    .registers 3

    .line 1
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object p1

    if-nez p1, :cond_7

    return-void

    .line 2
    :cond_7
    invoke-interface {p1, p0, p2}, Landroid/graphics/drawable/Drawable$Callback;->unscheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;)V

    return-void
.end method

.method public v(F)V
    .registers 5

    .line 1
    iget-object v0, p0, La6/m;->b:La6/g;

    if-nez v0, :cond_f

    .line 2
    iget-object v0, p0, La6/m;->h:Ljava/util/ArrayList;

    new-instance v1, La6/m$d;

    invoke-direct {v1, p0, p1}, La6/m$d;-><init>(La6/m;F)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    .line 3
    :cond_f
    iget-object v1, p0, La6/m;->c:Lm6/d;

    .line 4
    iget v2, v0, La6/g;->k:F

    iget v0, v0, La6/g;->l:F

    invoke-static {v2, v0, p1}, Lm6/f;->e(FFF)F

    move-result p1

    .line 5
    invoke-virtual {v1, p1}, Lm6/d;->j(F)V

    const-string p1, "Drawable#setProgress"

    .line 6
    invoke-static {p1}, La6/d;->m(Ljava/lang/String;)F

    return-void
.end method
