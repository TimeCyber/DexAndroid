.class public final La2/h;
.super Ljava/lang/Object;
.source "StaticLayoutFactory.kt"


# static fields
.field public static final a:La2/h;

.field public static final b:La2/i;


# direct methods
.method public static constructor <clinit>()V
    .registers 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x17

    if-lt v0, v1, :cond_c

    .line 2
    new-instance v0, La2/e;

    invoke-direct {v0}, La2/e;-><init>()V

    goto :goto_11

    .line 3
    :cond_c
    new-instance v0, La2/j;

    invoke-direct {v0}, La2/j;-><init>()V

    .line 4
    :goto_11
    sput-object v0, La2/h;->b:La2/i;

    return-void
.end method
