.class public final La0/r;
.super Ljava/lang/Object;
.source "Animation.kt"

# interfaces
.implements La0/c;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "V:",
        "La0/n;",
        ">",
        "Ljava/lang/Object;",
        "La0/c<",
        "TT;TV;>;"
    }
.end annotation


# instance fields
.field public final a:La0/b1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/b1<",
            "TV;>;"
        }
    .end annotation
.end field

.field public final b:La0/u0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/u0<",
            "TT;TV;>;"
        }
    .end annotation
.end field

.field public final c:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field

.field public final d:La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field

.field public final e:La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field

.field public final f:La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field

.field public final g:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field

.field public final h:J


# direct methods
.method public constructor <init>(La0/s;La0/u0;Ljava/lang/Object;La0/n;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La0/s<",
            "TT;>;",
            "La0/u0<",
            "TT;TV;>;TT;TV;)V"
        }
    .end annotation

    const-string v0, "animationSpec"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "typeConverter"

    invoke-static {p2, v1}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "initialVelocityVector"

    invoke-static {p4, v1}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-interface {p1, p2}, La0/s;->a(La0/u0;)La0/b1;

    move-result-object p1

    .line 2
    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La0/r;->a:La0/b1;

    .line 5
    iput-object p2, p0, La0/r;->b:La0/u0;

    .line 6
    iput-object p3, p0, La0/r;->c:Ljava/lang/Object;

    .line 7
    invoke-interface {p2}, La0/u0;->a()Lvg/l;

    move-result-object v0

    invoke-interface {v0, p3}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, La0/n;

    iput-object p3, p0, La0/r;->d:La0/n;

    .line 8
    invoke-static {p4}, Landroidx/appcompat/widget/m;->s(La0/n;)La0/n;

    move-result-object v0

    iput-object v0, p0, La0/r;->e:La0/n;

    .line 9
    invoke-interface {p2}, La0/u0;->b()Lvg/l;

    move-result-object p2

    .line 10
    invoke-interface {p1, p3, p4}, La0/b1;->e(La0/n;La0/n;)La0/n;

    move-result-object v0

    .line 11
    invoke-interface {p2, v0}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    iput-object p2, p0, La0/r;->g:Ljava/lang/Object;

    .line 12
    invoke-interface {p1, p3, p4}, La0/b1;->c(La0/n;La0/n;)J

    move-result-wide v0

    iput-wide v0, p0, La0/r;->h:J

    .line 13
    invoke-interface {p1, v0, v1, p3, p4}, La0/b1;->b(JLa0/n;La0/n;)La0/n;

    move-result-object p1

    .line 14
    invoke-static {p1}, Landroidx/appcompat/widget/m;->s(La0/n;)La0/n;

    move-result-object p1

    .line 15
    iput-object p1, p0, La0/r;->f:La0/n;

    const/4 p2, 0x0

    .line 16
    invoke-virtual {p1}, La0/n;->b()I

    move-result p1

    :goto_54
    if-ge p2, p1, :cond_73

    .line 17
    iget-object p3, p0, La0/r;->f:La0/n;

    invoke-virtual {p3, p2}, La0/n;->a(I)F

    move-result p4

    .line 18
    iget-object v0, p0, La0/r;->a:La0/b1;

    invoke-interface {v0}, La0/b1;->a()F

    move-result v0

    neg-float v0, v0

    .line 19
    iget-object v1, p0, La0/r;->a:La0/b1;

    invoke-interface {v1}, La0/b1;->a()F

    move-result v1

    .line 20
    invoke-static {p4, v0, v1}, Li0/z0;->l(FFF)F

    move-result p4

    invoke-virtual {p3, p2, p4}, La0/n;->e(IF)V

    add-int/lit8 p2, p2, 0x1

    goto :goto_54

    :cond_73
    return-void
.end method


# virtual methods
.method public a()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public b()J
    .registers 3

    .line 1
    iget-wide v0, p0, La0/r;->h:J

    return-wide v0
.end method

.method public c()La0/u0;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "La0/u0<",
            "TT;TV;>;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La0/r;->b:La0/u0;

    return-object v0
.end method

.method public d(J)La0/n;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J)TV;"
        }
    .end annotation

    .line 1
    invoke-virtual {p0, p1, p2}, La0/r;->e(J)Z

    move-result v0

    if-nez v0, :cond_11

    .line 2
    iget-object v0, p0, La0/r;->a:La0/b1;

    .line 3
    iget-object v1, p0, La0/r;->d:La0/n;

    .line 4
    iget-object v2, p0, La0/r;->e:La0/n;

    .line 5
    invoke-interface {v0, p1, p2, v1, v2}, La0/b1;->b(JLa0/n;La0/n;)La0/n;

    move-result-object p1

    return-object p1

    .line 6
    :cond_11
    iget-object p1, p0, La0/r;->f:La0/n;

    return-object p1
.end method

.method public e(J)Z
    .registers 6

    .line 1
    iget-wide v0, p0, La0/r;->h:J

    cmp-long v2, p1, v0

    if-ltz v2, :cond_8

    const/4 p1, 0x1

    goto :goto_9

    :cond_8
    const/4 p1, 0x0

    :goto_9
    return p1
.end method

.method public f(J)Ljava/lang/Object;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J)TT;"
        }
    .end annotation

    .line 1
    invoke-virtual {p0, p1, p2}, La0/r;->e(J)Z

    move-result v0

    if-nez v0, :cond_1b

    .line 2
    iget-object v0, p0, La0/r;->b:La0/u0;

    .line 3
    invoke-interface {v0}, La0/u0;->b()Lvg/l;

    move-result-object v0

    .line 4
    iget-object v1, p0, La0/r;->a:La0/b1;

    .line 5
    iget-object v2, p0, La0/r;->d:La0/n;

    .line 6
    iget-object v3, p0, La0/r;->e:La0/n;

    .line 7
    invoke-interface {v1, p1, p2, v2, v3}, La0/b1;->d(JLa0/n;La0/n;)La0/n;

    move-result-object p1

    .line 8
    invoke-interface {v0, p1}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 9
    :cond_1b
    iget-object p1, p0, La0/r;->g:Ljava/lang/Object;

    return-object p1
.end method

.method public g()Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La0/r;->g:Ljava/lang/Object;

    return-object v0
.end method
