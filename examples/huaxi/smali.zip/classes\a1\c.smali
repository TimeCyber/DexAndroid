.class public final La1/c;
.super Landroidx/compose/ui/platform/e1;
.source "DrawModifier.kt"

# interfaces
.implements La1/f;


# instance fields
.field public final b:Lvg/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lvg/l<",
            "Lf1/g;",
            "Lkg/l;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lvg/l;Lvg/l;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lvg/l<",
            "-",
            "Lf1/g;",
            "Lkg/l;",
            ">;",
            "Lvg/l<",
            "-",
            "Landroidx/compose/ui/platform/d1;",
            "Lkg/l;",
            ">;)V"
        }
    .end annotation

    const-string v0, "inspectorInfo"

    invoke-static {p2, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0, p2}, Landroidx/compose/ui/platform/e1;-><init>(Lvg/l;)V

    .line 2
    iput-object p1, p0, La1/c;->b:Lvg/l;

    return-void
.end method


# virtual methods
.method public K(Lf1/d;)V
    .registers 3

    .line 1
    iget-object v0, p0, La1/c;->b:Lvg/l;

    invoke-interface {v0, p1}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 2
    check-cast p1, Lt1/o;

    invoke-virtual {p1}, Lt1/o;->u0()V

    return-void
.end method

.method public synthetic Q(Ljava/lang/Object;Lvg/p;)Ljava/lang/Object;
    .registers 3

    invoke-static {p0, p1, p2}, Lv7/d;->b(Ly0/h$b;Ljava/lang/Object;Lvg/p;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 3

    if-ne p0, p1, :cond_4

    const/4 p1, 0x1

    return p1

    .line 1
    :cond_4
    instance-of v0, p1, La1/c;

    if-nez v0, :cond_a

    const/4 p1, 0x0

    return p1

    .line 2
    :cond_a
    iget-object v0, p0, La1/c;->b:Lvg/l;

    check-cast p1, La1/c;

    iget-object p1, p1, La1/c;->b:Lvg/l;

    invoke-static {v0, p1}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public hashCode()I
    .registers 2

    .line 1
    iget-object v0, p0, La1/c;->b:Lvg/l;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    return v0
.end method

.method public synthetic p0(Ly0/h;)Ly0/h;
    .registers 2

    invoke-static {p0, p1}, Landroidx/fragment/app/n;->b(Ly0/h;Ly0/h;)Ly0/h;

    move-result-object p1

    return-object p1
.end method

.method public synthetic v0(Ljava/lang/Object;Lvg/p;)Ljava/lang/Object;
    .registers 3

    invoke-static {p0, p1, p2}, Lv7/d;->c(Ly0/h$b;Ljava/lang/Object;Lvg/p;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public synthetic x(Lvg/l;)Z
    .registers 2

    invoke-static {p0, p1}, Lv7/d;->a(Ly0/h$b;Lvg/l;)Z

    move-result p1

    return p1
.end method
