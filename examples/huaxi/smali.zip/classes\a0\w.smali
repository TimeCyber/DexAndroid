.class public interface abstract La0/w;
.super Ljava/lang/Object;
.source "Easing.kt"


# virtual methods
.method public abstract a(F)F
.end method
