.class public final La3/j;
.super Ljava/lang/Object;
.source "MultiWindowModeChangedInfo.java"


# instance fields
.field public final a:Z

.field public final b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lva/m;Z)V
    .registers 3

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    iput-boolean p2, p0, La3/j;->a:Z

    .line 7
    iput-object p1, p0, La3/j;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(ZI)V
    .registers 5

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-eq p2, v1, :cond_c

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-boolean p1, p0, La3/j;->a:Z

    .line 3
    iput-object v0, p0, La3/j;->b:Ljava/lang/Object;

    return-void

    .line 4
    :cond_c
    invoke-direct {p0, v0, p1}, La3/j;-><init>(Lva/m;Z)V

    return-void
.end method

.method public synthetic constructor <init>(ZLandroid/content/res/Configuration;)V
    .registers 3

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 9
    iput-boolean p1, p0, La3/j;->a:Z

    .line 10
    iput-object p2, p0, La3/j;->b:Ljava/lang/Object;

    return-void
.end method
