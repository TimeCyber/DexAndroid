.class public Lac/d;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static a:Landroid/content/SharedPreferences;


# direct methods
.method public static declared-synchronized a(Landroid/content/Context;)Landroid/content/SharedPreferences;
    .registers 5

    const-class v0, Lac/d;

    monitor-enter v0

    .line 1
    :try_start_3
    sget-object v1, Lac/d;->a:Landroid/content/SharedPreferences;

    if-nez v1, :cond_27

    .line 2
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x18

    const/4 v3, 0x0

    if-lt v1, v2, :cond_1b

    .line 3
    invoke-virtual {p0}, Landroid/content/Context;->createDeviceProtectedStorageContext()Landroid/content/Context;

    move-result-object p0

    const-string v1, "aegis"

    invoke-virtual {p0, v1, v3}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    sput-object p0, Lac/d;->a:Landroid/content/SharedPreferences;

    goto :goto_27

    .line 4
    :cond_1b
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const-string v1, "aegis"

    invoke-virtual {p0, v1, v3}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    sput-object p0, Lac/d;->a:Landroid/content/SharedPreferences;

    .line 5
    :cond_27
    :goto_27
    sget-object p0, Lac/d;->a:Landroid/content/SharedPreferences;
    :try_end_29
    .catchall {:try_start_3 .. :try_end_29} :catchall_2b

    monitor-exit v0

    return-object p0

    :catchall_2b
    move-exception p0

    monitor-exit v0

    throw p0
.end method
