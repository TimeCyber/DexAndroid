.class public final La0/e1$a;
.super Ljava/lang/Object;
.source "VectorizedAnimationSpec.kt"

# interfaces
.implements La0/o;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La0/e1;-><init>(La0/z;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field public final synthetic a:La0/z;


# direct methods
.method public constructor <init>(La0/z;)V
    .registers 2

    iput-object p1, p0, La0/e1$a;->a:La0/z;

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public get(I)La0/z;
    .registers 2

    .line 1
    iget-object p1, p0, La0/e1$a;->a:La0/z;

    return-object p1
.end method
