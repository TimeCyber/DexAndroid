.class public final La0/v0;
.super Ljava/lang/Object;
.source "VectorConverters.kt"

# interfaces
.implements La0/u0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "V:",
        "La0/n;",
        ">",
        "Ljava/lang/Object;",
        "La0/u0<",
        "TT;TV;>;"
    }
.end annotation


# instance fields
.field public final a:Lvg/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lvg/l<",
            "TT;TV;>;"
        }
    .end annotation
.end field

.field public final b:Lvg/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lvg/l<",
            "TV;TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lvg/l;Lvg/l;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lvg/l<",
            "-TT;+TV;>;",
            "Lvg/l<",
            "-TV;+TT;>;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, La0/v0;->a:Lvg/l;

    .line 3
    iput-object p2, p0, La0/v0;->b:Lvg/l;

    return-void
.end method


# virtual methods
.method public a()Lvg/l;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lvg/l<",
            "TT;TV;>;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La0/v0;->a:Lvg/l;

    return-object v0
.end method

.method public b()Lvg/l;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lvg/l<",
            "TV;TT;>;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La0/v0;->b:Lvg/l;

    return-object v0
.end method
