.class public final La0/g0$a;
.super Ljava/lang/Object;
.source "InternalMutatorMutex.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La0/g0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:I

.field public final b:Lgh/g1;


# direct methods
.method public constructor <init>(ILgh/g1;)V
    .registers 4

    const-string v0, "priority"

    invoke-static {p1, v0}, Lp/e;->a(ILjava/lang/String;)V

    const-string v0, "job"

    invoke-static {p2, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, La0/g0$a;->a:I

    iput-object p2, p0, La0/g0$a;->b:Lgh/g1;

    return-void
.end method
