.class public final La0/e0;
.super Ljava/lang/Object;
.source "AnimationSpec.kt"

# interfaces
.implements La0/g;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "La0/g<",
        "TT;>;"
    }
.end annotation


# instance fields
.field public final a:La0/v;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/v<",
            "TT;>;"
        }
    .end annotation
.end field

.field public final b:I

.field public final c:J


# direct methods
.method public constructor <init>(La0/v;IJLwg/e;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, La0/e0;->a:La0/v;

    .line 3
    iput p2, p0, La0/e0;->b:I

    .line 4
    iput-wide p3, p0, La0/e0;->c:J

    return-void
.end method


# virtual methods
.method public a(La0/u0;)La0/y0;
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<V:",
            "La0/n;",
            ">(",
            "La0/u0<",
            "TT;TV;>;)",
            "La0/y0<",
            "TV;>;"
        }
    .end annotation

    .line 1
    new-instance v6, La0/g1;

    .line 2
    iget-object v0, p0, La0/e0;->a:La0/v;

    invoke-interface {v0, p1}, La0/v;->a(La0/u0;)La0/d1;

    move-result-object v1

    iget v2, p0, La0/e0;->b:I

    iget-wide v3, p0, La0/e0;->c:J

    const/4 v5, 0x0

    move-object v0, v6

    .line 3
    invoke-direct/range {v0 .. v5}, La0/g1;-><init>(La0/d1;IJLwg/e;)V

    return-object v6
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 9

    .line 1
    instance-of v0, p1, La0/e0;

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_26

    .line 2
    check-cast p1, La0/e0;

    iget-object v0, p1, La0/e0;->a:La0/v;

    iget-object v3, p0, La0/e0;->a:La0/v;

    invoke-static {v0, v3}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_26

    iget v0, p1, La0/e0;->b:I

    iget v3, p0, La0/e0;->b:I

    if-ne v0, v3, :cond_26

    .line 3
    iget-wide v3, p1, La0/e0;->c:J

    iget-wide v5, p0, La0/e0;->c:J

    cmp-long p1, v3, v5

    if-nez p1, :cond_22

    const/4 p1, 0x1

    goto :goto_23

    :cond_22
    const/4 p1, 0x0

    :goto_23
    if-eqz p1, :cond_26

    const/4 v1, 0x1

    :cond_26
    return v1
.end method

.method public hashCode()I
    .registers 7

    .line 1
    iget-object v0, p0, La0/e0;->a:La0/v;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, La0/e0;->b:I

    invoke-static {v1}, Lm/o;->c(I)I

    move-result v1

    add-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x1f

    .line 2
    iget-wide v2, p0, La0/e0;->c:J

    const/16 v0, 0x20

    ushr-long v4, v2, v0

    xor-long/2addr v2, v4

    long-to-int v0, v2

    add-int/2addr v1, v0

    return v1
.end method
