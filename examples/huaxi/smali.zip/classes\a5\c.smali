.class public La5/c;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Lc5/a;


# instance fields
.field public a:Lu4/h;

.field public b:Ljava/lang/String;

.field public c:Lv4/c;

.field public d:Z

.field public e:La5/g;


# direct methods
.method public constructor <init>(Lu4/h;La5/g;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, La5/c;->c:Lv4/c;

    const/4 v1, 0x0

    .line 3
    iput-boolean v1, p0, La5/c;->d:Z

    .line 4
    iput-object v0, p0, La5/c;->e:La5/g;

    .line 5
    iput-object p1, p0, La5/c;->a:Lu4/h;

    .line 6
    iput-object p2, p0, La5/c;->e:La5/g;

    if-eqz p1, :cond_1c

    .line 7
    :try_start_11
    invoke-interface {p1}, Lu4/h;->h()B

    move-result p1

    and-int/lit8 p1, p1, 0x8

    if-eqz p1, :cond_1c

    const/4 p1, 0x1

    .line 8
    iput-boolean p1, p0, La5/c;->d:Z
    :try_end_1c
    .catch Landroid/os/RemoteException; {:try_start_11 .. :try_end_1c} :catch_1c

    :catch_1c
    :cond_1c
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Runnable;)V
    .registers 4

    .line 1
    iget-object v0, p0, La5/c;->e:La5/g;

    .line 2
    iget-boolean v0, v0, La5/g;->k:Z

    if-eqz v0, :cond_a

    .line 3
    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    goto :goto_26

    .line 4
    :cond_a
    iget-object v0, p0, La5/c;->b:Ljava/lang/String;

    if-eqz v0, :cond_13

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    goto :goto_17

    :cond_13
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    .line 5
    :goto_17
    sget-object v1, La5/a;->a:[Ljava/util/concurrent/ExecutorService;

    .line 6
    rem-int/lit8 v0, v0, 0x2

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v0

    .line 7
    sget-object v1, La5/a;->a:[Ljava/util/concurrent/ExecutorService;

    aget-object v0, v1, v0

    invoke-interface {v0, p1}, Ljava/util/concurrent/ExecutorService;->submit(Ljava/lang/Runnable;)Ljava/util/concurrent/Future;

    :goto_26
    return-void
.end method

.method public b(IILanet/channel/bytes/ByteArray;)V
    .registers 11

    .line 1
    iget-object v5, p0, La5/c;->a:Lu4/h;

    if-eqz v5, :cond_11

    .line 2
    new-instance v6, La5/e;

    move-object v0, v6

    move-object v1, p0

    move v2, p1

    move-object v3, p3

    move v4, p2

    invoke-direct/range {v0 .. v5}, La5/e;-><init>(La5/c;ILanet/channel/bytes/ByteArray;ILu4/h;)V

    .line 3
    invoke-virtual {p0, v6}, La5/c;->a(Ljava/lang/Runnable;)V

    :cond_11
    return-void
.end method

.method public c(Lu4/b;)V
    .registers 6

    const/4 v0, 0x2

    .line 1
    invoke-static {v0}, Lanet/channel/util/ALog;->isPrintLog(I)Z

    move-result v0

    if-eqz v0, :cond_13

    .line 2
    iget-object v0, p0, La5/c;->b:Ljava/lang/String;

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/Object;

    const-string v2, "anet.Repeater"

    const-string v3, "[onFinish] "

    invoke-static {v2, v3, v0, v1}, Lanet/channel/util/ALog;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 3
    :cond_13
    iget-object v0, p0, La5/c;->a:Lu4/h;

    if-eqz v0, :cond_29

    .line 4
    new-instance v1, La5/f;

    invoke-direct {v1, p0, p1, v0}, La5/f;-><init>(La5/c;Lu4/b;Lu4/h;)V

    .line 5
    iget-object p1, p1, Lu4/b;->e:Lanet/channel/statist/RequestStatistic;

    if-eqz p1, :cond_26

    .line 6
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    iput-wide v2, p1, Lanet/channel/statist/RequestStatistic;->rspCbDispatch:J

    .line 7
    :cond_26
    invoke-virtual {p0, v1}, La5/c;->a(Ljava/lang/Runnable;)V

    :cond_29
    const/4 p1, 0x0

    .line 8
    iput-object p1, p0, La5/c;->a:Lu4/h;

    return-void
.end method

.method public d(ILjava/util/Map;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;>;)V"
        }
    .end annotation

    const/4 v0, 0x2

    .line 1
    invoke-static {v0}, Lanet/channel/util/ALog;->isPrintLog(I)Z

    move-result v0

    if-eqz v0, :cond_13

    .line 2
    iget-object v0, p0, La5/c;->b:Ljava/lang/String;

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/Object;

    const-string v2, "anet.Repeater"

    const-string v3, "[onResponseCode]"

    invoke-static {v2, v3, v0, v1}, Lanet/channel/util/ALog;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 3
    :cond_13
    iget-object v0, p0, La5/c;->a:Lu4/h;

    if-eqz v0, :cond_1f

    .line 4
    new-instance v1, La5/d;

    invoke-direct {v1, p0, v0, p1, p2}, La5/d;-><init>(La5/c;Lu4/h;ILjava/util/Map;)V

    .line 5
    invoke-virtual {p0, v1}, La5/c;->a(Ljava/lang/Runnable;)V

    :cond_1f
    return-void
.end method
