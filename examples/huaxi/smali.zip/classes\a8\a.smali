.class public final La8/a;
.super Ljava/lang/Object;
.source "FactoryPools.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La8/a$c;,
        La8/a$d;,
        La8/a$e;,
        La8/a$b;
    }
.end annotation


# static fields
.field public static final a:La8/a$e;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La8/a$e<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, La8/a$a;

    invoke-direct {v0}, La8/a$a;-><init>()V

    sput-object v0, La8/a;->a:La8/a$e;

    return-void
.end method

.method public static a(ILa8/a$b;)Lk3/d;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "La8/a$d;",
            ">(I",
            "La8/a$b<",
            "TT;>;)",
            "Lk3/d<",
            "TT;>;"
        }
    .end annotation

    .line 1
    new-instance v0, Lk3/e;

    invoke-direct {v0, p0}, Lk3/e;-><init>(I)V

    .line 2
    sget-object p0, La8/a;->a:La8/a$e;

    .line 3
    new-instance v1, La8/a$c;

    invoke-direct {v1, v0, p1, p0}, La8/a$c;-><init>(Lk3/d;La8/a$b;La8/a$e;)V

    return-object v1
.end method
