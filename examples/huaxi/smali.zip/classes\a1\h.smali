.class public final La1/h;
.super Ljava/lang/Object;
.source "DrawModifier.kt"


# instance fields
.field public a:Lvg/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lvg/l<",
            "-",
            "Lf1/d;",
            "Lkg/l;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lvg/l;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lvg/l<",
            "-",
            "Lf1/d;",
            "Lkg/l;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La1/h;->a:Lvg/l;

    return-void
.end method
