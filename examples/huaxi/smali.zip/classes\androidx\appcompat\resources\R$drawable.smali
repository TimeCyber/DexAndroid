.class public final Landroidx/appcompat/resources/R$drawable;
.super Ljava/lang/Object;


# static fields
.field public static final abc_vector_test:I = 0x7f070056


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
