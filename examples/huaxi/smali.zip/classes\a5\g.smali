.class public La5/g;
.super Ljava/lang/Object;
.source "Taobao"


# instance fields
.field public a:Lu4/i;

.field public b:Lanet/channel/request/Request;

.field public c:I

.field public d:I

.field public e:I

.field public f:Lanet/channel/statist/RequestStatistic;

.field public final g:I

.field public final h:I

.field public final i:Ljava/lang/String;

.field public final j:I

.field public final k:Z


# direct methods
.method public constructor <init>(Lu4/i;IZ)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, La5/g;->b:Lanet/channel/request/Request;

    const/4 v0, 0x0

    .line 3
    iput v0, p0, La5/g;->c:I

    .line 4
    iput v0, p0, La5/g;->d:I

    .line 5
    iput v0, p0, La5/g;->e:I

    if-eqz p1, :cond_c2

    .line 6
    iput-object p1, p0, La5/g;->a:Lu4/i;

    .line 7
    iput p2, p0, La5/g;->j:I

    .line 8
    iput-boolean p3, p0, La5/g;->k:Z

    .line 9
    iget-object p3, p1, Lu4/i;->l:Ljava/lang/String;

    if-nez p2, :cond_1c

    const-string p2, "HTTP"

    goto :goto_1e

    :cond_1c
    const-string p2, "DGRD"

    :goto_1e
    sget-object v0, Lh5/a;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 10
    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x10

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    if-eqz p3, :cond_31

    .line 11
    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p3, 0x2e

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 12
    :cond_31
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object p2, Lh5/a;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {p2}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    move-result p2

    const p3, 0x7fffffff

    and-int/2addr p2, p3

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 13
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    .line 14
    iput-object p2, p0, La5/g;->i:Ljava/lang/String;

    .line 15
    iget p2, p1, Lu4/i;->i:I

    const p3, 0x463b8000    # 12000.0f

    if-gtz p2, :cond_55

    .line 16
    invoke-static {}, Lanet/channel/util/Utils;->getNetworkTimeFactor()F

    move-result p2

    mul-float p2, p2, p3

    float-to-int p2, p2

    :cond_55
    iput p2, p0, La5/g;->g:I

    .line 17
    iget p2, p1, Lu4/i;->j:I

    if-gtz p2, :cond_62

    .line 18
    invoke-static {}, Lanet/channel/util/Utils;->getNetworkTimeFactor()F

    move-result p2

    mul-float p2, p2, p3

    float-to-int p2, p2

    :cond_62
    iput p2, p0, La5/g;->h:I

    .line 19
    iget p2, p1, Lu4/i;->b:I

    if-ltz p2, :cond_6b

    const/4 p3, 0x3

    if-le p2, p3, :cond_6c

    :cond_6b
    const/4 p2, 0x2

    :cond_6c
    iput p2, p0, La5/g;->d:I

    .line 20
    iget-object p2, p0, La5/g;->a:Lu4/i;

    iget-object p2, p2, Lu4/i;->c:Ljava/lang/String;

    invoke-static {p2}, Lanet/channel/util/HttpUrl;->parse(Ljava/lang/String;)Lanet/channel/util/HttpUrl;

    move-result-object p2

    if-eqz p2, :cond_ab

    .line 21
    sget-boolean p3, Lx4/b;->a:Z

    .line 22
    iget-object p3, p0, La5/g;->a:Lu4/i;

    const-string v0, "EnableSchemeReplace"

    invoke-virtual {p3, v0}, Lu4/i;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    const-string v0, "false"

    invoke-virtual {v0, p3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result p3

    if-eqz p3, :cond_8d

    .line 23
    invoke-virtual {p2}, Lanet/channel/util/HttpUrl;->lockScheme()V

    .line 24
    :cond_8d
    new-instance p3, Lanet/channel/statist/RequestStatistic;

    invoke-virtual {p2}, Lanet/channel/util/HttpUrl;->host()Ljava/lang/String;

    move-result-object v0

    iget-object p1, p1, Lu4/i;->k:Ljava/lang/String;

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p3, v0, p1}, Lanet/channel/statist/RequestStatistic;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    iput-object p3, p0, La5/g;->f:Lanet/channel/statist/RequestStatistic;

    .line 25
    invoke-virtual {p2}, Lanet/channel/util/HttpUrl;->simpleUrlString()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p3, Lanet/channel/statist/RequestStatistic;->url:Ljava/lang/String;

    .line 26
    invoke-virtual {p0, p2}, La5/g;->a(Lanet/channel/util/HttpUrl;)Lanet/channel/request/Request;

    move-result-object p1

    iput-object p1, p0, La5/g;->b:Lanet/channel/request/Request;

    return-void

    .line 27
    :cond_ab
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "url is invalid. url="

    invoke-static {p2}, Landroid/support/v4/media/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    iget-object p3, p0, La5/g;->a:Lu4/i;

    iget-object p3, p3, Lu4/i;->c:Ljava/lang/String;

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 28
    :cond_c2
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "request is null"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method


# virtual methods
.method public final a(Lanet/channel/util/HttpUrl;)Lanet/channel/request/Request;
    .registers 9

    .line 1
    new-instance v0, Lanet/channel/request/Request$Builder;

    invoke-direct {v0}, Lanet/channel/request/Request$Builder;-><init>()V

    .line 2
    invoke-virtual {v0, p1}, Lanet/channel/request/Request$Builder;->setUrl(Lanet/channel/util/HttpUrl;)Lanet/channel/request/Request$Builder;

    move-result-object v0

    iget-object v1, p0, La5/g;->a:Lu4/i;

    iget-object v1, v1, Lu4/i;->f:Ljava/lang/String;

    .line 3
    invoke-virtual {v0, v1}, Lanet/channel/request/Request$Builder;->setMethod(Ljava/lang/String;)Lanet/channel/request/Request$Builder;

    move-result-object v0

    iget-object v1, p0, La5/g;->a:Lu4/i;

    iget-object v1, v1, Lu4/i;->a:Lanet/channel/request/BodyEntry;

    .line 4
    invoke-virtual {v0, v1}, Lanet/channel/request/Request$Builder;->setBody(Lanet/channel/request/BodyEntry;)Lanet/channel/request/Request$Builder;

    move-result-object v0

    iget v1, p0, La5/g;->h:I

    .line 5
    invoke-virtual {v0, v1}, Lanet/channel/request/Request$Builder;->setReadTimeout(I)Lanet/channel/request/Request$Builder;

    move-result-object v0

    iget v1, p0, La5/g;->g:I

    .line 6
    invoke-virtual {v0, v1}, Lanet/channel/request/Request$Builder;->setConnectTimeout(I)Lanet/channel/request/Request$Builder;

    move-result-object v0

    iget-object v1, p0, La5/g;->a:Lu4/i;

    iget-boolean v1, v1, Lu4/i;->e:Z

    .line 7
    invoke-virtual {v0, v1}, Lanet/channel/request/Request$Builder;->setRedirectEnable(Z)Lanet/channel/request/Request$Builder;

    move-result-object v0

    iget v1, p0, La5/g;->c:I

    .line 8
    invoke-virtual {v0, v1}, Lanet/channel/request/Request$Builder;->setRedirectTimes(I)Lanet/channel/request/Request$Builder;

    move-result-object v0

    iget-object v1, p0, La5/g;->a:Lu4/i;

    iget-object v1, v1, Lu4/i;->k:Ljava/lang/String;

    .line 9
    invoke-virtual {v0, v1}, Lanet/channel/request/Request$Builder;->setBizId(Ljava/lang/String;)Lanet/channel/request/Request$Builder;

    move-result-object v0

    iget-object v1, p0, La5/g;->i:Ljava/lang/String;

    .line 10
    invoke-virtual {v0, v1}, Lanet/channel/request/Request$Builder;->setSeq(Ljava/lang/String;)Lanet/channel/request/Request$Builder;

    move-result-object v0

    iget-object v1, p0, La5/g;->f:Lanet/channel/statist/RequestStatistic;

    .line 11
    invoke-virtual {v0, v1}, Lanet/channel/request/Request$Builder;->setRequestStatistic(Lanet/channel/statist/RequestStatistic;)Lanet/channel/request/Request$Builder;

    move-result-object v0

    .line 12
    iget-object v1, p0, La5/g;->a:Lu4/i;

    iget-object v1, v1, Lu4/i;->h:Ljava/util/Map;

    invoke-virtual {v0, v1}, Lanet/channel/request/Request$Builder;->setParams(Ljava/util/Map;)Lanet/channel/request/Request$Builder;

    .line 13
    iget-object v1, p0, La5/g;->a:Lu4/i;

    iget-object v1, v1, Lu4/i;->d:Ljava/lang/String;

    if-eqz v1, :cond_57

    .line 14
    invoke-virtual {v0, v1}, Lanet/channel/request/Request$Builder;->setCharset(Ljava/lang/String;)Lanet/channel/request/Request$Builder;

    .line 15
    :cond_57
    invoke-virtual {p1}, Lanet/channel/util/HttpUrl;->host()Ljava/lang/String;

    move-result-object p1

    .line 16
    invoke-static {p1}, Lanet/channel/strategy/utils/c;->a(Ljava/lang/String;)Z

    move-result v1

    const/4 v2, 0x1

    xor-int/2addr v1, v2

    .line 17
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-le v3, v4, :cond_8e

    invoke-virtual {p1, v5}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/16 v4, 0x5b

    if-ne v3, v4, :cond_8e

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v3

    sub-int/2addr v3, v2

    invoke-virtual {p1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/16 v4, 0x5d

    if-ne v3, v4, :cond_8e

    .line 18
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v3

    sub-int/2addr v3, v2

    invoke-virtual {p1, v2, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    .line 19
    invoke-static {p1}, Lanet/channel/strategy/utils/c;->b(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_8e

    const/4 v1, 0x0

    .line 20
    :cond_8e
    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    .line 21
    iget-object v2, p0, La5/g;->a:Lu4/i;

    iget-object v2, v2, Lu4/i;->g:Ljava/util/Map;

    if-eqz v2, :cond_ef

    .line 22
    invoke-interface {v2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_a1
    :goto_a1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_ef

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/Map$Entry;

    .line 23
    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    const-string v5, "Host"

    .line 24
    invoke-virtual {v5, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_e5

    const-string v6, ":host"

    invoke-virtual {v6, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_c4

    goto :goto_e5

    .line 25
    :cond_c4
    iget-object v5, p0, La5/g;->a:Lu4/i;

    const-string v6, "KeepCustomCookie"

    .line 26
    invoke-virtual {v5, v6}, Lu4/i;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v6, "true"

    .line 27
    invoke-virtual {v6, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    const-string v6, "Cookie"

    .line 28
    invoke-virtual {v6, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_dd

    if-nez v5, :cond_dd

    goto :goto_a1

    .line 29
    :cond_dd
    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {p1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_a1

    :cond_e5
    :goto_e5
    if-nez v1, :cond_a1

    .line 30
    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {p1, v5, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_a1

    .line 31
    :cond_ef
    invoke-virtual {v0, p1}, Lanet/channel/request/Request$Builder;->setHeaders(Ljava/util/Map;)Lanet/channel/request/Request$Builder;

    .line 32
    invoke-virtual {v0}, Lanet/channel/request/Request$Builder;->build()Lanet/channel/request/Request;

    move-result-object p1

    return-object p1
.end method

.method public b()Lanet/channel/util/HttpUrl;
    .registers 2

    .line 1
    iget-object v0, p0, La5/g;->b:Lanet/channel/request/Request;

    invoke-virtual {v0}, Lanet/channel/request/Request;->getHttpUrl()Lanet/channel/util/HttpUrl;

    move-result-object v0

    return-object v0
.end method

.method public c()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, La5/g;->b:Lanet/channel/request/Request;

    invoke-virtual {v0}, Lanet/channel/request/Request;->getUrlString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public d()Ljava/util/Map;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La5/g;->b:Lanet/channel/request/Request;

    invoke-virtual {v0}, Lanet/channel/request/Request;->getHeaders()Ljava/util/Map;

    move-result-object v0

    return-object v0
.end method
