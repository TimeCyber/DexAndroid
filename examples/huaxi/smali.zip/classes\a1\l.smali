.class public final La1/l;
.super Lwg/j;
.source "Shadow.kt"

# interfaces
.implements Lvg/l;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lwg/j;",
        "Lvg/l<",
        "Ld1/w;",
        "Lkg/l;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic a:F

.field public final synthetic b:Ld1/k0;

.field public final synthetic c:Z

.field public final synthetic d:J

.field public final synthetic e:J


# direct methods
.method public constructor <init>(FLd1/k0;ZJJ)V
    .registers 8

    iput p1, p0, La1/l;->a:F

    iput-object p2, p0, La1/l;->b:Ld1/k0;

    iput-boolean p3, p0, La1/l;->c:Z

    iput-wide p4, p0, La1/l;->d:J

    iput-wide p6, p0, La1/l;->e:J

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lwg/j;-><init>(I)V

    return-void
.end method


# virtual methods
.method public invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 1
    check-cast p1, Ld1/w;

    const-string v0, "$this$graphicsLayer"

    .line 2
    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    iget v0, p0, La1/l;->a:F

    invoke-interface {p1, v0}, Lp2/b;->Z(F)F

    move-result v0

    invoke-interface {p1, v0}, Ld1/w;->p(F)V

    .line 4
    iget-object v0, p0, La1/l;->b:Ld1/k0;

    invoke-interface {p1, v0}, Ld1/w;->q(Ld1/k0;)V

    .line 5
    iget-boolean v0, p0, La1/l;->c:Z

    invoke-interface {p1, v0}, Ld1/w;->g0(Z)V

    .line 6
    iget-wide v0, p0, La1/l;->d:J

    invoke-interface {p1, v0, v1}, Ld1/w;->a0(J)V

    .line 7
    iget-wide v0, p0, La1/l;->e:J

    invoke-interface {p1, v0, v1}, Ld1/w;->l0(J)V

    .line 8
    sget-object p1, Lkg/l;->a:Lkg/l;

    return-object p1
.end method
