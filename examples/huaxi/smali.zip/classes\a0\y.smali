.class public interface abstract La0/y;
.super Ljava/lang/Object;
.source "AnimationSpec.kt"

# interfaces
.implements La0/g;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "La0/g<",
        "TT;>;"
    }
.end annotation
