.class public final La0/a1;
.super Ljava/lang/Object;
.source "VectorizedAnimationSpec.kt"

# interfaces
.implements La0/o;


# instance fields
.field public final a:La0/b0;


# direct methods
.method public constructor <init>(FF)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, La0/b0;

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {v0, p1, p2, v1, v2}, La0/b0;-><init>(FFFI)V

    iput-object v0, p0, La0/a1;->a:La0/b0;

    return-void
.end method


# virtual methods
.method public get(I)La0/z;
    .registers 2

    .line 1
    iget-object p1, p0, La0/a1;->a:La0/b0;

    return-object p1
.end method
