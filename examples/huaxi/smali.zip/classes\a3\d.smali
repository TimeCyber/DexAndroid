.class public La3/d;
.super Ljava/lang/Object;
.source "ActivityRecreator.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroid/app/Application;

.field public final synthetic b:La3/f$a;


# direct methods
.method public constructor <init>(Landroid/app/Application;La3/f$a;)V
    .registers 3

    .line 1
    iput-object p1, p0, La3/d;->a:Landroid/app/Application;

    iput-object p2, p0, La3/d;->b:La3/f$a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 3

    .line 1
    iget-object v0, p0, La3/d;->a:Landroid/app/Application;

    iget-object v1, p0, La3/d;->b:La3/f$a;

    invoke-virtual {v0, v1}, Landroid/app/Application;->unregisterActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    return-void
.end method
