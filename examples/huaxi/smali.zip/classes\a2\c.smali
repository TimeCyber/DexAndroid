.class public final La2/c;
.super Ljava/lang/Object;
.source "LayoutIntrinsics.kt"


# instance fields
.field public final a:Lkg/c;

.field public final b:Lkg/c;

.field public final c:Lkg/c;


# direct methods
.method public constructor <init>(Ljava/lang/CharSequence;Landroid/text/TextPaint;I)V
    .registers 5

    const-string v0, "charSequence"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "textPaint"

    invoke-static {p2, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, La2/c$a;

    invoke-direct {v0, p3, p1, p2}, La2/c$a;-><init>(ILjava/lang/CharSequence;Landroid/text/TextPaint;)V

    const/4 p3, 0x3

    invoke-static {p3, v0}, Ld3/g;->Q(ILvg/a;)Lkg/c;

    move-result-object v0

    iput-object v0, p0, La2/c;->a:Lkg/c;

    .line 3
    new-instance v0, La2/c$c;

    invoke-direct {v0, p1, p2}, La2/c$c;-><init>(Ljava/lang/CharSequence;Landroid/text/TextPaint;)V

    invoke-static {p3, v0}, Ld3/g;->Q(ILvg/a;)Lkg/c;

    move-result-object v0

    iput-object v0, p0, La2/c;->b:Lkg/c;

    .line 4
    new-instance v0, La2/c$b;

    invoke-direct {v0, p0, p1, p2}, La2/c$b;-><init>(La2/c;Ljava/lang/CharSequence;Landroid/text/TextPaint;)V

    invoke-static {p3, v0}, Ld3/g;->Q(ILvg/a;)Lkg/c;

    move-result-object p1

    iput-object p1, p0, La2/c;->c:Lkg/c;

    return-void
.end method
