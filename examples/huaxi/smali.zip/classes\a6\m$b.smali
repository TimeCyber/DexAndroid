.class public La6/m$b;
.super Ljava/lang/Object;
.source "LottieDrawable.java"

# interfaces
.implements La6/m$o;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La6/m;->q(II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:I

.field public final synthetic b:I

.field public final synthetic c:La6/m;


# direct methods
.method public constructor <init>(La6/m;II)V
    .registers 4

    .line 1
    iput-object p1, p0, La6/m$b;->c:La6/m;

    iput p2, p0, La6/m$b;->a:I

    iput p3, p0, La6/m$b;->b:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(La6/g;)V
    .registers 4

    .line 1
    iget-object p1, p0, La6/m$b;->c:La6/m;

    iget v0, p0, La6/m$b;->a:I

    iget v1, p0, La6/m$b;->b:I

    invoke-virtual {p1, v0, v1}, La6/m;->q(II)V

    return-void
.end method
