.class public final La7/d;
.super Ljava/lang/Object;
.source "CacheDiskStaticUtils.java"


# direct methods
.method public static a()La7/e;
    .registers 10

    .line 1
    sget-object v0, La7/e;->f:Ljava/util/Map;

    const-string v0, ""

    .line 2
    invoke-static {v0}, Lcom/blankj/utilcode/util/p;->h(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_c

    const-string v0, "cacheUtils"

    .line 3
    :cond_c
    new-instance v3, Ljava/io/File;

    invoke-static {}, Lcom/blankj/utilcode/util/l;->a()Landroid/app/Application;

    move-result-object v1

    invoke-virtual {v1}, Landroid/app/Application;->getCacheDir()Ljava/io/File;

    move-result-object v1

    invoke-direct {v3, v1, v0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 4
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3}, Ljava/io/File;->getAbsoluteFile()Ljava/io/File;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "_"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-wide v1, 0x7fffffffffffffffL

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, "_"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v1, 0x7fffffff

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 5
    sget-object v7, La7/e;->f:Ljava/util/Map;

    move-object v1, v7

    check-cast v1, Ljava/util/HashMap;

    invoke-virtual {v1, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La7/e;

    if-nez v1, :cond_76

    .line 6
    const-class v8, La7/e;

    monitor-enter v8

    .line 7
    :try_start_51
    move-object v1, v7

    check-cast v1, Ljava/util/HashMap;

    invoke-virtual {v1, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La7/e;

    if-nez v1, :cond_71

    .line 8
    new-instance v9, La7/e;

    const-wide v4, 0x7fffffffffffffffL

    const v6, 0x7fffffff

    move-object v1, v9

    move-object v2, v0

    invoke-direct/range {v1 .. v6}, La7/e;-><init>(Ljava/lang/String;Ljava/io/File;JI)V

    .line 9
    check-cast v7, Ljava/util/HashMap;

    invoke-virtual {v7, v0, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object v1, v9

    .line 10
    :cond_71
    monitor-exit v8

    goto :goto_76

    :catchall_73
    move-exception v0

    monitor-exit v8
    :try_end_75
    .catchall {:try_start_51 .. :try_end_75} :catchall_73

    throw v0

    :cond_76
    :goto_76
    return-object v1
.end method

.method public static b(Ljava/lang/String;)Ljava/lang/Object;
    .registers 4

    .line 1
    invoke-static {}, La7/d;->a()La7/e;

    move-result-object v0

    .line 2
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "se_"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, La7/e;->b(Ljava/lang/String;)[B

    move-result-object p0

    const/4 v0, 0x0

    if-nez p0, :cond_1d

    goto :goto_3f

    .line 3
    :cond_1d
    :try_start_1d
    new-instance v1, Ljava/io/ObjectInputStream;

    new-instance v2, Ljava/io/ByteArrayInputStream;

    invoke-direct {v2, p0}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    invoke-direct {v1, v2}, Ljava/io/ObjectInputStream;-><init>(Ljava/io/InputStream;)V
    :try_end_27
    .catch Ljava/lang/Exception; {:try_start_1d .. :try_end_27} :catch_30
    .catchall {:try_start_1d .. :try_end_27} :catchall_2e

    .line 4
    :try_start_27
    invoke-virtual {v1}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;

    move-result-object v0
    :try_end_2b
    .catch Ljava/lang/Exception; {:try_start_27 .. :try_end_2b} :catch_2c
    .catchall {:try_start_27 .. :try_end_2b} :catchall_40

    goto :goto_37

    :catch_2c
    move-exception p0

    goto :goto_32

    :catchall_2e
    move-exception p0

    goto :goto_42

    :catch_30
    move-exception p0

    move-object v1, v0

    .line 5
    :goto_32
    :try_start_32
    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V
    :try_end_35
    .catchall {:try_start_32 .. :try_end_35} :catchall_40

    if-eqz v1, :cond_3f

    .line 6
    :goto_37
    :try_start_37
    invoke-virtual {v1}, Ljava/io/ObjectInputStream;->close()V
    :try_end_3a
    .catch Ljava/io/IOException; {:try_start_37 .. :try_end_3a} :catch_3b

    goto :goto_3f

    :catch_3b
    move-exception p0

    .line 7
    invoke-virtual {p0}, Ljava/io/IOException;->printStackTrace()V

    :cond_3f
    :goto_3f
    return-object v0

    :catchall_40
    move-exception p0

    move-object v0, v1

    :goto_42
    if-eqz v0, :cond_4c

    .line 8
    :try_start_44
    invoke-virtual {v0}, Ljava/io/ObjectInputStream;->close()V
    :try_end_47
    .catch Ljava/io/IOException; {:try_start_44 .. :try_end_47} :catch_48

    goto :goto_4c

    :catch_48
    move-exception v0

    .line 9
    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    .line 10
    :cond_4c
    :goto_4c
    throw p0
.end method

.method public static c(Ljava/lang/String;Ljava/io/Serializable;)V
    .registers 6

    .line 1
    invoke-static {}, La7/d;->a()La7/e;

    move-result-object v0

    const-string v1, "se_"

    .line 2
    invoke-static {v1, p0}, Lhd/a;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x0

    .line 3
    :try_start_b
    new-instance v2, Ljava/io/ObjectOutputStream;

    new-instance v3, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v3}, Ljava/io/ByteArrayOutputStream;-><init>()V

    invoke-direct {v2, v3}, Ljava/io/ObjectOutputStream;-><init>(Ljava/io/OutputStream;)V
    :try_end_15
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_15} :catch_21
    .catchall {:try_start_b .. :try_end_15} :catchall_1f

    .line 4
    :try_start_15
    invoke-virtual {v2, p1}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V

    .line 5
    invoke-virtual {v3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1
    :try_end_1c
    .catch Ljava/lang/Exception; {:try_start_15 .. :try_end_1c} :catch_1d
    .catchall {:try_start_15 .. :try_end_1c} :catchall_35

    goto :goto_28

    :catch_1d
    move-exception p1

    goto :goto_23

    :catchall_1f
    move-exception p0

    goto :goto_37

    :catch_21
    move-exception p1

    move-object v2, v1

    .line 6
    :goto_23
    :try_start_23
    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V
    :try_end_26
    .catchall {:try_start_23 .. :try_end_26} :catchall_35

    if-eqz v2, :cond_30

    .line 7
    :goto_28
    :try_start_28
    invoke-virtual {v2}, Ljava/io/ObjectOutputStream;->close()V
    :try_end_2b
    .catch Ljava/io/IOException; {:try_start_28 .. :try_end_2b} :catch_2c

    goto :goto_30

    :catch_2c
    move-exception p1

    .line 8
    invoke-virtual {p1}, Ljava/io/IOException;->printStackTrace()V

    :cond_30
    :goto_30
    const/4 p1, -0x1

    .line 9
    invoke-virtual {v0, p0, v1, p1}, La7/e;->c(Ljava/lang/String;[BI)V

    return-void

    :catchall_35
    move-exception p0

    move-object v1, v2

    :goto_37
    if-eqz v1, :cond_41

    .line 10
    :try_start_39
    invoke-virtual {v1}, Ljava/io/ObjectOutputStream;->close()V
    :try_end_3c
    .catch Ljava/io/IOException; {:try_start_39 .. :try_end_3c} :catch_3d

    goto :goto_41

    :catch_3d
    move-exception p1

    .line 11
    invoke-virtual {p1}, Ljava/io/IOException;->printStackTrace()V

    .line 12
    :cond_41
    :goto_41
    throw p0
.end method
