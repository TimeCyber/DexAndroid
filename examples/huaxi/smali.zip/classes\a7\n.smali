.class public final La7/n;
.super Landroid/os/ResultReceiver;
.source "KeyboardUtils.java"


# direct methods
.method public constructor <init>(Landroid/os/Handler;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Landroid/os/ResultReceiver;-><init>(Landroid/os/Handler;)V

    return-void
.end method


# virtual methods
.method public onReceiveResult(ILandroid/os/Bundle;)V
    .registers 3

    const/4 p2, 0x1

    if-eq p1, p2, :cond_6

    const/4 p2, 0x3

    if-ne p1, p2, :cond_19

    .line 1
    :cond_6
    invoke-static {}, Lcom/blankj/utilcode/util/l;->a()Landroid/app/Application;

    move-result-object p1

    const-string p2, "input_method"

    invoke-virtual {p1, p2}, Landroid/app/Application;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/view/inputmethod/InputMethodManager;

    if-nez p1, :cond_15

    goto :goto_19

    :cond_15
    const/4 p2, 0x0

    .line 2
    invoke-virtual {p1, p2, p2}, Landroid/view/inputmethod/InputMethodManager;->toggleSoftInput(II)V

    :cond_19
    :goto_19
    return-void
.end method
