.class public final La0/w0$d;
.super Lwg/j;
.source "VectorConverters.kt"

# interfaces
.implements Lvg/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La0/w0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lwg/j;",
        "Lvg/l<",
        "La0/k;",
        "Lp2/d;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:La0/w0$d;


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    new-instance v0, La0/w0$d;

    invoke-direct {v0}, La0/w0$d;-><init>()V

    sput-object v0, La0/w0$d;->a:La0/w0$d;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lwg/j;-><init>(I)V

    return-void
.end method


# virtual methods
.method public invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    check-cast p1, La0/k;

    const-string v0, "it"

    .line 2
    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    iget p1, p1, La0/k;->a:F

    .line 4
    new-instance v0, Lp2/d;

    invoke-direct {v0, p1}, Lp2/d;-><init>(F)V

    return-object v0
.end method
