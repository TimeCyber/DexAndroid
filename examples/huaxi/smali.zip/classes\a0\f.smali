.class public final La0/f;
.super Ljava/lang/Object;
.source "AnimationState.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "V:",
        "La0/n;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field public final a:La0/u0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/u0<",
            "TT;TV;>;"
        }
    .end annotation
.end field

.field public final b:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field

.field public final c:J

.field public final d:Lvg/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lvg/a<",
            "Lkg/l;",
            ">;"
        }
    .end annotation
.end field

.field public final e:Lm0/x0;

.field public f:La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field

.field public g:J

.field public h:J

.field public final i:Lm0/x0;


# direct methods
.method public constructor <init>(Ljava/lang/Object;La0/u0;La0/n;JLjava/lang/Object;JZLvg/a;)V
    .registers 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "La0/u0<",
            "TT;TV;>;TV;JTT;JZ",
            "Lvg/a<",
            "Lkg/l;",
            ">;)V"
        }
    .end annotation

    const-string v0, "typeConverter"

    invoke-static {p2, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "initialVelocityVector"

    invoke-static {p3, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p2, p0, La0/f;->a:La0/u0;

    .line 3
    iput-object p6, p0, La0/f;->b:Ljava/lang/Object;

    .line 4
    iput-wide p7, p0, La0/f;->c:J

    .line 5
    iput-object p10, p0, La0/f;->d:Lvg/a;

    const/4 p2, 0x0

    const/4 p6, 0x2

    .line 6
    invoke-static {p1, p2, p6, p2}, Landroidx/appcompat/widget/m;->L(Ljava/lang/Object;Lm0/c2;ILjava/lang/Object;)Lm0/x0;

    move-result-object p1

    iput-object p1, p0, La0/f;->e:Lm0/x0;

    .line 7
    invoke-static {p3}, Landroidx/appcompat/widget/m;->s(La0/n;)La0/n;

    move-result-object p1

    iput-object p1, p0, La0/f;->f:La0/n;

    .line 8
    iput-wide p4, p0, La0/f;->g:J

    const-wide/high16 p3, -0x8000000000000000L

    .line 9
    iput-wide p3, p0, La0/f;->h:J

    .line 10
    invoke-static {p9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    invoke-static {p1, p2, p6, p2}, Landroidx/appcompat/widget/m;->L(Ljava/lang/Object;Lm0/c2;ILjava/lang/Object;)Lm0/x0;

    move-result-object p1

    iput-object p1, p0, La0/f;->i:Lm0/x0;

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La0/f;->e:Lm0/x0;

    .line 2
    invoke-interface {v0}, Lm0/g2;->getValue()Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final b(Z)V
    .registers 3

    .line 1
    iget-object v0, p0, La0/f;->i:Lm0/x0;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 2
    invoke-interface {v0, p1}, Lm0/x0;->setValue(Ljava/lang/Object;)V

    return-void
.end method
