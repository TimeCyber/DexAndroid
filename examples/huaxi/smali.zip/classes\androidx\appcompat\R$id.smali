.class public final Landroidx/appcompat/R$id;
.super Ljava/lang/Object;


# static fields
.field public static final action_bar:I = 0x7f08003c

.field public static final action_bar_activity_content:I = 0x7f08003d

.field public static final action_bar_container:I = 0x7f08003e

.field public static final action_bar_root:I = 0x7f08003f

.field public static final action_bar_spinner:I = 0x7f080040

.field public static final action_bar_subtitle:I = 0x7f080041

.field public static final action_bar_title:I = 0x7f080042

.field public static final action_context_bar:I = 0x7f080044

.field public static final action_menu_divider:I = 0x7f080047

.field public static final action_menu_presenter:I = 0x7f080048

.field public static final action_mode_bar:I = 0x7f080049

.field public static final action_mode_bar_stub:I = 0x7f08004a

.field public static final action_mode_close_button:I = 0x7f08004b

.field public static final activity_chooser_view_content:I = 0x7f08004e

.field public static final add:I = 0x7f08004f

.field public static final alertTitle:I = 0x7f080058

.field public static final buttonPanel:I = 0x7f080094

.field public static final checkbox:I = 0x7f0800b7

.field public static final checked:I = 0x7f0800b8

.field public static final content:I = 0x7f0800e1

.field public static final contentPanel:I = 0x7f0800e2

.field public static final custom:I = 0x7f0800f7

.field public static final customPanel:I = 0x7f0800f8

.field public static final decor_content_parent:I = 0x7f080104

.field public static final default_activity_button:I = 0x7f080105

.field public static final edit_query:I = 0x7f080137

.field public static final expand_activities_button:I = 0x7f080155

.field public static final expanded_menu:I = 0x7f080156

.field public static final group_divider:I = 0x7f0801b0

.field public static final home:I = 0x7f0801cb

.field public static final icon:I = 0x7f0801d1

.field public static final image:I = 0x7f0801d7

.field public static final listMode:I = 0x7f080256

.field public static final list_item:I = 0x7f080257

.field public static final message:I = 0x7f0802bc

.field public static final multiply:I = 0x7f0802e3

.field public static final none:I = 0x7f0802f6

.field public static final normal:I = 0x7f0802f7

.field public static final off:I = 0x7f080302

.field public static final on:I = 0x7f080304

.field public static final parentPanel:I = 0x7f080318

.field public static final progress_circular:I = 0x7f080343

.field public static final progress_horizontal:I = 0x7f080344

.field public static final radio:I = 0x7f08034c

.field public static final screen:I = 0x7f08039f

.field public static final scrollIndicatorDown:I = 0x7f0803a1

.field public static final scrollIndicatorUp:I = 0x7f0803a2

.field public static final scrollView:I = 0x7f0803a3

.field public static final search_badge:I = 0x7f0803a8

.field public static final search_bar:I = 0x7f0803a9

.field public static final search_button:I = 0x7f0803aa

.field public static final search_close_btn:I = 0x7f0803ab

.field public static final search_edit_frame:I = 0x7f0803ac

.field public static final search_go_btn:I = 0x7f0803ad

.field public static final search_mag_icon:I = 0x7f0803ae

.field public static final search_plate:I = 0x7f0803af

.field public static final search_src_text:I = 0x7f0803b0

.field public static final search_voice_btn:I = 0x7f0803b1

.field public static final select_dialog_listview:I = 0x7f0803b4

.field public static final shortcut:I = 0x7f0803be

.field public static final spacer:I = 0x7f0803d1

.field public static final split_action_bar:I = 0x7f0803d4

.field public static final src_atop:I = 0x7f0803d8

.field public static final src_in:I = 0x7f0803d9

.field public static final src_over:I = 0x7f0803da

.field public static final submenuarrow:I = 0x7f080402

.field public static final submit_area:I = 0x7f080404

.field public static final tabMode:I = 0x7f08041b

.field public static final textSpacerNoButtons:I = 0x7f080436

.field public static final textSpacerNoTitle:I = 0x7f080437

.field public static final title:I = 0x7f080450

.field public static final titleDividerNoCustom:I = 0x7f080452

.field public static final title_template:I = 0x7f080454

.field public static final topPanel:I = 0x7f080459

.field public static final unchecked:I = 0x7f0804fb

.field public static final uniform:I = 0x7f0804fc

.field public static final up:I = 0x7f0804fe

.field public static final wrap_content:I = 0x7f08054e


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
