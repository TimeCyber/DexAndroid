.class public final La0/f0$a;
.super Ljava/lang/Object;
.source "AnimationSpec.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La0/f0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field public final a:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field

.field public b:La0/w;


# direct methods
.method public constructor <init>(Ljava/lang/Object;La0/w;I)V
    .registers 4

    and-int/lit8 p2, p3, 0x2

    if-eqz p2, :cond_7

    .line 1
    sget-object p2, La0/x$a;->a:La0/x$a;

    goto :goto_8

    :cond_7
    const/4 p2, 0x0

    :goto_8
    const-string p3, "easing"

    .line 2
    invoke-static {p2, p3}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La0/f0$a;->a:Ljava/lang/Object;

    .line 5
    iput-object p2, p0, La0/f0$a;->b:La0/w;

    return-void
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .registers 4

    .line 1
    instance-of v0, p1, La0/f0$a;

    if-eqz v0, :cond_1c

    check-cast p1, La0/f0$a;

    iget-object v0, p1, La0/f0$a;->a:Ljava/lang/Object;

    iget-object v1, p0, La0/f0$a;->a:Ljava/lang/Object;

    invoke-static {v0, v1}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1c

    iget-object p1, p1, La0/f0$a;->b:La0/w;

    iget-object v0, p0, La0/f0$a;->b:La0/w;

    invoke-static {p1, v0}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1c

    const/4 p1, 0x1

    goto :goto_1d

    :cond_1c
    const/4 p1, 0x0

    :goto_1d
    return p1
.end method

.method public hashCode()I
    .registers 3

    .line 1
    iget-object v0, p0, La0/f0$a;->a:Ljava/lang/Object;

    if-eqz v0, :cond_9

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    goto :goto_a

    :cond_9
    const/4 v0, 0x0

    :goto_a
    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, La0/f0$a;->b:La0/w;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    return v1
.end method
