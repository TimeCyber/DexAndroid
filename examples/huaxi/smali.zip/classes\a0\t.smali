.class public final La0/t;
.super Ljava/lang/Object;
.source "DecayAnimationSpec.kt"

# interfaces
.implements La0/s;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "La0/s<",
        "TT;>;"
    }
.end annotation


# instance fields
.field public final a:La0/a0;


# direct methods
.method public constructor <init>(La0/a0;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, La0/t;->a:La0/a0;

    return-void
.end method


# virtual methods
.method public a(La0/u0;)La0/b1;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<V:",
            "La0/n;",
            ">(",
            "La0/u0<",
            "TT;TV;>;)",
            "La0/b1<",
            "TV;>;"
        }
    .end annotation

    .line 1
    new-instance p1, La0/f1;

    iget-object v0, p0, La0/t;->a:La0/a0;

    invoke-direct {p1, v0}, La0/f1;-><init>(La0/a0;)V

    return-object p1
.end method
