.class public final synthetic Landroid/support/v4/media/a;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"


# direct methods
.method public static a(Ln/l0;Ln/p$a;)Ln/p$b;
    .registers 2

    .line 1
    invoke-interface {p0}, Ln/l0;->b()Ln/p;

    move-result-object p0

    invoke-interface {p0, p1}, Ln/p;->e(Ln/p$a;)Ln/p$b;

    move-result-object p0

    return-object p0
.end method

.method public static b(Ln/l0;)Ljava/util/Set;
    .registers 1

    .line 1
    invoke-interface {p0}, Ln/l0;->b()Ln/p;

    move-result-object p0

    invoke-interface {p0}, Ln/p;->f()Ljava/util/Set;

    move-result-object p0

    return-object p0
.end method

.method public static c(Ln/l0;Ln/p$a;)Ljava/lang/Object;
    .registers 2

    .line 1
    invoke-interface {p0}, Ln/l0;->b()Ln/p;

    move-result-object p0

    invoke-interface {p0, p1}, Ln/p;->h(Ln/p$a;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static d(Ln/l0;Ln/p$a;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    invoke-interface {p0}, Ln/l0;->b()Ln/p;

    move-result-object p0

    invoke-interface {p0, p1, p2}, Ln/p;->a(Ln/p$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static e(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .registers 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    return-object v0
.end method

.method public static f(Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method
