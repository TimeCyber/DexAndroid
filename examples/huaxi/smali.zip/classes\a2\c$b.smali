.class public final La2/c$b;
.super Lwg/j;
.source "LayoutIntrinsics.kt"

# interfaces
.implements Lvg/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La2/c;-><init>(Ljava/lang/CharSequence;Landroid/text/TextPaint;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lwg/j;",
        "Lvg/a<",
        "Ljava/lang/Float;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic a:La2/c;

.field public final synthetic b:Ljava/lang/CharSequence;

.field public final synthetic c:Landroid/text/TextPaint;


# direct methods
.method public constructor <init>(La2/c;Ljava/lang/CharSequence;Landroid/text/TextPaint;)V
    .registers 4

    iput-object p1, p0, La2/c$b;->a:La2/c;

    iput-object p2, p0, La2/c$b;->b:Ljava/lang/CharSequence;

    iput-object p3, p0, La2/c$b;->c:Landroid/text/TextPaint;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lwg/j;-><init>(I)V

    return-void
.end method


# virtual methods
.method public invoke()Ljava/lang/Object;
    .registers 8

    .line 1
    iget-object v0, p0, La2/c$b;->a:La2/c;

    .line 2
    iget-object v0, v0, La2/c;->a:Lkg/c;

    invoke-interface {v0}, Lkg/c;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/text/BoringLayout$Metrics;

    const/4 v1, 0x0

    if-eqz v0, :cond_11

    .line 3
    iget v0, v0, Landroid/text/BoringLayout$Metrics;->width:I

    int-to-float v0, v0

    goto :goto_1d

    .line 4
    :cond_11
    iget-object v0, p0, La2/c$b;->b:Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v2

    iget-object v3, p0, La2/c$b;->c:Landroid/text/TextPaint;

    invoke-static {v0, v1, v2, v3}, Landroid/text/Layout;->getDesiredWidth(Ljava/lang/CharSequence;IILandroid/text/TextPaint;)F

    move-result v0

    .line 5
    :goto_1d
    iget-object v2, p0, La2/c$b;->b:Ljava/lang/CharSequence;

    iget-object v3, p0, La2/c$b;->c:Landroid/text/TextPaint;

    const/4 v4, 0x0

    const/4 v5, 0x1

    cmpg-float v6, v0, v4

    if-nez v6, :cond_29

    const/4 v6, 0x1

    goto :goto_2a

    :cond_29
    const/4 v6, 0x0

    :goto_2a
    if-nez v6, :cond_50

    .line 6
    instance-of v6, v2, Landroid/text/Spanned;

    if-eqz v6, :cond_50

    .line 7
    invoke-virtual {v3}, Landroid/text/TextPaint;->getLetterSpacing()F

    move-result v3

    cmpg-float v3, v3, v4

    if-nez v3, :cond_3a

    const/4 v3, 0x1

    goto :goto_3b

    :cond_3a
    const/4 v3, 0x0

    :goto_3b
    if-eqz v3, :cond_4f

    .line 8
    check-cast v2, Landroid/text/Spanned;

    const-class v3, Lc2/d;

    invoke-static {v2, v3}, Landroidx/activity/n;->C(Landroid/text/Spanned;Ljava/lang/Class;)Z

    move-result v3

    if-nez v3, :cond_4f

    .line 9
    const-class v3, Lc2/c;

    invoke-static {v2, v3}, Landroidx/activity/n;->C(Landroid/text/Spanned;Ljava/lang/Class;)Z

    move-result v2

    if-eqz v2, :cond_50

    :cond_4f
    const/4 v1, 0x1

    :cond_50
    if-eqz v1, :cond_55

    const/high16 v1, 0x3f000000    # 0.5f

    add-float/2addr v0, v1

    .line 10
    :cond_55
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    return-object v0
.end method
