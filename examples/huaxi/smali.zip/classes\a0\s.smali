.class public interface abstract La0/s;
.super Ljava/lang/Object;
.source "DecayAnimationSpec.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a(La0/u0;)La0/b1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<V:",
            "La0/n;",
            ">(",
            "La0/u0<",
            "TT;TV;>;)",
            "La0/b1<",
            "TV;>;"
        }
    .end annotation
.end method
