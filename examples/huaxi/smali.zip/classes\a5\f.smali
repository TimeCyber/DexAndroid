.class public La5/f;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lu4/b;

.field public final synthetic b:Lu4/h;

.field public final synthetic c:La5/c;


# direct methods
.method public constructor <init>(La5/c;Lu4/b;Lu4/h;)V
    .registers 4

    .line 1
    iput-object p1, p0, La5/f;->c:La5/c;

    iput-object p2, p0, La5/f;->a:Lu4/b;

    iput-object p3, p0, La5/f;->b:Lu4/h;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 11

    const-string v0, "anet.Repeater"

    .line 1
    iget-object v1, p0, La5/f;->a:Lu4/b;

    const/4 v2, 0x0

    if-eqz v1, :cond_9

    .line 2
    iput-object v2, v1, Lu4/b;->a:Ljava/lang/Object;

    .line 3
    :cond_9
    :try_start_9
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    .line 4
    iget-object v1, p0, La5/f;->a:Lu4/b;

    iget-object v1, v1, Lu4/b;->e:Lanet/channel/statist/RequestStatistic;

    if-eqz v1, :cond_2b

    .line 5
    iput-wide v3, v1, Lanet/channel/statist/RequestStatistic;->rspCbStart:J

    .line 6
    iget-wide v5, v1, Lanet/channel/statist/RequestStatistic;->rspEnd:J

    sub-long v5, v3, v5

    iput-wide v5, v1, Lanet/channel/statist/RequestStatistic;->lastProcessTime:J

    .line 7
    iget-wide v5, v1, Lanet/channel/statist/RequestStatistic;->retryCostTime:J

    iget-wide v7, v1, Lanet/channel/statist/RequestStatistic;->start:J

    sub-long v7, v3, v7

    add-long/2addr v7, v5

    iput-wide v7, v1, Lanet/channel/statist/RequestStatistic;->oneWayTime:J

    .line 8
    iget-object v5, p0, La5/f;->a:Lu4/b;

    .line 9
    iget-object v5, v5, Lu4/b;->d:Lf5/a;

    .line 10
    invoke-virtual {v5, v1}, Lf5/a;->a(Lanet/channel/statist/RequestStatistic;)V

    .line 11
    :cond_2b
    iget-object v5, p0, La5/f;->b:Lu4/h;

    iget-object v6, p0, La5/f;->a:Lu4/b;

    invoke-interface {v5, v6}, Lu4/h;->g(Lu4/b;)V

    if-eqz v1, :cond_46

    .line 12
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    .line 13
    iput-wide v5, v1, Lanet/channel/statist/RequestStatistic;->rspCbEnd:J

    sub-long/2addr v5, v3

    .line 14
    iput-wide v5, v1, Lanet/channel/statist/RequestStatistic;->callbackTime:J

    .line 15
    invoke-static {}, Lanet/channel/fulltrace/a;->a()Lanet/channel/fulltrace/IFullTraceAnalysis;

    move-result-object v3

    iget-object v4, v1, Lanet/channel/statist/RequestStatistic;->traceId:Ljava/lang/String;

    invoke-interface {v3, v4, v1}, Lanet/channel/fulltrace/IFullTraceAnalysis;->commitRequest(Ljava/lang/String;Lanet/channel/statist/RequestStatistic;)V

    .line 16
    :cond_46
    iget-object v3, p0, La5/f;->c:La5/c;

    .line 17
    iget-object v3, v3, La5/c;->c:Lv4/c;

    if-eqz v3, :cond_51

    .line 18
    sget-object v4, Lv4/c;->i:Lanet/channel/bytes/ByteArray;

    invoke-virtual {v3, v4}, Lv4/c;->o(Lanet/channel/bytes/ByteArray;)V

    :cond_51
    if-eqz v1, :cond_180

    .line 19
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "[traceId:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, v1, Lanet/channel/statist/RequestStatistic;->traceId:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "]"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "end, "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 20
    invoke-virtual {v1}, Lanet/channel/statist/RequestStatistic;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 21
    iget-object v4, p0, La5/f;->c:La5/c;

    .line 22
    iget-object v4, v4, La5/c;->b:Ljava/lang/String;

    const/4 v5, 0x0

    new-array v6, v5, [Ljava/lang/Object;

    .line 23
    invoke-static {v0, v3, v4, v6}, Lanet/channel/util/ALog;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 24
    invoke-static {}, Lanet/channel/GlobalAppRuntimeInfo;->getBucketInfo()Ljava/util/concurrent/CopyOnWriteArrayList;

    move-result-object v3

    if-eqz v3, :cond_a2

    .line 25
    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v4

    const/4 v6, 0x0

    :goto_8c
    add-int/lit8 v7, v4, -0x1

    if-ge v6, v7, :cond_a2

    .line 26
    invoke-interface {v3, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    add-int/lit8 v8, v6, 0x1

    invoke-interface {v3, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v1, v7, v8}, Lanet/channel/statist/RequestStatistic;->putExtra(Ljava/lang/String;Ljava/lang/Object;)V

    add-int/lit8 v6, v6, 0x2

    goto :goto_8c

    .line 27
    :cond_a2
    invoke-static {}, Lanet/channel/GlobalAppRuntimeInfo;->isAppBackground()Z

    move-result v3

    if-eqz v3, :cond_b5

    const-string v3, "restrictBg"

    .line 28
    invoke-static {}, Lanet/channel/status/NetworkStatusHelper;->getRestrictBackgroundStatus()I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v1, v3, v4}, Lanet/channel/statist/RequestStatistic;->putExtra(Ljava/lang/String;Ljava/lang/Object;)V

    .line 29
    :cond_b5
    invoke-static {}, Lanet/channel/fulltrace/a;->a()Lanet/channel/fulltrace/IFullTraceAnalysis;

    move-result-object v3

    invoke-interface {v3}, Lanet/channel/fulltrace/IFullTraceAnalysis;->getSceneInfo()Lanet/channel/fulltrace/b;

    move-result-object v3

    const/4 v4, 0x1

    if-eqz v3, :cond_f4

    .line 30
    invoke-virtual {v3}, Lanet/channel/fulltrace/b;->toString()Ljava/lang/String;

    move-result-object v6

    iget-object v7, p0, La5/f;->c:La5/c;

    .line 31
    iget-object v7, v7, La5/c;->b:Ljava/lang/String;

    new-array v8, v5, [Ljava/lang/Object;

    .line 32
    invoke-static {v0, v6, v7, v8}, Lanet/channel/util/ALog;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 33
    iget-wide v6, v1, Lanet/channel/statist/RequestStatistic;->start:J

    iget-wide v8, v3, Lanet/channel/fulltrace/b;->c:J

    sub-long/2addr v6, v8

    iput-wide v6, v1, Lanet/channel/statist/RequestStatistic;->sinceInitTime:J

    .line 34
    iget v0, v3, Lanet/channel/fulltrace/b;->a:I

    iput v0, v1, Lanet/channel/statist/RequestStatistic;->startType:I

    if-eq v0, v4, :cond_df

    .line 35
    iget-wide v6, v3, Lanet/channel/fulltrace/b;->d:J

    sub-long/2addr v8, v6

    iput-wide v8, v1, Lanet/channel/statist/RequestStatistic;->sinceLastLaunchTime:J

    .line 36
    :cond_df
    iget v0, v3, Lanet/channel/fulltrace/b;->e:I

    iput v0, v1, Lanet/channel/statist/RequestStatistic;->deviceLevel:I

    .line 37
    iget-boolean v0, v3, Lanet/channel/fulltrace/b;->b:Z

    if-eqz v0, :cond_e9

    const/4 v0, 0x1

    goto :goto_ea

    :cond_e9
    const/4 v0, 0x0

    :goto_ea
    iput v0, v1, Lanet/channel/statist/RequestStatistic;->isFromExternal:I

    .line 38
    iget-object v0, v3, Lanet/channel/fulltrace/b;->f:Ljava/lang/String;

    iput-object v0, v1, Lanet/channel/statist/RequestStatistic;->speedBucket:Ljava/lang/String;

    .line 39
    iget-object v0, v3, Lanet/channel/fulltrace/b;->g:Ljava/lang/String;

    iput-object v0, v1, Lanet/channel/statist/RequestStatistic;->abTestBucket:Ljava/lang/String;

    .line 40
    :cond_f4
    iget-wide v6, v1, Lanet/channel/statist/RequestStatistic;->reqServiceTransmissionEnd:J

    iget-wide v8, v1, Lanet/channel/statist/RequestStatistic;->netReqStart:J

    sub-long/2addr v6, v8

    iput-wide v6, v1, Lanet/channel/statist/RequestStatistic;->serializeTransferTime:J

    .line 41
    iget-object v0, p0, La5/f;->c:La5/c;

    .line 42
    iget-object v0, v0, La5/c;->e:La5/g;

    const-string v3, "RequestUserInfo"

    .line 43
    iget-object v0, v0, La5/g;->a:Lu4/i;

    invoke-virtual {v0, v3}, Lu4/i;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 44
    iput-object v0, v1, Lanet/channel/statist/RequestStatistic;->userInfo:Ljava/lang/String;

    .line 45
    invoke-static {}, Lanet/channel/appmonitor/AppMonitor;->getInstance()Lanet/channel/appmonitor/IAppMonitor;

    move-result-object v0

    invoke-interface {v0, v1}, Lanet/channel/appmonitor/IAppMonitor;->commitStat(Lanet/channel/statist/StatObject;)V

    .line 46
    sget-boolean v0, Lx4/b;->a:Z

    .line 47
    sget-object v0, Lx4/b;->k:Ljava/util/concurrent/CopyOnWriteArrayList;

    if-nez v0, :cond_117

    goto :goto_139

    .line 48
    :cond_117
    iget-object v3, v1, Lanet/channel/statist/RequestStatistic;->host:Ljava/lang/String;

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_120

    goto :goto_139

    .line 49
    :cond_120
    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_124
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_139

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    .line 50
    iget-object v6, v1, Lanet/channel/statist/RequestStatistic;->host:Ljava/lang/String;

    invoke-virtual {v6, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_124

    const/4 v5, 0x1

    :cond_139
    :goto_139
    if-eqz v5, :cond_147

    .line 51
    new-instance v0, Lanet/channel/statist/RequestMonitor;

    invoke-direct {v0, v1}, Lanet/channel/statist/RequestMonitor;-><init>(Lanet/channel/statist/RequestStatistic;)V

    .line 52
    invoke-static {}, Lanet/channel/appmonitor/AppMonitor;->getInstance()Lanet/channel/appmonitor/IAppMonitor;

    move-result-object v3

    invoke-interface {v3, v0}, Lanet/channel/appmonitor/IAppMonitor;->commitStat(Lanet/channel/statist/StatObject;)V
    :try_end_147
    .catchall {:try_start_9 .. :try_end_147} :catchall_180

    .line 53
    :cond_147
    :try_start_147
    iget-object v0, v1, Lanet/channel/statist/RequestStatistic;->ip:Ljava/lang/String;

    .line 54
    iget-object v3, v1, Lanet/channel/statist/RequestStatistic;->extra:Lorg/json/JSONObject;

    if-nez v3, :cond_14e

    goto :goto_154

    :cond_14e
    const-string v2, "firstIp"

    invoke-virtual {v3, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 55
    :goto_154
    invoke-static {v0}, Lanet/channel/strategy/utils/c;->b(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_160

    invoke-static {v2}, Lanet/channel/strategy/utils/c;->b(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_16c

    .line 56
    :cond_160
    new-instance v0, Lanet/channel/statist/RequestMonitor;

    invoke-direct {v0, v1}, Lanet/channel/statist/RequestMonitor;-><init>(Lanet/channel/statist/RequestStatistic;)V

    .line 57
    invoke-static {}, Lanet/channel/appmonitor/AppMonitor;->getInstance()Lanet/channel/appmonitor/IAppMonitor;

    move-result-object v2

    invoke-interface {v2, v0}, Lanet/channel/appmonitor/IAppMonitor;->commitStat(Lanet/channel/statist/StatObject;)V
    :try_end_16c
    .catch Ljava/lang/Exception; {:try_start_147 .. :try_end_16c} :catch_16c
    .catchall {:try_start_147 .. :try_end_16c} :catchall_180

    .line 58
    :catch_16c
    :cond_16c
    :try_start_16c
    sget-object v0, Le5/b$a;->a:Le5/b;

    .line 59
    iget-object v2, p0, La5/f;->c:La5/c;

    .line 60
    iget-object v2, v2, La5/c;->e:La5/g;

    .line 61
    invoke-virtual {v2}, La5/g;->c()Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, La5/f;->a:Lu4/b;

    .line 62
    iget-object v3, v3, Lu4/b;->d:Lf5/a;

    .line 63
    invoke-virtual {v0, v2, v3}, Le5/b;->a(Ljava/lang/String;Lf5/a;)V

    .line 64
    invoke-static {v1}, Lanet/channel/detect/n;->a(Lanet/channel/statist/RequestStatistic;)V
    :try_end_180
    .catchall {:try_start_16c .. :try_end_180} :catchall_180

    :catchall_180
    :cond_180
    return-void
.end method
