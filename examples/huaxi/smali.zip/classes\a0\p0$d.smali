.class public final La0/p0$d;
.super Lwg/j;
.source "SuspendAnimation.kt"

# interfaces
.implements Lvg/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La0/p0;->a(La0/h;La0/c;JLvg/l;Log/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lwg/j;",
        "Lvg/l<",
        "Ljava/lang/Long;",
        "Lkg/l;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic a:Lwg/w;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lwg/w<",
            "La0/f<",
            "TT;TV;>;>;"
        }
    .end annotation
.end field

.field public final synthetic b:F

.field public final synthetic c:La0/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/c<",
            "TT;TV;>;"
        }
    .end annotation
.end field

.field public final synthetic d:La0/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/h<",
            "TT;TV;>;"
        }
    .end annotation
.end field

.field public final synthetic e:Lvg/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lvg/l<",
            "La0/f<",
            "TT;TV;>;",
            "Lkg/l;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lwg/w;FLa0/c;La0/h;Lvg/l;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwg/w<",
            "La0/f<",
            "TT;TV;>;>;F",
            "La0/c<",
            "TT;TV;>;",
            "La0/h<",
            "TT;TV;>;",
            "Lvg/l<",
            "-",
            "La0/f<",
            "TT;TV;>;",
            "Lkg/l;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La0/p0$d;->a:Lwg/w;

    iput p2, p0, La0/p0$d;->b:F

    iput-object p3, p0, La0/p0$d;->c:La0/c;

    iput-object p4, p0, La0/p0$d;->d:La0/h;

    iput-object p5, p0, La0/p0$d;->e:Lvg/l;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lwg/j;-><init>(I)V

    return-void
.end method


# virtual methods
.method public invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    .line 1
    check-cast p1, Ljava/lang/Number;

    invoke-virtual {p1}, Ljava/lang/Number;->longValue()J

    move-result-wide v1

    .line 2
    iget-object p1, p0, La0/p0$d;->a:Lwg/w;

    iget-object p1, p1, Lwg/w;->a:Ljava/lang/Object;

    invoke-static {p1}, Lp/h;->m(Ljava/lang/Object;)V

    move-object v0, p1

    check-cast v0, La0/f;

    iget v3, p0, La0/p0$d;->b:F

    iget-object v4, p0, La0/p0$d;->c:La0/c;

    iget-object v5, p0, La0/p0$d;->d:La0/h;

    iget-object v6, p0, La0/p0$d;->e:Lvg/l;

    .line 3
    invoke-static/range {v0 .. v6}, La0/p0;->c(La0/f;JFLa0/c;La0/h;Lvg/l;)V

    .line 4
    sget-object p1, Lkg/l;->a:Lkg/l;

    return-object p1
.end method
