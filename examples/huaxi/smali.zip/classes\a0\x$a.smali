.class public final La0/x$a;
.super Ljava/lang/Object;
.source "Easing.kt"

# interfaces
.implements La0/w;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La0/x;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# static fields
.field public static final a:La0/x$a;


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    new-instance v0, La0/x$a;

    invoke-direct {v0}, La0/x$a;-><init>()V

    sput-object v0, La0/x$a;->a:La0/x$a;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(F)F
    .registers 2

    return p1
.end method
