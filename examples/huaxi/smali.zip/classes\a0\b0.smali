.class public final La0/b0;
.super Ljava/lang/Object;
.source "FloatAnimationSpec.kt"

# interfaces
.implements La0/z;


# instance fields
.field public final a:F

.field public final b:La0/m0;


# direct methods
.method public constructor <init>()V
    .registers 3

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0, v0, v0, v0, v1}, La0/b0;-><init>(FFFI)V

    return-void
.end method

.method public constructor <init>(FFF)V
    .registers 7

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput p3, p0, La0/b0;->a:F

    .line 3
    new-instance p3, La0/m0;

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-direct {p3, v0}, La0/m0;-><init>(F)V

    const/4 v0, 0x0

    cmpg-float v1, p1, v0

    if-ltz v1, :cond_33

    .line 4
    iput p1, p3, La0/m0;->g:F

    const/4 p1, 0x0

    .line 5
    iput-boolean p1, p3, La0/m0;->c:Z

    .line 6
    iget-wide v1, p3, La0/m0;->b:D

    mul-double v1, v1, v1

    double-to-float v1, v1

    cmpg-float v0, v1, v0

    if-lez v0, :cond_2b

    float-to-double v0, p2

    .line 7
    invoke-static {v0, v1}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v0

    iput-wide v0, p3, La0/m0;->b:D

    .line 8
    iput-boolean p1, p3, La0/m0;->c:Z

    .line 9
    iput-object p3, p0, La0/b0;->b:La0/m0;

    return-void

    .line 10
    :cond_2b
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "Spring stiffness constant must be positive."

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 11
    :cond_33
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "Damping ratio must be non-negative"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public synthetic constructor <init>(FFFI)V
    .registers 6

    and-int/lit8 v0, p4, 0x1

    if-eqz v0, :cond_6

    const/high16 p1, 0x3f800000    # 1.0f

    :cond_6
    and-int/lit8 v0, p4, 0x2

    if-eqz v0, :cond_d

    const p2, 0x44bb8000    # 1500.0f

    :cond_d
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_14

    const p3, 0x3c23d70a    # 0.01f

    .line 12
    :cond_14
    invoke-direct {p0, p1, p2, p3}, La0/b0;-><init>(FFF)V

    return-void
.end method


# virtual methods
.method public bridge synthetic a(La0/u0;)La0/y0;
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, La0/b0;->f(La0/u0;)La0/e1;

    move-result-object p1

    return-object p1
.end method

.method public b(JFFF)F
    .registers 8

    const-wide/32 v0, 0xf4240

    .line 1
    div-long/2addr p1, v0

    .line 2
    iget-object v0, p0, La0/b0;->b:La0/m0;

    .line 3
    iput p4, v0, La0/m0;->a:F

    .line 4
    invoke-virtual {v0, p3, p5, p1, p2}, La0/m0;->a(FFJ)J

    move-result-wide p1

    const-wide p3, 0xffffffffL

    and-long/2addr p1, p3

    long-to-int p2, p1

    .line 5
    invoke-static {p2}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p1

    return p1
.end method

.method public c(FFF)J
    .registers 45

    move-object/from16 v0, p0

    .line 1
    iget-object v1, v0, La0/b0;->b:La0/m0;

    .line 2
    iget-wide v2, v1, La0/m0;->b:D

    mul-double v2, v2, v2

    double-to-float v2, v2

    .line 3
    iget v1, v1, La0/m0;->g:F

    sub-float v3, p1, p2

    .line 4
    iget v4, v0, La0/b0;->a:F

    div-float/2addr v3, v4

    div-float v4, p3, v4

    float-to-double v5, v2

    float-to-double v1, v1

    float-to-double v7, v4

    float-to-double v3, v3

    const/high16 v9, 0x3f800000    # 1.0f

    float-to-double v9, v9

    const-wide/high16 v11, 0x4000000000000000L    # 2.0

    mul-double v13, v1, v11

    .line 5
    invoke-static {v5, v6}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v15

    mul-double v13, v13, v15

    neg-double v11, v13

    mul-double v13, v13, v13

    const-wide/high16 v15, 0x4010000000000000L    # 4.0

    mul-double v5, v5, v15

    sub-double/2addr v13, v5

    .line 6
    invoke-static {v13, v14}, Landroidx/appcompat/widget/m;->p(D)La0/p;

    move-result-object v5

    move-wide v15, v9

    .line 7
    iget-wide v9, v5, La0/p;->a:D

    add-double/2addr v9, v11

    .line 8
    iput-wide v9, v5, La0/p;->a:D

    const-wide/high16 v17, 0x4000000000000000L    # 2.0

    div-double v9, v9, v17

    .line 9
    iput-wide v9, v5, La0/p;->a:D

    .line 10
    iget-wide v9, v5, La0/p;->b:D

    div-double v9, v9, v17

    .line 11
    iput-wide v9, v5, La0/p;->b:D

    .line 12
    invoke-static {v13, v14}, Landroidx/appcompat/widget/m;->p(D)La0/p;

    move-result-object v6

    .line 13
    iget-wide v9, v6, La0/p;->a:D

    const/4 v13, -0x1

    int-to-double v13, v13

    mul-double v9, v9, v13

    .line 14
    iput-wide v9, v6, La0/p;->a:D

    move-wide/from16 v17, v1

    .line 15
    iget-wide v0, v6, La0/p;->b:D

    mul-double v0, v0, v13

    .line 16
    iput-wide v0, v6, La0/p;->b:D

    add-double/2addr v9, v11

    .line 17
    iput-wide v9, v6, La0/p;->a:D

    const-wide/high16 v11, 0x4000000000000000L    # 2.0

    div-double/2addr v9, v11

    .line 18
    iput-wide v9, v6, La0/p;->a:D

    div-double/2addr v0, v11

    .line 19
    iput-wide v0, v6, La0/p;->b:D

    const-wide/16 v0, 0x0

    const/4 v9, 0x1

    cmpg-double v10, v3, v0

    if-nez v10, :cond_69

    const/4 v11, 0x1

    goto :goto_6a

    :cond_69
    const/4 v11, 0x0

    :goto_6a
    if-eqz v11, :cond_79

    cmpg-double v11, v7, v0

    if-nez v11, :cond_72

    const/4 v11, 0x1

    goto :goto_73

    :cond_72
    const/4 v11, 0x0

    :goto_73
    if-eqz v11, :cond_79

    const-wide/16 v0, 0x0

    goto/16 :goto_2d2

    :cond_79
    if-gez v10, :cond_7c

    neg-double v7, v7

    .line 20
    :cond_7c
    invoke-static {v3, v4}, Ljava/lang/Math;->abs(D)D

    move-result-wide v3

    const-wide/high16 v10, 0x3ff0000000000000L    # 1.0

    const-wide v28, 0x7fefffffffffffffL    # Double.MAX_VALUE

    cmpl-double v19, v17, v10

    if-lez v19, :cond_1b2

    .line 21
    iget-wide v10, v5, La0/p;->a:D

    .line 22
    iget-wide v5, v6, La0/p;->a:D

    mul-double v17, v10, v3

    sub-double v17, v17, v7

    sub-double v7, v10, v5

    div-double v12, v17, v7

    sub-double/2addr v3, v12

    div-double v17, v15, v3

    .line 23
    invoke-static/range {v17 .. v18}, Ljava/lang/Math;->abs(D)D

    move-result-wide v17

    invoke-static/range {v17 .. v18}, Ljava/lang/Math;->log(D)D

    move-result-wide v17

    div-double v0, v17, v10

    div-double v17, v15, v12

    .line 24
    invoke-static/range {v17 .. v18}, Ljava/lang/Math;->abs(D)D

    move-result-wide v17

    invoke-static/range {v17 .. v18}, Ljava/lang/Math;->log(D)D

    move-result-wide v17

    move-wide/from16 v21, v15

    div-double v14, v17, v5

    .line 25
    invoke-static {v0, v1}, Ljava/lang/Double;->isInfinite(D)Z

    move-result v16

    if-nez v16, :cond_c1

    invoke-static {v0, v1}, Ljava/lang/Double;->isNaN(D)Z

    move-result v16

    if-nez v16, :cond_c1

    const/16 v16, 0x1

    goto :goto_c3

    :cond_c1
    const/16 v16, 0x0

    :goto_c3
    xor-int/lit8 v16, v16, 0x1

    if-eqz v16, :cond_c9

    move-wide v0, v14

    goto :goto_e3

    .line 26
    :cond_c9
    invoke-static {v14, v15}, Ljava/lang/Double;->isInfinite(D)Z

    move-result v16

    if-nez v16, :cond_d8

    invoke-static {v14, v15}, Ljava/lang/Double;->isNaN(D)Z

    move-result v16

    if-nez v16, :cond_d8

    const/16 v16, 0x1

    goto :goto_da

    :cond_d8
    const/16 v16, 0x0

    :goto_da
    xor-int/lit8 v9, v16, 0x1

    if-eqz v9, :cond_df

    goto :goto_e3

    .line 27
    :cond_df
    invoke-static {v0, v1, v14, v15}, Ljava/lang/Math;->max(DD)D

    move-result-wide v0

    :goto_e3
    mul-double v14, v3, v10

    move-wide/from16 p1, v3

    neg-double v2, v12

    mul-double v2, v2, v5

    div-double v2, v14, v2

    .line 28
    invoke-static {v2, v3}, Ljava/lang/Math;->log(D)D

    move-result-wide v2

    sub-double v17, v5, v10

    div-double v2, v2, v17

    .line 29
    invoke-static {v2, v3}, Ljava/lang/Double;->isNaN(D)Z

    move-result v4

    if-nez v4, :cond_142

    const-wide/16 v17, 0x0

    cmpg-double v4, v2, v17

    if-gtz v4, :cond_101

    goto :goto_142

    :cond_101
    cmpl-double v4, v2, v17

    if-lez v4, :cond_130

    mul-double v17, v10, v2

    .line 30
    invoke-static/range {v17 .. v18}, Ljava/lang/Math;->exp(D)D

    move-result-wide v17

    move-wide/from16 v23, p1

    mul-double v17, v17, v23

    mul-double v2, v2, v5

    invoke-static {v2, v3}, Ljava/lang/Math;->exp(D)D

    move-result-wide v2

    mul-double v2, v2, v12

    add-double v2, v2, v17

    neg-double v2, v2

    cmpg-double v4, v2, v21

    if-gez v4, :cond_132

    const-wide/16 v2, 0x0

    cmpl-double v4, v12, v2

    if-lez v4, :cond_12d

    cmpg-double v4, v23, v2

    if-gez v4, :cond_12d

    move-wide/from16 v2, v21

    const-wide/16 v0, 0x0

    goto :goto_146

    :cond_12d
    move-wide/from16 v2, v21

    goto :goto_146

    :cond_130
    move-wide/from16 v23, p1

    :cond_132
    move-wide/from16 v2, v21

    mul-double v0, v12, v5

    mul-double v0, v0, v5

    neg-double v0, v0

    mul-double v14, v14, v10

    div-double/2addr v0, v14

    .line 31
    invoke-static {v0, v1}, Ljava/lang/Math;->log(D)D

    move-result-wide v0

    div-double/2addr v0, v7

    goto :goto_147

    :cond_142
    :goto_142
    move-wide/from16 v23, p1

    move-wide/from16 v2, v21

    :goto_146
    neg-double v2, v2

    :goto_147
    move-wide/from16 v39, v2

    .line 32
    new-instance v2, La0/k0;

    move-object/from16 v30, v2

    move-wide/from16 v31, v23

    move-wide/from16 v33, v10

    move-wide/from16 v35, v12

    move-wide/from16 v37, v5

    invoke-direct/range {v30 .. v40}, La0/k0;-><init>(DDDDD)V

    .line 33
    new-instance v3, La0/l0;

    move-object/from16 v30, v3

    invoke-direct/range {v30 .. v38}, La0/l0;-><init>(DDDD)V

    .line 34
    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v4

    invoke-virtual {v2, v4}, La0/k0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Math;->abs(D)D

    move-result-wide v4

    const-wide v6, 0x3f1a36e2eb1c432dL    # 1.0E-4

    cmpg-double v8, v4, v6

    if-gez v8, :cond_17c

    goto/16 :goto_2ca

    :cond_17c
    const/4 v4, 0x0

    :goto_17d
    const-wide v5, 0x3f50624dd2f1a9fcL    # 0.001

    cmpl-double v7, v28, v5

    if-lez v7, :cond_2ca

    const/16 v5, 0x64

    if-ge v4, v5, :cond_2ca

    add-int/lit8 v4, v4, 0x1

    .line 35
    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v5

    invoke-virtual {v2, v5}, La0/k0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Number;

    invoke-virtual {v5}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v5

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v7

    invoke-virtual {v3, v7}, La0/l0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Number;

    invoke-virtual {v7}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v7

    div-double/2addr v5, v7

    sub-double v5, v0, v5

    sub-double/2addr v0, v5

    .line 36
    invoke-static {v0, v1}, Ljava/lang/Math;->abs(D)D

    move-result-wide v28

    move-wide v0, v5

    goto :goto_17d

    :cond_1b2
    move-wide v0, v15

    cmpg-double v2, v17, v10

    if-gez v2, :cond_1d0

    .line 37
    iget-wide v9, v5, La0/p;->a:D

    mul-double v11, v9, v3

    sub-double/2addr v7, v11

    .line 38
    iget-wide v5, v5, La0/p;->b:D

    div-double/2addr v7, v5

    mul-double v3, v3, v3

    mul-double v7, v7, v7

    add-double/2addr v7, v3

    .line 39
    invoke-static {v7, v8}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v2

    div-double/2addr v0, v2

    .line 40
    invoke-static {v0, v1}, Ljava/lang/Math;->log(D)D

    move-result-wide v0

    div-double/2addr v0, v9

    goto/16 :goto_2ca

    .line 41
    :cond_1d0
    iget-wide v5, v5, La0/p;->a:D

    mul-double v10, v5, v3

    sub-double/2addr v7, v10

    div-double v12, v0, v3

    .line 42
    invoke-static {v12, v13}, Ljava/lang/Math;->abs(D)D

    move-result-wide v12

    invoke-static {v12, v13}, Ljava/lang/Math;->log(D)D

    move-result-wide v12

    div-double/2addr v12, v5

    div-double v14, v0, v7

    .line 43
    invoke-static {v14, v15}, Ljava/lang/Math;->abs(D)D

    move-result-wide v14

    invoke-static {v14, v15}, Ljava/lang/Math;->log(D)D

    move-result-wide v14

    move-wide/from16 v17, v14

    const/4 v2, 0x0

    :goto_1ed
    const/4 v9, 0x6

    if-ge v2, v9, :cond_1ff

    div-double v17, v17, v5

    .line 44
    invoke-static/range {v17 .. v18}, Ljava/lang/Math;->abs(D)D

    move-result-wide v17

    invoke-static/range {v17 .. v18}, Ljava/lang/Math;->log(D)D

    move-result-wide v17

    sub-double v17, v14, v17

    add-int/lit8 v2, v2, 0x1

    goto :goto_1ed

    :cond_1ff
    div-double v14, v17, v5

    .line 45
    invoke-static {v12, v13}, Ljava/lang/Double;->isInfinite(D)Z

    move-result v2

    if-nez v2, :cond_211

    invoke-static {v12, v13}, Ljava/lang/Double;->isNaN(D)Z

    move-result v2

    if-nez v2, :cond_211

    const/4 v2, 0x1

    const/16 v21, 0x1

    goto :goto_214

    :cond_211
    const/4 v2, 0x1

    const/16 v21, 0x0

    :goto_214
    xor-int/lit8 v9, v21, 0x1

    if-eqz v9, :cond_21a

    move-wide v12, v14

    goto :goto_231

    .line 46
    :cond_21a
    invoke-static {v14, v15}, Ljava/lang/Double;->isInfinite(D)Z

    move-result v9

    if-nez v9, :cond_228

    invoke-static {v14, v15}, Ljava/lang/Double;->isNaN(D)Z

    move-result v9

    if-nez v9, :cond_228

    const/4 v9, 0x1

    goto :goto_229

    :cond_228
    const/4 v9, 0x0

    :goto_229
    xor-int/2addr v2, v9

    if-eqz v2, :cond_22d

    goto :goto_231

    .line 47
    :cond_22d
    invoke-static {v12, v13, v14, v15}, Ljava/lang/Math;->max(DD)D

    move-result-wide v12

    :goto_231
    add-double/2addr v10, v7

    neg-double v9, v10

    mul-double v14, v5, v7

    div-double/2addr v9, v14

    .line 48
    invoke-static {v9, v10}, Ljava/lang/Double;->isNaN(D)Z

    move-result v2

    if-nez v2, :cond_275

    const-wide/16 v14, 0x0

    cmpg-double v2, v9, v14

    if-gtz v2, :cond_243

    goto :goto_275

    :cond_243
    cmpl-double v2, v9, v14

    if-lez v2, :cond_26a

    mul-double v14, v5, v9

    .line 49
    invoke-static {v14, v15}, Ljava/lang/Math;->exp(D)D

    move-result-wide v17

    mul-double v17, v17, v3

    mul-double v9, v9, v7

    invoke-static {v14, v15}, Ljava/lang/Math;->exp(D)D

    move-result-wide v14

    mul-double v14, v14, v9

    add-double v14, v14, v17

    neg-double v9, v14

    cmpg-double v2, v9, v0

    if-gez v2, :cond_26a

    const-wide/16 v9, 0x0

    cmpg-double v2, v7, v9

    if-gez v2, :cond_275

    cmpl-double v2, v3, v9

    if-lez v2, :cond_275

    move-wide v12, v9

    goto :goto_275

    :cond_26a
    const-wide/high16 v9, 0x4000000000000000L    # 2.0

    div-double v11, v9, v5

    neg-double v9, v11

    div-double v11, v3, v7

    sub-double/2addr v9, v11

    move-wide/from16 v26, v0

    goto :goto_279

    :cond_275
    :goto_275
    neg-double v9, v0

    move-wide/from16 v26, v9

    move-wide v9, v12

    .line 50
    :goto_279
    new-instance v0, La0/i0;

    move-object/from16 v19, v0

    move-wide/from16 v20, v3

    move-wide/from16 v22, v7

    move-wide/from16 v24, v5

    invoke-direct/range {v19 .. v27}, La0/i0;-><init>(DDDD)V

    .line 51
    new-instance v1, La0/j0;

    move-object/from16 v19, v1

    move-wide/from16 v20, v7

    move-wide/from16 v22, v5

    move-wide/from16 v24, v3

    invoke-direct/range {v19 .. v25}, La0/j0;-><init>(DDD)V

    const/4 v2, 0x0

    const-wide v3, 0x3f50624dd2f1a9fcL    # 0.001

    :goto_299
    cmpl-double v5, v28, v3

    if-lez v5, :cond_2c9

    const/16 v5, 0x64

    if-ge v2, v5, :cond_2c9

    add-int/lit8 v2, v2, 0x1

    .line 52
    invoke-static {v9, v10}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v6

    invoke-virtual {v0, v6}, La0/i0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Number;

    invoke-virtual {v6}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v6

    invoke-static {v9, v10}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v8

    invoke-virtual {v1, v8}, La0/j0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/Number;

    invoke-virtual {v8}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v11

    div-double/2addr v6, v11

    sub-double v6, v9, v6

    sub-double/2addr v9, v6

    .line 53
    invoke-static {v9, v10}, Ljava/lang/Math;->abs(D)D

    move-result-wide v28

    move-wide v9, v6

    goto :goto_299

    :cond_2c9
    move-wide v0, v9

    :cond_2ca
    :goto_2ca
    const-wide v2, 0x408f400000000000L    # 1000.0

    mul-double v0, v0, v2

    double-to-long v0, v0

    :goto_2d2
    const-wide/32 v2, 0xf4240

    mul-long v0, v0, v2

    return-wide v0
.end method

.method public d(FFF)F
    .registers 4

    const/4 p1, 0x0

    return p1
.end method

.method public e(JFFF)F
    .registers 8

    const-wide/32 v0, 0xf4240

    .line 1
    div-long/2addr p1, v0

    .line 2
    iget-object v0, p0, La0/b0;->b:La0/m0;

    .line 3
    iput p4, v0, La0/m0;->a:F

    .line 4
    invoke-virtual {v0, p3, p5, p1, p2}, La0/m0;->a(FFJ)J

    move-result-wide p1

    const/16 p3, 0x20

    shr-long/2addr p1, p3

    long-to-int p2, p1

    .line 5
    invoke-static {p2}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p1

    return p1
.end method

.method public f(La0/u0;)La0/e1;
    .registers 3

    const-string v0, "converter"

    .line 1
    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    new-instance p1, La0/e1;

    invoke-direct {p1, p0}, La0/e1;-><init>(La0/z;)V

    return-object p1
.end method
