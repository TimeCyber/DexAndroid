.class public final La7/q;
.super Ljava/lang/Object;
.source "RegexUtils.java"

# interfaces
.implements Lc0/m0;
.implements Lg2/f;


# static fields
.field public static final b:La7/q;

.field public static final c:La7/q;


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, La7/q;

    invoke-direct {v0}, La7/q;-><init>()V

    sput-object v0, La7/q;->b:La7/q;

    .line 2
    new-instance v0, La7/q;

    invoke-direct {v0}, La7/q;-><init>()V

    sput-object v0, La7/q;->c:La7/q;

    return-void
.end method

.method public synthetic constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final c(Lp2/b;ILf2/d0;Lz1/r;ZI)Lc1/d;
    .registers 6

    if-eqz p3, :cond_d

    .line 1
    iget-object p2, p2, Lf2/d0;->b:Lf2/n;

    .line 2
    invoke-interface {p2, p1}, Lf2/n;->b(I)I

    move-result p1

    .line 3
    invoke-virtual {p3, p1}, Lz1/r;->c(I)Lc1/d;

    move-result-object p1

    goto :goto_f

    .line 4
    :cond_d
    sget-object p1, Lc1/d;->e:Lc1/d;

    .line 5
    :goto_f
    sget p2, Li0/j1;->a:F

    sget p2, Li0/j1;->a:F

    invoke-interface {p0, p2}, Lp2/b;->j0(F)I

    move-result p0

    if-eqz p4, :cond_20

    int-to-float p2, p5

    .line 6
    iget p3, p1, Lc1/d;->a:F

    sub-float/2addr p2, p3

    int-to-float p3, p0

    sub-float/2addr p2, p3

    goto :goto_22

    .line 7
    :cond_20
    iget p2, p1, Lc1/d;->a:F

    :goto_22
    if-eqz p4, :cond_29

    int-to-float p0, p5

    .line 8
    iget p3, p1, Lc1/d;->a:F

    sub-float/2addr p0, p3

    goto :goto_2d

    .line 9
    :cond_29
    iget p3, p1, Lc1/d;->a:F

    int-to-float p0, p0

    add-float/2addr p0, p3

    .line 10
    :goto_2d
    iget p3, p1, Lc1/d;->b:F

    iget p1, p1, Lc1/d;->d:F

    .line 11
    new-instance p4, Lc1/d;

    invoke-direct {p4, p2, p3, p0, p1}, Lc1/d;-><init>(FFFF)V

    return-object p4
.end method

.method public static e(Ljava/lang/String;Ljava/lang/CharSequence;)Z
    .registers 3

    if-eqz p1, :cond_10

    .line 1
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v0

    if-lez v0, :cond_10

    invoke-static {p0, p1}, Ljava/util/regex/Pattern;->matches(Ljava/lang/String;Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_10

    const/4 p0, 0x1

    goto :goto_11

    :cond_10
    const/4 p0, 0x0

    :goto_11
    return p0
.end method

.method public static f(Ljava/lang/CharSequence;)Z
    .registers 2

    const-string v0, "^[1]\\d{10}$"

    .line 1
    invoke-static {v0, p0}, La7/q;->e(Ljava/lang/String;Ljava/lang/CharSequence;)Z

    move-result p0

    return p0
.end method

.method public static g(Ly0/h;Lr1/a;FFI)Ly0/h;
    .registers 13

    and-int/lit8 v0, p4, 0x2

    const/high16 v1, 0x7fc00000    # Float.NaN

    if-eqz v0, :cond_9

    const/high16 v4, 0x7fc00000    # Float.NaN

    goto :goto_a

    :cond_9
    move v4, p2

    :goto_a
    and-int/lit8 p2, p4, 0x4

    if-eqz p2, :cond_11

    const/high16 v5, 0x7fc00000    # Float.NaN

    goto :goto_12

    :cond_11
    move v5, p3

    :goto_12
    const-string p2, "alignmentLine"

    .line 1
    invoke-static {p1, p2}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    new-instance p2, Le0/b;

    .line 3
    sget-object p3, Landroidx/compose/ui/platform/b1;->a:Lvg/l;

    .line 4
    sget-object v6, Landroidx/compose/ui/platform/b1;->a:Lvg/l;

    const/4 v7, 0x0

    move-object v2, p2

    move-object v3, p1

    .line 5
    invoke-direct/range {v2 .. v7}, Le0/b;-><init>(Lr1/a;FFLvg/l;Lwg/e;)V

    .line 6
    invoke-interface {p0, p2}, Ly0/h;->p0(Ly0/h;)Ly0/h;

    move-result-object p0

    return-object p0
.end method

.method public static h(ILjava/lang/String;)I
    .registers 4

    if-lez p0, :cond_3

    return p0

    .line 1
    :cond_3
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " > 0 required but it was "

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method


# virtual methods
.method public a()Ljava/util/List;
    .registers 8

    .line 1
    invoke-static {}, Landroid/os/LocaleList;->getDefault()Landroid/os/LocaleList;

    move-result-object v0

    const-string v1, "getDefault()"

    invoke-static {v0, v1}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 3
    invoke-virtual {v0}, Landroid/os/LocaleList;->size()I

    move-result v2

    const/4 v3, 0x0

    :goto_13
    if-ge v3, v2, :cond_29

    .line 4
    new-instance v4, Lg2/a;

    invoke-virtual {v0, v3}, Landroid/os/LocaleList;->get(I)Ljava/util/Locale;

    move-result-object v5

    const-string v6, "localeList[i]"

    invoke-static {v5, v6}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v4, v5}, Lg2/a;-><init>(Ljava/util/Locale;)V

    invoke-interface {v1, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_13

    :cond_29
    return-object v1
.end method

.method public b(Lp2/b;Lo1/k;J)J
    .registers 9

    const-string p3, "$this$calculateMouseWheelScroll"

    invoke-static {p1, p3}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object p2, p2, Lo1/k;->a:Ljava/util/List;

    .line 2
    sget-object p3, Lc1/c;->b:Lc1/c$a;

    .line 3
    sget-wide p3, Lc1/c;->c:J

    .line 4
    new-instance v0, Lc1/c;

    invoke-direct {v0, p3, p4}, Lc1/c;-><init>(J)V

    .line 5
    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 p4, 0x0

    :goto_15
    if-ge p4, p3, :cond_2e

    .line 6
    invoke-interface {p2, p4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    .line 7
    check-cast v1, Lo1/q;

    .line 8
    iget-wide v2, v0, Lc1/c;->a:J

    .line 9
    iget-wide v0, v1, Lo1/q;->i:J

    .line 10
    invoke-static {v2, v3, v0, v1}, Lc1/c;->g(JJ)J

    move-result-wide v0

    .line 11
    new-instance v2, Lc1/c;

    invoke-direct {v2, v0, v1}, Lc1/c;-><init>(J)V

    add-int/lit8 p4, p4, 0x1

    move-object v0, v2

    goto :goto_15

    .line 12
    :cond_2e
    iget-wide p2, v0, Lc1/c;->a:J

    const/16 p4, 0x40

    int-to-float p4, p4

    .line 13
    invoke-interface {p1, p4}, Lp2/b;->Z(F)F

    move-result p1

    neg-float p1, p1

    invoke-static {p2, p3, p1}, Lc1/c;->h(JF)J

    move-result-wide p1

    return-wide p1
.end method

.method public d(Ljava/lang/String;)Lg2/e;
    .registers 4

    .line 1
    new-instance v0, Lg2/a;

    invoke-static {p1}, Ljava/util/Locale;->forLanguageTag(Ljava/lang/String;)Ljava/util/Locale;

    move-result-object p1

    const-string v1, "forLanguageTag(languageTag)"

    invoke-static {p1, v1}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, p1}, Lg2/a;-><init>(Ljava/util/Locale;)V

    return-object v0
.end method
