.class public final Landroidx/appcompat/R$bool;
.super Ljava/lang/Object;


# static fields
.field public static final abc_action_bar_embed_tabs:I = 0x7f040000

.field public static final abc_config_actionMenuItemAllCaps:I = 0x7f040001


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
