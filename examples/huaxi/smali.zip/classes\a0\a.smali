.class public final La0/a;
.super Lqg/i;
.source "Animatable.kt"

# interfaces
.implements Lvg/l;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lqg/i;",
        "Lvg/l<",
        "Log/d<",
        "-",
        "La0/e<",
        "Ljava/lang/Object;",
        "La0/n;",
        ">;>;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lqg/e;
    c = "androidx.compose.animation.core.Animatable$runAnimation$2"
    f = "Animatable.kt"
    l = {
        0x123
    }
    m = "invokeSuspend"
.end annotation


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Ljava/lang/Object;

.field public c:I

.field public final synthetic d:La0/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/b<",
            "Ljava/lang/Object;",
            "La0/n;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic e:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Object;"
        }
    .end annotation
.end field

.field public final synthetic f:La0/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/c<",
            "Ljava/lang/Object;",
            "La0/n;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic g:J

.field public final synthetic h:Lvg/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lvg/l<",
            "La0/b<",
            "Ljava/lang/Object;",
            "La0/n;",
            ">;",
            "Lkg/l;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(La0/b;Ljava/lang/Object;La0/c;JLvg/l;Log/d;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La0/b<",
            "Ljava/lang/Object;",
            "La0/n;",
            ">;",
            "Ljava/lang/Object;",
            "La0/c<",
            "Ljava/lang/Object;",
            "La0/n;",
            ">;J",
            "Lvg/l<",
            "-",
            "La0/b<",
            "Ljava/lang/Object;",
            "La0/n;",
            ">;",
            "Lkg/l;",
            ">;",
            "Log/d<",
            "-",
            "La0/a;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La0/a;->d:La0/b;

    iput-object p2, p0, La0/a;->e:Ljava/lang/Object;

    iput-object p3, p0, La0/a;->f:La0/c;

    iput-wide p4, p0, La0/a;->g:J

    iput-object p6, p0, La0/a;->h:Lvg/l;

    const/4 p1, 0x1

    invoke-direct {p0, p1, p7}, Lqg/i;-><init>(ILog/d;)V

    return-void
.end method


# virtual methods
.method public final create(Log/d;)Log/d;
    .registers 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Log/d<",
            "*>;)",
            "Log/d<",
            "Lkg/l;",
            ">;"
        }
    .end annotation

    new-instance v8, La0/a;

    iget-object v1, p0, La0/a;->d:La0/b;

    iget-object v2, p0, La0/a;->e:Ljava/lang/Object;

    iget-object v3, p0, La0/a;->f:La0/c;

    iget-wide v4, p0, La0/a;->g:J

    iget-object v6, p0, La0/a;->h:Lvg/l;

    move-object v0, v8

    move-object v7, p1

    invoke-direct/range {v0 .. v7}, La0/a;-><init>(La0/b;Ljava/lang/Object;La0/c;JLvg/l;Log/d;)V

    return-object v8
.end method

.method public invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    move-object v7, p1

    check-cast v7, Log/d;

    .line 1
    new-instance p1, La0/a;

    iget-object v1, p0, La0/a;->d:La0/b;

    iget-object v2, p0, La0/a;->e:Ljava/lang/Object;

    iget-object v3, p0, La0/a;->f:La0/c;

    iget-wide v4, p0, La0/a;->g:J

    iget-object v6, p0, La0/a;->h:Lvg/l;

    move-object v0, p1

    invoke-direct/range {v0 .. v7}, La0/a;-><init>(La0/b;Ljava/lang/Object;La0/c;JLvg/l;Log/d;)V

    .line 2
    sget-object v0, Lkg/l;->a:Lkg/l;

    invoke-virtual {p1, v0}, La0/a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 20

    move-object/from16 v7, p0

    sget-object v0, Lpg/a;->a:Lpg/a;

    .line 1
    iget v1, v7, La0/a;->c:I

    const/4 v8, 0x1

    if-eqz v1, :cond_20

    if-ne v1, v8, :cond_18

    iget-object v0, v7, La0/a;->b:Ljava/lang/Object;

    check-cast v0, Lwg/s;

    iget-object v1, v7, La0/a;->a:Ljava/lang/Object;

    check-cast v1, La0/h;

    :try_start_13
    invoke-static/range {p1 .. p1}, Lo1/a0;->H(Ljava/lang/Object;)V
    :try_end_16
    .catch Ljava/util/concurrent/CancellationException; {:try_start_13 .. :try_end_16} :catch_a9

    goto/16 :goto_98

    .line 2
    :cond_18
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 3
    :cond_20
    invoke-static/range {p1 .. p1}, Lo1/a0;->H(Ljava/lang/Object;)V

    .line 4
    :try_start_23
    iget-object v1, v7, La0/a;->d:La0/b;

    .line 5
    iget-object v2, v1, La0/b;->c:La0/h;

    .line 6
    iget-object v1, v1, La0/b;->a:La0/u0;

    .line 7
    invoke-interface {v1}, La0/u0;->a()Lvg/l;

    move-result-object v1

    iget-object v3, v7, La0/a;->e:Ljava/lang/Object;

    invoke-interface {v1, v3}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La0/n;

    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const-string v3, "<set-?>"

    .line 8
    invoke-static {v1, v3}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    iput-object v1, v2, La0/h;->c:La0/n;

    .line 10
    iget-object v1, v7, La0/a;->d:La0/b;

    iget-object v2, v7, La0/a;->f:La0/c;

    invoke-interface {v2}, La0/c;->g()Ljava/lang/Object;

    move-result-object v2

    .line 11
    iget-object v1, v1, La0/b;->e:Lm0/x0;

    .line 12
    invoke-interface {v1, v2}, Lm0/x0;->setValue(Ljava/lang/Object;)V

    .line 13
    iget-object v1, v7, La0/a;->d:La0/b;

    .line 14
    iget-object v1, v1, La0/b;->d:Lm0/x0;

    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 15
    invoke-interface {v1, v2}, Lm0/x0;->setValue(Ljava/lang/Object;)V

    .line 16
    iget-object v1, v7, La0/a;->d:La0/b;

    .line 17
    iget-object v1, v1, La0/b;->c:La0/h;

    .line 18
    invoke-virtual {v1}, La0/h;->getValue()Ljava/lang/Object;

    move-result-object v11

    .line 19
    iget-object v2, v1, La0/h;->c:La0/n;

    .line 20
    invoke-static {v2}, Landroidx/appcompat/widget/m;->s(La0/n;)La0/n;

    move-result-object v12

    .line 21
    iget-wide v13, v1, La0/h;->d:J

    const-wide/high16 v15, -0x8000000000000000L

    .line 22
    iget-boolean v2, v1, La0/h;->f:Z

    .line 23
    new-instance v6, La0/h;

    .line 24
    iget-object v10, v1, La0/h;->a:La0/u0;

    move-object v9, v6

    move/from16 v17, v2

    .line 25
    invoke-direct/range {v9 .. v17}, La0/h;-><init>(La0/u0;Ljava/lang/Object;La0/n;JJZ)V

    .line 26
    new-instance v9, Lwg/s;

    invoke-direct {v9}, Lwg/s;-><init>()V

    .line 27
    iget-object v2, v7, La0/a;->f:La0/c;

    .line 28
    iget-wide v3, v7, La0/a;->g:J

    .line 29
    new-instance v5, La0/a$a;

    iget-object v1, v7, La0/a;->d:La0/b;

    iget-object v10, v7, La0/a;->h:Lvg/l;

    invoke-direct {v5, v1, v6, v10, v9}, La0/a$a;-><init>(La0/b;La0/h;Lvg/l;Lwg/s;)V

    iput-object v6, v7, La0/a;->a:Ljava/lang/Object;

    iput-object v9, v7, La0/a;->b:Ljava/lang/Object;

    iput v8, v7, La0/a;->c:I

    move-object v1, v6

    move-object v10, v6

    move-object/from16 v6, p0

    invoke-static/range {v1 .. v6}, La0/p0;->a(La0/h;La0/c;JLvg/l;Log/d;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v0, :cond_96

    return-object v0

    :cond_96
    move-object v0, v9

    move-object v1, v10

    .line 30
    :goto_98
    iget-boolean v0, v0, Lwg/s;->a:Z

    if-eqz v0, :cond_9d

    goto :goto_9e

    :cond_9d
    const/4 v8, 0x2

    .line 31
    :goto_9e
    iget-object v0, v7, La0/a;->d:La0/b;

    invoke-static {v0}, La0/b;->b(La0/b;)V

    .line 32
    new-instance v0, La0/e;

    invoke-direct {v0, v1, v8}, La0/e;-><init>(La0/h;I)V
    :try_end_a8
    .catch Ljava/util/concurrent/CancellationException; {:try_start_23 .. :try_end_a8} :catch_a9

    return-object v0

    :catch_a9
    move-exception v0

    .line 33
    iget-object v1, v7, La0/a;->d:La0/b;

    invoke-static {v1}, La0/b;->b(La0/b;)V

    .line 34
    throw v0
.end method
