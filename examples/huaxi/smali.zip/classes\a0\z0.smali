.class public final La0/z0;
.super Ljava/lang/Object;
.source "VectorizedAnimationSpec.kt"

# interfaces
.implements La0/o;


# instance fields
.field public final a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "La0/b0;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(La0/n;FF)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La0/n;",
            "FF)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    invoke-virtual {p1}, La0/n;->b()I

    move-result v0

    const/4 v1, 0x0

    invoke-static {v1, v0}, Li0/z0;->X(II)Lch/f;

    move-result-object v0

    .line 3
    new-instance v1, Ljava/util/ArrayList;

    const/16 v2, 0xa

    invoke-static {v0, v2}, Llg/k;->d0(Ljava/lang/Iterable;I)I

    move-result v2

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 4
    invoke-virtual {v0}, Lch/d;->g()Llg/y;

    move-result-object v0

    .line 5
    :goto_1b
    move-object v2, v0

    check-cast v2, Lch/e;

    .line 6
    iget-boolean v2, v2, Lch/e;->c:Z

    if-eqz v2, :cond_33

    .line 7
    invoke-virtual {v0}, Llg/y;->b()I

    move-result v2

    .line 8
    new-instance v3, La0/b0;

    invoke-virtual {p1, v2}, La0/n;->a(I)F

    move-result v2

    invoke-direct {v3, p2, p3, v2}, La0/b0;-><init>(FFF)V

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1b

    .line 9
    :cond_33
    iput-object v1, p0, La0/z0;->a:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public get(I)La0/z;
    .registers 3

    .line 1
    iget-object v0, p0, La0/z0;->a:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La0/b0;

    return-object p1
.end method
