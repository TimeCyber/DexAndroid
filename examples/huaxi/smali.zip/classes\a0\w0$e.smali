.class public final La0/w0$e;
.super Lwg/j;
.source "VectorConverters.kt"

# interfaces
.implements Lvg/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La0/w0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lwg/j;",
        "Lvg/l<",
        "Ljava/lang/Float;",
        "La0/k;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:La0/w0$e;


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    new-instance v0, La0/w0$e;

    invoke-direct {v0}, La0/w0$e;-><init>()V

    sput-object v0, La0/w0$e;->a:La0/w0$e;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lwg/j;-><init>(I)V

    return-void
.end method


# virtual methods
.method public invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    check-cast p1, Ljava/lang/Number;

    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    move-result p1

    .line 2
    new-instance v0, La0/k;

    invoke-direct {v0, p1}, La0/k;-><init>(F)V

    return-object v0
.end method
