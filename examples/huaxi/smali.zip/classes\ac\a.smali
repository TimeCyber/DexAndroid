.class public Lac/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Landroid/net/Uri;

.field public static final b:[Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .registers 2

    const-string v0, "content://com.huawei.hwid"

    .line 1
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    sput-object v0, Lac/a;->a:Landroid/net/Uri;

    const-string v0, "B92825C2BD5D6D6D1E7F39EECD17843B7D9016F611136B75441BC6F4D3F00F05"

    const-string v1, "E49D5C2C0E11B3B1B96CA56C6DE2A14EC7DAB5CCC3B5F300D03E5B4DBA44F539"

    .line 2
    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lac/a;->b:[Ljava/lang/String;

    return-void
.end method

.method public static a(Landroid/content/Context;)Ljava/lang/String;
    .registers 4

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const-string v1, "aegis"

    const/16 v2, 0x18

    if-lt v0, v2, :cond_1f

    .line 2
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Landroid/content/Context;->createDeviceProtectedStorageContext()Landroid/content/Context;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    sget-object p0, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-static {v0, p0, v1}, Lcom/huawei/hms/adapter/a;->a(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    goto :goto_35

    .line 3
    :cond_1f
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    sget-object p0, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-static {v0, p0, v1}, Lcom/huawei/hms/adapter/a;->a(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    :goto_35
    return-object p0
.end method

.method public static b([B)Ljava/lang/String;
    .registers 7

    if-eqz p0, :cond_2e

    .line 1
    array-length v0, p0

    if-nez v0, :cond_6

    goto :goto_2e

    .line 2
    :cond_6
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 3
    array-length v1, p0

    const/4 v2, 0x0

    :goto_d
    if-ge v2, v1, :cond_29

    aget-byte v3, p0, v2

    and-int/lit16 v3, v3, 0xff

    .line 4
    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    .line 5
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v5, 0x1

    if-ne v4, v5, :cond_23

    const/16 v4, 0x30

    .line 6
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 7
    :cond_23
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v2, v2, 0x1

    goto :goto_d

    .line 8
    :cond_29
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_2e
    :goto_2e
    const-string p0, ""

    return-object p0
.end method

.method public static c(Ljava/io/InputStream;Landroid/content/Context;)V
    .registers 8

    .line 1
    invoke-static {p1}, Lac/a;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    .line 2
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 3
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v0

    const-string v1, "BksUtil"

    if-nez v0, :cond_39

    .line 4
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_18

    goto :goto_39

    .line 5
    :cond_18
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 6
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v2

    if-eqz v2, :cond_2d

    .line 7
    invoke-static {v1}, La0/u;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "The directory  has already exists"

    invoke-static {v0, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_39

    .line 8
    :cond_2d
    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    move-result v0

    if-eqz v0, :cond_34

    goto :goto_39

    :cond_34
    const-string v0, "create directory  failed"

    .line 9
    invoke-static {v1, v0}, La0/u;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 10
    :cond_39
    :goto_39
    new-instance v0, Ljava/io/File;

    const-string v2, "hmsrootcas.bks"

    invoke-direct {v0, p1, v2}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 11
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result p1

    if-eqz p1, :cond_49

    .line 12
    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    :cond_49
    const/4 p1, 0x0

    :try_start_4a
    const-string v2, "write output stream "

    .line 13
    invoke-static {v1, v2}, La0/u;->m(Ljava/lang/String;Ljava/lang/String;)V

    .line 14
    new-instance v2, Ljava/io/FileOutputStream;

    invoke-direct {v2, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_54
    .catch Ljava/io/IOException; {:try_start_4a .. :try_end_54} :catch_6e
    .catchall {:try_start_4a .. :try_end_54} :catchall_6c

    const/16 p1, 0x800

    :try_start_56
    new-array v0, p1, [B

    :goto_58
    const/4 v3, 0x0

    .line 15
    invoke-virtual {p0, v0, v3, p1}, Ljava/io/InputStream;->read([BII)I

    move-result v4

    const/4 v5, -0x1

    if-eq v4, v5, :cond_64

    .line 16
    invoke-virtual {v2, v0, v3, v4}, Ljava/io/OutputStream;->write([BII)V
    :try_end_63
    .catch Ljava/io/IOException; {:try_start_56 .. :try_end_63} :catch_6a
    .catchall {:try_start_56 .. :try_end_63} :catchall_68

    goto :goto_58

    .line 17
    :cond_64
    invoke-static {v2}, Lf1/h;->b(Ljava/io/OutputStream;)V

    goto :goto_76

    :catchall_68
    move-exception p0

    goto :goto_78

    :catch_6a
    move-object p1, v2

    goto :goto_6e

    :catchall_6c
    move-exception p0

    goto :goto_77

    :catch_6e
    :goto_6e
    :try_start_6e
    const-string p0, " IOException"

    .line 18
    invoke-static {v1, p0}, La0/u;->i(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_73
    .catchall {:try_start_6e .. :try_end_73} :catchall_6c

    .line 19
    invoke-static {p1}, Lf1/h;->b(Ljava/io/OutputStream;)V

    :goto_76
    return-void

    :goto_77
    move-object v2, p1

    :goto_78
    invoke-static {v2}, Lf1/h;->b(Ljava/io/OutputStream;)V

    .line 20
    throw p0
.end method

.method public static d(Landroid/content/Context;Ljava/lang/String;)[B
    .registers 5

    const/4 v0, 0x0

    const-string v1, "BksUtil"

    if-eqz p0, :cond_51

    .line 1
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_c

    goto :goto_51

    .line 2
    :cond_c
    :try_start_c
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    if-eqz p0, :cond_4e

    const/16 v2, 0x40

    .line 3
    invoke-virtual {p0, p1, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    if-eqz p0, :cond_4e

    .line 4
    iget-object p0, p0, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    aget-object p0, p0, v0

    .line 5
    invoke-virtual {p0}, Landroid/content/pm/Signature;->toByteArray()[B

    move-result-object p0
    :try_end_22
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_c .. :try_end_22} :catch_39
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_22} :catch_23

    return-object p0

    :catch_23
    move-exception p0

    const-string p1, "get pm exception : "

    .line 6
    invoke-static {p1}, Landroid/support/v4/media/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_4e

    :catch_39
    move-exception p0

    const-string p1, "PackageManager.NameNotFoundException : "

    .line 7
    invoke-static {p1}, Landroid/support/v4/media/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p0}, Landroid/content/pm/PackageManager$NameNotFoundException;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_4e
    :goto_4e
    new-array p0, v0, [B

    return-object p0

    :cond_51
    :goto_51
    const-string p0, "packageName is null or context is null"

    .line 8
    invoke-static {v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    new-array p0, v0, [B

    return-object p0
.end method

.method public static e([B)Ljava/lang/String;
    .registers 3

    const-string v0, ""

    if-nez p0, :cond_5

    return-object v0

    :cond_5
    :try_start_5
    const-string v1, "SHA-256"

    .line 1
    invoke-static {v1}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v1

    .line 2
    invoke-virtual {v1, p0}, Ljava/security/MessageDigest;->update([B)V

    .line 3
    invoke-virtual {v1}, Ljava/security/MessageDigest;->digest()[B

    move-result-object p0

    invoke-static {p0}, Lac/a;->b([B)Ljava/lang/String;

    move-result-object p0
    :try_end_16
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_5 .. :try_end_16} :catch_17

    return-object p0

    :catch_17
    const-string p0, "BksUtil"

    const-string v1, "inputstraem exception"

    .line 4
    invoke-static {p0, v1}, La0/u;->i(Ljava/lang/String;Ljava/lang/String;)V

    return-object v0
.end method

.method public static f(Ljava/lang/String;)Z
    .registers 11

    .line 1
    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_8

    return v1

    .line 2
    :cond_8
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "hms version code is : "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, "BksUtil"

    invoke-static {v2, v0}, La0/u;->m(Ljava/lang/String;Ljava/lang/String;)V

    const-string v0, "\\."

    .line 3
    invoke-virtual {p0, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    const-string v3, "4.0.2.300"

    .line 4
    invoke-virtual {v3, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    .line 5
    array-length v3, p0

    .line 6
    array-length v4, v0

    .line 7
    invoke-static {v3, v4}, Ljava/lang/Math;->max(II)I

    move-result v5

    const/4 v6, 0x0

    :goto_31
    const/4 v7, 0x1

    if-ge v6, v5, :cond_6b

    if-ge v6, v3, :cond_3f

    .line 8
    :try_start_36
    aget-object v8, p0, v6

    invoke-static {v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v8

    goto :goto_40

    :catch_3d
    move-exception p0

    goto :goto_49

    :cond_3f
    const/4 v8, 0x0

    :goto_40
    if-ge v6, v4, :cond_61

    .line 9
    aget-object v9, v0, v6

    invoke-static {v9}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v9
    :try_end_48
    .catch Ljava/lang/Exception; {:try_start_36 .. :try_end_48} :catch_3d

    goto :goto_62

    :goto_49
    const-string v0, " exception : "

    .line 10
    invoke-static {v0}, Landroid/support/v4/media/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v2, p0}, La0/u;->i(Ljava/lang/String;Ljava/lang/String;)V

    if-lt v6, v4, :cond_60

    const/4 v1, 0x1

    :cond_60
    return v1

    :cond_61
    const/4 v9, 0x0

    :goto_62
    if-ge v8, v9, :cond_65

    return v1

    :cond_65
    if-le v8, v9, :cond_68

    return v7

    :cond_68
    add-int/lit8 v6, v6, 0x1

    goto :goto_31

    :cond_6b
    return v7
.end method

.method public static g([B)Ljava/lang/String;
    .registers 3

    const-string v0, ""

    if-eqz p0, :cond_2e

    .line 1
    array-length v1, p0

    if-nez v1, :cond_8

    goto :goto_2e

    :cond_8
    :try_start_8
    const-string v1, "SHA-256"

    .line 2
    invoke-static {v1}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v1

    .line 3
    invoke-virtual {v1, p0}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object p0

    .line 4
    invoke-static {p0}, Lac/a;->b([B)Ljava/lang/String;

    move-result-object v0
    :try_end_16
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_8 .. :try_end_16} :catch_17

    goto :goto_2e

    :catch_17
    move-exception p0

    const-string v1, "NoSuchAlgorithmException"

    .line 5
    invoke-static {v1}, Landroid/support/v4/media/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p0}, Ljava/security/NoSuchAlgorithmException;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string v1, "BksUtil"

    invoke-static {v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2e
    :goto_2e
    return-object v0
.end method

.method public static h(Landroid/content/Context;)Z
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0}, Lac/a;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object p0, Ljava/io/File;->separator:Ljava/lang/String;

    const-string v1, "hmsrootcas.bks"

    invoke-static {v0, p0, v1}, Lcom/huawei/hms/adapter/a;->a(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    .line 2
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 3
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result p0

    return p0
.end method

.method public static declared-synchronized i(Landroid/content/Context;)Ljava/io/InputStream;
    .registers 11

    const-class v0, Lac/a;

    monitor-enter v0

    :try_start_3
    const-string v1, "BksUtil"

    const-string v2, "get bks from tss begin"

    .line 1
    invoke-static {v1, v2}, La0/u;->m(Ljava/lang/String;Ljava/lang/String;)V

    if-eqz p0, :cond_f

    .line 2
    invoke-static {p0}, Lp/h;->e(Landroid/content/Context;)V

    .line 3
    :cond_f
    sget-object p0, Lp/h;->b:Landroid/content/Context;

    const/4 v1, 0x0

    if-nez p0, :cond_1d

    const-string p0, "BksUtil"

    const-string v2, "context is null"

    .line 4
    invoke-static {p0, v2}, La0/u;->i(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1b
    .catchall {:try_start_3 .. :try_end_1b} :catchall_158

    monitor-exit v0

    return-object v1

    :cond_1d
    :try_start_1d
    const-string v2, "com.huawei.hwid"

    .line 5
    invoke-static {v2}, Lac/c;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lac/a;->f(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_53

    const-string v2, "com.huawei.hms"

    invoke-static {v2}, Lac/c;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lac/a;->f(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_53

    .line 6
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "hms version code is too low : "

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "com.huawei.hwid"

    invoke-static {v2}, Lac/c;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string v2, "BksUtil"

    invoke-static {v2, p0}, La0/u;->i(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_51
    .catchall {:try_start_1d .. :try_end_51} :catchall_158

    monitor-exit v0

    return-object v1

    :cond_53
    :try_start_53
    const-string v2, "com.huawei.hwid"

    .line 7
    invoke-static {p0, v2}, Lac/a;->d(Landroid/content/Context;Ljava/lang/String;)[B

    move-result-object v2

    .line 8
    sget-object v3, Lac/a;->b:[Ljava/lang/String;

    array-length v4, v3

    const/4 v5, 0x0

    const/4 v6, 0x0

    :goto_5e
    if-ge v6, v4, :cond_71

    aget-object v7, v3, v6

    .line 9
    invoke-static {v2}, Lac/a;->g([B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_6e

    const/4 v2, 0x1

    goto :goto_72

    :cond_6e
    add-int/lit8 v6, v6, 0x1

    goto :goto_5e

    :cond_71
    const/4 v2, 0x0

    :goto_72
    if-nez v2, :cond_8f

    const-string v2, "com.huawei.hms"

    .line 10
    invoke-static {p0, v2}, Lac/a;->d(Landroid/content/Context;Ljava/lang/String;)[B

    move-result-object v2

    .line 11
    invoke-static {v2}, Lac/a;->g([B)Ljava/lang/String;

    move-result-object v2

    const-string v3, "E49D5C2C0E11B3B1B96CA56C6DE2A14EC7DAB5CCC3B5F300D03E5B4DBA44F539"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_8f

    const-string p0, "BksUtil"

    const-string v2, "hms sign error"

    .line 12
    invoke-static {p0, v2}, La0/u;->i(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_8d
    .catchall {:try_start_53 .. :try_end_8d} :catchall_158

    monitor-exit v0

    return-object v1

    .line 13
    :cond_8f
    :try_start_8f
    new-instance v2, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v2}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_94
    .catchall {:try_start_8f .. :try_end_94} :catchall_158

    .line 14
    :try_start_94
    sget-object v3, Lac/a;->a:Landroid/net/Uri;

    const-string v4, "files/hmsrootcas.bks"

    invoke-static {v3, v4}, Landroid/net/Uri;->withAppendedPath(Landroid/net/Uri;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    .line 15
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v4

    invoke-virtual {v4, v3}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v3
    :try_end_a4
    .catch Ljava/lang/Exception; {:try_start_94 .. :try_end_a4} :catch_11c
    .catchall {:try_start_94 .. :try_end_a4} :catchall_119

    const/16 v4, 0x400

    :try_start_a6
    new-array v4, v4, [B

    .line 16
    :goto_a8
    invoke-virtual {v3, v4}, Ljava/io/InputStream;->read([B)I

    move-result v6

    const/4 v7, -0x1

    if-le v6, v7, :cond_b3

    .line 17
    invoke-virtual {v2, v4, v5, v6}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_a8

    .line 18
    :cond_b3
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->flush()V

    .line 19
    new-instance v4, Ljava/io/ByteArrayInputStream;

    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v5

    invoke-direct {v4, v5}, Ljava/io/ByteArrayInputStream;-><init>([B)V
    :try_end_bf
    .catch Ljava/lang/Exception; {:try_start_a6 .. :try_end_bf} :catch_114
    .catchall {:try_start_a6 .. :try_end_bf} :catchall_111

    :try_start_bf
    const-string v1, "bks_hash"

    const-string v5, ""

    .line 20
    invoke-static {p0}, Lac/d;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v6

    invoke-interface {v6, v1, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 21
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v5

    invoke-static {v5}, Lac/a;->e([B)Ljava/lang/String;

    move-result-object v5

    .line 22
    invoke-static {p0}, Lac/a;->h(Landroid/content/Context;)Z

    move-result v6

    if-eqz v6, :cond_e8

    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_e0

    goto :goto_e8

    :cond_e0
    const-string v1, "BksUtil"

    const-string v5, "bks not update"

    .line 23
    invoke-static {v1, v5}, La0/u;->m(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_103

    :cond_e8
    :goto_e8
    const-string v1, "BksUtil"

    const-string v6, "update bks and sp"

    .line 24
    invoke-static {v1, v6}, La0/u;->m(Ljava/lang/String;Ljava/lang/String;)V

    .line 25
    invoke-static {v4, p0}, Lac/a;->c(Ljava/io/InputStream;Landroid/content/Context;)V

    const-string v1, "bks_hash"

    .line 26
    invoke-static {p0}, Lac/d;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v6

    invoke-interface {v6}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v6

    invoke-interface {v6, v1, v5}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_103
    .catch Ljava/lang/Exception; {:try_start_bf .. :try_end_103} :catch_10f
    .catchall {:try_start_bf .. :try_end_103} :catchall_10d

    .line 27
    :goto_103
    :try_start_103
    invoke-static {v3}, Lf1/h;->a(Ljava/io/InputStream;)V

    .line 28
    invoke-static {v2}, Lf1/h;->b(Ljava/io/OutputStream;)V

    .line 29
    invoke-static {v4}, Lf1/h;->a(Ljava/io/InputStream;)V

    goto :goto_143

    :catchall_10d
    move-exception p0

    goto :goto_14e

    :catch_10f
    move-exception v1

    goto :goto_120

    :catchall_111
    move-exception p0

    move-object v4, v1

    goto :goto_14a

    :catch_114
    move-exception v4

    move-object v9, v4

    move-object v4, v1

    move-object v1, v9

    goto :goto_120

    :catchall_119
    move-exception p0

    move-object v3, v1

    goto :goto_14d

    :catch_11c
    move-exception v3

    move-object v4, v1

    move-object v1, v3

    move-object v3, v4

    :goto_120
    const-string v5, "BksUtil"
    :try_end_122
    .catchall {:try_start_103 .. :try_end_122} :catchall_158

    .line 30
    :try_start_122
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "Get bks from HMS_VERSION_CODE exception : No content provider"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v5, v1}, La0/u;->i(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_13a
    .catchall {:try_start_122 .. :try_end_13a} :catchall_149

    .line 31
    :try_start_13a
    invoke-static {v3}, Lf1/h;->a(Ljava/io/InputStream;)V

    .line 32
    invoke-static {v2}, Lf1/h;->b(Ljava/io/OutputStream;)V

    .line 33
    invoke-static {v4}, Lf1/h;->a(Ljava/io/InputStream;)V

    .line 34
    :goto_143
    invoke-static {p0}, Lac/a;->j(Landroid/content/Context;)Ljava/io/InputStream;

    move-result-object p0
    :try_end_147
    .catchall {:try_start_13a .. :try_end_147} :catchall_158

    monitor-exit v0

    return-object p0

    :catchall_149
    move-exception p0

    :goto_14a
    move-object v1, v3

    move-object v3, v1

    move-object v1, v4

    :goto_14d
    move-object v4, v1

    .line 35
    :goto_14e
    :try_start_14e
    invoke-static {v3}, Lf1/h;->a(Ljava/io/InputStream;)V

    .line 36
    invoke-static {v2}, Lf1/h;->b(Ljava/io/OutputStream;)V

    .line 37
    invoke-static {v4}, Lf1/h;->a(Ljava/io/InputStream;)V

    .line 38
    throw p0
    :try_end_158
    .catchall {:try_start_14e .. :try_end_158} :catchall_158

    :catchall_158
    move-exception p0

    monitor-exit v0

    throw p0
.end method

.method public static j(Landroid/content/Context;)Ljava/io/InputStream;
    .registers 4

    .line 1
    invoke-static {p0}, Lac/a;->h(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_32

    const-string v0, "BksUtil"

    const-string v1, "getFilesBksIS "

    .line 2
    invoke-static {v0, v1}, La0/u;->m(Ljava/lang/String;Ljava/lang/String;)V

    .line 3
    :try_start_d
    new-instance v1, Ljava/io/FileInputStream;

    .line 4
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0}, Lac/a;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object p0, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "hmsrootcas.bks"

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    .line 5
    invoke-direct {v1, p0}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V
    :try_end_2c
    .catch Ljava/io/FileNotFoundException; {:try_start_d .. :try_end_2c} :catch_2d

    return-object v1

    :catch_2d
    const-string p0, "FileNotFoundExceptio: "

    .line 6
    invoke-static {v0, p0}, La0/u;->i(Ljava/lang/String;Ljava/lang/String;)V

    :cond_32
    const/4 p0, 0x0

    return-object p0
.end method
