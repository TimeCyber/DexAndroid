.class public final La2/a;
.super Ljava/lang/Object;
.source "CharSequenceCharacterIterator.kt"

# interfaces
.implements Ljava/text/CharacterIterator;


# instance fields
.field public final a:Ljava/lang/CharSequence;

.field public final b:I

.field public final c:I

.field public d:I


# direct methods
.method public constructor <init>(Ljava/lang/CharSequence;II)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, La2/a;->a:Ljava/lang/CharSequence;

    .line 3
    iput p2, p0, La2/a;->b:I

    .line 4
    iput p3, p0, La2/a;->c:I

    .line 5
    iput p2, p0, La2/a;->d:I

    return-void
.end method


# virtual methods
.method public clone()Ljava/lang/Object;
    .registers 3

    .line 1
    :try_start_0
    invoke-super {p0}, Ljava/text/CharacterIterator;->clone()Ljava/lang/Object;

    move-result-object v0

    const-string v1, "{\n            @Suppress(\u2026  super.clone()\n        }"

    .line 2
    invoke-static {v0, v1}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V
    :try_end_9
    .catch Ljava/lang/CloneNotSupportedException; {:try_start_0 .. :try_end_9} :catch_a

    return-object v0

    .line 3
    :catch_a
    new-instance v0, Ljava/lang/InternalError;

    invoke-direct {v0}, Ljava/lang/InternalError;-><init>()V

    throw v0
.end method

.method public current()C
    .registers 3

    .line 1
    iget v0, p0, La2/a;->d:I

    iget v1, p0, La2/a;->c:I

    if-ne v0, v1, :cond_a

    const v0, 0xffff

    goto :goto_10

    :cond_a
    iget-object v1, p0, La2/a;->a:Ljava/lang/CharSequence;

    invoke-interface {v1, v0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    :goto_10
    return v0
.end method

.method public first()C
    .registers 2

    .line 1
    iget v0, p0, La2/a;->b:I

    iput v0, p0, La2/a;->d:I

    .line 2
    invoke-virtual {p0}, La2/a;->current()C

    move-result v0

    return v0
.end method

.method public getBeginIndex()I
    .registers 2

    .line 1
    iget v0, p0, La2/a;->b:I

    return v0
.end method

.method public getEndIndex()I
    .registers 2

    .line 1
    iget v0, p0, La2/a;->c:I

    return v0
.end method

.method public getIndex()I
    .registers 2

    .line 1
    iget v0, p0, La2/a;->d:I

    return v0
.end method

.method public last()C
    .registers 3

    .line 1
    iget v0, p0, La2/a;->b:I

    iget v1, p0, La2/a;->c:I

    if-ne v0, v1, :cond_c

    .line 2
    iput v1, p0, La2/a;->d:I

    const v0, 0xffff

    goto :goto_16

    :cond_c
    add-int/lit8 v1, v1, -0x1

    .line 3
    iput v1, p0, La2/a;->d:I

    .line 4
    iget-object v0, p0, La2/a;->a:Ljava/lang/CharSequence;

    invoke-interface {v0, v1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    :goto_16
    return v0
.end method

.method public next()C
    .registers 3

    .line 1
    iget v0, p0, La2/a;->d:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La2/a;->d:I

    .line 2
    iget v1, p0, La2/a;->c:I

    if-lt v0, v1, :cond_10

    .line 3
    iput v1, p0, La2/a;->d:I

    const v0, 0xffff

    goto :goto_16

    .line 4
    :cond_10
    iget-object v1, p0, La2/a;->a:Ljava/lang/CharSequence;

    invoke-interface {v1, v0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    :goto_16
    return v0
.end method

.method public previous()C
    .registers 3

    .line 1
    iget v0, p0, La2/a;->d:I

    iget v1, p0, La2/a;->b:I

    if-gt v0, v1, :cond_a

    const v0, 0xffff

    goto :goto_14

    :cond_a
    add-int/lit8 v0, v0, -0x1

    .line 2
    iput v0, p0, La2/a;->d:I

    .line 3
    iget-object v1, p0, La2/a;->a:Ljava/lang/CharSequence;

    invoke-interface {v1, v0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    :goto_14
    return v0
.end method

.method public setIndex(I)C
    .registers 5

    .line 1
    iget v0, p0, La2/a;->b:I

    iget v1, p0, La2/a;->c:I

    const/4 v2, 0x0

    if-gt p1, v1, :cond_a

    if-gt v0, p1, :cond_a

    const/4 v2, 0x1

    :cond_a
    if-eqz v2, :cond_13

    .line 2
    iput p1, p0, La2/a;->d:I

    .line 3
    invoke-virtual {p0}, La2/a;->current()C

    move-result p1

    return p1

    .line 4
    :cond_13
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "invalid position"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
