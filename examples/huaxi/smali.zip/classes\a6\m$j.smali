.class public La6/m$j;
.super Ljava/lang/Object;
.source "LottieDrawable.java"

# interfaces
.implements La6/m$o;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La6/m;->u(F)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:F

.field public final synthetic b:La6/m;


# direct methods
.method public constructor <init>(La6/m;F)V
    .registers 3

    .line 1
    iput-object p1, p0, La6/m$j;->b:La6/m;

    iput p2, p0, La6/m$j;->a:F

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(La6/g;)V
    .registers 3

    .line 1
    iget-object p1, p0, La6/m$j;->b:La6/m;

    iget v0, p0, La6/m$j;->a:F

    invoke-virtual {p1, v0}, La6/m;->u(F)V

    return-void
.end method
