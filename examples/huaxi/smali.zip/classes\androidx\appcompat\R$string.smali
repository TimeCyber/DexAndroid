.class public final Landroidx/appcompat/R$string;
.super Ljava/lang/Object;


# static fields
.field public static final abc_action_bar_home_description:I = 0x7f10002e

.field public static final abc_action_bar_up_description:I = 0x7f10002f

.field public static final abc_action_menu_overflow_description:I = 0x7f100030

.field public static final abc_action_mode_done:I = 0x7f100031

.field public static final abc_activity_chooser_view_see_all:I = 0x7f100032

.field public static final abc_activitychooserview_choose_application:I = 0x7f100033

.field public static final abc_capital_off:I = 0x7f100034

.field public static final abc_capital_on:I = 0x7f100035

.field public static final abc_menu_alt_shortcut_label:I = 0x7f100036

.field public static final abc_menu_ctrl_shortcut_label:I = 0x7f100037

.field public static final abc_menu_delete_shortcut_label:I = 0x7f100038

.field public static final abc_menu_enter_shortcut_label:I = 0x7f100039

.field public static final abc_menu_function_shortcut_label:I = 0x7f10003a

.field public static final abc_menu_meta_shortcut_label:I = 0x7f10003b

.field public static final abc_menu_shift_shortcut_label:I = 0x7f10003c

.field public static final abc_menu_space_shortcut_label:I = 0x7f10003d

.field public static final abc_menu_sym_shortcut_label:I = 0x7f10003e

.field public static final abc_prepend_shortcut_label:I = 0x7f10003f

.field public static final abc_search_hint:I = 0x7f100040

.field public static final abc_searchview_description_clear:I = 0x7f100041

.field public static final abc_searchview_description_query:I = 0x7f100042

.field public static final abc_searchview_description_search:I = 0x7f100043

.field public static final abc_searchview_description_submit:I = 0x7f100044

.field public static final abc_searchview_description_voice:I = 0x7f100045

.field public static final abc_shareactionprovider_share_with:I = 0x7f100046

.field public static final abc_shareactionprovider_share_with_application:I = 0x7f100047

.field public static final abc_toolbar_collapse_description:I = 0x7f100048

.field public static final search_menu_title:I = 0x7f100161


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
