.class public final La8/a$c;
.super Ljava/lang/Object;
.source "FactoryPools.java"

# interfaces
.implements Lk3/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La8/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lk3/d<",
        "TT;>;"
    }
.end annotation


# instance fields
.field public final a:La8/a$b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La8/a$b<",
            "TT;>;"
        }
    .end annotation
.end field

.field public final b:La8/a$e;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La8/a$e<",
            "TT;>;"
        }
    .end annotation
.end field

.field public final c:Lk3/d;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lk3/d<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lk3/d;La8/a$b;La8/a$e;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lk3/d<",
            "TT;>;",
            "La8/a$b<",
            "TT;>;",
            "La8/a$e<",
            "TT;>;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, La8/a$c;->c:Lk3/d;

    .line 3
    iput-object p2, p0, La8/a$c;->a:La8/a$b;

    .line 4
    iput-object p3, p0, La8/a$c;->b:La8/a$e;

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;)Z
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)Z"
        }
    .end annotation

    .line 1
    instance-of v0, p1, La8/a$d;

    if-eqz v0, :cond_10

    .line 2
    move-object v0, p1

    check-cast v0, La8/a$d;

    invoke-interface {v0}, La8/a$d;->a()La8/d;

    move-result-object v0

    const/4 v1, 0x1

    check-cast v0, La8/d$b;

    .line 3
    iput-boolean v1, v0, La8/d$b;->a:Z

    .line 4
    :cond_10
    iget-object v0, p0, La8/a$c;->b:La8/a$e;

    invoke-interface {v0, p1}, La8/a$e;->a(Ljava/lang/Object;)V

    .line 5
    iget-object v0, p0, La8/a$c;->c:Lk3/d;

    invoke-interface {v0, p1}, Lk3/d;->a(Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public b()Ljava/lang/Object;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La8/a$c;->c:Lk3/d;

    invoke-interface {v0}, Lk3/d;->b()Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_2b

    .line 2
    iget-object v0, p0, La8/a$c;->a:La8/a$b;

    invoke-interface {v0}, La8/a$b;->create()Ljava/lang/Object;

    move-result-object v0

    const/4 v1, 0x2

    const-string v2, "FactoryPools"

    .line 3
    invoke-static {v2, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v1

    if-eqz v1, :cond_2b

    const-string v1, "Created new "

    .line 4
    invoke-static {v1}, Landroid/support/v4/media/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 5
    :cond_2b
    instance-of v1, v0, La8/a$d;

    if-eqz v1, :cond_3b

    .line 6
    move-object v1, v0

    check-cast v1, La8/a$d;

    invoke-interface {v1}, La8/a$d;->a()La8/d;

    move-result-object v1

    const/4 v2, 0x0

    check-cast v1, La8/d$b;

    .line 7
    iput-boolean v2, v1, La8/d$b;->a:Z

    :cond_3b
    return-object v0
.end method
