.class public La7/p;
.super Ljava/lang/Object;
.source "NotificationUtils.java"


# static fields
.field public static final b:La7/p;


# instance fields
.field public a:Landroid/app/NotificationChannel;


# direct methods
.method public static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, La7/p;

    .line 2
    invoke-static {}, Lcom/blankj/utilcode/util/l;->a()Landroid/app/Application;

    move-result-object v1

    invoke-virtual {v1}, Landroid/app/Application;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-static {}, Lcom/blankj/utilcode/util/l;->a()Landroid/app/Application;

    move-result-object v2

    invoke-virtual {v2}, Landroid/app/Application;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x3

    invoke-direct {v0, v1, v2, v3}, La7/p;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    sput-object v0, La7/p;->b:La7/p;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    if-lt v0, v1, :cond_10

    .line 3
    new-instance v0, Landroid/app/NotificationChannel;

    invoke-direct {v0, p1, p2, p3}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    iput-object v0, p0, La7/p;->a:Landroid/app/NotificationChannel;

    :cond_10
    return-void
.end method
