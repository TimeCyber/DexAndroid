.class public final synthetic Landroidx/activity/result/d;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"


# direct methods
.method public static synthetic a(I)Z
    .registers 4

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-ne p0, v0, :cond_5

    return v1

    :cond_5
    const/4 v2, 0x2

    if-ne p0, v2, :cond_9

    return v1

    :cond_9
    const/4 v2, 0x3

    if-ne p0, v2, :cond_d

    return v1

    :cond_d
    const/4 v2, 0x4

    if-ne p0, v2, :cond_11

    return v1

    :cond_11
    const/4 v2, 0x5

    if-ne p0, v2, :cond_15

    return v1

    :cond_15
    const/4 v2, 0x6

    if-ne p0, v2, :cond_19

    return v1

    :cond_19
    const/4 v2, 0x7

    if-ne p0, v2, :cond_1d

    return v1

    :cond_1d
    const/16 v2, 0x8

    if-ne p0, v2, :cond_22

    return v1

    :cond_22
    const/16 v2, 0x9

    if-ne p0, v2, :cond_27

    return v1

    :cond_27
    const/16 v2, 0xa

    if-ne p0, v2, :cond_2c

    return v1

    :cond_2c
    const/16 v2, 0xb

    if-ne p0, v2, :cond_31

    return v1

    :cond_31
    const/16 v2, 0xc

    if-ne p0, v2, :cond_36

    return v1

    :cond_36
    const/16 v2, 0xd

    if-ne p0, v2, :cond_3b

    return v1

    :cond_3b
    const/16 v2, 0xe

    if-ne p0, v2, :cond_40

    return v1

    :cond_40
    const/16 v2, 0xf

    if-ne p0, v2, :cond_45

    return v1

    :cond_45
    const/16 v2, 0x10

    if-ne p0, v2, :cond_4a

    return v1

    :cond_4a
    const/16 v2, 0x11

    if-ne p0, v2, :cond_4f

    return v1

    :cond_4f
    const/16 v2, 0x12

    if-ne p0, v2, :cond_54

    return v0

    :cond_54
    const/16 v2, 0x13

    if-ne p0, v2, :cond_59

    return v0

    :cond_59
    const/16 v2, 0x14

    if-ne p0, v2, :cond_5e

    return v0

    :cond_5e
    const/16 v2, 0x15

    if-ne p0, v2, :cond_63

    return v0

    :cond_63
    const/16 v2, 0x16

    if-ne p0, v2, :cond_68

    return v0

    :cond_68
    const/16 v2, 0x17

    if-ne p0, v2, :cond_6d

    return v0

    :cond_6d
    const/16 v2, 0x18

    if-ne p0, v2, :cond_72

    return v0

    :cond_72
    const/16 v2, 0x19

    if-ne p0, v2, :cond_77

    return v0

    :cond_77
    const/16 v2, 0x1a

    if-ne p0, v2, :cond_7c

    return v1

    :cond_7c
    const/16 v2, 0x1b

    if-ne p0, v2, :cond_81

    return v1

    :cond_81
    const/16 v2, 0x1c

    if-ne p0, v2, :cond_86

    return v1

    :cond_86
    const/16 v2, 0x1d

    if-ne p0, v2, :cond_8b

    return v1

    :cond_8b
    const/16 v2, 0x1e

    if-ne p0, v2, :cond_90

    return v1

    :cond_90
    const/16 v2, 0x1f

    if-ne p0, v2, :cond_95

    return v1

    :cond_95
    const/16 v2, 0x20

    if-ne p0, v2, :cond_9a

    return v1

    :cond_9a
    const/16 v2, 0x21

    if-ne p0, v2, :cond_9f

    return v1

    :cond_9f
    const/16 v2, 0x22

    if-ne p0, v2, :cond_a4

    return v1

    :cond_a4
    const/16 v2, 0x23

    if-ne p0, v2, :cond_a9

    return v1

    :cond_a9
    const/16 v2, 0x24

    if-ne p0, v2, :cond_ae

    return v1

    :cond_ae
    const/16 v2, 0x25

    if-ne p0, v2, :cond_b3

    return v1

    :cond_b3
    const/16 v2, 0x26

    if-ne p0, v2, :cond_b8

    return v1

    :cond_b8
    const/16 v2, 0x27

    if-ne p0, v2, :cond_bd

    return v1

    :cond_bd
    const/16 v2, 0x28

    if-ne p0, v2, :cond_c2

    return v1

    :cond_c2
    const/16 v2, 0x29

    if-ne p0, v2, :cond_c7

    return v1

    :cond_c7
    const/16 v2, 0x2a

    if-ne p0, v2, :cond_cc

    return v1

    :cond_cc
    const/16 v2, 0x2b

    if-ne p0, v2, :cond_d1

    return v1

    :cond_d1
    const/16 v1, 0x2c

    if-ne p0, v1, :cond_d6

    return v0

    :cond_d6
    const/16 v1, 0x2d

    if-ne p0, v1, :cond_db

    return v0

    :cond_db
    const/16 v1, 0x2e

    if-ne p0, v1, :cond_e0

    return v0

    :cond_e0
    const/16 v1, 0x2f

    if-ne p0, v1, :cond_e5

    return v0

    :cond_e5
    const/16 v1, 0x30

    if-ne p0, v1, :cond_ea

    return v0

    :cond_ea
    const/4 p0, 0x0

    throw p0
.end method

.method public static b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    return-object v0
.end method
