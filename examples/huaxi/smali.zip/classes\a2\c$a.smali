.class public final La2/c$a;
.super Lwg/j;
.source "LayoutIntrinsics.kt"

# interfaces
.implements Lvg/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La2/c;-><init>(Ljava/lang/CharSequence;Landroid/text/TextPaint;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lwg/j;",
        "Lvg/a<",
        "Landroid/text/BoringLayout$Metrics;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/CharSequence;

.field public final synthetic c:Landroid/text/TextPaint;


# direct methods
.method public constructor <init>(ILjava/lang/CharSequence;Landroid/text/TextPaint;)V
    .registers 4

    iput p1, p0, La2/c$a;->a:I

    iput-object p2, p0, La2/c$a;->b:Ljava/lang/CharSequence;

    iput-object p3, p0, La2/c$a;->c:Landroid/text/TextPaint;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lwg/j;-><init>(I)V

    return-void
.end method


# virtual methods
.method public invoke()Ljava/lang/Object;
    .registers 6

    .line 1
    iget v0, p0, La2/c$a;->a:I

    invoke-static {v0}, La2/o;->a(I)Landroid/text/TextDirectionHeuristic;

    move-result-object v0

    .line 2
    iget-object v1, p0, La2/c$a;->b:Ljava/lang/CharSequence;

    iget-object v2, p0, La2/c$a;->c:Landroid/text/TextPaint;

    const-string v3, "text"

    .line 3
    invoke-static {v1, v3}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v3

    const/4 v4, 0x0

    invoke-interface {v0, v1, v4, v3}, Landroid/text/TextDirectionHeuristic;->isRtl(Ljava/lang/CharSequence;II)Z

    move-result v0

    const/4 v3, 0x0

    if-nez v0, :cond_1f

    .line 5
    invoke-static {v1, v2, v3}, Landroid/text/BoringLayout;->isBoring(Ljava/lang/CharSequence;Landroid/text/TextPaint;Landroid/text/BoringLayout$Metrics;)Landroid/text/BoringLayout$Metrics;

    move-result-object v3

    :cond_1f
    return-object v3
.end method
