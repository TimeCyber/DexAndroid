.class public final La0/t0;
.super Ljava/lang/Object;
.source "AnimationSpec.kt"

# interfaces
.implements La0/v;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "La0/v<",
        "TT;>;"
    }
.end annotation


# instance fields
.field public final a:I

.field public final b:I

.field public final c:La0/w;


# direct methods
.method public constructor <init>()V
    .registers 4

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p0, v0, v0, v1, v2}, La0/t0;-><init>(IILa0/w;I)V

    return-void
.end method

.method public constructor <init>(IILa0/w;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput p1, p0, La0/t0;->a:I

    .line 3
    iput p2, p0, La0/t0;->b:I

    .line 4
    iput-object p3, p0, La0/t0;->c:La0/w;

    return-void
.end method

.method public constructor <init>(IILa0/w;I)V
    .registers 6

    and-int/lit8 v0, p4, 0x1

    if-eqz v0, :cond_6

    const/16 p1, 0x12c

    :cond_6
    and-int/lit8 v0, p4, 0x2

    if-eqz v0, :cond_b

    const/4 p2, 0x0

    :cond_b
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_11

    .line 5
    sget-object p3, La0/x;->a:La0/w;

    :cond_11
    const-string p4, "easing"

    .line 6
    invoke-static {p3, p4}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    iput p1, p0, La0/t0;->a:I

    .line 9
    iput p2, p0, La0/t0;->b:I

    .line 10
    iput-object p3, p0, La0/t0;->c:La0/w;

    return-void
.end method


# virtual methods
.method public a(La0/u0;)La0/d1;
    .registers 5

    .line 2
    new-instance p1, La0/j1;

    iget v0, p0, La0/t0;->a:I

    iget v1, p0, La0/t0;->b:I

    iget-object v2, p0, La0/t0;->c:La0/w;

    invoke-direct {p1, v0, v1, v2}, La0/j1;-><init>(IILa0/w;)V

    return-object p1
.end method

.method public a(La0/u0;)La0/y0;
    .registers 5

    .line 1
    new-instance p1, La0/j1;

    iget v0, p0, La0/t0;->a:I

    iget v1, p0, La0/t0;->b:I

    iget-object v2, p0, La0/t0;->c:La0/w;

    invoke-direct {p1, v0, v1, v2}, La0/j1;-><init>(IILa0/w;)V

    return-object p1
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 5

    .line 1
    instance-of v0, p1, La0/t0;

    const/4 v1, 0x0

    if-eqz v0, :cond_1e

    .line 2
    check-cast p1, La0/t0;

    iget v0, p1, La0/t0;->a:I

    iget v2, p0, La0/t0;->a:I

    if-ne v0, v2, :cond_1e

    .line 3
    iget v0, p1, La0/t0;->b:I

    iget v2, p0, La0/t0;->b:I

    if-ne v0, v2, :cond_1e

    .line 4
    iget-object p1, p1, La0/t0;->c:La0/w;

    iget-object v0, p0, La0/t0;->c:La0/w;

    invoke-static {p1, v0}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1e

    const/4 v1, 0x1

    :cond_1e
    return v1
.end method

.method public hashCode()I
    .registers 3

    .line 1
    iget v0, p0, La0/t0;->a:I

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, La0/t0;->c:La0/w;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x1f

    iget v0, p0, La0/t0;->b:I

    add-int/2addr v1, v0

    return v1
.end method
