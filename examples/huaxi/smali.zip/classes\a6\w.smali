.class public final enum La6/w;
.super Ljava/lang/Enum;
.source "RenderMode.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "La6/w;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum a:La6/w;

.field public static final enum b:La6/w;

.field public static final synthetic c:[La6/w;


# direct methods
.method public static constructor <clinit>()V
    .registers 7

    .line 1
    new-instance v0, La6/w;

    const-string v1, "AUTOMATIC"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, La6/w;-><init>(Ljava/lang/String;I)V

    sput-object v0, La6/w;->a:La6/w;

    .line 2
    new-instance v1, La6/w;

    const-string v3, "HARDWARE"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4}, La6/w;-><init>(Ljava/lang/String;I)V

    sput-object v1, La6/w;->b:La6/w;

    .line 3
    new-instance v3, La6/w;

    const-string v5, "SOFTWARE"

    const/4 v6, 0x2

    invoke-direct {v3, v5, v6}, La6/w;-><init>(Ljava/lang/String;I)V

    const/4 v5, 0x3

    new-array v5, v5, [La6/w;

    aput-object v0, v5, v2

    aput-object v1, v5, v4

    aput-object v3, v5, v6

    .line 4
    sput-object v5, La6/w;->c:[La6/w;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)La6/w;
    .registers 2

    .line 1
    const-class v0, La6/w;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, La6/w;

    return-object p0
.end method

.method public static values()[La6/w;
    .registers 1

    .line 1
    sget-object v0, La6/w;->c:[La6/w;

    invoke-virtual {v0}, [La6/w;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [La6/w;

    return-object v0
.end method
