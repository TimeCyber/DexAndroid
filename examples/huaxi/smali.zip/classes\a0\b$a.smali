.class public final La0/b$a;
.super Lqg/i;
.source "Animatable.kt"

# interfaces
.implements Lvg/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La0/b;->g(Ljava/lang/Object;Log/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lqg/i;",
        "Lvg/l<",
        "Log/d<",
        "-",
        "Lkg/l;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lqg/e;
    c = "androidx.compose.animation.core.Animatable$snapTo$2"
    f = "Animatable.kt"
    l = {}
    m = "invokeSuspend"
.end annotation


# instance fields
.field public final synthetic a:La0/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/b<",
            "TT;TV;>;"
        }
    .end annotation
.end field

.field public final synthetic b:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(La0/b;Ljava/lang/Object;Log/d;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La0/b<",
            "TT;TV;>;TT;",
            "Log/d<",
            "-",
            "La0/b$a;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La0/b$a;->a:La0/b;

    iput-object p2, p0, La0/b$a;->b:Ljava/lang/Object;

    const/4 p1, 0x1

    invoke-direct {p0, p1, p3}, Lqg/i;-><init>(ILog/d;)V

    return-void
.end method


# virtual methods
.method public final create(Log/d;)Log/d;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Log/d<",
            "*>;)",
            "Log/d<",
            "Lkg/l;",
            ">;"
        }
    .end annotation

    new-instance v0, La0/b$a;

    iget-object v1, p0, La0/b$a;->a:La0/b;

    iget-object v2, p0, La0/b$a;->b:Ljava/lang/Object;

    invoke-direct {v0, v1, v2, p1}, La0/b$a;-><init>(La0/b;Ljava/lang/Object;Log/d;)V

    return-object v0
.end method

.method public invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    check-cast p1, Log/d;

    .line 1
    new-instance v0, La0/b$a;

    iget-object v1, p0, La0/b$a;->a:La0/b;

    iget-object v2, p0, La0/b$a;->b:Ljava/lang/Object;

    invoke-direct {v0, v1, v2, p1}, La0/b$a;-><init>(La0/b;Ljava/lang/Object;Log/d;)V

    .line 2
    sget-object p1, Lkg/l;->a:Lkg/l;

    invoke-virtual {v0, p1}, La0/b$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    invoke-static {p1}, Lo1/a0;->H(Ljava/lang/Object;)V

    .line 2
    iget-object p1, p0, La0/b$a;->a:La0/b;

    invoke-static {p1}, La0/b;->b(La0/b;)V

    .line 3
    iget-object p1, p0, La0/b$a;->a:La0/b;

    iget-object v0, p0, La0/b$a;->b:Ljava/lang/Object;

    invoke-static {p1, v0}, La0/b;->a(La0/b;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    .line 4
    iget-object v0, p0, La0/b$a;->a:La0/b;

    .line 5
    iget-object v0, v0, La0/b;->c:La0/h;

    .line 6
    iget-object v0, v0, La0/h;->b:Lm0/x0;

    .line 7
    invoke-interface {v0, p1}, Lm0/x0;->setValue(Ljava/lang/Object;)V

    .line 8
    iget-object v0, p0, La0/b$a;->a:La0/b;

    .line 9
    iget-object v0, v0, La0/b;->e:Lm0/x0;

    .line 10
    invoke-interface {v0, p1}, Lm0/x0;->setValue(Ljava/lang/Object;)V

    .line 11
    sget-object p1, Lkg/l;->a:Lkg/l;

    return-object p1
.end method
