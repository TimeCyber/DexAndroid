.class public final La0/w0$h;
.super Lwg/j;
.source "VectorConverters.kt"

# interfaces
.implements Lvg/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La0/w0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lwg/j;",
        "Lvg/l<",
        "La0/l;",
        "Lp2/g;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:La0/w0$h;


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    new-instance v0, La0/w0$h;

    invoke-direct {v0}, La0/w0$h;-><init>()V

    sput-object v0, La0/w0$h;->a:La0/w0$h;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lwg/j;-><init>(I)V

    return-void
.end method


# virtual methods
.method public invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 1
    check-cast p1, La0/l;

    const-string v0, "it"

    .line 2
    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    iget v0, p1, La0/l;->a:F

    .line 4
    invoke-static {v0}, Lab/c;->d(F)I

    move-result v0

    .line 5
    iget p1, p1, La0/l;->b:F

    .line 6
    invoke-static {p1}, Lab/c;->d(F)I

    move-result p1

    invoke-static {v0, p1}, Landroidx/activity/n;->b(II)J

    move-result-wide v0

    .line 7
    new-instance p1, Lp2/g;

    invoke-direct {p1, v0, v1}, Lp2/g;-><init>(J)V

    return-object p1
.end method
