.class public final La0/w0$o;
.super Lwg/j;
.source "VectorConverters.kt"

# interfaces
.implements Lvg/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La0/w0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lwg/j;",
        "Lvg/l<",
        "Lc1/d;",
        "La0/m;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:La0/w0$o;


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    new-instance v0, La0/w0$o;

    invoke-direct {v0}, La0/w0$o;-><init>()V

    sput-object v0, La0/w0$o;->a:La0/w0$o;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lwg/j;-><init>(I)V

    return-void
.end method


# virtual methods
.method public invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 1
    check-cast p1, Lc1/d;

    const-string v0, "it"

    .line 2
    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    new-instance v0, La0/m;

    .line 4
    iget v1, p1, Lc1/d;->a:F

    .line 5
    iget v2, p1, Lc1/d;->b:F

    .line 6
    iget v3, p1, Lc1/d;->c:F

    .line 7
    iget p1, p1, Lc1/d;->d:F

    .line 8
    invoke-direct {v0, v1, v2, v3, p1}, La0/m;-><init>(FFFF)V

    return-object v0
.end method
