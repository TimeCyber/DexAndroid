.class public final La0/g1;
.super Ljava/lang/Object;
.source "VectorizedAnimationSpec.kt"

# interfaces
.implements La0/y0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<V:",
        "La0/n;",
        ">",
        "Ljava/lang/Object;",
        "La0/y0<",
        "TV;>;"
    }
.end annotation


# instance fields
.field public final a:La0/d1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/d1<",
            "TV;>;"
        }
    .end annotation
.end field

.field public final b:I

.field public final c:J

.field public final d:J


# direct methods
.method public constructor <init>(La0/d1;IJLwg/e;)V
    .registers 8

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, La0/g1;->a:La0/d1;

    .line 3
    iput p2, p0, La0/g1;->b:I

    .line 4
    invoke-interface {p1}, La0/d1;->f()I

    move-result p2

    invoke-interface {p1}, La0/d1;->g()I

    move-result p1

    add-int/2addr p1, p2

    int-to-long p1, p1

    const-wide/32 v0, 0xf4240

    mul-long p1, p1, v0

    iput-wide p1, p0, La0/g1;->c:J

    mul-long p3, p3, v0

    .line 5
    iput-wide p3, p0, La0/g1;->d:J

    return-void
.end method


# virtual methods
.method public a()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public b(La0/n;La0/n;La0/n;)J
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;TV;TV;)J"
        }
    .end annotation

    const-string v0, "initialValue"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "targetValue"

    invoke-static {p2, p1}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "initialVelocity"

    invoke-static {p3, p1}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-wide p1, 0x7fffffffffffffffL

    return-wide p1
.end method

.method public c(JLa0/n;La0/n;La0/n;)La0/n;
    .registers 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JTV;TV;TV;)TV;"
        }
    .end annotation

    const-string v0, "initialValue"

    invoke-static {p3, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "targetValue"

    invoke-static {p4, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "initialVelocity"

    invoke-static {p5, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object v1, p0, La0/g1;->a:La0/d1;

    .line 2
    invoke-virtual {p0, p1, p2}, La0/g1;->h(J)J

    move-result-wide v2

    move-object v4, p0

    move-wide v5, p1

    move-object v7, p3

    move-object v8, p5

    move-object v9, p4

    .line 3
    invoke-virtual/range {v4 .. v9}, La0/g1;->i(JLa0/n;La0/n;La0/n;)La0/n;

    move-result-object v6

    move-object v4, p3

    move-object v5, p4

    .line 4
    invoke-interface/range {v1 .. v6}, La0/y0;->c(JLa0/n;La0/n;La0/n;)La0/n;

    move-result-object p1

    return-object p1
.end method

.method public synthetic d(La0/n;La0/n;La0/n;)La0/n;
    .registers 4

    invoke-static {p0, p1, p2, p3}, La0/x0;->a(La0/y0;La0/n;La0/n;La0/n;)La0/n;

    move-result-object p1

    return-object p1
.end method

.method public e(JLa0/n;La0/n;La0/n;)La0/n;
    .registers 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JTV;TV;TV;)TV;"
        }
    .end annotation

    const-string v0, "initialValue"

    invoke-static {p3, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "targetValue"

    invoke-static {p4, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "initialVelocity"

    invoke-static {p5, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object v1, p0, La0/g1;->a:La0/d1;

    .line 2
    invoke-virtual {p0, p1, p2}, La0/g1;->h(J)J

    move-result-wide v2

    move-object v4, p0

    move-wide v5, p1

    move-object v7, p3

    move-object v8, p5

    move-object v9, p4

    .line 3
    invoke-virtual/range {v4 .. v9}, La0/g1;->i(JLa0/n;La0/n;La0/n;)La0/n;

    move-result-object v6

    move-object v4, p3

    move-object v5, p4

    .line 4
    invoke-interface/range {v1 .. v6}, La0/y0;->e(JLa0/n;La0/n;La0/n;)La0/n;

    move-result-object p1

    return-object p1
.end method

.method public final h(J)J
    .registers 12

    .line 1
    iget-wide v0, p0, La0/g1;->d:J

    add-long/2addr p1, v0

    const-wide/16 v0, 0x0

    cmp-long v2, p1, v0

    if-gtz v2, :cond_a

    return-wide v0

    .line 2
    :cond_a
    iget-wide v2, p0, La0/g1;->c:J

    div-long v4, p1, v2

    .line 3
    iget v6, p0, La0/g1;->b:I

    const/4 v7, 0x1

    if-eq v6, v7, :cond_23

    const/4 v6, 0x2

    int-to-long v6, v6

    rem-long v6, v4, v6

    cmp-long v8, v6, v0

    if-nez v8, :cond_1c

    goto :goto_23

    :cond_1c
    const-wide/16 v0, 0x1

    add-long/2addr v4, v0

    mul-long v4, v4, v2

    sub-long/2addr v4, p1

    return-wide v4

    .line 4
    :cond_23
    :goto_23
    invoke-static {v4, v5}, Ljava/lang/Long;->signum(J)I

    mul-long v4, v4, v2

    sub-long/2addr p1, v4

    return-wide p1
.end method

.method public final i(JLa0/n;La0/n;La0/n;)La0/n;
    .registers 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JTV;TV;TV;)TV;"
        }
    .end annotation

    .line 1
    iget-wide v0, p0, La0/g1;->d:J

    add-long v2, p1, v0

    iget-wide v4, p0, La0/g1;->c:J

    cmp-long v6, v2, v4

    if-lez v6, :cond_15

    sub-long v1, v4, v0

    move-object v0, p0

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    .line 2
    invoke-virtual/range {v0 .. v5}, La0/g1;->c(JLa0/n;La0/n;La0/n;)La0/n;

    move-result-object v0

    goto :goto_16

    :cond_15
    move-object v0, p4

    :goto_16
    return-object v0
.end method
