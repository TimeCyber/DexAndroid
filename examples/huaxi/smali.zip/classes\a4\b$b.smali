.class public La4/b$b;
.super Landroidx/lifecycle/ViewModel;
.source "LoaderManagerImpl.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La4/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# static fields
.field public static final b:Landroidx/lifecycle/ViewModelProvider$Factory;


# instance fields
.field public a:Ly/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ly/h<",
            "La4/b$a;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, La4/b$b$a;

    invoke-direct {v0}, La4/b$b$a;-><init>()V

    sput-object v0, La4/b$b;->b:Landroidx/lifecycle/ViewModelProvider$Factory;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Landroidx/lifecycle/ViewModel;-><init>()V

    .line 2
    new-instance v0, Ly/h;

    invoke-direct {v0}, Ly/h;-><init>()V

    iput-object v0, p0, La4/b$b;->a:Ly/h;

    return-void
.end method


# virtual methods
.method public onCleared()V
    .registers 7

    .line 1
    invoke-super {p0}, Landroidx/lifecycle/ViewModel;->onCleared()V

    .line 2
    iget-object v0, p0, La4/b$b;->a:Ly/h;

    invoke-virtual {v0}, Ly/h;->i()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-gtz v0, :cond_20

    .line 3
    iget-object v0, p0, La4/b$b;->a:Ly/h;

    .line 4
    iget v3, v0, Ly/h;->d:I

    .line 5
    iget-object v4, v0, Ly/h;->c:[Ljava/lang/Object;

    const/4 v5, 0x0

    :goto_14
    if-ge v5, v3, :cond_1b

    .line 6
    aput-object v1, v4, v5

    add-int/lit8 v5, v5, 0x1

    goto :goto_14

    .line 7
    :cond_1b
    iput v2, v0, Ly/h;->d:I

    .line 8
    iput-boolean v2, v0, Ly/h;->a:Z

    return-void

    .line 9
    :cond_20
    iget-object v0, p0, La4/b$b;->a:Ly/h;

    invoke-virtual {v0, v2}, Ly/h;->j(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La4/b$a;

    .line 10
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    throw v1
.end method
