.class public interface abstract La0/z;
.super Ljava/lang/Object;
.source "FloatAnimationSpec.kt"

# interfaces
.implements La0/g;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "La0/g<",
        "Ljava/lang/Float;",
        ">;"
    }
.end annotation


# virtual methods
.method public abstract b(JFFF)F
.end method

.method public abstract c(FFF)J
.end method

.method public abstract d(FFF)F
.end method

.method public abstract e(JFFF)F
.end method
