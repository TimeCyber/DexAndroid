.class public interface abstract La0/v;
.super Ljava/lang/Object;
.source "AnimationSpec.kt"

# interfaces
.implements La0/y;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "La0/y<",
        "TT;>;"
    }
.end annotation


# virtual methods
.method public abstract a(La0/u0;)La0/d1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<V:",
            "La0/n;",
            ">(",
            "La0/u0<",
            "TT;TV;>;)",
            "La0/d1<",
            "TV;>;"
        }
    .end annotation
.end method
