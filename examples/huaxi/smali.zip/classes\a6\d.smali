.class public La6/d;
.super Ljava/lang/Object;
.source "L.java"


# static fields
.field public static a:I

.field public static volatile b:Lj6/f;

.field public static volatile c:Lj6/e;


# direct methods
.method public static A(Ly0/h;FFI)Ly0/h;
    .registers 6

    and-int/lit8 v0, p3, 0x1

    const/4 v1, 0x0

    if-eqz v0, :cond_6

    int-to-float p1, v1

    :cond_6
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_b

    int-to-float p2, v1

    .line 1
    :cond_b
    invoke-static {p0, p1, p2}, La6/d;->z(Ly0/h;FF)Ly0/h;

    move-result-object p0

    return-object p0
.end method

.method public static B(Ly0/h;FFFFI)Ly0/h;
    .registers 16

    and-int/lit8 v0, p5, 0x1

    const/4 v1, 0x0

    if-eqz v0, :cond_6

    int-to-float p1, v1

    :cond_6
    move v3, p1

    and-int/lit8 p1, p5, 0x2

    if-eqz p1, :cond_c

    int-to-float p2, v1

    :cond_c
    move v4, p2

    and-int/lit8 p1, p5, 0x4

    if-eqz p1, :cond_12

    int-to-float p3, v1

    :cond_12
    move v5, p3

    and-int/lit8 p1, p5, 0x8

    if-eqz p1, :cond_18

    int-to-float p4, v1

    :cond_18
    move v6, p4

    const-string p1, "$this$padding"

    .line 1
    invoke-static {p0, p1}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    new-instance p1, Le0/l0;

    .line 3
    sget-object p2, Landroidx/compose/ui/platform/b1;->a:Lvg/l;

    .line 4
    sget-object v8, Landroidx/compose/ui/platform/b1;->a:Lvg/l;

    const/4 v9, 0x0

    const/4 v7, 0x1

    move-object v2, p1

    .line 5
    invoke-direct/range {v2 .. v9}, Le0/l0;-><init>(FFFFZLvg/l;Lwg/e;)V

    .line 6
    invoke-interface {p0, p1}, Ly0/h;->p0(Ly0/h;)Ly0/h;

    move-result-object p0

    return-object p0
.end method

.method public static final C(Lm0/g;)Lg0/d;
    .registers 4

    const v0, -0x3d7a14e4

    invoke-interface {p0, v0}, Lm0/g;->e(I)V

    .line 1
    sget-object v0, Landroidx/compose/ui/platform/v;->f:Lm0/e1;

    .line 2
    invoke-interface {p0, v0}, Lm0/g;->C(Lm0/w;)Ljava/lang/Object;

    move-result-object v0

    .line 3
    check-cast v0, Landroid/view/View;

    const v1, 0x44faf204

    .line 4
    invoke-interface {p0, v1}, Lm0/g;->e(I)V

    .line 5
    invoke-interface {p0, v0}, Lm0/g;->O(Ljava/lang/Object;)Z

    move-result v1

    .line 6
    invoke-interface {p0}, Lm0/g;->f()Ljava/lang/Object;

    move-result-object v2

    if-nez v1, :cond_22

    .line 7
    sget-object v1, Lm0/g$a;->b:Ljava/lang/Object;

    if-ne v2, v1, :cond_2a

    .line 8
    :cond_22
    new-instance v2, Lg0/a;

    invoke-direct {v2, v0}, Lg0/a;-><init>(Landroid/view/View;)V

    .line 9
    invoke-interface {p0, v2}, Lm0/g;->H(Ljava/lang/Object;)V

    .line 10
    :cond_2a
    invoke-interface {p0}, Lm0/g;->L()V

    .line 11
    check-cast v2, Lg0/a;

    invoke-interface {p0}, Lm0/g;->L()V

    return-object v2
.end method

.method public static final D(Lb1/l;ILvg/l;)Ljava/lang/Object;
    .registers 10

    .line 1
    iget-object p0, p0, Lb1/l;->i:Lr1/c;

    if-eqz p0, :cond_49

    const/4 v0, 0x5

    .line 2
    invoke-static {p1, v0}, Lb1/c;->a(II)Z

    move-result v1

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-eqz v1, :cond_11

    goto :goto_38

    .line 3
    :cond_11
    invoke-static {p1, v2}, Lb1/c;->a(II)Z

    move-result v0

    if-eqz v0, :cond_19

    const/4 v0, 0x6

    goto :goto_38

    .line 4
    :cond_19
    invoke-static {p1, v3}, Lb1/c;->a(II)Z

    move-result v0

    if-eqz v0, :cond_21

    const/4 v0, 0x3

    goto :goto_38

    .line 5
    :cond_21
    invoke-static {p1, v4}, Lb1/c;->a(II)Z

    move-result v0

    if-eqz v0, :cond_29

    const/4 v0, 0x4

    goto :goto_38

    .line 6
    :cond_29
    invoke-static {p1, v5}, Lb1/c;->a(II)Z

    move-result v0

    if-eqz v0, :cond_31

    const/4 v0, 0x2

    goto :goto_38

    .line 7
    :cond_31
    invoke-static {p1, v6}, Lb1/c;->a(II)Z

    move-result p1

    if-eqz p1, :cond_3d

    const/4 v0, 0x1

    .line 8
    :goto_38
    invoke-interface {p0, v0, p2}, Lr1/c;->a(ILvg/l;)Ljava/lang/Object;

    move-result-object p0

    goto :goto_4a

    .line 9
    :cond_3d
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Unsupported direction for beyond bounds layout"

    .line 10
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_49
    const/4 p0, 0x0

    :goto_4a
    return-object p0
.end method

.method public static final E([FLandroid/graphics/Matrix;)V
    .registers 21

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const-string v2, "$this$setFrom"

    invoke-static {v0, v2}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "matrix"

    invoke-static {v1, v2}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-virtual {v1, v0}, Landroid/graphics/Matrix;->getValues([F)V

    const/4 v1, 0x0

    .line 2
    aget v2, v0, v1

    const/4 v3, 0x1

    .line 3
    aget v4, v0, v3

    const/4 v5, 0x2

    .line 4
    aget v6, v0, v5

    const/4 v7, 0x3

    .line 5
    aget v8, v0, v7

    const/4 v9, 0x4

    .line 6
    aget v10, v0, v9

    const/4 v11, 0x5

    .line 7
    aget v12, v0, v11

    const/4 v13, 0x6

    .line 8
    aget v14, v0, v13

    const/4 v15, 0x7

    .line 9
    aget v16, v0, v15

    const/16 v17, 0x8

    .line 10
    aget v18, v0, v17

    .line 11
    aput v2, v0, v1

    .line 12
    aput v8, v0, v3

    const/4 v1, 0x0

    .line 13
    aput v1, v0, v5

    .line 14
    aput v14, v0, v7

    .line 15
    aput v4, v0, v9

    .line 16
    aput v10, v0, v11

    .line 17
    aput v1, v0, v13

    .line 18
    aput v16, v0, v15

    .line 19
    aput v1, v0, v17

    const/16 v2, 0x9

    .line 20
    aput v1, v0, v2

    const/16 v2, 0xa

    const/high16 v3, 0x3f800000    # 1.0f

    .line 21
    aput v3, v0, v2

    const/16 v2, 0xb

    .line 22
    aput v1, v0, v2

    const/16 v2, 0xc

    .line 23
    aput v6, v0, v2

    const/16 v2, 0xd

    .line 24
    aput v12, v0, v2

    const/16 v2, 0xe

    .line 25
    aput v1, v0, v2

    const/16 v1, 0xf

    .line 26
    aput v18, v0, v1

    return-void
.end method

.method public static final F(Ljava/lang/CharSequence;)V
    .registers 2

    const/4 v0, 0x0

    .line 1
    invoke-static {p0, v0}, La6/d;->G(Ljava/lang/CharSequence;Z)V

    return-void
.end method

.method public static final G(Ljava/lang/CharSequence;Z)V
    .registers 5

    .line 1
    new-instance v0, Lcom/blankj/utilcode/util/ToastUtils;

    invoke-direct {v0}, Lcom/blankj/utilcode/util/ToastUtils;-><init>()V

    .line 2
    sget v1, Linfo/cd120/two/base/R$drawable;->bg_toast:I

    .line 3
    iput v1, v0, Lcom/blankj/utilcode/util/ToastUtils;->d:I

    const/16 v1, 0x11

    .line 4
    iput v1, v0, Lcom/blankj/utilcode/util/ToastUtils;->a:I

    const/4 v1, 0x0

    .line 5
    iput v1, v0, Lcom/blankj/utilcode/util/ToastUtils;->b:I

    .line 6
    iput v1, v0, Lcom/blankj/utilcode/util/ToastUtils;->c:I

    const/16 v1, 0xe

    .line 7
    iput v1, v0, Lcom/blankj/utilcode/util/ToastUtils;->f:I

    .line 8
    sget v1, Linfo/cd120/two/base/R$color;->white:I

    invoke-static {v1}, Ld3/g;->D(I)I

    move-result v1

    .line 9
    iput v1, v0, Lcom/blankj/utilcode/util/ToastUtils;->e:I

    .line 10
    iput-boolean p1, v0, Lcom/blankj/utilcode/util/ToastUtils;->g:Z

    .line 11
    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v1

    if-nez v1, :cond_28

    const-string p0, "toast nothing"

    .line 12
    :cond_28
    new-instance v1, Lcom/blankj/utilcode/util/j;

    const/4 v2, 0x0

    invoke-direct {v1, v0, v2, p0, p1}, Lcom/blankj/utilcode/util/j;-><init>(Lcom/blankj/utilcode/util/ToastUtils;Landroid/view/View;Ljava/lang/CharSequence;I)V

    invoke-static {v1}, Lcom/blankj/utilcode/util/p;->i(Ljava/lang/Runnable;)V

    return-void
.end method

.method public static final H(ILjava/lang/Object;Le2/i;Le2/t;I)Ljava/lang/Object;
    .registers 10

    const-string v0, "typeface"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "font"

    invoke-static {p2, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "requestedWeight"

    invoke-static {p3, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    instance-of v0, p1, Landroid/graphics/Typeface;

    if-nez v0, :cond_14

    return-object p1

    :cond_14
    const/4 v0, 0x1

    .line 2
    invoke-static {p0, v0}, Le2/s;->a(II)Z

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_26

    const/4 v1, 0x2

    invoke-static {p0, v1}, Le2/s;->a(II)Z

    move-result v1

    if-eqz v1, :cond_24

    goto :goto_26

    :cond_24
    const/4 v1, 0x0

    goto :goto_27

    :cond_26
    :goto_26
    const/4 v1, 0x1

    :goto_27
    if-eqz v1, :cond_4f

    .line 3
    invoke-interface {p2}, Le2/i;->b()Le2/t;

    move-result-object v1

    invoke-static {v1, p3}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4f

    .line 4
    sget-object v1, Le2/t;->b:Le2/t$a;

    invoke-static {v1}, Le2/z;->x(Le2/t$a;)Le2/t;

    move-result-object v3

    invoke-virtual {p3, v3}, Le2/t;->a(Le2/t;)I

    move-result v3

    if-ltz v3, :cond_4f

    invoke-interface {p2}, Le2/i;->b()Le2/t;

    move-result-object v3

    invoke-static {v1}, Le2/z;->x(Le2/t$a;)Le2/t;

    move-result-object v1

    invoke-virtual {v3, v1}, Le2/t;->a(Le2/t;)I

    move-result v1

    if-gez v1, :cond_4f

    const/4 v1, 0x1

    goto :goto_50

    :cond_4f
    const/4 v1, 0x0

    .line 5
    :goto_50
    invoke-static {p0, v0}, Le2/s;->a(II)Z

    move-result v3

    if-nez v3, :cond_60

    const/4 v3, 0x3

    invoke-static {p0, v3}, Le2/s;->a(II)Z

    move-result p0

    if-eqz p0, :cond_5e

    goto :goto_60

    :cond_5e
    const/4 p0, 0x0

    goto :goto_61

    :cond_60
    :goto_60
    const/4 p0, 0x1

    :goto_61
    if-eqz p0, :cond_6f

    .line 6
    invoke-interface {p2}, Le2/i;->c()I

    move-result p0

    invoke-static {p4, p0}, Le2/r;->a(II)Z

    move-result p0

    if-nez p0, :cond_6f

    const/4 p0, 0x1

    goto :goto_70

    :cond_6f
    const/4 p0, 0x0

    :goto_70
    if-nez p0, :cond_75

    if-nez v1, :cond_75

    return-object p1

    .line 7
    :cond_75
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x1c

    if-ge v3, v4, :cond_90

    if-eqz p0, :cond_84

    .line 8
    invoke-static {p4, v0}, Le2/r;->a(II)Z

    move-result p0

    if-eqz p0, :cond_84

    goto :goto_85

    :cond_84
    const/4 v0, 0x0

    .line 9
    :goto_85
    invoke-static {v1, v0}, Le2/z;->y(ZZ)I

    move-result p0

    .line 10
    check-cast p1, Landroid/graphics/Typeface;

    invoke-static {p1, p0}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object p0

    goto :goto_b2

    :cond_90
    if-eqz v1, :cond_95

    .line 11
    iget p3, p3, Le2/t;->a:I

    goto :goto_9b

    .line 12
    :cond_95
    invoke-interface {p2}, Le2/i;->b()Le2/t;

    move-result-object p3

    .line 13
    iget p3, p3, Le2/t;->a:I

    :goto_9b
    if-eqz p0, :cond_a2

    .line 14
    invoke-static {p4, v0}, Le2/r;->a(II)Z

    move-result p0

    goto :goto_aa

    .line 15
    :cond_a2
    invoke-interface {p2}, Le2/i;->c()I

    move-result p0

    invoke-static {p0, v0}, Le2/r;->a(II)Z

    move-result p0

    .line 16
    :goto_aa
    sget-object p2, Le2/d0;->a:Le2/d0;

    check-cast p1, Landroid/graphics/Typeface;

    invoke-virtual {p2, p1, p3, p0}, Le2/d0;->a(Landroid/graphics/Typeface;IZ)Landroid/graphics/Typeface;

    move-result-object p0

    :goto_b2
    const-string p1, "if (Build.VERSION.SDK_IN\u2026ht, finalFontStyle)\n    }"

    invoke-static {p0, p1}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p0
.end method

.method public static final I(J)J
    .registers 3

    .line 1
    invoke-static {p0, p1}, Lp2/i;->c(J)I

    move-result v0

    int-to-float v0, v0

    invoke-static {p0, p1}, Lp2/i;->b(J)I

    move-result p0

    int-to-float p0, p0

    invoke-static {v0, p0}, Landroidx/appcompat/widget/m;->j(FF)J

    move-result-wide p0

    return-wide p0
.end method

.method public static a(FFI)La0/b;
    .registers 4

    and-int/lit8 p2, p2, 0x2

    if-eqz p2, :cond_7

    const p1, 0x3c23d70a    # 0.01f

    .line 1
    :cond_7
    new-instance p2, La0/b;

    .line 2
    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p0

    .line 3
    sget-object v0, Lm/d;->c:Lm/d;

    invoke-static {v0}, La0/w0;->b(Lm/d;)La0/u0;

    move-result-object v0

    .line 4
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    .line 5
    invoke-direct {p2, p0, v0, p1}, La0/b;-><init>(Ljava/lang/Object;La0/u0;Ljava/lang/Object;)V

    return-object p2
.end method

.method public static final b(Landroid/content/Context;)Lp2/b;
    .registers 3

    const-string v0, "context"

    invoke-static {p0, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    .line 2
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p0

    iget p0, p0, Landroid/content/res/Configuration;->fontScale:F

    .line 3
    new-instance v1, Lp2/c;

    invoke-direct {v1, v0, p0}, Lp2/c;-><init>(FF)V

    return-object v1
.end method

.method public static final c(II)J
    .registers 6

    int-to-long v0, p0

    const/16 p0, 0x20

    shl-long/2addr v0, p0

    int-to-long p0, p1

    const-wide v2, 0xffffffffL

    and-long/2addr p0, v2

    or-long/2addr p0, v0

    return-wide p0
.end method

.method public static final d(I)J
    .registers 7

    int-to-long v0, p0

    const/16 p0, 0x20

    shl-long/2addr v0, p0

    const/4 p0, 0x0

    int-to-long v2, p0

    const-wide v4, 0xffffffffL

    and-long/2addr v2, v4

    or-long/2addr v0, v2

    .line 1
    sget-object p0, Lm1/a;->a:Lm1/a;

    return-wide v0
.end method

.method public static final e(FFFF)Le0/m0;
    .registers 11

    .line 1
    new-instance v6, Le0/n0;

    const/4 v5, 0x0

    move-object v0, v6

    move v1, p0

    move v2, p1

    move v3, p2

    move v4, p3

    invoke-direct/range {v0 .. v5}, Le0/n0;-><init>(FFFFLwg/e;)V

    return-object v6
.end method

.method public static final f(FFFFJ)Lc1/e;
    .registers 22

    .line 1
    invoke-static/range {p4 .. p5}, Lc1/a;->b(J)F

    move-result v0

    .line 2
    invoke-static/range {p4 .. p5}, Lc1/a;->c(J)F

    move-result v1

    .line 3
    invoke-static {v0, v1}, Landroidx/appcompat/widget/m;->f(FF)J

    move-result-wide v13

    .line 4
    new-instance v0, Lc1/e;

    const/4 v15, 0x0

    move-object v2, v0

    move/from16 v3, p0

    move/from16 v4, p1

    move/from16 v5, p2

    move/from16 v6, p3

    move-wide v7, v13

    move-wide v9, v13

    move-wide v11, v13

    invoke-direct/range {v2 .. v15}, Lc1/e;-><init>(FFFFJJJJLwg/e;)V

    return-object v0
.end method

.method public static final g(II)J
    .registers 6

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-ltz p0, :cond_6

    const/4 v2, 0x1

    goto :goto_7

    :cond_6
    const/4 v2, 0x0

    :goto_7
    const/16 v3, 0x5d

    if-eqz v2, :cond_3d

    if-ltz p1, :cond_e

    const/4 v0, 0x1

    :cond_e
    if-eqz v0, :cond_1f

    int-to-long v0, p0

    const/16 p0, 0x20

    shl-long/2addr v0, p0

    int-to-long p0, p1

    const-wide v2, 0xffffffffL

    and-long/2addr p0, v2

    or-long/2addr p0, v0

    .line 1
    sget-object v0, Lz1/s;->b:Lz1/s$a;

    return-wide p0

    .line 2
    :cond_1f
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "end cannot negative. [end: "

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    .line 3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 4
    :cond_3d
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "start cannot be negative. [start: "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    .line 5
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public static final h(Landroid/view/View;Lt1/h;)V
    .registers 5

    .line 1
    iget-object p1, p1, Lt1/h;->C:Lt1/q;

    .line 2
    invoke-static {p1}, Le2/z;->P(Lr1/m;)J

    move-result-wide v0

    .line 3
    invoke-static {v0, v1}, Lc1/c;->c(J)F

    move-result p1

    invoke-static {p1}, Lab/c;->d(F)I

    move-result p1

    .line 4
    invoke-static {v0, v1}, Lc1/c;->d(J)F

    move-result v0

    invoke-static {v0}, Lab/c;->d(F)I

    move-result v0

    .line 5
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result v1

    add-int/2addr v1, p1

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v2

    add-int/2addr v2, v0

    invoke-virtual {p0, p1, v0, v1, v2}, Landroid/view/View;->layout(IIII)V

    return-void
.end method

.method public static final i(I)F
    .registers 2

    int-to-float p0, p0

    const/4 v0, -0x1

    int-to-float v0, v0

    mul-float p0, p0, v0

    return p0
.end method

.method public static final j(I)I
    .registers 1

    if-nez p0, :cond_4

    const/4 p0, 0x1

    goto :goto_5

    :cond_4
    const/4 p0, 0x2

    :goto_5
    return p0
.end method

.method public static final k(JFJJ)F
    .registers 14

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/16 v6, 0xe

    move-wide v0, p0

    move v2, p2

    .line 1
    invoke-static/range {v0 .. v6}, Ld1/s;->a(JFFFFI)J

    move-result-wide p0

    .line 2
    invoke-static {p0, p1, p5, p6}, Landroidx/appcompat/widget/m;->q(JJ)J

    move-result-wide p0

    .line 3
    invoke-static {p3, p4, p0, p1}, Landroidx/appcompat/widget/m;->q(JJ)J

    move-result-wide p2

    .line 4
    invoke-static {p2, p3}, Landroidx/appcompat/widget/m;->F(J)F

    move-result p2

    const p3, 0x3d4ccccd    # 0.05f

    add-float/2addr p2, p3

    .line 5
    invoke-static {p0, p1}, Landroidx/appcompat/widget/m;->F(J)F

    move-result p0

    add-float/2addr p0, p3

    .line 6
    invoke-static {p2, p0}, Ljava/lang/Math;->max(FF)F

    move-result p1

    .line 7
    invoke-static {p2, p0}, Ljava/lang/Math;->min(FF)F

    move-result p0

    div-float/2addr p1, p0

    return p1
.end method

.method public static final l(JII)J
    .registers 6

    .line 1
    invoke-static {p0, p1}, Lz1/s;->i(J)I

    move-result v0

    invoke-static {v0, p2, p3}, Li0/z0;->m(III)I

    move-result v0

    .line 2
    invoke-static {p0, p1}, Lz1/s;->d(J)I

    move-result v1

    invoke-static {v1, p2, p3}, Li0/z0;->m(III)I

    move-result p2

    .line 3
    invoke-static {p0, p1}, Lz1/s;->i(J)I

    move-result p3

    if-ne v0, p3, :cond_1e

    invoke-static {p0, p1}, Lz1/s;->d(J)I

    move-result p3

    if-eq p2, p3, :cond_1d

    goto :goto_1e

    :cond_1d
    return-wide p0

    .line 4
    :cond_1e
    :goto_1e
    invoke-static {v0, p2}, La6/d;->g(II)J

    move-result-wide p0

    return-wide p0
.end method

.method public static m(Ljava/lang/String;)F
    .registers 2

    .line 1
    sget p0, La6/d;->a:I

    const/4 v0, 0x0

    if-lez p0, :cond_9

    add-int/lit8 p0, p0, -0x1

    .line 2
    sput p0, La6/d;->a:I

    :cond_9
    return v0
.end method

.method public static n(Ljava/util/List;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lvg/l;I)Ljava/lang/String;
    .registers 11

    and-int/lit8 p2, p7, 0x1

    if-eqz p2, :cond_6

    const-string p1, ", "

    :cond_6
    and-int/lit8 p2, p7, 0x2

    const-string p3, ""

    const/4 p5, 0x0

    if-eqz p2, :cond_f

    move-object p2, p3

    goto :goto_10

    :cond_f
    move-object p2, p5

    :goto_10
    and-int/lit8 p6, p7, 0x4

    if-eqz p6, :cond_15

    goto :goto_16

    :cond_15
    move-object p3, p5

    :goto_16
    and-int/lit8 p6, p7, 0x8

    if-eqz p6, :cond_1b

    const/4 p4, -0x1

    :cond_1b
    and-int/lit8 p6, p7, 0x10

    if-eqz p6, :cond_21

    const-string p5, "..."

    :cond_21
    const-string p6, "prefix"

    .line 1
    invoke-static {p2, p6}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p6, "postfix"

    invoke-static {p3, p6}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p6, "truncated"

    invoke-static {p5, p6}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    new-instance p6, Ljava/lang/StringBuilder;

    invoke-direct {p6}, Ljava/lang/StringBuilder;-><init>()V

    .line 3
    invoke-virtual {p6, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    .line 4
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result p2

    const/4 p7, 0x0

    const/4 v0, 0x0

    :goto_3e
    if-ge p7, p2, :cond_75

    .line 5
    invoke-interface {p0, p7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    add-int/lit8 v0, v0, 0x1

    const/4 v2, 0x1

    if-le v0, v2, :cond_4c

    .line 6
    invoke-virtual {p6, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    :cond_4c
    if-ltz p4, :cond_50

    if-gt v0, p4, :cond_75

    :cond_50
    if-nez v1, :cond_53

    goto :goto_55

    .line 7
    :cond_53
    instance-of v2, v1, Ljava/lang/CharSequence;

    :goto_55
    if-eqz v2, :cond_5d

    check-cast v1, Ljava/lang/CharSequence;

    invoke-virtual {p6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    goto :goto_72

    .line 8
    :cond_5d
    instance-of v2, v1, Ljava/lang/Character;

    if-eqz v2, :cond_6b

    check-cast v1, Ljava/lang/Character;

    invoke-virtual {v1}, Ljava/lang/Character;->charValue()C

    move-result v1

    invoke-virtual {p6, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/Appendable;

    goto :goto_72

    .line 9
    :cond_6b
    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    :goto_72
    add-int/lit8 p7, p7, 0x1

    goto :goto_3e

    :cond_75
    if-ltz p4, :cond_7c

    if-le v0, p4, :cond_7c

    .line 10
    invoke-virtual {p6, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    .line 11
    :cond_7c
    invoke-virtual {p6, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    .line 12
    invoke-virtual {p6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "fastJoinTo(StringBuilder\u2026form)\n        .toString()"

    invoke-static {p0, p1}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p0
.end method

.method public static final o(Lr1/x;)Ljava/lang/Object;
    .registers 3

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-interface {p0}, Lr1/j;->M()Ljava/lang/Object;

    move-result-object p0

    instance-of v0, p0, Lr1/o;

    const/4 v1, 0x0

    if-eqz v0, :cond_11

    check-cast p0, Lr1/o;

    goto :goto_12

    :cond_11
    move-object p0, v1

    :goto_12
    if-eqz p0, :cond_18

    invoke-interface {p0}, Lr1/o;->a()Ljava/lang/Object;

    move-result-object v1

    :cond_18
    return-object v1
.end method

.method public static final p(Lf2/v;)Lz1/a;
    .registers 4

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object v0, p0, Lf2/v;->a:Lz1/a;

    .line 2
    iget-wide v1, p0, Lf2/v;->b:J

    .line 3
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    invoke-static {v1, v2}, Lz1/s;->g(J)I

    move-result p0

    invoke-static {v1, v2}, Lz1/s;->f(J)I

    move-result v1

    invoke-virtual {v0, p0, v1}, Lz1/a;->b(II)Lz1/a;

    move-result-object p0

    return-object p0
.end method

.method public static final q(Lf2/v;I)Lz1/a;
    .registers 6

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object v0, p0, Lf2/v;->a:Lz1/a;

    .line 2
    iget-wide v1, p0, Lf2/v;->b:J

    .line 3
    invoke-static {v1, v2}, Lz1/s;->f(J)I

    move-result v1

    .line 4
    iget-wide v2, p0, Lf2/v;->b:J

    .line 5
    invoke-static {v2, v3}, Lz1/s;->f(J)I

    move-result v2

    add-int/2addr v2, p1

    .line 6
    iget-object p0, p0, Lf2/v;->a:Lz1/a;

    .line 7
    iget-object p0, p0, Lz1/a;->a:Ljava/lang/String;

    .line 8
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    invoke-static {v2, p0}, Ljava/lang/Math;->min(II)I

    move-result p0

    invoke-virtual {v0, v1, p0}, Lz1/a;->b(II)Lz1/a;

    move-result-object p0

    return-object p0
.end method

.method public static final r(Lf2/v;I)Lz1/a;
    .registers 6

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object v0, p0, Lf2/v;->a:Lz1/a;

    const/4 v1, 0x0

    .line 2
    iget-wide v2, p0, Lf2/v;->b:J

    .line 3
    invoke-static {v2, v3}, Lz1/s;->g(J)I

    move-result v2

    sub-int/2addr v2, p1

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result p1

    .line 4
    iget-wide v1, p0, Lf2/v;->b:J

    .line 5
    invoke-static {v1, v2}, Lz1/s;->g(J)I

    move-result p0

    invoke-virtual {v0, p1, p0}, Lz1/a;->b(II)Lz1/a;

    move-result-object p0

    return-object p0
.end method

.method public static s(Ly0/h;FFFFFFFFFFJLd1/k0;ZJJI)Ly0/h;
    .registers 46

    move-object/from16 v0, p0

    move/from16 v1, p19

    and-int/lit8 v2, v1, 0x1

    const/high16 v3, 0x3f800000    # 1.0f

    if-eqz v2, :cond_d

    const/high16 v5, 0x3f800000    # 1.0f

    goto :goto_f

    :cond_d
    move/from16 v5, p1

    :goto_f
    and-int/lit8 v2, v1, 0x2

    if-eqz v2, :cond_16

    const/high16 v6, 0x3f800000    # 1.0f

    goto :goto_18

    :cond_16
    move/from16 v6, p2

    :goto_18
    and-int/lit8 v2, v1, 0x4

    if-eqz v2, :cond_1f

    const/high16 v7, 0x3f800000    # 1.0f

    goto :goto_21

    :cond_1f
    move/from16 v7, p3

    :goto_21
    and-int/lit8 v2, v1, 0x8

    const/4 v3, 0x0

    if-eqz v2, :cond_28

    const/4 v8, 0x0

    goto :goto_2a

    :cond_28
    move/from16 v8, p4

    :goto_2a
    and-int/lit8 v2, v1, 0x10

    if-eqz v2, :cond_30

    const/4 v9, 0x0

    goto :goto_32

    :cond_30
    move/from16 v9, p5

    :goto_32
    and-int/lit8 v2, v1, 0x20

    if-eqz v2, :cond_38

    const/4 v10, 0x0

    goto :goto_3a

    :cond_38
    move/from16 v10, p6

    :goto_3a
    and-int/lit8 v2, v1, 0x40

    if-eqz v2, :cond_40

    const/4 v11, 0x0

    goto :goto_42

    :cond_40
    move/from16 v11, p7

    :goto_42
    and-int/lit16 v2, v1, 0x80

    if-eqz v2, :cond_48

    const/4 v12, 0x0

    goto :goto_4a

    :cond_48
    move/from16 v12, p8

    :goto_4a
    and-int/lit16 v2, v1, 0x100

    if-eqz v2, :cond_50

    const/4 v13, 0x0

    goto :goto_52

    :cond_50
    move/from16 v13, p9

    :goto_52
    and-int/lit16 v2, v1, 0x200

    if-eqz v2, :cond_5b

    const/high16 v2, 0x41000000    # 8.0f

    const/high16 v14, 0x41000000    # 8.0f

    goto :goto_5d

    :cond_5b
    move/from16 v14, p10

    :goto_5d
    and-int/lit16 v2, v1, 0x400

    if-eqz v2, :cond_67

    .line 1
    sget-object v2, Ld1/q0;->a:Ld1/q0$a;

    .line 2
    sget-wide v2, Ld1/q0;->b:J

    move-wide v15, v2

    goto :goto_69

    :cond_67
    move-wide/from16 v15, p11

    :goto_69
    and-int/lit16 v2, v1, 0x800

    if-eqz v2, :cond_70

    .line 3
    sget-object v2, Ld1/f0;->a:Ld1/k0;

    goto :goto_72

    :cond_70
    move-object/from16 v2, p13

    :goto_72
    and-int/lit16 v3, v1, 0x1000

    if-eqz v3, :cond_7a

    const/4 v3, 0x0

    const/16 v18, 0x0

    goto :goto_7c

    :cond_7a
    move/from16 v18, p14

    :goto_7c
    and-int/lit16 v3, v1, 0x4000

    if-eqz v3, :cond_85

    .line 4
    sget-wide v3, Ld1/x;->a:J

    move-wide/from16 v20, v3

    goto :goto_87

    :cond_85
    move-wide/from16 v20, p15

    :goto_87
    const v3, 0x8000

    and-int/2addr v1, v3

    if-eqz v1, :cond_92

    .line 5
    sget-wide v3, Ld1/x;->a:J

    move-wide/from16 v22, v3

    goto :goto_94

    :cond_92
    move-wide/from16 v22, p17

    :goto_94
    const-string v1, "$this$graphicsLayer"

    .line 6
    invoke-static {v0, v1}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "shape"

    invoke-static {v2, v1}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 7
    sget-object v1, Landroidx/compose/ui/platform/b1;->a:Lvg/l;

    .line 8
    sget-object v24, Landroidx/compose/ui/platform/b1;->a:Lvg/l;

    .line 9
    new-instance v1, Ld1/m0;

    move-object v4, v1

    const/16 v25, 0x0

    const/16 v19, 0x0

    move-object/from16 v17, v2

    invoke-direct/range {v4 .. v25}, Ld1/m0;-><init>(FFFFFFFFFFJLd1/k0;ZLd1/g0;JJLvg/l;Lwg/e;)V

    .line 10
    invoke-interface {v0, v1}, Ly0/h;->p0(Ly0/h;)Ly0/h;

    move-result-object v0

    return-object v0
.end method

.method public static final t([Lt1/p;I)Z
    .registers 2

    .line 1
    aget-object p0, p0, p1

    if-eqz p0, :cond_6

    const/4 p0, 0x1

    goto :goto_7

    :cond_6
    const/4 p0, 0x0

    :goto_7
    return p0
.end method

.method public static final u(Lz1/n;)Z
    .registers 2

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object v0, p0, Lz1/n;->f:Le2/j;

    if-nez v0, :cond_14

    .line 2
    iget-object v0, p0, Lz1/n;->d:Le2/r;

    if-nez v0, :cond_14

    .line 3
    iget-object p0, p0, Lz1/n;->c:Le2/t;

    if-eqz p0, :cond_12

    goto :goto_14

    :cond_12
    const/4 p0, 0x0

    goto :goto_15

    :cond_14
    :goto_14
    const/4 p0, 0x1

    :goto_15
    return p0
.end method

.method public static final v(Lc1/e;)Z
    .registers 7

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-wide v0, p0, Lc1/e;->e:J

    .line 2
    invoke-static {v0, v1}, Lc1/a;->b(J)F

    move-result v0

    .line 3
    iget-wide v1, p0, Lc1/e;->e:J

    .line 4
    invoke-static {v1, v2}, Lc1/a;->c(J)F

    move-result v1

    const/4 v2, 0x1

    const/4 v3, 0x0

    cmpg-float v0, v0, v1

    if-nez v0, :cond_19

    const/4 v0, 0x1

    goto :goto_1a

    :cond_19
    const/4 v0, 0x0

    :goto_1a
    if-eqz v0, :cond_9b

    .line 5
    iget-wide v0, p0, Lc1/e;->e:J

    .line 6
    invoke-static {v0, v1}, Lc1/a;->b(J)F

    move-result v0

    .line 7
    iget-wide v4, p0, Lc1/e;->f:J

    .line 8
    invoke-static {v4, v5}, Lc1/a;->b(J)F

    move-result v1

    cmpg-float v0, v0, v1

    if-nez v0, :cond_2e

    const/4 v0, 0x1

    goto :goto_2f

    :cond_2e
    const/4 v0, 0x0

    :goto_2f
    if-eqz v0, :cond_9b

    .line 9
    iget-wide v0, p0, Lc1/e;->e:J

    .line 10
    invoke-static {v0, v1}, Lc1/a;->b(J)F

    move-result v0

    .line 11
    iget-wide v4, p0, Lc1/e;->f:J

    .line 12
    invoke-static {v4, v5}, Lc1/a;->c(J)F

    move-result v1

    cmpg-float v0, v0, v1

    if-nez v0, :cond_43

    const/4 v0, 0x1

    goto :goto_44

    :cond_43
    const/4 v0, 0x0

    :goto_44
    if-eqz v0, :cond_9b

    .line 13
    iget-wide v0, p0, Lc1/e;->e:J

    .line 14
    invoke-static {v0, v1}, Lc1/a;->b(J)F

    move-result v0

    .line 15
    iget-wide v4, p0, Lc1/e;->g:J

    .line 16
    invoke-static {v4, v5}, Lc1/a;->b(J)F

    move-result v1

    cmpg-float v0, v0, v1

    if-nez v0, :cond_58

    const/4 v0, 0x1

    goto :goto_59

    :cond_58
    const/4 v0, 0x0

    :goto_59
    if-eqz v0, :cond_9b

    .line 17
    iget-wide v0, p0, Lc1/e;->e:J

    .line 18
    invoke-static {v0, v1}, Lc1/a;->b(J)F

    move-result v0

    .line 19
    iget-wide v4, p0, Lc1/e;->g:J

    .line 20
    invoke-static {v4, v5}, Lc1/a;->c(J)F

    move-result v1

    cmpg-float v0, v0, v1

    if-nez v0, :cond_6d

    const/4 v0, 0x1

    goto :goto_6e

    :cond_6d
    const/4 v0, 0x0

    :goto_6e
    if-eqz v0, :cond_9b

    .line 21
    iget-wide v0, p0, Lc1/e;->e:J

    .line 22
    invoke-static {v0, v1}, Lc1/a;->b(J)F

    move-result v0

    .line 23
    iget-wide v4, p0, Lc1/e;->h:J

    .line 24
    invoke-static {v4, v5}, Lc1/a;->b(J)F

    move-result v1

    cmpg-float v0, v0, v1

    if-nez v0, :cond_82

    const/4 v0, 0x1

    goto :goto_83

    :cond_82
    const/4 v0, 0x0

    :goto_83
    if-eqz v0, :cond_9b

    .line 25
    iget-wide v0, p0, Lc1/e;->e:J

    .line 26
    invoke-static {v0, v1}, Lc1/a;->b(J)F

    move-result v0

    .line 27
    iget-wide v4, p0, Lc1/e;->h:J

    .line 28
    invoke-static {v4, v5}, Lc1/a;->c(J)F

    move-result p0

    cmpg-float p0, v0, p0

    if-nez p0, :cond_97

    const/4 p0, 0x1

    goto :goto_98

    :cond_97
    const/4 p0, 0x0

    :goto_98
    if-eqz p0, :cond_9b

    goto :goto_9c

    :cond_9b
    const/4 v2, 0x0

    :goto_9c
    return v2
.end method

.method public static final w(Ly0/h;Ljava/lang/Object;)Ly0/h;
    .registers 3

    .line 1
    new-instance p0, Lr1/n;

    .line 2
    sget-object v0, Landroidx/compose/ui/platform/b1;->a:Lvg/l;

    .line 3
    sget-object v0, Landroidx/compose/ui/platform/b1;->a:Lvg/l;

    .line 4
    invoke-direct {p0, p1, v0}, Lr1/n;-><init>(Ljava/lang/Object;Lvg/l;)V

    return-object p0
.end method

.method public static final x(Landroid/graphics/Paint$FontMetricsInt;)I
    .registers 2

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget v0, p0, Landroid/graphics/Paint$FontMetricsInt;->descent:I

    iget p0, p0, Landroid/graphics/Paint$FontMetricsInt;->ascent:I

    sub-int/2addr v0, p0

    return v0
.end method

.method public static final y(Ly0/h;F)Ly0/h;
    .registers 11

    const-string v0, "$this$padding"

    invoke-static {p0, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    new-instance v0, Le0/l0;

    .line 2
    sget-object v1, Landroidx/compose/ui/platform/b1;->a:Lvg/l;

    .line 3
    sget-object v7, Landroidx/compose/ui/platform/b1;->a:Lvg/l;

    const/4 v8, 0x0

    const/4 v6, 0x1

    move-object v1, v0

    move v2, p1

    move v3, p1

    move v4, p1

    move v5, p1

    .line 4
    invoke-direct/range {v1 .. v8}, Le0/l0;-><init>(FFFFZLvg/l;Lwg/e;)V

    .line 5
    invoke-interface {p0, v0}, Ly0/h;->p0(Ly0/h;)Ly0/h;

    move-result-object p0

    return-object p0
.end method

.method public static final z(Ly0/h;FF)Ly0/h;
    .registers 12

    const-string v0, "$this$padding"

    invoke-static {p0, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    new-instance v0, Le0/l0;

    .line 2
    sget-object v1, Landroidx/compose/ui/platform/b1;->a:Lvg/l;

    .line 3
    sget-object v7, Landroidx/compose/ui/platform/b1;->a:Lvg/l;

    const/4 v8, 0x0

    const/4 v6, 0x1

    move-object v1, v0

    move v2, p1

    move v3, p2

    move v4, p1

    move v5, p2

    .line 4
    invoke-direct/range {v1 .. v8}, Le0/l0;-><init>(FFFFZLvg/l;Lwg/e;)V

    .line 5
    invoke-interface {p0, v0}, Ly0/h;->p0(Ly0/h;)Ly0/h;

    move-result-object p0

    return-object p0
.end method
