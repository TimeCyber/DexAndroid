.class public final La0/w0$q;
.super Lwg/j;
.source "VectorConverters.kt"

# interfaces
.implements Lvg/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La0/w0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lwg/j;",
        "Lvg/l<",
        "Lc1/f;",
        "La0/l;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:La0/w0$q;


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    new-instance v0, La0/w0$q;

    invoke-direct {v0}, La0/w0$q;-><init>()V

    sput-object v0, La0/w0$q;->a:La0/w0$q;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lwg/j;-><init>(I)V

    return-void
.end method


# virtual methods
.method public invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    check-cast p1, Lc1/f;

    .line 2
    iget-wide v0, p1, Lc1/f;->a:J

    .line 3
    new-instance p1, La0/l;

    invoke-static {v0, v1}, Lc1/f;->e(J)F

    move-result v2

    invoke-static {v0, v1}, Lc1/f;->c(J)F

    move-result v0

    invoke-direct {p1, v2, v0}, La0/l;-><init>(FF)V

    return-object p1
.end method
