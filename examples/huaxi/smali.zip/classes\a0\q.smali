.class public final La0/q;
.super Ljava/lang/Object;
.source "Easing.kt"

# interfaces
.implements La0/w;


# instance fields
.field public final a:F

.field public final b:F

.field public final c:F

.field public final d:F


# direct methods
.method public constructor <init>(FFFF)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput p1, p0, La0/q;->a:F

    .line 3
    iput p2, p0, La0/q;->b:F

    .line 4
    iput p3, p0, La0/q;->c:F

    .line 5
    iput p4, p0, La0/q;->d:F

    return-void
.end method


# virtual methods
.method public a(F)F
    .registers 8

    const/4 v0, 0x0

    cmpl-float v1, p1, v0

    if-lez v1, :cond_36

    const/high16 v1, 0x3f800000    # 1.0f

    cmpg-float v2, p1, v1

    if-gez v2, :cond_36

    :goto_b
    add-float v2, v0, v1

    const/4 v3, 0x2

    int-to-float v3, v3

    div-float/2addr v2, v3

    .line 1
    iget v3, p0, La0/q;->a:F

    iget v4, p0, La0/q;->c:F

    invoke-virtual {p0, v3, v4, v2}, La0/q;->b(FFF)F

    move-result v3

    sub-float v4, p1, v3

    .line 2
    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    move-result v4

    const v5, 0x3a83126f    # 0.001f

    cmpg-float v4, v4, v5

    if-gez v4, :cond_2e

    .line 3
    iget p1, p0, La0/q;->b:F

    iget v0, p0, La0/q;->d:F

    invoke-virtual {p0, p1, v0, v2}, La0/q;->b(FFF)F

    move-result p1

    return p1

    :cond_2e
    cmpg-float v3, v3, p1

    if-gez v3, :cond_34

    move v0, v2

    goto :goto_b

    :cond_34
    move v1, v2

    goto :goto_b

    :cond_36
    return p1
.end method

.method public final b(FFF)F
    .registers 6

    const/4 v0, 0x3

    int-to-float v0, v0

    mul-float p1, p1, v0

    const/4 v1, 0x1

    int-to-float v1, v1

    sub-float/2addr v1, p3

    mul-float p1, p1, v1

    mul-float p1, p1, v1

    mul-float p1, p1, p3

    mul-float v0, v0, p2

    mul-float v0, v0, v1

    mul-float v0, v0, p3

    mul-float v0, v0, p3

    add-float/2addr v0, p1

    mul-float p1, p3, p3

    mul-float p1, p1, p3

    add-float/2addr p1, v0

    return p1
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    instance-of v0, p1, La0/q;

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_3d

    iget v0, p0, La0/q;->a:F

    check-cast p1, La0/q;

    iget v3, p1, La0/q;->a:F

    cmpg-float v0, v0, v3

    if-nez v0, :cond_12

    const/4 v0, 0x1

    goto :goto_13

    :cond_12
    const/4 v0, 0x0

    :goto_13
    if-eqz v0, :cond_3d

    iget v0, p0, La0/q;->b:F

    iget v3, p1, La0/q;->b:F

    cmpg-float v0, v0, v3

    if-nez v0, :cond_1f

    const/4 v0, 0x1

    goto :goto_20

    :cond_1f
    const/4 v0, 0x0

    :goto_20
    if-eqz v0, :cond_3d

    iget v0, p0, La0/q;->c:F

    iget v3, p1, La0/q;->c:F

    cmpg-float v0, v0, v3

    if-nez v0, :cond_2c

    const/4 v0, 0x1

    goto :goto_2d

    :cond_2c
    const/4 v0, 0x0

    :goto_2d
    if-eqz v0, :cond_3d

    .line 2
    iget v0, p0, La0/q;->d:F

    iget p1, p1, La0/q;->d:F

    cmpg-float p1, v0, p1

    if-nez p1, :cond_39

    const/4 p1, 0x1

    goto :goto_3a

    :cond_39
    const/4 p1, 0x0

    :goto_3a
    if-eqz p1, :cond_3d

    goto :goto_3e

    :cond_3d
    const/4 v1, 0x0

    :goto_3e
    return v1
.end method

.method public hashCode()I
    .registers 4

    .line 1
    iget v0, p0, La0/q;->a:F

    invoke-static {v0}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, La0/q;->b:F

    const/16 v2, 0x1f

    invoke-static {v1, v0, v2}, Lc0/a0;->c(FII)I

    move-result v0

    iget v1, p0, La0/q;->c:F

    invoke-static {v1, v0, v2}, Lc0/a0;->c(FII)I

    move-result v0

    iget v1, p0, La0/q;->d:F

    invoke-static {v1}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v1

    add-int/2addr v1, v0

    return v1
.end method
