.class public final La0/j1;
.super Ljava/lang/Object;
.source "VectorizedAnimationSpec.kt"

# interfaces
.implements La0/d1;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<V:",
        "La0/n;",
        ">",
        "Ljava/lang/Object;",
        "La0/d1<",
        "TV;>;"
    }
.end annotation


# instance fields
.field public final a:I

.field public final b:I

.field public final c:La0/w;

.field public final d:La0/e1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/e1<",
            "TV;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(IILa0/w;)V
    .registers 6

    const-string v0, "easing"

    invoke-static {p3, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput p1, p0, La0/j1;->a:I

    .line 3
    iput p2, p0, La0/j1;->b:I

    .line 4
    iput-object p3, p0, La0/j1;->c:La0/w;

    .line 5
    new-instance v0, La0/e1;

    .line 6
    new-instance v1, La0/c0;

    invoke-direct {v1, p1, p2, p3}, La0/c0;-><init>(IILa0/w;)V

    .line 7
    invoke-direct {v0, v1}, La0/e1;-><init>(La0/z;)V

    iput-object v0, p0, La0/j1;->d:La0/e1;

    return-void
.end method


# virtual methods
.method public synthetic a()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public synthetic b(La0/n;La0/n;La0/n;)J
    .registers 4

    invoke-static {p0, p1, p2, p3}, La0/c1;->a(La0/d1;La0/n;La0/n;La0/n;)J

    move-result-wide p1

    return-wide p1
.end method

.method public c(JLa0/n;La0/n;La0/n;)La0/n;
    .registers 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JTV;TV;TV;)TV;"
        }
    .end annotation

    const-string v0, "initialValue"

    invoke-static {p3, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "targetValue"

    invoke-static {p4, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "initialVelocity"

    invoke-static {p5, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object v1, p0, La0/j1;->d:La0/e1;

    move-wide v2, p1

    move-object v4, p3

    move-object v5, p4

    move-object v6, p5

    invoke-virtual/range {v1 .. v6}, La0/e1;->c(JLa0/n;La0/n;La0/n;)La0/n;

    move-result-object p1

    return-object p1
.end method

.method public synthetic d(La0/n;La0/n;La0/n;)La0/n;
    .registers 4

    invoke-static {p0, p1, p2, p3}, La0/x0;->a(La0/y0;La0/n;La0/n;La0/n;)La0/n;

    move-result-object p1

    return-object p1
.end method

.method public e(JLa0/n;La0/n;La0/n;)La0/n;
    .registers 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JTV;TV;TV;)TV;"
        }
    .end annotation

    const-string v0, "initialValue"

    invoke-static {p3, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "targetValue"

    invoke-static {p4, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "initialVelocity"

    invoke-static {p5, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object v1, p0, La0/j1;->d:La0/e1;

    move-wide v2, p1

    move-object v4, p3

    move-object v5, p4

    move-object v6, p5

    invoke-virtual/range {v1 .. v6}, La0/e1;->e(JLa0/n;La0/n;La0/n;)La0/n;

    move-result-object p1

    return-object p1
.end method

.method public f()I
    .registers 2

    .line 1
    iget v0, p0, La0/j1;->b:I

    return v0
.end method

.method public g()I
    .registers 2

    .line 1
    iget v0, p0, La0/j1;->a:I

    return v0
.end method
