.class public final La1/k;
.super Landroidx/compose/ui/platform/e1;
.source "PainterModifier.kt"

# interfaces
.implements Lr1/s;
.implements La1/f;


# instance fields
.field public final b:Lg1/b;

.field public final c:Z

.field public final d:Ly0/a;

.field public final e:Lr1/f;

.field public final f:F

.field public final g:Ld1/t;


# direct methods
.method public constructor <init>(Lg1/b;ZLy0/a;Lr1/f;FLd1/t;Lvg/l;)V
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lg1/b;",
            "Z",
            "Ly0/a;",
            "Lr1/f;",
            "F",
            "Ld1/t;",
            "Lvg/l<",
            "-",
            "Landroidx/compose/ui/platform/d1;",
            "Lkg/l;",
            ">;)V"
        }
    .end annotation

    const-string v0, "inspectorInfo"

    invoke-static {p7, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0, p7}, Landroidx/compose/ui/platform/e1;-><init>(Lvg/l;)V

    .line 2
    iput-object p1, p0, La1/k;->b:Lg1/b;

    .line 3
    iput-boolean p2, p0, La1/k;->c:Z

    .line 4
    iput-object p3, p0, La1/k;->d:Ly0/a;

    .line 5
    iput-object p4, p0, La1/k;->e:Lr1/f;

    .line 6
    iput p5, p0, La1/k;->f:F

    .line 7
    iput-object p6, p0, La1/k;->g:Ld1/t;

    return-void
.end method


# virtual methods
.method public F(Lr1/k;Lr1/j;I)I
    .registers 6

    const-string v0, "<this>"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "measurable"

    invoke-static {p2, p1}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-virtual {p0}, La1/k;->b()Z

    move-result p1

    if-eqz p1, :cond_28

    const/16 p1, 0xd

    const/4 v0, 0x0

    .line 2
    invoke-static {v0, p3, v0, v0, p1}, Le2/z;->d(IIIII)J

    move-result-wide v0

    invoke-virtual {p0, v0, v1}, La1/k;->f(J)J

    move-result-wide v0

    .line 3
    invoke-interface {p2, p3}, Lr1/j;->d0(I)I

    move-result p1

    .line 4
    invoke-static {v0, v1}, Lp2/a;->j(J)I

    move-result p2

    invoke-static {p2, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    goto :goto_2c

    .line 5
    :cond_28
    invoke-interface {p2, p3}, Lr1/j;->d0(I)I

    move-result p1

    :goto_2c
    return p1
.end method

.method public K(Lf1/d;)V
    .registers 15

    .line 1
    iget-object v0, p0, La1/k;->b:Lg1/b;

    invoke-virtual {v0}, Lg1/b;->c()J

    move-result-wide v0

    .line 2
    invoke-virtual {p0, v0, v1}, La1/k;->d(J)Z

    move-result v2

    if-eqz v2, :cond_11

    .line 3
    invoke-static {v0, v1}, Lc1/f;->e(J)F

    move-result v2

    goto :goto_1c

    .line 4
    :cond_11
    move-object v2, p1

    check-cast v2, Lt1/o;

    invoke-virtual {v2}, Lt1/o;->c()J

    move-result-wide v2

    invoke-static {v2, v3}, Lc1/f;->e(J)F

    move-result v2

    .line 5
    :goto_1c
    invoke-virtual {p0, v0, v1}, La1/k;->c(J)Z

    move-result v3

    if-eqz v3, :cond_27

    .line 6
    invoke-static {v0, v1}, Lc1/f;->c(J)F

    move-result v0

    goto :goto_32

    .line 7
    :cond_27
    move-object v0, p1

    check-cast v0, Lt1/o;

    invoke-virtual {v0}, Lt1/o;->c()J

    move-result-wide v0

    invoke-static {v0, v1}, Lc1/f;->c(J)F

    move-result v0

    .line 8
    :goto_32
    invoke-static {v2, v0}, Landroidx/appcompat/widget/m;->j(FF)J

    move-result-wide v0

    .line 9
    move-object v2, p1

    check-cast v2, Lt1/o;

    invoke-virtual {v2}, Lt1/o;->c()J

    move-result-wide v3

    invoke-static {v3, v4}, Lc1/f;->e(J)F

    move-result v3

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    cmpg-float v3, v3, v4

    if-nez v3, :cond_4a

    const/4 v3, 0x1

    goto :goto_4b

    :cond_4a
    const/4 v3, 0x0

    :goto_4b
    if-nez v3, :cond_6d

    invoke-virtual {v2}, Lt1/o;->c()J

    move-result-wide v7

    invoke-static {v7, v8}, Lc1/f;->c(J)F

    move-result v3

    cmpg-float v3, v3, v4

    if-nez v3, :cond_5b

    const/4 v3, 0x1

    goto :goto_5c

    :cond_5b
    const/4 v3, 0x0

    :goto_5c
    if-nez v3, :cond_6d

    .line 10
    iget-object v3, p0, La1/k;->e:Lr1/f;

    invoke-virtual {v2}, Lt1/o;->c()J

    move-result-wide v7

    invoke-interface {v3, v0, v1, v7, v8}, Lr1/f;->a(JJ)J

    move-result-wide v7

    invoke-static {v0, v1, v7, v8}, La0/j;->u(JJ)J

    move-result-wide v0

    goto :goto_71

    .line 11
    :cond_6d
    sget-object v0, Lc1/f;->b:Lc1/f$a;

    .line 12
    sget-wide v0, Lc1/f;->c:J

    .line 13
    :goto_71
    iget-object v7, p0, La1/k;->d:Ly0/a;

    .line 14
    invoke-static {v0, v1}, Lc1/f;->e(J)F

    move-result v3

    invoke-static {v3}, Lab/c;->d(F)I

    move-result v3

    invoke-static {v0, v1}, Lc1/f;->c(J)F

    move-result v8

    invoke-static {v8}, Lab/c;->d(F)I

    move-result v8

    invoke-static {v3, v8}, La6/d;->c(II)J

    move-result-wide v8

    .line 15
    invoke-virtual {v2}, Lt1/o;->c()J

    move-result-wide v10

    invoke-static {v10, v11}, Lc1/f;->e(J)F

    move-result v3

    invoke-static {v3}, Lab/c;->d(F)I

    move-result v3

    invoke-virtual {v2}, Lt1/o;->c()J

    move-result-wide v10

    invoke-static {v10, v11}, Lc1/f;->c(J)F

    move-result v10

    invoke-static {v10}, Lab/c;->d(F)I

    move-result v10

    invoke-static {v3, v10}, La6/d;->c(II)J

    move-result-wide v10

    .line 16
    invoke-virtual {v2}, Lt1/o;->getLayoutDirection()Lp2/j;

    move-result-object v12

    .line 17
    invoke-interface/range {v7 .. v12}, Ly0/a;->a(JJLp2/j;)J

    move-result-wide v7

    .line 18
    invoke-static {v7, v8}, Lp2/g;->a(J)I

    move-result v3

    int-to-float v3, v3

    .line 19
    invoke-static {v7, v8}, Lp2/g;->b(J)I

    move-result v7

    int-to-float v7, v7

    .line 20
    iget-object v8, v2, Lt1/o;->a:Lf1/a;

    .line 21
    iget-object v8, v8, Lf1/a;->b:Lf1/e;

    .line 22
    invoke-interface {v8}, Lf1/e;->a()Lf1/i;

    move-result-object v8

    invoke-interface {v8, v3, v7}, Lf1/i;->c(FF)V

    .line 23
    iget-object v8, p0, La1/k;->b:Lg1/b;

    .line 24
    iget v9, p0, La1/k;->f:F

    iget-object v10, p0, La1/k;->g:Ld1/t;

    invoke-static {v8}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    iget v11, v8, Lg1/b;->d:F

    cmpg-float v11, v11, v9

    if-nez v11, :cond_d1

    const/4 v11, 0x1

    goto :goto_d2

    :cond_d1
    const/4 v11, 0x0

    :goto_d2
    if-nez v11, :cond_fb

    .line 26
    invoke-virtual {v8, v9}, Lg1/b;->a(F)Z

    move-result v11

    if-nez v11, :cond_f9

    const/high16 v11, 0x3f800000    # 1.0f

    cmpg-float v11, v9, v11

    if-nez v11, :cond_e2

    const/4 v11, 0x1

    goto :goto_e3

    :cond_e2
    const/4 v11, 0x0

    :goto_e3
    if-eqz v11, :cond_f0

    .line 27
    iget-object v11, v8, Lg1/b;->a:Ld1/b0;

    if-nez v11, :cond_ea

    goto :goto_ed

    :cond_ea
    invoke-interface {v11, v9}, Ld1/b0;->b(F)V

    .line 28
    :goto_ed
    iput-boolean v5, v8, Lg1/b;->b:Z

    goto :goto_f9

    .line 29
    :cond_f0
    invoke-virtual {v8}, Lg1/b;->d()Ld1/b0;

    move-result-object v11

    invoke-interface {v11, v9}, Ld1/b0;->b(F)V

    .line 30
    iput-boolean v6, v8, Lg1/b;->b:Z

    .line 31
    :cond_f9
    :goto_f9
    iput v9, v8, Lg1/b;->d:F

    .line 32
    :cond_fb
    iget-object v11, v8, Lg1/b;->c:Ld1/t;

    invoke-static {v11, v10}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_122

    .line 33
    invoke-virtual {v8, v10}, Lg1/b;->b(Ld1/t;)Z

    move-result v11

    if-nez v11, :cond_120

    if-nez v10, :cond_117

    .line 34
    iget-object v6, v8, Lg1/b;->a:Ld1/b0;

    if-nez v6, :cond_110

    goto :goto_114

    :cond_110
    const/4 v11, 0x0

    invoke-interface {v6, v11}, Ld1/b0;->t(Ld1/t;)V

    .line 35
    :goto_114
    iput-boolean v5, v8, Lg1/b;->b:Z

    goto :goto_120

    .line 36
    :cond_117
    invoke-virtual {v8}, Lg1/b;->d()Ld1/b0;

    move-result-object v5

    invoke-interface {v5, v10}, Ld1/b0;->t(Ld1/t;)V

    .line 37
    iput-boolean v6, v8, Lg1/b;->b:Z

    .line 38
    :cond_120
    :goto_120
    iput-object v10, v8, Lg1/b;->c:Ld1/t;

    .line 39
    :cond_122
    invoke-virtual {v2}, Lt1/o;->getLayoutDirection()Lp2/j;

    move-result-object v5

    .line 40
    iget-object v6, v8, Lg1/b;->e:Lp2/j;

    if-eq v6, v5, :cond_131

    const-string v6, "layoutDirection"

    .line 41
    invoke-static {v5, v6}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 42
    iput-object v5, v8, Lg1/b;->e:Lp2/j;

    .line 43
    :cond_131
    invoke-virtual {v2}, Lt1/o;->c()J

    move-result-wide v5

    invoke-static {v5, v6}, Lc1/f;->e(J)F

    move-result v5

    invoke-static {v0, v1}, Lc1/f;->e(J)F

    move-result v6

    sub-float/2addr v5, v6

    .line 44
    invoke-virtual {v2}, Lt1/o;->c()J

    move-result-wide v10

    invoke-static {v10, v11}, Lc1/f;->c(J)F

    move-result v6

    invoke-static {v0, v1}, Lc1/f;->c(J)F

    move-result v10

    sub-float/2addr v6, v10

    .line 45
    iget-object v10, v2, Lt1/o;->a:Lf1/a;

    .line 46
    iget-object v10, v10, Lf1/a;->b:Lf1/e;

    .line 47
    invoke-interface {v10}, Lf1/e;->a()Lf1/i;

    move-result-object v10

    invoke-interface {v10, v4, v4, v5, v6}, Lf1/i;->f(FFFF)V

    cmpl-float v9, v9, v4

    if-lez v9, :cond_1a0

    .line 48
    invoke-static {v0, v1}, Lc1/f;->e(J)F

    move-result v9

    cmpl-float v9, v9, v4

    if-lez v9, :cond_1a0

    invoke-static {v0, v1}, Lc1/f;->c(J)F

    move-result v9

    cmpl-float v4, v9, v4

    if-lez v4, :cond_1a0

    .line 49
    iget-boolean v4, v8, Lg1/b;->b:Z

    if-eqz v4, :cond_19d

    .line 50
    sget-object v4, Lc1/c;->b:Lc1/c$a;

    .line 51
    sget-wide v9, Lc1/c;->c:J

    .line 52
    invoke-static {v0, v1}, Lc1/f;->e(J)F

    move-result v4

    invoke-static {v0, v1}, Lc1/f;->c(J)F

    move-result v0

    invoke-static {v4, v0}, Landroidx/appcompat/widget/m;->j(FF)J

    move-result-wide v0

    invoke-static {v9, v10, v0, v1}, Landroidx/appcompat/widget/m;->i(JJ)Lc1/d;

    move-result-object v0

    .line 53
    iget-object v1, v2, Lt1/o;->a:Lf1/a;

    .line 54
    iget-object v1, v1, Lf1/a;->b:Lf1/e;

    .line 55
    invoke-interface {v1}, Lf1/e;->d()Ld1/p;

    move-result-object v1

    .line 56
    invoke-virtual {v8}, Lg1/b;->d()Ld1/b0;

    move-result-object v4

    .line 57
    :try_start_18e
    invoke-interface {v1, v0, v4}, Ld1/p;->h(Lc1/d;Ld1/b0;)V

    .line 58
    invoke-virtual {v8, p1}, Lg1/b;->e(Lf1/g;)V
    :try_end_194
    .catchall {:try_start_18e .. :try_end_194} :catchall_198

    .line 59
    invoke-interface {v1}, Ld1/p;->q()V

    goto :goto_1a0

    :catchall_198
    move-exception p1

    invoke-interface {v1}, Ld1/p;->q()V

    throw p1

    .line 60
    :cond_19d
    invoke-virtual {v8, p1}, Lg1/b;->e(Lf1/g;)V

    .line 61
    :cond_1a0
    :goto_1a0
    iget-object p1, v2, Lt1/o;->a:Lf1/a;

    .line 62
    iget-object p1, p1, Lf1/a;->b:Lf1/e;

    .line 63
    invoke-interface {p1}, Lf1/e;->a()Lf1/i;

    move-result-object p1

    const/high16 v0, -0x80000000

    neg-float v1, v5

    neg-float v4, v6

    invoke-interface {p1, v0, v0, v1, v4}, Lf1/i;->f(FFFF)V

    .line 64
    iget-object p1, v2, Lt1/o;->a:Lf1/a;

    .line 65
    iget-object p1, p1, Lf1/a;->b:Lf1/e;

    .line 66
    invoke-interface {p1}, Lf1/e;->a()Lf1/i;

    move-result-object p1

    neg-float v0, v3

    neg-float v1, v7

    invoke-interface {p1, v0, v1}, Lf1/i;->c(FF)V

    .line 67
    invoke-virtual {v2}, Lt1/o;->u0()V

    return-void
.end method

.method public synthetic Q(Ljava/lang/Object;Lvg/p;)Ljava/lang/Object;
    .registers 3

    invoke-static {p0, p1, p2}, Lv7/d;->b(Ly0/h$b;Ljava/lang/Object;Lvg/p;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public R(Lr1/k;Lr1/j;I)I
    .registers 6

    const-string v0, "<this>"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "measurable"

    invoke-static {p2, p1}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-virtual {p0}, La1/k;->b()Z

    move-result p1

    if-eqz p1, :cond_28

    const/16 p1, 0xd

    const/4 v0, 0x0

    .line 2
    invoke-static {v0, p3, v0, v0, p1}, Le2/z;->d(IIIII)J

    move-result-wide v0

    invoke-virtual {p0, v0, v1}, La1/k;->f(J)J

    move-result-wide v0

    .line 3
    invoke-interface {p2, p3}, Lr1/j;->k(I)I

    move-result p1

    .line 4
    invoke-static {v0, v1}, Lp2/a;->j(J)I

    move-result p2

    invoke-static {p2, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    goto :goto_2c

    .line 5
    :cond_28
    invoke-interface {p2, p3}, Lr1/j;->k(I)I

    move-result p1

    :goto_2c
    return p1
.end method

.method public final b()Z
    .registers 8

    .line 1
    iget-boolean v0, p0, La1/k;->c:Z

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_1a

    iget-object v0, p0, La1/k;->b:Lg1/b;

    invoke-virtual {v0}, Lg1/b;->c()J

    move-result-wide v3

    .line 2
    sget-object v0, Lc1/f;->b:Lc1/f$a;

    .line 3
    sget-wide v5, Lc1/f;->d:J

    cmp-long v0, v3, v5

    if-eqz v0, :cond_16

    const/4 v0, 0x1

    goto :goto_17

    :cond_16
    const/4 v0, 0x0

    :goto_17
    if-eqz v0, :cond_1a

    goto :goto_1b

    :cond_1a
    const/4 v1, 0x0

    :goto_1b
    return v1
.end method

.method public final c(J)Z
    .registers 6

    .line 1
    sget-object v0, Lc1/f;->b:Lc1/f$a;

    .line 2
    sget-wide v0, Lc1/f;->d:J

    .line 3
    invoke-static {p1, p2, v0, v1}, Lc1/f;->b(JJ)Z

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_22

    invoke-static {p1, p2}, Lc1/f;->c(J)F

    move-result p1

    invoke-static {p1}, Ljava/lang/Float;->isInfinite(F)Z

    move-result p2

    if-nez p2, :cond_1e

    invoke-static {p1}, Ljava/lang/Float;->isNaN(F)Z

    move-result p1

    if-nez p1, :cond_1e

    const/4 p1, 0x1

    goto :goto_1f

    :cond_1e
    const/4 p1, 0x0

    :goto_1f
    if-eqz p1, :cond_22

    goto :goto_23

    :cond_22
    const/4 v1, 0x0

    :goto_23
    return v1
.end method

.method public final d(J)Z
    .registers 6

    .line 1
    sget-object v0, Lc1/f;->b:Lc1/f$a;

    .line 2
    sget-wide v0, Lc1/f;->d:J

    .line 3
    invoke-static {p1, p2, v0, v1}, Lc1/f;->b(JJ)Z

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_22

    invoke-static {p1, p2}, Lc1/f;->e(J)F

    move-result p1

    invoke-static {p1}, Ljava/lang/Float;->isInfinite(F)Z

    move-result p2

    if-nez p2, :cond_1e

    invoke-static {p1}, Ljava/lang/Float;->isNaN(F)Z

    move-result p1

    if-nez p1, :cond_1e

    const/4 p1, 0x1

    goto :goto_1f

    :cond_1e
    const/4 p1, 0x0

    :goto_1f
    if-eqz p1, :cond_22

    goto :goto_23

    :cond_22
    const/4 v1, 0x0

    :goto_23
    return v1
.end method

.method public e(Lr1/k;Lr1/j;I)I
    .registers 6

    const-string v0, "<this>"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "measurable"

    invoke-static {p2, p1}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-virtual {p0}, La1/k;->b()Z

    move-result p1

    if-eqz p1, :cond_27

    const/4 p1, 0x7

    const/4 v0, 0x0

    .line 2
    invoke-static {v0, v0, v0, p3, p1}, Le2/z;->d(IIIII)J

    move-result-wide v0

    invoke-virtual {p0, v0, v1}, La1/k;->f(J)J

    move-result-wide v0

    .line 3
    invoke-interface {p2, p3}, Lr1/j;->B(I)I

    move-result p1

    .line 4
    invoke-static {v0, v1}, Lp2/a;->k(J)I

    move-result p2

    invoke-static {p2, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    goto :goto_2b

    .line 5
    :cond_27
    invoke-interface {p2, p3}, Lr1/j;->B(I)I

    move-result p1

    :goto_2b
    return p1
.end method

.method public e0(Lr1/b0;Lr1/x;J)Lr1/z;
    .registers 12

    const-string v0, "$this$measure"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "measurable"

    invoke-static {p2, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-virtual {p0, p3, p4}, La1/k;->f(J)J

    move-result-wide p3

    invoke-interface {p2, p3, p4}, Lr1/x;->K(J)Lr1/m0;

    move-result-object p2

    .line 2
    iget v1, p2, Lr1/m0;->a:I

    .line 3
    iget v2, p2, Lr1/m0;->b:I

    const/4 v3, 0x0

    .line 4
    new-instance v4, La1/k$a;

    invoke-direct {v4, p2}, La1/k$a;-><init>(Lr1/m0;)V

    const/4 v5, 0x4

    const/4 v6, 0x0

    move-object v0, p1

    invoke-static/range {v0 .. v6}, La0/i;->c(Lr1/b0;IILjava/util/Map;Lvg/l;ILjava/lang/Object;)Lr1/z;

    move-result-object p1

    return-object p1
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    instance-of v0, p1, La1/k;

    if-eqz v0, :cond_7

    check-cast p1, La1/k;

    goto :goto_8

    :cond_7
    const/4 p1, 0x0

    :goto_8
    const/4 v0, 0x0

    if-nez p1, :cond_c

    return v0

    .line 2
    :cond_c
    iget-object v1, p0, La1/k;->b:Lg1/b;

    iget-object v2, p1, La1/k;->b:Lg1/b;

    invoke-static {v1, v2}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_49

    .line 3
    iget-boolean v1, p0, La1/k;->c:Z

    iget-boolean v3, p1, La1/k;->c:Z

    if-ne v1, v3, :cond_49

    .line 4
    iget-object v1, p0, La1/k;->d:Ly0/a;

    iget-object v3, p1, La1/k;->d:Ly0/a;

    invoke-static {v1, v3}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_49

    .line 5
    iget-object v1, p0, La1/k;->e:Lr1/f;

    iget-object v3, p1, La1/k;->e:Lr1/f;

    invoke-static {v1, v3}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_49

    .line 6
    iget v1, p0, La1/k;->f:F

    iget v3, p1, La1/k;->f:F

    cmpg-float v1, v1, v3

    if-nez v1, :cond_3b

    const/4 v1, 0x1

    goto :goto_3c

    :cond_3b
    const/4 v1, 0x0

    :goto_3c
    if-eqz v1, :cond_49

    .line 7
    iget-object v1, p0, La1/k;->g:Ld1/t;

    iget-object p1, p1, La1/k;->g:Ld1/t;

    invoke-static {v1, p1}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_49

    const/4 v0, 0x1

    :cond_49
    return v0
.end method

.method public final f(J)J
    .registers 15

    .line 1
    invoke-static {p1, p2}, Lp2/a;->e(J)Z

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_10

    invoke-static {p1, p2}, Lp2/a;->d(J)Z

    move-result v0

    if-eqz v0, :cond_10

    const/4 v0, 0x1

    goto :goto_11

    :cond_10
    const/4 v0, 0x0

    .line 2
    :goto_11
    invoke-static {p1, p2}, Lp2/a;->g(J)Z

    move-result v3

    if-eqz v3, :cond_1f

    invoke-static {p1, p2}, Lp2/a;->f(J)Z

    move-result v3

    if-eqz v3, :cond_1f

    const/4 v3, 0x1

    goto :goto_20

    :cond_1f
    const/4 v3, 0x0

    .line 3
    :goto_20
    invoke-virtual {p0}, La1/k;->b()Z

    move-result v4

    if-nez v4, :cond_28

    if-nez v0, :cond_2a

    :cond_28
    if-eqz v3, :cond_3c

    .line 4
    :cond_2a
    invoke-static {p1, p2}, Lp2/a;->i(J)I

    move-result v7

    const/4 v8, 0x0

    .line 5
    invoke-static {p1, p2}, Lp2/a;->h(J)I

    move-result v9

    const/4 v10, 0x0

    const/16 v11, 0xa

    move-wide v5, p1

    .line 6
    invoke-static/range {v5 .. v11}, Lp2/a;->a(JIIIII)J

    move-result-wide p1

    return-wide p1

    .line 7
    :cond_3c
    iget-object v0, p0, La1/k;->b:Lg1/b;

    invoke-virtual {v0}, Lg1/b;->c()J

    move-result-wide v3

    .line 8
    invoke-virtual {p0, v3, v4}, La1/k;->d(J)Z

    move-result v0

    if-eqz v0, :cond_51

    .line 9
    invoke-static {v3, v4}, Lc1/f;->e(J)F

    move-result v0

    invoke-static {v0}, Lab/c;->d(F)I

    move-result v0

    goto :goto_55

    .line 10
    :cond_51
    invoke-static {p1, p2}, Lp2/a;->k(J)I

    move-result v0

    .line 11
    :goto_55
    invoke-virtual {p0, v3, v4}, La1/k;->c(J)Z

    move-result v5

    if-eqz v5, :cond_64

    .line 12
    invoke-static {v3, v4}, Lc1/f;->c(J)F

    move-result v3

    invoke-static {v3}, Lab/c;->d(F)I

    move-result v3

    goto :goto_68

    .line 13
    :cond_64
    invoke-static {p1, p2}, Lp2/a;->j(J)I

    move-result v3

    .line 14
    :goto_68
    invoke-static {p1, p2, v0}, Le2/z;->p(JI)I

    move-result v0

    .line 15
    invoke-static {p1, p2, v3}, Le2/z;->o(JI)I

    move-result v3

    int-to-float v0, v0

    int-to-float v3, v3

    .line 16
    invoke-static {v0, v3}, Landroidx/appcompat/widget/m;->j(FF)J

    move-result-wide v3

    .line 17
    invoke-virtual {p0}, La1/k;->b()Z

    move-result v0

    if-nez v0, :cond_7d

    goto :goto_e0

    .line 18
    :cond_7d
    iget-object v0, p0, La1/k;->b:Lg1/b;

    invoke-virtual {v0}, Lg1/b;->c()J

    move-result-wide v5

    invoke-virtual {p0, v5, v6}, La1/k;->d(J)Z

    move-result v0

    if-nez v0, :cond_8e

    .line 19
    invoke-static {v3, v4}, Lc1/f;->e(J)F

    move-result v0

    goto :goto_98

    .line 20
    :cond_8e
    iget-object v0, p0, La1/k;->b:Lg1/b;

    invoke-virtual {v0}, Lg1/b;->c()J

    move-result-wide v5

    invoke-static {v5, v6}, Lc1/f;->e(J)F

    move-result v0

    .line 21
    :goto_98
    iget-object v5, p0, La1/k;->b:Lg1/b;

    invoke-virtual {v5}, Lg1/b;->c()J

    move-result-wide v5

    invoke-virtual {p0, v5, v6}, La1/k;->c(J)Z

    move-result v5

    if-nez v5, :cond_a9

    .line 22
    invoke-static {v3, v4}, Lc1/f;->c(J)F

    move-result v5

    goto :goto_b3

    .line 23
    :cond_a9
    iget-object v5, p0, La1/k;->b:Lg1/b;

    invoke-virtual {v5}, Lg1/b;->c()J

    move-result-wide v5

    invoke-static {v5, v6}, Lc1/f;->c(J)F

    move-result v5

    .line 24
    :goto_b3
    invoke-static {v0, v5}, Landroidx/appcompat/widget/m;->j(FF)J

    move-result-wide v5

    .line 25
    invoke-static {v3, v4}, Lc1/f;->e(J)F

    move-result v0

    const/4 v7, 0x0

    cmpg-float v0, v0, v7

    if-nez v0, :cond_c2

    const/4 v0, 0x1

    goto :goto_c3

    :cond_c2
    const/4 v0, 0x0

    :goto_c3
    if-nez v0, :cond_dc

    invoke-static {v3, v4}, Lc1/f;->c(J)F

    move-result v0

    cmpg-float v0, v0, v7

    if-nez v0, :cond_ce

    goto :goto_cf

    :cond_ce
    const/4 v1, 0x0

    :goto_cf
    if-nez v1, :cond_dc

    .line 26
    iget-object v0, p0, La1/k;->e:Lr1/f;

    invoke-interface {v0, v5, v6, v3, v4}, Lr1/f;->a(JJ)J

    move-result-wide v0

    invoke-static {v5, v6, v0, v1}, La0/j;->u(JJ)J

    move-result-wide v3

    goto :goto_e0

    .line 27
    :cond_dc
    sget-object v0, Lc1/f;->b:Lc1/f$a;

    .line 28
    sget-wide v3, Lc1/f;->c:J

    .line 29
    :goto_e0
    invoke-static {v3, v4}, Lc1/f;->e(J)F

    move-result v0

    invoke-static {v0}, Lab/c;->d(F)I

    move-result v0

    invoke-static {p1, p2, v0}, Le2/z;->p(JI)I

    move-result v7

    .line 30
    invoke-static {v3, v4}, Lc1/f;->c(J)F

    move-result v0

    invoke-static {v0}, Lab/c;->d(F)I

    move-result v0

    invoke-static {p1, p2, v0}, Le2/z;->o(JI)I

    move-result v9

    const/4 v8, 0x0

    const/4 v10, 0x0

    const/16 v11, 0xa

    move-wide v5, p1

    .line 31
    invoke-static/range {v5 .. v11}, Lp2/a;->a(JIIIII)J

    move-result-wide p1

    return-wide p1
.end method

.method public hashCode()I
    .registers 4

    .line 1
    iget-object v0, p0, La1/k;->b:Lg1/b;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    .line 2
    iget-boolean v1, p0, La1/k;->c:Z

    if-eqz v1, :cond_f

    const/16 v1, 0x4cf

    goto :goto_11

    :cond_f
    const/16 v1, 0x4d5

    :goto_11
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    .line 3
    iget-object v1, p0, La1/k;->d:Ly0/a;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x1f

    .line 4
    iget-object v0, p0, La1/k;->e:Lr1/f;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    .line 5
    iget v1, p0, La1/k;->f:F

    const/16 v2, 0x1f

    invoke-static {v1, v0, v2}, Lc0/a0;->c(FII)I

    move-result v0

    .line 6
    iget-object v1, p0, La1/k;->g:Ld1/t;

    if-eqz v1, :cond_37

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    goto :goto_38

    :cond_37
    const/4 v1, 0x0

    :goto_38
    add-int/2addr v0, v1

    return v0
.end method

.method public synthetic p0(Ly0/h;)Ly0/h;
    .registers 2

    invoke-static {p0, p1}, Landroidx/fragment/app/n;->b(Ly0/h;Ly0/h;)Ly0/h;

    move-result-object p1

    return-object p1
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    const-string v0, "PainterModifier(painter="

    .line 1
    invoke-static {v0}, Landroid/support/v4/media/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 2
    iget-object v1, p0, La1/k;->b:Lg1/b;

    .line 3
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", sizeToIntrinsics="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4
    iget-boolean v1, p0, La1/k;->c:Z

    .line 5
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ", alignment="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 6
    iget-object v1, p0, La1/k;->d:Ly0/a;

    .line 7
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", alpha="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 8
    iget v1, p0, La1/k;->f:F

    .line 9
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v1, ", colorFilter="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 10
    iget-object v1, p0, La1/k;->g:Ld1/t;

    .line 11
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v1, 0x29

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public v(Lr1/k;Lr1/j;I)I
    .registers 6

    const-string v0, "<this>"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "measurable"

    invoke-static {p2, p1}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-virtual {p0}, La1/k;->b()Z

    move-result p1

    if-eqz p1, :cond_27

    const/4 p1, 0x7

    const/4 v0, 0x0

    .line 2
    invoke-static {v0, v0, v0, p3, p1}, Le2/z;->d(IIIII)J

    move-result-wide v0

    invoke-virtual {p0, v0, v1}, La1/k;->f(J)J

    move-result-wide v0

    .line 3
    invoke-interface {p2, p3}, Lr1/j;->z(I)I

    move-result p1

    .line 4
    invoke-static {v0, v1}, Lp2/a;->k(J)I

    move-result p2

    invoke-static {p2, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    goto :goto_2b

    .line 5
    :cond_27
    invoke-interface {p2, p3}, Lr1/j;->z(I)I

    move-result p1

    :goto_2b
    return p1
.end method

.method public synthetic v0(Ljava/lang/Object;Lvg/p;)Ljava/lang/Object;
    .registers 3

    invoke-static {p0, p1, p2}, Lv7/d;->c(Ly0/h$b;Ljava/lang/Object;Lvg/p;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public synthetic x(Lvg/l;)Z
    .registers 2

    invoke-static {p0, p1}, Lv7/d;->a(Ly0/h$b;Lvg/l;)Z

    move-result p1

    return p1
.end method
