.class public La6/u;
.super Ljava/lang/Object;
.source "LottieTask.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La6/u$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# static fields
.field public static e:Ljava/util/concurrent/Executor;


# instance fields
.field public final a:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "La6/o<",
            "TT;>;>;"
        }
    .end annotation
.end field

.field public final b:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "La6/o<",
            "Ljava/lang/Throwable;",
            ">;>;"
        }
    .end annotation
.end field

.field public final c:Landroid/os/Handler;

.field public volatile d:La6/s;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La6/s<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    .line 1
    invoke-static {}, Ljava/util/concurrent/Executors;->newCachedThreadPool()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    sput-object v0, La6/u;->e:Ljava/util/concurrent/Executor;

    return-void
.end method

.method public constructor <init>(Ljava/util/concurrent/Callable;Z)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/Callable<",
            "La6/s<",
            "TT;>;>;Z)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Ljava/util/LinkedHashSet;-><init>(I)V

    iput-object v0, p0, La6/u;->a:Ljava/util/Set;

    .line 3
    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0, v1}, Ljava/util/LinkedHashSet;-><init>(I)V

    iput-object v0, p0, La6/u;->b:Ljava/util/Set;

    .line 4
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, La6/u;->c:Landroid/os/Handler;

    const/4 v0, 0x0

    .line 5
    iput-object v0, p0, La6/u;->d:La6/s;

    if-eqz p2, :cond_36

    .line 6
    :try_start_22
    invoke-interface {p1}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La6/s;

    invoke-virtual {p0, p1}, La6/u;->c(La6/s;)V
    :try_end_2b
    .catchall {:try_start_22 .. :try_end_2b} :catchall_2c

    goto :goto_40

    :catchall_2c
    move-exception p1

    .line 7
    new-instance p2, La6/s;

    invoke-direct {p2, p1}, La6/s;-><init>(Ljava/lang/Throwable;)V

    invoke-virtual {p0, p2}, La6/u;->c(La6/s;)V

    goto :goto_40

    .line 8
    :cond_36
    sget-object p2, La6/u;->e:Ljava/util/concurrent/Executor;

    new-instance v0, La6/u$a;

    invoke-direct {v0, p0, p1}, La6/u$a;-><init>(La6/u;Ljava/util/concurrent/Callable;)V

    invoke-interface {p2, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :goto_40
    return-void
.end method


# virtual methods
.method public declared-synchronized a(La6/o;)La6/u;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La6/o<",
            "Ljava/lang/Throwable;",
            ">;)",
            "La6/u<",
            "TT;>;"
        }
    .end annotation

    monitor-enter p0

    .line 1
    :try_start_1
    iget-object v0, p0, La6/u;->d:La6/s;

    if-eqz v0, :cond_12

    iget-object v0, p0, La6/u;->d:La6/s;

    .line 2
    iget-object v0, v0, La6/s;->b:Ljava/lang/Throwable;

    if-eqz v0, :cond_12

    .line 3
    iget-object v0, p0, La6/u;->d:La6/s;

    .line 4
    iget-object v0, v0, La6/s;->b:Ljava/lang/Throwable;

    .line 5
    invoke-interface {p1, v0}, La6/o;->onResult(Ljava/lang/Object;)V

    .line 6
    :cond_12
    iget-object v0, p0, La6/u;->b:Ljava/util/Set;

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z
    :try_end_17
    .catchall {:try_start_1 .. :try_end_17} :catchall_19

    .line 7
    monitor-exit p0

    return-object p0

    :catchall_19
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public declared-synchronized b(La6/o;)La6/u;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La6/o<",
            "TT;>;)",
            "La6/u<",
            "TT;>;"
        }
    .end annotation

    monitor-enter p0

    .line 1
    :try_start_1
    iget-object v0, p0, La6/u;->d:La6/s;

    if-eqz v0, :cond_12

    iget-object v0, p0, La6/u;->d:La6/s;

    .line 2
    iget-object v0, v0, La6/s;->a:Ljava/lang/Object;

    if-eqz v0, :cond_12

    .line 3
    iget-object v0, p0, La6/u;->d:La6/s;

    .line 4
    iget-object v0, v0, La6/s;->a:Ljava/lang/Object;

    .line 5
    invoke-interface {p1, v0}, La6/o;->onResult(Ljava/lang/Object;)V

    .line 6
    :cond_12
    iget-object v0, p0, La6/u;->a:Ljava/util/Set;

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z
    :try_end_17
    .catchall {:try_start_1 .. :try_end_17} :catchall_19

    .line 7
    monitor-exit p0

    return-object p0

    :catchall_19
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final c(La6/s;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La6/s<",
            "TT;>;)V"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La6/u;->d:La6/s;

    if-nez v0, :cond_11

    .line 2
    iput-object p1, p0, La6/u;->d:La6/s;

    .line 3
    iget-object p1, p0, La6/u;->c:Landroid/os/Handler;

    new-instance v0, La6/t;

    invoke-direct {v0, p0}, La6/t;-><init>(La6/u;)V

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    .line 4
    :cond_11
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "A task may only be set once."

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
