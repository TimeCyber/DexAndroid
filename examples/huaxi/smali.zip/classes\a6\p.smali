.class public interface abstract La6/p;
.super Ljava/lang/Object;
.source "LottieLogger.java"
