.class public final Lab/e;
.super Ljava/lang/Object;
.source "PDF417HighLevelEncoder.java"


# static fields
.field public static final a:[B

.field public static final b:[B

.field public static final c:[B

.field public static final d:[B

.field public static final e:Ljava/nio/charset/Charset;


# direct methods
.method public static constructor <clinit>()V
    .registers 6

    const/16 v0, 0x1e

    new-array v1, v0, [B

    .line 1
    fill-array-data v1, :array_4c

    sput-object v1, Lab/e;->a:[B

    new-array v0, v0, [B

    .line 2
    fill-array-data v0, :array_60

    sput-object v0, Lab/e;->b:[B

    const/16 v0, 0x80

    new-array v1, v0, [B

    .line 3
    sput-object v1, Lab/e;->c:[B

    new-array v0, v0, [B

    .line 4
    sput-object v0, Lab/e;->d:[B

    .line 5
    sget-object v0, Ljava/nio/charset/StandardCharsets;->ISO_8859_1:Ljava/nio/charset/Charset;

    sput-object v0, Lab/e;->e:Ljava/nio/charset/Charset;

    const/4 v0, -0x1

    .line 6
    invoke-static {v1, v0}, Ljava/util/Arrays;->fill([BB)V

    const/4 v1, 0x0

    const/4 v2, 0x0

    .line 7
    :goto_24
    sget-object v3, Lab/e;->a:[B

    array-length v4, v3

    if-ge v2, v4, :cond_35

    .line 8
    aget-byte v3, v3, v2

    if-lez v3, :cond_32

    .line 9
    sget-object v4, Lab/e;->c:[B

    int-to-byte v5, v2

    aput-byte v5, v4, v3

    :cond_32
    add-int/lit8 v2, v2, 0x1

    goto :goto_24

    .line 10
    :cond_35
    sget-object v2, Lab/e;->d:[B

    invoke-static {v2, v0}, Ljava/util/Arrays;->fill([BB)V

    .line 11
    :goto_3a
    sget-object v0, Lab/e;->b:[B

    array-length v2, v0

    if-ge v1, v2, :cond_4b

    .line 12
    aget-byte v0, v0, v1

    if-lez v0, :cond_48

    .line 13
    sget-object v2, Lab/e;->d:[B

    int-to-byte v3, v1

    aput-byte v3, v2, v0

    :cond_48
    add-int/lit8 v1, v1, 0x1

    goto :goto_3a

    :cond_4b
    return-void

    :array_4c
    .array-data 1
        0x30t
        0x31t
        0x32t
        0x33t
        0x34t
        0x35t
        0x36t
        0x37t
        0x38t
        0x39t
        0x26t
        0xdt
        0x9t
        0x2ct
        0x3at
        0x23t
        0x2dt
        0x2et
        0x24t
        0x2ft
        0x2bt
        0x25t
        0x2at
        0x3dt
        0x5et
        0x0t
        0x20t
        0x0t
        0x0t
        0x0t
    .end array-data

    nop

    :array_60
    .array-data 1
        0x3bt
        0x3ct
        0x3et
        0x40t
        0x5bt
        0x5ct
        0x5dt
        0x5ft
        0x60t
        0x7et
        0x21t
        0xdt
        0x9t
        0x2ct
        0x3at
        0xat
        0x2dt
        0x2et
        0x24t
        0x2ft
        0x22t
        0x7ct
        0x2at
        0x28t
        0x29t
        0x3ft
        0x7bt
        0x7dt
        0x27t
        0x0t
    .end array-data
.end method

.method public static a([BIIILjava/lang/StringBuilder;)V
    .registers 15

    const/4 v0, 0x1

    if-ne p2, v0, :cond_b

    if-nez p3, :cond_b

    const/16 p3, 0x391

    .line 1
    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_1a

    .line 2
    :cond_b
    rem-int/lit8 p3, p2, 0x6

    if-nez p3, :cond_15

    const/16 p3, 0x39c

    .line 3
    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_1a

    :cond_15
    const/16 p3, 0x385

    .line 4
    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :goto_1a
    const/4 p3, 0x6

    if-lt p2, p3, :cond_56

    const/4 v0, 0x5

    new-array v1, v0, [C

    move v2, p1

    :goto_21
    add-int v3, p1, p2

    sub-int/2addr v3, v2

    if-lt v3, p3, :cond_57

    const-wide/16 v3, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    :goto_2a
    if-ge v6, p3, :cond_3a

    const/16 v7, 0x8

    shl-long/2addr v3, v7

    add-int v7, v2, v6

    .line 5
    aget-byte v7, p0, v7

    and-int/lit16 v7, v7, 0xff

    int-to-long v7, v7

    add-long/2addr v3, v7

    add-int/lit8 v6, v6, 0x1

    goto :goto_2a

    :cond_3a
    :goto_3a
    if-ge v5, v0, :cond_48

    const-wide/16 v6, 0x384

    .line 6
    rem-long v8, v3, v6

    long-to-int v9, v8

    int-to-char v8, v9

    aput-char v8, v1, v5

    .line 7
    div-long/2addr v3, v6

    add-int/lit8 v5, v5, 0x1

    goto :goto_3a

    :cond_48
    const/4 v3, 0x4

    :goto_49
    if-ltz v3, :cond_53

    .line 8
    aget-char v4, v1, v3

    invoke-virtual {p4, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    add-int/lit8 v3, v3, -0x1

    goto :goto_49

    :cond_53
    add-int/lit8 v2, v2, 0x6

    goto :goto_21

    :cond_56
    move v2, p1

    :cond_57
    :goto_57
    add-int p3, p1, p2

    if-ge v2, p3, :cond_66

    .line 9
    aget-byte p3, p0, v2

    and-int/lit16 p3, p3, 0xff

    int-to-char p3, p3

    .line 10
    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    add-int/lit8 v2, v2, 0x1

    goto :goto_57

    :cond_66
    return-void
.end method

.method public static b(Ljava/lang/String;IILjava/lang/StringBuilder;)V
    .registers 13

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    div-int/lit8 v1, p2, 0x3

    add-int/lit8 v1, v1, 0x1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const-wide/16 v1, 0x384

    .line 2
    invoke-static {v1, v2}, Ljava/math/BigInteger;->valueOf(J)Ljava/math/BigInteger;

    move-result-object v1

    const-wide/16 v2, 0x0

    .line 3
    invoke-static {v2, v3}, Ljava/math/BigInteger;->valueOf(J)Ljava/math/BigInteger;

    move-result-object v2

    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_17
    if-ge v4, p2, :cond_67

    .line 4
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->setLength(I)V

    const/16 v5, 0x2c

    sub-int v6, p2, v4

    .line 5
    invoke-static {v5, v6}, Ljava/lang/Math;->min(II)I

    move-result v5

    .line 6
    new-instance v6, Ljava/lang/StringBuilder;

    const-string v7, "1"

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    add-int v7, p1, v4

    add-int v8, v7, v5

    invoke-virtual {p0, v7, v8}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    .line 7
    new-instance v7, Ljava/math/BigInteger;

    invoke-direct {v7, v6}, Ljava/math/BigInteger;-><init>(Ljava/lang/String;)V

    .line 8
    :cond_3f
    invoke-virtual {v7, v1}, Ljava/math/BigInteger;->mod(Ljava/math/BigInteger;)Ljava/math/BigInteger;

    move-result-object v6

    invoke-virtual {v6}, Ljava/math/BigInteger;->intValue()I

    move-result v6

    int-to-char v6, v6

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 9
    invoke-virtual {v7, v1}, Ljava/math/BigInteger;->divide(Ljava/math/BigInteger;)Ljava/math/BigInteger;

    move-result-object v7

    .line 10
    invoke-virtual {v7, v2}, Ljava/math/BigInteger;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3f

    .line 11
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v6

    :goto_59
    add-int/lit8 v6, v6, -0x1

    if-ltz v6, :cond_65

    .line 12
    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->charAt(I)C

    move-result v7

    invoke-virtual {p3, v7}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_59

    :cond_65
    add-int/2addr v4, v5

    goto :goto_17

    :cond_67
    return-void
.end method

.method public static c(Ljava/lang/CharSequence;IILjava/lang/StringBuilder;I)I
    .registers 21

    move-object/from16 v0, p0

    move/from16 v1, p2

    move-object/from16 v2, p3

    .line 1
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    move/from16 v7, p4

    const/4 v8, 0x0

    :cond_11
    :goto_11
    add-int v9, p1, v8

    .line 2
    invoke-interface {v0, v9}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v10

    const/16 v11, 0x1a

    const/16 v12, 0x20

    const/16 v13, 0x1c

    const/16 v14, 0x1b

    const/16 v15, 0x1d

    if-eqz v7, :cond_c5

    if-eq v7, v6, :cond_8c

    const/4 v11, -0x1

    if-eq v7, v4, :cond_3f

    .line 3
    sget-object v9, Lab/e;->d:[B

    aget-byte v12, v9, v10

    if-eq v12, v11, :cond_30

    const/4 v11, 0x1

    goto :goto_31

    :cond_30
    const/4 v11, 0x0

    :goto_31
    if-eqz v11, :cond_3b

    .line 4
    aget-byte v9, v9, v10

    int-to-char v9, v9

    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto/16 :goto_fb

    .line 5
    :cond_3b
    invoke-virtual {v3, v15}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_58

    .line 6
    :cond_3f
    invoke-static {v10}, Lab/e;->g(C)Z

    move-result v12

    if-eqz v12, :cond_4f

    .line 7
    sget-object v9, Lab/e;->c:[B

    aget-byte v9, v9, v10

    int-to-char v9, v9

    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto/16 :goto_fb

    .line 8
    :cond_4f
    invoke-static {v10}, Lab/e;->e(C)Z

    move-result v12

    if-eqz v12, :cond_5a

    .line 9
    invoke-virtual {v3, v13}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :goto_58
    const/4 v7, 0x0

    goto :goto_11

    .line 10
    :cond_5a
    invoke-static {v10}, Lab/e;->d(C)Z

    move-result v12

    if-eqz v12, :cond_65

    .line 11
    invoke-virtual {v3, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto/16 :goto_e1

    :cond_65
    add-int/lit8 v9, v9, 0x1

    if-ge v9, v1, :cond_7f

    .line 12
    invoke-interface {v0, v9}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v9

    .line 13
    sget-object v12, Lab/e;->d:[B

    aget-byte v9, v12, v9

    if-eq v9, v11, :cond_75

    const/4 v9, 0x1

    goto :goto_76

    :cond_75
    const/4 v9, 0x0

    :goto_76
    if-eqz v9, :cond_7f

    const/4 v7, 0x3

    const/16 v9, 0x19

    .line 14
    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_11

    .line 15
    :cond_7f
    invoke-virtual {v3, v15}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 16
    sget-object v9, Lab/e;->d:[B

    aget-byte v9, v9, v10

    int-to-char v9, v9

    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto/16 :goto_fb

    .line 17
    :cond_8c
    invoke-static {v10}, Lab/e;->d(C)Z

    move-result v9

    if-eqz v9, :cond_9f

    if-ne v10, v12, :cond_98

    .line 18
    invoke-virtual {v3, v11}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_fb

    :cond_98
    add-int/lit8 v10, v10, -0x61

    int-to-char v9, v10

    .line 19
    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_fb

    .line 20
    :cond_9f
    invoke-static {v10}, Lab/e;->e(C)Z

    move-result v9

    if-eqz v9, :cond_af

    .line 21
    invoke-virtual {v3, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    add-int/lit8 v10, v10, -0x41

    int-to-char v9, v10

    .line 22
    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_fb

    .line 23
    :cond_af
    invoke-static {v10}, Lab/e;->g(C)Z

    move-result v9

    if-eqz v9, :cond_b9

    .line 24
    invoke-virtual {v3, v13}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_ed

    .line 25
    :cond_b9
    invoke-virtual {v3, v15}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 26
    sget-object v9, Lab/e;->d:[B

    aget-byte v9, v9, v10

    int-to-char v9, v9

    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_fb

    .line 27
    :cond_c5
    invoke-static {v10}, Lab/e;->e(C)Z

    move-result v9

    if-eqz v9, :cond_d8

    if-ne v10, v12, :cond_d1

    .line 28
    invoke-virtual {v3, v11}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_fb

    :cond_d1
    add-int/lit8 v10, v10, -0x41

    int-to-char v9, v10

    .line 29
    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_fb

    .line 30
    :cond_d8
    invoke-static {v10}, Lab/e;->d(C)Z

    move-result v9

    if-eqz v9, :cond_e4

    .line 31
    invoke-virtual {v3, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :goto_e1
    const/4 v7, 0x1

    goto/16 :goto_11

    .line 32
    :cond_e4
    invoke-static {v10}, Lab/e;->g(C)Z

    move-result v9

    if-eqz v9, :cond_f0

    .line 33
    invoke-virtual {v3, v13}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :goto_ed
    const/4 v7, 0x2

    goto/16 :goto_11

    .line 34
    :cond_f0
    invoke-virtual {v3, v15}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 35
    sget-object v9, Lab/e;->d:[B

    aget-byte v9, v9, v10

    int-to-char v9, v9

    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :goto_fb
    add-int/lit8 v8, v8, 0x1

    if-lt v8, v1, :cond_11

    .line 36
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->length()I

    move-result v0

    const/4 v1, 0x0

    const/4 v8, 0x0

    :goto_105
    if-ge v1, v0, :cond_123

    .line 37
    rem-int/lit8 v9, v1, 0x2

    if-eqz v9, :cond_10d

    const/4 v9, 0x1

    goto :goto_10e

    :cond_10d
    const/4 v9, 0x0

    :goto_10e
    if-eqz v9, :cond_11c

    mul-int/lit8 v8, v8, 0x1e

    .line 38
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->charAt(I)C

    move-result v9

    add-int/2addr v9, v8

    int-to-char v8, v9

    .line 39
    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_120

    .line 40
    :cond_11c
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->charAt(I)C

    move-result v8

    :goto_120
    add-int/lit8 v1, v1, 0x1

    goto :goto_105

    .line 41
    :cond_123
    rem-int/2addr v0, v4

    if-eqz v0, :cond_12d

    mul-int/lit8 v8, v8, 0x1e

    add-int/2addr v8, v15

    int-to-char v0, v8

    .line 42
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_12d
    return v7
.end method

.method public static d(C)Z
    .registers 2

    const/16 v0, 0x20

    if-eq p0, v0, :cond_f

    const/16 v0, 0x61

    if-lt p0, v0, :cond_d

    const/16 v0, 0x7a

    if-gt p0, v0, :cond_d

    goto :goto_f

    :cond_d
    const/4 p0, 0x0

    return p0

    :cond_f
    :goto_f
    const/4 p0, 0x1

    return p0
.end method

.method public static e(C)Z
    .registers 2

    const/16 v0, 0x20

    if-eq p0, v0, :cond_f

    const/16 v0, 0x41

    if-lt p0, v0, :cond_d

    const/16 v0, 0x5a

    if-gt p0, v0, :cond_d

    goto :goto_f

    :cond_d
    const/4 p0, 0x0

    return p0

    :cond_f
    :goto_f
    const/4 p0, 0x1

    return p0
.end method

.method public static f(C)Z
    .registers 2

    const/16 v0, 0x30

    if-lt p0, v0, :cond_a

    const/16 v0, 0x39

    if-gt p0, v0, :cond_a

    const/4 p0, 0x1

    return p0

    :cond_a
    const/4 p0, 0x0

    return p0
.end method

.method public static g(C)Z
    .registers 2

    .line 1
    sget-object v0, Lab/e;->c:[B

    aget-byte p0, v0, p0

    const/4 v0, -0x1

    if-eq p0, v0, :cond_9

    const/4 p0, 0x1

    return p0

    :cond_9
    const/4 p0, 0x0

    return p0
.end method
