.class public interface abstract La0/d1;
.super Ljava/lang/Object;
.source "VectorizedAnimationSpec.kt"

# interfaces
.implements La0/y0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<V:",
        "La0/n;",
        ">",
        "Ljava/lang/Object;",
        "La0/y0;"
    }
.end annotation


# virtual methods
.method public abstract f()I
.end method

.method public abstract g()I
.end method
