.class public final La0/b;
.super Ljava/lang/Object;
.source "Animatable.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "V:",
        "La0/n;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field public final a:La0/u0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/u0<",
            "TT;TV;>;"
        }
    .end annotation
.end field

.field public final b:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field

.field public final c:La0/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/h<",
            "TT;TV;>;"
        }
    .end annotation
.end field

.field public final d:Lm0/x0;

.field public final e:Lm0/x0;

.field public final f:La0/g0;

.field public final g:La0/n0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/n0<",
            "TT;>;"
        }
    .end annotation
.end field

.field public final h:La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field

.field public final i:La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field

.field public j:La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field

.field public k:La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/Object;La0/u0;Ljava/lang/Object;)V
    .registers 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "La0/u0<",
            "TT;TV;>;TT;)V"
        }
    .end annotation

    const-string v0, "typeConverter"

    invoke-static {p2, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p2, p0, La0/b;->a:La0/u0;

    .line 3
    iput-object p3, p0, La0/b;->b:Ljava/lang/Object;

    .line 4
    new-instance v0, La0/h;

    const/4 v4, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v7, 0x0

    const/4 v9, 0x0

    const/16 v10, 0x3c

    move-object v1, v0

    move-object v2, p2

    move-object v3, p1

    invoke-direct/range {v1 .. v10}, La0/h;-><init>(La0/u0;Ljava/lang/Object;La0/n;JJZI)V

    iput-object v0, p0, La0/b;->c:La0/h;

    .line 5
    sget-object p2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-static {p2, v0, v1, v0}, Landroidx/appcompat/widget/m;->L(Ljava/lang/Object;Lm0/c2;ILjava/lang/Object;)Lm0/x0;

    move-result-object p2

    iput-object p2, p0, La0/b;->d:Lm0/x0;

    .line 6
    invoke-static {p1, v0, v1, v0}, Landroidx/appcompat/widget/m;->L(Ljava/lang/Object;Lm0/c2;ILjava/lang/Object;)Lm0/x0;

    move-result-object p2

    iput-object p2, p0, La0/b;->e:Lm0/x0;

    .line 7
    new-instance p2, La0/g0;

    invoke-direct {p2}, La0/g0;-><init>()V

    iput-object p2, p0, La0/b;->f:La0/g0;

    .line 8
    new-instance p2, La0/n0;

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p2, v0, v0, p3, v1}, La0/n0;-><init>(FFLjava/lang/Object;I)V

    iput-object p2, p0, La0/b;->g:La0/n0;

    const/high16 p2, -0x800000    # Float.NEGATIVE_INFINITY

    .line 9
    invoke-virtual {p0, p1, p2}, La0/b;->d(Ljava/lang/Object;F)La0/n;

    move-result-object p2

    iput-object p2, p0, La0/b;->h:La0/n;

    const/high16 p3, 0x7f800000    # Float.POSITIVE_INFINITY

    .line 10
    invoke-virtual {p0, p1, p3}, La0/b;->d(Ljava/lang/Object;F)La0/n;

    move-result-object p1

    iput-object p1, p0, La0/b;->i:La0/n;

    .line 11
    iput-object p2, p0, La0/b;->j:La0/n;

    .line 12
    iput-object p1, p0, La0/b;->k:La0/n;

    return-void
.end method

.method public static final a(La0/b;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    .line 1
    iget-object v0, p0, La0/b;->j:La0/n;

    iget-object v1, p0, La0/b;->h:La0/n;

    invoke-static {v0, v1}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15

    .line 2
    iget-object v0, p0, La0/b;->k:La0/n;

    iget-object v1, p0, La0/b;->i:La0/n;

    invoke-static {v0, v1}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15

    goto :goto_6c

    .line 3
    :cond_15
    iget-object v0, p0, La0/b;->a:La0/u0;

    invoke-interface {v0}, La0/u0;->a()Lvg/l;

    move-result-object v0

    invoke-interface {v0, p1}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La0/n;

    .line 4
    invoke-virtual {v0}, La0/n;->b()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_27
    if-ge v2, v1, :cond_60

    .line 5
    invoke-virtual {v0, v2}, La0/n;->a(I)F

    move-result v4

    iget-object v5, p0, La0/b;->j:La0/n;

    invoke-virtual {v5, v2}, La0/n;->a(I)F

    move-result v5

    cmpg-float v4, v4, v5

    if-ltz v4, :cond_45

    invoke-virtual {v0, v2}, La0/n;->a(I)F

    move-result v4

    iget-object v5, p0, La0/b;->k:La0/n;

    invoke-virtual {v5, v2}, La0/n;->a(I)F

    move-result v5

    cmpl-float v4, v4, v5

    if-lez v4, :cond_5d

    .line 6
    :cond_45
    invoke-virtual {v0, v2}, La0/n;->a(I)F

    move-result v3

    iget-object v4, p0, La0/b;->j:La0/n;

    invoke-virtual {v4, v2}, La0/n;->a(I)F

    move-result v4

    iget-object v5, p0, La0/b;->k:La0/n;

    invoke-virtual {v5, v2}, La0/n;->a(I)F

    move-result v5

    invoke-static {v3, v4, v5}, Li0/z0;->l(FFF)F

    move-result v3

    .line 7
    invoke-virtual {v0, v2, v3}, La0/n;->e(IF)V

    const/4 v3, 0x1

    :cond_5d
    add-int/lit8 v2, v2, 0x1

    goto :goto_27

    :cond_60
    if-eqz v3, :cond_6c

    .line 8
    iget-object p0, p0, La0/b;->a:La0/u0;

    invoke-interface {p0}, La0/u0;->b()Lvg/l;

    move-result-object p0

    invoke-interface {p0, v0}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    :cond_6c
    :goto_6c
    return-object p1
.end method

.method public static final b(La0/b;)V
    .registers 4

    .line 1
    iget-object v0, p0, La0/b;->c:La0/h;

    .line 2
    iget-object v1, v0, La0/h;->c:La0/n;

    .line 3
    invoke-virtual {v1}, La0/n;->d()V

    const-wide/high16 v1, -0x8000000000000000L

    .line 4
    iput-wide v1, v0, La0/h;->d:J

    .line 5
    iget-object p0, p0, La0/b;->d:Lm0/x0;

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 6
    invoke-interface {p0, v0}, Lm0/x0;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method public static c(La0/b;Ljava/lang/Object;La0/g;Ljava/lang/Object;Lvg/l;Log/d;I)Ljava/lang/Object;
    .registers 21

    move-object v1, p0

    and-int/lit8 v0, p6, 0x2

    if-eqz v0, :cond_9

    .line 1
    iget-object v0, v1, La0/b;->g:La0/n0;

    move-object v3, v0

    goto :goto_b

    :cond_9
    move-object/from16 v3, p2

    :goto_b
    and-int/lit8 v0, p6, 0x4

    const/4 v8, 0x0

    if-eqz v0, :cond_20

    .line 2
    iget-object v0, v1, La0/b;->a:La0/u0;

    invoke-interface {v0}, La0/u0;->b()Lvg/l;

    move-result-object v0

    .line 3
    iget-object v2, v1, La0/b;->c:La0/h;

    .line 4
    iget-object v2, v2, La0/h;->c:La0/n;

    .line 5
    invoke-interface {v0, v2}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    move-object v9, v0

    goto :goto_21

    :cond_20
    move-object v9, v8

    :goto_21
    and-int/lit8 v0, p6, 0x8

    if-eqz v0, :cond_27

    move-object v10, v8

    goto :goto_29

    :cond_27
    move-object/from16 v10, p4

    .line 6
    :goto_29
    invoke-virtual {p0}, La0/b;->f()Ljava/lang/Object;

    move-result-object v5

    .line 7
    iget-object v4, v1, La0/b;->a:La0/u0;

    const-string v0, "animationSpec"

    .line 8
    invoke-static {v3, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "typeConverter"

    invoke-static {v4, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    new-instance v11, La0/r0;

    .line 10
    invoke-interface {v4}, La0/u0;->a()Lvg/l;

    move-result-object v0

    invoke-interface {v0, v9}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    move-object v7, v0

    check-cast v7, La0/n;

    move-object v2, v11

    move-object v6, p1

    .line 11
    invoke-direct/range {v2 .. v7}, La0/r0;-><init>(La0/g;La0/u0;Ljava/lang/Object;Ljava/lang/Object;La0/n;)V

    .line 12
    iget-object v0, v1, La0/b;->c:La0/h;

    .line 13
    iget-wide v4, v0, La0/h;->d:J

    .line 14
    iget-object v12, v1, La0/b;->f:La0/g0;

    new-instance v13, La0/a;

    const/4 v7, 0x0

    move-object v0, v13

    move-object v1, p0

    move-object v2, v9

    move-object v3, v11

    move-object v6, v10

    invoke-direct/range {v0 .. v7}, La0/a;-><init>(La0/b;Ljava/lang/Object;La0/c;JLvg/l;Log/d;)V

    const/4 v0, 0x1

    .line 15
    invoke-static {v12}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    new-instance v1, La0/h0;

    invoke-direct {v1, v0, v12, v13, v8}, La0/h0;-><init>(ILa0/g0;Lvg/l;Log/d;)V

    move-object/from16 v0, p5

    invoke-static {v1, v0}, Lp/h;->u(Lvg/p;Log/d;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public final d(Ljava/lang/Object;F)La0/n;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;F)TV;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La0/b;->a:La0/u0;

    invoke-interface {v0}, La0/u0;->a()Lvg/l;

    move-result-object v0

    invoke-interface {v0, p1}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La0/n;

    .line 2
    invoke-virtual {p1}, La0/n;->b()I

    move-result v0

    const/4 v1, 0x0

    :goto_11
    if-ge v1, v0, :cond_19

    .line 3
    invoke-virtual {p1, v1, p2}, La0/n;->e(IF)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_11

    :cond_19
    return-object p1
.end method

.method public final e()Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La0/b;->e:Lm0/x0;

    .line 2
    invoke-interface {v0}, Lm0/g2;->getValue()Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final f()Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La0/b;->c:La0/h;

    invoke-virtual {v0}, La0/h;->getValue()Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final g(Ljava/lang/Object;Log/d;)Ljava/lang/Object;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Log/d<",
            "-",
            "Lkg/l;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La0/b;->f:La0/g0;

    new-instance v1, La0/b$a;

    const/4 v2, 0x0

    invoke-direct {v1, p0, p1, v2}, La0/b$a;-><init>(La0/b;Ljava/lang/Object;Log/d;)V

    .line 2
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 3
    new-instance p1, La0/h0;

    const/4 v3, 0x1

    invoke-direct {p1, v3, v0, v1, v2}, La0/h0;-><init>(ILa0/g0;Lvg/l;Log/d;)V

    invoke-static {p1, p2}, Lp/h;->u(Lvg/p;Log/d;)Ljava/lang/Object;

    move-result-object p1

    .line 4
    sget-object p2, Lpg/a;->a:Lpg/a;

    if-ne p1, p2, :cond_1a

    return-object p1

    :cond_1a
    sget-object p1, Lkg/l;->a:Lkg/l;

    return-object p1
.end method
