.class public final La1/g;
.super Ljava/lang/Object;
.source "DrawModifier.kt"


# direct methods
.method public static final a(Ly0/h;Lvg/l;)Ly0/h;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ly0/h;",
            "Lvg/l<",
            "-",
            "Lf1/g;",
            "Lkg/l;",
            ">;)",
            "Ly0/h;"
        }
    .end annotation

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    new-instance v0, La1/c;

    .line 2
    sget-object v1, Landroidx/compose/ui/platform/b1;->a:Lvg/l;

    .line 3
    sget-object v1, Landroidx/compose/ui/platform/b1;->a:Lvg/l;

    .line 4
    invoke-direct {v0, p1, v1}, La1/c;-><init>(Lvg/l;Lvg/l;)V

    .line 5
    invoke-interface {p0, v0}, Ly0/h;->p0(Ly0/h;)Ly0/h;

    move-result-object p0

    return-object p0
.end method

.method public static final b(Ly0/h;Lvg/l;)Ly0/h;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ly0/h;",
            "Lvg/l<",
            "-",
            "La1/b;",
            "La1/h;",
            ">;)",
            "Ly0/h;"
        }
    .end annotation

    .line 1
    sget-object v0, Landroidx/compose/ui/platform/b1;->a:Lvg/l;

    .line 2
    sget-object v0, Landroidx/compose/ui/platform/b1;->a:Lvg/l;

    .line 3
    new-instance v1, La1/g$a;

    invoke-direct {v1, p1}, La1/g$a;-><init>(Lvg/l;)V

    invoke-static {p0, v0, v1}, Ly0/g;->a(Ly0/h;Lvg/l;Lvg/q;)Ly0/h;

    move-result-object p0

    return-object p0
.end method
