.class public final Landroidx/appcompat/view/menu/b;
.super Ll/d;
.source "CascadingMenuPopup.java"

# interfaces
.implements Landroid/view/View$OnKeyListener;
.implements Landroid/widget/PopupWindow$OnDismissListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/view/menu/b$d;
    }
.end annotation


# static fields
.field public static final B:I


# instance fields
.field public A:Z

.field public final b:Landroid/content/Context;

.field public final c:I

.field public final d:I

.field public final e:I

.field public final f:Z

.field public final g:Landroid/os/Handler;

.field public final h:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Landroidx/appcompat/view/menu/e;",
            ">;"
        }
    .end annotation
.end field

.field public final i:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Landroidx/appcompat/view/menu/b$d;",
            ">;"
        }
    .end annotation
.end field

.field public final j:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

.field public final k:Landroid/view/View$OnAttachStateChangeListener;

.field public final l:Landroidx/appcompat/widget/g0;

.field public m:I

.field public n:I

.field public o:Landroid/view/View;

.field public p:Landroid/view/View;

.field public q:I

.field public r:Z

.field public s:Z

.field public t:I

.field public u:I

.field public v:Z

.field public w:Z

.field public x:Landroidx/appcompat/view/menu/i$a;

.field public y:Landroid/view/ViewTreeObserver;

.field public z:Landroid/widget/PopupWindow$OnDismissListener;


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    .line 1
    sget v0, Landroidx/appcompat/R$layout;->abc_cascading_menu_item_layout:I

    sput v0, Landroidx/appcompat/view/menu/b;->B:I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/view/View;IIZ)V
    .registers 7

    .line 1
    invoke-direct {p0}, Ll/d;-><init>()V

    .line 2
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/appcompat/view/menu/b;->h:Ljava/util/List;

    .line 3
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/appcompat/view/menu/b;->i:Ljava/util/List;

    .line 4
    new-instance v0, Landroidx/appcompat/view/menu/b$a;

    invoke-direct {v0, p0}, Landroidx/appcompat/view/menu/b$a;-><init>(Landroidx/appcompat/view/menu/b;)V

    iput-object v0, p0, Landroidx/appcompat/view/menu/b;->j:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    .line 5
    new-instance v0, Landroidx/appcompat/view/menu/b$b;

    invoke-direct {v0, p0}, Landroidx/appcompat/view/menu/b$b;-><init>(Landroidx/appcompat/view/menu/b;)V

    iput-object v0, p0, Landroidx/appcompat/view/menu/b;->k:Landroid/view/View$OnAttachStateChangeListener;

    .line 6
    new-instance v0, Landroidx/appcompat/view/menu/b$c;

    invoke-direct {v0, p0}, Landroidx/appcompat/view/menu/b$c;-><init>(Landroidx/appcompat/view/menu/b;)V

    iput-object v0, p0, Landroidx/appcompat/view/menu/b;->l:Landroidx/appcompat/widget/g0;

    const/4 v0, 0x0

    .line 7
    iput v0, p0, Landroidx/appcompat/view/menu/b;->m:I

    .line 8
    iput v0, p0, Landroidx/appcompat/view/menu/b;->n:I

    .line 9
    iput-object p1, p0, Landroidx/appcompat/view/menu/b;->b:Landroid/content/Context;

    .line 10
    iput-object p2, p0, Landroidx/appcompat/view/menu/b;->o:Landroid/view/View;

    .line 11
    iput p3, p0, Landroidx/appcompat/view/menu/b;->d:I

    .line 12
    iput p4, p0, Landroidx/appcompat/view/menu/b;->e:I

    .line 13
    iput-boolean p5, p0, Landroidx/appcompat/view/menu/b;->f:Z

    .line 14
    iput-boolean v0, p0, Landroidx/appcompat/view/menu/b;->v:Z

    .line 15
    sget-object p3, Ll3/d0;->a:Ljava/util/WeakHashMap;

    .line 16
    invoke-static {p2}, Ll3/d0$e;->d(Landroid/view/View;)I

    move-result p2

    const/4 p3, 0x1

    if-ne p2, p3, :cond_41

    goto :goto_42

    :cond_41
    const/4 v0, 0x1

    .line 17
    :goto_42
    iput v0, p0, Landroidx/appcompat/view/menu/b;->q:I

    .line 18
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    .line 19
    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p2

    iget p2, p2, Landroid/util/DisplayMetrics;->widthPixels:I

    div-int/lit8 p2, p2, 0x2

    sget p3, Landroidx/appcompat/R$dimen;->abc_config_prefDialogWidth:I

    .line 20
    invoke-virtual {p1, p3}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p1

    .line 21
    invoke-static {p2, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    iput p1, p0, Landroidx/appcompat/view/menu/b;->c:I

    .line 22
    new-instance p1, Landroid/os/Handler;

    invoke-direct {p1}, Landroid/os/Handler;-><init>()V

    iput-object p1, p0, Landroidx/appcompat/view/menu/b;->g:Landroid/os/Handler;

    return-void
.end method


# virtual methods
.method public a()Z
    .registers 3

    .line 1
    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->i:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    if-lez v0, :cond_1a

    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->i:Ljava/util/List;

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/appcompat/view/menu/b$d;

    iget-object v0, v0, Landroidx/appcompat/view/menu/b$d;->a:Landroidx/appcompat/widget/MenuPopupWindow;

    invoke-virtual {v0}, Landroidx/appcompat/widget/f0;->a()Z

    move-result v0

    if-eqz v0, :cond_1a

    const/4 v1, 0x1

    :cond_1a
    return v1
.end method

.method public b(Landroidx/appcompat/view/menu/e;Z)V
    .registers 9

    .line 1
    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->i:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_8
    if-ge v2, v0, :cond_1a

    .line 2
    iget-object v3, p0, Landroidx/appcompat/view/menu/b;->i:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/appcompat/view/menu/b$d;

    .line 3
    iget-object v3, v3, Landroidx/appcompat/view/menu/b$d;->b:Landroidx/appcompat/view/menu/e;

    if-ne p1, v3, :cond_17

    goto :goto_1b

    :cond_17
    add-int/lit8 v2, v2, 0x1

    goto :goto_8

    :cond_1a
    const/4 v2, -0x1

    :goto_1b
    if-gez v2, :cond_1e

    return-void

    :cond_1e
    add-int/lit8 v0, v2, 0x1

    .line 4
    iget-object v3, p0, Landroidx/appcompat/view/menu/b;->i:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    if-ge v0, v3, :cond_35

    .line 5
    iget-object v3, p0, Landroidx/appcompat/view/menu/b;->i:Ljava/util/List;

    invoke-interface {v3, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/appcompat/view/menu/b$d;

    .line 6
    iget-object v0, v0, Landroidx/appcompat/view/menu/b$d;->b:Landroidx/appcompat/view/menu/e;

    invoke-virtual {v0, v1}, Landroidx/appcompat/view/menu/e;->c(Z)V

    .line 7
    :cond_35
    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->i:Ljava/util/List;

    invoke-interface {v0, v2}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/appcompat/view/menu/b$d;

    .line 8
    iget-object v2, v0, Landroidx/appcompat/view/menu/b$d;->b:Landroidx/appcompat/view/menu/e;

    invoke-virtual {v2, p0}, Landroidx/appcompat/view/menu/e;->t(Landroidx/appcompat/view/menu/i;)V

    .line 9
    iget-boolean v2, p0, Landroidx/appcompat/view/menu/b;->A:Z

    const/4 v3, 0x0

    if-eqz v2, :cond_5e

    .line 10
    iget-object v2, v0, Landroidx/appcompat/view/menu/b$d;->a:Landroidx/appcompat/widget/MenuPopupWindow;

    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v5, 0x17

    if-lt v4, v5, :cond_57

    .line 12
    iget-object v2, v2, Landroidx/appcompat/widget/f0;->y:Landroid/widget/PopupWindow;

    invoke-static {v2, v3}, Landroidx/appcompat/widget/MenuPopupWindow$a;->b(Landroid/widget/PopupWindow;Landroid/transition/Transition;)V

    .line 13
    :cond_57
    iget-object v2, v0, Landroidx/appcompat/view/menu/b$d;->a:Landroidx/appcompat/widget/MenuPopupWindow;

    .line 14
    iget-object v2, v2, Landroidx/appcompat/widget/f0;->y:Landroid/widget/PopupWindow;

    invoke-virtual {v2, v1}, Landroid/widget/PopupWindow;->setAnimationStyle(I)V

    .line 15
    :cond_5e
    iget-object v0, v0, Landroidx/appcompat/view/menu/b$d;->a:Landroidx/appcompat/widget/MenuPopupWindow;

    invoke-virtual {v0}, Landroidx/appcompat/widget/f0;->dismiss()V

    .line 16
    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->i:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x1

    if-lez v0, :cond_7b

    .line 17
    iget-object v4, p0, Landroidx/appcompat/view/menu/b;->i:Ljava/util/List;

    add-int/lit8 v5, v0, -0x1

    invoke-interface {v4, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroidx/appcompat/view/menu/b$d;

    iget v4, v4, Landroidx/appcompat/view/menu/b$d;->c:I

    iput v4, p0, Landroidx/appcompat/view/menu/b;->q:I

    goto :goto_8a

    .line 18
    :cond_7b
    iget-object v4, p0, Landroidx/appcompat/view/menu/b;->o:Landroid/view/View;

    sget-object v5, Ll3/d0;->a:Ljava/util/WeakHashMap;

    .line 19
    invoke-static {v4}, Ll3/d0$e;->d(Landroid/view/View;)I

    move-result v4

    if-ne v4, v2, :cond_87

    const/4 v4, 0x0

    goto :goto_88

    :cond_87
    const/4 v4, 0x1

    .line 20
    :goto_88
    iput v4, p0, Landroidx/appcompat/view/menu/b;->q:I

    :goto_8a
    if-nez v0, :cond_b6

    .line 21
    invoke-virtual {p0}, Landroidx/appcompat/view/menu/b;->dismiss()V

    .line 22
    iget-object p2, p0, Landroidx/appcompat/view/menu/b;->x:Landroidx/appcompat/view/menu/i$a;

    if-eqz p2, :cond_96

    .line 23
    invoke-interface {p2, p1, v2}, Landroidx/appcompat/view/menu/i$a;->b(Landroidx/appcompat/view/menu/e;Z)V

    .line 24
    :cond_96
    iget-object p1, p0, Landroidx/appcompat/view/menu/b;->y:Landroid/view/ViewTreeObserver;

    if-eqz p1, :cond_a9

    .line 25
    invoke-virtual {p1}, Landroid/view/ViewTreeObserver;->isAlive()Z

    move-result p1

    if-eqz p1, :cond_a7

    .line 26
    iget-object p1, p0, Landroidx/appcompat/view/menu/b;->y:Landroid/view/ViewTreeObserver;

    iget-object p2, p0, Landroidx/appcompat/view/menu/b;->j:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    invoke-virtual {p1, p2}, Landroid/view/ViewTreeObserver;->removeGlobalOnLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 27
    :cond_a7
    iput-object v3, p0, Landroidx/appcompat/view/menu/b;->y:Landroid/view/ViewTreeObserver;

    .line 28
    :cond_a9
    iget-object p1, p0, Landroidx/appcompat/view/menu/b;->p:Landroid/view/View;

    iget-object p2, p0, Landroidx/appcompat/view/menu/b;->k:Landroid/view/View$OnAttachStateChangeListener;

    invoke-virtual {p1, p2}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 29
    iget-object p1, p0, Landroidx/appcompat/view/menu/b;->z:Landroid/widget/PopupWindow$OnDismissListener;

    invoke-interface {p1}, Landroid/widget/PopupWindow$OnDismissListener;->onDismiss()V

    goto :goto_c5

    :cond_b6
    if-eqz p2, :cond_c5

    .line 30
    iget-object p1, p0, Landroidx/appcompat/view/menu/b;->i:Ljava/util/List;

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroidx/appcompat/view/menu/b$d;

    .line 31
    iget-object p1, p1, Landroidx/appcompat/view/menu/b$d;->b:Landroidx/appcompat/view/menu/e;

    invoke-virtual {p1, v1}, Landroidx/appcompat/view/menu/e;->c(Z)V

    :cond_c5
    :goto_c5
    return-void
.end method

.method public c(Z)V
    .registers 4

    .line 1
    iget-object p1, p0, Landroidx/appcompat/view/menu/b;->i:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_6
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_2d

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/appcompat/view/menu/b$d;

    .line 2
    iget-object v0, v0, Landroidx/appcompat/view/menu/b$d;->a:Landroidx/appcompat/widget/MenuPopupWindow;

    .line 3
    iget-object v0, v0, Landroidx/appcompat/widget/f0;->c:Landroidx/appcompat/widget/b0;

    .line 4
    invoke-virtual {v0}, Landroid/widget/ListView;->getAdapter()Landroid/widget/ListAdapter;

    move-result-object v0

    .line 5
    instance-of v1, v0, Landroid/widget/HeaderViewListAdapter;

    if-eqz v1, :cond_27

    .line 6
    check-cast v0, Landroid/widget/HeaderViewListAdapter;

    invoke-virtual {v0}, Landroid/widget/HeaderViewListAdapter;->getWrappedAdapter()Landroid/widget/ListAdapter;

    move-result-object v0

    check-cast v0, Landroidx/appcompat/view/menu/d;

    goto :goto_29

    .line 7
    :cond_27
    check-cast v0, Landroidx/appcompat/view/menu/d;

    .line 8
    :goto_29
    invoke-virtual {v0}, Landroidx/appcompat/view/menu/d;->notifyDataSetChanged()V

    goto :goto_6

    :cond_2d
    return-void
.end method

.method public d()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public dismiss()V
    .registers 5

    .line 1
    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->i:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-lez v0, :cond_28

    .line 2
    iget-object v1, p0, Landroidx/appcompat/view/menu/b;->i:Ljava/util/List;

    new-array v2, v0, [Landroidx/appcompat/view/menu/b$d;

    .line 3
    invoke-interface {v1, v2}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Landroidx/appcompat/view/menu/b$d;

    add-int/lit8 v0, v0, -0x1

    :goto_14
    if-ltz v0, :cond_28

    .line 4
    aget-object v2, v1, v0

    .line 5
    iget-object v3, v2, Landroidx/appcompat/view/menu/b$d;->a:Landroidx/appcompat/widget/MenuPopupWindow;

    invoke-virtual {v3}, Landroidx/appcompat/widget/f0;->a()Z

    move-result v3

    if-eqz v3, :cond_25

    .line 6
    iget-object v2, v2, Landroidx/appcompat/view/menu/b$d;->a:Landroidx/appcompat/widget/MenuPopupWindow;

    invoke-virtual {v2}, Landroidx/appcompat/widget/f0;->dismiss()V

    :cond_25
    add-int/lit8 v0, v0, -0x1

    goto :goto_14

    :cond_28
    return-void
.end method

.method public g(Landroidx/appcompat/view/menu/i$a;)V
    .registers 2

    .line 1
    iput-object p1, p0, Landroidx/appcompat/view/menu/b;->x:Landroidx/appcompat/view/menu/i$a;

    return-void
.end method

.method public i(Landroid/os/Parcelable;)V
    .registers 2

    return-void
.end method

.method public j()Landroid/widget/ListView;
    .registers 3

    .line 1
    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->i:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_a

    const/4 v0, 0x0

    goto :goto_1c

    .line 2
    :cond_a
    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->i:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/appcompat/view/menu/b$d;

    .line 3
    iget-object v0, v0, Landroidx/appcompat/view/menu/b$d;->a:Landroidx/appcompat/widget/MenuPopupWindow;

    .line 4
    iget-object v0, v0, Landroidx/appcompat/widget/f0;->c:Landroidx/appcompat/widget/b0;

    :goto_1c
    return-object v0
.end method

.method public k(Landroidx/appcompat/view/menu/l;)Z
    .registers 6

    .line 1
    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->i:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_1f

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/appcompat/view/menu/b$d;

    .line 2
    iget-object v3, v1, Landroidx/appcompat/view/menu/b$d;->b:Landroidx/appcompat/view/menu/e;

    if-ne p1, v3, :cond_6

    .line 3
    iget-object p1, v1, Landroidx/appcompat/view/menu/b$d;->a:Landroidx/appcompat/widget/MenuPopupWindow;

    .line 4
    iget-object p1, p1, Landroidx/appcompat/widget/f0;->c:Landroidx/appcompat/widget/b0;

    .line 5
    invoke-virtual {p1}, Landroid/widget/ListView;->requestFocus()Z

    return v2

    .line 6
    :cond_1f
    invoke-virtual {p1}, Landroidx/appcompat/view/menu/e;->hasVisibleItems()Z

    move-result v0

    if-eqz v0, :cond_41

    .line 7
    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->b:Landroid/content/Context;

    invoke-virtual {p1, p0, v0}, Landroidx/appcompat/view/menu/e;->b(Landroidx/appcompat/view/menu/i;Landroid/content/Context;)V

    .line 8
    invoke-virtual {p0}, Landroidx/appcompat/view/menu/b;->a()Z

    move-result v0

    if-eqz v0, :cond_34

    .line 9
    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/b;->w(Landroidx/appcompat/view/menu/e;)V

    goto :goto_39

    .line 10
    :cond_34
    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->h:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 11
    :goto_39
    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->x:Landroidx/appcompat/view/menu/i$a;

    if-eqz v0, :cond_40

    .line 12
    invoke-interface {v0, p1}, Landroidx/appcompat/view/menu/i$a;->c(Landroidx/appcompat/view/menu/e;)Z

    :cond_40
    return v2

    :cond_41
    const/4 p1, 0x0

    return p1
.end method

.method public l()Landroid/os/Parcelable;
    .registers 2

    const/4 v0, 0x0

    return-object v0
.end method

.method public m(Landroidx/appcompat/view/menu/e;)V
    .registers 3

    .line 1
    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->b:Landroid/content/Context;

    invoke-virtual {p1, p0, v0}, Landroidx/appcompat/view/menu/e;->b(Landroidx/appcompat/view/menu/i;Landroid/content/Context;)V

    .line 2
    invoke-virtual {p0}, Landroidx/appcompat/view/menu/b;->a()Z

    move-result v0

    if-eqz v0, :cond_f

    .line 3
    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/b;->w(Landroidx/appcompat/view/menu/e;)V

    goto :goto_14

    .line 4
    :cond_f
    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->h:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_14
    return-void
.end method

.method public o(Landroid/view/View;)V
    .registers 4

    .line 1
    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->o:Landroid/view/View;

    if-eq v0, p1, :cond_14

    .line 2
    iput-object p1, p0, Landroidx/appcompat/view/menu/b;->o:Landroid/view/View;

    .line 3
    iget v0, p0, Landroidx/appcompat/view/menu/b;->m:I

    .line 4
    sget-object v1, Ll3/d0;->a:Ljava/util/WeakHashMap;

    .line 5
    invoke-static {p1}, Ll3/d0$e;->d(Landroid/view/View;)I

    move-result p1

    .line 6
    invoke-static {v0, p1}, Landroid/view/Gravity;->getAbsoluteGravity(II)I

    move-result p1

    .line 7
    iput p1, p0, Landroidx/appcompat/view/menu/b;->n:I

    :cond_14
    return-void
.end method

.method public onDismiss()V
    .registers 6

    .line 1
    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->i:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_8
    if-ge v2, v0, :cond_1e

    .line 2
    iget-object v3, p0, Landroidx/appcompat/view/menu/b;->i:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/appcompat/view/menu/b$d;

    .line 3
    iget-object v4, v3, Landroidx/appcompat/view/menu/b$d;->a:Landroidx/appcompat/widget/MenuPopupWindow;

    invoke-virtual {v4}, Landroidx/appcompat/widget/f0;->a()Z

    move-result v4

    if-nez v4, :cond_1b

    goto :goto_1f

    :cond_1b
    add-int/lit8 v2, v2, 0x1

    goto :goto_8

    :cond_1e
    const/4 v3, 0x0

    :goto_1f
    if-eqz v3, :cond_26

    .line 4
    iget-object v0, v3, Landroidx/appcompat/view/menu/b$d;->b:Landroidx/appcompat/view/menu/e;

    invoke-virtual {v0, v1}, Landroidx/appcompat/view/menu/e;->c(Z)V

    :cond_26
    return-void
.end method

.method public onKey(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .registers 4

    .line 1
    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result p1

    const/4 p3, 0x1

    if-ne p1, p3, :cond_f

    const/16 p1, 0x52

    if-ne p2, p1, :cond_f

    .line 2
    invoke-virtual {p0}, Landroidx/appcompat/view/menu/b;->dismiss()V

    return p3

    :cond_f
    const/4 p1, 0x0

    return p1
.end method

.method public p(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Landroidx/appcompat/view/menu/b;->v:Z

    return-void
.end method

.method public q(I)V
    .registers 4

    .line 1
    iget v0, p0, Landroidx/appcompat/view/menu/b;->m:I

    if-eq v0, p1, :cond_14

    .line 2
    iput p1, p0, Landroidx/appcompat/view/menu/b;->m:I

    .line 3
    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->o:Landroid/view/View;

    .line 4
    sget-object v1, Ll3/d0;->a:Ljava/util/WeakHashMap;

    .line 5
    invoke-static {v0}, Ll3/d0$e;->d(Landroid/view/View;)I

    move-result v0

    .line 6
    invoke-static {p1, v0}, Landroid/view/Gravity;->getAbsoluteGravity(II)I

    move-result p1

    .line 7
    iput p1, p0, Landroidx/appcompat/view/menu/b;->n:I

    :cond_14
    return-void
.end method

.method public r(I)V
    .registers 3

    const/4 v0, 0x1

    .line 1
    iput-boolean v0, p0, Landroidx/appcompat/view/menu/b;->r:Z

    .line 2
    iput p1, p0, Landroidx/appcompat/view/menu/b;->t:I

    return-void
.end method

.method public s(Landroid/widget/PopupWindow$OnDismissListener;)V
    .registers 2

    .line 1
    iput-object p1, p0, Landroidx/appcompat/view/menu/b;->z:Landroid/widget/PopupWindow$OnDismissListener;

    return-void
.end method

.method public show()V
    .registers 3

    .line 1
    invoke-virtual {p0}, Landroidx/appcompat/view/menu/b;->a()Z

    move-result v0

    if-eqz v0, :cond_7

    return-void

    .line 2
    :cond_7
    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->h:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_d
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1d

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/appcompat/view/menu/e;

    .line 3
    invoke-virtual {p0, v1}, Landroidx/appcompat/view/menu/b;->w(Landroidx/appcompat/view/menu/e;)V

    goto :goto_d

    .line 4
    :cond_1d
    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->h:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 5
    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->o:Landroid/view/View;

    iput-object v0, p0, Landroidx/appcompat/view/menu/b;->p:Landroid/view/View;

    if-eqz v0, :cond_43

    .line 6
    iget-object v1, p0, Landroidx/appcompat/view/menu/b;->y:Landroid/view/ViewTreeObserver;

    if-nez v1, :cond_2e

    const/4 v1, 0x1

    goto :goto_2f

    :cond_2e
    const/4 v1, 0x0

    .line 7
    :goto_2f
    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    iput-object v0, p0, Landroidx/appcompat/view/menu/b;->y:Landroid/view/ViewTreeObserver;

    if-eqz v1, :cond_3c

    .line 8
    iget-object v1, p0, Landroidx/appcompat/view/menu/b;->j:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 9
    :cond_3c
    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->p:Landroid/view/View;

    iget-object v1, p0, Landroidx/appcompat/view/menu/b;->k:Landroid/view/View$OnAttachStateChangeListener;

    invoke-virtual {v0, v1}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    :cond_43
    return-void
.end method

.method public t(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Landroidx/appcompat/view/menu/b;->w:Z

    return-void
.end method

.method public u(I)V
    .registers 3

    const/4 v0, 0x1

    .line 1
    iput-boolean v0, p0, Landroidx/appcompat/view/menu/b;->s:Z

    .line 2
    iput p1, p0, Landroidx/appcompat/view/menu/b;->u:I

    return-void
.end method

.method public final w(Landroidx/appcompat/view/menu/e;)V
    .registers 16

    .line 1
    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->b:Landroid/content/Context;

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    .line 2
    new-instance v1, Landroidx/appcompat/view/menu/d;

    iget-boolean v2, p0, Landroidx/appcompat/view/menu/b;->f:Z

    sget v3, Landroidx/appcompat/view/menu/b;->B:I

    invoke-direct {v1, p1, v0, v2, v3}, Landroidx/appcompat/view/menu/d;-><init>(Landroidx/appcompat/view/menu/e;Landroid/view/LayoutInflater;ZI)V

    .line 3
    invoke-virtual {p0}, Landroidx/appcompat/view/menu/b;->a()Z

    move-result v2

    const/4 v3, 0x1

    if-nez v2, :cond_1d

    iget-boolean v2, p0, Landroidx/appcompat/view/menu/b;->v:Z

    if-eqz v2, :cond_1d

    .line 4
    iput-boolean v3, v1, Landroidx/appcompat/view/menu/d;->c:Z

    goto :goto_29

    .line 5
    :cond_1d
    invoke-virtual {p0}, Landroidx/appcompat/view/menu/b;->a()Z

    move-result v2

    if-eqz v2, :cond_29

    .line 6
    invoke-static {p1}, Ll/d;->v(Landroidx/appcompat/view/menu/e;)Z

    move-result v2

    .line 7
    iput-boolean v2, v1, Landroidx/appcompat/view/menu/d;->c:Z

    .line 8
    :cond_29
    :goto_29
    iget-object v2, p0, Landroidx/appcompat/view/menu/b;->b:Landroid/content/Context;

    iget v4, p0, Landroidx/appcompat/view/menu/b;->c:I

    const/4 v5, 0x0

    invoke-static {v1, v5, v2, v4}, Ll/d;->n(Landroid/widget/ListAdapter;Landroid/view/ViewGroup;Landroid/content/Context;I)I

    move-result v2

    .line 9
    new-instance v4, Landroidx/appcompat/widget/MenuPopupWindow;

    iget-object v6, p0, Landroidx/appcompat/view/menu/b;->b:Landroid/content/Context;

    iget v7, p0, Landroidx/appcompat/view/menu/b;->d:I

    iget v8, p0, Landroidx/appcompat/view/menu/b;->e:I

    invoke-direct {v4, v6, v5, v7, v8}, Landroidx/appcompat/widget/MenuPopupWindow;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    .line 10
    iget-object v6, p0, Landroidx/appcompat/view/menu/b;->l:Landroidx/appcompat/widget/g0;

    .line 11
    iput-object v6, v4, Landroidx/appcompat/widget/MenuPopupWindow;->C:Landroidx/appcompat/widget/g0;

    .line 12
    iput-object p0, v4, Landroidx/appcompat/widget/f0;->p:Landroid/widget/AdapterView$OnItemClickListener;

    .line 13
    iget-object v6, v4, Landroidx/appcompat/widget/f0;->y:Landroid/widget/PopupWindow;

    invoke-virtual {v6, p0}, Landroid/widget/PopupWindow;->setOnDismissListener(Landroid/widget/PopupWindow$OnDismissListener;)V

    .line 14
    iget-object v6, p0, Landroidx/appcompat/view/menu/b;->o:Landroid/view/View;

    .line 15
    iput-object v6, v4, Landroidx/appcompat/widget/f0;->o:Landroid/view/View;

    .line 16
    iget v6, p0, Landroidx/appcompat/view/menu/b;->n:I

    .line 17
    iput v6, v4, Landroidx/appcompat/widget/f0;->l:I

    .line 18
    invoke-virtual {v4, v3}, Landroidx/appcompat/widget/f0;->r(Z)V

    .line 19
    iget-object v6, v4, Landroidx/appcompat/widget/f0;->y:Landroid/widget/PopupWindow;

    const/4 v7, 0x2

    invoke-virtual {v6, v7}, Landroid/widget/PopupWindow;->setInputMethodMode(I)V

    .line 20
    invoke-virtual {v4, v1}, Landroidx/appcompat/widget/f0;->o(Landroid/widget/ListAdapter;)V

    .line 21
    invoke-virtual {v4, v2}, Landroidx/appcompat/widget/f0;->q(I)V

    .line 22
    iget v1, p0, Landroidx/appcompat/view/menu/b;->n:I

    .line 23
    iput v1, v4, Landroidx/appcompat/widget/f0;->l:I

    .line 24
    iget-object v1, p0, Landroidx/appcompat/view/menu/b;->i:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v6, 0x0

    if-lez v1, :cond_e0

    .line 25
    iget-object v1, p0, Landroidx/appcompat/view/menu/b;->i:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v7

    sub-int/2addr v7, v3

    invoke-interface {v1, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/appcompat/view/menu/b$d;

    .line 26
    iget-object v7, v1, Landroidx/appcompat/view/menu/b$d;->b:Landroidx/appcompat/view/menu/e;

    .line 27
    invoke-virtual {v7}, Landroidx/appcompat/view/menu/e;->size()I

    move-result v8

    const/4 v9, 0x0

    :goto_80
    if-ge v9, v8, :cond_96

    .line 28
    invoke-virtual {v7, v9}, Landroidx/appcompat/view/menu/e;->getItem(I)Landroid/view/MenuItem;

    move-result-object v10

    .line 29
    invoke-interface {v10}, Landroid/view/MenuItem;->hasSubMenu()Z

    move-result v11

    if-eqz v11, :cond_93

    invoke-interface {v10}, Landroid/view/MenuItem;->getSubMenu()Landroid/view/SubMenu;

    move-result-object v11

    if-ne p1, v11, :cond_93

    goto :goto_97

    :cond_93
    add-int/lit8 v9, v9, 0x1

    goto :goto_80

    :cond_96
    move-object v10, v5

    :goto_97
    if-nez v10, :cond_9a

    goto :goto_e2

    .line 30
    :cond_9a
    iget-object v5, v1, Landroidx/appcompat/view/menu/b$d;->a:Landroidx/appcompat/widget/MenuPopupWindow;

    .line 31
    iget-object v5, v5, Landroidx/appcompat/widget/f0;->c:Landroidx/appcompat/widget/b0;

    .line 32
    invoke-virtual {v5}, Landroid/widget/ListView;->getAdapter()Landroid/widget/ListAdapter;

    move-result-object v7

    .line 33
    instance-of v8, v7, Landroid/widget/HeaderViewListAdapter;

    if-eqz v8, :cond_b3

    .line 34
    check-cast v7, Landroid/widget/HeaderViewListAdapter;

    .line 35
    invoke-virtual {v7}, Landroid/widget/HeaderViewListAdapter;->getHeadersCount()I

    move-result v8

    .line 36
    invoke-virtual {v7}, Landroid/widget/HeaderViewListAdapter;->getWrappedAdapter()Landroid/widget/ListAdapter;

    move-result-object v7

    check-cast v7, Landroidx/appcompat/view/menu/d;

    goto :goto_b6

    .line 37
    :cond_b3
    check-cast v7, Landroidx/appcompat/view/menu/d;

    const/4 v8, 0x0

    .line 38
    :goto_b6
    invoke-virtual {v7}, Landroidx/appcompat/view/menu/d;->getCount()I

    move-result v9

    const/4 v11, 0x0

    :goto_bb
    const/4 v12, -0x1

    if-ge v11, v9, :cond_c8

    .line 39
    invoke-virtual {v7, v11}, Landroidx/appcompat/view/menu/d;->b(I)Landroidx/appcompat/view/menu/g;

    move-result-object v13

    if-ne v10, v13, :cond_c5

    goto :goto_c9

    :cond_c5
    add-int/lit8 v11, v11, 0x1

    goto :goto_bb

    :cond_c8
    const/4 v11, -0x1

    :goto_c9
    if-ne v11, v12, :cond_cc

    goto :goto_e1

    :cond_cc
    add-int/2addr v11, v8

    .line 40
    invoke-virtual {v5}, Landroid/widget/ListView;->getFirstVisiblePosition()I

    move-result v7

    sub-int/2addr v11, v7

    if-ltz v11, :cond_e1

    .line 41
    invoke-virtual {v5}, Landroid/widget/ListView;->getChildCount()I

    move-result v7

    if-lt v11, v7, :cond_db

    goto :goto_e1

    .line 42
    :cond_db
    invoke-virtual {v5, v11}, Landroid/widget/ListView;->getChildAt(I)Landroid/view/View;

    move-result-object v5

    goto :goto_e2

    :cond_e0
    const/4 v1, 0x0

    :cond_e1
    :goto_e1
    const/4 v5, 0x0

    :goto_e2
    if-eqz v5, :cond_1b0

    .line 43
    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v8, 0x1c

    if-gt v7, v8, :cond_102

    .line 44
    sget-object v7, Landroidx/appcompat/widget/MenuPopupWindow;->D:Ljava/lang/reflect/Method;

    if-eqz v7, :cond_107

    .line 45
    :try_start_ee
    iget-object v8, v4, Landroidx/appcompat/widget/f0;->y:Landroid/widget/PopupWindow;

    new-array v9, v3, [Ljava/lang/Object;

    sget-object v10, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    aput-object v10, v9, v6

    invoke-virtual {v7, v8, v9}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_f9
    .catch Ljava/lang/Exception; {:try_start_ee .. :try_end_f9} :catch_fa

    goto :goto_107

    :catch_fa
    const-string v7, "MenuPopupWindow"

    const-string v8, "Could not invoke setTouchModal() on PopupWindow. Oh well."

    .line 46
    invoke-static {v7, v8}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_107

    .line 47
    :cond_102
    iget-object v7, v4, Landroidx/appcompat/widget/f0;->y:Landroid/widget/PopupWindow;

    invoke-static {v7, v6}, Landroidx/appcompat/widget/MenuPopupWindow$b;->a(Landroid/widget/PopupWindow;Z)V

    .line 48
    :cond_107
    :goto_107
    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v8, 0x17

    if-lt v7, v8, :cond_113

    .line 49
    iget-object v8, v4, Landroidx/appcompat/widget/f0;->y:Landroid/widget/PopupWindow;

    const/4 v9, 0x0

    invoke-static {v8, v9}, Landroidx/appcompat/widget/MenuPopupWindow$a;->a(Landroid/widget/PopupWindow;Landroid/transition/Transition;)V

    .line 50
    :cond_113
    iget-object v8, p0, Landroidx/appcompat/view/menu/b;->i:Ljava/util/List;

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v9

    sub-int/2addr v9, v3

    invoke-interface {v8, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroidx/appcompat/view/menu/b$d;

    .line 51
    iget-object v8, v8, Landroidx/appcompat/view/menu/b$d;->a:Landroidx/appcompat/widget/MenuPopupWindow;

    .line 52
    iget-object v8, v8, Landroidx/appcompat/widget/f0;->c:Landroidx/appcompat/widget/b0;

    const/4 v9, 0x2

    new-array v9, v9, [I

    .line 53
    invoke-virtual {v8, v9}, Landroid/widget/ListView;->getLocationOnScreen([I)V

    .line 54
    new-instance v10, Landroid/graphics/Rect;

    invoke-direct {v10}, Landroid/graphics/Rect;-><init>()V

    .line 55
    iget-object v11, p0, Landroidx/appcompat/view/menu/b;->p:Landroid/view/View;

    invoke-virtual {v11, v10}, Landroid/view/View;->getWindowVisibleDisplayFrame(Landroid/graphics/Rect;)V

    .line 56
    iget v11, p0, Landroidx/appcompat/view/menu/b;->q:I

    if-ne v11, v3, :cond_145

    .line 57
    aget v9, v9, v6

    invoke-virtual {v8}, Landroid/widget/ListView;->getWidth()I

    move-result v8

    add-int/2addr v8, v9

    add-int/2addr v8, v2

    .line 58
    iget v9, v10, Landroid/graphics/Rect;->right:I

    if-le v8, v9, :cond_14a

    goto :goto_14c

    .line 59
    :cond_145
    aget v8, v9, v6

    sub-int/2addr v8, v2

    if-gez v8, :cond_14c

    :cond_14a
    const/4 v8, 0x1

    goto :goto_14d

    :cond_14c
    :goto_14c
    const/4 v8, 0x0

    :goto_14d
    if-ne v8, v3, :cond_151

    const/4 v9, 0x1

    goto :goto_152

    :cond_151
    const/4 v9, 0x0

    .line 60
    :goto_152
    iput v8, p0, Landroidx/appcompat/view/menu/b;->q:I

    const/16 v8, 0x1a

    const/4 v10, 0x5

    if-lt v7, v8, :cond_15e

    .line 61
    iput-object v5, v4, Landroidx/appcompat/widget/f0;->o:Landroid/view/View;

    const/4 v7, 0x0

    const/4 v8, 0x0

    goto :goto_190

    :cond_15e
    const/4 v7, 0x2

    new-array v8, v7, [I

    .line 62
    iget-object v11, p0, Landroidx/appcompat/view/menu/b;->o:Landroid/view/View;

    invoke-virtual {v11, v8}, Landroid/view/View;->getLocationOnScreen([I)V

    new-array v7, v7, [I

    .line 63
    invoke-virtual {v5, v7}, Landroid/view/View;->getLocationOnScreen([I)V

    .line 64
    iget v11, p0, Landroidx/appcompat/view/menu/b;->n:I

    and-int/lit8 v11, v11, 0x7

    if-ne v11, v10, :cond_185

    .line 65
    aget v11, v8, v6

    iget-object v12, p0, Landroidx/appcompat/view/menu/b;->o:Landroid/view/View;

    invoke-virtual {v12}, Landroid/view/View;->getWidth()I

    move-result v12

    add-int/2addr v12, v11

    aput v12, v8, v6

    .line 66
    aget v11, v7, v6

    invoke-virtual {v5}, Landroid/view/View;->getWidth()I

    move-result v12

    add-int/2addr v12, v11

    aput v12, v7, v6

    .line 67
    :cond_185
    aget v11, v7, v6

    aget v12, v8, v6

    sub-int/2addr v11, v12

    .line 68
    aget v7, v7, v3

    aget v8, v8, v3

    sub-int/2addr v7, v8

    move v8, v11

    .line 69
    :goto_190
    iget v11, p0, Landroidx/appcompat/view/menu/b;->n:I

    and-int/2addr v11, v10

    if-ne v11, v10, :cond_19d

    if-eqz v9, :cond_198

    goto :goto_1a3

    .line 70
    :cond_198
    invoke-virtual {v5}, Landroid/view/View;->getWidth()I

    move-result v2

    goto :goto_1a5

    :cond_19d
    if-eqz v9, :cond_1a5

    .line 71
    invoke-virtual {v5}, Landroid/view/View;->getWidth()I

    move-result v2

    :goto_1a3
    add-int/2addr v8, v2

    goto :goto_1a6

    :cond_1a5
    :goto_1a5
    sub-int/2addr v8, v2

    .line 72
    :goto_1a6
    iput v8, v4, Landroidx/appcompat/widget/f0;->f:I

    .line 73
    iput-boolean v3, v4, Landroidx/appcompat/widget/f0;->k:Z

    .line 74
    iput-boolean v3, v4, Landroidx/appcompat/widget/f0;->j:Z

    .line 75
    invoke-virtual {v4, v7}, Landroidx/appcompat/widget/f0;->k(I)V

    goto :goto_1ce

    .line 76
    :cond_1b0
    iget-boolean v2, p0, Landroidx/appcompat/view/menu/b;->r:Z

    if-eqz v2, :cond_1b8

    .line 77
    iget v2, p0, Landroidx/appcompat/view/menu/b;->t:I

    .line 78
    iput v2, v4, Landroidx/appcompat/widget/f0;->f:I

    .line 79
    :cond_1b8
    iget-boolean v2, p0, Landroidx/appcompat/view/menu/b;->s:Z

    if-eqz v2, :cond_1c1

    .line 80
    iget v2, p0, Landroidx/appcompat/view/menu/b;->u:I

    invoke-virtual {v4, v2}, Landroidx/appcompat/widget/f0;->k(I)V

    .line 81
    :cond_1c1
    iget-object v2, p0, Ll/d;->a:Landroid/graphics/Rect;

    if-eqz v2, :cond_1cb

    .line 82
    new-instance v3, Landroid/graphics/Rect;

    invoke-direct {v3, v2}, Landroid/graphics/Rect;-><init>(Landroid/graphics/Rect;)V

    goto :goto_1cc

    :cond_1cb
    const/4 v3, 0x0

    :goto_1cc
    iput-object v3, v4, Landroidx/appcompat/widget/f0;->w:Landroid/graphics/Rect;

    .line 83
    :goto_1ce
    new-instance v2, Landroidx/appcompat/view/menu/b$d;

    iget v3, p0, Landroidx/appcompat/view/menu/b;->q:I

    invoke-direct {v2, v4, p1, v3}, Landroidx/appcompat/view/menu/b$d;-><init>(Landroidx/appcompat/widget/MenuPopupWindow;Landroidx/appcompat/view/menu/e;I)V

    .line 84
    iget-object v3, p0, Landroidx/appcompat/view/menu/b;->i:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 85
    invoke-virtual {v4}, Landroidx/appcompat/widget/f0;->show()V

    .line 86
    iget-object v2, v4, Landroidx/appcompat/widget/f0;->c:Landroidx/appcompat/widget/b0;

    .line 87
    invoke-virtual {v2, p0}, Landroid/widget/ListView;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    if-nez v1, :cond_20c

    .line 88
    iget-boolean v1, p0, Landroidx/appcompat/view/menu/b;->w:Z

    if-eqz v1, :cond_20c

    .line 89
    iget-object v1, p1, Landroidx/appcompat/view/menu/e;->m:Ljava/lang/CharSequence;

    if-eqz v1, :cond_20c

    .line 90
    sget v1, Landroidx/appcompat/R$layout;->abc_popup_menu_header_item_layout:I

    invoke-virtual {v0, v1, v2, v6}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/FrameLayout;

    const v1, 0x1020016

    .line 91
    invoke-virtual {v0, v1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    .line 92
    invoke-virtual {v0, v6}, Landroid/widget/FrameLayout;->setEnabled(Z)V

    .line 93
    iget-object p1, p1, Landroidx/appcompat/view/menu/e;->m:Ljava/lang/CharSequence;

    .line 94
    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 p1, 0x0

    .line 95
    invoke-virtual {v2, v0, p1, v6}, Landroid/widget/ListView;->addHeaderView(Landroid/view/View;Ljava/lang/Object;Z)V

    .line 96
    invoke-virtual {v4}, Landroidx/appcompat/widget/f0;->show()V

    :cond_20c
    return-void
.end method
