.class public abstract La7/h;
.super Ljava/lang/Object;
.source "ClickUtils.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# static fields
.field public static c:Z = true

.field public static final d:Ljava/lang/Runnable;


# instance fields
.field public a:J

.field public b:Z


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, La7/h$a;

    invoke-direct {v0}, La7/h$a;-><init>()V

    sput-object v0, La7/h;->d:Ljava/lang/Runnable;

    return-void
.end method

.method public constructor <init>(ZJ)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-boolean p1, p0, La7/h;->b:Z

    .line 3
    iput-wide p2, p0, La7/h;->a:J

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 12

    .line 1
    iget-boolean v0, p0, La7/h;->b:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_1c

    .line 2
    sget-boolean v0, La7/h;->c:Z

    if-eqz v0, :cond_92

    .line 3
    sput-boolean v1, La7/h;->c:Z

    .line 4
    sget-object v0, La7/h;->d:Ljava/lang/Runnable;

    iget-wide v1, p0, La7/h;->a:J

    invoke-virtual {p1, v0, v1, v2}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 5
    move-object v0, p0

    check-cast v0, La7/g;

    .line 6
    iget-object v0, v0, La7/g;->e:Landroid/view/View$OnClickListener;

    invoke-interface {v0, p1}, Landroid/view/View$OnClickListener;->onClick(Landroid/view/View;)V

    goto/16 :goto_92

    .line 7
    :cond_1c
    iget-wide v2, p0, La7/h;->a:J

    .line 8
    sget-object v0, La7/i;->a:Ljava/util/Map;

    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    .line 10
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_9b

    const-wide/16 v4, 0x0

    cmp-long v6, v2, v4

    if-ltz v6, :cond_93

    .line 11
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    .line 12
    sget-object v6, La7/i;->a:Ljava/util/Map;

    check-cast v6, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v6}, Ljava/util/concurrent/ConcurrentHashMap;->size()I

    move-result v7

    const/16 v8, 0x40

    if-ge v7, v8, :cond_45

    goto :goto_6b

    .line 13
    :cond_45
    invoke-virtual {v6}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v6

    invoke-interface {v6}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_4d
    :goto_4d
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_6b

    .line 14
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/util/Map$Entry;

    .line 15
    invoke-interface {v7}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Long;

    .line 16
    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    move-result-wide v7

    cmp-long v9, v4, v7

    if-ltz v9, :cond_4d

    .line 17
    invoke-interface {v6}, Ljava/util/Iterator;->remove()V

    goto :goto_4d

    .line 18
    :cond_6b
    :goto_6b
    sget-object v6, La7/i;->a:Ljava/util/Map;

    check-cast v6, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v6, v0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Long;

    if-eqz v7, :cond_7f

    .line 19
    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    move-result-wide v7

    cmp-long v9, v4, v7

    if-ltz v9, :cond_88

    :cond_7f
    add-long/2addr v4, v2

    .line 20
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-virtual {v6, v0, v1}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x1

    :cond_88
    if-eqz v1, :cond_92

    .line 21
    move-object v0, p0

    check-cast v0, La7/g;

    .line 22
    iget-object v0, v0, La7/g;->e:Landroid/view/View$OnClickListener;

    invoke-interface {v0, p1}, Landroid/view/View$OnClickListener;->onClick(Landroid/view/View;)V

    :cond_92
    :goto_92
    return-void

    .line 23
    :cond_93
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "The duration is less than 0."

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 24
    :cond_9b
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "The key is null."

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
