.class public final La1/g$a;
.super Lwg/j;
.source "DrawModifier.kt"

# interfaces
.implements Lvg/q;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La1/g;->b(Ly0/h;Lvg/l;)Ly0/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lwg/j;",
        "Lvg/q<",
        "Ly0/h;",
        "Lm0/g;",
        "Ljava/lang/Integer;",
        "Ly0/h;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic a:Lvg/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lvg/l<",
            "La1/b;",
            "La1/h;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lvg/l;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lvg/l<",
            "-",
            "La1/b;",
            "La1/h;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La1/g$a;->a:Lvg/l;

    const/4 p1, 0x3

    invoke-direct {p0, p1}, Lwg/j;-><init>(I)V

    return-void
.end method


# virtual methods
.method public w(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 1
    check-cast p1, Ly0/h;

    check-cast p2, Lm0/g;

    check-cast p3, Ljava/lang/Number;

    invoke-virtual {p3}, Ljava/lang/Number;->intValue()I

    const-string p3, "$this$composed"

    .line 2
    invoke-static {p1, p3}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const p3, -0x64b4c6fb

    invoke-interface {p2, p3}, Lm0/g;->e(I)V

    const p3, -0x1d58f75c

    .line 3
    invoke-interface {p2, p3}, Lm0/g;->e(I)V

    .line 4
    invoke-interface {p2}, Lm0/g;->f()Ljava/lang/Object;

    move-result-object p3

    .line 5
    sget v0, Lm0/g;->a:I

    sget-object v0, Lm0/g$a;->b:Ljava/lang/Object;

    if-ne p3, v0, :cond_2c

    .line 6
    new-instance p3, La1/b;

    invoke-direct {p3}, La1/b;-><init>()V

    .line 7
    invoke-interface {p2, p3}, Lm0/g;->H(Ljava/lang/Object;)V

    .line 8
    :cond_2c
    invoke-interface {p2}, Lm0/g;->L()V

    .line 9
    check-cast p3, La1/b;

    .line 10
    new-instance v0, La1/e;

    iget-object v1, p0, La1/g$a;->a:Lvg/l;

    invoke-direct {v0, p3, v1}, La1/e;-><init>(La1/b;Lvg/l;)V

    invoke-interface {p1, v0}, Ly0/h;->p0(Ly0/h;)Ly0/h;

    move-result-object p1

    invoke-interface {p2}, Lm0/g;->L()V

    return-object p1
.end method
