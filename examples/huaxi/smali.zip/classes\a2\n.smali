.class public final La2/n;
.super Ljava/lang/Object;
.source "TextLayout.kt"


# instance fields
.field public final a:Z

.field public final b:Z

.field public final c:Z

.field public final d:Landroid/text/Layout;

.field public final e:I

.field public final f:I

.field public final g:I

.field public final h:Z

.field public final i:Lkg/c;


# direct methods
.method public constructor <init>(Ljava/lang/CharSequence;FLandroid/text/TextPaint;ILandroid/text/TextUtils$TruncateAt;IFFZZIIII[I[ILa2/c;I)V
    .registers 44

    move-object/from16 v0, p0

    move-object/from16 v15, p1

    move-object/from16 v5, p3

    move/from16 v1, p18

    and-int/lit8 v2, v1, 0x2

    if-eqz v2, :cond_e

    const/4 v2, 0x0

    goto :goto_10

    :cond_e
    move/from16 v2, p2

    :goto_10
    and-int/lit8 v3, v1, 0x8

    if-eqz v3, :cond_16

    const/4 v3, 0x0

    goto :goto_18

    :cond_16
    move/from16 v3, p4

    :goto_18
    and-int/lit8 v4, v1, 0x10

    if-eqz v4, :cond_1f

    const/4 v4, 0x0

    move-object v10, v4

    goto :goto_21

    :cond_1f
    move-object/from16 v10, p5

    :goto_21
    and-int/lit8 v4, v1, 0x20

    if-eqz v4, :cond_27

    const/4 v4, 0x2

    goto :goto_29

    :cond_27
    move/from16 v4, p6

    :goto_29
    and-int/lit8 v6, v1, 0x40

    if-eqz v6, :cond_32

    const/high16 v6, 0x3f800000    # 1.0f

    const/high16 v12, 0x3f800000    # 1.0f

    goto :goto_34

    :cond_32
    move/from16 v12, p7

    :goto_34
    and-int/lit16 v6, v1, 0x80

    if-eqz v6, :cond_3b

    const/4 v6, 0x0

    const/4 v13, 0x0

    goto :goto_3d

    :cond_3b
    move/from16 v13, p8

    :goto_3d
    and-int/lit16 v6, v1, 0x100

    if-eqz v6, :cond_44

    const/4 v6, 0x0

    const/4 v14, 0x0

    goto :goto_46

    :cond_44
    move/from16 v14, p9

    :goto_46
    and-int/lit16 v6, v1, 0x200

    const/4 v7, 0x1

    if-eqz v6, :cond_4e

    const/4 v6, 0x1

    const/4 v9, 0x1

    goto :goto_50

    :cond_4e
    move/from16 v9, p10

    :goto_50
    and-int/lit16 v6, v1, 0x400

    if-eqz v6, :cond_5b

    const v6, 0x7fffffff

    const v8, 0x7fffffff

    goto :goto_5d

    :cond_5b
    move/from16 v8, p11

    :goto_5d
    and-int/lit16 v6, v1, 0x800

    if-eqz v6, :cond_65

    const/4 v6, 0x0

    const/16 v17, 0x0

    goto :goto_67

    :cond_65
    move/from16 v17, p12

    :goto_67
    and-int/lit16 v6, v1, 0x1000

    if-eqz v6, :cond_6f

    const/4 v6, 0x0

    const/16 v18, 0x0

    goto :goto_71

    :cond_6f
    move/from16 v18, p13

    :goto_71
    and-int/lit16 v6, v1, 0x2000

    if-eqz v6, :cond_79

    const/4 v6, 0x0

    const/16 v16, 0x0

    goto :goto_7b

    :cond_79
    move/from16 v16, p14

    :goto_7b
    const/16 v19, 0x0

    const/16 v20, 0x0

    const/high16 v6, 0x10000

    and-int/2addr v1, v6

    if-eqz v1, :cond_8a

    .line 1
    new-instance v1, La2/c;

    invoke-direct {v1, v15, v5, v4}, La2/c;-><init>(Ljava/lang/CharSequence;Landroid/text/TextPaint;I)V

    goto :goto_8c

    :cond_8a
    move-object/from16 v1, p17

    :goto_8c
    const-string v6, "charSequence"

    .line 2
    invoke-static {v15, v6}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v6, "textPaint"

    invoke-static {v5, v6}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v6, "layoutIntrinsics"

    invoke-static {v1, v6}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    invoke-direct/range {p0 .. p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-boolean v14, v0, La2/n;->a:Z

    .line 5
    iput-boolean v9, v0, La2/n;->b:Z

    .line 6
    invoke-interface/range {p1 .. p1}, Ljava/lang/CharSequence;->length()I

    move-result v6

    .line 7
    invoke-static {v4}, La2/o;->a(I)Landroid/text/TextDirectionHeuristic;

    move-result-object v21

    .line 8
    sget-object v4, La2/l;->a:La2/l;

    const/4 v4, 0x3

    if-eqz v3, :cond_c8

    if-eq v3, v7, :cond_c5

    const/4 v7, 0x2

    if-eq v3, v7, :cond_c2

    if-eq v3, v4, :cond_bf

    const/4 v4, 0x4

    if-eq v3, v4, :cond_bc

    .line 9
    sget-object v3, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    goto :goto_ca

    .line 10
    :cond_bc
    sget-object v3, La2/l;->c:Landroid/text/Layout$Alignment;

    goto :goto_ca

    .line 11
    :cond_bf
    sget-object v3, La2/l;->b:Landroid/text/Layout$Alignment;

    goto :goto_ca

    .line 12
    :cond_c2
    sget-object v3, Landroid/text/Layout$Alignment;->ALIGN_CENTER:Landroid/text/Layout$Alignment;

    goto :goto_ca

    .line 13
    :cond_c5
    sget-object v3, Landroid/text/Layout$Alignment;->ALIGN_OPPOSITE:Landroid/text/Layout$Alignment;

    goto :goto_ca

    .line 14
    :cond_c8
    sget-object v3, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    :goto_ca
    move-object v7, v3

    .line 15
    instance-of v3, v15, Landroid/text/Spanned;

    if-eqz v3, :cond_dd

    .line 16
    move-object v3, v15

    check-cast v3, Landroid/text/Spanned;

    const-class v4, Lc2/a;

    const/4 v11, -0x1

    invoke-interface {v3, v11, v6, v4}, Landroid/text/Spanned;->nextSpanTransition(IILjava/lang/Class;)I

    move-result v3

    if-ge v3, v6, :cond_dd

    const/4 v3, 0x1

    goto :goto_de

    :cond_dd
    const/4 v3, 0x0

    .line 17
    :goto_de
    iget-object v4, v1, La2/c;->a:Lkg/c;

    invoke-interface {v4}, Lkg/c;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/text/BoringLayout$Metrics;

    float-to-double v5, v2

    move/from16 p15, v8

    move/from16 p2, v9

    .line 18
    invoke-static {v5, v6}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v8

    double-to-float v8, v8

    float-to-int v8, v8

    const-string v9, "alignment"

    if-eqz v4, :cond_173

    .line 19
    iget-object v1, v1, La2/c;->c:Lkg/c;

    invoke-interface {v1}, Lkg/c;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    move-result v1

    cmpg-float v1, v1, v2

    if-gtz v1, :cond_173

    if-nez v3, :cond_173

    const/4 v1, 0x1

    .line 20
    iput-boolean v1, v0, La2/n;->h:Z

    .line 21
    invoke-static {v7, v9}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    if-ltz v8, :cond_111

    const/4 v1, 0x1

    goto :goto_112

    :cond_111
    const/4 v1, 0x0

    :goto_112
    const-string v2, "Failed requirement."

    if-eqz v1, :cond_169

    if-ltz v8, :cond_11a

    const/4 v1, 0x1

    goto :goto_11b

    :cond_11a
    const/4 v1, 0x0

    :goto_11b
    if-eqz v1, :cond_15f

    if-nez v10, :cond_13a

    .line 22
    new-instance v1, Landroid/text/BoringLayout;

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v3, 0x0

    move-object/from16 p4, v1

    move-object/from16 p5, p1

    move-object/from16 p6, p3

    move/from16 p7, v8

    move-object/from16 p8, v7

    move/from16 p9, v2

    move/from16 p10, v3

    move-object/from16 p11, v4

    move/from16 p12, v14

    invoke-direct/range {p4 .. p12}, Landroid/text/BoringLayout;-><init>(Ljava/lang/CharSequence;Landroid/text/TextPaint;ILandroid/text/Layout$Alignment;FFLandroid/text/BoringLayout$Metrics;Z)V

    goto :goto_158

    .line 23
    :cond_13a
    new-instance v1, Landroid/text/BoringLayout;

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v3, 0x0

    move-object/from16 p4, v1

    move-object/from16 p5, p1

    move-object/from16 p6, p3

    move/from16 p7, v8

    move-object/from16 p8, v7

    move/from16 p9, v2

    move/from16 p10, v3

    move-object/from16 p11, v4

    move/from16 p12, v14

    move-object/from16 p13, v10

    move/from16 p14, v8

    invoke-direct/range {p4 .. p14}, Landroid/text/BoringLayout;-><init>(Ljava/lang/CharSequence;Landroid/text/TextPaint;ILandroid/text/Layout$Alignment;FFLandroid/text/BoringLayout$Metrics;ZLandroid/text/TextUtils$TruncateAt;I)V

    :goto_158
    move/from16 v21, p2

    move/from16 p3, p15

    move/from16 v24, v14

    goto :goto_1b0

    .line 24
    :cond_15f
    new-instance v1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 25
    :cond_169
    new-instance v1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_173
    const/4 v1, 0x0

    .line 26
    iput-boolean v1, v0, La2/n;->h:Z

    .line 27
    sget-object v1, La2/h;->a:La2/h;

    const/4 v3, 0x0

    .line 28
    invoke-interface/range {p1 .. p1}, Ljava/lang/CharSequence;->length()I

    move-result v4

    .line 29
    invoke-static {v5, v6}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v1

    double-to-float v1, v1

    float-to-int v11, v1

    .line 30
    invoke-static {v7, v9}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 31
    sget-object v9, La2/h;->b:La2/i;

    .line 32
    new-instance v6, La2/k;

    move-object v1, v6

    move-object/from16 v2, p1

    move-object/from16 v5, p3

    move-object/from16 v22, v6

    move v6, v8

    move-object v8, v7

    move-object/from16 v7, v21

    move/from16 p3, p15

    move/from16 v21, p2

    move-object/from16 v23, v9

    move/from16 v9, p3

    move/from16 v24, v14

    move/from16 v14, v16

    move/from16 v15, v24

    move/from16 v16, v21

    invoke-direct/range {v1 .. v20}, La2/k;-><init>(Ljava/lang/CharSequence;IILandroid/text/TextPaint;ILandroid/text/TextDirectionHeuristic;Landroid/text/Layout$Alignment;ILandroid/text/TextUtils$TruncateAt;IFFIZZII[I[I)V

    move-object/from16 v2, v22

    move-object/from16 v1, v23

    .line 33
    invoke-interface {v1, v2}, La2/i;->a(La2/k;)Landroid/text/StaticLayout;

    move-result-object v1

    .line 34
    :goto_1b0
    iput-object v1, v0, La2/n;->d:Landroid/text/Layout;

    .line 35
    invoke-virtual {v1}, Landroid/text/Layout;->getLineCount()I

    move-result v2

    move/from16 v6, p3

    invoke-static {v2, v6}, Ljava/lang/Math;->min(II)I

    move-result v2

    iput v2, v0, La2/n;->e:I

    if-ge v2, v6, :cond_1c1

    goto :goto_1d4

    :cond_1c1
    add-int/lit8 v3, v2, -0x1

    .line 36
    invoke-virtual {v1, v3}, Landroid/text/Layout;->getEllipsisCount(I)I

    move-result v4

    if-gtz v4, :cond_1d6

    .line 37
    invoke-virtual {v1, v3}, Landroid/text/Layout;->getLineEnd(I)I

    move-result v3

    invoke-interface/range {p1 .. p1}, Ljava/lang/CharSequence;->length()I

    move-result v4

    if-eq v3, v4, :cond_1d4

    goto :goto_1d6

    :cond_1d4
    :goto_1d4
    const/4 v3, 0x0

    goto :goto_1d7

    :cond_1d6
    :goto_1d6
    const/4 v3, 0x1

    .line 38
    :goto_1d7
    iput-boolean v3, v0, La2/n;->c:Z

    if-nez v24, :cond_257

    if-eqz v21, :cond_1e9

    .line 39
    iget-boolean v3, v0, La2/n;->h:Z

    if-nez v3, :cond_1e9

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x1c

    if-lt v3, v4, :cond_1e9

    const/4 v3, 0x1

    goto :goto_1ea

    :cond_1e9
    const/4 v3, 0x0

    :goto_1ea
    if-eqz v3, :cond_1ed

    goto :goto_257

    .line 40
    :cond_1ed
    invoke-virtual {v1}, Landroid/text/Layout;->getPaint()Landroid/text/TextPaint;

    move-result-object v3

    .line 41
    invoke-virtual {v1}, Landroid/text/Layout;->getText()Ljava/lang/CharSequence;

    move-result-object v4

    const-string v5, "paint"

    .line 42
    invoke-static {v3, v5}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "text"

    .line 43
    invoke-static {v4, v5}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v5, 0x0

    .line 44
    invoke-virtual {v1, v5}, Landroid/text/Layout;->getLineStart(I)I

    move-result v6

    .line 45
    invoke-virtual {v1, v5}, Landroid/text/Layout;->getLineEnd(I)I

    move-result v7

    .line 46
    invoke-static {v3, v4, v6, v7}, Le2/z;->A(Landroid/text/TextPaint;Ljava/lang/CharSequence;II)Landroid/graphics/Rect;

    move-result-object v6

    .line 47
    invoke-virtual {v1, v5}, Landroid/text/Layout;->getLineAscent(I)I

    move-result v7

    .line 48
    iget v8, v6, Landroid/graphics/Rect;->top:I

    if-ge v8, v7, :cond_216

    sub-int/2addr v7, v8

    goto :goto_21a

    .line 49
    :cond_216
    invoke-virtual {v1}, Landroid/text/Layout;->getTopPadding()I

    move-result v7

    :goto_21a
    const/4 v8, 0x1

    if-ne v2, v8, :cond_21e

    goto :goto_22f

    .line 50
    :cond_21e
    invoke-virtual {v1}, Landroid/text/Layout;->getLineCount()I

    move-result v2

    sub-int/2addr v2, v8

    .line 51
    invoke-virtual {v1, v2}, Landroid/text/Layout;->getLineStart(I)I

    move-result v6

    invoke-virtual {v1, v2}, Landroid/text/Layout;->getLineEnd(I)I

    move-result v2

    invoke-static {v3, v4, v6, v2}, Le2/z;->A(Landroid/text/TextPaint;Ljava/lang/CharSequence;II)Landroid/graphics/Rect;

    move-result-object v6

    .line 52
    :goto_22f
    invoke-virtual {v1}, Landroid/text/Layout;->getLineCount()I

    move-result v2

    sub-int/2addr v2, v8

    invoke-virtual {v1, v2}, Landroid/text/Layout;->getLineDescent(I)I

    move-result v2

    .line 53
    iget v3, v6, Landroid/graphics/Rect;->bottom:I

    if-le v3, v2, :cond_23e

    sub-int/2addr v3, v2

    goto :goto_242

    .line 54
    :cond_23e
    invoke-virtual {v1}, Landroid/text/Layout;->getBottomPadding()I

    move-result v3

    :goto_242
    if-nez v7, :cond_249

    if-nez v3, :cond_249

    .line 55
    sget-object v1, La2/o;->a:Lkg/e;

    goto :goto_265

    .line 56
    :cond_249
    new-instance v1, Lkg/e;

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Lkg/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_265

    :cond_257
    :goto_257
    const/4 v5, 0x0

    .line 57
    new-instance v1, Lkg/e;

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Lkg/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 58
    :goto_265
    invoke-virtual/range {p0 .. p0}, La2/n;->h()Ljava/lang/CharSequence;

    move-result-object v2

    instance-of v2, v2, Landroid/text/Spanned;

    if-nez v2, :cond_270

    new-array v2, v5, [Lc2/f;

    goto :goto_295

    .line 59
    :cond_270
    invoke-virtual/range {p0 .. p0}, La2/n;->h()Ljava/lang/CharSequence;

    move-result-object v2

    check-cast v2, Landroid/text/Spanned;

    .line 60
    invoke-virtual/range {p0 .. p0}, La2/n;->h()Ljava/lang/CharSequence;

    move-result-object v3

    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    move-result v3

    const-class v4, Lc2/f;

    .line 61
    invoke-interface {v2, v5, v3, v4}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [Lc2/f;

    const-string v3, "lineHeightStyleSpans"

    .line 62
    invoke-static {v2, v3}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    array-length v3, v2

    if-nez v3, :cond_290

    const/4 v3, 0x1

    goto :goto_291

    :cond_290
    const/4 v3, 0x0

    :goto_291
    if-eqz v3, :cond_295

    new-array v2, v5, [Lc2/f;

    .line 63
    :cond_295
    :goto_295
    array-length v3, v2

    const/4 v4, 0x0

    const/4 v6, 0x0

    :goto_298
    if-ge v6, v3, :cond_2b7

    aget-object v7, v2, v6

    .line 64
    iget v8, v7, Lc2/f;->k:I

    if-gez v8, :cond_2a8

    .line 65
    invoke-static {v8}, Ljava/lang/Math;->abs(I)I

    move-result v8

    invoke-static {v5, v8}, Ljava/lang/Math;->max(II)I

    move-result v5

    .line 66
    :cond_2a8
    iget v7, v7, Lc2/f;->l:I

    if-gez v7, :cond_2b4

    .line 67
    invoke-static {v7}, Ljava/lang/Math;->abs(I)I

    move-result v4

    invoke-static {v5, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    :cond_2b4
    add-int/lit8 v6, v6, 0x1

    goto :goto_298

    :cond_2b7
    if-nez v5, :cond_2be

    if-nez v4, :cond_2be

    .line 68
    sget-object v2, La2/o;->a:Lkg/e;

    goto :goto_2cb

    .line 69
    :cond_2be
    new-instance v2, Lkg/e;

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-direct {v2, v3, v4}, Lkg/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 70
    :goto_2cb
    iget-object v3, v1, Lkg/e;->a:Ljava/lang/Object;

    .line 71
    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    .line 72
    iget-object v4, v2, Lkg/e;->a:Ljava/lang/Object;

    .line 73
    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    move-result v4

    invoke-static {v3, v4}, Ljava/lang/Math;->max(II)I

    move-result v3

    iput v3, v0, La2/n;->f:I

    .line 74
    iget-object v1, v1, Lkg/e;->b:Ljava/lang/Object;

    .line 75
    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    .line 76
    iget-object v2, v2, Lkg/e;->b:Ljava/lang/Object;

    .line 77
    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, v0, La2/n;->g:I

    .line 78
    new-instance v1, La2/m;

    invoke-direct {v1, v0}, La2/m;-><init>(La2/n;)V

    const/4 v2, 0x3

    invoke-static {v2, v1}, Ld3/g;->Q(ILvg/a;)Lkg/c;

    move-result-object v1

    iput-object v1, v0, La2/n;->i:Lkg/c;

    return-void
.end method

.method public static g(La2/n;IZI)F
    .registers 4

    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_5

    const/4 p2, 0x0

    .line 1
    :cond_5
    iget-object p0, p0, La2/n;->i:Lkg/c;

    invoke-interface {p0}, Lkg/c;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, La2/b;

    const/4 p3, 0x1

    .line 2
    invoke-virtual {p0, p1, p3, p2}, La2/b;->b(IZZ)F

    move-result p0

    return p0
.end method


# virtual methods
.method public final a()I
    .registers 3

    .line 1
    iget-boolean v0, p0, La2/n;->c:Z

    if-eqz v0, :cond_f

    .line 2
    iget-object v0, p0, La2/n;->d:Landroid/text/Layout;

    iget v1, p0, La2/n;->e:I

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v0, v1}, Landroid/text/Layout;->getLineBottom(I)I

    move-result v0

    goto :goto_15

    .line 3
    :cond_f
    iget-object v0, p0, La2/n;->d:Landroid/text/Layout;

    invoke-virtual {v0}, Landroid/text/Layout;->getHeight()I

    move-result v0

    .line 4
    :goto_15
    iget v1, p0, La2/n;->f:I

    add-int/2addr v0, v1

    iget v1, p0, La2/n;->g:I

    add-int/2addr v0, v1

    return v0
.end method

.method public final b(I)F
    .registers 4

    .line 1
    iget v0, p0, La2/n;->f:I

    int-to-float v0, v0

    iget-object v1, p0, La2/n;->d:Landroid/text/Layout;

    invoke-virtual {v1, p1}, Landroid/text/Layout;->getLineBaseline(I)I

    move-result p1

    int-to-float p1, p1

    add-float/2addr v0, p1

    return v0
.end method

.method public final c(I)F
    .registers 4

    .line 1
    iget v0, p0, La2/n;->f:I

    int-to-float v0, v0

    .line 2
    iget-object v1, p0, La2/n;->d:Landroid/text/Layout;

    invoke-virtual {v1, p1}, Landroid/text/Layout;->getLineBottom(I)I

    move-result v1

    int-to-float v1, v1

    add-float/2addr v0, v1

    .line 3
    iget v1, p0, La2/n;->e:I

    add-int/lit8 v1, v1, -0x1

    if-ne p1, v1, :cond_14

    iget p1, p0, La2/n;->g:I

    goto :goto_15

    :cond_14
    const/4 p1, 0x0

    :goto_15
    int-to-float p1, p1

    add-float/2addr v0, p1

    return v0
.end method

.method public final d(I)I
    .registers 3

    .line 1
    iget-object v0, p0, La2/n;->d:Landroid/text/Layout;

    invoke-virtual {v0, p1}, Landroid/text/Layout;->getEllipsisStart(I)I

    move-result v0

    if-nez v0, :cond_f

    .line 2
    iget-object v0, p0, La2/n;->d:Landroid/text/Layout;

    invoke-virtual {v0, p1}, Landroid/text/Layout;->getLineEnd(I)I

    move-result p1

    goto :goto_19

    .line 3
    :cond_f
    iget-object p1, p0, La2/n;->d:Landroid/text/Layout;

    invoke-virtual {p1}, Landroid/text/Layout;->getText()Ljava/lang/CharSequence;

    move-result-object p1

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result p1

    :goto_19
    return p1
.end method

.method public final e(I)I
    .registers 3

    .line 1
    iget-object v0, p0, La2/n;->d:Landroid/text/Layout;

    invoke-virtual {v0, p1}, Landroid/text/Layout;->getLineForOffset(I)I

    move-result p1

    return p1
.end method

.method public final f(I)F
    .registers 3

    .line 1
    iget-object v0, p0, La2/n;->d:Landroid/text/Layout;

    invoke-virtual {v0, p1}, Landroid/text/Layout;->getLineTop(I)I

    move-result v0

    int-to-float v0, v0

    if-nez p1, :cond_b

    const/4 p1, 0x0

    goto :goto_d

    .line 2
    :cond_b
    iget p1, p0, La2/n;->f:I

    :goto_d
    int-to-float p1, p1

    add-float/2addr v0, p1

    return v0
.end method

.method public final h()Ljava/lang/CharSequence;
    .registers 3

    .line 1
    iget-object v0, p0, La2/n;->d:Landroid/text/Layout;

    invoke-virtual {v0}, Landroid/text/Layout;->getText()Ljava/lang/CharSequence;

    move-result-object v0

    const-string v1, "layout.text"

    invoke-static {v0, v1}, Lp/h;->o(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0
.end method

.method public final i(Landroid/graphics/Canvas;)V
    .registers 5

    const-string v0, "canvas"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget v0, p0, La2/n;->f:I

    const/4 v1, 0x0

    if-eqz v0, :cond_e

    int-to-float v0, v0

    .line 2
    invoke-virtual {p1, v1, v0}, Landroid/graphics/Canvas;->translate(FF)V

    .line 3
    :cond_e
    iget-object v0, p0, La2/n;->d:Landroid/text/Layout;

    invoke-virtual {v0, p1}, Landroid/text/Layout;->draw(Landroid/graphics/Canvas;)V

    .line 4
    iget v0, p0, La2/n;->f:I

    if-eqz v0, :cond_1f

    const/4 v2, -0x1

    int-to-float v2, v2

    int-to-float v0, v0

    mul-float v2, v2, v0

    .line 5
    invoke-virtual {p1, v1, v2}, Landroid/graphics/Canvas;->translate(FF)V

    :cond_1f
    return-void
.end method
