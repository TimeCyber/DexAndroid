.class public final La2/j;
.super Ljava/lang/Object;
.source "StaticLayoutFactory.kt"

# interfaces
.implements La2/i;


# static fields
.field public static a:Z

.field public static b:Ljava/lang/reflect/Constructor;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/reflect/Constructor<",
            "Landroid/text/StaticLayout;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(La2/k;)Landroid/text/StaticLayout;
    .registers 24

    move-object/from16 v0, p1

    const-string v1, "unable to call constructor"

    const-string v2, "params"

    invoke-static {v0, v2}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    sget-boolean v2, La2/j;->a:Z

    const/16 v5, 0xa

    const/16 v6, 0x9

    const/16 v7, 0x8

    const/4 v8, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x2

    const/4 v14, 0x0

    const/16 v15, 0xd

    const/16 v16, 0x1

    const-string v3, "StaticLayoutFactory"

    const/16 v18, 0x0

    if-eqz v2, :cond_25

    .line 2
    sget-object v2, La2/j;->b:Ljava/lang/reflect/Constructor;

    goto :goto_69

    .line 3
    :cond_25
    sput-boolean v16, La2/j;->a:Z

    .line 4
    :try_start_27
    const-class v2, Landroid/text/StaticLayout;

    new-array v4, v15, [Ljava/lang/Class;

    .line 5
    const-class v20, Ljava/lang/CharSequence;

    aput-object v20, v4, v14

    sget-object v20, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    aput-object v20, v4, v16

    aput-object v20, v4, v13

    const-class v21, Landroid/text/TextPaint;

    aput-object v21, v4, v12

    aput-object v20, v4, v11

    const-class v21, Landroid/text/Layout$Alignment;

    aput-object v21, v4, v10

    const-class v21, Landroid/text/TextDirectionHeuristic;

    aput-object v21, v4, v9

    sget-object v21, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    aput-object v21, v4, v8

    aput-object v21, v4, v7

    sget-object v21, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    aput-object v21, v4, v6

    const-class v21, Landroid/text/TextUtils$TruncateAt;

    aput-object v21, v4, v5

    const/16 v19, 0xb

    aput-object v20, v4, v19

    const/16 v17, 0xc

    aput-object v20, v4, v17

    .line 6
    invoke-virtual {v2, v4}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v2

    .line 7
    sput-object v2, La2/j;->b:Ljava/lang/reflect/Constructor;
    :try_end_5f
    .catch Ljava/lang/NoSuchMethodException; {:try_start_27 .. :try_end_5f} :catch_60

    goto :goto_67

    .line 8
    :catch_60
    sput-object v18, La2/j;->b:Ljava/lang/reflect/Constructor;

    const-string v2, "unable to collect necessary constructor."

    .line 9
    invoke-static {v3, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 10
    :goto_67
    sget-object v2, La2/j;->b:Ljava/lang/reflect/Constructor;

    :goto_69
    if-eqz v2, :cond_df

    :try_start_6b
    new-array v4, v15, [Ljava/lang/Object;

    .line 11
    iget-object v15, v0, La2/k;->a:Ljava/lang/CharSequence;

    aput-object v15, v4, v14

    .line 12
    iget v14, v0, La2/k;->b:I

    .line 13
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    aput-object v14, v4, v16

    .line 14
    iget v14, v0, La2/k;->c:I

    .line 15
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    aput-object v14, v4, v13

    .line 16
    iget-object v13, v0, La2/k;->d:Landroid/text/TextPaint;

    aput-object v13, v4, v12

    .line 17
    iget v12, v0, La2/k;->e:I

    .line 18
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    aput-object v12, v4, v11

    .line 19
    iget-object v11, v0, La2/k;->g:Landroid/text/Layout$Alignment;

    aput-object v11, v4, v10

    .line 20
    iget-object v10, v0, La2/k;->f:Landroid/text/TextDirectionHeuristic;

    aput-object v10, v4, v9

    .line 21
    iget v9, v0, La2/k;->k:F

    .line 22
    invoke-static {v9}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v9

    aput-object v9, v4, v8

    .line 23
    iget v8, v0, La2/k;->l:F

    .line 24
    invoke-static {v8}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v8

    aput-object v8, v4, v7

    .line 25
    iget-boolean v7, v0, La2/k;->n:Z

    .line 26
    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v7

    aput-object v7, v4, v6

    .line 27
    iget-object v6, v0, La2/k;->i:Landroid/text/TextUtils$TruncateAt;

    aput-object v6, v4, v5

    .line 28
    iget v5, v0, La2/k;->j:I

    .line 29
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/16 v6, 0xb

    aput-object v5, v4, v6

    .line 30
    iget v5, v0, La2/k;->h:I

    .line 31
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/16 v6, 0xc

    aput-object v5, v4, v6

    .line 32
    invoke-virtual {v2, v4}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/text/StaticLayout;
    :try_end_cb
    .catch Ljava/lang/IllegalAccessException; {:try_start_6b .. :try_end_cb} :catch_da
    .catch Ljava/lang/InstantiationException; {:try_start_6b .. :try_end_cb} :catch_d4
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_6b .. :try_end_cb} :catch_ce

    move-object/from16 v18, v2

    goto :goto_df

    .line 33
    :catch_ce
    sput-object v18, La2/j;->b:Ljava/lang/reflect/Constructor;

    .line 34
    invoke-static {v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_df

    .line 35
    :catch_d4
    sput-object v18, La2/j;->b:Ljava/lang/reflect/Constructor;

    .line 36
    invoke-static {v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_df

    .line 37
    :catch_da
    sput-object v18, La2/j;->b:Ljava/lang/reflect/Constructor;

    .line 38
    invoke-static {v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_df
    :goto_df
    if-eqz v18, :cond_e2

    return-object v18

    .line 39
    :cond_e2
    new-instance v12, Landroid/text/StaticLayout;

    .line 40
    iget-object v1, v0, La2/k;->a:Ljava/lang/CharSequence;

    .line 41
    iget v2, v0, La2/k;->b:I

    .line 42
    iget v3, v0, La2/k;->c:I

    .line 43
    iget-object v4, v0, La2/k;->d:Landroid/text/TextPaint;

    .line 44
    iget v5, v0, La2/k;->e:I

    .line 45
    iget-object v6, v0, La2/k;->g:Landroid/text/Layout$Alignment;

    .line 46
    iget v7, v0, La2/k;->k:F

    .line 47
    iget v8, v0, La2/k;->l:F

    .line 48
    iget-boolean v9, v0, La2/k;->n:Z

    .line 49
    iget-object v10, v0, La2/k;->i:Landroid/text/TextUtils$TruncateAt;

    .line 50
    iget v11, v0, La2/k;->j:I

    move-object v0, v12

    .line 51
    invoke-direct/range {v0 .. v11}, Landroid/text/StaticLayout;-><init>(Ljava/lang/CharSequence;IILandroid/text/TextPaint;ILandroid/text/Layout$Alignment;FFZLandroid/text/TextUtils$TruncateAt;I)V

    return-object v12
.end method
