.class public final La7/u$a;
.super Ljava/util/concurrent/LinkedBlockingQueue;
.source "ThreadUtils.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La7/u;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/util/concurrent/LinkedBlockingQueue<",
        "Ljava/lang/Runnable;",
        ">;"
    }
.end annotation


# instance fields
.field public volatile a:La7/u$b;

.field public b:I


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    const v0, 0x7fffffff

    .line 2
    iput v0, p0, La7/u$a;->b:I

    return-void
.end method

.method public constructor <init>(Z)V
    .registers 3

    .line 3
    invoke-direct {p0}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    const v0, 0x7fffffff

    .line 4
    iput v0, p0, La7/u$a;->b:I

    if-eqz p1, :cond_d

    const/4 p1, 0x0

    .line 5
    iput p1, p0, La7/u$a;->b:I

    :cond_d
    return-void
.end method


# virtual methods
.method public b(Ljava/lang/Runnable;)Z
    .registers 4

    .line 1
    iget v0, p0, La7/u$a;->b:I

    invoke-virtual {p0}, Ljava/util/concurrent/LinkedBlockingQueue;->size()I

    move-result v1

    if-gt v0, v1, :cond_1c

    iget-object v0, p0, La7/u$a;->a:La7/u$b;

    if-eqz v0, :cond_1c

    iget-object v0, p0, La7/u$a;->a:La7/u$b;

    .line 2
    invoke-virtual {v0}, Ljava/util/concurrent/ThreadPoolExecutor;->getPoolSize()I

    move-result v0

    iget-object v1, p0, La7/u$a;->a:La7/u$b;

    invoke-virtual {v1}, Ljava/util/concurrent/ThreadPoolExecutor;->getMaximumPoolSize()I

    move-result v1

    if-ge v0, v1, :cond_1c

    const/4 p1, 0x0

    return p1

    .line 3
    :cond_1c
    invoke-super {p0, p1}, Ljava/util/concurrent/LinkedBlockingQueue;->offer(Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public bridge synthetic offer(Ljava/lang/Object;)Z
    .registers 2

    .line 1
    check-cast p1, Ljava/lang/Runnable;

    invoke-virtual {p0, p1}, La7/u$a;->b(Ljava/lang/Runnable;)Z

    move-result p1

    return p1
.end method
