.class public final La0/k;
.super La0/n;
.source "AnimationVectors.kt"


# instance fields
.field public a:F


# direct methods
.method public constructor <init>(F)V
    .registers 3

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, La0/n;-><init>(Lwg/e;)V

    .line 2
    iput p1, p0, La0/k;->a:F

    return-void
.end method


# virtual methods
.method public a(I)F
    .registers 2

    if-nez p1, :cond_5

    .line 1
    iget p1, p0, La0/k;->a:F

    return p1

    :cond_5
    const/4 p1, 0x0

    return p1
.end method

.method public b()I
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public c()La0/n;
    .registers 3

    .line 1
    new-instance v0, La0/k;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, La0/k;-><init>(F)V

    return-object v0
.end method

.method public d()V
    .registers 2

    const/4 v0, 0x0

    .line 1
    iput v0, p0, La0/k;->a:F

    return-void
.end method

.method public e(IF)V
    .registers 3

    if-nez p1, :cond_4

    .line 1
    iput p2, p0, La0/k;->a:F

    :cond_4
    return-void
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 5

    .line 1
    instance-of v0, p1, La0/k;

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_16

    check-cast p1, La0/k;

    iget p1, p1, La0/k;->a:F

    iget v0, p0, La0/k;->a:F

    cmpg-float p1, p1, v0

    if-nez p1, :cond_12

    const/4 p1, 0x1

    goto :goto_13

    :cond_12
    const/4 p1, 0x0

    :goto_13
    if-eqz p1, :cond_16

    goto :goto_17

    :cond_16
    const/4 v1, 0x0

    :goto_17
    return v1
.end method

.method public hashCode()I
    .registers 2

    .line 1
    iget v0, p0, La0/k;->a:F

    invoke-static {v0}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    const-string v0, "AnimationVector1D: value = "

    .line 1
    invoke-static {v0}, Landroid/support/v4/media/a;->e(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, La0/k;->a:F

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
