.class public final La0/o0;
.super Lwg/j;
.source "SuspendAnimation.kt"

# interfaces
.implements Lvg/l;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lwg/j;",
        "Lvg/l<",
        "La0/f<",
        "Ljava/lang/Object;",
        "La0/n;",
        ">;",
        "Lkg/l;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic a:Lvg/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lvg/p<",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            "Lkg/l;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic b:La0/u0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/u0<",
            "Ljava/lang/Object;",
            "La0/n;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lvg/p;La0/u0;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lvg/p<",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            "Lkg/l;",
            ">;",
            "La0/u0<",
            "Ljava/lang/Object;",
            "La0/n;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La0/o0;->a:Lvg/p;

    iput-object p2, p0, La0/o0;->b:La0/u0;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lwg/j;-><init>(I)V

    return-void
.end method


# virtual methods
.method public invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    check-cast p1, La0/f;

    const-string v0, "$this$animate"

    .line 2
    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    iget-object v0, p0, La0/o0;->a:Lvg/p;

    invoke-virtual {p1}, La0/f;->a()Ljava/lang/Object;

    move-result-object v1

    iget-object v2, p0, La0/o0;->b:La0/u0;

    invoke-interface {v2}, La0/u0;->b()Lvg/l;

    move-result-object v2

    .line 4
    iget-object p1, p1, La0/f;->f:La0/n;

    .line 5
    invoke-interface {v2, p1}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    invoke-interface {v0, v1, p1}, Lvg/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    sget-object p1, Lkg/l;->a:Lkg/l;

    return-object p1
.end method
