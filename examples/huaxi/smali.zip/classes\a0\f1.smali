.class public final La0/f1;
.super Ljava/lang/Object;
.source "DecayAnimationSpec.kt"

# interfaces
.implements La0/b1;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<V:",
        "La0/n;",
        ">",
        "Ljava/lang/Object;",
        "La0/b1<",
        "TV;>;"
    }
.end annotation


# instance fields
.field public final a:La0/a0;

.field public b:La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field

.field public c:La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field

.field public d:La0/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field

.field public final e:F


# direct methods
.method public constructor <init>(La0/a0;)V
    .registers 3

    const-string v0, "floatDecaySpec"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, La0/f1;->a:La0/a0;

    .line 3
    invoke-interface {p1}, La0/a0;->a()F

    move-result p1

    iput p1, p0, La0/f1;->e:F

    return-void
.end method


# virtual methods
.method public a()F
    .registers 2

    .line 1
    iget v0, p0, La0/f1;->e:F

    return v0
.end method

.method public b(JLa0/n;La0/n;)La0/n;
    .registers 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JTV;TV;)TV;"
        }
    .end annotation

    const-string v0, "initialValue"

    invoke-static {p3, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "initialVelocity"

    invoke-static {p4, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object v0, p0, La0/f1;->c:La0/n;

    if-nez v0, :cond_14

    .line 2
    invoke-static {p3}, Landroidx/appcompat/widget/m;->M(La0/n;)La0/n;

    move-result-object v0

    iput-object v0, p0, La0/f1;->c:La0/n;

    :cond_14
    const/4 v0, 0x0

    .line 3
    iget-object v1, p0, La0/f1;->c:La0/n;

    const/4 v2, 0x0

    const-string v3, "velocityVector"

    if-eqz v1, :cond_47

    invoke-virtual {v1}, La0/n;->b()I

    move-result v1

    :goto_20
    if-ge v0, v1, :cond_3e

    .line 4
    iget-object v4, p0, La0/f1;->c:La0/n;

    if-eqz v4, :cond_3a

    iget-object v5, p0, La0/f1;->a:La0/a0;

    .line 5
    invoke-virtual {p3, v0}, La0/n;->a(I)F

    move-result v6

    .line 6
    invoke-virtual {p4, v0}, La0/n;->a(I)F

    move-result v7

    .line 7
    invoke-interface {v5, p1, p2, v6, v7}, La0/a0;->b(JFF)F

    move-result v5

    invoke-virtual {v4, v0, v5}, La0/n;->e(IF)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_20

    :cond_3a
    invoke-static {v3}, Lp/h;->b0(Ljava/lang/String;)V

    throw v2

    .line 8
    :cond_3e
    iget-object p1, p0, La0/f1;->c:La0/n;

    if-eqz p1, :cond_43

    return-object p1

    :cond_43
    invoke-static {v3}, Lp/h;->b0(Ljava/lang/String;)V

    throw v2

    .line 9
    :cond_47
    invoke-static {v3}, Lp/h;->b0(Ljava/lang/String;)V

    throw v2
.end method

.method public c(La0/n;La0/n;)J
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;TV;)J"
        }
    .end annotation

    const-string v0, "initialValue"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object v0, p0, La0/f1;->c:La0/n;

    if-nez v0, :cond_f

    .line 2
    invoke-static {p1}, Landroidx/appcompat/widget/m;->M(La0/n;)La0/n;

    move-result-object v0

    iput-object v0, p0, La0/f1;->c:La0/n;

    :cond_f
    const/4 v0, 0x0

    .line 3
    iget-object v1, p0, La0/f1;->c:La0/n;

    if-eqz v1, :cond_32

    invoke-virtual {v1}, La0/n;->b()I

    move-result v1

    const-wide/16 v2, 0x0

    :goto_1a
    if-ge v0, v1, :cond_31

    .line 4
    iget-object v4, p0, La0/f1;->a:La0/a0;

    invoke-virtual {p1, v0}, La0/n;->a(I)F

    move-result v5

    invoke-virtual {p2, v0}, La0/n;->a(I)F

    move-result v6

    invoke-interface {v4, v5, v6}, La0/a0;->c(FF)J

    move-result-wide v4

    invoke-static {v2, v3, v4, v5}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v2

    add-int/lit8 v0, v0, 0x1

    goto :goto_1a

    :cond_31
    return-wide v2

    :cond_32
    const-string p1, "velocityVector"

    .line 5
    invoke-static {p1}, Lp/h;->b0(Ljava/lang/String;)V

    const/4 p1, 0x0

    throw p1
.end method

.method public d(JLa0/n;La0/n;)La0/n;
    .registers 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JTV;TV;)TV;"
        }
    .end annotation

    const-string v0, "initialValue"

    invoke-static {p3, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "initialVelocity"

    invoke-static {p4, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object v0, p0, La0/f1;->b:La0/n;

    if-nez v0, :cond_14

    .line 2
    invoke-static {p3}, Landroidx/appcompat/widget/m;->M(La0/n;)La0/n;

    move-result-object v0

    iput-object v0, p0, La0/f1;->b:La0/n;

    :cond_14
    const/4 v0, 0x0

    .line 3
    iget-object v1, p0, La0/f1;->b:La0/n;

    const/4 v2, 0x0

    const-string v3, "valueVector"

    if-eqz v1, :cond_47

    invoke-virtual {v1}, La0/n;->b()I

    move-result v1

    :goto_20
    if-ge v0, v1, :cond_3e

    .line 4
    iget-object v4, p0, La0/f1;->b:La0/n;

    if-eqz v4, :cond_3a

    iget-object v5, p0, La0/f1;->a:La0/a0;

    .line 5
    invoke-virtual {p3, v0}, La0/n;->a(I)F

    move-result v6

    .line 6
    invoke-virtual {p4, v0}, La0/n;->a(I)F

    move-result v7

    .line 7
    invoke-interface {v5, p1, p2, v6, v7}, La0/a0;->e(JFF)F

    move-result v5

    invoke-virtual {v4, v0, v5}, La0/n;->e(IF)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_20

    :cond_3a
    invoke-static {v3}, Lp/h;->b0(Ljava/lang/String;)V

    throw v2

    .line 8
    :cond_3e
    iget-object p1, p0, La0/f1;->b:La0/n;

    if-eqz p1, :cond_43

    return-object p1

    :cond_43
    invoke-static {v3}, Lp/h;->b0(Ljava/lang/String;)V

    throw v2

    .line 9
    :cond_47
    invoke-static {v3}, Lp/h;->b0(Ljava/lang/String;)V

    throw v2
.end method

.method public e(La0/n;La0/n;)La0/n;
    .registers 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;TV;)TV;"
        }
    .end annotation

    const-string v0, "initialValue"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object v0, p0, La0/f1;->d:La0/n;

    if-nez v0, :cond_f

    .line 2
    invoke-static {p1}, Landroidx/appcompat/widget/m;->M(La0/n;)La0/n;

    move-result-object v0

    iput-object v0, p0, La0/f1;->d:La0/n;

    :cond_f
    const/4 v0, 0x0

    .line 3
    iget-object v1, p0, La0/f1;->d:La0/n;

    const-string v2, "targetVector"

    const/4 v3, 0x0

    if-eqz v1, :cond_42

    invoke-virtual {v1}, La0/n;->b()I

    move-result v1

    :goto_1b
    if-ge v0, v1, :cond_39

    .line 4
    iget-object v4, p0, La0/f1;->d:La0/n;

    if-eqz v4, :cond_35

    iget-object v5, p0, La0/f1;->a:La0/a0;

    .line 5
    invoke-virtual {p1, v0}, La0/n;->a(I)F

    move-result v6

    .line 6
    invoke-virtual {p2, v0}, La0/n;->a(I)F

    move-result v7

    .line 7
    invoke-interface {v5, v6, v7}, La0/a0;->d(FF)F

    move-result v5

    invoke-virtual {v4, v0, v5}, La0/n;->e(IF)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_1b

    :cond_35
    invoke-static {v2}, Lp/h;->b0(Ljava/lang/String;)V

    throw v3

    .line 8
    :cond_39
    iget-object p1, p0, La0/f1;->d:La0/n;

    if-eqz p1, :cond_3e

    return-object p1

    :cond_3e
    invoke-static {v2}, Lp/h;->b0(Ljava/lang/String;)V

    throw v3

    .line 9
    :cond_42
    invoke-static {v2}, Lp/h;->b0(Ljava/lang/String;)V

    throw v3
.end method
