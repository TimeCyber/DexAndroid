.class public final La1/k$a;
.super Lwg/j;
.source "PainterModifier.kt"

# interfaces
.implements Lvg/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La1/k;->e0(Lr1/b0;Lr1/x;J)Lr1/z;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lwg/j;",
        "Lvg/l<",
        "Lr1/m0$a;",
        "Lkg/l;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic a:Lr1/m0;


# direct methods
.method public constructor <init>(Lr1/m0;)V
    .registers 2

    iput-object p1, p0, La1/k$a;->a:Lr1/m0;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lwg/j;-><init>(I)V

    return-void
.end method


# virtual methods
.method public invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    .line 1
    move-object v0, p1

    check-cast v0, Lr1/m0$a;

    const-string p1, "$this$layout"

    .line 2
    invoke-static {v0, p1}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    iget-object v1, p0, La1/k$a;->a:Lr1/m0;

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static/range {v0 .. v6}, Lr1/m0$a;->f(Lr1/m0$a;Lr1/m0;IIFILjava/lang/Object;)V

    .line 4
    sget-object p1, Lkg/l;->a:Lkg/l;

    return-object p1
.end method
