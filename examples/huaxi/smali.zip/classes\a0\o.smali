.class public interface abstract La0/o;
.super Ljava/lang/Object;
.source "VectorizedAnimationSpec.kt"


# virtual methods
.method public abstract get(I)La0/z;
.end method
