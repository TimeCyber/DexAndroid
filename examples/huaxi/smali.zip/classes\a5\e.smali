.class public La5/e;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lanet/channel/bytes/ByteArray;

.field public final synthetic c:I

.field public final synthetic d:Lu4/h;

.field public final synthetic e:La5/c;


# direct methods
.method public constructor <init>(La5/c;ILanet/channel/bytes/ByteArray;ILu4/h;)V
    .registers 6

    .line 1
    iput-object p1, p0, La5/e;->e:La5/c;

    iput p2, p0, La5/e;->a:I

    iput-object p3, p0, La5/e;->b:Lanet/channel/bytes/ByteArray;

    iput p4, p0, La5/e;->c:I

    iput-object p5, p0, La5/e;->d:Lu4/h;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 6

    .line 1
    iget-object v0, p0, La5/e;->e:La5/c;

    .line 2
    iget-boolean v1, v0, La5/c;->d:Z

    if-nez v1, :cond_21

    .line 3
    new-instance v0, Lu4/c;

    iget v1, p0, La5/e;->a:I

    iget-object v2, p0, La5/e;->b:Lanet/channel/bytes/ByteArray;

    invoke-virtual {v2}, Lanet/channel/bytes/ByteArray;->getDataLength()I

    move-result v2

    iget v3, p0, La5/e;->c:I

    iget-object v4, p0, La5/e;->b:Lanet/channel/bytes/ByteArray;

    invoke-virtual {v4}, Lanet/channel/bytes/ByteArray;->getBuffer()[B

    move-result-object v4

    invoke-direct {v0, v1, v2, v3, v4}, Lu4/c;-><init>(III[B)V

    .line 4
    :try_start_1b
    iget-object v1, p0, La5/e;->d:Lu4/h;

    invoke-interface {v1, v0}, Lu4/h;->c(Lu4/c;)V
    :try_end_20
    .catch Landroid/os/RemoteException; {:try_start_1b .. :try_end_20} :catch_5a

    goto :goto_5a

    .line 5
    :cond_21
    :try_start_21
    iget-object v1, v0, La5/c;->c:Lv4/c;

    if-nez v1, :cond_4b

    .line 6
    new-instance v1, Lv4/c;

    invoke-direct {v1}, Lv4/c;-><init>()V

    .line 7
    iput-object v1, v0, La5/c;->c:Lv4/c;

    .line 8
    iget-object v0, p0, La5/e;->e:La5/c;

    .line 9
    iget-object v1, v0, La5/c;->c:Lv4/c;

    .line 10
    iget-object v0, v0, La5/c;->e:La5/g;

    .line 11
    iget v2, p0, La5/e;->c:I

    .line 12
    iput v2, v1, Lv4/c;->e:I

    .line 13
    iget-object v2, v0, La5/g;->i:Ljava/lang/String;

    .line 14
    iget v0, v0, La5/g;->h:I

    iput v0, v1, Lv4/c;->f:I

    .line 15
    iget-object v0, p0, La5/e;->b:Lanet/channel/bytes/ByteArray;

    invoke-virtual {v1, v0}, Lv4/c;->o(Lanet/channel/bytes/ByteArray;)V

    .line 16
    iget-object v0, p0, La5/e;->d:Lu4/h;

    iget-object v1, p0, La5/e;->e:La5/c;

    .line 17
    iget-object v1, v1, La5/c;->c:Lv4/c;

    .line 18
    invoke-interface {v0, v1}, Lu4/h;->i(Lu4/g;)V

    goto :goto_5a

    .line 19
    :cond_4b
    iget-object v0, p0, La5/e;->b:Lanet/channel/bytes/ByteArray;

    invoke-virtual {v1, v0}, Lv4/c;->o(Lanet/channel/bytes/ByteArray;)V
    :try_end_50
    .catch Ljava/lang/Exception; {:try_start_21 .. :try_end_50} :catch_51

    goto :goto_5a

    .line 20
    :catch_51
    iget-object v0, p0, La5/e;->e:La5/c;

    .line 21
    iget-object v0, v0, La5/c;->c:Lv4/c;

    if-eqz v0, :cond_5a

    .line 22
    :try_start_57
    invoke-virtual {v0}, Lv4/c;->j()V
    :try_end_5a
    .catch Landroid/os/RemoteException; {:try_start_57 .. :try_end_5a} :catch_5a

    :catch_5a
    :cond_5a
    :goto_5a
    return-void
.end method
