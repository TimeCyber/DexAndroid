.class public abstract La0/n;
.super Ljava/lang/Object;
.source "AnimationVectors.kt"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lwg/e;)V
    .registers 2

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract a(I)F
.end method

.method public abstract b()I
.end method

.method public abstract c()La0/n;
.end method

.method public abstract d()V
.end method

.method public abstract e(IF)V
.end method
