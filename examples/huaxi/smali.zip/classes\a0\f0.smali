.class public final La0/f0;
.super Ljava/lang/Object;
.source "AnimationSpec.kt"

# interfaces
.implements La0/v;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La0/f0$b;,
        La0/f0$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "La0/v<",
        "TT;>;"
    }
.end annotation


# instance fields
.field public final a:La0/f0$b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La0/f0$b<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(La0/f0$b;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La0/f0$b<",
            "TT;>;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, La0/f0;->a:La0/f0$b;

    return-void
.end method


# virtual methods
.method public bridge synthetic a(La0/u0;)La0/d1;
    .registers 2

    .line 2
    invoke-virtual {p0, p1}, La0/f0;->f(La0/u0;)La0/h1;

    move-result-object p1

    return-object p1
.end method

.method public bridge synthetic a(La0/u0;)La0/y0;
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, La0/f0;->f(La0/u0;)La0/h1;

    move-result-object p1

    return-object p1
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 3

    .line 1
    instance-of v0, p1, La0/f0;

    if-eqz v0, :cond_12

    .line 2
    iget-object v0, p0, La0/f0;->a:La0/f0$b;

    check-cast p1, La0/f0;

    iget-object p1, p1, La0/f0;->a:La0/f0$b;

    invoke-static {v0, p1}, Lp/h;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_12

    const/4 p1, 0x1

    goto :goto_13

    :cond_12
    const/4 p1, 0x0

    :goto_13
    return p1
.end method

.method public f(La0/u0;)La0/h1;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<V:",
            "La0/n;",
            ">(",
            "La0/u0<",
            "TT;TV;>;)",
            "La0/h1<",
            "TV;>;"
        }
    .end annotation

    const-string v0, "converter"

    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object v0, p0, La0/f0;->a:La0/f0$b;

    .line 2
    iget-object v0, v0, La0/f0$b;->b:Ljava/util/Map;

    .line 3
    new-instance v1, Ljava/util/LinkedHashMap;

    invoke-interface {v0}, Ljava/util/Map;->size()I

    move-result v2

    invoke-static {v2}, Li0/z0;->E(I)I

    move-result v2

    invoke-direct {v1, v2}, Ljava/util/LinkedHashMap;-><init>(I)V

    .line 4
    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    .line 5
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1e
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_51

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    .line 6
    check-cast v2, Ljava/util/Map$Entry;

    .line 7
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    .line 8
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La0/f0$a;

    invoke-interface {p1}, La0/u0;->a()Lvg/l;

    move-result-object v4

    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const-string v5, "convertToVector"

    .line 9
    invoke-static {v4, v5}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    iget-object v5, v2, La0/f0$a;->a:Ljava/lang/Object;

    invoke-interface {v4, v5}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    iget-object v2, v2, La0/f0$a;->b:La0/w;

    .line 11
    new-instance v5, Lkg/e;

    invoke-direct {v5, v4, v2}, Lkg/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 12
    invoke-interface {v1, v3, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1e

    .line 13
    :cond_51
    iget-object p1, p0, La0/f0;->a:La0/f0$b;

    .line 14
    iget v0, p1, La0/f0$b;->a:I

    .line 15
    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 p1, 0x0

    .line 16
    new-instance v2, La0/h1;

    invoke-direct {v2, v1, v0, p1}, La0/h1;-><init>(Ljava/util/Map;II)V

    return-object v2
.end method

.method public hashCode()I
    .registers 2

    .line 1
    iget-object v0, p0, La0/f0;->a:La0/f0$b;

    invoke-virtual {v0}, La0/f0$b;->hashCode()I

    move-result v0

    return v0
.end method
