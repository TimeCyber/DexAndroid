.class public final La0/h0;
.super Lqg/i;
.source "InternalMutatorMutex.kt"

# interfaces
.implements Lvg/p;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lqg/i;",
        "Lvg/p<",
        "Lgh/e0;",
        "Log/d<",
        "Ljava/lang/Object;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lqg/e;
    c = "androidx.compose.animation.core.MutatorMutex$mutate$2"
    f = "InternalMutatorMutex.kt"
    l = {
        0xab,
        0x77
    }
    m = "invokeSuspend"
.end annotation


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Ljava/lang/Object;

.field public c:Ljava/lang/Object;

.field public d:I

.field public synthetic e:Ljava/lang/Object;

.field public final synthetic f:I

.field public final synthetic g:La0/g0;

.field public final synthetic h:Lvg/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lvg/l<",
            "Log/d<",
            "Ljava/lang/Object;",
            ">;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(ILa0/g0;Lvg/l;Log/d;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "La0/g0;",
            "Lvg/l<",
            "-",
            "Log/d<",
            "Ljava/lang/Object;",
            ">;+",
            "Ljava/lang/Object;",
            ">;",
            "Log/d<",
            "-",
            "La0/h0;",
            ">;)V"
        }
    .end annotation

    iput p1, p0, La0/h0;->f:I

    iput-object p2, p0, La0/h0;->g:La0/g0;

    iput-object p3, p0, La0/h0;->h:Lvg/l;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lqg/i;-><init>(ILog/d;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Log/d;)Log/d;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Log/d<",
            "*>;)",
            "Log/d<",
            "Lkg/l;",
            ">;"
        }
    .end annotation

    new-instance v0, La0/h0;

    iget v1, p0, La0/h0;->f:I

    iget-object v2, p0, La0/h0;->g:La0/g0;

    iget-object v3, p0, La0/h0;->h:Lvg/l;

    invoke-direct {v0, v1, v2, v3, p2}, La0/h0;-><init>(ILa0/g0;Lvg/l;Log/d;)V

    iput-object p1, v0, La0/h0;->e:Ljava/lang/Object;

    return-object v0
.end method

.method public invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    check-cast p1, Lgh/e0;

    check-cast p2, Log/d;

    .line 1
    new-instance v0, La0/h0;

    iget v1, p0, La0/h0;->f:I

    iget-object v2, p0, La0/h0;->g:La0/g0;

    iget-object v3, p0, La0/h0;->h:Lvg/l;

    invoke-direct {v0, v1, v2, v3, p2}, La0/h0;-><init>(ILa0/g0;Lvg/l;Log/d;)V

    iput-object p1, v0, La0/h0;->e:Ljava/lang/Object;

    .line 2
    sget-object p1, Lkg/l;->a:Lkg/l;

    invoke-virtual {v0, p1}, La0/h0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 11

    sget-object v0, Lpg/a;->a:Lpg/a;

    .line 1
    iget v1, p0, La0/h0;->d:I

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eqz v1, :cond_42

    if-eq v1, v3, :cond_29

    if-ne v1, v4, :cond_21

    iget-object v0, p0, La0/h0;->b:Ljava/lang/Object;

    check-cast v0, La0/g0;

    iget-object v1, p0, La0/h0;->a:Ljava/lang/Object;

    check-cast v1, Loh/b;

    iget-object v3, p0, La0/h0;->e:Ljava/lang/Object;

    check-cast v3, La0/g0$a;

    :try_start_19
    invoke-static {p1}, Lo1/a0;->H(Ljava/lang/Object;)V
    :try_end_1c
    .catchall {:try_start_19 .. :try_end_1c} :catchall_1e

    goto/16 :goto_be

    :catchall_1e
    move-exception p1

    goto/16 :goto_cd

    .line 2
    :cond_21
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 3
    :cond_29
    iget-object v1, p0, La0/h0;->c:Ljava/lang/Object;

    check-cast v1, La0/g0;

    iget-object v3, p0, La0/h0;->b:Ljava/lang/Object;

    check-cast v3, Lvg/l;

    iget-object v5, p0, La0/h0;->a:Ljava/lang/Object;

    check-cast v5, Loh/b;

    iget-object v6, p0, La0/h0;->e:Ljava/lang/Object;

    check-cast v6, La0/g0$a;

    invoke-static {p1}, Lo1/a0;->H(Ljava/lang/Object;)V

    move-object p1, v1

    move-object v1, v5

    move-object v8, v6

    move-object v6, v3

    move-object v3, v8

    goto :goto_ab

    :cond_42
    invoke-static {p1}, Lo1/a0;->H(Ljava/lang/Object;)V

    iget-object p1, p0, La0/h0;->e:Ljava/lang/Object;

    check-cast p1, Lgh/e0;

    .line 4
    new-instance v1, La0/g0$a;

    iget v5, p0, La0/h0;->f:I

    invoke-interface {p1}, Lgh/e0;->getCoroutineContext()Log/f;

    move-result-object p1

    sget-object v6, Lgh/g1$b;->a:Lgh/g1$b;

    invoke-interface {p1, v6}, Log/f;->get(Log/f$b;)Log/f$a;

    move-result-object p1

    invoke-static {p1}, Lp/h;->m(Ljava/lang/Object;)V

    check-cast p1, Lgh/g1;

    invoke-direct {v1, v5, p1}, La0/g0$a;-><init>(ILgh/g1;)V

    .line 5
    iget-object p1, p0, La0/h0;->g:La0/g0;

    .line 6
    :cond_61
    iget-object v5, p1, La0/g0;->a:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v5}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La0/g0$a;

    if-eqz v5, :cond_83

    .line 7
    iget v6, v1, La0/g0$a;->a:I

    iget v7, v5, La0/g0$a;->a:I

    invoke-static {v6, v7}, Lm/o;->b(II)I

    move-result v6

    if-ltz v6, :cond_77

    const/4 v6, 0x1

    goto :goto_78

    :cond_77
    const/4 v6, 0x0

    :goto_78
    if-eqz v6, :cond_7b

    goto :goto_83

    .line 8
    :cond_7b
    new-instance p1, Ljava/util/concurrent/CancellationException;

    const-string v0, "Current mutation had a higher priority"

    invoke-direct {p1, v0}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 9
    :cond_83
    :goto_83
    iget-object v6, p1, La0/g0;->a:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v6, v5, v1}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_61

    if-eqz v5, :cond_92

    .line 10
    iget-object p1, v5, La0/g0$a;->b:Lgh/g1;

    .line 11
    invoke-interface {p1, v2}, Lgh/g1;->b(Ljava/util/concurrent/CancellationException;)V

    .line 12
    :cond_92
    iget-object p1, p0, La0/h0;->g:La0/g0;

    .line 13
    iget-object v5, p1, La0/g0;->b:Loh/b;

    .line 14
    iget-object v6, p0, La0/h0;->h:Lvg/l;

    .line 15
    iput-object v1, p0, La0/h0;->e:Ljava/lang/Object;

    iput-object v5, p0, La0/h0;->a:Ljava/lang/Object;

    iput-object v6, p0, La0/h0;->b:Ljava/lang/Object;

    iput-object p1, p0, La0/h0;->c:Ljava/lang/Object;

    iput v3, p0, La0/h0;->d:I

    invoke-interface {v5, v2, p0}, Loh/b;->a(Ljava/lang/Object;Log/d;)Ljava/lang/Object;

    move-result-object v3

    if-ne v3, v0, :cond_a9

    return-object v0

    :cond_a9
    move-object v3, v1

    move-object v1, v5

    .line 16
    :goto_ab
    :try_start_ab
    iput-object v3, p0, La0/h0;->e:Ljava/lang/Object;

    iput-object v1, p0, La0/h0;->a:Ljava/lang/Object;

    iput-object p1, p0, La0/h0;->b:Ljava/lang/Object;

    iput-object v2, p0, La0/h0;->c:Ljava/lang/Object;

    iput v4, p0, La0/h0;->d:I

    invoke-interface {v6, p0}, Lvg/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4
    :try_end_b9
    .catchall {:try_start_ab .. :try_end_b9} :catchall_c9

    if-ne v4, v0, :cond_bc

    return-object v0

    :cond_bc
    move-object v0, p1

    move-object p1, v4

    .line 17
    :goto_be
    :try_start_be
    iget-object v0, v0, La0/g0;->a:Ljava/util/concurrent/atomic/AtomicReference;

    .line 18
    invoke-virtual {v0, v3, v2}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z
    :try_end_c3
    .catchall {:try_start_be .. :try_end_c3} :catchall_c7

    .line 19
    invoke-interface {v1, v2}, Loh/b;->c(Ljava/lang/Object;)V

    return-object p1

    :catchall_c7
    move-exception p1

    goto :goto_d3

    :catchall_c9
    move-exception v0

    move-object v8, v0

    move-object v0, p1

    move-object p1, v8

    .line 20
    :goto_cd
    :try_start_cd
    iget-object v0, v0, La0/g0;->a:Ljava/util/concurrent/atomic/AtomicReference;

    .line 21
    invoke-virtual {v0, v3, v2}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    throw p1
    :try_end_d3
    .catchall {:try_start_cd .. :try_end_d3} :catchall_c7

    .line 22
    :goto_d3
    invoke-interface {v1, v2}, Loh/b;->c(Ljava/lang/Object;)V

    throw p1
.end method
