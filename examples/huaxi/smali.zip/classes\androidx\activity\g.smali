.class public final synthetic Landroidx/activity/g;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lk3/a;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .registers 3

    .line 1
    iput p2, p0, Landroidx/activity/g;->a:I

    iput-object p1, p0, Landroidx/activity/g;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)V
    .registers 4

    iget v0, p0, Landroidx/activity/g;->a:I

    packed-switch v0, :pswitch_data_38

    goto :goto_19

    :pswitch_6
    iget-object v0, p0, Landroidx/activity/g;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/activity/OnBackPressedDispatcher;

    check-cast p1, Ljava/lang/Boolean;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1
    invoke-static {}, Lh3/a;->a()Z

    move-result p1

    if-eqz p1, :cond_18

    .line 2
    invoke-virtual {v0}, Landroidx/activity/OnBackPressedDispatcher;->d()V

    :cond_18
    return-void

    .line 3
    :goto_19
    iget-object v0, p0, Landroidx/activity/g;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/camera/view/d$b;

    check-cast p1, Lm/e1$a;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const-string p1, "SurfaceViewImpl"

    const-string v1, "Safe to release surface."

    .line 4
    invoke-static {p1, v1}, Lm/w0;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 5
    iget-object p1, v0, Landroidx/camera/view/d$b;->e:Landroidx/camera/view/d;

    .line 6
    iget-object v0, p1, Landroidx/camera/view/d;->g:Landroidx/camera/view/c$a;

    if-eqz v0, :cond_37

    .line 7
    check-cast v0, Lu/c;

    invoke-virtual {v0}, Lu/c;->a()V

    const/4 v0, 0x0

    .line 8
    iput-object v0, p1, Landroidx/camera/view/d;->g:Landroidx/camera/view/c$a;

    :cond_37
    return-void

    :pswitch_data_38
    .packed-switch 0x0
        :pswitch_6
    .end packed-switch
.end method
