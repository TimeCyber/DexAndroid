.class public final synthetic La0/x0;
.super Ljava/lang/Object;
.source "VectorizedAnimationSpec.kt"


# direct methods
.method public static a(La0/y0;La0/n;La0/n;La0/n;)La0/n;
    .registers 11

    const-string v0, "initialValue"

    .line 1
    invoke-static {p1, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "targetValue"

    invoke-static {p2, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "initialVelocity"

    invoke-static {p3, v0}, Lp/h;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    invoke-interface {p0, p1, p2, p3}, La0/y0;->b(La0/n;La0/n;La0/n;)J

    move-result-wide v2

    move-object v1, p0

    move-object v4, p1

    move-object v5, p2

    move-object v6, p3

    .line 3
    invoke-interface/range {v1 .. v6}, La0/y0;->c(JLa0/n;La0/n;La0/n;)La0/n;

    move-result-object p0

    return-object p0
.end method

.method public static b(Lm0/g;)V
    .registers 1

    invoke-interface {p0}, Lm0/g;->L()V

    invoke-interface {p0}, Lm0/g;->L()V

    invoke-interface {p0}, Lm0/g;->M()V

    invoke-interface {p0}, Lm0/g;->L()V

    invoke-interface {p0}, Lm0/g;->L()V

    return-void
.end method

.method public static synthetic c(I)Ljava/lang/String;
    .registers 2

    const/4 v0, 0x1

    if-ne p0, v0, :cond_6

    const-string p0, "NONE"

    return-object p0

    :cond_6
    const/4 v0, 0x2

    if-ne p0, v0, :cond_c

    const-string p0, "ADDING"

    return-object p0

    :cond_c
    const/4 v0, 0x3

    if-ne p0, v0, :cond_12

    const-string p0, "REMOVING"

    return-object p0

    :cond_12
    const-string p0, "null"

    return-object p0
.end method
