.class public La3/q;
.super Ljava/lang/Object;
.source "Person.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La3/q$a;,
        La3/q$b;
    }
.end annotation


# instance fields
.field public a:Ljava/lang/CharSequence;

.field public b:Landroidx/core/graphics/drawable/IconCompat;

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:Z

.field public f:Z


# direct methods
.method public constructor <init>(La3/q$b;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iget-object v0, p1, La3/q$b;->a:Ljava/lang/CharSequence;

    iput-object v0, p0, La3/q;->a:Ljava/lang/CharSequence;

    .line 3
    iget-object v0, p1, La3/q$b;->b:Landroidx/core/graphics/drawable/IconCompat;

    iput-object v0, p0, La3/q;->b:Landroidx/core/graphics/drawable/IconCompat;

    .line 4
    iget-object v0, p1, La3/q$b;->c:Ljava/lang/String;

    iput-object v0, p0, La3/q;->c:Ljava/lang/String;

    .line 5
    iget-object v0, p1, La3/q$b;->d:Ljava/lang/String;

    iput-object v0, p0, La3/q;->d:Ljava/lang/String;

    .line 6
    iget-boolean v0, p1, La3/q$b;->e:Z

    iput-boolean v0, p0, La3/q;->e:Z

    .line 7
    iget-boolean p1, p1, La3/q$b;->f:Z

    iput-boolean p1, p0, La3/q;->f:Z

    return-void
.end method
