.class public La6/m$e;
.super Ljava/lang/Object;
.source "LottieDrawable.java"

# interfaces
.implements La6/m$o;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La6/m;->a(Lf6/e;Ljava/lang/Object;Ls5/i;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lf6/e;

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ls5/i;

.field public final synthetic d:La6/m;


# direct methods
.method public constructor <init>(La6/m;Lf6/e;Ljava/lang/Object;Ls5/i;)V
    .registers 5

    .line 1
    iput-object p1, p0, La6/m$e;->d:La6/m;

    iput-object p2, p0, La6/m$e;->a:Lf6/e;

    iput-object p3, p0, La6/m$e;->b:Ljava/lang/Object;

    iput-object p4, p0, La6/m$e;->c:Ls5/i;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(La6/g;)V
    .registers 5

    .line 1
    iget-object p1, p0, La6/m$e;->d:La6/m;

    iget-object v0, p0, La6/m$e;->a:Lf6/e;

    iget-object v1, p0, La6/m$e;->b:Ljava/lang/Object;

    iget-object v2, p0, La6/m$e;->c:Ls5/i;

    invoke-virtual {p1, v0, v1, v2}, La6/m;->a(Lf6/e;Ljava/lang/Object;Ls5/i;)V

    return-void
.end method
