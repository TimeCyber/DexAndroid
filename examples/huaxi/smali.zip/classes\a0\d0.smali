.class public final La0/d0;
.super Lqg/i;
.source "InfiniteAnimationPolicy.kt"

# interfaces
.implements Lvg/l;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lqg/i;",
        "Lvg/l<",
        "Log/d<",
        "Ljava/lang/Object;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lqg/e;
    c = "androidx.compose.animation.core.InfiniteAnimationPolicyKt$withInfiniteAnimationFrameNanos$2"
    f = "InfiniteAnimationPolicy.kt"
    l = {
        0x1f
    }
    m = "invokeSuspend"
.end annotation


# instance fields
.field public a:I

.field public final synthetic b:Lvg/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lvg/l<",
            "Ljava/lang/Long;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lvg/l;Log/d;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lvg/l<",
            "-",
            "Ljava/lang/Long;",
            "Ljava/lang/Object;",
            ">;",
            "Log/d<",
            "-",
            "La0/d0;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, La0/d0;->b:Lvg/l;

    const/4 p1, 0x1

    invoke-direct {p0, p1, p2}, Lqg/i;-><init>(ILog/d;)V

    return-void
.end method


# virtual methods
.method public final create(Log/d;)Log/d;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Log/d<",
            "*>;)",
            "Log/d<",
            "Lkg/l;",
            ">;"
        }
    .end annotation

    new-instance v0, La0/d0;

    iget-object v1, p0, La0/d0;->b:Lvg/l;

    invoke-direct {v0, v1, p1}, La0/d0;-><init>(Lvg/l;Log/d;)V

    return-object v0
.end method

.method public invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, Log/d;

    .line 1
    new-instance v0, La0/d0;

    iget-object v1, p0, La0/d0;->b:Lvg/l;

    invoke-direct {v0, v1, p1}, La0/d0;-><init>(Lvg/l;Log/d;)V

    .line 2
    sget-object p1, Lkg/l;->a:Lkg/l;

    invoke-virtual {v0, p1}, La0/d0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    sget-object v0, Lpg/a;->a:Lpg/a;

    .line 1
    iget v1, p0, La0/d0;->a:I

    const/4 v2, 0x1

    if-eqz v1, :cond_15

    if-ne v1, v2, :cond_d

    invoke-static {p1}, Lo1/a0;->H(Ljava/lang/Object;)V

    goto :goto_2b

    :cond_d
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_15
    invoke-static {p1}, Lo1/a0;->H(Ljava/lang/Object;)V

    iget-object p1, p0, La0/d0;->b:Lvg/l;

    iput v2, p0, La0/d0;->a:I

    .line 2
    invoke-interface {p0}, Log/d;->getContext()Log/f;

    move-result-object v1

    invoke-static {v1}, La0/j;->p(Log/f;)Lm0/t0;

    move-result-object v1

    invoke-interface {v1, p1, p0}, Lm0/t0;->s(Lvg/l;Log/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_2b

    return-object v0

    :cond_2b
    :goto_2b
    return-object p1
.end method
