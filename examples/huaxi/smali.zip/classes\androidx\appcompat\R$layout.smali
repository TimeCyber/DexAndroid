.class public final Landroidx/appcompat/R$layout;
.super Ljava/lang/Object;


# static fields
.field public static final abc_action_bar_title_item:I = 0x7f0b0011

.field public static final abc_action_bar_up_container:I = 0x7f0b0012

.field public static final abc_action_menu_item_layout:I = 0x7f0b0013

.field public static final abc_action_menu_layout:I = 0x7f0b0014

.field public static final abc_action_mode_bar:I = 0x7f0b0015

.field public static final abc_action_mode_close_item_material:I = 0x7f0b0016

.field public static final abc_activity_chooser_view:I = 0x7f0b0017

.field public static final abc_activity_chooser_view_list_item:I = 0x7f0b0018

.field public static final abc_alert_dialog_button_bar_material:I = 0x7f0b0019

.field public static final abc_alert_dialog_material:I = 0x7f0b001a

.field public static final abc_alert_dialog_title_material:I = 0x7f0b001b

.field public static final abc_cascading_menu_item_layout:I = 0x7f0b001c

.field public static final abc_dialog_title_material:I = 0x7f0b001d

.field public static final abc_expanded_menu_layout:I = 0x7f0b001e

.field public static final abc_list_menu_item_checkbox:I = 0x7f0b001f

.field public static final abc_list_menu_item_icon:I = 0x7f0b0020

.field public static final abc_list_menu_item_layout:I = 0x7f0b0021

.field public static final abc_list_menu_item_radio:I = 0x7f0b0022

.field public static final abc_popup_menu_header_item_layout:I = 0x7f0b0023

.field public static final abc_popup_menu_item_layout:I = 0x7f0b0024

.field public static final abc_screen_content_include:I = 0x7f0b0025

.field public static final abc_screen_simple:I = 0x7f0b0026

.field public static final abc_screen_simple_overlay_action_mode:I = 0x7f0b0027

.field public static final abc_screen_toolbar:I = 0x7f0b0028

.field public static final abc_search_dropdown_item_icons_2line:I = 0x7f0b0029

.field public static final abc_search_view:I = 0x7f0b002a

.field public static final abc_select_dialog_material:I = 0x7f0b002b

.field public static final abc_tooltip:I = 0x7f0b002c

.field public static final select_dialog_item_material:I = 0x7f0b0166

.field public static final select_dialog_multichoice_material:I = 0x7f0b0167

.field public static final select_dialog_singlechoice_material:I = 0x7f0b0168

.field public static final support_simple_spinner_dropdown_item:I = 0x7f0b016c


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
