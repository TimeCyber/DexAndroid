.class public La5/d;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lu4/h;

.field public final synthetic b:I

.field public final synthetic c:Ljava/util/Map;


# direct methods
.method public constructor <init>(La5/c;Lu4/h;ILjava/util/Map;)V
    .registers 5

    .line 1
    iput-object p2, p0, La5/d;->a:Lu4/h;

    iput p3, p0, La5/d;->b:I

    iput-object p4, p0, La5/d;->c:Ljava/util/Map;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    .line 1
    :try_start_0
    iget-object v0, p0, La5/d;->a:Lu4/h;

    iget v1, p0, La5/d;->b:I

    new-instance v2, Lu4/f;

    iget-object v3, p0, La5/d;->c:Ljava/util/Map;

    invoke-direct {v2, v1, v3}, Lu4/f;-><init>(ILjava/util/Map;)V

    invoke-interface {v0, v1, v2}, Lu4/h;->e(ILu4/f;)Z
    :try_end_e
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_e} :catch_e

    :catch_e
    return-void
.end method
