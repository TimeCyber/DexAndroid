.class public Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$a;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->initListeners()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$a;->a:Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$a;->a:Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;

    # getter for: Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mOnStreetDivisionSelectedListener:Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$OnStreetDivisionSelectedListener;
    invoke-static {p1}, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->access$000(Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;)Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$OnStreetDivisionSelectedListener;

    move-result-object p1

    if-eqz p1, :cond_3e

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$a;->a:Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;

    # getter for: Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mSelectedStreet:Lcn/damai/commonbusiness/address/bean/DivisionBean;
    invoke-static {p1}, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->access$100(Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;)Lcn/damai/commonbusiness/address/bean/DivisionBean;

    move-result-object p1

    if-eqz p1, :cond_3e

    iget-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$a;->a:Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;

    # getter for: Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->isScrolling:Z
    invoke-static {p1}, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->access$200(Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;)Z

    move-result p1

    if-nez p1, :cond_3e

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$a;->a:Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;

    # getter for: Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mOnStreetDivisionSelectedListener:Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$OnStreetDivisionSelectedListener;
    invoke-static {p1}, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->access$000(Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;)Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$OnStreetDivisionSelectedListener;

    move-result-object p1

    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$a;->a:Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;

    # getter for: Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mSelectedStreet:Lcn/damai/commonbusiness/address/bean/DivisionBean;
    invoke-static {v0}, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->access$100(Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;)Lcn/damai/commonbusiness/address/bean/DivisionBean;

    move-result-object v0

    invoke-interface {p1, v0}, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$OnStreetDivisionSelectedListener;->onStreetDivisionSelected(Lcn/damai/commonbusiness/address/bean/DivisionBean;)V

    :cond_3e
    return-void
.end method
