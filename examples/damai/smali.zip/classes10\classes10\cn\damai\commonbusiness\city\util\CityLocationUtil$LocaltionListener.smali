.class public interface abstract Lcn/damai/commonbusiness/city/util/CityLocationUtil$LocaltionListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/city/util/CityLocationUtil;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "LocaltionListener"
.end annotation


# virtual methods
.method public abstract onGetLocalFinsih()V
.end method

.method public abstract onGetLocalSuccess(Lcn/damai/commonbusiness/city/model/SitesBean;)V
.end method
