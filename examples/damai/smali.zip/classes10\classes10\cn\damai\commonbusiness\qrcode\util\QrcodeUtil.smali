.class public Lcn/damai/commonbusiness/qrcode/util/QrcodeUtil;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/qrcode/util/QrcodeUtil$OnQRcodeCreateListener;
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon; = null

.field public static final REQUEST_CODE_SCAN_GALLERY:I = 0x3e8


# direct methods
.method public static a(ILjava/lang/String;)Landroid/graphics/Bitmap;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/qrcode/util/QrcodeUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    aput-object p0, v2, v3

    const/4 p0, 0x1

    aput-object p1, v2, p0

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/graphics/Bitmap;

    return-object p0

    .line 1
    :cond_1e
    invoke-static {p1, p0}, Lcn/damai/commonbusiness/qrcode/util/QrcodeUtil;->f(Ljava/lang/String;I)Landroid/graphics/Bitmap;

    move-result-object p0

    return-object p0
.end method

.method public static b(ILjava/lang/String;Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/qrcode/util/QrcodeUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_21

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    aput-object p0, v2, v3

    const/4 p0, 0x1

    aput-object p1, v2, p0

    const/4 p0, 0x2

    aput-object p2, v2, p0

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/graphics/Bitmap;

    return-object p0

    .line 1
    :cond_21
    invoke-static {p1, p0}, Lcn/damai/commonbusiness/qrcode/util/QrcodeUtil;->f(Ljava/lang/String;I)Landroid/graphics/Bitmap;

    move-result-object p0

    return-object p0
.end method

.method public static c(ILjava/lang/String;Lcn/damai/commonbusiness/qrcode/util/QrcodeUtil$OnQRcodeCreateListener;)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/qrcode/util/QrcodeUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    aput-object p0, v2, v3

    const/4 p0, 0x1

    aput-object p1, v2, p0

    const/4 p0, 0x2

    aput-object p2, v2, p0

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1e
    invoke-static {p1, p0}, Lcn/damai/commonbusiness/qrcode/util/QrcodeUtil;->f(Ljava/lang/String;I)Landroid/graphics/Bitmap;

    move-result-object p0

    if-eqz p0, :cond_2a

    if-eqz p2, :cond_2f

    .line 2
    invoke-interface {p2, p0}, Lcn/damai/commonbusiness/qrcode/util/QrcodeUtil$OnQRcodeCreateListener;->onSuccess(Landroid/graphics/Bitmap;)V

    goto :goto_2f

    :cond_2a
    if-eqz p2, :cond_2f

    .line 3
    invoke-interface {p2}, Lcn/damai/commonbusiness/qrcode/util/QrcodeUtil$OnQRcodeCreateListener;->onFailure()V

    :cond_2f
    :goto_2f
    return-void
.end method

.method public static d(Ljava/lang/String;III)Landroid/graphics/Bitmap;
    .registers 16
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/zxing/WriterException;
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/qrcode/util/QrcodeUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_2c

    const/4 v2, 0x4

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 p1, 0x1

    aput-object p0, v2, p1

    const/4 p0, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, p0

    const/4 p0, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, p0

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/graphics/Bitmap;

    return-object p0

    :cond_2c
    const/4 v0, 0x0

    .line 1
    :try_start_2d
    new-instance v1, Ltb/o20;

    invoke-direct {v1}, Ltb/o20;-><init>()V

    .line 2
    sget-object v2, Ltb/ph;->CODE_128:Ltb/ph;

    invoke-virtual {v1, p0, v2, p1, p2}, Ltb/rg6;->encode(Ljava/lang/String;Ltb/ph;II)Ltb/pn;

    move-result-object v0
    :try_end_38
    .catch Lcom/google/zxing/WriterException; {:try_start_2d .. :try_end_38} :catch_39

    goto :goto_3d

    :catch_39
    move-exception p0

    .line 3
    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    .line 4
    :goto_3d
    invoke-virtual {v0}, Ltb/pn;->c()I

    move-result v10

    .line 5
    invoke-virtual {v0}, Ltb/pn;->b()I

    move-result v11

    mul-int p0, v10, v11

    .line 6
    new-array v5, p0, [I

    const/4 p0, 0x0

    :goto_4a
    if-ge p0, v11, :cond_64

    mul-int p1, p0, v10

    const/4 p2, 0x0

    :goto_4f
    if-ge p2, v10, :cond_61

    add-int v1, p1, p2

    .line 7
    invoke-virtual {v0, p2, p0}, Ltb/pn;->a(II)Z

    move-result v2

    if-eqz v2, :cond_5b

    move v2, p3

    goto :goto_5c

    :cond_5b
    const/4 v2, -0x1

    :goto_5c
    aput v2, v5, v1

    add-int/lit8 p2, p2, 0x1

    goto :goto_4f

    :cond_61
    add-int/lit8 p0, p0, 0x1

    goto :goto_4a

    .line 8
    :cond_64
    sget-object p0, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v10, v11, p0}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object p0

    const/4 v6, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object v4, p0

    move v7, v10

    .line 9
    invoke-virtual/range {v4 .. v11}, Landroid/graphics/Bitmap;->setPixels([IIIIIII)V

    return-object p0
.end method

.method private static e(Ljava/lang/String;Ltb/ph;IILjava/util/Hashtable;)Ltb/pn;
    .registers 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/zxing/WriterException;
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/qrcode/util/QrcodeUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "15"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_2b

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 p0, 0x1

    aput-object p1, v2, p0

    const/4 p0, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, p0

    const/4 p0, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, p0

    const/4 p0, 0x4

    aput-object p4, v2, p0

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ltb/pn;

    return-object p0

    :cond_2b
    if-eqz p0, :cond_8d

    .line 1
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    if-eqz v0, :cond_8d

    .line 2
    sget-object v0, Ltb/ph;->QR_CODE:Ltb/ph;

    if-ne p1, v0, :cond_76

    if-ltz p2, :cond_57

    if-ltz p3, :cond_57

    .line 3
    sget-object p1, Ltb/qf1;->L:Ltb/qf1;

    if-eqz p4, :cond_4a

    .line 4
    sget-object v0, Ltb/af1;->ERROR_CORRECTION:Ltb/af1;

    invoke-virtual {p4, v0}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltb/qf1;

    if-eqz v0, :cond_4a

    move-object p1, v0

    .line 5
    :cond_4a
    new-instance v0, Ltb/ir4;

    invoke-direct {v0}, Ltb/ir4;-><init>()V

    .line 6
    invoke-static {p0, p1, p4, v0}, Ltb/ef1;->l(Ljava/lang/String;Ltb/qf1;Ljava/util/Hashtable;Ltb/ir4;)V

    .line 7
    invoke-static {v0, p2, p3}, Lcn/damai/commonbusiness/qrcode/util/QrcodeUtil;->i(Ltb/ir4;II)Ltb/pn;

    move-result-object p0

    return-object p0

    .line 8
    :cond_57
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p4, "Requested dimensions are too small: "

    invoke-virtual {p1, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 p2, 0x78

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 9
    :cond_76
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string p3, "Can only encode QR_CODE, but got "

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 10
    :cond_8d
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Found empty contents"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private static f(Ljava/lang/String;I)Landroid/graphics/Bitmap;
    .registers 14

    sget-object v0, Lcn/damai/commonbusiness/qrcode/util/QrcodeUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "14"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 p1, 0x1

    aput-object p0, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/graphics/Bitmap;

    return-object p0

    .line 1
    :cond_1e
    :try_start_1e
    new-instance v0, Ljava/util/Hashtable;

    invoke-direct {v0}, Ljava/util/Hashtable;-><init>()V

    .line 2
    sget-object v1, Ltb/af1;->CHARACTER_SET:Ltb/af1;

    const-string v2, "utf-8"

    invoke-virtual {v0, v1, v2}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 3
    sget-object v1, Ltb/ph;->QR_CODE:Ltb/ph;

    invoke-static {p0, v1, p1, p1, v0}, Lcn/damai/commonbusiness/qrcode/util/QrcodeUtil;->e(Ljava/lang/String;Ltb/ph;IILjava/util/Hashtable;)Ltb/pn;

    move-result-object p0

    .line 4
    invoke-virtual {p0}, Ltb/pn;->c()I

    move-result v10

    .line 5
    invoke-virtual {p0}, Ltb/pn;->b()I

    move-result v11

    mul-int p1, v10, v11

    .line 6
    new-array v5, p1, [I

    const/4 p1, 0x0

    :goto_3d
    if-ge p1, v11, :cond_5c

    const/4 v0, 0x0

    :goto_40
    if-ge v0, v10, :cond_59

    .line 7
    invoke-virtual {p0, v0, p1}, Ltb/pn;->a(II)Z

    move-result v1

    if-eqz v1, :cond_50

    mul-int v1, p1, v10

    add-int/2addr v1, v0

    const/high16 v2, -0x1000000

    .line 8
    aput v2, v5, v1

    goto :goto_56

    :cond_50
    mul-int v1, p1, v10

    add-int/2addr v1, v0

    const/4 v2, -0x1

    .line 9
    aput v2, v5, v1

    :goto_56
    add-int/lit8 v0, v0, 0x1

    goto :goto_40

    :cond_59
    add-int/lit8 p1, p1, 0x1

    goto :goto_3d

    .line 10
    :cond_5c
    sget-object p0, Landroid/graphics/Bitmap$Config;->ARGB_4444:Landroid/graphics/Bitmap$Config;

    invoke-static {v10, v11, p0}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object p0

    const/4 v6, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object v4, p0

    move v7, v10

    .line 11
    invoke-virtual/range {v4 .. v11}, Landroid/graphics/Bitmap;->setPixels([IIIIIII)V
    :try_end_6a
    .catch Ljava/lang/Exception; {:try_start_1e .. :try_end_6a} :catch_6b

    return-object p0

    :catch_6b
    move-exception p0

    .line 12
    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static g(Landroid/app/Activity;Landroid/net/Uri;)Ljava/lang/String;
    .registers 9

    const-string v0, "_data"

    sget-object v1, Lcn/damai/commonbusiness/qrcode/util/QrcodeUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v2, "7"

    invoke-static {v1, v2}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_1c

    const/4 v0, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v0, v3

    const/4 p0, 0x1

    aput-object p1, v0, p0

    invoke-interface {v1, v2, v0}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0

    .line 1
    :cond_1c
    :try_start_1c
    invoke-virtual {p0}, Landroid/app/Activity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v2, p1

    invoke-virtual/range {v1 .. v6}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p0

    if-nez p0, :cond_33

    .line 2
    invoke-virtual {p1}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object p0

    goto :goto_42

    .line 3
    :cond_33
    invoke-interface {p0}, Landroid/database/Cursor;->moveToFirst()Z

    .line 4
    invoke-interface {p0, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result p1

    .line 5
    invoke-interface {p0, p1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object p1

    .line 6
    invoke-interface {p0}, Landroid/database/Cursor;->close()V
    :try_end_41
    .catch Ljava/lang/Exception; {:try_start_1c .. :try_end_41} :catch_43

    move-object p0, p1

    :goto_42
    return-object p0

    :catch_43
    move-exception p0

    .line 7
    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static h(Landroid/app/Activity;)V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/qrcode/util/QrcodeUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    sget-object v0, Ltb/b74;->STORAGE:[Ljava/lang/String;

    new-instance v1, Lcn/damai/commonbusiness/qrcode/util/QrcodeUtil$a;

    invoke-direct {v1, p0}, Lcn/damai/commonbusiness/qrcode/util/QrcodeUtil$a;-><init>(Landroid/app/Activity;)V

    const-string v2, "\u7528\u4e8e\u9009\u53d6\u56fe\u7247\u8fdb\u884c\u4e8c\u7ef4\u7801\u8bc6\u522b"

    invoke-static {p0, v3, v0, v2, v1}, Ltb/w64;->a(Landroid/app/Activity;Z[Ljava/lang/String;Ljava/lang/String;Lcn/damai/common/askpermission/OnGrantListener;)V

    return-void
.end method

.method private static i(Ltb/ir4;II)Ltb/pn;
    .registers 13

    sget-object v0, Lcn/damai/commonbusiness/qrcode/util/QrcodeUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "16"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v2, :cond_25

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    aput-object p0, v2, v5

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    aput-object p0, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ltb/pn;

    return-object p0

    .line 1
    :cond_25
    invoke-virtual {p0}, Ltb/ir4;->c()Ltb/or;

    move-result-object p0

    .line 2
    invoke-virtual {p0}, Ltb/or;->e()I

    move-result v0

    .line 3
    invoke-virtual {p0}, Ltb/or;->d()I

    move-result v1

    .line 4
    invoke-static {p1, v0}, Ljava/lang/Math;->max(II)I

    move-result p1

    .line 5
    invoke-static {p2, v1}, Ljava/lang/Math;->max(II)I

    move-result p2

    .line 6
    div-int v2, p1, v0

    div-int v6, p2, v1

    invoke-static {v2, v6}, Ljava/lang/Math;->min(II)I

    move-result v2

    mul-int v6, v0, v2

    sub-int v6, p1, v6

    .line 7
    div-int/2addr v6, v4

    mul-int v7, v1, v2

    sub-int v7, p2, v7

    .line 8
    div-int/2addr v7, v4

    .line 9
    new-instance v4, Ltb/pn;

    invoke-direct {v4, p1, p2}, Ltb/pn;-><init>(II)V

    const/4 p1, 0x0

    :goto_51
    if-ge p1, v1, :cond_68

    move v8, v6

    const/4 p2, 0x0

    :goto_55
    if-ge p2, v0, :cond_64

    .line 10
    invoke-virtual {p0, p2, p1}, Ltb/or;->b(II)B

    move-result v9

    if-ne v9, v5, :cond_60

    .line 11
    invoke-virtual {v4, v8, v7, v2, v2}, Ltb/pn;->d(IIII)V

    :cond_60
    add-int/lit8 p2, p2, 0x1

    add-int/2addr v8, v2

    goto :goto_55

    :cond_64
    add-int/lit8 p1, p1, 0x1

    add-int/2addr v7, v2

    goto :goto_51

    :cond_68
    return-object v4
.end method
