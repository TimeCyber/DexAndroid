.class public Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$1;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel;->loadImageForSDCard(Landroid/content/Context;Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$DataCallback;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic val$callback:Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$DataCallback;

.field final synthetic val$context:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$DataCallback;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$1;->val$context:Landroid/content/Context;

    iput-object p2, p0, Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$1;->val$callback:Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$DataCallback;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 14

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$1;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    sget-object v5, Landroid/provider/MediaStore$Images$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$1;->val$context:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v4

    const-string v0, "_id"

    const-string v1, "_data"

    const-string v2, "_display_name"

    const-string v3, "date_added"

    .line 3
    filled-new-array {v0, v1, v2, v3, v0}, [Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x0

    const/4 v8, 0x0

    const-string v9, "date_added"

    invoke-virtual/range {v4 .. v9}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v4

    .line 4
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    if-eqz v4, :cond_7d

    .line 5
    :cond_37
    :goto_37
    invoke-interface {v4}, Landroid/database/Cursor;->moveToNext()Z

    move-result v6

    if-eqz v6, :cond_7a

    .line 6
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v6

    invoke-interface {v4, v6}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v6

    .line 7
    sget-object v8, Landroid/provider/MediaStore$Video$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    invoke-static {v8, v6, v7}, Landroid/content/ContentUris;->withAppendedId(Landroid/net/Uri;J)Landroid/net/Uri;

    move-result-object v6

    .line 8
    invoke-interface {v4, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v7

    .line 9
    invoke-interface {v4, v7}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v7

    .line 10
    invoke-interface {v4, v2}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v8

    .line 11
    invoke-interface {v4, v8}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v8

    .line 12
    invoke-interface {v4, v3}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v9

    .line 13
    invoke-interface {v4, v9}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v9

    .line 14
    invoke-static {v7}, Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel;->getExtensionName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const-string v12, ".downloading"

    invoke-virtual {v12, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_37

    .line 15
    new-instance v11, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;

    invoke-direct {v11, v7, v9, v10, v8}, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;-><init>(Ljava/lang/String;JLjava/lang/String;)V

    .line 16
    iput-object v6, v11, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;->uri:Landroid/net/Uri;

    .line 17
    invoke-virtual {v5, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_37

    .line 18
    :cond_7a
    invoke-interface {v4}, Landroid/database/Cursor;->close()V

    .line 19
    :cond_7d
    invoke-static {v5}, Ljava/util/Collections;->reverse(Ljava/util/List;)V

    .line 20
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$1;->val$callback:Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$DataCallback;

    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$1;->val$context:Landroid/content/Context;

    # invokes: Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel;->splitFolder(Landroid/content/Context;Ljava/util/ArrayList;)Ljava/util/ArrayList;
    invoke-static {v1, v5}, Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel;->access$000(Landroid/content/Context;Ljava/util/ArrayList;)Ljava/util/ArrayList;

    move-result-object v1

    invoke-interface {v0, v1}, Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$DataCallback;->onSuccess(Ljava/util/ArrayList;)V

    return-void
.end method
