.class public Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "AnimatedZoomRunnable"
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private final mFocalX:F

.field private final mFocalY:F

.field private final mStartTime:J

.field private final mZoomEnd:F

.field private final mZoomStart:F

.field final synthetic this$0:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;


# direct methods
.method public constructor <init>(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;FFFF)V
    .registers 6

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;->this$0:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput p4, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;->mFocalX:F

    .line 3
    iput p5, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;->mFocalY:F

    .line 4
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide p4

    iput-wide p4, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;->mStartTime:J

    .line 5
    iput p2, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;->mZoomStart:F

    .line 6
    iput p3, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;->mZoomEnd:F

    return-void
.end method

.method private interpolate()F
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Float;

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v0

    return v0

    .line 1
    :cond_1b
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iget-wide v2, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;->mStartTime:J

    sub-long/2addr v0, v2

    long-to-float v0, v0

    const/high16 v1, 0x3f800000    # 1.0f

    mul-float v0, v0, v1

    iget-object v2, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;->this$0:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-static {v2}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->q(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v0, v2

    .line 2
    invoke-static {v1, v0}, Ljava/lang/Math;->min(FF)F

    move-result v0

    .line 3
    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;->this$0:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-static {v1}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->r(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Landroid/view/animation/Interpolator;

    move-result-object v1

    invoke-interface {v1, v0}, Landroid/view/animation/Interpolator;->getInterpolation(F)F

    move-result v0

    return v0
.end method


# virtual methods
.method public run()V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    invoke-direct {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;->interpolate()F

    move-result v0

    .line 2
    iget v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;->mZoomStart:F

    iget v2, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;->mZoomEnd:F

    sub-float/2addr v2, v1

    mul-float v2, v2, v0

    add-float/2addr v1, v2

    .line 3
    iget-object v2, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;->this$0:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-virtual {v2}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->N()F

    move-result v2

    div-float/2addr v1, v2

    .line 4
    iget-object v2, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;->this$0:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-static {v2}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->p(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Lcn/damai/commonbusiness/photoselect/photoview/OnGestureListener;

    move-result-object v2

    iget v3, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;->mFocalX:F

    iget v4, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;->mFocalY:F

    invoke-interface {v2, v1, v3, v4}, Lcn/damai/commonbusiness/photoselect/photoview/OnGestureListener;->onScale(FFF)V

    const/high16 v1, 0x3f800000    # 1.0f

    cmpg-float v0, v0, v1

    if-gez v0, :cond_43

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;->this$0:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->t(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Landroid/widget/ImageView;

    move-result-object v0

    invoke-static {v0, p0}, Ltb/l80;->a(Landroid/view/View;Ljava/lang/Runnable;)V

    :cond_43
    return-void
.end method
