.class public Lcn/damai/commonbusiness/model/SpecialProjectList;
.super Ljava/lang/Object;
.source "Taobao"


# instance fields
.field public Data:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/model/HotProject;",
            ">;"
        }
    .end annotation
.end field

.field public PicUrl:Ljava/lang/String;

.field public Text:Ljava/lang/String;

.field public Title:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
