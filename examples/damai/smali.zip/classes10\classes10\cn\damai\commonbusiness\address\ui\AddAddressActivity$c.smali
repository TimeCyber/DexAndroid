.class public Lcn/damai/commonbusiness/address/ui/AddAddressActivity$c;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/address/ui/AddAddressActivity;->initListeners()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/address/ui/AddAddressActivity;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/address/ui/AddAddressActivity;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/address/ui/AddAddressActivity$c;->a:Lcn/damai/commonbusiness/address/ui/AddAddressActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/ui/AddAddressActivity$c;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object p1, p0, Lcn/damai/commonbusiness/address/ui/AddAddressActivity$c;->a:Lcn/damai/commonbusiness/address/ui/AddAddressActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/address/ui/AddAddressActivity;->access$1000(Lcn/damai/commonbusiness/address/ui/AddAddressActivity;)Lcn/damai/commonbusiness/address/bean/DivisionBean;

    move-result-object p1

    if-nez p1, :cond_2b

    .line 2
    invoke-static {}, Lcn/damai/common/util/ToastUtil;->a()Lcn/damai/common/util/ToastUtil;

    move-result-object p1

    iget-object v0, p0, Lcn/damai/commonbusiness/address/ui/AddAddressActivity$c;->a:Lcn/damai/commonbusiness/address/ui/AddAddressActivity;

    const-string v1, "\u8bf7\u9009\u62e9\u533a\u57df"

    invoke-virtual {p1, v0, v1}, Lcn/damai/common/util/ToastUtil;->j(Landroid/content/Context;Ljava/lang/String;)V

    return-void

    .line 3
    :cond_2b
    iget-object p1, p0, Lcn/damai/commonbusiness/address/ui/AddAddressActivity$c;->a:Lcn/damai/commonbusiness/address/ui/AddAddressActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/address/ui/AddAddressActivity;->access$1100(Lcn/damai/commonbusiness/address/ui/AddAddressActivity;)Lcn/damai/commonbusiness/address/bean/DivisionBean;

    move-result-object p1

    if-eqz p1, :cond_38

    .line 4
    iget-object p1, p0, Lcn/damai/commonbusiness/address/ui/AddAddressActivity$c;->a:Lcn/damai/commonbusiness/address/ui/AddAddressActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/address/ui/AddAddressActivity;->access$1200(Lcn/damai/commonbusiness/address/ui/AddAddressActivity;)V

    :cond_38
    return-void
.end method
