.class public Lcn/damai/commonbusiness/dynamicx/DynamicXInit;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/dynamicx/DynamicXInit$ImgStateRecord;
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# direct methods
.method static synthetic a(Ljava/lang/String;)[I
    .registers 1

    .line 1
    invoke-static {p0}, Lcn/damai/commonbusiness/dynamicx/DynamicXInit;->f(Ljava/lang/String;)[I

    move-result-object p0

    return-object p0
.end method

.method static synthetic b(Ljava/lang/String;)Ljava/lang/String;
    .registers 1

    .line 1
    invoke-static {p0}, Lcn/damai/commonbusiness/dynamicx/DynamicXInit;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static c()Lcom/taobao/android/dinamicx/monitor/IDXAppMonitor;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/DynamicXInit;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "8"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/taobao/android/dinamicx/monitor/IDXAppMonitor;

    return-object v0

    .line 1
    :cond_14
    new-instance v0, Ltb/gi0;

    invoke-direct {v0}, Ltb/gi0;-><init>()V

    return-object v0
.end method

.method public static d()Lcom/taobao/android/dinamicx/model/DXLongSparseArray;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/taobao/android/dinamicx/model/DXLongSparseArray<",
            "Lcom/taobao/android/dinamicx/IDXEventHandler;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/DynamicXInit;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "7"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/taobao/android/dinamicx/model/DXLongSparseArray;

    return-object v0

    .line 1
    :cond_14
    new-instance v0, Lcom/taobao/android/dinamicx/model/DXLongSparseArray;

    invoke-direct {v0}, Lcom/taobao/android/dinamicx/model/DXLongSparseArray;-><init>()V

    const-wide v1, -0x58255b959ed5d230L

    .line 2
    new-instance v3, Ltb/up0;

    invoke-direct {v3}, Ltb/up0;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    return-object v0
.end method

.method private static e()Lcom/taobao/android/dinamicx/widget/IDXWebImageInterface;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/DynamicXInit;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/taobao/android/dinamicx/widget/IDXWebImageInterface;

    return-object v0

    .line 1
    :cond_14
    new-instance v0, Lcn/damai/commonbusiness/dynamicx/DynamicXInit$a;

    invoke-direct {v0}, Lcn/damai/commonbusiness/dynamicx/DynamicXInit$a;-><init>()V

    return-object v0
.end method

.method private static f(Ljava/lang/String;)[I
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/DynamicXInit;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_17

    new-array v2, v4, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, [I

    return-object p0

    :cond_17
    const-string v0, "?optParams="

    .line 1
    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    const-string v1, ""

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "x"

    .line 2
    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v2, 0x2

    const/4 v5, -0x1

    if-eqz v1, :cond_66

    .line 3
    invoke-virtual {p0, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    .line 4
    invoke-static {p0}, Ltb/kh0;->a([Ljava/lang/Object;)I

    move-result v0

    if-ne v0, v2, :cond_66

    aget-object v0, p0, v3

    .line 5
    invoke-static {v0}, Ltb/mw5;->j(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_66

    aget-object v0, p0, v4

    .line 6
    invoke-static {v0}, Ltb/mw5;->j(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_66

    .line 7
    :try_start_4b
    aget-object v0, p0, v3

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0
    :try_end_51
    .catch Ljava/lang/Exception; {:try_start_4b .. :try_end_51} :catch_5c

    .line 8
    :try_start_51
    aget-object p0, p0, v4

    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5
    :try_end_57
    .catch Ljava/lang/Exception; {:try_start_51 .. :try_end_57} :catch_5a

    move p0, v5

    move v5, v0

    goto :goto_67

    :catch_5a
    move-exception p0

    goto :goto_5e

    :catch_5c
    move-exception p0

    const/4 v0, -0x1

    .line 9
    :goto_5e
    invoke-virtual {p0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ltb/av2;->a(Ljava/lang/String;)V

    move v5, v0

    :cond_66
    const/4 p0, -0x1

    :goto_67
    new-array v0, v2, [I

    aput v5, v0, v3

    aput p0, v0, v4

    return-object v0
.end method

.method private static g(Ljava/lang/String;)Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/DynamicXInit;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0

    :cond_17
    const-string v0, "?optParams="

    .line 1
    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v3, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static h()Lcom/taobao/android/dinamicx/model/DXLongSparseArray;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/taobao/android/dinamicx/model/DXLongSparseArray<",
            "Lcom/taobao/android/dinamicx/expression/parser/IDXDataParser;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/DynamicXInit;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/taobao/android/dinamicx/model/DXLongSparseArray;

    return-object v0

    .line 1
    :cond_14
    new-instance v0, Lcom/taobao/android/dinamicx/model/DXLongSparseArray;

    invoke-direct {v0}, Lcom/taobao/android/dinamicx/model/DXLongSparseArray;-><init>()V

    const-wide v1, 0x2d0f8e5277ac9ee4L    # 1.2102428717375808E-91

    .line 2
    new-instance v3, Ltb/gr0;

    invoke-direct {v3}, Ltb/gr0;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, -0x66dbc378ab610123L    # -1.453405580150063E-187

    .line 3
    new-instance v3, Ltb/br0;

    invoke-direct {v3}, Ltb/br0;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, -0x6be529bdb58905a3L    # -7.971796475657547E-212

    .line 4
    new-instance v3, Ltb/hr0;

    invoke-direct {v3}, Ltb/hr0;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, 0x2c5c7db452d0ad73L    # 5.3354317772654485E-95

    .line 5
    new-instance v3, Ltb/kt0;

    invoke-direct {v3}, Ltb/kt0;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, -0x152bda2d5196ded8L    # -4.042811661704291E206

    .line 6
    new-instance v3, Ltb/wq0;

    invoke-direct {v3}, Ltb/wq0;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, 0x17dc626bd06ad0L

    .line 7
    new-instance v3, Ltb/yq0;

    invoke-direct {v3}, Ltb/yq0;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, -0x66dbaebe36359816L

    .line 8
    new-instance v3, Ltb/fr0;

    invoke-direct {v3}, Ltb/fr0;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, 0x4feaec6121febb17L    # 9.742224285082232E76

    .line 9
    new-instance v3, Ltb/zq0;

    invoke-direct {v3}, Ltb/zq0;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, 0x791049217af742f7L    # 1.409618554890184E275

    .line 10
    new-instance v3, Ltb/cr0;

    invoke-direct {v3}, Ltb/cr0;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, -0x1d0854c14cc6fb8fL    # -5.582852211732318E168

    .line 11
    new-instance v3, Ltb/ar0;

    invoke-direct {v3}, Ltb/ar0;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, 0x31974930e1efaf90L    # 8.434786273170788E-70

    .line 12
    new-instance v3, Ltb/xq0;

    invoke-direct {v3}, Ltb/xq0;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, -0x330cb2efd167303cL    # -4.962489033040373E62

    .line 13
    new-instance v3, Ltb/dr0;

    invoke-direct {v3}, Ltb/dr0;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, -0x4fc287be7eb797f3L    # -2.5450572419285352E-76

    .line 14
    new-instance v3, Ltb/ws0;

    invoke-direct {v3}, Ltb/ws0;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, -0x5e0ff6a75ff5b4cfL

    .line 15
    new-instance v3, Ltb/er0;

    invoke-direct {v3}, Ltb/er0;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    return-object v0
.end method

.method public static i()Lcom/taobao/android/dinamicx/log/IDXRemoteDebugLog;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/DynamicXInit;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "9"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/taobao/android/dinamicx/log/IDXRemoteDebugLog;

    return-object v0

    .line 1
    :cond_14
    new-instance v0, Ltb/hi0;

    invoke-direct {v0}, Ltb/hi0;-><init>()V

    return-object v0
.end method

.method private static j()Lcom/taobao/android/dinamicx/model/DXLongSparseArray;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/taobao/android/dinamicx/model/DXLongSparseArray<",
            "Lcom/taobao/android/dinamicx/widget/IDXBuilderWidgetNode;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/DynamicXInit;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/taobao/android/dinamicx/model/DXLongSparseArray;

    return-object v0

    .line 1
    :cond_14
    new-instance v0, Lcom/taobao/android/dinamicx/model/DXLongSparseArray;

    invoke-direct {v0}, Lcom/taobao/android/dinamicx/model/DXLongSparseArray;-><init>()V

    const-wide v1, -0x6778ba3a74b415f9L

    .line 2
    new-instance v3, Ltb/yp0$a;

    invoke-direct {v3}, Ltb/yp0$a;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, -0x23693d4d07945525L    # -1.058767635737375E138

    .line 3
    new-instance v3, Ltb/jq0$a;

    invoke-direct {v3}, Ltb/jq0$a;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, -0x1a4bd2f316c10aa4L    # -8.37205358990154E181

    .line 4
    new-instance v3, Ltb/aq0$a;

    invoke-direct {v3}, Ltb/aq0$a;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, -0x2fec226283c6eef5L    # -5.750722718475346E77

    .line 5
    new-instance v3, Ltb/vp0$a;

    invoke-direct {v3}, Ltb/vp0$a;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, 0x5e05e9f2ce80fc8cL    # 8.551195548473939E144

    .line 6
    new-instance v3, Lcn/damai/commonbusiness/dynamicx/customwidget/scrollerlayout/DXDMScrollLayoutWidgetNode$a;

    invoke-direct {v3}, Lcn/damai/commonbusiness/dynamicx/customwidget/scrollerlayout/DXDMScrollLayoutWidgetNode$a;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, 0x660d3164652b645aL    # 3.876369644559222E183

    .line 7
    new-instance v3, Ltb/cq0$a;

    invoke-direct {v3}, Ltb/cq0$a;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, 0x5ea755ec8c7c6a6L

    .line 8
    new-instance v3, Ltb/zp0$a;

    invoke-direct {v3}, Ltb/zp0$a;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, 0x1c7fc10767adb52fL    # 2.054192710778379E-171

    .line 9
    new-instance v3, Ltb/hq0$a;

    invoke-direct {v3}, Ltb/hq0$a;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, 0x54f6bc8cef3c031aL    # 1.9892192742777547E101

    .line 10
    new-instance v3, Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$b;

    invoke-direct {v3}, Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$b;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, -0x2888745d06dfba4aL    # -2.2649858017826745E113

    .line 11
    new-instance v3, Ltb/xp0$a;

    invoke-direct {v3}, Ltb/xp0$a;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, 0x75bca110fc1536fL

    .line 12
    new-instance v3, Ltb/gq0$a;

    invoke-direct {v3}, Ltb/gq0$a;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, -0x46df8243addb5650L    # -1.5880404421940506E-33

    .line 13
    new-instance v3, Ltb/bq0;

    invoke-direct {v3}, Ltb/bq0;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, 0x34193e93fe4bf3c8L    # 1.005418056112678E-57

    .line 14
    new-instance v3, Ltb/fq0;

    invoke-direct {v3}, Ltb/fq0;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, 0x7a2edf5c4406edb9L    # 3.5024972462477584E280

    .line 15
    new-instance v3, Ltb/eq0;

    invoke-direct {v3}, Ltb/eq0;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, 0x6dbc115e0bf1e80dL    # 3.9631987794265855E220

    .line 16
    new-instance v3, Ltb/wp0;

    invoke-direct {v3}, Ltb/wp0;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, -0x115e4d01da7865b1L    # -8.189175552954471E224

    .line 17
    new-instance v3, Ltb/dq0;

    invoke-direct {v3}, Ltb/dq0;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, -0x5d48801b2c42573dL

    .line 18
    new-instance v3, Ltb/vt0;

    invoke-direct {v3}, Ltb/vt0;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, -0x5e2fc5684b2003f5L    # -8.122890253130448E-146

    .line 19
    new-instance v3, Ltb/kq0;

    invoke-direct {v3}, Ltb/kq0;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    const-wide v1, -0x42c07846ac85bac7L    # -1.1201767194403933E-13

    .line 20
    new-instance v3, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DXDMPicConvertViewWidgetNode;

    invoke-direct {v3}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DXDMPicConvertViewWidgetNode;-><init>()V

    invoke-virtual {v0, v1, v2, v3}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    return-object v0
.end method

.method public static k()V
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/DynamicXInit;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_11

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_11
    new-instance v0, Lcom/taobao/android/dinamicx/e$b;

    invoke-direct {v0}, Lcom/taobao/android/dinamicx/e$b;-><init>()V

    .line 2
    invoke-static {}, Lcn/damai/commonbusiness/dynamicx/DynamicXInit;->e()Lcom/taobao/android/dinamicx/widget/IDXWebImageInterface;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/taobao/android/dinamicx/e$b;->B(Lcom/taobao/android/dinamicx/widget/IDXWebImageInterface;)Lcom/taobao/android/dinamicx/e$b;

    .line 3
    invoke-static {}, Lcn/damai/commonbusiness/dynamicx/DynamicXInit;->j()Lcom/taobao/android/dinamicx/model/DXLongSparseArray;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/taobao/android/dinamicx/e$b;->z(Lcom/taobao/android/dinamicx/model/DXLongSparseArray;)Lcom/taobao/android/dinamicx/e$b;

    .line 4
    invoke-static {}, Lcn/damai/commonbusiness/dynamicx/DynamicXInit;->h()Lcom/taobao/android/dinamicx/model/DXLongSparseArray;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/taobao/android/dinamicx/e$b;->x(Lcom/taobao/android/dinamicx/model/DXLongSparseArray;)Lcom/taobao/android/dinamicx/e$b;

    .line 5
    invoke-static {}, Lcn/damai/commonbusiness/dynamicx/DynamicXInit;->d()Lcom/taobao/android/dinamicx/model/DXLongSparseArray;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/taobao/android/dinamicx/e$b;->y(Lcom/taobao/android/dinamicx/model/DXLongSparseArray;)Lcom/taobao/android/dinamicx/e$b;

    .line 6
    sget-object v1, Ltb/oa;->INSTANCE:Ltb/oa;

    invoke-virtual {v1}, Ltb/oa;->debugable()Z

    move-result v2

    invoke-virtual {v0, v2}, Lcom/taobao/android/dinamicx/e$b;->w(Z)Lcom/taobao/android/dinamicx/e$b;

    .line 7
    invoke-static {}, Lcn/damai/commonbusiness/dynamicx/DynamicXInit;->c()Lcom/taobao/android/dinamicx/monitor/IDXAppMonitor;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/taobao/android/dinamicx/e$b;->v(Lcom/taobao/android/dinamicx/monitor/IDXAppMonitor;)Lcom/taobao/android/dinamicx/e$b;

    .line 8
    invoke-static {}, Lcn/damai/commonbusiness/dynamicx/DynamicXInit;->i()Lcom/taobao/android/dinamicx/log/IDXRemoteDebugLog;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/taobao/android/dinamicx/e$b;->A(Lcom/taobao/android/dinamicx/log/IDXRemoteDebugLog;)Lcom/taobao/android/dinamicx/e$b;

    .line 9
    invoke-virtual {v1}, Ltb/oa;->getApplication()Landroid/app/Application;

    move-result-object v1

    invoke-virtual {v0}, Lcom/taobao/android/dinamicx/e$b;->u()Lcom/taobao/android/dinamicx/e;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/taobao/android/dinamicx/DinamicXEngine;->w(Landroid/content/Context;Lcom/taobao/android/dinamicx/e;)V

    return-void
.end method
