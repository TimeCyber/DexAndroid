.class public interface abstract Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask$Listener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "Listener"
.end annotation


# virtual methods
.method public abstract onSuccess(Landroid/graphics/Bitmap;)V
.end method
