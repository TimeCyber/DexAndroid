.class public Lcn/damai/commonbusiness/discover/bean/ThemeHeadResult;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x1L


# instance fields
.field public activity:Lcn/damai/discover/main/ui/bean/ThemeRankBean;

.field public projectDOS:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/search/bean/ProjectItemBean;",
            ">;"
        }
    .end annotation
.end field

.field public share:Lcn/damai/commonbusiness/discover/bean/ThemeShareBean;

.field public theme:Lcn/damai/commonbusiness/discover/bean/ThemeBean;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
