.class public Lcn/damai/commonbusiness/city/util/CityLocationUtil;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/city/util/CityLocationUtil$LocaltionListener;
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private a:Landroid/content/Context;

.field public b:Lcn/damai/commonbusiness/city/util/CityLocationUtil$LocaltionListener;

.field private c:J

.field private d:Ljava/lang/Double;

.field private e:Ljava/lang/Double;

.field private f:Ljava/lang/String;

.field private g:Ljava/lang/String;

.field private h:Z

.field private i:Z

.field private j:Ljava/lang/String;

.field private k:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcn/damai/commonbusiness/city/util/CityLocationUtil$LocaltionListener;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->h:Z

    const/4 v0, 0x1

    .line 3
    iput-boolean v0, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->i:Z

    const-string v0, "\u9999\u6e2f"

    .line 4
    iput-object v0, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->j:Ljava/lang/String;

    const-string v0, "\u6fb3\u95e8"

    .line 5
    iput-object v0, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->k:Ljava/lang/String;

    .line 6
    iput-object p1, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->a:Landroid/content/Context;

    .line 7
    iput-object p2, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->b:Lcn/damai/commonbusiness/city/util/CityLocationUtil$LocaltionListener;

    return-void
.end method

.method static synthetic a(Lcn/damai/commonbusiness/city/util/CityLocationUtil;)Ljava/lang/Double;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->d:Ljava/lang/Double;

    return-object p0
.end method

.method static synthetic b(Lcn/damai/commonbusiness/city/util/CityLocationUtil;Ljava/lang/Double;)Ljava/lang/Double;
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->d:Ljava/lang/Double;

    return-object p1
.end method

.method static synthetic c(Lcn/damai/commonbusiness/city/util/CityLocationUtil;)Ljava/lang/Double;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->e:Ljava/lang/Double;

    return-object p0
.end method

.method static synthetic d(Lcn/damai/commonbusiness/city/util/CityLocationUtil;)Z
    .registers 1

    .line 1
    iget-boolean p0, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->i:Z

    return p0
.end method

.method static synthetic e(Lcn/damai/commonbusiness/city/util/CityLocationUtil;Ljava/lang/Double;)Ljava/lang/Double;
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->e:Ljava/lang/Double;

    return-object p1
.end method

.method static synthetic f(Lcn/damai/commonbusiness/city/util/CityLocationUtil;)Z
    .registers 1

    .line 1
    iget-boolean p0, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->h:Z

    return p0
.end method

.method static synthetic g(Lcn/damai/commonbusiness/city/util/CityLocationUtil;Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->f:Ljava/lang/String;

    return-object p1
.end method

.method static synthetic h(Lcn/damai/commonbusiness/city/util/CityLocationUtil;)Ljava/lang/String;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->g:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic i(Lcn/damai/commonbusiness/city/util/CityLocationUtil;Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->g:Ljava/lang/String;

    return-object p1
.end method

.method static synthetic j(Lcn/damai/commonbusiness/city/util/CityLocationUtil;)Landroid/content/Context;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->a:Landroid/content/Context;

    return-object p0
.end method

.method static synthetic k(Lcn/damai/commonbusiness/city/util/CityLocationUtil;)Ljava/lang/String;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->j:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic l(Lcn/damai/commonbusiness/city/util/CityLocationUtil;)Ljava/lang/String;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->k:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic m(Lcn/damai/commonbusiness/city/util/CityLocationUtil;Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->q(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic n(Lcn/damai/commonbusiness/city/util/CityLocationUtil;Ljava/lang/String;)J
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->p(Ljava/lang/String;)J

    move-result-wide p0

    return-wide p0
.end method

.method static synthetic o(Lcn/damai/commonbusiness/city/util/CityLocationUtil;J)J
    .registers 3

    .line 1
    iput-wide p1, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->c:J

    return-wide p1
.end method

.method private p(Ljava/lang/String;)J
    .registers 12

    sget-object v0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Long;

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    return-wide v0

    .line 1
    :cond_1e
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const-wide/16 v1, 0x0

    if-eqz v0, :cond_27

    return-wide v1

    :cond_27
    const-string v0, "city_data_new"

    .line 2
    invoke-static {v0}, Ltb/ty0;->A(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 3
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_40

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->a:Landroid/content/Context;

    invoke-static {v0}, Ltb/z00;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    .line 5
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_40

    return-wide v1

    .line 6
    :cond_40
    :try_start_40
    const-class v4, Lcn/damai/commonbusiness/city/net/CityListResponse;

    invoke-static {v0, v4}, Lcom/alibaba/fastjson/JSON;->parseObject(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/city/net/CityListResponse;

    if-nez v0, :cond_4b

    return-wide v1

    .line 7
    :cond_4b
    invoke-virtual {v0}, Lcn/damai/commonbusiness/city/net/CityListResponse;->getGroups()Ljava/util/List;

    move-result-object v4

    .line 8
    invoke-static {v4}, Ltb/mw5;->f(Ljava/util/List;)I

    move-result v5

    if-gtz v5, :cond_56

    return-wide v1

    :cond_56
    const/4 v5, 0x0

    .line 9
    :goto_57
    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v6

    if-ge v5, v6, :cond_b9

    .line 10
    invoke-interface {v4, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcn/damai/commonbusiness/city/model/GroupsBean;

    if-eqz v6, :cond_b6

    .line 11
    invoke-virtual {v6}, Lcn/damai/commonbusiness/city/model/GroupsBean;->getSites()Ljava/util/List;

    move-result-object v6

    .line 12
    invoke-static {v6}, Ltb/mw5;->f(Ljava/util/List;)I

    move-result v7

    if-lez v7, :cond_b6

    const/4 v7, 0x0

    .line 13
    :goto_70
    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v8

    if-ge v7, v8, :cond_b6

    .line 14
    invoke-interface {v6, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcn/damai/commonbusiness/city/model/SitesBean;

    if-eqz v8, :cond_b3

    .line 15
    invoke-virtual {v8}, Lcn/damai/commonbusiness/city/model/SitesBean;->getCityName()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_b3

    .line 16
    invoke-virtual {v8}, Lcn/damai/commonbusiness/city/model/SitesBean;->getCityName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_b3

    .line 17
    invoke-virtual {v8}, Lcn/damai/commonbusiness/city/model/SitesBean;->getCityId()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_b3

    .line 18
    invoke-virtual {v8}, Lcn/damai/commonbusiness/city/model/SitesBean;->getCityId()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_b3

    .line 19
    invoke-virtual {v8}, Lcn/damai/commonbusiness/city/model/SitesBean;->getCityId()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1, v1, v2}, Ltb/mw5;->m(Ljava/lang/String;J)J

    move-result-wide v0

    return-wide v0

    :cond_b3
    add-int/lit8 v7, v7, 0x1

    goto :goto_70

    :cond_b6
    add-int/lit8 v5, v5, 0x1

    goto :goto_57

    .line 20
    :cond_b9
    invoke-virtual {v0}, Lcn/damai/commonbusiness/city/net/CityListResponse;->getHotCity()Ljava/util/List;

    move-result-object v0

    .line 21
    invoke-static {v4}, Ltb/mw5;->f(Ljava/util/List;)I

    move-result v4

    if-gtz v4, :cond_c4

    return-wide v1

    .line 22
    :cond_c4
    :goto_c4
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v4

    if-ge v3, v4, :cond_10b

    .line 23
    invoke-interface {v0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcn/damai/commonbusiness/city/model/HotCityBean;

    if-eqz v4, :cond_108

    .line 24
    invoke-virtual {v4}, Lcn/damai/commonbusiness/city/model/HotCityBean;->getCityName()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_108

    .line 25
    invoke-virtual {v4}, Lcn/damai/commonbusiness/city/model/HotCityBean;->getCityName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_108

    .line 26
    invoke-virtual {v4}, Lcn/damai/commonbusiness/city/model/HotCityBean;->getCityId()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_108

    .line 27
    invoke-virtual {v4}, Lcn/damai/commonbusiness/city/model/HotCityBean;->getCityId()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_108

    .line 28
    invoke-virtual {v4}, Lcn/damai/commonbusiness/city/model/HotCityBean;->getCityId()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p1
    :try_end_106
    .catch Ljava/lang/Exception; {:try_start_40 .. :try_end_106} :catch_10c

    int-to-long v0, p1

    return-wide v0

    :cond_108
    add-int/lit8 v3, v3, 0x1

    goto :goto_c4

    :cond_10b
    return-wide v1

    :catch_10c
    move-exception p1

    .line 29
    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return-wide v1
.end method

.method private q(Ljava/lang/String;)Ljava/lang/String;
    .registers 11

    sget-object v0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    return-object p1

    :cond_1a
    const-string v0, ""

    const-string v1, "city_data_new"

    .line 1
    invoke-static {v1}, Ltb/ty0;->A(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 2
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_35

    .line 3
    iget-object v1, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->a:Landroid/content/Context;

    invoke-static {v1}, Ltb/z00;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    .line 4
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_35

    return-object v0

    .line 5
    :cond_35
    :try_start_35
    const-class v2, Lcn/damai/commonbusiness/city/net/CityListResponse;

    invoke-static {v1, v2}, Lcom/alibaba/fastjson/JSON;->parseObject(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcn/damai/commonbusiness/city/net/CityListResponse;

    if-nez v1, :cond_40

    return-object v0

    .line 6
    :cond_40
    invoke-virtual {v1}, Lcn/damai/commonbusiness/city/net/CityListResponse;->getGroups()Ljava/util/List;

    move-result-object v2

    .line 7
    invoke-static {v2}, Ltb/mw5;->f(Ljava/util/List;)I

    move-result v4

    if-gtz v4, :cond_4b

    return-object v0

    :cond_4b
    const/4 v4, 0x0

    .line 8
    :goto_4c
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v5

    if-ge v4, v5, :cond_92

    .line 9
    invoke-interface {v2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcn/damai/commonbusiness/city/model/GroupsBean;

    if-eqz v5, :cond_8f

    .line 10
    invoke-virtual {v5}, Lcn/damai/commonbusiness/city/model/GroupsBean;->getSites()Ljava/util/List;

    move-result-object v5

    .line 11
    invoke-static {v5}, Ltb/mw5;->f(Ljava/util/List;)I

    move-result v6

    if-lez v6, :cond_8f

    const/4 v6, 0x0

    .line 12
    :goto_65
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v7

    if-ge v6, v7, :cond_8f

    .line 13
    invoke-interface {v5, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcn/damai/commonbusiness/city/model/SitesBean;

    if-eqz v7, :cond_8c

    .line 14
    invoke-virtual {v7}, Lcn/damai/commonbusiness/city/model/SitesBean;->getCityName()Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v8

    if-nez v8, :cond_8c

    .line 15
    invoke-virtual {v7}, Lcn/damai/commonbusiness/city/model/SitesBean;->getCityName()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {p1, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-eqz v8, :cond_8c

    .line 16
    invoke-virtual {v7}, Lcn/damai/commonbusiness/city/model/SitesBean;->getCityName()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_8c
    add-int/lit8 v6, v6, 0x1

    goto :goto_65

    :cond_8f
    add-int/lit8 v4, v4, 0x1

    goto :goto_4c

    .line 17
    :cond_92
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_cd

    .line 18
    invoke-virtual {v1}, Lcn/damai/commonbusiness/city/net/CityListResponse;->getHotCity()Ljava/util/List;

    move-result-object v1

    .line 19
    invoke-static {v2}, Ltb/mw5;->f(Ljava/util/List;)I

    move-result v2

    if-gtz v2, :cond_a3

    return-object v0

    .line 20
    :cond_a3
    :goto_a3
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v2

    if-ge v3, v2, :cond_cd

    .line 21
    invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/damai/commonbusiness/city/model/HotCityBean;

    if-eqz v2, :cond_ca

    .line 22
    invoke-virtual {v2}, Lcn/damai/commonbusiness/city/model/HotCityBean;->getCityName()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_ca

    .line 23
    invoke-virtual {v2}, Lcn/damai/commonbusiness/city/model/HotCityBean;->getCityName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_ca

    .line 24
    invoke-virtual {v2}, Lcn/damai/commonbusiness/city/model/HotCityBean;->getCityName()Ljava/lang/String;

    move-result-object p1
    :try_end_c9
    .catch Ljava/lang/Exception; {:try_start_35 .. :try_end_c9} :catch_ce

    return-object p1

    :cond_ca
    add-int/lit8 v3, v3, 0x1

    goto :goto_a3

    :cond_cd
    return-object v0

    :catch_ce
    move-exception p1

    .line 25
    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return-object v0
.end method


# virtual methods
.method public r()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    invoke-virtual {p0, v3}, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->s(Z)V

    return-void
.end method

.method public s(Z)V
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    invoke-static {}, Ltb/w64;->g()Z

    move-result v0

    if-eqz v0, :cond_7a

    .line 2
    new-instance v0, Lcn/damai/commonbusiness/city/util/CityLocationUtil$a;

    invoke-direct {v0, p0}, Lcn/damai/commonbusiness/city/util/CityLocationUtil$a;-><init>(Lcn/damai/commonbusiness/city/util/CityLocationUtil;)V

    .line 3
    new-instance v1, Ltb/st2;

    invoke-direct {v1}, Ltb/st2;-><init>()V

    if-eqz p1, :cond_3d

    const-wide/32 v2, 0x5265c00

    .line 4
    invoke-virtual {v1, v2, v3}, Ltb/st2;->e(J)V

    .line 5
    sget-object p1, Ltb/eu2;->INSTANCE:Ltb/eu2;

    invoke-virtual {p1}, Ltb/eu2;->e()Lcom/alibaba/pictures/piclocation/LocationInterface;

    move-result-object p1

    invoke-interface {p1, v0, v1}, Lcom/alibaba/pictures/piclocation/LocationInterface;->startLocation(Lcom/alibaba/pictures/piclocation/listener/LocateGpsPicListener;Ltb/st2;)V

    goto :goto_7a

    :cond_3d
    const-wide/32 v4, 0x493e0

    .line 6
    invoke-static {}, Ltb/nc0;->f()Ltb/k20;

    move-result-object p1

    const-string v2, "city_location_use_cache_time"

    const-string v6, "on"

    invoke-virtual {p1, v2, v6, v3}, Ltb/k20;->isExpected(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result p1

    if-eqz p1, :cond_4f

    goto :goto_51

    :cond_4f
    const-wide/16 v4, 0x0

    .line 7
    :goto_51
    invoke-virtual {v1, v4, v5}, Ltb/st2;->e(J)V

    .line 8
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "useCacheTime\uff1a"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz p1, :cond_63

    const-string p1, "\u4f7f\u75285\u5206\u949f\u5b9a\u4f4d\u7f13\u5b58"

    goto :goto_65

    :cond_63
    const-string p1, "\u672a\u4f7f\u7528\u5b9a\u4f4d\u7f13\u5b58"

    :goto_65
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v2, "CityLocationUtil"

    invoke-static {v2, p1}, Ltb/av2;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 9
    sget-object p1, Ltb/eu2;->INSTANCE:Ltb/eu2;

    invoke-virtual {p1}, Ltb/eu2;->e()Lcom/alibaba/pictures/piclocation/LocationInterface;

    move-result-object p1

    invoke-interface {p1, v0, v1}, Lcom/alibaba/pictures/piclocation/LocationInterface;->startLocation(Lcom/alibaba/pictures/piclocation/listener/LocateGpsPicListener;Ltb/st2;)V

    :cond_7a
    :goto_7a
    return-void
.end method

.method public t()V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "8"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-wide v0, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->c:J

    const-wide/16 v2, 0x0

    cmp-long v4, v0, v2

    if-eqz v4, :cond_71

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->d:Ljava/lang/Double;

    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    invoke-static {v0, v1}, Ltb/ty0;->n0(D)V

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->e:Ljava/lang/Double;

    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    invoke-static {v0, v1}, Ltb/ty0;->o0(D)V

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->f:Ljava/lang/String;

    invoke-static {v0}, Ltb/ty0;->k0(Ljava/lang/String;)V

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->g:Ljava/lang/String;

    invoke-static {v0}, Ltb/ty0;->p0(Ljava/lang/String;)V

    .line 6
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-wide v1, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->c:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, ","

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->d:Ljava/lang/Double;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->e:Ljava/lang/Double;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ltb/ty0;->m0(Ljava/lang/String;)V

    .line 7
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-wide v1, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->c:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, ""

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ltb/ty0;->l0(Ljava/lang/String;)V

    :cond_71
    return-void
.end method

.method public u(Z)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iput-boolean p1, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->h:Z

    return-void
.end method

.method public v()V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "7"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-wide v0, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->c:J

    const-wide/16 v2, 0x0

    cmp-long v4, v0, v2

    if-eqz v4, :cond_4f

    .line 2
    sput-wide v0, Ltb/o52;->b:J

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->g:Ljava/lang/String;

    sput-object v0, Ltb/o52;->c:Ljava/lang/String;

    .line 4
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-wide v1, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->c:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, ""

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ltb/ty0;->b0(Ljava/lang/String;)V

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->g:Ljava/lang/String;

    invoke-static {v0}, Ltb/ty0;->e0(Ljava/lang/String;)V

    .line 6
    iget-object v0, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->d:Ljava/lang/Double;

    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    invoke-static {v0, v1}, Ltb/ty0;->c0(D)V

    .line 7
    iget-object v0, p0, Lcn/damai/commonbusiness/city/util/CityLocationUtil;->e:Ljava/lang/Double;

    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    invoke-static {v0, v1}, Ltb/ty0;->d0(D)V

    :cond_4f
    return-void
.end method
