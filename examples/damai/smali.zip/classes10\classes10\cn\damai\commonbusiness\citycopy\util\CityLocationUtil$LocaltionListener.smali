.class public interface abstract Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil$LocaltionListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "LocaltionListener"
.end annotation


# virtual methods
.method public abstract onGetLocalFinsih()V
.end method

.method public abstract onGetLocalSuccess(Lcn/damai/commonbusiness/citycopy/model/SitesBean;)V
.end method
