.class public interface abstract Lcn/damai/commonbusiness/fission/util/FissionUtil$FissionViewInterface;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/fission/util/FissionUtil;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "FissionViewInterface"
.end annotation


# virtual methods
.method public abstract showEmptyPage()V
.end method

.method public abstract showErrorView(Ljava/lang/String;Ljava/lang/String;)V
.end method

.method public abstract showView(Lcn/damai/commonbusiness/fission/bean/FissionInfoBean;)V
.end method
