.class public Lcn/damai/commonbusiness/calendarcopy/bean/CalendarPerformEntity;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = -0x5eac5c71eb13eec6L


# instance fields
.field public dateType:I

.field public endDate:Ljava/lang/String;

.field public index:I

.field public isSelected:Z

.field public name:Ljava/lang/String;

.field public startDate:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
