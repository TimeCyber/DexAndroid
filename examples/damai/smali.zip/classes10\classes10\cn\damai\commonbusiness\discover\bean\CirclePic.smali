.class public Lcn/damai/commonbusiness/discover/bean/CirclePic;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field public id:Ljava/lang/String;

.field public pic:Ljava/lang/String;

.field public videoInfo:Lcn/damai/tetris/component/discover/bean/VideoInfo;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public getPicUrl()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/discover/bean/CirclePic;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    invoke-virtual {p0}, Lcn/damai/commonbusiness/discover/bean/CirclePic;->isUseVideoPic()Z

    move-result v0

    if-eqz v0, :cond_22

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/discover/bean/CirclePic;->videoInfo:Lcn/damai/tetris/component/discover/bean/VideoInfo;

    iget-object v0, v0, Lcn/damai/tetris/component/discover/bean/VideoInfo;->coverUrl:Ljava/lang/String;

    return-object v0

    .line 3
    :cond_22
    iget-object v0, p0, Lcn/damai/commonbusiness/discover/bean/CirclePic;->pic:Ljava/lang/String;

    return-object v0
.end method

.method public isUseVideoPic()Z
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/discover/bean/CirclePic;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_1b

    new-array v2, v4, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget-object v0, p0, Lcn/damai/commonbusiness/discover/bean/CirclePic;->videoInfo:Lcn/damai/tetris/component/discover/bean/VideoInfo;

    if-eqz v0, :cond_28

    iget-object v0, v0, Lcn/damai/tetris/component/discover/bean/VideoInfo;->coverUrl:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_28

    const/4 v3, 0x1

    :cond_28
    return v3
.end method
