.class public final Lcn/damai/commonbusiness/fission/FissionActivity$a;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/animation/Animation$AnimationListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/fission/FissionActivity;->animShareMenu()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    bv = {}
    d1 = {
        "\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0004*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J\u0012\u0010\u0005\u001a\u00020\u00042\u0008\u0010\u0003\u001a\u0004\u0018\u00010\u0002H\u0016J\u0012\u0010\u0006\u001a\u00020\u00042\u0008\u0010\u0003\u001a\u0004\u0018\u00010\u0002H\u0016J\u0012\u0010\u0007\u001a\u00020\u00042\u0008\u0010\u0003\u001a\u0004\u0018\u00010\u0002H\u0016\u00a8\u0006\u0008"
    }
    d2 = {
        "cn/damai/commonbusiness/fission/FissionActivity$a",
        "Landroid/view/animation/Animation$AnimationListener;",
        "Landroid/view/animation/Animation;",
        "animation",
        "",
        "onAnimationStart",
        "onAnimationEnd",
        "onAnimationRepeat",
        "commonbusiness_release"
    }
    k = 0x1
    mv = {
        0x1,
        0x7,
        0x1
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/fission/FissionActivity;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/fission/FissionActivity;)V
    .registers 2

    iput-object p1, p0, Lcn/damai/commonbusiness/fission/FissionActivity$a;->a:Lcn/damai/commonbusiness/fission/FissionActivity;

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/view/animation/Animation;)V
    .registers 7
    .param p1    # Landroid/view/animation/Animation;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param

    sget-object v0, Lcn/damai/commonbusiness/fission/FissionActivity$a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object p1, p0, Lcn/damai/commonbusiness/fission/FissionActivity$a;->a:Lcn/damai/commonbusiness/fission/FissionActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/fission/FissionActivity;->access$isWant$p(Lcn/damai/commonbusiness/fission/FissionActivity;)Z

    move-result p1

    if-eqz p1, :cond_20

    return-void

    .line 2
    :cond_20
    iget-object p1, p0, Lcn/damai/commonbusiness/fission/FissionActivity$a;->a:Lcn/damai/commonbusiness/fission/FissionActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/fission/FissionActivity;->access$isShowWantGuideAnim$p(Lcn/damai/commonbusiness/fission/FissionActivity;)Z

    move-result p1

    if-eqz p1, :cond_2e

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/fission/FissionActivity$a;->a:Lcn/damai/commonbusiness/fission/FissionActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/fission/FissionActivity;->access$animLight(Lcn/damai/commonbusiness/fission/FissionActivity;)V

    return-void

    .line 4
    :cond_2e
    iget-object p1, p0, Lcn/damai/commonbusiness/fission/FissionActivity$a;->a:Lcn/damai/commonbusiness/fission/FissionActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/fission/FissionActivity;->access$animLight(Lcn/damai/commonbusiness/fission/FissionActivity;)V

    .line 5
    iget-object p1, p0, Lcn/damai/commonbusiness/fission/FissionActivity$a;->a:Lcn/damai/commonbusiness/fission/FissionActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/fission/FissionActivity;->access$getLottieWantGuide$p(Lcn/damai/commonbusiness/fission/FissionActivity;)Lcom/alibaba/pictures/bricks/view/SafeLottieAnimationView;

    move-result-object p1

    if-eqz p1, :cond_43

    const-string v0, "https://g.alicdn.com/eva-assets/6b0d4649f01a972ce902bfe42ecf1c92/0.0.1/tmp/100e24c/100e24c.json"

    .line 6
    invoke-virtual {p1, v0}, Lcom/alibaba/pictures/bricks/view/SafeLottieAnimationView;->setAnimationFromUrl(Ljava/lang/String;)V

    .line 7
    invoke-virtual {p1}, Lcom/airbnb/lottie/LottieAnimationView;->playAnimation()V

    .line 8
    :cond_43
    invoke-static {}, Ltb/nc0;->i()Ltb/lt2;

    move-result-object p1

    const-string v0, "local_kv_project_detail_share_want_guide_anim"

    invoke-virtual {p1, v0, v3}, Ltb/lt2;->putBoolean(Ljava/lang/String;Z)V

    return-void
.end method

.method public onAnimationRepeat(Landroid/view/animation/Animation;)V
    .registers 6
    .param p1    # Landroid/view/animation/Animation;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param

    sget-object v0, Lcn/damai/commonbusiness/fission/FissionActivity$a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_16

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    :cond_16
    return-void
.end method

.method public onAnimationStart(Landroid/view/animation/Animation;)V
    .registers 6
    .param p1    # Landroid/view/animation/Animation;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param

    sget-object v0, Lcn/damai/commonbusiness/fission/FissionActivity$a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_16

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    :cond_16
    return-void
.end method
