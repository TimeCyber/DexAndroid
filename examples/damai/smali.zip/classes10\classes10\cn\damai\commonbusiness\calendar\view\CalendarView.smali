.class public Lcn/damai/commonbusiness/calendar/view/CalendarView;
.super Landroid/view/ViewGroup;
.source "Taobao"


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private mBubbleColumn:I

.field private mBubbleRow:I

.field private mContext:Landroid/content/Context;

.field private mDayHeigth:I

.field private mDayWidth:I

.field private mDays:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/calendar/bean/Day;",
            ">;"
        }
    .end annotation
.end field

.field private mIsCurrentMonth:Z

.field private mItemClickListener:Landroid/view/View$OnClickListener;

.field private mMonth:I

.field private mProjectTag:Ljava/lang/String;

.field private mRowNum:I

.field private mStartWeek:I

.field private mWidth:I

.field private mYear:I


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, p1, v0}, Lcn/damai/commonbusiness/calendar/view/CalendarView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 3

    .line 2
    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 p2, 0x0

    .line 3
    iput p2, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mBubbleRow:I

    .line 4
    iput p2, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mBubbleColumn:I

    .line 5
    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mContext:Landroid/content/Context;

    return-void
.end method

.method private fakeday(Lcn/damai/commonbusiness/calendar/bean/Day;)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "7"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v2, :cond_17

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    aput-object p1, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget v0, p1, Lcn/damai/commonbusiness/calendar/bean/Day;->day:I

    rem-int/lit8 v1, v0, 0x3

    const-string v2, ""

    if-nez v1, :cond_22

    .line 2
    iput-object v2, p1, Lcn/damai/commonbusiness/calendar/bean/Day;->tip:Ljava/lang/String;

    goto :goto_2f

    .line 3
    :cond_22
    rem-int/lit8 v1, v0, 0x3

    if-ne v1, v4, :cond_2b

    const-string v1, "\u4e00\u4e8c\u4e09\u56db"

    .line 4
    iput-object v1, p1, Lcn/damai/commonbusiness/calendar/bean/Day;->tip:Ljava/lang/String;

    goto :goto_2f

    :cond_2b
    const-string v1, "\u4e00\u4e8c\u4e09\u56db\u4e94\u516d\u4e03"

    .line 5
    iput-object v1, p1, Lcn/damai/commonbusiness/calendar/bean/Day;->tip:Ljava/lang/String;

    .line 6
    :goto_2f
    rem-int/lit8 v1, v0, 0x3

    iput v1, p1, Lcn/damai/commonbusiness/calendar/bean/Day;->dayType:I

    .line 7
    rem-int/lit8 v1, v0, 0x2

    if-nez v1, :cond_3c

    const-string v1, "\u56fd\u5e86\u8282"

    .line 8
    iput-object v1, p1, Lcn/damai/commonbusiness/calendar/bean/Day;->tag:Ljava/lang/String;

    goto :goto_42

    .line 9
    :cond_3c
    rem-int/lit8 v1, v0, 0x3

    if-ne v1, v4, :cond_42

    .line 10
    iput-object v2, p1, Lcn/damai/commonbusiness/calendar/bean/Day;->tag:Ljava/lang/String;

    .line 11
    :cond_42
    :goto_42
    rem-int/lit8 v0, v0, 0x4

    if-eqz v0, :cond_5d

    if-eq v0, v4, :cond_58

    if-eq v0, v3, :cond_53

    const/4 v1, 0x3

    if-eq v0, v1, :cond_4e

    goto :goto_61

    .line 12
    :cond_4e
    sget-object v0, Lcn/damai/commonbusiness/calendar/bean/DispatchDesc$TYPE;->PURPLE:Lcn/damai/commonbusiness/calendar/bean/DispatchDesc$TYPE;

    iput-object v0, p1, Lcn/damai/commonbusiness/calendar/bean/Day;->tipBg:Lcn/damai/commonbusiness/calendar/bean/DispatchDesc$TYPE;

    goto :goto_61

    .line 13
    :cond_53
    sget-object v0, Lcn/damai/commonbusiness/calendar/bean/DispatchDesc$TYPE;->YELLOW:Lcn/damai/commonbusiness/calendar/bean/DispatchDesc$TYPE;

    iput-object v0, p1, Lcn/damai/commonbusiness/calendar/bean/Day;->tipBg:Lcn/damai/commonbusiness/calendar/bean/DispatchDesc$TYPE;

    goto :goto_61

    .line 14
    :cond_58
    sget-object v0, Lcn/damai/commonbusiness/calendar/bean/DispatchDesc$TYPE;->PINK:Lcn/damai/commonbusiness/calendar/bean/DispatchDesc$TYPE;

    iput-object v0, p1, Lcn/damai/commonbusiness/calendar/bean/Day;->tipBg:Lcn/damai/commonbusiness/calendar/bean/DispatchDesc$TYPE;

    goto :goto_61

    .line 15
    :cond_5d
    sget-object v0, Lcn/damai/commonbusiness/calendar/bean/DispatchDesc$TYPE;->BLUE:Lcn/damai/commonbusiness/calendar/bean/DispatchDesc$TYPE;

    iput-object v0, p1, Lcn/damai/commonbusiness/calendar/bean/Day;->tipBg:Lcn/damai/commonbusiness/calendar/bean/DispatchDesc$TYPE;

    :goto_61
    return-void
.end method

.method private rePaintView()V
    .registers 14

    sget-object v0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_14

    new-array v2, v4, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    invoke-virtual {p0}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mContext:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    invoke-static {v0}, Lcom/alibaba/wireless/security/aopsdk/replace/android/util/DisplayMetrics;->getwidthPixels(Landroid/util/DisplayMetrics;)I

    move-result v0

    iput v0, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mWidth:I

    .line 3
    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mContext:Landroid/content/Context;

    const/high16 v2, 0x41900000    # 18.0f

    invoke-static {v1, v2}, Lcom/ali/user/mobile/utils/ScreenUtil;->dip2px(Landroid/content/Context;F)I

    move-result v1

    sub-int/2addr v0, v1

    const/4 v1, 0x7

    div-int/2addr v0, v1

    iput v0, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mDayWidth:I

    add-int/lit8 v0, v0, -0x6

    mul-int/lit8 v0, v0, 0x38

    .line 4
    div-int/lit8 v0, v0, 0x2d

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mContext:Landroid/content/Context;

    const/high16 v5, 0x41800000    # 16.0f

    invoke-static {v2, v5}, Lcom/ali/user/mobile/utils/ScreenUtil;->dip2px(Landroid/content/Context;F)I

    move-result v2

    add-int/2addr v0, v2

    iput v0, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mDayHeigth:I

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mDays:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    iget v2, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mStartWeek:I

    add-int/2addr v0, v2

    sub-int/2addr v0, v4

    rem-int/2addr v0, v1

    if-nez v0, :cond_60

    .line 6
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mDays:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    iget v2, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mStartWeek:I

    add-int/2addr v0, v2

    sub-int/2addr v0, v4

    div-int/2addr v0, v1

    iput v0, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mRowNum:I

    goto :goto_6e

    .line 7
    :cond_60
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mDays:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    iget v2, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mStartWeek:I

    add-int/2addr v0, v2

    sub-int/2addr v0, v4

    div-int/2addr v0, v1

    add-int/2addr v0, v4

    iput v0, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mRowNum:I

    :goto_6e
    const/4 v0, 0x0

    .line 8
    :goto_6f
    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mDays:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    if-ge v0, v2, :cond_1ad

    .line 9
    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mDays:Ljava/util/List;

    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/damai/commonbusiness/calendar/bean/Day;

    if-nez v2, :cond_83

    goto/16 :goto_1a9

    .line 10
    :cond_83
    iget-boolean v6, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mIsCurrentMonth:Z

    const/4 v7, 0x2

    if-eqz v6, :cond_a1

    .line 11
    invoke-static {}, Ltb/lt;->k()I

    move-result v6

    iget v8, v2, Lcn/damai/commonbusiness/calendar/bean/Day;->day:I

    if-le v6, v8, :cond_93

    .line 12
    iput v3, v2, Lcn/damai/commonbusiness/calendar/bean/Day;->showType:I

    goto :goto_a3

    .line 13
    :cond_93
    invoke-static {}, Ltb/lt;->k()I

    move-result v6

    iget v8, v2, Lcn/damai/commonbusiness/calendar/bean/Day;->day:I

    if-ne v6, v8, :cond_9e

    .line 14
    iput v4, v2, Lcn/damai/commonbusiness/calendar/bean/Day;->showType:I

    goto :goto_a3

    .line 15
    :cond_9e
    iput v7, v2, Lcn/damai/commonbusiness/calendar/bean/Day;->showType:I

    goto :goto_a3

    .line 16
    :cond_a1
    iput v7, v2, Lcn/damai/commonbusiness/calendar/bean/Day;->showType:I

    .line 17
    :goto_a3
    invoke-static {}, Ltb/g01;->a()Ltb/g01;

    move-result-object v6

    iget-object v8, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mContext:Landroid/content/Context;

    invoke-virtual {v6, v8, v2}, Ltb/g01;->b(Landroid/content/Context;Lcn/damai/commonbusiness/calendar/bean/Day;)Landroid/view/View;

    move-result-object v6

    .line 18
    invoke-virtual {v6, v2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 19
    iget-object v8, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mItemClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v6, v8}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 20
    invoke-virtual {p0, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 21
    sget v8, Lcn/damai/commonbusiness/R$id;->view_bg:I

    invoke-virtual {v6, v8}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v9

    invoke-virtual {v9}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v9

    iget v10, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mDayWidth:I

    iget-object v11, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mContext:Landroid/content/Context;

    const/high16 v12, 0x40c00000    # 6.0f

    invoke-static {v11, v12}, Ltb/d31;->a(Landroid/content/Context;F)I

    move-result v11

    sub-int/2addr v10, v11

    iput v10, v9, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 22
    invoke-virtual {v6, v8}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v8

    invoke-virtual {v8}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v8

    iget v9, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mDayHeigth:I

    iget-object v10, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mContext:Landroid/content/Context;

    invoke-static {v10, v5}, Lcom/ali/user/mobile/utils/ScreenUtil;->dip2px(Landroid/content/Context;F)I

    move-result v10

    sub-int/2addr v9, v10

    iput v9, v8, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 23
    sget v8, Lcn/damai/commonbusiness/R$id;->view_long_select:I

    invoke-virtual {v6, v8}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v9

    invoke-virtual {v9}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v9

    iget v10, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mDayWidth:I

    iput v10, v9, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 24
    invoke-virtual {v6, v8}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v9

    invoke-virtual {v9}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v9

    iget v10, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mDayHeigth:I

    iget-object v11, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mContext:Landroid/content/Context;

    invoke-static {v11, v5}, Lcom/ali/user/mobile/utils/ScreenUtil;->dip2px(Landroid/content/Context;F)I

    move-result v11

    sub-int/2addr v10, v11

    iput v10, v9, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 25
    invoke-virtual {v6, v8}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/FrameLayout;

    .line 26
    iget v8, v2, Lcn/damai/commonbusiness/calendar/bean/Day;->selectType:I

    if-lez v8, :cond_19e

    const-string v8, "GMT+8"

    .line 27
    invoke-static {v8}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v8

    invoke-static {v8}, Ljava/util/Calendar;->getInstance(Ljava/util/TimeZone;)Ljava/util/Calendar;

    move-result-object v8

    .line 28
    iget v9, v2, Lcn/damai/commonbusiness/calendar/bean/Day;->year:I

    iget v10, v2, Lcn/damai/commonbusiness/calendar/bean/Day;->month:I

    sub-int/2addr v10, v4

    iget v11, v2, Lcn/damai/commonbusiness/calendar/bean/Day;->day:I

    invoke-virtual {v8, v9, v10, v11}, Ljava/util/Calendar;->set(III)V

    .line 29
    invoke-virtual {v8, v1}, Ljava/util/Calendar;->get(I)I

    move-result v9

    const/4 v10, 0x5

    .line 30
    invoke-virtual {v8, v10}, Ljava/util/Calendar;->get(I)I

    move-result v11

    .line 31
    invoke-virtual {v8, v10}, Ljava/util/Calendar;->getActualMaximum(I)I

    move-result v8

    if-ne v11, v8, :cond_132

    const/4 v8, 0x1

    goto :goto_133

    :cond_132
    const/4 v8, 0x0

    :goto_133
    const/4 v10, 0x4

    if-eqz v8, :cond_13c

    .line 32
    iget v12, v2, Lcn/damai/commonbusiness/calendar/bean/Day;->selectType:I

    if-ne v12, v10, :cond_13c

    if-eq v9, v4, :cond_144

    :cond_13c
    if-ne v11, v4, :cond_150

    iget v12, v2, Lcn/damai/commonbusiness/calendar/bean/Day;->selectType:I

    if-ne v12, v10, :cond_150

    if-ne v9, v1, :cond_150

    .line 33
    :cond_144
    sget v2, Lcn/damai/commonbusiness/R$id;->view_long_select_inner:I

    invoke-virtual {v6, v2}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object v2

    sget v6, Lcn/damai/commonbusiness/R$drawable;->common_calendar_day_long_select_bg_all:I

    invoke-virtual {v2, v6}, Landroid/view/View;->setBackgroundResource(I)V

    goto :goto_1a9

    .line 34
    :cond_150
    iget v2, v2, Lcn/damai/commonbusiness/calendar/bean/Day;->selectType:I

    if-ne v2, v7, :cond_156

    if-nez v8, :cond_163

    :cond_156
    if-ne v2, v7, :cond_15a

    if-eq v9, v1, :cond_163

    :cond_15a
    const/4 v7, 0x3

    if-ne v2, v7, :cond_15f

    if-eq v9, v4, :cond_163

    :cond_15f
    if-ne v2, v7, :cond_169

    if-ne v11, v4, :cond_169

    :cond_163
    const/16 v2, 0x8

    .line 35
    invoke-virtual {v6, v2}, Landroid/widget/FrameLayout;->setVisibility(I)V

    goto :goto_1a9

    :cond_169
    const/high16 v2, 0x40400000    # 3.0f

    if-eq v9, v4, :cond_189

    if-ne v11, v4, :cond_170

    goto :goto_189

    :cond_170
    if-eq v9, v1, :cond_174

    if-eqz v8, :cond_1a9

    .line 36
    :cond_174
    iget-object v7, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mContext:Landroid/content/Context;

    invoke-static {v7, v2}, Ltb/d31;->a(Landroid/content/Context;F)I

    move-result v2

    invoke-virtual {v6, v3, v3, v2, v3}, Landroid/widget/FrameLayout;->setPadding(IIII)V

    .line 37
    sget v2, Lcn/damai/commonbusiness/R$id;->view_long_select_inner:I

    invoke-virtual {v6, v2}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object v2

    sget v6, Lcn/damai/commonbusiness/R$drawable;->common_calendar_day_long_select_bg_right:I

    invoke-virtual {v2, v6}, Landroid/view/View;->setBackgroundResource(I)V

    goto :goto_1a9

    .line 38
    :cond_189
    :goto_189
    iget-object v7, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mContext:Landroid/content/Context;

    invoke-static {v7, v2}, Ltb/d31;->a(Landroid/content/Context;F)I

    move-result v2

    invoke-virtual {v6, v2, v3, v3, v3}, Landroid/widget/FrameLayout;->setPadding(IIII)V

    .line 39
    sget v2, Lcn/damai/commonbusiness/R$id;->view_long_select_inner:I

    invoke-virtual {v6, v2}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object v2

    sget v6, Lcn/damai/commonbusiness/R$drawable;->common_calendar_day_long_select_bg_left:I

    invoke-virtual {v2, v6}, Landroid/view/View;->setBackgroundResource(I)V

    goto :goto_1a9

    .line 40
    :cond_19e
    sget v2, Lcn/damai/commonbusiness/R$id;->view_long_select_inner:I

    invoke-virtual {v6, v2}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object v2

    sget v6, Lcn/damai/commonbusiness/R$drawable;->common_calendar_day_long_select_bg:I

    invoke-virtual {v2, v6}, Landroid/view/View;->setBackgroundResource(I)V

    :cond_1a9
    :goto_1a9
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_6f

    :cond_1ad
    return-void
.end method

.method private reSetProjectName()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_14
    const/4 v0, 0x0

    .line 1
    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mProjectTag:Ljava/lang/String;

    .line 2
    iput v3, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mBubbleRow:I

    .line 3
    iput v3, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mBubbleColumn:I

    return-void
.end method


# virtual methods
.method public getDayWidth()I
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget v0, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mDayWidth:I

    return v0
.end method

.method public getLocation()[I
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_17

    new-array v2, v3, [Ljava/lang/Object;

    aput-object p0, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [I

    return-object v0

    :cond_17
    const/4 v0, 0x2

    new-array v0, v0, [I

    .line 1
    iget v1, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mBubbleRow:I

    aput v1, v0, v4

    iget v1, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mBubbleColumn:I

    aput v1, v0, v3

    return-object v0
.end method

.method public getProjectTag()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mProjectTag:Ljava/lang/String;

    return-object v0
.end method

.method protected onLayout(ZIIII)V
    .registers 11

    sget-object v0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "9"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_37

    const/4 v2, 0x6

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v4

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x5

    invoke-static {p5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_37
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mContext:Landroid/content/Context;

    const/high16 p2, 0x41100000    # 9.0f

    invoke-static {p1, p2}, Lcom/ali/user/mobile/utils/ScreenUtil;->dip2px(Landroid/content/Context;F)I

    move-result p1

    .line 2
    :goto_3f
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p2

    if-ge v3, p2, :cond_74

    .line 3
    invoke-virtual {p0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p2

    .line 4
    iget p3, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mStartWeek:I

    add-int p4, v3, p3

    sub-int/2addr p4, v4

    rem-int/lit8 p4, p4, 0x7

    iget p5, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mDayWidth:I

    mul-int p4, p4, p5

    add-int/2addr p4, p1

    iget v0, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mDayHeigth:I

    add-int v1, v3, p3

    sub-int/2addr v1, v4

    div-int/lit8 v1, v1, 0x7

    mul-int v1, v1, v0

    add-int v2, v3, p3

    sub-int/2addr v2, v4

    rem-int/lit8 v2, v2, 0x7

    add-int/2addr v2, v4

    mul-int v2, v2, p5

    add-int/2addr v2, p1

    add-int/2addr p3, v3

    sub-int/2addr p3, v4

    div-int/lit8 p3, p3, 0x7

    add-int/2addr p3, v4

    mul-int v0, v0, p3

    invoke-virtual {p2, p4, v1, v2, v0}, Landroid/view/View;->layout(IIII)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_3f

    :cond_74
    return-void
.end method

.method protected onMeasure(II)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "8"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_22

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_22
    invoke-super {p0, p1, p2}, Landroid/view/ViewGroup;->onMeasure(II)V

    .line 2
    :goto_25
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p1

    if-ge v3, p1, :cond_4b

    .line 3
    invoke-virtual {p0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p1

    .line 4
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p1

    .line 5
    iget p1, p1, Landroid/view/ViewGroup$LayoutParams;->height:I

    const/high16 p2, 0x40000000    # 2.0f

    invoke-static {p1, p2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p1

    .line 6
    iget v0, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mDayWidth:I

    invoke-static {v0, p2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p2

    .line 7
    invoke-virtual {p0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0, p2, p1}, Landroid/view/View;->measure(II)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_25

    .line 8
    :cond_4b
    iget p1, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mWidth:I

    iget p2, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mRowNum:I

    iget v0, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mDayHeigth:I

    mul-int p2, p2, v0

    invoke-virtual {p0, p1, p2}, Landroid/view/ViewGroup;->setMeasuredDimension(II)V

    return-void
.end method

.method public setMonth(IILjava/util/List;Lcn/damai/commonbusiness/calendar/bean/CalendarMonthBean;Landroid/view/View$OnClickListener;)V
    .registers 11
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "NewApi"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II",
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/calendar/bean/Day;",
            ">;",
            "Lcn/damai/commonbusiness/calendar/bean/CalendarMonthBean;",
            "Landroid/view/View$OnClickListener;",
            ")V"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_2b

    const/4 v2, 0x6

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v4

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    aput-object p3, v2, p1

    const/4 p1, 0x4

    aput-object p4, v2, p1

    const/4 p1, 0x5

    aput-object p5, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_2b
    invoke-direct {p0}, Lcn/damai/commonbusiness/calendar/view/CalendarView;->reSetProjectName()V

    .line 2
    iput-object p5, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mItemClickListener:Landroid/view/View$OnClickListener;

    .line 3
    iput p1, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mYear:I

    .line 4
    iput p2, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mMonth:I

    .line 5
    invoke-static {p1, p2}, Ltb/lt;->r(II)Z

    move-result p5

    iput-boolean p5, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mIsCurrentMonth:Z

    .line 6
    invoke-static {p1, p2, p3, p4}, Ltb/lt;->c(IILjava/util/List;Lcn/damai/commonbusiness/calendar/bean/CalendarMonthBean;)Ljava/util/List;

    move-result-object p3

    iput-object p3, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mDays:Ljava/util/List;

    .line 7
    invoke-static {p1, p2}, Ltb/lt;->h(II)I

    move-result p1

    iput p1, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mStartWeek:I

    .line 8
    :goto_46
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mDays:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    if-ge v3, p1, :cond_86

    .line 9
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mDays:Ljava/util/List;

    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    if-eqz p1, :cond_83

    .line 10
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mDays:Ljava/util/List;

    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/calendar/bean/Day;

    iget-object p1, p1, Lcn/damai/commonbusiness/calendar/bean/Day;->projectName:Ljava/lang/String;

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez p1, :cond_83

    .line 11
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mDays:Ljava/util/List;

    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/calendar/bean/Day;

    iget-object p1, p1, Lcn/damai/commonbusiness/calendar/bean/Day;->projectName:Ljava/lang/String;

    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mProjectTag:Ljava/lang/String;

    .line 12
    iget p1, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mStartWeek:I

    add-int p2, v3, p1

    sub-int/2addr p2, v4

    div-int/lit8 p2, p2, 0x7

    add-int/2addr p2, v4

    iput p2, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mBubbleRow:I

    add-int/2addr p1, v3

    sub-int/2addr p1, v4

    .line 13
    rem-int/lit8 p1, p1, 0x7

    add-int/2addr p1, v4

    iput p1, p0, Lcn/damai/commonbusiness/calendar/view/CalendarView;->mBubbleColumn:I

    :cond_83
    add-int/lit8 v3, v3, 0x1

    goto :goto_46

    .line 14
    :cond_86
    invoke-virtual {p0}, Landroid/view/ViewGroup;->isInEditMode()Z

    move-result p1

    if-nez p1, :cond_8f

    .line 15
    invoke-direct {p0}, Lcn/damai/commonbusiness/calendar/view/CalendarView;->rePaintView()V

    .line 16
    :cond_8f
    invoke-virtual {p0}, Landroid/view/ViewGroup;->requestLayout()V

    return-void
.end method
