.class public interface abstract Lcn/damai/commonbusiness/photoselect/photoview/OnMatrixChangedListener;
.super Ljava/lang/Object;
.source "Taobao"


# virtual methods
.method public abstract onMatrixChanged(Landroid/graphics/RectF;)V
.end method
