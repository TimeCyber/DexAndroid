.class public Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$5;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;->showBar()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic this$0:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$5;->this$0:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 6
    .annotation build Landroidx/annotation/RequiresApi;
        api = 0xb
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$5;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_14

    new-array v2, v4, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$5;->this$0:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;->access$600(Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;)Landroid/widget/LinearLayout;

    move-result-object v0

    if-eqz v0, :cond_4b

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$5;->this$0:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;->access$600(Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;)Landroid/widget/LinearLayout;

    move-result-object v0

    const/4 v1, 0x2

    new-array v1, v1, [F

    iget-object v2, p0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$5;->this$0:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;

    .line 3
    invoke-static {v2}, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;->access$600(Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;)Landroid/widget/LinearLayout;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/LinearLayout;->getTranslationY()F

    move-result v2

    aput v2, v1, v3

    const/4 v2, 0x0

    aput v2, v1, v4

    const-string v2, "translationY"

    .line 4
    invoke-static {v0, v2, v1}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object v0

    const-wide/16 v1, 0x12c

    .line 5
    invoke-virtual {v0, v1, v2}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    move-result-object v0

    .line 6
    new-instance v1, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$5$a;

    invoke-direct {v1, p0}, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$5$a;-><init>(Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$5;)V

    invoke-virtual {v0, v1}, Landroid/animation/ObjectAnimator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    .line 7
    invoke-virtual {v0}, Landroid/animation/ObjectAnimator;->start()V

    :cond_4b
    return-void
.end method
