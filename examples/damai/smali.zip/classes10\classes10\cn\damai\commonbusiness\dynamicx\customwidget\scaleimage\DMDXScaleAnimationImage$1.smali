.class public Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$1;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->run(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic this$0:Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;

.field final synthetic val$position:I


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;I)V
    .registers 3

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$1;->this$0:Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;

    iput p2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$1;->val$position:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$1;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_14

    new-array v2, v4, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$1;->val$position:I

    add-int/2addr v0, v4

    .line 2
    iget-object v1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$1;->this$0:Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;

    # getter for: Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageList:Ljava/util/List;
    invoke-static {v1}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->access$000(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)Ljava/util/List;

    move-result-object v1

    invoke-static {v1}, Ltb/mw5;->f(Ljava/util/List;)I

    move-result v1

    if-lt v0, v1, :cond_24

    goto :goto_25

    :cond_24
    move v3, v0

    .line 3
    :goto_25
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$1;->this$0:Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;

    # invokes: Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->setImage(I)V
    invoke-static {v0, v3}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->access$100(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;I)V

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$1;->this$0:Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;

    # getter for: Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->scaleOutAnimation:Landroid/animation/AnimatorSet;
    invoke-static {v0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->access$200(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)Landroid/animation/AnimatorSet;

    move-result-object v0

    invoke-virtual {v0}, Landroid/animation/AnimatorSet;->start()V

    return-void
.end method
