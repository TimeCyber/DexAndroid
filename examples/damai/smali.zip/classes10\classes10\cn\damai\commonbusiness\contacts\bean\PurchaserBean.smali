.class public Lcn/damai/commonbusiness/contacts/bean/PurchaserBean;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public contactsId:Ljava/lang/Long;

.field public createSource:Ljava/lang/String;

.field public identityHash:Ljava/lang/String;

.field public identityNo:Ljava/lang/String;

.field public identityType:Ljava/lang/Integer;

.field public identityTypeName:Ljava/lang/String;

.field public isUserVerified:Ljava/lang/Integer;

.field public maskedIdentityNo:Ljava/lang/String;

.field public maskedName:Ljava/lang/String;

.field public name:Ljava/lang/String;

.field public userCode:Ljava/lang/Long;

.field public verifyStatus:Ljava/lang/Integer;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
