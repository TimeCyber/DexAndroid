.class public final Lcn/damai/commonbusiness/R$style;
.super Ljava/lang/Object;
.source "Taobao"


# static fields
.field public static final ActionSheetDialogAnimation:I = 0x7f130000

.field public static final ActionSheetDialogStyle:I = 0x7f130001

.field public static final ActivityFlag:I = 0x7f130003

.field public static final AlertDialog_AppCompat:I = 0x7f130004

.field public static final AlertDialog_AppCompat_Light:I = 0x7f130005

.field public static final AliDialog_Status_Container:I = 0x7f130006

.field public static final AliMember_Base_AppTheme:I = 0x7f130007

.field public static final AliMember_UCC_Web_AppTheme:I = 0x7f130008

.field public static final AliUserAppThemeBase:I = 0x7f130009

.field public static final AliUserAppThemeLogin:I = 0x7f13000a

.field public static final AliUserAppThemeLoginBase:I = 0x7f13000b

.field public static final AliUserButtonStyle:I = 0x7f13000c

.field public static final AliUserDialogTheme:I = 0x7f13000d

.field public static final AliUserEditParentLayoutStyle:I = 0x7f13000e

.field public static final AliUserEditTextStyle:I = 0x7f13000f

.field public static final AliUserEditTextTheme:I = 0x7f130010

.field public static final AliUserFuncTextAppearance:I = 0x7f130011

.field public static final AliUserLoginTransparentTheme:I = 0x7f130012

.field public static final AliUserMenuAnimation:I = 0x7f130013

.field public static final AliUserMenuTextAppearance:I = 0x7f130014

.field public static final AliUserToolbarMenuTextStyle:I = 0x7f130015

.field public static final AliUserTransparentTheme:I = 0x7f130016

.field public static final AliuserNewTextApperance:I = 0x7f130018

.field public static final Aliuser_Theme_Permission_Transparent:I = 0x7f130017

.field public static final AndroidThemeColorAccentYellow:I = 0x7f130019

.field public static final Animation:I = 0x7f13001a

.field public static final Animation_AppCompat_Dialog:I = 0x7f13001b

.field public static final Animation_AppCompat_DropDownUp:I = 0x7f13001c

.field public static final Animation_AppCompat_Tooltip:I = 0x7f13001d

.field public static final Animation_Design_BottomSheetDialog:I = 0x7f13001e

.field public static final Animation_FromCommonBusiness:I = 0x7f130021

.field public static final Animation_MaterialComponents_BottomSheetDialog:I = 0x7f13001f

.field public static final AppTheme:I = 0x7f130023

.field public static final AppTheme_NoActionBar:I = 0x7f130024

.field public static final AppTheme_translucent:I = 0x7f130025

.field public static final AppTheme_translucent_bricks:I = 0x7f130026

.field public static final AppTheme_translucent_bricks_classic:I = 0x7f130027

.field public static final AppTheme_translucent_bricks_pioneer:I = 0x7f130028

.field public static final AppTheme_translucent_classic:I = 0x7f130029

.field public static final AppTheme_translucent_no_anim:I = 0x7f13002a

.field public static final AppTheme_translucent_no_animPioneer:I = 0x7f13002b

.field public static final AppTheme_translucent_pioneer:I = 0x7f13002c

.field public static final AppTheme_white:I = 0x7f13002d

.field public static final Assist_Style:I = 0x7f13002e

.field public static final AwesomeDialogAnimation:I = 0x7f13002f

.field public static final BaseTbmovieTheme:I = 0x7f130135

.field public static final BaseTheme:I = 0x7f130138

.field public static final Base_AlertDialog_AppCompat:I = 0x7f130030

.field public static final Base_AlertDialog_AppCompat_Light:I = 0x7f130031

.field public static final Base_Animation_AppCompat_Dialog:I = 0x7f130032

.field public static final Base_Animation_AppCompat_DropDownUp:I = 0x7f130033

.field public static final Base_Animation_AppCompat_Tooltip:I = 0x7f130034

.field public static final Base_CardView:I = 0x7f130035

.field public static final Base_DialogWindowTitleBackground_AppCompat:I = 0x7f130037

.field public static final Base_DialogWindowTitle_AppCompat:I = 0x7f130036

.field public static final Base_MaterialAlertDialog_MaterialComponents_Title_Icon:I = 0x7f130038

.field public static final Base_MaterialAlertDialog_MaterialComponents_Title_Panel:I = 0x7f130039

.field public static final Base_MaterialAlertDialog_MaterialComponents_Title_Text:I = 0x7f13003a

.field public static final Base_TextAppearance_AppCompat:I = 0x7f13003b

.field public static final Base_TextAppearance_AppCompat_Body1:I = 0x7f13003c

.field public static final Base_TextAppearance_AppCompat_Body2:I = 0x7f13003d

.field public static final Base_TextAppearance_AppCompat_Button:I = 0x7f13003e

.field public static final Base_TextAppearance_AppCompat_Caption:I = 0x7f13003f

.field public static final Base_TextAppearance_AppCompat_Display1:I = 0x7f130040

.field public static final Base_TextAppearance_AppCompat_Display2:I = 0x7f130041

.field public static final Base_TextAppearance_AppCompat_Display3:I = 0x7f130042

.field public static final Base_TextAppearance_AppCompat_Display4:I = 0x7f130043

.field public static final Base_TextAppearance_AppCompat_Headline:I = 0x7f130044

.field public static final Base_TextAppearance_AppCompat_Inverse:I = 0x7f130045

.field public static final Base_TextAppearance_AppCompat_Large:I = 0x7f130046

.field public static final Base_TextAppearance_AppCompat_Large_Inverse:I = 0x7f130047

.field public static final Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large:I = 0x7f130048

.field public static final Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small:I = 0x7f130049

.field public static final Base_TextAppearance_AppCompat_Medium:I = 0x7f13004a

.field public static final Base_TextAppearance_AppCompat_Medium_Inverse:I = 0x7f13004b

.field public static final Base_TextAppearance_AppCompat_Menu:I = 0x7f13004c

.field public static final Base_TextAppearance_AppCompat_SearchResult:I = 0x7f13004d

.field public static final Base_TextAppearance_AppCompat_SearchResult_Subtitle:I = 0x7f13004e

.field public static final Base_TextAppearance_AppCompat_SearchResult_Title:I = 0x7f13004f

.field public static final Base_TextAppearance_AppCompat_Small:I = 0x7f130050

.field public static final Base_TextAppearance_AppCompat_Small_Inverse:I = 0x7f130051

.field public static final Base_TextAppearance_AppCompat_Subhead:I = 0x7f130052

.field public static final Base_TextAppearance_AppCompat_Subhead_Inverse:I = 0x7f130053

.field public static final Base_TextAppearance_AppCompat_Title:I = 0x7f130054

.field public static final Base_TextAppearance_AppCompat_Title_Inverse:I = 0x7f130055

.field public static final Base_TextAppearance_AppCompat_Tooltip:I = 0x7f130056

.field public static final Base_TextAppearance_AppCompat_Widget_ActionBar_Menu:I = 0x7f130057

.field public static final Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle:I = 0x7f130058

.field public static final Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse:I = 0x7f130059

.field public static final Base_TextAppearance_AppCompat_Widget_ActionBar_Title:I = 0x7f13005a

.field public static final Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse:I = 0x7f13005b

.field public static final Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle:I = 0x7f13005c

.field public static final Base_TextAppearance_AppCompat_Widget_ActionMode_Title:I = 0x7f13005d

.field public static final Base_TextAppearance_AppCompat_Widget_Button:I = 0x7f13005e

.field public static final Base_TextAppearance_AppCompat_Widget_Button_Borderless_Colored:I = 0x7f13005f

.field public static final Base_TextAppearance_AppCompat_Widget_Button_Colored:I = 0x7f130060

.field public static final Base_TextAppearance_AppCompat_Widget_Button_Inverse:I = 0x7f130061

.field public static final Base_TextAppearance_AppCompat_Widget_DropDownItem:I = 0x7f130062

.field public static final Base_TextAppearance_AppCompat_Widget_PopupMenu_Header:I = 0x7f130063

.field public static final Base_TextAppearance_AppCompat_Widget_PopupMenu_Large:I = 0x7f130064

.field public static final Base_TextAppearance_AppCompat_Widget_PopupMenu_Small:I = 0x7f130065

.field public static final Base_TextAppearance_AppCompat_Widget_Switch:I = 0x7f130066

.field public static final Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem:I = 0x7f130067

.field public static final Base_TextAppearance_MaterialComponents_Badge:I = 0x7f130068

.field public static final Base_TextAppearance_MaterialComponents_Button:I = 0x7f130069

.field public static final Base_TextAppearance_MaterialComponents_Headline6:I = 0x7f13006a

.field public static final Base_TextAppearance_MaterialComponents_Subtitle2:I = 0x7f13006b

.field public static final Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item:I = 0x7f13006c

.field public static final Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle:I = 0x7f13006d

.field public static final Base_TextAppearance_Widget_AppCompat_Toolbar_Title:I = 0x7f13006e

.field public static final Base_ThemeOverlay_AppCompat:I = 0x7f130096

.field public static final Base_ThemeOverlay_AppCompat_ActionBar:I = 0x7f130097

.field public static final Base_ThemeOverlay_AppCompat_Dark:I = 0x7f130098

.field public static final Base_ThemeOverlay_AppCompat_Dark_ActionBar:I = 0x7f130099

.field public static final Base_ThemeOverlay_AppCompat_Dialog:I = 0x7f13009a

.field public static final Base_ThemeOverlay_AppCompat_Dialog_Alert:I = 0x7f13009b

.field public static final Base_ThemeOverlay_AppCompat_Light:I = 0x7f13009c

.field public static final Base_ThemeOverlay_MaterialComponents_Dialog:I = 0x7f1300a1

.field public static final Base_ThemeOverlay_MaterialComponents_Dialog_Alert:I = 0x7f1300a2

.field public static final Base_ThemeOverlay_MaterialComponents_Dialog_Alert_Framework:I = 0x7f1300a3

.field public static final Base_ThemeOverlay_MaterialComponents_Light_Dialog_Alert_Framework:I = 0x7f1300a4

.field public static final Base_ThemeOverlay_MaterialComponents_MaterialAlertDialog:I = 0x7f1300a5

.field public static final Base_Theme_AppCompat:I = 0x7f13006f

.field public static final Base_Theme_AppCompat_CompactMenu:I = 0x7f130070

.field public static final Base_Theme_AppCompat_Dialog:I = 0x7f130071

.field public static final Base_Theme_AppCompat_DialogWhenLarge:I = 0x7f130075

.field public static final Base_Theme_AppCompat_Dialog_Alert:I = 0x7f130072

.field public static final Base_Theme_AppCompat_Dialog_FixedSize:I = 0x7f130073

.field public static final Base_Theme_AppCompat_Dialog_MinWidth:I = 0x7f130074

.field public static final Base_Theme_AppCompat_Light:I = 0x7f130076

.field public static final Base_Theme_AppCompat_Light_DarkActionBar:I = 0x7f130077

.field public static final Base_Theme_AppCompat_Light_Dialog:I = 0x7f130078

.field public static final Base_Theme_AppCompat_Light_DialogWhenLarge:I = 0x7f13007c

.field public static final Base_Theme_AppCompat_Light_Dialog_Alert:I = 0x7f130079

.field public static final Base_Theme_AppCompat_Light_Dialog_FixedSize:I = 0x7f13007a

.field public static final Base_Theme_AppCompat_Light_Dialog_MinWidth:I = 0x7f13007b

.field public static final Base_Theme_MaterialComponents:I = 0x7f130083

.field public static final Base_Theme_MaterialComponents_Bridge:I = 0x7f130084

.field public static final Base_Theme_MaterialComponents_CompactMenu:I = 0x7f130085

.field public static final Base_Theme_MaterialComponents_Dialog:I = 0x7f130086

.field public static final Base_Theme_MaterialComponents_DialogWhenLarge:I = 0x7f13008b

.field public static final Base_Theme_MaterialComponents_Dialog_Alert:I = 0x7f130087

.field public static final Base_Theme_MaterialComponents_Dialog_Bridge:I = 0x7f130088

.field public static final Base_Theme_MaterialComponents_Dialog_FixedSize:I = 0x7f130089

.field public static final Base_Theme_MaterialComponents_Dialog_MinWidth:I = 0x7f13008a

.field public static final Base_Theme_MaterialComponents_Light:I = 0x7f13008c

.field public static final Base_Theme_MaterialComponents_Light_Bridge:I = 0x7f13008d

.field public static final Base_Theme_MaterialComponents_Light_DarkActionBar:I = 0x7f13008e

.field public static final Base_Theme_MaterialComponents_Light_DarkActionBar_Bridge:I = 0x7f13008f

.field public static final Base_Theme_MaterialComponents_Light_Dialog:I = 0x7f130090

.field public static final Base_Theme_MaterialComponents_Light_DialogWhenLarge:I = 0x7f130095

.field public static final Base_Theme_MaterialComponents_Light_Dialog_Alert:I = 0x7f130091

.field public static final Base_Theme_MaterialComponents_Light_Dialog_Bridge:I = 0x7f130092

.field public static final Base_Theme_MaterialComponents_Light_Dialog_FixedSize:I = 0x7f130093

.field public static final Base_Theme_MaterialComponents_Light_Dialog_MinWidth:I = 0x7f130094

.field public static final Base_Translucent:I = 0x7f130139

.field public static final Base_V14_ThemeOverlay_MaterialComponents_BottomSheetDialog:I = 0x7f1300b6

.field public static final Base_V14_ThemeOverlay_MaterialComponents_Dialog:I = 0x7f1300b7

.field public static final Base_V14_ThemeOverlay_MaterialComponents_Dialog_Alert:I = 0x7f1300b8

.field public static final Base_V14_ThemeOverlay_MaterialComponents_MaterialAlertDialog:I = 0x7f1300b9

.field public static final Base_V14_Theme_MaterialComponents:I = 0x7f1300ac

.field public static final Base_V14_Theme_MaterialComponents_Bridge:I = 0x7f1300ad

.field public static final Base_V14_Theme_MaterialComponents_Dialog:I = 0x7f1300ae

.field public static final Base_V14_Theme_MaterialComponents_Dialog_Bridge:I = 0x7f1300af

.field public static final Base_V14_Theme_MaterialComponents_Light:I = 0x7f1300b0

.field public static final Base_V14_Theme_MaterialComponents_Light_Bridge:I = 0x7f1300b1

.field public static final Base_V14_Theme_MaterialComponents_Light_DarkActionBar_Bridge:I = 0x7f1300b2

.field public static final Base_V14_Theme_MaterialComponents_Light_Dialog:I = 0x7f1300b3

.field public static final Base_V14_Theme_MaterialComponents_Light_Dialog_Bridge:I = 0x7f1300b4

.field public static final Base_V21_ThemeOverlay_AppCompat_Dialog:I = 0x7f1300c2

.field public static final Base_V21_ThemeOverlay_MaterialComponents_BottomSheetDialog:I = 0x7f1300c4

.field public static final Base_V21_Theme_AppCompat:I = 0x7f1300ba

.field public static final Base_V21_Theme_AppCompat_Dialog:I = 0x7f1300bb

.field public static final Base_V21_Theme_AppCompat_Light:I = 0x7f1300bc

.field public static final Base_V21_Theme_AppCompat_Light_Dialog:I = 0x7f1300bd

.field public static final Base_V21_Theme_MaterialComponents:I = 0x7f1300be

.field public static final Base_V21_Theme_MaterialComponents_Dialog:I = 0x7f1300bf

.field public static final Base_V21_Theme_MaterialComponents_Light:I = 0x7f1300c0

.field public static final Base_V21_Theme_MaterialComponents_Light_Dialog:I = 0x7f1300c1

.field public static final Base_V22_Theme_AppCompat:I = 0x7f1300c5

.field public static final Base_V22_Theme_AppCompat_Light:I = 0x7f1300c6

.field public static final Base_V23_Theme_AppCompat:I = 0x7f1300c7

.field public static final Base_V23_Theme_AppCompat_Light:I = 0x7f1300c8

.field public static final Base_V26_Theme_AppCompat:I = 0x7f1300cd

.field public static final Base_V26_Theme_AppCompat_Light:I = 0x7f1300ce

.field public static final Base_V26_Widget_AppCompat_Toolbar:I = 0x7f1300cf

.field public static final Base_V28_Theme_AppCompat:I = 0x7f1300d0

.field public static final Base_V28_Theme_AppCompat_Light:I = 0x7f1300d1

.field public static final Base_V7_ThemeOverlay_AppCompat_Dialog:I = 0x7f1300d6

.field public static final Base_V7_Theme_AppCompat:I = 0x7f1300d2

.field public static final Base_V7_Theme_AppCompat_Dialog:I = 0x7f1300d3

.field public static final Base_V7_Theme_AppCompat_Light:I = 0x7f1300d4

.field public static final Base_V7_Theme_AppCompat_Light_Dialog:I = 0x7f1300d5

.field public static final Base_V7_Widget_AppCompat_AutoCompleteTextView:I = 0x7f1300d7

.field public static final Base_V7_Widget_AppCompat_EditText:I = 0x7f1300d8

.field public static final Base_V7_Widget_AppCompat_Toolbar:I = 0x7f1300d9

.field public static final Base_Widget_AppCompat_ActionBar:I = 0x7f1300da

.field public static final Base_Widget_AppCompat_ActionBar_Solid:I = 0x7f1300db

.field public static final Base_Widget_AppCompat_ActionBar_TabBar:I = 0x7f1300dc

.field public static final Base_Widget_AppCompat_ActionBar_TabText:I = 0x7f1300dd

.field public static final Base_Widget_AppCompat_ActionBar_TabView:I = 0x7f1300de

.field public static final Base_Widget_AppCompat_ActionButton:I = 0x7f1300df

.field public static final Base_Widget_AppCompat_ActionButton_CloseMode:I = 0x7f1300e0

.field public static final Base_Widget_AppCompat_ActionButton_Overflow:I = 0x7f1300e1

.field public static final Base_Widget_AppCompat_ActionMode:I = 0x7f1300e2

.field public static final Base_Widget_AppCompat_ActivityChooserView:I = 0x7f1300e3

.field public static final Base_Widget_AppCompat_AutoCompleteTextView:I = 0x7f1300e4

.field public static final Base_Widget_AppCompat_Button:I = 0x7f1300e5

.field public static final Base_Widget_AppCompat_ButtonBar:I = 0x7f1300eb

.field public static final Base_Widget_AppCompat_ButtonBar_AlertDialog:I = 0x7f1300ec

.field public static final Base_Widget_AppCompat_Button_Borderless:I = 0x7f1300e6

.field public static final Base_Widget_AppCompat_Button_Borderless_Colored:I = 0x7f1300e7

.field public static final Base_Widget_AppCompat_Button_ButtonBar_AlertDialog:I = 0x7f1300e8

.field public static final Base_Widget_AppCompat_Button_Colored:I = 0x7f1300e9

.field public static final Base_Widget_AppCompat_Button_Small:I = 0x7f1300ea

.field public static final Base_Widget_AppCompat_CompoundButton_CheckBox:I = 0x7f1300ed

.field public static final Base_Widget_AppCompat_CompoundButton_RadioButton:I = 0x7f1300ee

.field public static final Base_Widget_AppCompat_CompoundButton_Switch:I = 0x7f1300ef

.field public static final Base_Widget_AppCompat_DrawerArrowToggle:I = 0x7f1300f0

.field public static final Base_Widget_AppCompat_DrawerArrowToggle_Common:I = 0x7f1300f1

.field public static final Base_Widget_AppCompat_DropDownItem_Spinner:I = 0x7f1300f2

.field public static final Base_Widget_AppCompat_EditText:I = 0x7f1300f3

.field public static final Base_Widget_AppCompat_ImageButton:I = 0x7f1300f4

.field public static final Base_Widget_AppCompat_Light_ActionBar:I = 0x7f1300f5

.field public static final Base_Widget_AppCompat_Light_ActionBar_Solid:I = 0x7f1300f6

.field public static final Base_Widget_AppCompat_Light_ActionBar_TabBar:I = 0x7f1300f7

.field public static final Base_Widget_AppCompat_Light_ActionBar_TabText:I = 0x7f1300f8

.field public static final Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse:I = 0x7f1300f9

.field public static final Base_Widget_AppCompat_Light_ActionBar_TabView:I = 0x7f1300fa

.field public static final Base_Widget_AppCompat_Light_PopupMenu:I = 0x7f1300fb

.field public static final Base_Widget_AppCompat_Light_PopupMenu_Overflow:I = 0x7f1300fc

.field public static final Base_Widget_AppCompat_ListMenuView:I = 0x7f1300fd

.field public static final Base_Widget_AppCompat_ListPopupWindow:I = 0x7f1300fe

.field public static final Base_Widget_AppCompat_ListView:I = 0x7f1300ff

.field public static final Base_Widget_AppCompat_ListView_DropDown:I = 0x7f130100

.field public static final Base_Widget_AppCompat_ListView_Menu:I = 0x7f130101

.field public static final Base_Widget_AppCompat_PopupMenu:I = 0x7f130102

.field public static final Base_Widget_AppCompat_PopupMenu_Overflow:I = 0x7f130103

.field public static final Base_Widget_AppCompat_PopupWindow:I = 0x7f130104

.field public static final Base_Widget_AppCompat_ProgressBar:I = 0x7f130105

.field public static final Base_Widget_AppCompat_ProgressBar_Horizontal:I = 0x7f130106

.field public static final Base_Widget_AppCompat_RatingBar:I = 0x7f130107

.field public static final Base_Widget_AppCompat_RatingBar_Indicator:I = 0x7f130108

.field public static final Base_Widget_AppCompat_RatingBar_Small:I = 0x7f130109

.field public static final Base_Widget_AppCompat_SearchView:I = 0x7f13010a

.field public static final Base_Widget_AppCompat_SearchView_ActionBar:I = 0x7f13010b

.field public static final Base_Widget_AppCompat_SeekBar:I = 0x7f13010c

.field public static final Base_Widget_AppCompat_SeekBar_Discrete:I = 0x7f13010d

.field public static final Base_Widget_AppCompat_Spinner:I = 0x7f13010e

.field public static final Base_Widget_AppCompat_Spinner_Underlined:I = 0x7f13010f

.field public static final Base_Widget_AppCompat_TextView:I = 0x7f130110

.field public static final Base_Widget_AppCompat_TextView_SpinnerItem:I = 0x7f130111

.field public static final Base_Widget_AppCompat_Toolbar:I = 0x7f130112

.field public static final Base_Widget_AppCompat_Toolbar_Button_Navigation:I = 0x7f130113

.field public static final Base_Widget_Design_TabLayout:I = 0x7f130114

.field public static final Base_Widget_MaterialComponents_AutoCompleteTextView:I = 0x7f130127

.field public static final Base_Widget_MaterialComponents_CheckedTextView:I = 0x7f130128

.field public static final Base_Widget_MaterialComponents_Chip:I = 0x7f130129

.field public static final Base_Widget_MaterialComponents_MaterialCalendar_NavigationButton:I = 0x7f13012b

.field public static final Base_Widget_MaterialComponents_PopupMenu:I = 0x7f13012c

.field public static final Base_Widget_MaterialComponents_PopupMenu_ContextMenu:I = 0x7f13012d

.field public static final Base_Widget_MaterialComponents_PopupMenu_ListPopupWindow:I = 0x7f13012e

.field public static final Base_Widget_MaterialComponents_PopupMenu_Overflow:I = 0x7f13012f

.field public static final Base_Widget_MaterialComponents_Slider:I = 0x7f130130

.field public static final Base_Widget_MaterialComponents_Snackbar:I = 0x7f130131

.field public static final Base_Widget_MaterialComponents_TextInputEditText:I = 0x7f130132

.field public static final Base_Widget_MaterialComponents_TextInputLayout:I = 0x7f130133

.field public static final Base_Widget_MaterialComponents_TextView:I = 0x7f130134

.field public static final BottomSheet_Persistent:I = 0x7f13013a

.field public static final BricksArtistTabStyle:I = 0x7f13013b

.field public static final BricksGenericDialogTheme:I = 0x7f13013c

.field public static final BricksScriptTabStyle:I = 0x7f13013d

.field public static final BricksThemeDialogTheme:I = 0x7f13013e

.field public static final CardView:I = 0x7f130140

.field public static final CardView_Dark:I = 0x7f130141

.field public static final CardView_Light:I = 0x7f130142

.field public static final ChannelArtistTabStyle:I = 0x7f130143

.field public static final CinemaList_Address:I = 0x7f130144

.field public static final CinemaList_Distance:I = 0x7f130145

.field public static final Circle_CountDown_Num_Text_Style:I = 0x7f130146

.field public static final CommonListItemContainerWhite:I = 0x7f130147

.field public static final CommonListItemContainerWhite2:I = 0x7f130148

.field public static final CommonListItemContainerWhiteGoodHeader:I = 0x7f130149

.field public static final CommonListItemContainerWhiteSaleItem:I = 0x7f13014a

.field public static final CommonListItemOrderHeaderContainerWhite:I = 0x7f13014b

.field public static final CommonListItemOrderTitle:I = 0x7f13014c

.field public static final CommonListItemText:I = 0x7f13014d

.field public static final CommonListItemTitle:I = 0x7f13014e

.field public static final CommonTabStyle:I = 0x7f13014f

.field public static final CustomDialog:I = 0x7f130151

.field public static final CustomProgressDialog:I = 0x7f130152

.field public static final CustomSeekbarStyle:I = 0x7f130153

.field public static final CustomTabText:I = 0x7f130154

.field public static final DMBaseTokenDefault:I = 0x7f130155

.field public static final DMBaseTokenPioneer:I = 0x7f130156

.field public static final DMDialogStyle:I = 0x7f130157

.field public static final DMSemanticsTokenDefault:I = 0x7f130159

.field public static final DMTabThemeDefault:I = 0x7f13015a

.field public static final DMTabThemePioneer:I = 0x7f13015b

.field public static final DMTextViewStyle:I = 0x7f13015c

.field public static final DMThemeSemanticsPioneer:I = 0x7f13015f

.field public static final DialogTheme:I = 0x7f130165

.field public static final DialogWindowTheme:I = 0x7f130166

.field public static final Dialog_Status_Container:I = 0x7f130163

.field public static final DrawerArrowStyle:I = 0x7f130167

.field public static final EmptyTheme:I = 0x7f130168

.field public static final FeedNewCard:I = 0x7f130169

.field public static final FilmDetailAnchorTabStyle:I = 0x7f13016a

.field public static final FilmDetailAnchorTabStylePioneer:I = 0x7f13016b

.field public static final FilmDetailTabStyle:I = 0x7f13016c

.field public static final FilmDetailTabStylePioneer:I = 0x7f13016d

.field public static final FilmDetailThemeDefault:I = 0x7f13016e

.field public static final FilmDetailThemePioneer:I = 0x7f13016f

.field public static final FilmImageSize:I = 0x7f130170

.field public static final FilmList_Director_72:I = 0x7f130171

.field public static final FilmRemark:I = 0x7f130172

.field public static final FilmRemarkBricksNumber:I = 0x7f130173

.field public static final FilmRemarkNumber:I = 0x7f130174

.field public static final FilmRemarkNumberPioneer:I = 0x7f130175

.field public static final FilmRemarkTitle:I = 0x7f130176

.field public static final FilmWantTitle:I = 0x7f130177

.field public static final FloatingDialogTheme:I = 0x7f130178

.field public static final FloatingDialogWindowTheme:I = 0x7f130179

.field public static final GrabButton:I = 0x7f13017b

.field public static final HeaderIconStyle:I = 0x7f13017e

.field public static final HomeFeedTabStyle:I = 0x7f13017f

.field public static final HomeTabStyle:I = 0x7f130180

.field public static final Homepage_TextView_Base_Timer_Text:I = 0x7f130181

.field public static final ImageStyle:I = 0x7f130182

.field public static final ImageTagsLayoutStyle:I = 0x7f130183

.field public static final Item_SubTitle2:I = 0x7f130184

.field public static final ListItemBorder:I = 0x7f130185

.field public static final ListItemBorderWithMarginDp:I = 0x7f130186

.field public static final LiveFeedTabStyle:I = 0x7f130187

.field public static final MainTheme:I = 0x7f130188

.field public static final MaterialAlertDialog_MaterialComponents:I = 0x7f130192

.field public static final MaterialAlertDialog_MaterialComponents_Body_Text:I = 0x7f130193

.field public static final MaterialAlertDialog_MaterialComponents_Picker_Date_Calendar:I = 0x7f130194

.field public static final MaterialAlertDialog_MaterialComponents_Picker_Date_Spinner:I = 0x7f130195

.field public static final MaterialAlertDialog_MaterialComponents_Title_Icon:I = 0x7f130196

.field public static final MaterialAlertDialog_MaterialComponents_Title_Icon_CenterStacked:I = 0x7f130197

.field public static final MaterialAlertDialog_MaterialComponents_Title_Panel:I = 0x7f130198

.field public static final MaterialAlertDialog_MaterialComponents_Title_Panel_CenterStacked:I = 0x7f130199

.field public static final MaterialAlertDialog_MaterialComponents_Title_Text:I = 0x7f13019a

.field public static final MaterialAlertDialog_MaterialComponents_Title_Text_CenterStacked:I = 0x7f13019b

.field public static final MaterialTheme:I = 0x7f13019c

.field public static final MovieTabLayoutTextAppearance:I = 0x7f13019e

.field public static final Mtitlebar:I = 0x7f13019f

.field public static final MyDialog:I = 0x7f1301a0

.field public static final MyDialogStyle:I = 0x7f1301a1

.field public static final MyDialogWithoutBackDim:I = 0x7f1301a2

.field public static final MyDialogWithoutBackDim2:I = 0x7f1301a3

.field public static final MyPullToRefreshHeader:I = 0x7f1301a5

.field public static final MyTextStyle:I = 0x7f1301a6

.field public static final MyToolBar:I = 0x7f1301a7

.field public static final MyToolBarText:I = 0x7f1301a8

.field public static final NewVenueTabStyle:I = 0x7f1301a9

.field public static final NoAnimTheme:I = 0x7f1301ab

.field public static final NoAnimThemeNew:I = 0x7f1301ac

.field public static final NoAnimThemeNewClassic:I = 0x7f1301ad

.field public static final NoAnimThemeNewPioneer:I = 0x7f1301ae

.field public static final NoAnimThemeNew_FromCommonBusiness:I = 0x7f1301af

.field public static final NoAnimThemeNew_FromCommonBusiness_Classic:I = 0x7f1301b0

.field public static final NoAnimThemeNew_FromCommonBusiness_Pioneer:I = 0x7f1301b1

.field public static final NoAnimThemePioneer:I = 0x7f1301b2

.field public static final NoAnimTransBgTheme:I = 0x7f1301b3

.field public static final NoAnimTransBgThemeClassic:I = 0x7f1301b4

.field public static final NoAnimTransBgThemePioneer:I = 0x7f1301b5

.field public static final NormalProgressbarStyle:I = 0x7f1301b7

.field public static final ONE_TAB_TEXT_SIZE2:I = 0x7f1301ba

.field public static final OrderCommonMarketItem:I = 0x7f1301bb

.field public static final PSK_Dialog:I = 0x7f1301bd

.field public static final PSK_FullScreenTheme:I = 0x7f1301be

.field public static final Permission_Delegate_Theme:I = 0x7f1301bf

.field public static final Permission_Delegate_Theme_Pioneer:I = 0x7f1301c0

.field public static final PioneerDialogTheme:I = 0x7f1301c1

.field public static final Platform_AppCompat:I = 0x7f1301c3

.field public static final Platform_AppCompat_Light:I = 0x7f1301c4

.field public static final Platform_MaterialComponents:I = 0x7f1301c5

.field public static final Platform_MaterialComponents_Dialog:I = 0x7f1301c6

.field public static final Platform_MaterialComponents_Light:I = 0x7f1301c7

.field public static final Platform_MaterialComponents_Light_Dialog:I = 0x7f1301c8

.field public static final Platform_ThemeOverlay_AppCompat:I = 0x7f1301c9

.field public static final Platform_ThemeOverlay_AppCompat_Dark:I = 0x7f1301ca

.field public static final Platform_ThemeOverlay_AppCompat_Light:I = 0x7f1301cb

.field public static final Platform_V21_AppCompat:I = 0x7f1301cc

.field public static final Platform_V21_AppCompat_Light:I = 0x7f1301cd

.field public static final Platform_V25_AppCompat:I = 0x7f1301ce

.field public static final Platform_V25_AppCompat_Light:I = 0x7f1301cf

.field public static final Platform_Widget_AppCompat_Spinner:I = 0x7f1301d0

.field public static final Project_Tabs_Style2:I = 0x7f1301d4

.field public static final PureTabStyle:I = 0x7f1301d7

.field public static final PureTabText:I = 0x7f1301d8

.field public static final RP_Dialog:I = 0x7f1301d9

.field public static final RP_FullScreenTheme:I = 0x7f1301da

.field public static final RtlOverlay_DialogWindowTitle_AppCompat:I = 0x7f1301db

.field public static final RtlOverlay_Widget_AppCompat_ActionBar_TitleItem:I = 0x7f1301dc

.field public static final RtlOverlay_Widget_AppCompat_DialogTitle_Icon:I = 0x7f1301dd

.field public static final RtlOverlay_Widget_AppCompat_PopupMenuItem:I = 0x7f1301de

.field public static final RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup:I = 0x7f1301df

.field public static final RtlOverlay_Widget_AppCompat_PopupMenuItem_Shortcut:I = 0x7f1301e0

.field public static final RtlOverlay_Widget_AppCompat_PopupMenuItem_SubmenuArrow:I = 0x7f1301e1

.field public static final RtlOverlay_Widget_AppCompat_PopupMenuItem_Text:I = 0x7f1301e2

.field public static final RtlOverlay_Widget_AppCompat_PopupMenuItem_Title:I = 0x7f1301e3

.field public static final RtlOverlay_Widget_AppCompat_SearchView_MagIcon:I = 0x7f1301e9

.field public static final RtlOverlay_Widget_AppCompat_Search_DropDown:I = 0x7f1301e4

.field public static final RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1:I = 0x7f1301e5

.field public static final RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2:I = 0x7f1301e6

.field public static final RtlOverlay_Widget_AppCompat_Search_DropDown_Query:I = 0x7f1301e7

.field public static final RtlOverlay_Widget_AppCompat_Search_DropDown_Text:I = 0x7f1301e8

.field public static final RtlUnderlay_Widget_AppCompat_ActionButton:I = 0x7f1301ea

.field public static final RtlUnderlay_Widget_AppCompat_ActionButton_Overflow:I = 0x7f1301eb

.field public static final ScenicDetailTabStyle:I = 0x7f1301ec

.field public static final Schedule_Err_desc:I = 0x7f1301ed

.field public static final ScoreRatinbar:I = 0x7f1301ee

.field public static final ScriptTabStyle:I = 0x7f1301ef

.field public static final ShapeAppearanceOverlay:I = 0x7f13020e

.field public static final ShapeAppearanceOverlay_BottomLeftDifferentCornerSize:I = 0x7f13020f

.field public static final ShapeAppearanceOverlay_BottomRightCut:I = 0x7f130210

.field public static final ShapeAppearanceOverlay_Cut:I = 0x7f130211

.field public static final ShapeAppearanceOverlay_DifferentCornerSize:I = 0x7f130212

.field public static final ShapeAppearanceOverlay_MaterialComponents_BottomSheet:I = 0x7f130219

.field public static final ShapeAppearanceOverlay_MaterialComponents_Chip:I = 0x7f13021a

.field public static final ShapeAppearanceOverlay_MaterialComponents_ExtendedFloatingActionButton:I = 0x7f13021b

.field public static final ShapeAppearanceOverlay_MaterialComponents_FloatingActionButton:I = 0x7f13021c

.field public static final ShapeAppearanceOverlay_MaterialComponents_MaterialCalendar_Day:I = 0x7f13021d

.field public static final ShapeAppearanceOverlay_MaterialComponents_MaterialCalendar_Window_Fullscreen:I = 0x7f13021e

.field public static final ShapeAppearanceOverlay_MaterialComponents_MaterialCalendar_Year:I = 0x7f13021f

.field public static final ShapeAppearanceOverlay_MaterialComponents_TextInputLayout_FilledBox:I = 0x7f130220

.field public static final ShapeAppearanceOverlay_TopLeftCut:I = 0x7f130221

.field public static final ShapeAppearanceOverlay_TopRightDifferentCornerSize:I = 0x7f130222

.field public static final ShapeAppearance_MaterialComponents:I = 0x7f130208

.field public static final ShapeAppearance_MaterialComponents_LargeComponent:I = 0x7f130209

.field public static final ShapeAppearance_MaterialComponents_MediumComponent:I = 0x7f13020a

.field public static final ShapeAppearance_MaterialComponents_SmallComponent:I = 0x7f13020b

.field public static final ShapeAppearance_MaterialComponents_Test:I = 0x7f13020c

.field public static final ShapeAppearance_MaterialComponents_Tooltip:I = 0x7f13020d

.field public static final ShareDeleteDialog:I = 0x7f130223

.field public static final ShareTransparentTheme:I = 0x7f130224

.field public static final SmoothProgressBar:I = 0x7f130225

.field public static final StickyHeaderTabStyle:I = 0x7f130228

.field public static final StickyHeaderTabText:I = 0x7f130229

.field public static final TMDialogStyle:I = 0x7f13022b

.field public static final TaoMaiH5Animation_Activity:I = 0x7f13022c

.field public static final TbMovieAnimation:I = 0x7f13022d

.field public static final TbMovieAnimation_Default:I = 0x7f13022e

.field public static final TbmovieStateHintStyle:I = 0x7f13022f

.field public static final TbmovieStateImageStyle:I = 0x7f130230

.field public static final TbmovieStateSubHintStyle:I = 0x7f130231

.field public static final TbmovieTheme:I = 0x7f130232

.field public static final TbmovieTheme_NoActionbar:I = 0x7f130233

.field public static final TbmovieTheme_NoActionbar_Translucent:I = 0x7f130234

.field public static final TbmovieTheme_NoActionbar_Translucent_ActionViewWaker:I = 0x7f130235

.field public static final TbmovieTheme_NoTitleBar_Fullscreen:I = 0x7f130236

.field public static final TbmovieTheme_Toolbar:I = 0x7f130237

.field public static final TbmovieTheme_Toolbar_Translucent:I = 0x7f130238

.field public static final TbmovieTheme_Translucent:I = 0x7f130239

.field public static final TestStyleWithLineHeight:I = 0x7f13023f

.field public static final TestStyleWithLineHeightAppearance:I = 0x7f130240

.field public static final TestStyleWithThemeLineHeightAttribute:I = 0x7f130241

.field public static final TestStyleWithoutLineHeight:I = 0x7f130242

.field public static final TestThemeWithLineHeight:I = 0x7f130243

.field public static final TestThemeWithLineHeightDisabled:I = 0x7f130244

.field public static final Test_ShapeAppearanceOverlay_MaterialComponents_MaterialCalendar_Day:I = 0x7f13023a

.field public static final Test_Theme_MaterialComponents_MaterialCalendar:I = 0x7f13023b

.field public static final Test_Widget_MaterialComponents_MaterialCalendar:I = 0x7f13023c

.field public static final Test_Widget_MaterialComponents_MaterialCalendar_Day:I = 0x7f13023d

.field public static final Test_Widget_MaterialComponents_MaterialCalendar_Day_Selected:I = 0x7f13023e

.field public static final TextAppearance_AppCompat:I = 0x7f130245

.field public static final TextAppearance_AppCompat_Body1:I = 0x7f130246

.field public static final TextAppearance_AppCompat_Body2:I = 0x7f130247

.field public static final TextAppearance_AppCompat_Button:I = 0x7f130248

.field public static final TextAppearance_AppCompat_Caption:I = 0x7f130249

.field public static final TextAppearance_AppCompat_Display1:I = 0x7f13024a

.field public static final TextAppearance_AppCompat_Display2:I = 0x7f13024b

.field public static final TextAppearance_AppCompat_Display3:I = 0x7f13024c

.field public static final TextAppearance_AppCompat_Display4:I = 0x7f13024d

.field public static final TextAppearance_AppCompat_Headline:I = 0x7f13024e

.field public static final TextAppearance_AppCompat_Inverse:I = 0x7f13024f

.field public static final TextAppearance_AppCompat_Large:I = 0x7f130250

.field public static final TextAppearance_AppCompat_Large_Inverse:I = 0x7f130251

.field public static final TextAppearance_AppCompat_Light_SearchResult_Subtitle:I = 0x7f130252

.field public static final TextAppearance_AppCompat_Light_SearchResult_Title:I = 0x7f130253

.field public static final TextAppearance_AppCompat_Light_Widget_PopupMenu_Large:I = 0x7f130254

.field public static final TextAppearance_AppCompat_Light_Widget_PopupMenu_Small:I = 0x7f130255

.field public static final TextAppearance_AppCompat_Medium:I = 0x7f130256

.field public static final TextAppearance_AppCompat_Medium_Inverse:I = 0x7f130257

.field public static final TextAppearance_AppCompat_Menu:I = 0x7f130258

.field public static final TextAppearance_AppCompat_SearchResult_Subtitle:I = 0x7f130259

.field public static final TextAppearance_AppCompat_SearchResult_Title:I = 0x7f13025a

.field public static final TextAppearance_AppCompat_Small:I = 0x7f13025b

.field public static final TextAppearance_AppCompat_Small_Inverse:I = 0x7f13025c

.field public static final TextAppearance_AppCompat_Subhead:I = 0x7f13025d

.field public static final TextAppearance_AppCompat_Subhead_Inverse:I = 0x7f13025e

.field public static final TextAppearance_AppCompat_Title:I = 0x7f13025f

.field public static final TextAppearance_AppCompat_Title_Inverse:I = 0x7f130260

.field public static final TextAppearance_AppCompat_Tooltip:I = 0x7f130261

.field public static final TextAppearance_AppCompat_Widget_ActionBar_Menu:I = 0x7f130262

.field public static final TextAppearance_AppCompat_Widget_ActionBar_Subtitle:I = 0x7f130263

.field public static final TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse:I = 0x7f130264

.field public static final TextAppearance_AppCompat_Widget_ActionBar_Title:I = 0x7f130265

.field public static final TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse:I = 0x7f130266

.field public static final TextAppearance_AppCompat_Widget_ActionMode_Subtitle:I = 0x7f130267

.field public static final TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse:I = 0x7f130268

.field public static final TextAppearance_AppCompat_Widget_ActionMode_Title:I = 0x7f130269

.field public static final TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse:I = 0x7f13026a

.field public static final TextAppearance_AppCompat_Widget_Button:I = 0x7f13026b

.field public static final TextAppearance_AppCompat_Widget_Button_Borderless_Colored:I = 0x7f13026c

.field public static final TextAppearance_AppCompat_Widget_Button_Colored:I = 0x7f13026d

.field public static final TextAppearance_AppCompat_Widget_Button_Inverse:I = 0x7f13026e

.field public static final TextAppearance_AppCompat_Widget_DropDownItem:I = 0x7f13026f

.field public static final TextAppearance_AppCompat_Widget_PopupMenu_Header:I = 0x7f130270

.field public static final TextAppearance_AppCompat_Widget_PopupMenu_Large:I = 0x7f130271

.field public static final TextAppearance_AppCompat_Widget_PopupMenu_Small:I = 0x7f130272

.field public static final TextAppearance_AppCompat_Widget_Switch:I = 0x7f130273

.field public static final TextAppearance_AppCompat_Widget_TextView_SpinnerItem:I = 0x7f130274

.field public static final TextAppearance_Compat_Notification:I = 0x7f130275

.field public static final TextAppearance_Compat_Notification_Info:I = 0x7f130276

.field public static final TextAppearance_Compat_Notification_Info_Media:I = 0x7f130277

.field public static final TextAppearance_Compat_Notification_Line2:I = 0x7f130278

.field public static final TextAppearance_Compat_Notification_Line2_Media:I = 0x7f130279

.field public static final TextAppearance_Compat_Notification_Media:I = 0x7f13027a

.field public static final TextAppearance_Compat_Notification_Time:I = 0x7f13027b

.field public static final TextAppearance_Compat_Notification_Time_Media:I = 0x7f13027c

.field public static final TextAppearance_Compat_Notification_Title:I = 0x7f13027d

.field public static final TextAppearance_Compat_Notification_Title_Media:I = 0x7f13027e

.field public static final TextAppearance_Design_CollapsingToolbar_Expanded:I = 0x7f13027f

.field public static final TextAppearance_Design_Counter:I = 0x7f130280

.field public static final TextAppearance_Design_Counter_Overflow:I = 0x7f130281

.field public static final TextAppearance_Design_Error:I = 0x7f130282

.field public static final TextAppearance_Design_HelperText:I = 0x7f130283

.field public static final TextAppearance_Design_Hint:I = 0x7f130284

.field public static final TextAppearance_Design_Placeholder:I = 0x7f130285

.field public static final TextAppearance_Design_Prefix:I = 0x7f130286

.field public static final TextAppearance_Design_Snackbar_Message:I = 0x7f130287

.field public static final TextAppearance_Design_Suffix:I = 0x7f130288

.field public static final TextAppearance_Design_Tab:I = 0x7f130289

.field public static final TextAppearance_MaterialCalendarWidget_Date:I = 0x7f1302ab

.field public static final TextAppearance_MaterialCalendarWidget_Header:I = 0x7f1302ac

.field public static final TextAppearance_MaterialCalendarWidget_WeekDay:I = 0x7f1302ad

.field public static final TextAppearance_MaterialComponents_Badge:I = 0x7f1302ae

.field public static final TextAppearance_MaterialComponents_Body1:I = 0x7f1302af

.field public static final TextAppearance_MaterialComponents_Body2:I = 0x7f1302b0

.field public static final TextAppearance_MaterialComponents_Button:I = 0x7f1302b1

.field public static final TextAppearance_MaterialComponents_Caption:I = 0x7f1302b2

.field public static final TextAppearance_MaterialComponents_Chip:I = 0x7f1302b3

.field public static final TextAppearance_MaterialComponents_Headline1:I = 0x7f1302b4

.field public static final TextAppearance_MaterialComponents_Headline2:I = 0x7f1302b5

.field public static final TextAppearance_MaterialComponents_Headline3:I = 0x7f1302b6

.field public static final TextAppearance_MaterialComponents_Headline4:I = 0x7f1302b7

.field public static final TextAppearance_MaterialComponents_Headline5:I = 0x7f1302b8

.field public static final TextAppearance_MaterialComponents_Headline6:I = 0x7f1302b9

.field public static final TextAppearance_MaterialComponents_Overline:I = 0x7f1302ba

.field public static final TextAppearance_MaterialComponents_Subtitle1:I = 0x7f1302bb

.field public static final TextAppearance_MaterialComponents_Subtitle2:I = 0x7f1302bc

.field public static final TextAppearance_MaterialComponents_TimePicker_Title:I = 0x7f1302bd

.field public static final TextAppearance_MaterialComponents_Tooltip:I = 0x7f1302be

.field public static final TextAppearance_Widget_AppCompat_ExpandedMenu_Item:I = 0x7f1302c2

.field public static final TextAppearance_Widget_AppCompat_Toolbar_Subtitle:I = 0x7f1302c3

.field public static final TextAppearance_Widget_AppCompat_Toolbar_Title:I = 0x7f1302c4

.field public static final ThemeFeedBack:I = 0x7f130331

.field public static final ThemeFeedBackPioneer:I = 0x7f130332

.field public static final ThemeOverlayColorAccentRed:I = 0x7f13039a

.field public static final ThemeOverlay_AppCompat:I = 0x7f130337

.field public static final ThemeOverlay_AppCompat_ActionBar:I = 0x7f130338

.field public static final ThemeOverlay_AppCompat_Dark:I = 0x7f130339

.field public static final ThemeOverlay_AppCompat_Dark_ActionBar:I = 0x7f13033a

.field public static final ThemeOverlay_AppCompat_DayNight:I = 0x7f13033b

.field public static final ThemeOverlay_AppCompat_DayNight_ActionBar:I = 0x7f13033c

.field public static final ThemeOverlay_AppCompat_Dialog:I = 0x7f13033d

.field public static final ThemeOverlay_AppCompat_Dialog_Alert:I = 0x7f13033e

.field public static final ThemeOverlay_AppCompat_Light:I = 0x7f13033f

.field public static final ThemeOverlay_Design_TextInputEditText:I = 0x7f130340

.field public static final ThemeOverlay_MaterialComponents:I = 0x7f130372

.field public static final ThemeOverlay_MaterialComponents_ActionBar:I = 0x7f130373

.field public static final ThemeOverlay_MaterialComponents_ActionBar_Primary:I = 0x7f130374

.field public static final ThemeOverlay_MaterialComponents_ActionBar_Surface:I = 0x7f130375

.field public static final ThemeOverlay_MaterialComponents_AutoCompleteTextView:I = 0x7f130376

.field public static final ThemeOverlay_MaterialComponents_AutoCompleteTextView_FilledBox:I = 0x7f130377

.field public static final ThemeOverlay_MaterialComponents_AutoCompleteTextView_FilledBox_Dense:I = 0x7f130378

.field public static final ThemeOverlay_MaterialComponents_AutoCompleteTextView_OutlinedBox:I = 0x7f130379

.field public static final ThemeOverlay_MaterialComponents_AutoCompleteTextView_OutlinedBox_Dense:I = 0x7f13037a

.field public static final ThemeOverlay_MaterialComponents_BottomAppBar_Primary:I = 0x7f13037b

.field public static final ThemeOverlay_MaterialComponents_BottomAppBar_Surface:I = 0x7f13037c

.field public static final ThemeOverlay_MaterialComponents_BottomSheetDialog:I = 0x7f13037d

.field public static final ThemeOverlay_MaterialComponents_Dark:I = 0x7f13037e

.field public static final ThemeOverlay_MaterialComponents_Dark_ActionBar:I = 0x7f13037f

.field public static final ThemeOverlay_MaterialComponents_DayNight_BottomSheetDialog:I = 0x7f130380

.field public static final ThemeOverlay_MaterialComponents_Dialog:I = 0x7f130381

.field public static final ThemeOverlay_MaterialComponents_Dialog_Alert:I = 0x7f130382

.field public static final ThemeOverlay_MaterialComponents_Dialog_Alert_Framework:I = 0x7f130383

.field public static final ThemeOverlay_MaterialComponents_Light:I = 0x7f130384

.field public static final ThemeOverlay_MaterialComponents_Light_Dialog_Alert_Framework:I = 0x7f130385

.field public static final ThemeOverlay_MaterialComponents_MaterialAlertDialog:I = 0x7f130386

.field public static final ThemeOverlay_MaterialComponents_MaterialAlertDialog_Centered:I = 0x7f130387

.field public static final ThemeOverlay_MaterialComponents_MaterialAlertDialog_Picker_Date:I = 0x7f130388

.field public static final ThemeOverlay_MaterialComponents_MaterialAlertDialog_Picker_Date_Calendar:I = 0x7f130389

.field public static final ThemeOverlay_MaterialComponents_MaterialAlertDialog_Picker_Date_Header_Text:I = 0x7f13038a

.field public static final ThemeOverlay_MaterialComponents_MaterialAlertDialog_Picker_Date_Header_Text_Day:I = 0x7f13038b

.field public static final ThemeOverlay_MaterialComponents_MaterialAlertDialog_Picker_Date_Spinner:I = 0x7f13038c

.field public static final ThemeOverlay_MaterialComponents_MaterialCalendar:I = 0x7f13038d

.field public static final ThemeOverlay_MaterialComponents_MaterialCalendar_Fullscreen:I = 0x7f13038e

.field public static final ThemeOverlay_MaterialComponents_TextInputEditText:I = 0x7f13038f

.field public static final ThemeOverlay_MaterialComponents_TextInputEditText_FilledBox:I = 0x7f130390

.field public static final ThemeOverlay_MaterialComponents_TextInputEditText_FilledBox_Dense:I = 0x7f130391

.field public static final ThemeOverlay_MaterialComponents_TextInputEditText_OutlinedBox:I = 0x7f130392

.field public static final ThemeOverlay_MaterialComponents_TextInputEditText_OutlinedBox_Dense:I = 0x7f130393

.field public static final ThemeOverlay_MaterialComponents_TimePicker:I = 0x7f130394

.field public static final ThemeOverlay_MaterialComponents_TimePicker_Display:I = 0x7f130395

.field public static final ThemeOverlay_MaterialComponents_TimePicker_Display_TextInputEditText:I = 0x7f130396

.field public static final ThemeOverlay_MaterialComponents_Toolbar_Primary:I = 0x7f130398

.field public static final ThemeOverlay_MaterialComponents_Toolbar_Surface:I = 0x7f130399

.field public static final Theme_AppCompat:I = 0x7f1302c5

.field public static final Theme_AppCompat_CompactMenu:I = 0x7f1302c6

.field public static final Theme_AppCompat_DayNight:I = 0x7f1302c7

.field public static final Theme_AppCompat_DayNight_DarkActionBar:I = 0x7f1302c8

.field public static final Theme_AppCompat_DayNight_Dialog:I = 0x7f1302c9

.field public static final Theme_AppCompat_DayNight_DialogWhenLarge:I = 0x7f1302cc

.field public static final Theme_AppCompat_DayNight_Dialog_Alert:I = 0x7f1302ca

.field public static final Theme_AppCompat_DayNight_Dialog_MinWidth:I = 0x7f1302cb

.field public static final Theme_AppCompat_DayNight_NoActionBar:I = 0x7f1302cd

.field public static final Theme_AppCompat_Dialog:I = 0x7f1302ce

.field public static final Theme_AppCompat_DialogWhenLarge:I = 0x7f1302d1

.field public static final Theme_AppCompat_Dialog_Alert:I = 0x7f1302cf

.field public static final Theme_AppCompat_Dialog_MinWidth:I = 0x7f1302d0

.field public static final Theme_AppCompat_Empty:I = 0x7f1302d2

.field public static final Theme_AppCompat_Light:I = 0x7f1302d3

.field public static final Theme_AppCompat_Light_DarkActionBar:I = 0x7f1302d4

.field public static final Theme_AppCompat_Light_Dialog:I = 0x7f1302d5

.field public static final Theme_AppCompat_Light_DialogWhenLarge:I = 0x7f1302d8

.field public static final Theme_AppCompat_Light_Dialog_Alert:I = 0x7f1302d6

.field public static final Theme_AppCompat_Light_Dialog_MinWidth:I = 0x7f1302d7

.field public static final Theme_AppCompat_Light_NoActionBar:I = 0x7f1302d9

.field public static final Theme_AppCompat_Light_NoActionBar_FullScreen:I = 0x7f1302da

.field public static final Theme_AppCompat_NoActionBar:I = 0x7f1302db

.field public static final Theme_AppCompat_UccTranslucent:I = 0x7f1302dc

.field public static final Theme_AppStartLoadTranslucent:I = 0x7f1302dd

.field public static final Theme_CountDown_Num_Text_Style:I = 0x7f13039b

.field public static final Theme_CountDown_Text_Style:I = 0x7f13039c

.field public static final Theme_Design:I = 0x7f1302de

.field public static final Theme_Design_BottomSheetDialog:I = 0x7f1302df

.field public static final Theme_Design_Light:I = 0x7f1302e0

.field public static final Theme_Design_Light_BottomSheetDialog:I = 0x7f1302e1

.field public static final Theme_Design_Light_NoActionBar:I = 0x7f1302e2

.field public static final Theme_Design_NoActionBar:I = 0x7f1302e3

.field public static final Theme_FeedBack:I = 0x7f1302e4

.field public static final Theme_MaterialComponents:I = 0x7f1302ff

.field public static final Theme_MaterialComponents_BottomSheetDialog:I = 0x7f130300

.field public static final Theme_MaterialComponents_Bridge:I = 0x7f130301

.field public static final Theme_MaterialComponents_CompactMenu:I = 0x7f130302

.field public static final Theme_MaterialComponents_DayNight:I = 0x7f130303

.field public static final Theme_MaterialComponents_DayNight_BottomSheetDialog:I = 0x7f130304

.field public static final Theme_MaterialComponents_DayNight_Bridge:I = 0x7f130305

.field public static final Theme_MaterialComponents_DayNight_DarkActionBar:I = 0x7f130306

.field public static final Theme_MaterialComponents_DayNight_DarkActionBar_Bridge:I = 0x7f130307

.field public static final Theme_MaterialComponents_DayNight_Dialog:I = 0x7f130308

.field public static final Theme_MaterialComponents_DayNight_DialogWhenLarge:I = 0x7f130310

.field public static final Theme_MaterialComponents_DayNight_Dialog_Alert:I = 0x7f130309

.field public static final Theme_MaterialComponents_DayNight_Dialog_Alert_Bridge:I = 0x7f13030a

.field public static final Theme_MaterialComponents_DayNight_Dialog_Bridge:I = 0x7f13030b

.field public static final Theme_MaterialComponents_DayNight_Dialog_FixedSize:I = 0x7f13030c

.field public static final Theme_MaterialComponents_DayNight_Dialog_FixedSize_Bridge:I = 0x7f13030d

.field public static final Theme_MaterialComponents_DayNight_Dialog_MinWidth:I = 0x7f13030e

.field public static final Theme_MaterialComponents_DayNight_Dialog_MinWidth_Bridge:I = 0x7f13030f

.field public static final Theme_MaterialComponents_DayNight_NoActionBar:I = 0x7f130311

.field public static final Theme_MaterialComponents_DayNight_NoActionBar_Bridge:I = 0x7f130312

.field public static final Theme_MaterialComponents_Dialog:I = 0x7f130313

.field public static final Theme_MaterialComponents_DialogWhenLarge:I = 0x7f13031b

.field public static final Theme_MaterialComponents_Dialog_Alert:I = 0x7f130314

.field public static final Theme_MaterialComponents_Dialog_Alert_Bridge:I = 0x7f130315

.field public static final Theme_MaterialComponents_Dialog_Bridge:I = 0x7f130316

.field public static final Theme_MaterialComponents_Dialog_FixedSize:I = 0x7f130317

.field public static final Theme_MaterialComponents_Dialog_FixedSize_Bridge:I = 0x7f130318

.field public static final Theme_MaterialComponents_Dialog_MinWidth:I = 0x7f130319

.field public static final Theme_MaterialComponents_Dialog_MinWidth_Bridge:I = 0x7f13031a

.field public static final Theme_MaterialComponents_Light:I = 0x7f13031c

.field public static final Theme_MaterialComponents_Light_BarSize:I = 0x7f13031d

.field public static final Theme_MaterialComponents_Light_BottomSheetDialog:I = 0x7f13031e

.field public static final Theme_MaterialComponents_Light_Bridge:I = 0x7f13031f

.field public static final Theme_MaterialComponents_Light_DarkActionBar:I = 0x7f130320

.field public static final Theme_MaterialComponents_Light_DarkActionBar_Bridge:I = 0x7f130321

.field public static final Theme_MaterialComponents_Light_Dialog:I = 0x7f130322

.field public static final Theme_MaterialComponents_Light_DialogWhenLarge:I = 0x7f13032a

.field public static final Theme_MaterialComponents_Light_Dialog_Alert:I = 0x7f130323

.field public static final Theme_MaterialComponents_Light_Dialog_Alert_Bridge:I = 0x7f130324

.field public static final Theme_MaterialComponents_Light_Dialog_Bridge:I = 0x7f130325

.field public static final Theme_MaterialComponents_Light_Dialog_FixedSize:I = 0x7f130326

.field public static final Theme_MaterialComponents_Light_Dialog_FixedSize_Bridge:I = 0x7f130327

.field public static final Theme_MaterialComponents_Light_Dialog_MinWidth:I = 0x7f130328

.field public static final Theme_MaterialComponents_Light_Dialog_MinWidth_Bridge:I = 0x7f130329

.field public static final Theme_MaterialComponents_Light_LargeTouch:I = 0x7f13032b

.field public static final Theme_MaterialComponents_Light_NoActionBar:I = 0x7f13032c

.field public static final Theme_MaterialComponents_Light_NoActionBar_Bridge:I = 0x7f13032d

.field public static final Theme_MaterialComponents_NoActionBar:I = 0x7f13032e

.field public static final Theme_MaterialComponents_NoActionBar_Bridge:I = 0x7f13032f

.field public static final Theme_SmoothProgressBarDefaults:I = 0x7f130330

.field public static final TickletPopWindow:I = 0x7f13039e

.field public static final ToolbarStyle:I = 0x7f1303a1

.field public static final TppBaseTheme:I = 0x7f1303a2

.field public static final TppBaseThemeClassic:I = 0x7f1303a3

.field public static final TppBaseThemePioneer:I = 0x7f1303a4

.field public static final Trans:I = 0x7f1303a5

.field public static final TranslucentBase:I = 0x7f1303a6

.field public static final TranslucentCommon:I = 0x7f1303a7

.field public static final TranslucentCommonPioneer:I = 0x7f1303a8

.field public static final TranslucentPicturesBizBase:I = 0x7f1303a9

.field public static final TranslucentPicturesBizBasePioneer:I = 0x7f1303aa

.field public static final TransparentTheme:I = 0x7f1303ab

.field public static final VenueThemeNormal:I = 0x7f1303ad

.field public static final VenueThemePioneer:I = 0x7f1303ae

.field public static final WarningTipsView:I = 0x7f1303b0

.field public static final Widget_AppCompat_ActionBar:I = 0x7f1303b1

.field public static final Widget_AppCompat_ActionBar_Solid:I = 0x7f1303b2

.field public static final Widget_AppCompat_ActionBar_TabBar:I = 0x7f1303b3

.field public static final Widget_AppCompat_ActionBar_TabText:I = 0x7f1303b4

.field public static final Widget_AppCompat_ActionBar_TabView:I = 0x7f1303b5

.field public static final Widget_AppCompat_ActionButton:I = 0x7f1303b6

.field public static final Widget_AppCompat_ActionButton_CloseMode:I = 0x7f1303b7

.field public static final Widget_AppCompat_ActionButton_Overflow:I = 0x7f1303b8

.field public static final Widget_AppCompat_ActionMode:I = 0x7f1303b9

.field public static final Widget_AppCompat_ActivityChooserView:I = 0x7f1303ba

.field public static final Widget_AppCompat_AutoCompleteTextView:I = 0x7f1303bb

.field public static final Widget_AppCompat_Button:I = 0x7f1303bc

.field public static final Widget_AppCompat_ButtonBar:I = 0x7f1303c2

.field public static final Widget_AppCompat_ButtonBar_AlertDialog:I = 0x7f1303c3

.field public static final Widget_AppCompat_Button_Borderless:I = 0x7f1303bd

.field public static final Widget_AppCompat_Button_Borderless_Colored:I = 0x7f1303be

.field public static final Widget_AppCompat_Button_ButtonBar_AlertDialog:I = 0x7f1303bf

.field public static final Widget_AppCompat_Button_Colored:I = 0x7f1303c0

.field public static final Widget_AppCompat_Button_Small:I = 0x7f1303c1

.field public static final Widget_AppCompat_CompoundButton_CheckBox:I = 0x7f1303c4

.field public static final Widget_AppCompat_CompoundButton_RadioButton:I = 0x7f1303c5

.field public static final Widget_AppCompat_CompoundButton_Switch:I = 0x7f1303c6

.field public static final Widget_AppCompat_DrawerArrowToggle:I = 0x7f1303c7

.field public static final Widget_AppCompat_DropDownItem_Spinner:I = 0x7f1303c8

.field public static final Widget_AppCompat_EditText:I = 0x7f1303c9

.field public static final Widget_AppCompat_ImageButton:I = 0x7f1303ca

.field public static final Widget_AppCompat_Light_ActionBar:I = 0x7f1303cb

.field public static final Widget_AppCompat_Light_ActionBar_Solid:I = 0x7f1303cc

.field public static final Widget_AppCompat_Light_ActionBar_Solid_Inverse:I = 0x7f1303cd

.field public static final Widget_AppCompat_Light_ActionBar_TabBar:I = 0x7f1303ce

.field public static final Widget_AppCompat_Light_ActionBar_TabBar_Inverse:I = 0x7f1303cf

.field public static final Widget_AppCompat_Light_ActionBar_TabText:I = 0x7f1303d0

.field public static final Widget_AppCompat_Light_ActionBar_TabText_Inverse:I = 0x7f1303d1

.field public static final Widget_AppCompat_Light_ActionBar_TabView:I = 0x7f1303d2

.field public static final Widget_AppCompat_Light_ActionBar_TabView_Inverse:I = 0x7f1303d3

.field public static final Widget_AppCompat_Light_ActionButton:I = 0x7f1303d4

.field public static final Widget_AppCompat_Light_ActionButton_CloseMode:I = 0x7f1303d5

.field public static final Widget_AppCompat_Light_ActionButton_Overflow:I = 0x7f1303d6

.field public static final Widget_AppCompat_Light_ActionMode_Inverse:I = 0x7f1303d7

.field public static final Widget_AppCompat_Light_ActivityChooserView:I = 0x7f1303d8

.field public static final Widget_AppCompat_Light_AutoCompleteTextView:I = 0x7f1303d9

.field public static final Widget_AppCompat_Light_DropDownItem_Spinner:I = 0x7f1303da

.field public static final Widget_AppCompat_Light_ListPopupWindow:I = 0x7f1303db

.field public static final Widget_AppCompat_Light_ListView_DropDown:I = 0x7f1303dc

.field public static final Widget_AppCompat_Light_PopupMenu:I = 0x7f1303dd

.field public static final Widget_AppCompat_Light_PopupMenu_Overflow:I = 0x7f1303de

.field public static final Widget_AppCompat_Light_SearchView:I = 0x7f1303df

.field public static final Widget_AppCompat_Light_Spinner_DropDown_ActionBar:I = 0x7f1303e0

.field public static final Widget_AppCompat_ListMenuView:I = 0x7f1303e1

.field public static final Widget_AppCompat_ListPopupWindow:I = 0x7f1303e2

.field public static final Widget_AppCompat_ListView:I = 0x7f1303e3

.field public static final Widget_AppCompat_ListView_DropDown:I = 0x7f1303e4

.field public static final Widget_AppCompat_ListView_Menu:I = 0x7f1303e5

.field public static final Widget_AppCompat_PopupMenu:I = 0x7f1303e6

.field public static final Widget_AppCompat_PopupMenu_Overflow:I = 0x7f1303e7

.field public static final Widget_AppCompat_PopupWindow:I = 0x7f1303e8

.field public static final Widget_AppCompat_ProgressBar:I = 0x7f1303e9

.field public static final Widget_AppCompat_ProgressBar_Horizontal:I = 0x7f1303ea

.field public static final Widget_AppCompat_RatingBar:I = 0x7f1303eb

.field public static final Widget_AppCompat_RatingBar_Indicator:I = 0x7f1303ec

.field public static final Widget_AppCompat_RatingBar_Small:I = 0x7f1303ed

.field public static final Widget_AppCompat_SearchView:I = 0x7f1303ee

.field public static final Widget_AppCompat_SearchView_ActionBar:I = 0x7f1303ef

.field public static final Widget_AppCompat_SeekBar:I = 0x7f1303f0

.field public static final Widget_AppCompat_SeekBar_Discrete:I = 0x7f1303f1

.field public static final Widget_AppCompat_Spinner:I = 0x7f1303f2

.field public static final Widget_AppCompat_Spinner_DropDown:I = 0x7f1303f3

.field public static final Widget_AppCompat_Spinner_DropDown_ActionBar:I = 0x7f1303f4

.field public static final Widget_AppCompat_Spinner_Underlined:I = 0x7f1303f5

.field public static final Widget_AppCompat_TextView:I = 0x7f1303f6

.field public static final Widget_AppCompat_TextView_SpinnerItem:I = 0x7f1303f7

.field public static final Widget_AppCompat_Toolbar:I = 0x7f1303f8

.field public static final Widget_AppCompat_Toolbar_Button_Navigation:I = 0x7f1303f9

.field public static final Widget_Compat_NotificationActionContainer:I = 0x7f1303fa

.field public static final Widget_Compat_NotificationActionText:I = 0x7f1303fb

.field public static final Widget_Design_AppBarLayout:I = 0x7f1303fc

.field public static final Widget_Design_BottomNavigationView:I = 0x7f1303fd

.field public static final Widget_Design_BottomSheet_Modal:I = 0x7f1303fe

.field public static final Widget_Design_CollapsingToolbar:I = 0x7f1303ff

.field public static final Widget_Design_FloatingActionButton:I = 0x7f130400

.field public static final Widget_Design_NavigationView:I = 0x7f130401

.field public static final Widget_Design_ScrimInsetsFrameLayout:I = 0x7f130402

.field public static final Widget_Design_Snackbar:I = 0x7f130403

.field public static final Widget_Design_TabLayout:I = 0x7f130404

.field public static final Widget_Design_TextInputEditText:I = 0x7f130405

.field public static final Widget_Design_TextInputLayout:I = 0x7f130406

.field public static final Widget_MaterialComponents_ActionBar_Primary:I = 0x7f13048f

.field public static final Widget_MaterialComponents_ActionBar_PrimarySurface:I = 0x7f130490

.field public static final Widget_MaterialComponents_ActionBar_Solid:I = 0x7f130491

.field public static final Widget_MaterialComponents_ActionBar_Surface:I = 0x7f130492

.field public static final Widget_MaterialComponents_AppBarLayout_Primary:I = 0x7f130494

.field public static final Widget_MaterialComponents_AppBarLayout_PrimarySurface:I = 0x7f130495

.field public static final Widget_MaterialComponents_AppBarLayout_Surface:I = 0x7f130496

.field public static final Widget_MaterialComponents_AutoCompleteTextView_FilledBox:I = 0x7f130497

.field public static final Widget_MaterialComponents_AutoCompleteTextView_FilledBox_Dense:I = 0x7f130498

.field public static final Widget_MaterialComponents_AutoCompleteTextView_OutlinedBox:I = 0x7f130499

.field public static final Widget_MaterialComponents_AutoCompleteTextView_OutlinedBox_Dense:I = 0x7f13049a

.field public static final Widget_MaterialComponents_Badge:I = 0x7f13049b

.field public static final Widget_MaterialComponents_BottomAppBar:I = 0x7f13049c

.field public static final Widget_MaterialComponents_BottomAppBar_Colored:I = 0x7f13049d

.field public static final Widget_MaterialComponents_BottomAppBar_PrimarySurface:I = 0x7f13049e

.field public static final Widget_MaterialComponents_BottomNavigationView:I = 0x7f13049f

.field public static final Widget_MaterialComponents_BottomNavigationView_Colored:I = 0x7f1304a0

.field public static final Widget_MaterialComponents_BottomNavigationView_PrimarySurface:I = 0x7f1304a1

.field public static final Widget_MaterialComponents_BottomSheet:I = 0x7f1304a2

.field public static final Widget_MaterialComponents_BottomSheet_Modal:I = 0x7f1304a3

.field public static final Widget_MaterialComponents_Button:I = 0x7f1304a4

.field public static final Widget_MaterialComponents_Button_Icon:I = 0x7f1304a5

.field public static final Widget_MaterialComponents_Button_OutlinedButton:I = 0x7f1304a6

.field public static final Widget_MaterialComponents_Button_OutlinedButton_Icon:I = 0x7f1304a7

.field public static final Widget_MaterialComponents_Button_TextButton:I = 0x7f1304a8

.field public static final Widget_MaterialComponents_Button_TextButton_Dialog:I = 0x7f1304a9

.field public static final Widget_MaterialComponents_Button_TextButton_Dialog_Flush:I = 0x7f1304aa

.field public static final Widget_MaterialComponents_Button_TextButton_Dialog_Icon:I = 0x7f1304ab

.field public static final Widget_MaterialComponents_Button_TextButton_Icon:I = 0x7f1304ac

.field public static final Widget_MaterialComponents_Button_TextButton_Snackbar:I = 0x7f1304ad

.field public static final Widget_MaterialComponents_Button_UnelevatedButton:I = 0x7f1304ae

.field public static final Widget_MaterialComponents_Button_UnelevatedButton_Icon:I = 0x7f1304af

.field public static final Widget_MaterialComponents_CardView:I = 0x7f1304b0

.field public static final Widget_MaterialComponents_CheckedTextView:I = 0x7f1304b1

.field public static final Widget_MaterialComponents_ChipGroup:I = 0x7f1304b6

.field public static final Widget_MaterialComponents_Chip_Action:I = 0x7f1304b2

.field public static final Widget_MaterialComponents_Chip_Choice:I = 0x7f1304b3

.field public static final Widget_MaterialComponents_Chip_Entry:I = 0x7f1304b4

.field public static final Widget_MaterialComponents_Chip_Filter:I = 0x7f1304b5

.field public static final Widget_MaterialComponents_CircularProgressIndicator:I = 0x7f1304b7

.field public static final Widget_MaterialComponents_CircularProgressIndicator_ExtraSmall:I = 0x7f1304b8

.field public static final Widget_MaterialComponents_CircularProgressIndicator_Medium:I = 0x7f1304b9

.field public static final Widget_MaterialComponents_CircularProgressIndicator_Small:I = 0x7f1304ba

.field public static final Widget_MaterialComponents_CollapsingToolbar:I = 0x7f1304bb

.field public static final Widget_MaterialComponents_CompoundButton_CheckBox:I = 0x7f1304bc

.field public static final Widget_MaterialComponents_CompoundButton_RadioButton:I = 0x7f1304bd

.field public static final Widget_MaterialComponents_CompoundButton_Switch:I = 0x7f1304be

.field public static final Widget_MaterialComponents_ExtendedFloatingActionButton:I = 0x7f1304bf

.field public static final Widget_MaterialComponents_ExtendedFloatingActionButton_Icon:I = 0x7f1304c0

.field public static final Widget_MaterialComponents_FloatingActionButton:I = 0x7f1304c1

.field public static final Widget_MaterialComponents_Light_ActionBar_Solid:I = 0x7f1304c2

.field public static final Widget_MaterialComponents_LinearProgressIndicator:I = 0x7f1304c3

.field public static final Widget_MaterialComponents_MaterialButtonToggleGroup:I = 0x7f1304c4

.field public static final Widget_MaterialComponents_MaterialCalendar:I = 0x7f1304c5

.field public static final Widget_MaterialComponents_MaterialCalendar_Day:I = 0x7f1304c6

.field public static final Widget_MaterialComponents_MaterialCalendar_DayOfWeekLabel:I = 0x7f1304ca

.field public static final Widget_MaterialComponents_MaterialCalendar_DayTextView:I = 0x7f1304cb

.field public static final Widget_MaterialComponents_MaterialCalendar_Day_Invalid:I = 0x7f1304c7

.field public static final Widget_MaterialComponents_MaterialCalendar_Day_Selected:I = 0x7f1304c8

.field public static final Widget_MaterialComponents_MaterialCalendar_Day_Today:I = 0x7f1304c9

.field public static final Widget_MaterialComponents_MaterialCalendar_Fullscreen:I = 0x7f1304cc

.field public static final Widget_MaterialComponents_MaterialCalendar_HeaderCancelButton:I = 0x7f1304cd

.field public static final Widget_MaterialComponents_MaterialCalendar_HeaderConfirmButton:I = 0x7f1304ce

.field public static final Widget_MaterialComponents_MaterialCalendar_HeaderDivider:I = 0x7f1304cf

.field public static final Widget_MaterialComponents_MaterialCalendar_HeaderLayout:I = 0x7f1304d0

.field public static final Widget_MaterialComponents_MaterialCalendar_HeaderSelection:I = 0x7f1304d1

.field public static final Widget_MaterialComponents_MaterialCalendar_HeaderSelection_Fullscreen:I = 0x7f1304d2

.field public static final Widget_MaterialComponents_MaterialCalendar_HeaderTitle:I = 0x7f1304d3

.field public static final Widget_MaterialComponents_MaterialCalendar_HeaderToggleButton:I = 0x7f1304d4

.field public static final Widget_MaterialComponents_MaterialCalendar_Item:I = 0x7f1304d5

.field public static final Widget_MaterialComponents_MaterialCalendar_MonthNavigationButton:I = 0x7f1304d6

.field public static final Widget_MaterialComponents_MaterialCalendar_MonthTextView:I = 0x7f1304d7

.field public static final Widget_MaterialComponents_MaterialCalendar_Year:I = 0x7f1304d8

.field public static final Widget_MaterialComponents_MaterialCalendar_YearNavigationButton:I = 0x7f1304db

.field public static final Widget_MaterialComponents_MaterialCalendar_Year_Selected:I = 0x7f1304d9

.field public static final Widget_MaterialComponents_MaterialCalendar_Year_Today:I = 0x7f1304da

.field public static final Widget_MaterialComponents_MaterialDivider:I = 0x7f1304dc

.field public static final Widget_MaterialComponents_NavigationRailView:I = 0x7f1304dd

.field public static final Widget_MaterialComponents_NavigationRailView_Colored:I = 0x7f1304de

.field public static final Widget_MaterialComponents_NavigationRailView_Colored_Compact:I = 0x7f1304df

.field public static final Widget_MaterialComponents_NavigationRailView_Compact:I = 0x7f1304e0

.field public static final Widget_MaterialComponents_NavigationRailView_PrimarySurface:I = 0x7f1304e1

.field public static final Widget_MaterialComponents_NavigationView:I = 0x7f1304e2

.field public static final Widget_MaterialComponents_PopupMenu:I = 0x7f1304e3

.field public static final Widget_MaterialComponents_PopupMenu_ContextMenu:I = 0x7f1304e4

.field public static final Widget_MaterialComponents_PopupMenu_ListPopupWindow:I = 0x7f1304e5

.field public static final Widget_MaterialComponents_PopupMenu_Overflow:I = 0x7f1304e6

.field public static final Widget_MaterialComponents_ProgressIndicator:I = 0x7f1304e7

.field public static final Widget_MaterialComponents_ShapeableImageView:I = 0x7f1304e8

.field public static final Widget_MaterialComponents_Slider:I = 0x7f1304e9

.field public static final Widget_MaterialComponents_Snackbar:I = 0x7f1304ea

.field public static final Widget_MaterialComponents_Snackbar_FullWidth:I = 0x7f1304eb

.field public static final Widget_MaterialComponents_Snackbar_TextView:I = 0x7f1304ec

.field public static final Widget_MaterialComponents_TabLayout:I = 0x7f1304ed

.field public static final Widget_MaterialComponents_TabLayout_Colored:I = 0x7f1304ee

.field public static final Widget_MaterialComponents_TabLayout_PrimarySurface:I = 0x7f1304ef

.field public static final Widget_MaterialComponents_TextInputEditText_FilledBox:I = 0x7f1304f0

.field public static final Widget_MaterialComponents_TextInputEditText_FilledBox_Dense:I = 0x7f1304f1

.field public static final Widget_MaterialComponents_TextInputEditText_OutlinedBox:I = 0x7f1304f2

.field public static final Widget_MaterialComponents_TextInputEditText_OutlinedBox_Dense:I = 0x7f1304f3

.field public static final Widget_MaterialComponents_TextInputLayout_FilledBox:I = 0x7f1304f4

.field public static final Widget_MaterialComponents_TextInputLayout_FilledBox_Dense:I = 0x7f1304f5

.field public static final Widget_MaterialComponents_TextInputLayout_FilledBox_Dense_ExposedDropdownMenu:I = 0x7f1304f6

.field public static final Widget_MaterialComponents_TextInputLayout_FilledBox_ExposedDropdownMenu:I = 0x7f1304f7

.field public static final Widget_MaterialComponents_TextInputLayout_OutlinedBox:I = 0x7f1304f8

.field public static final Widget_MaterialComponents_TextInputLayout_OutlinedBox_Dense:I = 0x7f1304f9

.field public static final Widget_MaterialComponents_TextInputLayout_OutlinedBox_Dense_ExposedDropdownMenu:I = 0x7f1304fa

.field public static final Widget_MaterialComponents_TextInputLayout_OutlinedBox_ExposedDropdownMenu:I = 0x7f1304fb

.field public static final Widget_MaterialComponents_TextView:I = 0x7f1304fc

.field public static final Widget_MaterialComponents_TimePicker:I = 0x7f1304fd

.field public static final Widget_MaterialComponents_TimePicker_Button:I = 0x7f1304fe

.field public static final Widget_MaterialComponents_TimePicker_Clock:I = 0x7f1304ff

.field public static final Widget_MaterialComponents_TimePicker_Display:I = 0x7f130500

.field public static final Widget_MaterialComponents_TimePicker_Display_Divider:I = 0x7f130501

.field public static final Widget_MaterialComponents_TimePicker_Display_HelperText:I = 0x7f130502

.field public static final Widget_MaterialComponents_TimePicker_Display_TextInputEditText:I = 0x7f130503

.field public static final Widget_MaterialComponents_TimePicker_Display_TextInputLayout:I = 0x7f130504

.field public static final Widget_MaterialComponents_TimePicker_ImageButton:I = 0x7f130505

.field public static final Widget_MaterialComponents_TimePicker_ImageButton_ShapeAppearance:I = 0x7f130506

.field public static final Widget_MaterialComponents_Toolbar:I = 0x7f130507

.field public static final Widget_MaterialComponents_Toolbar_Primary:I = 0x7f130508

.field public static final Widget_MaterialComponents_Toolbar_PrimarySurface:I = 0x7f130509

.field public static final Widget_MaterialComponents_Toolbar_Surface:I = 0x7f13050a

.field public static final Widget_MaterialComponents_Tooltip:I = 0x7f13050b

.field public static final Widget_ProgressBar_PullToRefresh:I = 0x7f13050c

.field public static final Widget_Support_CoordinatorLayout:I = 0x7f13050d

.field public static final alert_dialog_bottom_theme:I = 0x7f13050e

.field public static final alert_dialog_theme_translant:I = 0x7f13050f

.field public static final ali_auth_qr_activity_style:I = 0x7f130510

.field public static final aliuser_text_24:I = 0x7f130511

.field public static final aliuser_text_32:I = 0x7f130512

.field public static final aliuser_text_dark_gray_32:I = 0x7f130513

.field public static final aliuser_text_gray_28:I = 0x7f130514

.field public static final aliuser_text_gray_32:I = 0x7f130515

.field public static final aliuser_text_light_gray_24:I = 0x7f130516

.field public static final aliuser_text_white_28:I = 0x7f130517

.field public static final aliuser_text_white_32:I = 0x7f130518

.field public static final aliuser_text_white_42:I = 0x7f130519

.field public static final aliuser_transparent:I = 0x7f13051a

.field public static final alpha_in_out_style:I = 0x7f13051b

.field public static final amap_map3d_AppBaseTheme:I = 0x7f13051c

.field public static final amap_map3d_AppTheme:I = 0x7f13051d

.field public static final animStyle:I = 0x7f13051e

.field public static final battle_agree_label_style:I = 0x7f13051f

.field public static final big_round_style:I = 0x7f130520

.field public static final blue_author_label_style:I = 0x7f130521

.field public static final blue_label_style_73:I = 0x7f130522

.field public static final bottomSheetStyleWrapper:I = 0x7f130523

.field public static final bottom_sheet:I = 0x7f130524

.field public static final bottom_sheet_with_dim:I = 0x7f130525

.field public static final bricks_myDialogTheme:I = 0x7f130526

.field public static final bricks_pop_animation:I = 0x7f130527

.field public static final bricks_translucent_dialog_style:I = 0x7f130528

.field public static final bubble_dialog:I = 0x7f130529

.field public static final button_style_binding:I = 0x7f13052a

.field public static final buy_button_style_small_7_3:I = 0x7f13052b

.field public static final buy_button_style_small_7_3_pioneer:I = 0x7f13052c

.field public static final buy_button_style_small_7_3_pioneer_v2:I = 0x7f13052d

.field public static final buy_button_style_small_8_2:I = 0x7f13052e

.field public static final buy_button_style_small_auto_width:I = 0x7f13052f

.field public static final buy_button_style_small_auto_width_blue_text:I = 0x7f130530

.field public static final buy_button_style_small_auto_width_pioneer:I = 0x7f130531

.field public static final buy_button_style_small_auto_width_pioneer_v2:I = 0x7f130532

.field public static final buy_button_style_small_auto_width_red_text:I = 0x7f130533

.field public static final buy_button_style_small_vip_exchange:I = 0x7f130534

.field public static final cinemaList_address_schedules_intro:I = 0x7f130538

.field public static final collapsedTitleText:I = 0x7f130539

.field public static final combolist_button_style:I = 0x7f13053a

.field public static final combolist_hint_style:I = 0x7f13053b

.field public static final coupon_limit_text_tag:I = 0x7f13053c

.field public static final custom_bottom_sheet:I = 0x7f13053d

.field public static final custom_dialog_style:I = 0x7f13053e

.field public static final custom_dialog_style_nobg:I = 0x7f13053f

.field public static final ddShareStyle:I = 0x7f130540

.field public static final ddShareStylePioneer:I = 0x7f130541

.field public static final dialog_animation:I = 0x7f130543

.field public static final dialog_animation_style:I = 0x7f130544

.field public static final edittextpading10:I = 0x7f130545

.field public static final expandedTitleText:I = 0x7f130546

.field public static final feedback_popwindow_in_out_style:I = 0x7f130547

.field public static final film_detail_block_title:I = 0x7f130548

.field public static final film_detail_item_arrow_style:I = 0x7f130549

.field public static final fullscreenCommon:I = 0x7f13054a

.field public static final fullscreenCommonPioneer:I = 0x7f13054b

.field public static final fullscreen_dialog_theme:I = 0x7f13054c

.field public static final fullscreen_dialogfragment_theme:I = 0x7f13054d

.field public static final gray_label_style_73:I = 0x7f13054e

.field public static final h5_alpha_in_out_style:I = 0x7f13054f

.field public static final h5_noTitleTransBgDialogStyle:I = 0x7f130550

.field public static final lightNoActionBarCustom:I = 0x7f130551

.field public static final lightNoActionBarCustomPioneer:I = 0x7f130552

.field public static final loading_dialog:I = 0x7f130553

.field public static final loading_style:I = 0x7f130554

.field public static final loading_style_transparent:I = 0x7f130555

.field public static final mcard_refresh_button_style_small:I = 0x7f130556

.field public static final mcard_refresh_button_style_small_73:I = 0x7f130557

.field public static final movie_toast:I = 0x7f130558

.field public static final myDialogTheme:I = 0x7f130559

.field public static final myDialogThemeV2:I = 0x7f13055a

.field public static final ordering_item__tv_style:I = 0x7f13055b

.field public static final ordering_item_arrow_style:I = 0x7f13055c

.field public static final ordering_item_price_prefix_tv_style:I = 0x7f13055d

.field public static final ordering_item_price_tv_style:I = 0x7f13055e

.field public static final ordering_item_strong_guide_tv_style:I = 0x7f13055f

.field public static final ordering_item_subtitle_tv_style:I = 0x7f130560

.field public static final ordering_item_weak_guide_tv_style:I = 0x7f130561

.field public static final ordering_module_title_tv_style:I = 0x7f130562

.field public static final ordering_pop_window_reduce_title_style:I = 0x7f130563

.field public static final oscar_payment_result_tv_style1:I = 0x7f130564

.field public static final oscar_payment_result_tv_style2:I = 0x7f130565

.field public static final oscar_payment_result_tv_style3:I = 0x7f130566

.field public static final photo_picker_dialog_style:I = 0x7f130567

.field public static final pic_dialog_fullscreen:I = 0x7f130568

.field public static final pic_kit_fullscreen_dialog_theme:I = 0x7f130569

.field public static final pic_translucent_dialog_style:I = 0x7f13056a

.field public static final pop_animation:I = 0x7f13056d

.field public static final pre_buy_button_style_small_7_3_pioneer:I = 0x7f13056e

.field public static final pre_buy_button_style_small_7_3_pioneer_v2:I = 0x7f13056f

.field public static final pre_buy_button_style_small_auto_width_pioneer:I = 0x7f130570

.field public static final pre_buy_button_style_small_auto_width_pioneer_v2:I = 0x7f130571

.field public static final presale_button_style_small:I = 0x7f130572

.field public static final presale_button_style_small_7_3:I = 0x7f130573

.field public static final presale_button_style_small_8_2:I = 0x7f130574

.field public static final presale_button_style_small_auto_width:I = 0x7f130575

.field public static final red_label_style:I = 0x7f130576

.field public static final red_label_style_common_friend_tag_focused:I = 0x7f130577

.field public static final right_triangle:I = 0x7f130578

.field public static final round_dialog:I = 0x7f130579

.field public static final select_seat_bottom:I = 0x7f13057a

.field public static final select_seat_loading_style:I = 0x7f13057b

.field public static final share_delete_dialog:I = 0x7f13057c

.field public static final share_dialog_theme:I = 0x7f13057d

.field public static final share_popwindow_anim_style:I = 0x7f13057e

.field public static final slide_in_out_bottom_anim:I = 0x7f13057f

.field public static final slide_in_out_bottom_anim_activity:I = 0x7f130580

.field public static final small_round_style:I = 0x7f130581

.field public static final statemanager_button_style:I = 0x7f130582

.field public static final statemanager_hint_style:I = 0x7f130583

.field public static final statemanager_image_style:I = 0x7f130584

.field public static final statemanager_loading_style:I = 0x7f130585

.field public static final statemanager_subhint_style:I = 0x7f130586

.field public static final statemanager_view_style:I = 0x7f130587

.field public static final style_add_address_clear_btn:I = 0x7f130588

.field public static final style_add_address_divider_line:I = 0x7f130589

.field public static final style_add_address_edit_text:I = 0x7f13058a

.field public static final style_add_address_left_static_text:I = 0x7f13058b

.field public static final style_add_address_middle_editable_text:I = 0x7f13058c

.field public static final style_add_address_right_arrow:I = 0x7f13058d

.field public static final style_calendar_week:I = 0x7f13058f

.field public static final style_horizontal_line_mine_page:I = 0x7f130594

.field public static final style_margin_left_horizontal_line:I = 0x7f130595

.field public static final sub_main_button_style:I = 0x7f130596

.field public static final tab_layout_one_text_style:I = 0x7f130597

.field public static final taomai_h5_theme:I = 0x7f130598

.field public static final taomai_h5_theme_DM:I = 0x7f130599

.field public static final taomai_h5_theme_dm_classic:I = 0x7f13059a

.field public static final taomai_h5_theme_dm_pioneer:I = 0x7f13059b

.field public static final theme_activity_translucent:I = 0x7f13059c

.field public static final theme_activity_translucent_pioneer:I = 0x7f13059d

.field public static final ticket_tip_dialog:I = 0x7f13059e

.field public static final tpp_bottomSheetStyleWrapper:I = 0x7f1305d8

.field public static final tpp_custom_bottom_sheet:I = 0x7f1305d9

.field public static final tpp_statemanager_loading_style:I = 0x7f1305da

.field public static final tpp_sub_button_style:I = 0x7f1305db

.field public static final translucent_activity:I = 0x7f1305dc

.field public static final translucent_activity_pioneer:I = 0x7f1305de

.field public static final translucent_dialog_style:I = 0x7f1305df

.field public static final transparent_activity:I = 0x7f1305e0

.field public static final transparent_button_style:I = 0x7f1305e1

.field public static final transparent_dialog_style:I = 0x7f1305e2

.field public static final tv_style_light_black_444:I = 0x7f1305e3

.field public static final uik_imagesavechoice:I = 0x7f1305e5

.field public static final uik_imagesavedialog:I = 0x7f1305e6

.field public static final wanna_2_see_radio_style:I = 0x7f1305e7

.field public static final want_button_style_small:I = 0x7f1305e8

.field public static final want_button_style_small_8_2:I = 0x7f1305e9

.field public static final want_button_style_small_pioneer:I = 0x7f1305ea

.field public static final want_button_style_small_pioneer_v2:I = 0x7f1305eb

.field public static final want_done_button_style_small:I = 0x7f1305ec

.field public static final want_done_button_style_small_pioneer:I = 0x7f1305ed

.field public static final want_see_poster_tips_dialog:I = 0x7f1305ee

.field public static final want_see_tips_dialog:I = 0x7f1305ef

.field public static final wanted_list_style:I = 0x7f1305f0

.field public static final watch_film_button_style_small_7_3:I = 0x7f1305f1

.field public static final watched_white_button_style_small:I = 0x7f1305f2

.field public static final wrap:I = 0x7f1305f3


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
