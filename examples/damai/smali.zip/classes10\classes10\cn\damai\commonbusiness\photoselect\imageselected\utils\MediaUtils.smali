.class public Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon; = null

.field private static a:Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils; = null

.field public static b:I = 0x3e8

.field public static c:I = 0x0

.field public static d:I = 0x5

.field public static e:I = 0x4


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const/16 v0, 0x3e8

    mul-int/lit16 v1, v0, 0x1f4

    mul-int/lit16 v1, v1, 0x3e8

    .line 1
    sput v1, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->c:I

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic a(Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;J)Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->h(J)Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;

    move-result-object p0

    return-object p0
.end method

.method static synthetic b(Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;J)Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->g(J)Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;

    move-result-object p0

    return-object p0
.end method

.method public static c()Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;

    return-object v0

    .line 1
    :cond_14
    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->a:Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;

    if-nez v0, :cond_1f

    .line 2
    new-instance v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;

    invoke-direct {v0}, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;-><init>()V

    sput-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->a:Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;

    .line 3
    :cond_1f
    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->a:Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;

    return-object v0
.end method

.method private g(J)Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;
    .registers 14

    const-string v0, "M"

    const-string v1, "."

    sget-object v2, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v3, "5"

    invoke-static {v2, v3}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v4

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v4, :cond_22

    const/4 v0, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    aput-object p0, v0, v6

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    aput-object p1, v0, v5

    invoke-interface {v2, v3, v0}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;

    return-object p1

    .line 1
    :cond_22
    new-instance v2, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;

    invoke-direct {v2, p0}, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;-><init>(Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;)V

    .line 2
    sget v3, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->b:I

    int-to-long v7, v3

    cmp-long v4, p1, v7

    if-gez v4, :cond_45

    .line 3
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string p1, "B"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iput-object p1, v2, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;->b:Ljava/lang/String;

    .line 4
    iput-boolean v6, v2, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;->a:Z

    goto/16 :goto_ff

    :cond_45
    int-to-long v7, v3

    int-to-long v9, v3

    mul-long v7, v7, v9

    cmp-long v4, p1, v7

    if-gez v4, :cond_66

    long-to-int p2, p1

    .line 5
    div-int/2addr p2, v3

    .line 6
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, "K"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iput-object p1, v2, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;->b:Ljava/lang/String;

    .line 7
    iput-boolean v6, v2, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;->a:Z

    goto/16 :goto_ff

    :cond_66
    long-to-int v4, p1

    .line 8
    div-int/2addr v4, v3

    div-int/2addr v4, v3

    mul-int v7, v4, v3

    mul-int v7, v7, v3

    int-to-long v7, v7

    sub-long/2addr p1, v7

    long-to-int p2, p1

    .line 9
    div-int/2addr p2, v3

    .line 10
    invoke-static {p2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/16 v3, 0x9

    if-ge p2, v3, :cond_8b

    .line 11
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "00"

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    goto :goto_a0

    :cond_8b
    const/16 v3, 0x63

    if-ge p2, v3, :cond_a0

    .line 12
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "0"

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 13
    :cond_a0
    :goto_a0
    :try_start_a0
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v3

    float-to-double v7, v3

    .line 14
    invoke-static {v7, v8}, Ljava/math/BigDecimal;->valueOf(D)Ljava/math/BigDecimal;

    move-result-object v3

    sget-object v7, Ljava/math/RoundingMode;->HALF_UP:Ljava/math/RoundingMode;

    invoke-virtual {v3, v5, v7}, Ljava/math/BigDecimal;->setScale(ILjava/math/RoundingMode;)Ljava/math/BigDecimal;

    move-result-object v3

    invoke-virtual {v3}, Ljava/math/BigDecimal;->doubleValue()D

    move-result-wide v7

    .line 15
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v7, v8}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    iput-object v3, v2, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;->b:Ljava/lang/String;
    :try_end_d6
    .catch Ljava/lang/Exception; {:try_start_a0 .. :try_end_d6} :catch_d7

    goto :goto_ee

    .line 16
    :catch_d7
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iput-object p1, v2, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;->b:Ljava/lang/String;

    .line 17
    :goto_ee
    sget p1, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->b:I

    mul-int v4, v4, p1

    mul-int v4, v4, p1

    mul-int p2, p2, p1

    add-int/2addr v4, p2

    sget p1, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->c:I

    if-le v4, p1, :cond_fc

    goto :goto_fd

    :cond_fc
    const/4 v5, 0x0

    :goto_fd
    iput-boolean v5, v2, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;->a:Z

    :goto_ff
    return-object v2
.end method

.method private h(J)Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;
    .registers 14

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v4

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;

    return-object p1

    .line 1
    :cond_1e
    new-instance v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;

    invoke-direct {v0, p0}, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;-><init>(Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;)V

    long-to-int v1, p1

    .line 2
    div-int/lit16 v1, v1, 0x3e8

    div-int/lit8 v1, v1, 0x3c

    const-string v2, "0"

    const-wide/16 v5, 0xa

    const-wide v7, 0x408f400000000000L    # 1000.0

    if-lez v1, :cond_6f

    mul-int/lit8 v9, v1, 0x3c

    mul-int/lit16 v9, v9, 0x3e8

    int-to-long v9, v9

    sub-long/2addr p1, v9

    long-to-double p1, p1

    div-double/2addr p1, v7

    .line 3
    invoke-static {p1, p2}, Ljava/lang/Math;->floor(D)D

    move-result-wide p1

    double-to-int p1, p1

    int-to-long p1, p1

    .line 4
    invoke-static {p1, p2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v7

    cmp-long v8, p1, v5

    if-gez v8, :cond_58

    .line 5
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    .line 6
    :cond_58
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v5, ":"

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 7
    iput-object v2, v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;->b:Ljava/lang/String;

    goto :goto_a5

    :cond_6f
    long-to-double p1, p1

    div-double/2addr p1, v7

    .line 8
    invoke-static {p1, p2}, Ljava/lang/Math;->floor(D)D

    move-result-wide p1

    double-to-int p1, p1

    int-to-long p1, p1

    .line 9
    invoke-static {p1, p2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v7

    cmp-long v8, p1, v5

    if-gez v8, :cond_92

    .line 10
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1, p2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    .line 11
    :cond_92
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "0:"

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 12
    iput-object v2, v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;->b:Ljava/lang/String;

    :goto_a5
    mul-int/lit8 v1, v1, 0x3c

    int-to-long v1, v1

    add-long/2addr v1, p1

    .line 13
    sget p1, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->d:I

    int-to-long p1, p1

    cmp-long v5, v1, p1

    if-gez v5, :cond_b1

    goto :goto_b2

    :cond_b1
    const/4 v3, 0x0

    :goto_b2
    iput-boolean v3, v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;->a:Z

    return-object v0
.end method


# virtual methods
.method public d(Ljava/lang/String;)Landroid/graphics/Bitmap;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/graphics/Bitmap;

    return-object p1

    :cond_1a
    const/4 v0, 0x0

    .line 1
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0xe

    if-lt v1, v2, :cond_49

    .line 2
    new-instance v1, Landroid/media/MediaMetadataRetriever;

    invoke-direct {v1}, Landroid/media/MediaMetadataRetriever;-><init>()V

    .line 3
    :try_start_26
    invoke-virtual {v1, p1}, Landroid/media/MediaMetadataRetriever;->setDataSource(Ljava/lang/String;)V

    .line 4
    invoke-virtual {v1}, Landroid/media/MediaMetadataRetriever;->getFrameAtTime()Landroid/graphics/Bitmap;

    move-result-object v0
    :try_end_2d
    .catch Ljava/lang/IllegalArgumentException; {:try_start_26 .. :try_end_2d} :catch_38
    .catchall {:try_start_26 .. :try_end_2d} :catchall_36

    .line 5
    :try_start_2d
    invoke-virtual {v1}, Landroid/media/MediaMetadataRetriever;->release()V
    :try_end_30
    .catch Ljava/io/IOException; {:try_start_2d .. :try_end_30} :catch_31

    goto :goto_49

    :catch_31
    move-exception p1

    .line 6
    invoke-virtual {p1}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_49

    :catchall_36
    move-exception p1

    goto :goto_40

    :catch_38
    move-exception p1

    .line 7
    :try_start_39
    invoke-virtual {p1}, Ljava/lang/IllegalArgumentException;->printStackTrace()V
    :try_end_3c
    .catchall {:try_start_39 .. :try_end_3c} :catchall_36

    .line 8
    :try_start_3c
    invoke-virtual {v1}, Landroid/media/MediaMetadataRetriever;->release()V
    :try_end_3f
    .catch Ljava/io/IOException; {:try_start_3c .. :try_end_3f} :catch_31

    goto :goto_49

    :goto_40
    :try_start_40
    invoke-virtual {v1}, Landroid/media/MediaMetadataRetriever;->release()V
    :try_end_43
    .catch Ljava/io/IOException; {:try_start_40 .. :try_end_43} :catch_44

    goto :goto_48

    :catch_44
    move-exception v0

    .line 9
    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    .line 10
    :goto_48
    throw p1

    :cond_49
    :goto_49
    return-object v0
.end method

.method public e(Ljava/lang/String;III)Landroid/graphics/Bitmap;
    .registers 10

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x2

    if-eqz v2, :cond_2f

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    const/4 v4, 0x1

    aput-object p1, v2, v4

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/graphics/Bitmap;

    return-object p1

    :cond_2f
    const/4 v0, 0x0

    .line 1
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_48

    .line 2
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x8

    if-lt v1, v2, :cond_48

    .line 3
    invoke-static {p1, p2}, Landroid/media/ThumbnailUtils;->createVideoThumbnail(Ljava/lang/String;I)Landroid/graphics/Bitmap;

    move-result-object v0

    if-lez p3, :cond_48

    if-lez p4, :cond_48

    .line 4
    invoke-static {v0, p3, p4, v3}, Landroid/media/ThumbnailUtils;->extractThumbnail(Landroid/graphics/Bitmap;III)Landroid/graphics/Bitmap;

    move-result-object v0

    :cond_48
    return-object v0
.end method

.method public f(Landroid/content/Context;Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$DataCallback;)Ljava/util/ArrayList;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$DataCallback;",
            ")",
            "Ljava/util/ArrayList<",
            "Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1d

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/ArrayList;

    return-object p1

    :cond_1d
    if-nez p1, :cond_21

    const/4 p1, 0x0

    return-object p1

    .line 1
    :cond_21
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 2
    new-instance v1, Ljava/lang/Thread;

    new-instance v2, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$1;

    invoke-direct {v2, p0, p1, v0, p2}, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$1;-><init>(Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;Landroid/content/Context;Ljava/util/ArrayList;Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$DataCallback;)V

    invoke-direct {v1, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 3
    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    return-object v0
.end method
