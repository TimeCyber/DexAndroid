.class public interface abstract Lcn/damai/commonbusiness/photoselect/photoview/OnScaleChangedListener;
.super Ljava/lang/Object;
.source "Taobao"


# virtual methods
.method public abstract onScaleChange(FFF)V
.end method
