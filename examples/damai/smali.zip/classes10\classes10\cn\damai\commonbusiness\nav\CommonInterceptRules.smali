.class public Lcn/damai/commonbusiness/nav/CommonInterceptRules;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/nav/CommonInterceptRules$Param;,
        Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private routerParamList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcn/damai/commonbusiness/nav/CommonInterceptRules;->routerParamList:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public getRules()Ljava/util/List;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    return-object v0

    .line 1
    :cond_17
    new-instance v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;

    invoke-direct {v0}, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;-><init>()V

    const-string v2, "https://m.damai.cn/damai/activity/discover/themepagecms.html"

    .line 2
    iput-object v2, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->keyUri:Ljava/lang/String;

    const-string v2, "themeId"

    .line 3
    iput-object v2, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->sourceParamKey:Ljava/lang/String;

    .line 4
    iput-object v2, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->targetParamKey:Ljava/lang/String;

    const-string v3, "discover_circle_activity"

    .line 5
    iput-object v3, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->targetUri:Ljava/lang/String;

    .line 6
    iget-object v4, p0, Lcn/damai/commonbusiness/nav/CommonInterceptRules;->routerParamList:Ljava/util/List;

    invoke-interface {v4, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 7
    new-instance v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;

    invoke-direct {v0}, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;-><init>()V

    const-string v4, "https://m.damai.cn/shows/themepagecms.html"

    .line 8
    iput-object v4, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->keyUri:Ljava/lang/String;

    .line 9
    iput-object v2, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->sourceParamKey:Ljava/lang/String;

    .line 10
    iput-object v2, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->targetParamKey:Ljava/lang/String;

    .line 11
    iput-object v3, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->targetUri:Ljava/lang/String;

    .line 12
    iget-object v2, p0, Lcn/damai/commonbusiness/nav/CommonInterceptRules;->routerParamList:Ljava/util/List;

    invoke-interface {v2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 13
    new-instance v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;

    invoke-direct {v0}, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;-><init>()V

    const-string v2, "https://m.damai.cn/app/dmfe/show/pages/my/index.html"

    .line 14
    iput-object v2, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->keyUri:Ljava/lang/String;

    const-string v2, "hid"

    .line 15
    iput-object v2, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->sourceParamKey:Ljava/lang/String;

    const-string v2, "userId"

    .line 16
    iput-object v2, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->targetParamKey:Ljava/lang/String;

    .line 17
    sget-object v2, Lcn/damai/commonbusiness/nav/DMPage;->f0:Ljava/lang/String;

    iput-object v2, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->targetUri:Ljava/lang/String;

    .line 18
    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    const-string v3, "userType"

    .line 19
    invoke-virtual {v2, v3, v1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 20
    iput-object v2, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->extraBundle:Landroid/os/Bundle;

    .line 21
    iget-object v1, p0, Lcn/damai/commonbusiness/nav/CommonInterceptRules;->routerParamList:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 22
    new-instance v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;

    invoke-direct {v0}, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;-><init>()V

    const-string v1, "https://m.damai.cn/damai/activity/waitcomment/index.html"

    .line 23
    iput-object v1, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->keyUri:Ljava/lang/String;

    const-string v1, "mycomment"

    .line 24
    iput-object v1, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->targetUri:Ljava/lang/String;

    .line 25
    iget-object v1, p0, Lcn/damai/commonbusiness/nav/CommonInterceptRules;->routerParamList:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 26
    new-instance v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;

    invoke-direct {v0}, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;-><init>()V

    const-string v1, "https://m.damai.cn/damai/activity/discover/detail.html"

    .line 27
    iput-object v1, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->keyUri:Ljava/lang/String;

    const-string v1, "discover_content_detail"

    .line 28
    iput-object v1, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->targetUri:Ljava/lang/String;

    const-string v2, "contentId"

    .line 29
    iput-object v2, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->sourceParamKey:Ljava/lang/String;

    .line 30
    iput-object v2, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->targetParamKey:Ljava/lang/String;

    .line 31
    iget-object v3, p0, Lcn/damai/commonbusiness/nav/CommonInterceptRules;->routerParamList:Ljava/util/List;

    invoke-interface {v3, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 32
    new-instance v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;

    invoke-direct {v0}, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;-><init>()V

    const-string v3, "https://m.damai.cn/shows/pages/content-detail.html"

    .line 33
    iput-object v3, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->keyUri:Ljava/lang/String;

    .line 34
    iput-object v1, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->targetUri:Ljava/lang/String;

    .line 35
    iput-object v2, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->sourceParamKey:Ljava/lang/String;

    .line 36
    iput-object v2, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->targetParamKey:Ljava/lang/String;

    .line 37
    iget-object v1, p0, Lcn/damai/commonbusiness/nav/CommonInterceptRules;->routerParamList:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 38
    new-instance v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;

    invoke-direct {v0}, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;-><init>()V

    const-string v1, "https://m.damai.cn/shows/pages/jbs/store-detail.html"

    .line 39
    iput-object v1, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->keyUri:Ljava/lang/String;

    const-string v1, "script_shop_detail"

    .line 40
    iput-object v1, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->targetUri:Ljava/lang/String;

    const-string v1, "storeId"

    .line 41
    iput-object v1, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->sourceParamKey:Ljava/lang/String;

    .line 42
    iput-object v1, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->targetParamKey:Ljava/lang/String;

    .line 43
    iget-object v1, p0, Lcn/damai/commonbusiness/nav/CommonInterceptRules;->routerParamList:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 44
    new-instance v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;

    invoke-direct {v0}, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;-><init>()V

    const-string v1, "https://m.damai.cn/shows/pages/jbs/coupon-detail.html"

    .line 45
    iput-object v1, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->keyUri:Ljava/lang/String;

    const-string v1, "script_coupon_detail"

    .line 46
    iput-object v1, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->targetUri:Ljava/lang/String;

    const-string v1, "couponId"

    .line 47
    iput-object v1, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->sourceParamKey:Ljava/lang/String;

    .line 48
    iput-object v1, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->targetParamKey:Ljava/lang/String;

    .line 49
    iget-object v1, p0, Lcn/damai/commonbusiness/nav/CommonInterceptRules;->routerParamList:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 50
    new-instance v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;

    invoke-direct {v0}, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;-><init>()V

    const-string v1, "https://m.damai.cn/damai/detail/item.html"

    .line 51
    iput-object v1, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->keyUri:Ljava/lang/String;

    .line 52
    sget-object v1, Lcn/damai/commonbusiness/nav/DMPage;->f:Ljava/lang/String;

    iput-object v1, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->targetUri:Ljava/lang/String;

    const-string v1, "itemId"

    .line 53
    iput-object v1, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->sourceParamKey:Ljava/lang/String;

    const-string v2, "ProjectID"

    .line 54
    iput-object v2, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->targetParamKey:Ljava/lang/String;

    .line 55
    iget-object v3, p0, Lcn/damai/commonbusiness/nav/CommonInterceptRules;->routerParamList:Ljava/util/List;

    invoke-interface {v3, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 56
    new-instance v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;

    invoke-direct {v0}, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;-><init>()V

    const-string v3, "https://m.damai.cn/shows/item.html"

    .line 57
    iput-object v3, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->keyUri:Ljava/lang/String;

    .line 58
    sget-object v3, Lcn/damai/commonbusiness/nav/DMPage;->f:Ljava/lang/String;

    iput-object v3, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->targetUri:Ljava/lang/String;

    .line 59
    iput-object v1, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->sourceParamKey:Ljava/lang/String;

    .line 60
    iput-object v2, v0, Lcn/damai/commonbusiness/nav/CommonInterceptRules$RouterParam;->targetParamKey:Ljava/lang/String;

    .line 61
    iget-object v1, p0, Lcn/damai/commonbusiness/nav/CommonInterceptRules;->routerParamList:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 62
    iget-object v0, p0, Lcn/damai/commonbusiness/nav/CommonInterceptRules;->routerParamList:Ljava/util/List;

    return-object v0
.end method
