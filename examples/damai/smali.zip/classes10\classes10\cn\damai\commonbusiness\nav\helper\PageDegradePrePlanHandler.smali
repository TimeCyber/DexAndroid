.class public final Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation runtime Lkotlin/Metadata;
    bv = {}
    d1 = {
        "\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0004\u0008\u00c6\u0002\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0006\u0010\u0007J\u000e\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002\u00a8\u0006\u0008"
    }
    d2 = {
        "Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler;",
        "",
        "Ltb/yi;",
        "interceptor",
        "",
        "a",
        "<init>",
        "()V",
        "commonbusiness_release"
    }
    k = 0x1
    mv = {
        0x1,
        0x7,
        0x1
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

.field public static final INSTANCE:Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler;

    invoke-direct {v0}, Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler;-><init>()V

    sput-object v0, Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler;->INSTANCE:Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Ltb/yi;)V
    .registers 6
    .param p1    # Ltb/yi;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    sget-object v0, Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_17
    const-string v0, "interceptor"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-static {}, Ltb/nc0;->f()Ltb/k20;

    move-result-object v0

    const-string v1, "pre_plan_dg_film_chain"

    const-string v2, "on"

    invoke-virtual {v0, v1, v2, v3}, Ltb/k20;->isExpected(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    .line 2
    invoke-static {}, Ltb/nc0;->j()Ltb/yu2;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "filmChainDG="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "PageDegradePrePlanHandler"

    invoke-virtual {v1, v3, v2}, Ltb/yu2;->d(Ljava/lang/String;Ljava/lang/String;)V

    if-eqz v0, :cond_76

    .line 3
    sget-object v0, Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler$updatePrePlanConfig$1;->INSTANCE:Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler$updatePrePlanConfig$1;

    invoke-virtual {p1, v0}, Ltb/yi;->n(Lkotlin/jvm/functions/Function1;)V

    .line 4
    sget-object v0, Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler$updatePrePlanConfig$2;->INSTANCE:Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler$updatePrePlanConfig$2;

    invoke-virtual {p1, v0}, Ltb/yi;->n(Lkotlin/jvm/functions/Function1;)V

    .line 5
    sget-object v0, Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler$updatePrePlanConfig$3;->INSTANCE:Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler$updatePrePlanConfig$3;

    invoke-virtual {p1, v0}, Ltb/yi;->n(Lkotlin/jvm/functions/Function1;)V

    .line 6
    sget-object v0, Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler$updatePrePlanConfig$4;->INSTANCE:Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler$updatePrePlanConfig$4;

    invoke-virtual {p1, v0}, Ltb/yi;->n(Lkotlin/jvm/functions/Function1;)V

    .line 7
    sget-object v0, Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler$updatePrePlanConfig$5;->INSTANCE:Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler$updatePrePlanConfig$5;

    invoke-virtual {p1, v0}, Ltb/yi;->n(Lkotlin/jvm/functions/Function1;)V

    .line 8
    sget-object v0, Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler$updatePrePlanConfig$6;->INSTANCE:Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler$updatePrePlanConfig$6;

    invoke-virtual {p1, v0}, Ltb/yi;->n(Lkotlin/jvm/functions/Function1;)V

    .line 9
    sget-object v0, Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler$updatePrePlanConfig$7;->INSTANCE:Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler$updatePrePlanConfig$7;

    invoke-virtual {p1, v0}, Ltb/yi;->n(Lkotlin/jvm/functions/Function1;)V

    .line 10
    sget-object v0, Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler$updatePrePlanConfig$8;->INSTANCE:Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler$updatePrePlanConfig$8;

    invoke-virtual {p1, v0}, Ltb/yi;->n(Lkotlin/jvm/functions/Function1;)V

    .line 11
    sget-object v0, Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler$updatePrePlanConfig$9;->INSTANCE:Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler$updatePrePlanConfig$9;

    invoke-virtual {p1, v0}, Ltb/yi;->n(Lkotlin/jvm/functions/Function1;)V

    .line 12
    sget-object v0, Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler$updatePrePlanConfig$10;->INSTANCE:Lcn/damai/commonbusiness/nav/helper/PageDegradePrePlanHandler$updatePrePlanConfig$10;

    invoke-virtual {p1, v0}, Ltb/yi;->n(Lkotlin/jvm/functions/Function1;)V

    :cond_76
    return-void
.end method
