.class public Lcn/damai/commonbusiness/coupondialog/net/CouponListResponse;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/coupondialog/net/CouponListResponse$Coupon;,
        Lcn/damai/commonbusiness/coupondialog/net/CouponListResponse$ContentList;,
        Lcn/damai/commonbusiness/coupondialog/net/CouponListResponse$Model;
    }
.end annotation


# instance fields
.field public model:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/coupondialog/net/CouponListResponse$Model;",
            ">;"
        }
    .end annotation
.end field

.field public success:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
