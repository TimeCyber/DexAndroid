.class public Lcn/damai/commonbusiness/config/SeatSwitch;
.super Ljava/lang/Object;
.source "Taobao"


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon; = null

.field public static final BY_NEW:I = 0x1

.field public static final BY_OLD:I = 0x2

.field public static final BY_ORANGE:I = 0x0

.field public static final SEAT_QILIN_SEAT_REFACTOR_KEY:Ljava/lang/String; = "match_user_code_suffix"

.field public static final SEAT_QILIN_SEAT_REFACTOR_SWITCH:Ljava/lang/String; = "damai_qilin_seat_refactor_switch"
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final SEAT_STATUS_COMPRESS_API_KEY:Ljava/lang/String; = "is_use_seat_status_compress_api"

.field public static final SWITCH_MTOP_API_PRELOAD:Ljava/lang/String; = "damai_mtop_api_preload_switch"

.field public static final SWITCH_MTOP_API_PRELOAD_KEY:Ljava/lang/String; = "mtop_api_preload_close_group"

.field public static final SWITCH_SEAT_ACCESSIBILITY:Ljava/lang/String; = "damai_seat_accessibility"

.field public static final SWITCH_SEAT_ACCESSIBILITY_KEY:Ljava/lang/String; = "enable_seat_accessibility"

.field public static final SWITCH_SEAT_STATUS_COMPRESS_API:Ljava/lang/String; = "damai_seat_status_compress_switch"
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field private static a:I

.field private static b:Z


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const/4 v0, 0x0

    :try_start_1
    const-string v1, "sp_use_seat_page"

    .line 1
    invoke-static {v1}, Ltb/uy0;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 2
    invoke-static {v1}, Ltb/mw5;->h(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    .line 3
    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    sput v1, Lcn/damai/commonbusiness/config/SeatSwitch;->a:I

    goto :goto_1b

    .line 4
    :cond_14
    sput v0, Lcn/damai/commonbusiness/config/SeatSwitch;->a:I
    :try_end_16
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_16} :catch_17

    goto :goto_1b

    :catch_17
    move-exception v1

    .line 5
    invoke-virtual {v1}, Ljava/lang/Exception;->printStackTrace()V

    .line 6
    :goto_1b
    sput-boolean v0, Lcn/damai/commonbusiness/config/SeatSwitch;->b:Z

    return-void
.end method

.method public static a()Z
    .registers 4

    sget-object v0, Lcn/damai/commonbusiness/config/SeatSwitch;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "7"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_18

    new-array v2, v3, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    return v0

    .line 1
    :cond_18
    :try_start_18
    invoke-static {}, Lcn/damai/common/OrangeConfigCenter;->c()Lcn/damai/common/OrangeConfigCenter;

    move-result-object v0

    const-string v1, "damai_seat_accessibility"

    const-string v2, "enable_seat_accessibility"

    invoke-virtual {v0, v1, v2, v3}, Lcn/damai/common/OrangeConfigCenter;->a(Ljava/lang/String;Ljava/lang/String;I)I

    move-result v0
    :try_end_24
    .catch Ljava/lang/Exception; {:try_start_18 .. :try_end_24} :catch_29

    const/4 v1, 0x1

    if-ne v0, v1, :cond_2d

    const/4 v3, 0x1

    goto :goto_2d

    :catch_29
    move-exception v0

    .line 2
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :cond_2d
    :goto_2d
    return v3
.end method

.method public static b(Ljava/lang/String;)Z
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/config/SeatSwitch;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_1b

    new-array v2, v4, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0

    .line 1
    :cond_1b
    :try_start_1b
    invoke-static {}, Lcn/damai/common/OrangeConfigCenter;->c()Lcn/damai/common/OrangeConfigCenter;

    move-result-object v0

    const-string v1, "damai_mtop_api_preload_switch"

    const-string v2, "mtop_api_preload_close_group"

    const-string v5, ""

    invoke-virtual {v0, v1, v2, v5}, Lcn/damai/common/OrangeConfigCenter;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 2
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_46

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_46

    const-string v1, ","

    .line 3
    invoke-virtual {v0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    .line 4
    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    .line 5
    invoke-interface {v1, p0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v1
    :try_end_43
    .catch Ljava/lang/Exception; {:try_start_1b .. :try_end_43} :catch_7b

    if-eqz v1, :cond_46

    goto :goto_47

    :cond_46
    const/4 v3, 0x1

    .line 6
    :goto_47
    :try_start_47
    invoke-static {}, Ltb/nc0;->b()Ltb/oa;

    move-result-object v1

    invoke-virtual {v1}, Ltb/oa;->debugable()Z

    move-result v1

    if-eqz v1, :cond_80

    const-string v1, "ApiPreload"

    .line 7
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "orange config="

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " groupType="

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " isSupport="

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Ltb/av2;->c(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_77
    .catch Ljava/lang/Exception; {:try_start_47 .. :try_end_77} :catch_78

    goto :goto_80

    :catch_78
    move-exception p0

    move v4, v3

    goto :goto_7c

    :catch_7b
    move-exception p0

    .line 8
    :goto_7c
    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    move v3, v4

    :cond_80
    :goto_80
    return v3
.end method

.method public static c(Z)V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/config/SeatSwitch;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_18

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_18
    const-string v0, "damai_seat_accessibility"

    const-string v1, "damai_mtop_api_preload_switch"

    if-eqz p0, :cond_3d

    .line 1
    :try_start_1e
    new-instance v2, Lcn/damai/commonbusiness/config/SeatSwitch$1;

    invoke-direct {v2}, Lcn/damai/commonbusiness/config/SeatSwitch$1;-><init>()V

    .line 2
    invoke-static {}, Ltb/nc0;->b()Ltb/oa;

    move-result-object v3

    invoke-virtual {v3}, Ltb/oa;->debugable()Z

    move-result v3

    .line 3
    invoke-static {v2, v3}, Ltb/vq;->f(Lcn/damai/tool2/bufferkit/BufferSwitch;Z)V

    .line 4
    invoke-static {}, Lcn/damai/common/OrangeConfigCenter;->c()Lcn/damai/common/OrangeConfigCenter;

    move-result-object v2

    invoke-virtual {v2, v1}, Lcn/damai/common/OrangeConfigCenter;->e(Ljava/lang/String;)V

    .line 5
    invoke-static {}, Lcn/damai/common/OrangeConfigCenter;->c()Lcn/damai/common/OrangeConfigCenter;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcn/damai/common/OrangeConfigCenter;->e(Ljava/lang/String;)V

    goto :goto_4b

    .line 6
    :cond_3d
    invoke-static {}, Lcn/damai/common/OrangeConfigCenter;->c()Lcn/damai/common/OrangeConfigCenter;

    move-result-object v2

    invoke-virtual {v2, v1}, Lcn/damai/common/OrangeConfigCenter;->g(Ljava/lang/String;)V

    .line 7
    invoke-static {}, Lcn/damai/common/OrangeConfigCenter;->c()Lcn/damai/common/OrangeConfigCenter;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcn/damai/common/OrangeConfigCenter;->g(Ljava/lang/String;)V

    .line 8
    :goto_4b
    invoke-static {p0}, Ltb/kh5;->g(Z)V
    :try_end_4e
    .catch Ljava/lang/Exception; {:try_start_1e .. :try_end_4e} :catch_4f

    goto :goto_53

    :catch_4f
    move-exception p0

    .line 9
    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    :goto_53
    return-void
.end method
