.class public interface abstract Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$ImageLoadListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "ImageLoadListener"
.end annotation


# virtual methods
.method public abstract onHappen(Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$d;)Z
.end method
