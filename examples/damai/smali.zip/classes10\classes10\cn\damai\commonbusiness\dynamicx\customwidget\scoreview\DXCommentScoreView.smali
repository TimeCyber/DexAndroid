.class public Lcn/damai/commonbusiness/dynamicx/customwidget/scoreview/DXCommentScoreView;
.super Landroid/widget/LinearLayout;
.source "Taobao"


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private mDigitTextView:Lcn/damai/uikit/number/DMDigitTextView;

.field private mScoreStarView:Lcn/damai/uikit/view/ScoreStarViewV2;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 2
    invoke-direct {p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scoreview/DXCommentScoreView;->initView()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 3
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .line 3
    invoke-direct {p0, p1, p2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 4
    invoke-direct {p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scoreview/DXCommentScoreView;->initView()V

    return-void
.end method

.method private initView()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scoreview/DXCommentScoreView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    invoke-virtual {p0, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v0, 0x50

    .line 2
    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 3
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 4
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    sget v1, Lcom/alibaba/pictures/picturesbiz/R$layout;->common_score_star_dx:I

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    .line 5
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getContext()Landroid/content/Context;

    move-result-object v1

    const/high16 v2, 0x42a00000    # 80.0f

    invoke-static {v1, v2}, Ltb/f95;->a(Landroid/content/Context;F)I

    move-result v1

    .line 6
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v3, -0x1

    invoke-direct {v2, v3, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 7
    sget v1, Lcom/alibaba/pictures/picturesbiz/R$id;->score_text:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Lcn/damai/uikit/number/DMDigitTextView;

    iput-object v1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scoreview/DXCommentScoreView;->mDigitTextView:Lcn/damai/uikit/number/DMDigitTextView;

    .line 8
    sget v1, Lcom/alibaba/pictures/picturesbiz/R$id;->score_icon:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Lcn/damai/uikit/view/ScoreStarViewV2;

    iput-object v1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scoreview/DXCommentScoreView;->mScoreStarView:Lcn/damai/uikit/view/ScoreStarViewV2;

    .line 9
    invoke-virtual {p0, v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method


# virtual methods
.method public updateView(D)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scoreview/DXCommentScoreView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1, p2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scoreview/DXCommentScoreView;->mDigitTextView:Lcn/damai/uikit/number/DMDigitTextView;

    invoke-static {p1, p2}, Ljava/lang/String;->valueOf(D)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scoreview/DXCommentScoreView;->mScoreStarView:Lcn/damai/uikit/view/ScoreStarViewV2;

    invoke-virtual {v0, p1, p2}, Lcom/alibaba/pictures/bricks/view/ScoreStarViewV2;->updateView(D)V

    return-void
.end method
