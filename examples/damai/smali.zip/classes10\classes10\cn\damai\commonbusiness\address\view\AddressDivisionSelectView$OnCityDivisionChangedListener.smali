.class public interface abstract Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnCityDivisionChangedListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnCityDivisionChangedListener"
.end annotation


# virtual methods
.method public abstract onCityDivisionChanged(Lcn/damai/commonbusiness/address/bean/DivisionBean;)V
.end method
