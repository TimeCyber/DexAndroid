.class public interface abstract Lcn/damai/commonbusiness/dynamicx/customwidget/event/DXDmOnClickedEvent$OnTemplateViewClickListener;
.super Ljava/lang/Object;
.source "Taobao"


# virtual methods
.method public abstract onClick(Ljava/lang/String;[Ljava/lang/Object;)V
.end method
