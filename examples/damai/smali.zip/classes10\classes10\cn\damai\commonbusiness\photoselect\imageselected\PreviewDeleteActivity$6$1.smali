.class public Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$6$1;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$6;->onAnimationEnd(Landroid/animation/Animator;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic this$1:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$6;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$6;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$6$1;->this$1:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$6;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$6$1;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$6$1;->this$1:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$6;

    iget-object v0, v0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$6;->a:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;

    invoke-static {v0, v3}, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;->access$700(Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;Z)V

    return-void
.end method
