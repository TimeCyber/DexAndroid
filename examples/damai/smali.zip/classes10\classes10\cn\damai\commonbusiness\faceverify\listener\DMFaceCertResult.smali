.class public Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;
    }
.end annotation
