.class public interface abstract Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnProvinceCityCountySelectedListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnProvinceCityCountySelectedListener"
.end annotation


# virtual methods
.method public abstract onDivisionsSelected(Lcn/damai/commonbusiness/address/bean/DivisionBean;Lcn/damai/commonbusiness/address/bean/DivisionBean;Lcn/damai/commonbusiness/address/bean/DivisionBean;)V
.end method
