.class public final Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper$a;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    bv = {}
    d1 = {
        "\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0004\n\u0002\u0010\u000b\n\u0002\u0008\u0007\u0018\u0000 \u00102\u00020\u0001:\u0001\u0011B\u0007\u00a2\u0006\u0004\u0008\u000e\u0010\u000fJ\u0012\u0010\u0005\u001a\u00020\u00042\u0008\u0010\u0003\u001a\u0004\u0018\u00010\u0002H\u0002J\u0018\u0010\t\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0008\u001a\u00020\u0006H\u0002J\u0006\u0010\n\u001a\u00020\u0004J\u0016\u0010\u000c\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0008\u001a\u00020\u000bJ\u0010\u0010\r\u001a\u0004\u0018\u00010\u00062\u0006\u0010\u0007\u001a\u00020\u0006\u00a8\u0006\u0012"
    }
    d2 = {
        "Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper;",
        "",
        "Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel;",
        "model",
        "",
        "d",
        "",
        "itemId",
        "followStatus",
        "e",
        "g",
        "",
        "f",
        "c",
        "<init>",
        "()V",
        "Companion",
        "a",
        "picturesbiz_release"
    }
    k = 0x1
    mv = {
        0x1,
        0x7,
        0x1
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

.field public static final Companion:Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper$a;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private static final a:Lkotlin/Lazy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/Lazy<",
            "Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper$a;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper;->Companion:Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper$a;

    .line 1
    sget-object v0, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper$Companion$singleton$2;->INSTANCE:Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper$Companion$singleton$2;

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper;->a:Lkotlin/Lazy;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final synthetic a()Lkotlin/Lazy;
    .registers 1

    .line 1
    sget-object v0, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper;->a:Lkotlin/Lazy;

    return-object v0
.end method

.method public static final synthetic b(Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper;Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper;->d(Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel;)V

    return-void
.end method

.method private final d(Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    sget-object v0, Ltb/nw2;->INSTANCE:Ltb/nw2;

    invoke-virtual {v0}, Ltb/nw2;->isLogin()Z

    move-result v1

    if-nez v1, :cond_20

    return-void

    :cond_20
    if-eqz p1, :cond_5e

    .line 2
    iget-object v1, p1, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel;->list:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_5e

    .line 3
    invoke-virtual {v0}, Ltb/nw2;->getUserId()Ljava/lang/String;

    move-result-object v0

    .line 4
    invoke-static {p1}, Ltb/zn2;->e(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    .line 5
    sget-object v1, Ltb/lt2;->INSTANCE:Ltb/lt2;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "dm_project_wantstatus_"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0, p1}, Ltb/lt2;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 6
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "\u672c\u5730\u7f13\u5b58\u6570\u636e\u66f4\u65b0\u7ed3\u679cdata= "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "ProjectFollow"

    .line 7
    invoke-static {v0, p1}, Ltb/av2;->c(Ljava/lang/String;Ljava/lang/String;)V

    :cond_5e
    return-void
.end method

.method private final e(Ljava/lang/String;Ljava/lang/String;)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1a
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "\u5f53\u524d\u672c\u5730\u6ca1\u6709\u7f13\u5b58\u6570\u636e\uff0c\u66f4\u65b0\u5546\u54c1\u70b9\u51fb\u540e\u5355\u6761\u6570\u636e itemId= "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " followStatus= "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "ProjectFollow"

    .line 2
    invoke-static {v1, v0}, Ltb/av2;->c(Ljava/lang/String;Ljava/lang/String;)V

    .line 3
    new-instance v0, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel;

    invoke-direct {v0}, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel;-><init>()V

    .line 4
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, v0, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel;->list:Ljava/util/ArrayList;

    .line 5
    new-instance v1, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel$WantStatusTodayUpdateProject;

    invoke-direct {v1}, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel$WantStatusTodayUpdateProject;-><init>()V

    .line 6
    iput-object p2, v1, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel$WantStatusTodayUpdateProject;->status:Ljava/lang/String;

    .line 7
    iput-object p1, v1, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel$WantStatusTodayUpdateProject;->itemId:Ljava/lang/String;

    .line 8
    iget-object p1, v0, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel;->list:Ljava/util/ArrayList;

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 9
    invoke-direct {p0, v0}, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper;->d(Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel;)V

    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/String;)Ljava/lang/String;
    .registers 8
    .param p1    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    return-object p1

    :cond_1a
    const-string v0, "itemId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    sget-object v0, Ltb/nw2;->INSTANCE:Ltb/nw2;

    invoke-virtual {v0}, Ltb/nw2;->getUserId()Ljava/lang/String;

    move-result-object v0

    .line 2
    sget-object v1, Ltb/lt2;->INSTANCE:Ltb/lt2;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "dm_project_wantstatus_"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, ""

    invoke-virtual {v1, v0, v2}, Ltb/lt2;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 3
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const-string v2, "\u5546\u54c1\u8be6\u60c5\u83b7\u53d6\u60f3\u770b\u6570\u636e itemId= "

    const-string v3, "ProjectFollow"

    if-nez v1, :cond_b1

    .line 4
    const-class v1, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel;

    invoke-static {v0, v1}, Ltb/zn2;->a(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel;

    if-eqz v0, :cond_b1

    .line 5
    iget-object v1, v0, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel;->list:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_b1

    .line 6
    iget-object v0, v0, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel;->list:Ljava/util/ArrayList;

    const-string v1, "modelCache.list"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v1, Ljava/util/LinkedHashMap;

    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 7
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_6a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_7d

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .line 8
    move-object v5, v4

    check-cast v5, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel$WantStatusTodayUpdateProject;

    .line 9
    iget-object v5, v5, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel$WantStatusTodayUpdateProject;->itemId:Ljava/lang/String;

    invoke-interface {v1, v5, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_6a

    .line 10
    :cond_7d
    invoke-interface {v1, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel$WantStatusTodayUpdateProject;

    if-eqz v0, :cond_b1

    .line 11
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " followStatus= "

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p1, v0, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel$WantStatusTodayUpdateProject;->status:Ljava/lang/String;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 12
    invoke-static {v3, p1}, Ltb/av2;->c(Ljava/lang/String;Ljava/lang/String;)V

    .line 13
    iget-object p1, v0, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel$WantStatusTodayUpdateProject;->status:Ljava/lang/String;

    const-string v0, "1"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_ae

    const-string p1, "true"

    goto :goto_b0

    :cond_ae
    const-string p1, "false"

    :goto_b0
    return-object p1

    .line 14
    :cond_b1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " \u6ca1\u6709\u7f13\u5b58\u60f3\u770b\u72b6\u6001\uff0c\u4f1a\u7ee7\u7eed\u67e5\u8be2\u8001\u7684\u7f13\u5b58key\u60c5\u51b5"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 15
    invoke-static {v3, p1}, Ltb/av2;->c(Ljava/lang/String;Ljava/lang/String;)V

    const/4 p1, 0x0

    return-object p1
.end method

.method public final f(Ljava/lang/String;Z)V
    .registers 9
    .param p1    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    sget-object v0, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_1e
    const-string v0, "itemId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    sget-object v0, Ltb/nw2;->INSTANCE:Ltb/nw2;

    invoke-virtual {v0}, Ltb/nw2;->isLogin()Z

    move-result v1

    if-nez v1, :cond_2c

    return-void

    .line 2
    :cond_2c
    invoke-virtual {v0}, Ltb/nw2;->getUserId()Ljava/lang/String;

    move-result-object v0

    .line 3
    sget-object v1, Ltb/lt2;->INSTANCE:Ltb/lt2;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "dm_project_wantstatus_"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, ""

    invoke-virtual {v1, v0, v2}, Ltb/lt2;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz p2, :cond_4e

    const-string v1, "1"

    goto :goto_50

    :cond_4e
    const-string v1, "0"

    .line 4
    :goto_50
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_cf

    .line 5
    const-class v2, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel;

    invoke-static {v0, v2}, Ltb/zn2;->a(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel;

    if-eqz v0, :cond_cb

    .line 6
    iget-object v2, v0, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel;->list:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_cb

    .line 7
    iget-object v2, v0, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel;->list:Ljava/util/ArrayList;

    const-string v3, "modelCache.list"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v3, Ljava/util/LinkedHashMap;

    invoke-direct {v3}, Ljava/util/LinkedHashMap;-><init>()V

    .line 8
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_78
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_8b

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .line 9
    move-object v5, v4

    check-cast v5, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel$WantStatusTodayUpdateProject;

    .line 10
    iget-object v5, v5, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel$WantStatusTodayUpdateProject;->itemId:Ljava/lang/String;

    invoke-interface {v3, v5, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_78

    .line 11
    :cond_8b
    invoke-interface {v3, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel$WantStatusTodayUpdateProject;

    if-eqz v2, :cond_96

    .line 12
    iput-object v1, v2, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel$WantStatusTodayUpdateProject;->status:Ljava/lang/String;

    goto :goto_a9

    .line 13
    :cond_96
    new-instance v2, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel$WantStatusTodayUpdateProject;

    invoke-direct {v2}, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel$WantStatusTodayUpdateProject;-><init>()V

    .line 14
    iput-object v1, v2, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel$WantStatusTodayUpdateProject;->status:Ljava/lang/String;

    .line 15
    iput-object p1, v2, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel$WantStatusTodayUpdateProject;->itemId:Ljava/lang/String;

    .line 16
    iget-object v1, v0, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel;->list:Ljava/util/ArrayList;

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 17
    iget-object v1, v2, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel$WantStatusTodayUpdateProject;->itemId:Ljava/lang/String;

    invoke-interface {v3, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 18
    :goto_a9
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\u5f53\u524d\u672c\u5730\u6709\u7f13\u5b58\u6570\u636e\uff0c\u66f4\u65b0\u5546\u54c1\u70b9\u51fb\u540e\u6570\u636e itemId= "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " followStatus= "

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "ProjectFollow"

    .line 19
    invoke-static {p2, p1}, Ltb/av2;->c(Ljava/lang/String;Ljava/lang/String;)V

    .line 20
    invoke-direct {p0, v0}, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper;->d(Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateModel;)V

    goto :goto_d2

    .line 21
    :cond_cb
    invoke-direct {p0, p1, v1}, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper;->e(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_d2

    .line 22
    :cond_cf
    invoke-direct {p0, p1, v1}, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_d2
    return-void
.end method

.method public final g()V
    .registers 15

    sget-object v0, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_14

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    sget-object v0, Ltb/nw2;->INSTANCE:Ltb/nw2;

    invoke-virtual {v0}, Ltb/nw2;->isLogin()Z

    move-result v0

    if-nez v0, :cond_1d

    return-void

    .line 2
    :cond_1d
    new-instance v9, Ljava/util/LinkedHashMap;

    invoke-direct {v9}, Ljava/util/LinkedHashMap;-><init>()V

    .line 3
    new-instance v8, Ljava/util/LinkedHashMap;

    invoke-direct {v8}, Ljava/util/LinkedHashMap;-><init>()V

    const-string v0, "patternName"

    const-string v1, "damai_startup_dispatch"

    .line 4
    invoke-interface {v9, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "patternVersion"

    const-string v1, "1.0"

    .line 5
    invoke-interface {v9, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    sget-object v4, Ltb/uh0;->INSTANCE:Ltb/uh0;

    .line 7
    sget-object v0, Ltb/oa;->INSTANCE:Ltb/oa;

    invoke-virtual {v0}, Ltb/oa;->getAppContext()Landroid/content/Context;

    move-result-object v5

    const-wide/16 v6, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/16 v12, 0x30

    const/4 v13, 0x0

    .line 8
    invoke-static/range {v4 .. v13}, Ltb/uh0;->b(Ltb/uh0;Landroid/content/Context;JLjava/util/Map;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/youku/arch/v3/data/Request;

    move-result-object v0

    .line 9
    sget-object v1, Lcom/alient/onearch/adapter/request/RequestParamsInjector;->Companion:Lcom/alient/onearch/adapter/request/RequestParamsInjector$Companion;

    invoke-virtual {v1}, Lcom/alient/onearch/adapter/request/RequestParamsInjector$Companion;->getInstance()Lcom/alient/onearch/adapter/request/RequestParamsInjector;

    move-result-object v1

    new-instance v2, Ljava/util/LinkedHashMap;

    invoke-direct {v2}, Ljava/util/LinkedHashMap;-><init>()V

    invoke-virtual {v1, v0, v2}, Lcom/alient/onearch/adapter/request/RequestParamsInjector;->inject(Lcom/youku/arch/v3/io/IRequest;Ljava/util/Map;)V

    .line 10
    :try_start_56
    new-instance v1, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v1}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V

    const/4 v2, 0x0

    invoke-static {v2, v3, v2}, Lkotlinx/coroutines/t;->b(Lkotlinx/coroutines/Job;ILjava/lang/Object;)Lkotlinx/coroutines/CompletableJob;

    move-result-object v3

    invoke-static {v3}, Lkotlinx/coroutines/i;->a(Lkotlin/coroutines/CoroutineContext;)Lkotlinx/coroutines/CoroutineScope;

    move-result-object v3

    iput-object v3, v1, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    .line 11
    move-object v4, v3

    check-cast v4, Lkotlinx/coroutines/CoroutineScope;

    const/4 v5, 0x0

    const/4 v6, 0x0

    new-instance v7, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper$wantStatusTodayUpdateRequest$1;

    invoke-direct {v7, v0, v1, p0, v2}, Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper$wantStatusTodayUpdateRequest$1;-><init>(Lcom/youku/arch/v3/data/Request;Lkotlin/jvm/internal/Ref$ObjectRef;Lcn/damai/commonbusiness/helper/WantStatusTodayUpdateHelper;Lkotlin/coroutines/Continuation;)V

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-static/range {v4 .. v9}, Ltb/ar;->d(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Lkotlinx/coroutines/Job;
    :try_end_75
    .catch Ljava/lang/Exception; {:try_start_56 .. :try_end_75} :catch_75

    :catch_75
    return-void
.end method
