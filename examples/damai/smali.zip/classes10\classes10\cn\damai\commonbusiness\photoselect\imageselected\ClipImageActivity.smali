.class public Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;
.super Landroid/app/Activity;
.source "Taobao"


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private a:Landroid/widget/FrameLayout;

.field private b:Landroid/widget/FrameLayout;

.field private c:Lcn/damai/commonbusiness/photoselect/imageselected/view/ClipImageView;

.field private d:I


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method static synthetic a(Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;)Lcn/damai/commonbusiness/photoselect/imageselected/view/ClipImageView;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->c:Lcn/damai/commonbusiness/photoselect/imageselected/view/ClipImageView;

    return-object p0
.end method

.method static synthetic b(Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;)Landroid/widget/FrameLayout;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->a:Landroid/widget/FrameLayout;

    return-object p0
.end method

.method static synthetic c(Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;Landroid/graphics/Bitmap;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->d(Landroid/graphics/Bitmap;)V

    return-void
.end method

.method private d(Landroid/graphics/Bitmap;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_17
    const/4 v0, 0x0

    if-eqz p1, :cond_3f

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Landroid/app/Activity;->getExternalCacheDir()Ljava/io/File;

    move-result-object v1

    invoke-virtual {v1}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "image_select"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Ltb/ni2;->e(Landroid/graphics/Bitmap;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 2
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->recycle()V

    .line 3
    :cond_3f
    invoke-static {v0}, Ltb/mw5;->i(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_5b

    .line 4
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 5
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 6
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const-string v1, "select_result"

    .line 7
    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putStringArrayListExtra(Ljava/lang/String;Ljava/util/ArrayList;)Landroid/content/Intent;

    const/4 p1, -0x1

    .line 8
    invoke-virtual {p0, p1, v0}, Landroid/app/Activity;->setResult(ILandroid/content/Intent;)V

    .line 9
    :cond_5b
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void
.end method

.method private e()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    sget v0, Lcn/damai/commonbusiness/R$id;->process_img:I

    invoke-virtual {p0, v0}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/photoselect/imageselected/view/ClipImageView;

    iput-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->c:Lcn/damai/commonbusiness/photoselect/imageselected/view/ClipImageView;

    .line 2
    sget v0, Lcn/damai/commonbusiness/R$id;->btn_confirm:I

    invoke-virtual {p0, v0}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/FrameLayout;

    iput-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->a:Landroid/widget/FrameLayout;

    .line 3
    sget v0, Lcn/damai/commonbusiness/R$id;->btn_back:I

    invoke-virtual {p0, v0}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/FrameLayout;

    iput-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->b:Landroid/widget/FrameLayout;

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->a:Landroid/widget/FrameLayout;

    new-instance v1, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity$a;

    invoke-direct {v1, p0}, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity$a;-><init>(Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/FrameLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->b:Landroid/widget/FrameLayout;

    new-instance v1, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity$b;

    invoke-direct {v1, p0}, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity$b;-><init>(Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/FrameLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method private f()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x15

    if-lt v0, v1, :cond_2c

    .line 2
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/high16 v1, -0x80000000

    .line 3
    invoke-virtual {v0, v1}, Landroid/view/Window;->addFlags(I)V

    const-string v1, "#FFFFFF"

    .line 4
    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/Window;->setStatusBarColor(I)V

    :cond_2c
    return-void
.end method


# virtual methods
.method protected onActivityResult(IILandroid/content/Intent;)V
    .registers 8

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_25

    const/4 v2, 0x4

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    aput-object p3, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_25
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    if-eqz p3, :cond_4e

    .line 2
    iget p2, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->d:I

    if-ne p1, p2, :cond_4e

    const-string p1, "select_result"

    .line 3
    invoke-virtual {p3, p1}, Landroid/content/Intent;->getStringArrayListExtra(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object p1

    .line 4
    invoke-virtual {p1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    const/16 p2, 0x2d0

    const/16 p3, 0x438

    invoke-static {p1, p2, p3}, Ltb/ni2;->b(Ljava/lang/String;II)Landroid/graphics/Bitmap;

    move-result-object p1

    if-eqz p1, :cond_4a

    .line 5
    iget-object p2, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->c:Lcn/damai/commonbusiness/photoselect/imageselected/view/ClipImageView;

    invoke-virtual {p2, p1}, Lcn/damai/commonbusiness/photoselect/imageselected/view/ClipImageView;->setBitmapData(Landroid/graphics/Bitmap;)V

    goto :goto_51

    .line 6
    :cond_4a
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    goto :goto_51

    .line 7
    :cond_4e
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    :goto_51
    return-void
.end method

.method public onBackPressed()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_13

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    :cond_13
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    sget-object v0, Ltb/oa;->INSTANCE:Ltb/oa;

    invoke-virtual {v0}, Ltb/oa;->getAppConfigProvider()Lcom/alibaba/pictures/cornerstone/common/IAppConfigProvider;

    move-result-object v1

    if-eqz v1, :cond_2f

    .line 2
    invoke-virtual {v0}, Ltb/oa;->getAppConfigProvider()Lcom/alibaba/pictures/cornerstone/common/IAppConfigProvider;

    move-result-object v0

    invoke-interface {v0}, Lcom/alibaba/pictures/cornerstone/common/IAppConfigProvider;->getIsPioneerOpen()Z

    move-result v0

    if-eqz v0, :cond_2f

    .line 3
    sget v0, Lcn/damai/commonbusiness/R$style;->lightNoActionBarCustomPioneer:I

    invoke-virtual {p0, v0}, Landroid/app/Activity;->setTheme(I)V

    goto :goto_34

    .line 4
    :cond_2f
    sget v0, Lcn/damai/commonbusiness/R$style;->lightNoActionBarCustom:I

    invoke-virtual {p0, v0}, Landroid/app/Activity;->setTheme(I)V

    .line 5
    :goto_34
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 6
    invoke-virtual {p0, v3}, Landroid/app/Activity;->setRequestedOrientation(I)V

    .line 7
    sget p1, Lcn/damai/commonbusiness/R$layout;->activity_clip_image:I

    invoke-virtual {p0, p1}, Landroid/app/Activity;->setContentView(I)V

    .line 8
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const-string v0, "requestCode"

    invoke-virtual {p1, v0, v4}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p1

    iput p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->d:I

    .line 9
    invoke-direct {p0}, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->f()V

    .line 10
    iget p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->d:I

    invoke-static {p0, p1, v3, v4}, Ltb/di2;->a(Landroid/app/Activity;IZI)V

    .line 11
    invoke-direct {p0}, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->e()V

    return-void
.end method
