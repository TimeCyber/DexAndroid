.class public Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$1;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->f(Landroid/content/Context;Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$DataCallback;)Ljava/util/ArrayList;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic this$0:Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;

.field final synthetic val$callback:Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$DataCallback;

.field final synthetic val$context:Landroid/content/Context;

.field final synthetic val$images:Ljava/util/ArrayList;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;Landroid/content/Context;Ljava/util/ArrayList;Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$DataCallback;)V
    .registers 5

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$1;->this$0:Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;

    iput-object p2, p0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$1;->val$context:Landroid/content/Context;

    iput-object p3, p0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$1;->val$images:Ljava/util/ArrayList;

    iput-object p4, p0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$1;->val$callback:Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$DataCallback;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 21

    move-object/from16 v0, p0

    sget-object v1, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$1;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v2, "1"

    invoke-static {v1, v2}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_16

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object v0, v3, v4

    invoke-interface {v1, v2, v3}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_16
    sget-object v6, Landroid/provider/MediaStore$Video$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    .line 2
    iget-object v1, v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$1;->val$context:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v5

    const-string v7, "_id"

    const-string v8, "title"

    const-string v9, "_display_name"

    const-string v10, "_data"

    const-string v11, "date_added"

    const-string v12, "_size"

    const-string v13, "duration"

    const-string v14, "bucket_id"

    const-string v15, "bucket_display_name"

    .line 3
    filled-new-array/range {v7 .. v15}, [Ljava/lang/String;

    move-result-object v7

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    .line 4
    invoke-virtual/range {v5 .. v10}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    if-eqz v1, :cond_126

    .line 5
    invoke-interface {v1}, Landroid/database/Cursor;->getCount()I

    move-result v2

    if-eqz v2, :cond_126

    .line 6
    :goto_43
    invoke-interface {v1}, Landroid/database/Cursor;->moveToNext()Z

    move-result v2

    if-eqz v2, :cond_126

    const-string v2, "title"

    .line 7
    invoke-interface {v1, v2}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v2

    invoke-interface {v1, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v2

    const-string v3, "_display_name"

    .line 8
    invoke-interface {v1, v3}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v3

    invoke-interface {v1, v3}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v3

    const-string v4, "_data"

    .line 9
    invoke-interface {v1, v4}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v4

    invoke-interface {v1, v4}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v4

    const-string v5, "date_added"

    .line 10
    invoke-interface {v1, v5}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v5

    invoke-interface {v1, v5}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v5

    const-string v7, "_size"

    .line 11
    invoke-interface {v1, v7}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v7

    invoke-interface {v1, v7}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v7

    const-string v9, "duration"

    .line 12
    invoke-interface {v1, v9}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v9

    invoke-interface {v1, v9}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v9

    const-string v11, "bucket_id"

    .line 13
    invoke-interface {v1, v11}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v11

    invoke-interface {v1, v11}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v11

    const-string v12, "bucket_display_name"

    .line 14
    invoke-interface {v1, v12}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v12

    invoke-interface {v1, v12}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v12

    .line 15
    iget-object v13, v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$1;->this$0:Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;

    invoke-static {v13, v9, v10}, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->a(Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;J)Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;

    move-result-object v13

    .line 16
    iget-object v14, v13, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;->b:Ljava/lang/String;

    .line 17
    iget-boolean v13, v13, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;->a:Z

    .line 18
    iget-object v15, v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$1;->this$0:Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;

    invoke-static {v15, v7, v8}, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->b(Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;J)Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;

    move-result-object v15

    .line 19
    iget-object v0, v15, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;->b:Ljava/lang/String;

    .line 20
    iget-boolean v15, v15, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;->a:Z

    move-object/from16 v16, v12

    const-string v12, "."

    .line 21
    invoke-virtual {v4, v12}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v12

    move-object/from16 v17, v11

    const-string v11, "_id"

    .line 22
    invoke-interface {v1, v11}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v11

    move/from16 v19, v13

    move-object/from16 v18, v14

    invoke-interface {v1, v11}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v13

    .line 23
    sget-object v11, Landroid/provider/MediaStore$Video$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    invoke-static {v11, v13, v14}, Landroid/content/ContentUris;->withAppendedId(Landroid/net/Uri;J)Landroid/net/Uri;

    move-result-object v11

    const/4 v13, -0x1

    if-eq v12, v13, :cond_122

    .line 24
    invoke-virtual {v4, v12}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v12

    .line 25
    new-instance v13, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;

    invoke-direct {v13}, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;-><init>()V

    .line 26
    invoke-virtual {v13, v2}, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;->setTitle(Ljava/lang/String;)V

    .line 27
    invoke-virtual {v13, v3}, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;->setName(Ljava/lang/String;)V

    const-string v2, "2"

    .line 28
    invoke-virtual {v13, v2}, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;->setType(Ljava/lang/String;)V

    .line 29
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1d

    if-lt v2, v3, :cond_f0

    .line 30
    invoke-virtual {v11}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v13, v2}, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;->setPath(Ljava/lang/String;)V

    goto :goto_f3

    .line 31
    :cond_f0
    invoke-virtual {v13, v4}, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;->setPath(Ljava/lang/String;)V

    .line 32
    :goto_f3
    invoke-virtual {v13, v5, v6}, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;->setAddDate(J)V

    .line 33
    invoke-virtual {v13, v7, v8}, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;->setSize(J)V

    .line 34
    invoke-virtual {v13, v0}, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;->setSizeShow(Ljava/lang/String;)V

    .line 35
    invoke-virtual {v13, v15}, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;->setLimitSize(Z)V

    .line 36
    invoke-virtual {v13, v9, v10}, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;->setDuration(J)V

    move-object/from16 v0, v18

    .line 37
    invoke-virtual {v13, v0}, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;->setDurationShow(Ljava/lang/String;)V

    move/from16 v0, v19

    .line 38
    invoke-virtual {v13, v0}, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;->setLimitDur(Z)V

    move-object/from16 v0, v17

    .line 39
    invoke-virtual {v13, v0}, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;->setBucketId(Ljava/lang/String;)V

    move-object/from16 v0, v16

    .line 40
    invoke-virtual {v13, v0}, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;->setBucketName(Ljava/lang/String;)V

    .line 41
    invoke-virtual {v13, v12}, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;->setSuffixType(Ljava/lang/String;)V

    move-object/from16 v0, p0

    .line 42
    iget-object v2, v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$1;->val$images:Ljava/util/ArrayList;

    invoke-virtual {v2, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_43

    :cond_122
    move-object/from16 v0, p0

    goto/16 :goto_43

    .line 43
    :cond_126
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 44
    iget-object v1, v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$1;->val$images:Ljava/util/ArrayList;

    invoke-static {v1}, Ljava/util/Collections;->reverse(Ljava/util/List;)V

    .line 45
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 46
    new-instance v2, Ltb/ww1;

    iget-object v3, v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$1;->val$images:Ljava/util/ArrayList;

    const-string v4, "\u6240\u6709\u89c6\u9891"

    invoke-direct {v2, v4, v3}, Ltb/ww1;-><init>(Ljava/lang/String;Ljava/util/ArrayList;)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 47
    iget-object v2, v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$1;->val$callback:Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$DataCallback;

    invoke-interface {v2, v1}, Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$DataCallback;->onSuccess(Ljava/util/ArrayList;)V

    return-void
.end method
