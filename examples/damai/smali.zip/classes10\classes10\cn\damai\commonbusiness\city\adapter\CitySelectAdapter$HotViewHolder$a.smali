.class public Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder$a;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder;->b(Ltb/e10;Ljava/util/List;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Ltb/e10;

.field final synthetic b:Lcn/damai/commonbusiness/city/model/HotCityBean;

.field final synthetic c:Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder;Ltb/e10;Lcn/damai/commonbusiness/city/model/HotCityBean;)V
    .registers 4

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder$a;->c:Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder;

    iput-object p2, p0, Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder$a;->a:Ltb/e10;

    iput-object p3, p0, Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder$a;->b:Lcn/damai/commonbusiness/city/model/HotCityBean;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder$a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-static {}, Ltb/ih5;->d()Z

    move-result p1

    if-eqz p1, :cond_1e

    return-void

    .line 2
    :cond_1e
    iget-object p1, p0, Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder$a;->c:Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder;

    iget-object p1, p1, Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder;->b:Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter;

    invoke-static {p1}, Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter;->g(Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter;)Lcn/damai/commonbusiness/city/listener/OnCityListItemClickListener;

    move-result-object p1

    if-eqz p1, :cond_6e

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder$a;->a:Ltb/e10;

    invoke-virtual {p1}, Ltb/e10;->e()I

    move-result p1

    if-ne p1, v3, :cond_4e

    .line 4
    iget-object p1, p0, Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder$a;->c:Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder;

    iget-object p1, p1, Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder;->b:Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter;

    invoke-static {p1}, Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter;->g(Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter;)Lcn/damai/commonbusiness/city/listener/OnCityListItemClickListener;

    move-result-object p1

    iget-object v0, p0, Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder$a;->b:Lcn/damai/commonbusiness/city/model/HotCityBean;

    .line 5
    invoke-virtual {v0}, Lcn/damai/commonbusiness/city/model/HotCityBean;->getCityName()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder$a;->b:Lcn/damai/commonbusiness/city/model/HotCityBean;

    invoke-virtual {v1}, Lcn/damai/commonbusiness/city/model/HotCityBean;->getCityId()Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder$a;->b:Lcn/damai/commonbusiness/city/model/HotCityBean;

    .line 6
    invoke-virtual {v2}, Lcn/damai/commonbusiness/city/model/HotCityBean;->getUrl()Ljava/lang/String;

    move-result-object v2

    .line 7
    invoke-interface {p1, v0, v1, v2}, Lcn/damai/commonbusiness/city/listener/OnCityListItemClickListener;->onHotCityClick(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_6e

    .line 8
    :cond_4e
    iget-object p1, p0, Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder$a;->a:Ltb/e10;

    invoke-virtual {p1}, Ltb/e10;->e()I

    move-result p1

    const/4 v0, 0x3

    if-ne p1, v0, :cond_6e

    .line 9
    iget-object p1, p0, Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder$a;->c:Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder;

    iget-object p1, p1, Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder;->b:Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter;

    invoke-static {p1}, Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter;->g(Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter;)Lcn/damai/commonbusiness/city/listener/OnCityListItemClickListener;

    move-result-object p1

    iget-object v0, p0, Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder$a;->b:Lcn/damai/commonbusiness/city/model/HotCityBean;

    .line 10
    invoke-virtual {v0}, Lcn/damai/commonbusiness/city/model/HotCityBean;->getCityName()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcn/damai/commonbusiness/city/adapter/CitySelectAdapter$HotViewHolder$a;->b:Lcn/damai/commonbusiness/city/model/HotCityBean;

    invoke-virtual {v1}, Lcn/damai/commonbusiness/city/model/HotCityBean;->getCityId()Ljava/lang/String;

    move-result-object v1

    .line 11
    invoke-interface {p1, v0, v1}, Lcn/damai/commonbusiness/city/listener/OnCityListItemClickListener;->onHistoryCityClick(Ljava/lang/String;Ljava/lang/String;)V

    :cond_6e
    :goto_6e
    return-void
.end method
