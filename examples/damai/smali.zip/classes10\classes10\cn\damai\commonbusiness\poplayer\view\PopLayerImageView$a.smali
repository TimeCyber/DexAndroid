.class public Lcn/damai/commonbusiness/poplayer/view/PopLayerImageView$a;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/poplayer/view/PopLayerImageView;->init(Landroid/content/Context;Ltb/jf2;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/poplayer/view/PopLayerImageView;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/poplayer/view/PopLayerImageView;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/poplayer/view/PopLayerImageView$a;->a:Lcn/damai/commonbusiness/poplayer/view/PopLayerImageView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 7

    const-string v0, "groupId"

    sget-object v1, Lcn/damai/commonbusiness/poplayer/view/PopLayerImageView$a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v2, "1"

    invoke-static {v1, v2}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_19

    const/4 v0, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    aput-object p0, v0, v4

    const/4 v3, 0x1

    aput-object p1, v0, v3

    invoke-interface {v1, v2, v0}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_19
    :try_start_19
    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    .line 2
    iget-object v1, p0, Lcn/damai/commonbusiness/poplayer/view/PopLayerImageView$a;->a:Lcn/damai/commonbusiness/poplayer/view/PopLayerImageView;

    invoke-static {v1, v0}, Lcn/damai/commonbusiness/poplayer/view/PopLayerImageView;->access$000(Lcn/damai/commonbusiness/poplayer/view/PopLayerImageView;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 3
    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/poplayer/view/PopLayerImageView$a;->a:Lcn/damai/commonbusiness/poplayer/view/PopLayerImageView;

    const-string v1, "clicked"

    invoke-virtual {v0, v1, p1}, Lcom/alibaba/poplayer/factory/view/base/PopLayerBaseView;->fireEventToMasterIfExist(Ljava/lang/String;Ljava/lang/String;)V

    const-string p1, "PopLayerImageView.onClick:clicked."

    new-array v0, v4, [Ljava/lang/Object;

    .line 5
    invoke-static {p1, v0}, Ltb/ue4;->b(Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_39
    .catchall {:try_start_19 .. :try_end_39} :catchall_3a

    goto :goto_40

    :catchall_3a
    move-exception p1

    const-string v0, "PopLayerImageView. fire event error."

    .line 6
    invoke-static {v0, p1}, Ltb/ue4;->c(Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_40
    return-void
.end method
