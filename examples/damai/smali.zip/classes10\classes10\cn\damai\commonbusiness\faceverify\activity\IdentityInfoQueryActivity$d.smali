.class public Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$d;
.super Landroid/text/style/ClickableSpan;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;->setListener()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$d;->a:Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;

    invoke-direct {p0}, Landroid/text/style/ClickableSpan;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 6
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param

    sget-object v0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$d;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    new-instance p1, Landroid/os/Bundle;

    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V

    const-string v0, "url"

    const-string v1, "https://m.damai.cn/damai/mine/audience-notice/index.html"

    .line 2
    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$d;->a:Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;

    invoke-static {v0}, Lcn/damai/common/nav/DMNav;->from(Landroid/content/Context;)Lcn/damai/common/nav/DMNav;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcn/damai/common/nav/DMNav;->withExtras(Landroid/os/Bundle;)Lcn/damai/common/nav/DMNav;

    move-result-object p1

    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->y:Ljava/lang/String;

    invoke-static {v0}, Lcn/damai/common/nav/NavUri;->e(Ljava/lang/String;)Lcn/damai/common/nav/NavUri;

    move-result-object v0

    invoke-virtual {p1, v0}, Lcn/damai/common/nav/DMNav;->toUri(Lcn/damai/common/nav/NavUri;)Z

    return-void
.end method

.method public updateDrawState(Landroid/text/TextPaint;)V
    .registers 6
    .param p1    # Landroid/text/TextPaint;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param

    sget-object v0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$d;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-super {p0, p1}, Landroid/text/style/ClickableSpan;->updateDrawState(Landroid/text/TextPaint;)V

    const-string v0, "#ff1268"

    .line 2
    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/text/TextPaint;->setColor(I)V

    .line 3
    invoke-virtual {p1, v3}, Landroid/text/TextPaint;->setUnderlineText(Z)V

    return-void
.end method
