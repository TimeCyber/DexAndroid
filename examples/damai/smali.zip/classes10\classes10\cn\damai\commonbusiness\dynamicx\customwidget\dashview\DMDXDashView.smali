.class public Lcn/damai/commonbusiness/dynamicx/customwidget/dashview/DMDXDashView;
.super Landroid/view/View;
.source "Taobao"


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private dashColor:I

.field private dashGap:I

.field private dashWidth:I


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    const-string p1, "#EEEEEE"

    .line 2
    invoke-static {p1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p1

    iput p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/dashview/DMDXDashView;->dashColor:I

    .line 3
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/high16 v0, 0x40400000    # 3.0f

    invoke-static {p1, v0}, Ltb/g31;->a(Landroid/content/Context;F)I

    move-result p1

    iput p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/dashview/DMDXDashView;->dashWidth:I

    .line 4
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/high16 v0, 0x40000000    # 2.0f

    invoke-static {p1, v0}, Ltb/g31;->a(Landroid/content/Context;F)I

    move-result p1

    iput p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/dashview/DMDXDashView;->dashGap:I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 3

    .line 5
    invoke-direct {p0, p1, p2}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const-string p1, "#EEEEEE"

    .line 6
    invoke-static {p1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p1

    iput p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/dashview/DMDXDashView;->dashColor:I

    .line 7
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/high16 p2, 0x40400000    # 3.0f

    invoke-static {p1, p2}, Ltb/g31;->a(Landroid/content/Context;F)I

    move-result p1

    iput p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/dashview/DMDXDashView;->dashWidth:I

    .line 8
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/high16 p2, 0x40000000    # 2.0f

    invoke-static {p1, p2}, Ltb/g31;->a(Landroid/content/Context;F)I

    move-result p1

    iput p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/dashview/DMDXDashView;->dashGap:I

    return-void
.end method


# virtual methods
.method protected onDraw(Landroid/graphics/Canvas;)V
    .registers 14

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/dashview/DMDXDashView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v2, :cond_17

    new-array v2, v4, [Ljava/lang/Object;

    aput-object p0, v2, v3

    aput-object p1, v2, v5

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    new-instance v11, Landroid/graphics/Paint;

    invoke-direct {v11, v5}, Landroid/graphics/Paint;-><init>(I)V

    .line 2
    iget v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/dashview/DMDXDashView;->dashColor:I

    invoke-virtual {v11, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 3
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {v11, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 4
    new-instance v0, Landroid/graphics/DashPathEffect;

    new-array v1, v4, [F

    iget v2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/dashview/DMDXDashView;->dashWidth:I

    int-to-float v2, v2

    aput v2, v1, v3

    iget v2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/dashview/DMDXDashView;->dashGap:I

    int-to-float v2, v2

    aput v2, v1, v5

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Landroid/graphics/DashPathEffect;-><init>([FF)V

    invoke-virtual {v11, v0}, Landroid/graphics/Paint;->setPathEffect(Landroid/graphics/PathEffect;)Landroid/graphics/PathEffect;

    .line 5
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v0

    div-int/2addr v0, v4

    const/4 v7, 0x0

    int-to-float v10, v0

    .line 6
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v0

    int-to-float v9, v0

    move-object v6, p1

    move v8, v10

    invoke-virtual/range {v6 .. v11}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    return-void
.end method

.method public setParams(III)V
    .registers 8

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/dashview/DMDXDashView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_29

    const/4 v2, 0x4

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_29
    iput p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/dashview/DMDXDashView;->dashColor:I

    .line 2
    iput p2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/dashview/DMDXDashView;->dashWidth:I

    .line 3
    iput p3, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/dashview/DMDXDashView;->dashGap:I

    .line 4
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method
