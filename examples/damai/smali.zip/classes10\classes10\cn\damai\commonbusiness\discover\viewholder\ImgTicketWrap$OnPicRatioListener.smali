.class public interface abstract Lcn/damai/commonbusiness/discover/viewholder/ImgTicketWrap$OnPicRatioListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/discover/viewholder/ImgTicketWrap;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnPicRatioListener"
.end annotation


# virtual methods
.method public abstract onRatio(Ljava/lang/String;F)V
.end method
