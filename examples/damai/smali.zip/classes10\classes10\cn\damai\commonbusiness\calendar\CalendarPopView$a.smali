.class public Lcn/damai/commonbusiness/calendar/CalendarPopView$a;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/calendar/CalendarPopView;->x()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/calendar/CalendarPopView;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/calendar/CalendarPopView;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$a;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/calendar/CalendarPopView$a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-virtual {p1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_b6

    .line 2
    invoke-virtual {p1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/calendar/bean/Day;

    if-eqz p1, :cond_b6

    .line 3
    iget v0, p1, Lcn/damai/commonbusiness/calendar/bean/Day;->showType:I

    if-nez v0, :cond_2b

    goto/16 :goto_b6

    .line 4
    :cond_2b
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$a;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    const/4 v1, 0x5

    iput v1, v0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->r:I

    .line 5
    invoke-static {v0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->g(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Lcn/damai/commonbusiness/calendar/bean/Day;

    move-result-object v0

    if-nez v0, :cond_49

    .line 6
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$a;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {v0, p1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->h(Lcn/damai/commonbusiness/calendar/CalendarPopView;Lcn/damai/commonbusiness/calendar/bean/Day;)Lcn/damai/commonbusiness/calendar/bean/Day;

    .line 7
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 8
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 9
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$a;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {p1, v0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->i(Lcn/damai/commonbusiness/calendar/CalendarPopView;Ljava/util/List;)V

    goto :goto_b6

    .line 10
    :cond_49
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$a;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {v0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->j(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Lcn/damai/commonbusiness/calendar/bean/Day;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_67

    .line 11
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$a;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {p1, v1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->h(Lcn/damai/commonbusiness/calendar/CalendarPopView;Lcn/damai/commonbusiness/calendar/bean/Day;)Lcn/damai/commonbusiness/calendar/bean/Day;

    .line 12
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$a;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {p1, v1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->k(Lcn/damai/commonbusiness/calendar/CalendarPopView;Lcn/damai/commonbusiness/calendar/bean/Day;)Lcn/damai/commonbusiness/calendar/bean/Day;

    .line 13
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$a;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-static {p1, v0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->i(Lcn/damai/commonbusiness/calendar/CalendarPopView;Ljava/util/List;)V

    return-void

    .line 14
    :cond_67
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$a;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {v0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->g(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Lcn/damai/commonbusiness/calendar/bean/Day;

    move-result-object v0

    invoke-virtual {p1, v0}, Lcn/damai/commonbusiness/calendar/bean/Day;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_83

    .line 15
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$a;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {p1, v1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->h(Lcn/damai/commonbusiness/calendar/CalendarPopView;Lcn/damai/commonbusiness/calendar/bean/Day;)Lcn/damai/commonbusiness/calendar/bean/Day;

    .line 16
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$a;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-static {p1, v0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->i(Lcn/damai/commonbusiness/calendar/CalendarPopView;Ljava/util/List;)V

    goto :goto_b6

    .line 17
    :cond_83
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$a;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {v0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->g(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Lcn/damai/commonbusiness/calendar/bean/Day;

    move-result-object v0

    invoke-virtual {p1, v0}, Lcn/damai/commonbusiness/calendar/bean/Day;->isAfterDay(Lcn/damai/commonbusiness/calendar/bean/Day;)Z

    move-result v0

    if-eqz v0, :cond_9e

    .line 18
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$a;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {v0, p1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->k(Lcn/damai/commonbusiness/calendar/CalendarPopView;Lcn/damai/commonbusiness/calendar/bean/Day;)Lcn/damai/commonbusiness/calendar/bean/Day;

    .line 19
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$a;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-virtual {p1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->p()Ljava/util/List;

    move-result-object v0

    invoke-static {p1, v0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->i(Lcn/damai/commonbusiness/calendar/CalendarPopView;Ljava/util/List;)V

    goto :goto_b6

    .line 20
    :cond_9e
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$a;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {v0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->g(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Lcn/damai/commonbusiness/calendar/bean/Day;

    move-result-object v1

    invoke-static {v0, v1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->k(Lcn/damai/commonbusiness/calendar/CalendarPopView;Lcn/damai/commonbusiness/calendar/bean/Day;)Lcn/damai/commonbusiness/calendar/bean/Day;

    .line 21
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$a;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {v0, p1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->h(Lcn/damai/commonbusiness/calendar/CalendarPopView;Lcn/damai/commonbusiness/calendar/bean/Day;)Lcn/damai/commonbusiness/calendar/bean/Day;

    .line 22
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$a;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-virtual {p1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->p()Ljava/util/List;

    move-result-object v0

    invoke-static {p1, v0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->i(Lcn/damai/commonbusiness/calendar/CalendarPopView;Ljava/util/List;)V

    nop

    :cond_b6
    :goto_b6
    return-void
.end method
