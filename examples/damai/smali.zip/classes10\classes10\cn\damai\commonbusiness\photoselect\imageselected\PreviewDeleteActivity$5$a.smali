.class public Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$5$a;
.super Landroid/animation/AnimatorListenerAdapter;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$5;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$5;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$5;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$5$a;->a:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$5;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public onAnimationStart(Landroid/animation/Animator;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$5$a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-super {p0, p1}, Landroid/animation/AnimatorListenerAdapter;->onAnimationStart(Landroid/animation/Animator;)V

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$5$a;->a:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$5;

    iget-object p1, p1, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$5;->this$0:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;->access$600(Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;)Landroid/widget/LinearLayout;

    move-result-object p1

    if-eqz p1, :cond_2f

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$5$a;->a:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$5;

    iget-object p1, p1, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$5;->this$0:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;->access$600(Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;)Landroid/widget/LinearLayout;

    move-result-object p1

    invoke-virtual {p1, v3}, Landroid/widget/LinearLayout;->setVisibility(I)V

    :cond_2f
    return-void
.end method
