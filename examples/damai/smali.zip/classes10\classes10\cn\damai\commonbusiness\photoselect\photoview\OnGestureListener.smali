.class interface abstract Lcn/damai/commonbusiness/photoselect/photoview/OnGestureListener;
.super Ljava/lang/Object;
.source "Taobao"


# virtual methods
.method public abstract onDrag(FF)V
.end method

.method public abstract onFling(FFFF)V
.end method

.method public abstract onScale(FFF)V
.end method
