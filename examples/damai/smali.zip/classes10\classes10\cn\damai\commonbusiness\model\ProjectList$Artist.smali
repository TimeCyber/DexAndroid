.class public Lcn/damai/commonbusiness/model/ProjectList$Artist;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/model/ProjectList;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Artist"
.end annotation


# instance fields
.field public ArtistID:Ljava/lang/String;

.field public ArtistName:Ljava/lang/String;

.field public pic:Ljava/lang/String;

.field public projSum:I


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
