.class public interface abstract Lcn/damai/commonbusiness/address/contract/AddAddressContract;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/address/contract/AddAddressContract$Presenter;,
        Lcn/damai/commonbusiness/address/contract/AddAddressContract$View;,
        Lcn/damai/commonbusiness/address/contract/AddAddressContract$Model;
    }
.end annotation
