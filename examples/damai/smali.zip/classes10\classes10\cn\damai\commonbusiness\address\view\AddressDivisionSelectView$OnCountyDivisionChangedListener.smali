.class public interface abstract Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnCountyDivisionChangedListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnCountyDivisionChangedListener"
.end annotation


# virtual methods
.method public abstract onCountyDivisionChanged(Lcn/damai/commonbusiness/address/bean/DivisionBean;)V
.end method
