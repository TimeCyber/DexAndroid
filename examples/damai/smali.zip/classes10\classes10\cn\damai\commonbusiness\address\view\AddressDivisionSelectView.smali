.class public Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;
.super Landroid/widget/FrameLayout;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnCountyDivisionChangedListener;,
        Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnCityDivisionChangedListener;,
        Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnProvinceDivisionChangedListener;,
        Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnProvinceCityCountySelectedListener;
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private isCityScrolling:Z

.field private isCountyScrolling:Z

.field private isProvinceScrolling:Z

.field private mCityDivisionAdapter:Ltb/t81;

.field private mCityDivisionList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/address/bean/DivisionBean;",
            ">;"
        }
    .end annotation
.end field

.field private mCountyDivisionAdapter:Ltb/t81;

.field private mCountyDivisionList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/address/bean/DivisionBean;",
            ">;"
        }
    .end annotation
.end field

.field private mOnCityDivisionChangedListener:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnCityDivisionChangedListener;

.field private mOnCityWheelScrollListener:Lcn/damai/uikit/wheel/OnWheelScrollListener;

.field private mOnCompletedClickListener:Landroid/view/View$OnClickListener;

.field private mOnCountyDivisionChangedListener:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnCountyDivisionChangedListener;

.field private mOnCountyWheelScrollListener:Lcn/damai/uikit/wheel/OnWheelScrollListener;

.field private mOnProvinceCityCountySelectedListener:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnProvinceCityCountySelectedListener;

.field private mOnProvinceDivisionChangedListener:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnProvinceDivisionChangedListener;

.field private mOnProvinceWheelScrollListener:Lcn/damai/uikit/wheel/OnWheelScrollListener;

.field private mProvinceDivisionAdapter:Ltb/t81;

.field private mProvinceDivisionList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/address/bean/DivisionBean;",
            ">;"
        }
    .end annotation
.end field

.field private mSelectedCity:Lcn/damai/commonbusiness/address/bean/DivisionBean;

.field private mSelectedCounty:Lcn/damai/commonbusiness/address/bean/DivisionBean;

.field private mSelectedProvince:Lcn/damai/commonbusiness/address/bean/DivisionBean;

.field private mTvCancel:Landroid/widget/TextView;

.field private mTvConfirm:Landroid/widget/TextView;

.field private mWheelViewCity:Lcn/damai/uikit/wheel/WheelView;

.field private mWheelViewCounty:Lcn/damai/uikit/wheel/WheelView;

.field private mWheelViewProvince:Lcn/damai/uikit/wheel/WheelView;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 2
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->init(Landroid/content/Context;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 3
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .line 3
    invoke-direct {p0, p1, p2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 4
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->init(Landroid/content/Context;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .line 5
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 6
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->init(Landroid/content/Context;)V

    return-void
.end method

.method static synthetic access$000(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;)Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnProvinceCityCountySelectedListener;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mOnProvinceCityCountySelectedListener:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnProvinceCityCountySelectedListener;

    return-object p0
.end method

.method static synthetic access$100(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;)Z
    .registers 1

    .line 1
    iget-boolean p0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->isProvinceScrolling:Z

    return p0
.end method

.method static synthetic access$1000(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;)Ljava/util/List;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mCountyDivisionList:Ljava/util/List;

    return-object p0
.end method

.method static synthetic access$102(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;Z)Z
    .registers 2

    .line 1
    iput-boolean p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->isProvinceScrolling:Z

    return p1
.end method

.method static synthetic access$200(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;)Z
    .registers 1

    .line 1
    iget-boolean p0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->isCityScrolling:Z

    return p0
.end method

.method static synthetic access$202(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;Z)Z
    .registers 2

    .line 1
    iput-boolean p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->isCityScrolling:Z

    return p1
.end method

.method static synthetic access$300(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;)Z
    .registers 1

    .line 1
    iget-boolean p0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->isCountyScrolling:Z

    return p0
.end method

.method static synthetic access$302(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;Z)Z
    .registers 2

    .line 1
    iput-boolean p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->isCountyScrolling:Z

    return p1
.end method

.method static synthetic access$400(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;)Lcn/damai/commonbusiness/address/bean/DivisionBean;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedProvince:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    return-object p0
.end method

.method static synthetic access$500(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;)Lcn/damai/commonbusiness/address/bean/DivisionBean;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedCity:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    return-object p0
.end method

.method static synthetic access$600(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;)Lcn/damai/commonbusiness/address/bean/DivisionBean;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedCounty:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    return-object p0
.end method

.method static synthetic access$602(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;Lcn/damai/commonbusiness/address/bean/DivisionBean;)Lcn/damai/commonbusiness/address/bean/DivisionBean;
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedCounty:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    return-object p1
.end method

.method static synthetic access$700(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;)Lcn/damai/uikit/wheel/WheelView;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mWheelViewProvince:Lcn/damai/uikit/wheel/WheelView;

    return-object p0
.end method

.method static synthetic access$800(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->updateCityBySelectedProvince(I)V

    return-void
.end method

.method static synthetic access$900(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->updateCountyBySelectedCity(I)V

    return-void
.end method

.method private getSelectedDivisionIndex(Ljava/util/List;Lcn/damai/commonbusiness/address/bean/DivisionBean;)I
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/address/bean/DivisionBean;",
            ">;",
            "Lcn/damai/commonbusiness/address/bean/DivisionBean;",
            ")I"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "15"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_21

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    return p1

    :cond_21
    if-eqz p2, :cond_4a

    .line 1
    invoke-virtual {p2}, Lcn/damai/commonbusiness/address/bean/DivisionBean;->getDivisionId()Ljava/lang/String;

    move-result-object p2

    .line 2
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_4a

    .line 3
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_32
    if-ge v1, v0, :cond_4a

    .line 4
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/damai/commonbusiness/address/bean/DivisionBean;

    if-eqz v2, :cond_47

    .line 5
    invoke-virtual {v2}, Lcn/damai/commonbusiness/address/bean/DivisionBean;->getDivisionId()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p2, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_47

    return v1

    :cond_47
    add-int/lit8 v1, v1, 0x1

    goto :goto_32

    :cond_4a
    return v3
.end method

.method private init(Landroid/content/Context;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p1

    sget v0, Lcom/alibaba/pictures/picturesbiz/R$layout;->common_business_select_division_layout:I

    invoke-virtual {p1, v0, p0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    .line 2
    sget p1, Lcom/alibaba/pictures/picturesbiz/R$id;->common_business_division_select_cancel_tv:I

    invoke-virtual {p0, p1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mTvCancel:Landroid/widget/TextView;

    .line 3
    sget p1, Lcom/alibaba/pictures/picturesbiz/R$id;->common_business_division_select_completed_tv:I

    invoke-virtual {p0, p1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mTvConfirm:Landroid/widget/TextView;

    .line 4
    sget p1, Lcom/alibaba/pictures/picturesbiz/R$id;->common_business_province_wheel_view:I

    invoke-virtual {p0, p1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Lcn/damai/uikit/wheel/WheelView;

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mWheelViewProvince:Lcn/damai/uikit/wheel/WheelView;

    .line 5
    sget p1, Lcom/alibaba/pictures/picturesbiz/R$id;->common_business_city_wheel_view:I

    invoke-virtual {p0, p1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Lcn/damai/uikit/wheel/WheelView;

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mWheelViewCity:Lcn/damai/uikit/wheel/WheelView;

    .line 6
    sget p1, Lcom/alibaba/pictures/picturesbiz/R$id;->common_business_county_wheel_view:I

    invoke-virtual {p0, p1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Lcn/damai/uikit/wheel/WheelView;

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mWheelViewCounty:Lcn/damai/uikit/wheel/WheelView;

    .line 7
    invoke-direct {p0}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->initListeners()V

    .line 8
    invoke-direct {p0}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->setupListeners()V

    return-void
.end method

.method private initListeners()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    new-instance v0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$a;

    invoke-direct {v0, p0}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$a;-><init>(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;)V

    iput-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mOnCompletedClickListener:Landroid/view/View$OnClickListener;

    .line 2
    new-instance v0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$b;

    invoke-direct {v0, p0}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$b;-><init>(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;)V

    iput-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mOnProvinceWheelScrollListener:Lcn/damai/uikit/wheel/OnWheelScrollListener;

    .line 3
    new-instance v0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$c;

    invoke-direct {v0, p0}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$c;-><init>(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;)V

    iput-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mOnCityWheelScrollListener:Lcn/damai/uikit/wheel/OnWheelScrollListener;

    .line 4
    new-instance v0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$d;

    invoke-direct {v0, p0}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$d;-><init>(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;)V

    iput-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mOnCountyWheelScrollListener:Lcn/damai/uikit/wheel/OnWheelScrollListener;

    return-void
.end method

.method private resetData()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "14"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_14
    const/4 v0, 0x0

    .line 1
    iput-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mProvinceDivisionList:Ljava/util/List;

    .line 2
    iput-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedProvince:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    .line 3
    iput-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mCityDivisionList:Ljava/util/List;

    .line 4
    iput-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedCity:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    .line 5
    iput-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mCountyDivisionList:Ljava/util/List;

    .line 6
    iput-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedCounty:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    return-void
.end method

.method private setupListeners()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mTvConfirm:Landroid/widget/TextView;

    iget-object v1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mOnCompletedClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mWheelViewProvince:Lcn/damai/uikit/wheel/WheelView;

    iget-object v1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mOnProvinceWheelScrollListener:Lcn/damai/uikit/wheel/OnWheelScrollListener;

    invoke-virtual {v0, v1}, Lcn/damai/uikit/wheel/WheelView;->addScrollingListener(Lcn/damai/uikit/wheel/OnWheelScrollListener;)V

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mWheelViewCity:Lcn/damai/uikit/wheel/WheelView;

    iget-object v1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mOnCityWheelScrollListener:Lcn/damai/uikit/wheel/OnWheelScrollListener;

    invoke-virtual {v0, v1}, Lcn/damai/uikit/wheel/WheelView;->addScrollingListener(Lcn/damai/uikit/wheel/OnWheelScrollListener;)V

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mWheelViewCounty:Lcn/damai/uikit/wheel/WheelView;

    iget-object v1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mOnCountyWheelScrollListener:Lcn/damai/uikit/wheel/OnWheelScrollListener;

    invoke-virtual {v0, v1}, Lcn/damai/uikit/wheel/WheelView;->addScrollingListener(Lcn/damai/uikit/wheel/OnWheelScrollListener;)V

    return-void
.end method

.method private updateCityBySelectedProvince(I)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mProvinceDivisionList:Ljava/util/List;

    if-eqz v0, :cond_4f

    .line 2
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/address/bean/DivisionBean;

    if-eqz p1, :cond_4f

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedProvince:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    if-nez v0, :cond_2e

    .line 4
    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedProvince:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    goto :goto_46

    .line 5
    :cond_2e
    invoke-virtual {p1}, Lcn/damai/commonbusiness/address/bean/DivisionBean;->getDivisionId()Ljava/lang/String;

    move-result-object v0

    .line 6
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_46

    iget-object v1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedProvince:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    invoke-virtual {v1}, Lcn/damai/commonbusiness/address/bean/DivisionBean;->getDivisionId()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_46

    .line 7
    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedProvince:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    .line 8
    :cond_46
    :goto_46
    iget-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mOnProvinceDivisionChangedListener:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnProvinceDivisionChangedListener;

    if-eqz p1, :cond_4f

    .line 9
    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedProvince:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    invoke-interface {p1, v0}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnProvinceDivisionChangedListener;->onProvinceDivisionChanged(Lcn/damai/commonbusiness/address/bean/DivisionBean;)V

    :cond_4f
    return-void
.end method

.method private updateCountyBySelectedCity(I)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mCityDivisionList:Ljava/util/List;

    if-eqz v0, :cond_59

    if-ltz p1, :cond_59

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-ge p1, v0, :cond_59

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mCityDivisionList:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/address/bean/DivisionBean;

    if-eqz p1, :cond_59

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedCity:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    if-nez v0, :cond_38

    .line 4
    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedCity:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    goto :goto_50

    .line 5
    :cond_38
    invoke-virtual {p1}, Lcn/damai/commonbusiness/address/bean/DivisionBean;->getDivisionId()Ljava/lang/String;

    move-result-object v0

    .line 6
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_50

    iget-object v1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedCity:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    invoke-virtual {v1}, Lcn/damai/commonbusiness/address/bean/DivisionBean;->getDivisionId()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_50

    .line 7
    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedCity:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    .line 8
    :cond_50
    :goto_50
    iget-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mOnCityDivisionChangedListener:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnCityDivisionChangedListener;

    if-eqz p1, :cond_59

    .line 9
    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedCity:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    invoke-interface {p1, v0}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnCityDivisionChangedListener;->onCityDivisionChanged(Lcn/damai/commonbusiness/address/bean/DivisionBean;)V

    :cond_59
    return-void
.end method


# virtual methods
.method public setCityList(Ljava/util/List;Lcn/damai/commonbusiness/address/bean/DivisionBean;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/address/bean/DivisionBean;",
            ">;",
            "Lcn/damai/commonbusiness/address/bean/DivisionBean;",
            ")V"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "12"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_1a
    if-eqz p1, :cond_55

    .line 1
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-lez v0, :cond_55

    .line 2
    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mCityDivisionList:Ljava/util/List;

    .line 3
    new-instance p1, Ltb/t81;

    invoke-virtual {p0}, Landroid/widget/FrameLayout;->getContext()Landroid/content/Context;

    move-result-object v0

    iget-object v1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mCityDivisionList:Ljava/util/List;

    invoke-direct {p1, v0, v1}, Ltb/t81;-><init>(Landroid/content/Context;Ljava/util/List;)V

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mCityDivisionAdapter:Ltb/t81;

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mWheelViewCity:Lcn/damai/uikit/wheel/WheelView;

    invoke-virtual {v0, p1}, Lcn/damai/uikit/wheel/WheelView;->setViewAdapter(Lcn/damai/uikit/wheel/adapters/WheelViewAdapter;)V

    .line 5
    iget-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mCityDivisionList:Ljava/util/List;

    invoke-direct {p0, p1, p2}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->getSelectedDivisionIndex(Ljava/util/List;Lcn/damai/commonbusiness/address/bean/DivisionBean;)I

    move-result p1

    .line 6
    iget-object p2, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mWheelViewCity:Lcn/damai/uikit/wheel/WheelView;

    invoke-virtual {p2, p1}, Lcn/damai/uikit/wheel/WheelView;->setCurrentItem(I)V

    .line 7
    iget-object p2, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mCityDivisionList:Ljava/util/List;

    invoke-interface {p2, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/address/bean/DivisionBean;

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedCity:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    .line 8
    iget-object p2, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mOnCityDivisionChangedListener:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnCityDivisionChangedListener;

    if-eqz p2, :cond_71

    if-eqz p1, :cond_71

    .line 9
    invoke-interface {p2, p1}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnCityDivisionChangedListener;->onCityDivisionChanged(Lcn/damai/commonbusiness/address/bean/DivisionBean;)V

    goto :goto_71

    .line 10
    :cond_55
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mCityDivisionList:Ljava/util/List;

    .line 11
    new-instance p1, Ltb/t81;

    invoke-virtual {p0}, Landroid/widget/FrameLayout;->getContext()Landroid/content/Context;

    move-result-object p2

    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mCityDivisionList:Ljava/util/List;

    invoke-direct {p1, p2, v0}, Ltb/t81;-><init>(Landroid/content/Context;Ljava/util/List;)V

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mCityDivisionAdapter:Ltb/t81;

    .line 12
    iget-object p2, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mWheelViewCity:Lcn/damai/uikit/wheel/WheelView;

    invoke-virtual {p2, p1}, Lcn/damai/uikit/wheel/WheelView;->setViewAdapter(Lcn/damai/uikit/wheel/adapters/WheelViewAdapter;)V

    const/4 p1, 0x0

    .line 13
    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedCity:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    :cond_71
    :goto_71
    return-void
.end method

.method public setCountyList(Ljava/util/List;Lcn/damai/commonbusiness/address/bean/DivisionBean;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/address/bean/DivisionBean;",
            ">;",
            "Lcn/damai/commonbusiness/address/bean/DivisionBean;",
            ")V"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "13"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_1a
    if-eqz p1, :cond_80

    .line 1
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-lez v0, :cond_80

    .line 2
    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mCountyDivisionList:Ljava/util/List;

    .line 3
    new-instance p1, Ltb/t81;

    invoke-virtual {p0}, Landroid/widget/FrameLayout;->getContext()Landroid/content/Context;

    move-result-object v0

    iget-object v1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mCountyDivisionList:Ljava/util/List;

    invoke-direct {p1, v0, v1}, Ltb/t81;-><init>(Landroid/content/Context;Ljava/util/List;)V

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mCountyDivisionAdapter:Ltb/t81;

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mWheelViewCounty:Lcn/damai/uikit/wheel/WheelView;

    invoke-virtual {v0, p1}, Lcn/damai/uikit/wheel/WheelView;->setViewAdapter(Lcn/damai/uikit/wheel/adapters/WheelViewAdapter;)V

    .line 5
    iget-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mCountyDivisionList:Ljava/util/List;

    invoke-direct {p0, p1, p2}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->getSelectedDivisionIndex(Ljava/util/List;Lcn/damai/commonbusiness/address/bean/DivisionBean;)I

    move-result p1

    .line 6
    iget-object p2, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mWheelViewCounty:Lcn/damai/uikit/wheel/WheelView;

    invoke-virtual {p2, p1}, Lcn/damai/uikit/wheel/WheelView;->setCurrentItem(I)V

    .line 7
    iget-object p2, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mCountyDivisionList:Ljava/util/List;

    invoke-interface {p2, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/address/bean/DivisionBean;

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedCounty:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    .line 8
    iget-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedCity:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    if-eqz p1, :cond_74

    .line 9
    invoke-virtual {p1}, Lcn/damai/commonbusiness/address/bean/DivisionBean;->getDivisionName()Ljava/lang/String;

    move-result-object p1

    iget-object p2, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedCounty:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    invoke-virtual {p2}, Lcn/damai/commonbusiness/address/bean/DivisionBean;->getDivisionName()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_74

    .line 10
    new-instance p1, Ltb/t81;

    invoke-virtual {p0}, Landroid/widget/FrameLayout;->getContext()Landroid/content/Context;

    move-result-object p2

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-direct {p1, p2, v0}, Ltb/t81;-><init>(Landroid/content/Context;Ljava/util/List;)V

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mCountyDivisionAdapter:Ltb/t81;

    .line 11
    iget-object p2, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mWheelViewCounty:Lcn/damai/uikit/wheel/WheelView;

    invoke-virtual {p2, p1}, Lcn/damai/uikit/wheel/WheelView;->setViewAdapter(Lcn/damai/uikit/wheel/adapters/WheelViewAdapter;)V

    .line 12
    :cond_74
    iget-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mOnCountyDivisionChangedListener:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnCountyDivisionChangedListener;

    if-eqz p1, :cond_9c

    iget-object p2, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedCounty:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    if-eqz p2, :cond_9c

    .line 13
    invoke-interface {p1, p2}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnCountyDivisionChangedListener;->onCountyDivisionChanged(Lcn/damai/commonbusiness/address/bean/DivisionBean;)V

    goto :goto_9c

    :cond_80
    const/4 p1, 0x0

    .line 14
    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedCounty:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    .line 15
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mCountyDivisionList:Ljava/util/List;

    .line 16
    new-instance p1, Ltb/t81;

    invoke-virtual {p0}, Landroid/widget/FrameLayout;->getContext()Landroid/content/Context;

    move-result-object p2

    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mCountyDivisionList:Ljava/util/List;

    invoke-direct {p1, p2, v0}, Ltb/t81;-><init>(Landroid/content/Context;Ljava/util/List;)V

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mCountyDivisionAdapter:Ltb/t81;

    .line 17
    iget-object p2, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mWheelViewCounty:Lcn/damai/uikit/wheel/WheelView;

    invoke-virtual {p2, p1}, Lcn/damai/uikit/wheel/WheelView;->setViewAdapter(Lcn/damai/uikit/wheel/adapters/WheelViewAdapter;)V

    :cond_9c
    :goto_9c
    return-void
.end method

.method public setOnCancelClickListener(Landroid/view/View$OnClickListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mTvCancel:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method public setOnCityDivisionChangedListener(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnCityDivisionChangedListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "9"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mOnCityDivisionChangedListener:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnCityDivisionChangedListener;

    return-void
.end method

.method public setOnCountyDivisionChangedListener(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnCountyDivisionChangedListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "10"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mOnCountyDivisionChangedListener:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnCountyDivisionChangedListener;

    return-void
.end method

.method public setOnDivisionsSelectedListener(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnProvinceCityCountySelectedListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "7"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mOnProvinceCityCountySelectedListener:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnProvinceCityCountySelectedListener;

    return-void
.end method

.method public setOnProvinceDivisionChangedListener(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnProvinceDivisionChangedListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "8"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mOnProvinceDivisionChangedListener:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnProvinceDivisionChangedListener;

    return-void
.end method

.method public setProvinceList(Ljava/util/List;Lcn/damai/commonbusiness/address/bean/DivisionBean;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/address/bean/DivisionBean;",
            ">;",
            "Lcn/damai/commonbusiness/address/bean/DivisionBean;",
            ")V"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "11"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_1a
    if-eqz p1, :cond_55

    .line 1
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-lez v0, :cond_55

    .line 2
    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mProvinceDivisionList:Ljava/util/List;

    .line 3
    new-instance p1, Ltb/t81;

    invoke-virtual {p0}, Landroid/widget/FrameLayout;->getContext()Landroid/content/Context;

    move-result-object v0

    iget-object v1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mProvinceDivisionList:Ljava/util/List;

    invoke-direct {p1, v0, v1}, Ltb/t81;-><init>(Landroid/content/Context;Ljava/util/List;)V

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mProvinceDivisionAdapter:Ltb/t81;

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mWheelViewProvince:Lcn/damai/uikit/wheel/WheelView;

    invoke-virtual {v0, p1}, Lcn/damai/uikit/wheel/WheelView;->setViewAdapter(Lcn/damai/uikit/wheel/adapters/WheelViewAdapter;)V

    .line 5
    iget-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mProvinceDivisionList:Ljava/util/List;

    invoke-direct {p0, p1, p2}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->getSelectedDivisionIndex(Ljava/util/List;Lcn/damai/commonbusiness/address/bean/DivisionBean;)I

    move-result p1

    .line 6
    iget-object p2, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mWheelViewProvince:Lcn/damai/uikit/wheel/WheelView;

    invoke-virtual {p2, p1}, Lcn/damai/uikit/wheel/WheelView;->setCurrentItem(I)V

    .line 7
    iget-object p2, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mProvinceDivisionList:Ljava/util/List;

    invoke-interface {p2, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/address/bean/DivisionBean;

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedProvince:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    .line 8
    iget-object p2, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mOnProvinceDivisionChangedListener:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnProvinceDivisionChangedListener;

    if-eqz p2, :cond_73

    if-eqz p1, :cond_73

    .line 9
    invoke-interface {p2, p1}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnProvinceDivisionChangedListener;->onProvinceDivisionChanged(Lcn/damai/commonbusiness/address/bean/DivisionBean;)V

    goto :goto_73

    .line 10
    :cond_55
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mProvinceDivisionList:Ljava/util/List;

    .line 11
    new-instance p1, Ltb/t81;

    invoke-virtual {p0}, Landroid/widget/FrameLayout;->getContext()Landroid/content/Context;

    move-result-object p2

    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mProvinceDivisionList:Ljava/util/List;

    invoke-direct {p1, p2, v0}, Ltb/t81;-><init>(Landroid/content/Context;Ljava/util/List;)V

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mProvinceDivisionAdapter:Ltb/t81;

    .line 12
    iget-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mWheelViewProvince:Lcn/damai/uikit/wheel/WheelView;

    iget-object p2, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mCityDivisionAdapter:Ltb/t81;

    invoke-virtual {p1, p2}, Lcn/damai/uikit/wheel/WheelView;->setViewAdapter(Lcn/damai/uikit/wheel/adapters/WheelViewAdapter;)V

    const/4 p1, 0x0

    .line 13
    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedProvince:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    :cond_73
    :goto_73
    return-void
.end method
