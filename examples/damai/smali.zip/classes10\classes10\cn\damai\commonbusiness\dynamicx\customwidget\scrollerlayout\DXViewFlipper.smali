.class public Lcn/damai/commonbusiness/dynamicx/customwidget/scrollerlayout/DXViewFlipper;
.super Landroid/widget/FrameLayout;
.source "Taobao"


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private marqueeView:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;

.field private width:I


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param

    .line 1
    invoke-direct {p0, p1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 2
    invoke-direct {p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scrollerlayout/DXViewFlipper;->initView()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .line 3
    invoke-direct {p0, p1, p2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 4
    invoke-direct {p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scrollerlayout/DXViewFlipper;->initView()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .line 5
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 6
    invoke-direct {p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scrollerlayout/DXViewFlipper;->initView()V

    return-void
.end method

.method private createView(Lcom/alibaba/fastjson/JSONObject;)Landroid/view/View;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scrollerlayout/DXViewFlipper;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/view/View;

    return-object p1

    :cond_1a
    const/4 v0, 0x0

    if-nez p1, :cond_1e

    return-object v0

    .line 8
    :cond_1e
    invoke-virtual {p0}, Landroid/widget/FrameLayout;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v1

    sget v2, Lcom/alibaba/pictures/picturesbiz/R$layout;->homepage_video_item_artist:I

    invoke-virtual {v1, v2, v0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    .line 9
    sget v1, Lcom/alibaba/pictures/picturesbiz/R$id;->user_head_single_name:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    const-string v2, "name"

    .line 10
    invoke-virtual {p1, v2}, Lcom/alibaba/fastjson/JSONObject;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_43

    .line 11
    invoke-virtual {p1, v2}, Lcom/alibaba/fastjson/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 12
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 13
    :cond_43
    sget v1, Lcom/alibaba/pictures/picturesbiz/R$id;->user_head_single:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    const-string v2, "headPic"

    .line 14
    invoke-virtual {p1, v2}, Lcom/alibaba/fastjson/JSONObject;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_5a

    .line 15
    invoke-virtual {p1, v2}, Lcom/alibaba/fastjson/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 16
    invoke-direct {p0, p1, v1}, Lcn/damai/commonbusiness/dynamicx/customwidget/scrollerlayout/DXViewFlipper;->loadHead(Ljava/lang/String;Landroid/widget/ImageView;)V

    :cond_5a
    return-object v0
.end method

.method private initView()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scrollerlayout/DXViewFlipper;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    sget-object v0, Ltb/oa;->INSTANCE:Ltb/oa;

    invoke-virtual {v0}, Ltb/oa;->getApplication()Landroid/app/Application;

    move-result-object v0

    const/high16 v1, 0x41a00000    # 20.0f

    invoke-static {v0, v1}, Ltb/g95;->a(Landroid/content/Context;F)I

    move-result v0

    iput v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scrollerlayout/DXViewFlipper;->width:I

    .line 2
    invoke-virtual {p0}, Landroid/widget/FrameLayout;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    sget v1, Lcom/alibaba/pictures/picturesbiz/R$layout;->layout_mult_artist:I

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;

    iput-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scrollerlayout/DXViewFlipper;->marqueeView:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;

    .line 3
    invoke-virtual {p0, v0}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V

    return-void
.end method

.method private loadHead(Ljava/lang/String;Landroid/widget/ImageView;)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scrollerlayout/DXViewFlipper;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1a
    invoke-static {}, Ltb/n73;->x()Ltb/n73;

    move-result-object v0

    iget v1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scrollerlayout/DXViewFlipper;->width:I

    invoke-virtual {v0, p1, v1, v1}, Ltb/n73;->p(Ljava/lang/String;II)Ltb/n73;

    move-result-object p1

    sget v0, Lcom/alibaba/pictures/picturesbiz/R$drawable;->uikit_user_default_icon_trans_white:I

    .line 2
    invoke-virtual {p1, v0}, Ltb/n73;->t(I)Ltb/n73;

    move-result-object p1

    .line 3
    invoke-virtual {p1, v0}, Ltb/n73;->h(I)Ltb/n73;

    move-result-object p1

    .line 4
    invoke-virtual {p1}, Ltb/n73;->f()Ltb/n73;

    move-result-object p1

    .line 5
    invoke-virtual {p1, p2}, Ltb/n73;->l(Landroid/widget/ImageView;)V

    return-void
.end method


# virtual methods
.method public createView(Lcom/alibaba/fastjson/JSONArray;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scrollerlayout/DXViewFlipper;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-static {p1}, Ltb/wm2;->b(Lcom/alibaba/fastjson/JSONArray;)I

    move-result v0

    .line 2
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 3
    invoke-interface {v1}, Ljava/util/List;->clear()V

    :goto_23
    if-ge v3, v0, :cond_38

    .line 4
    invoke-virtual {p1, v3}, Lcom/alibaba/fastjson/JSONArray;->getJSONObject(I)Lcom/alibaba/fastjson/JSONObject;

    move-result-object v2

    if-nez v2, :cond_2c

    goto :goto_35

    .line 5
    :cond_2c
    invoke-direct {p0, v2}, Lcn/damai/commonbusiness/dynamicx/customwidget/scrollerlayout/DXViewFlipper;->createView(Lcom/alibaba/fastjson/JSONObject;)Landroid/view/View;

    move-result-object v2

    if-eqz v2, :cond_35

    .line 6
    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_35
    :goto_35
    add-int/lit8 v3, v3, 0x1

    goto :goto_23

    .line 7
    :cond_38
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scrollerlayout/DXViewFlipper;->marqueeView:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;

    invoke-virtual {p1, v1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;->setItems(Ljava/util/List;)V

    return-void
.end method

.method public setAnimateTime(J)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scrollerlayout/DXViewFlipper;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scrollerlayout/DXViewFlipper;->marqueeView:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;

    if-eqz v0, :cond_2a

    const-wide/16 v1, 0x0

    cmp-long v3, p1, v1

    if-gtz v3, :cond_27

    const-wide/16 p1, 0x1f4

    .line 2
    :cond_27
    invoke-virtual {v0, p1, p2}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;->setAnimationDuration(J)V

    :cond_2a
    return-void
.end method

.method public setInterval(I)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scrollerlayout/DXViewFlipper;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scrollerlayout/DXViewFlipper;->marqueeView:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;

    if-eqz v0, :cond_26

    if-gtz p1, :cond_23

    const/16 p1, 0xbb8

    .line 2
    :cond_23
    invoke-virtual {v0, p1}, Landroid/widget/ViewFlipper;->setFlipInterval(I)V

    :cond_26
    return-void
.end method
