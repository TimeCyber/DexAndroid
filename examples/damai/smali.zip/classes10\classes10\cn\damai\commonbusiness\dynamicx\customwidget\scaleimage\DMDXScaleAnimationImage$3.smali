.class public Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$3;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic this$0:Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$3;->this$0:Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$3;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_14

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$3;->this$0:Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;

    # getter for: Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->isAttachedToWindow:Z
    invoke-static {v0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->access$500(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)Z

    move-result v0

    if-nez v0, :cond_1d

    return-void

    .line 2
    :cond_1d
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$3;->this$0:Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;

    # getter for: Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageList:Ljava/util/List;
    invoke-static {v0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->access$000(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)Ljava/util/List;

    move-result-object v0

    invoke-static {v0}, Ltb/ck5;->a(Ljava/util/Collection;)I

    move-result v0

    if-le v0, v3, :cond_56

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$3;->this$0:Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;

    # getter for: Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->index:I
    invoke-static {v0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->access$600(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)I

    move-result v1

    iget-object v2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$3;->this$0:Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;

    # getter for: Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageList:Ljava/util/List;
    invoke-static {v2}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->access$000(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)Ljava/util/List;

    move-result-object v2

    invoke-static {v2}, Ltb/mw5;->f(Ljava/util/List;)I

    move-result v2

    rem-int/2addr v1, v2

    # setter for: Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->index:I
    invoke-static {v0, v1}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->access$602(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;I)I

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$3;->this$0:Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;

    # getter for: Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageHandler:Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$b;
    invoke-static {v0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->access$700(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$b;

    move-result-object v0

    iget-object v1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$3;->this$0:Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;

    # getter for: Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->index:I
    invoke-static {v1}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->access$600(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$3;->this$0:Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;

    # operator++ for: Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->index:I
    invoke-static {v0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->access$608(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)I

    .line 6
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$3;->this$0:Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;

    invoke-virtual {v0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->startAnimationV2()V

    :cond_56
    return-void
.end method
