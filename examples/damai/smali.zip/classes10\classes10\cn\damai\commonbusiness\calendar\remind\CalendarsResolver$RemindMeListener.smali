.class public interface abstract Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver$RemindMeListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "RemindMeListener"
.end annotation


# virtual methods
.method public abstract addRemindmeSuccess()V
.end method

.method public abstract candelRemindmeSuccess()V
.end method
