.class public interface abstract Lcn/damai/commonbusiness/pageut/PageUtExecutor$FragmentPropertiesProvider;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/pageut/PageUtExecutor;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "FragmentPropertiesProvider"
.end annotation


# virtual methods
.method public abstract get(Ljava/lang/String;)Ljava/util/Map;
.end method

.method public abstract put(Ljava/lang/String;Ljava/util/Map;)V
.end method
