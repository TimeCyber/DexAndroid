.class public Lcn/damai/commonbusiness/base/PermissionsHelper$1;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/lang/Runnable;


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic val$activity:Landroid/app/Activity;

.field final synthetic val$permissionTypeMessage:Ljava/lang/String;


# direct methods
.method constructor <init>(Landroid/app/Activity;Ljava/lang/String;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/base/PermissionsHelper$1;->val$activity:Landroid/app/Activity;

    iput-object p2, p0, Lcn/damai/commonbusiness/base/PermissionsHelper$1;->val$permissionTypeMessage:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static synthetic a(Landroid/app/Activity;Landroid/content/DialogInterface;I)V
    .registers 3

    invoke-static {p0, p1, p2}, Lcn/damai/commonbusiness/base/PermissionsHelper$1;->lambda$run$0(Landroid/app/Activity;Landroid/content/DialogInterface;I)V

    return-void
.end method

.method private static synthetic lambda$run$0(Landroid/app/Activity;Landroid/content/DialogInterface;I)V
    .registers 4

    .line 1
    new-instance p1, Landroid/content/Intent;

    const-string p2, "android.settings.APPLICATION_DETAILS_SETTINGS"

    invoke-direct {p1, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 2
    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "package:"

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Landroid/app/Activity;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {p2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 3
    invoke-virtual {p0, p1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/base/PermissionsHelper$1;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_14

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    new-instance v0, Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;

    iget-object v1, p0, Lcn/damai/commonbusiness/base/PermissionsHelper$1;->val$activity:Landroid/app/Activity;

    invoke-direct {v0, v1}, Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;-><init>(Landroid/content/Context;)V

    sget-object v1, Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog$TMDialogPermissionType;->THEME_PERMISSION_NOTIFICATION:Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog$TMDialogPermissionType;

    .line 2
    invoke-virtual {v0, v1}, Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;->u(Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog$TMDialogPermissionType;)Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;

    move-result-object v0

    .line 3
    invoke-virtual {v0, v3}, Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;->m(Z)Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;

    move-result-object v0

    iget-object v1, p0, Lcn/damai/commonbusiness/base/PermissionsHelper$1;->val$permissionTypeMessage:Ljava/lang/String;

    .line 4
    invoke-virtual {v0, v1}, Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;->q(Ljava/lang/CharSequence;)Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;

    move-result-object v0

    iget-object v1, p0, Lcn/damai/commonbusiness/base/PermissionsHelper$1;->val$activity:Landroid/app/Activity;

    new-instance v2, Ltb/c74;

    invoke-direct {v2, v1}, Ltb/c74;-><init>(Landroid/app/Activity;)V

    const-string v1, "\u53bb\u8bbe\u7f6e"

    .line 5
    invoke-virtual {v0, v1, v2}, Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;->o(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;

    move-result-object v0

    const/4 v1, 0x0

    const-string v2, "\u4e0d\u518d\u63d0\u793a"

    .line 6
    invoke-virtual {v0, v2, v1}, Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;->k(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;

    move-result-object v0

    .line 7
    invoke-virtual {v0}, Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;->show()V

    return-void
.end method
