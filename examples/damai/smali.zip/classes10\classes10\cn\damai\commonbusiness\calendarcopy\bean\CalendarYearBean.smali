.class public Lcn/damai/commonbusiness/calendarcopy/bean/CalendarYearBean;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = -0x437eb8e8270ec45L


# instance fields
.field public months:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/calendarcopy/bean/CalendarMonthBean;",
            ">;"
        }
    .end annotation
.end field

.field public year:I


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
