.class public interface abstract Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$OnImageSelectListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnImageSelectListener"
.end annotation


# virtual methods
.method public abstract OnImageSelect(Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;ZI)V
.end method
