.class public Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView$a;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;->setItems(Ljava/util/List;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:I

.field final synthetic b:Ljava/util/List;

.field final synthetic c:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;ILjava/util/List;)V
    .registers 4

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView$a;->c:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;

    iput p2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView$a;->a:I

    iput-object p3, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView$a;->b:Ljava/util/List;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView$a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView$a;->c:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;

    # getter for: Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;->onItemClickListener:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView$OnItemClickListener;
    invoke-static {p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;->access$000(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView$OnItemClickListener;

    move-result-object p1

    if-eqz p1, :cond_32

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView$a;->c:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;

    # getter for: Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;->onItemClickListener:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView$OnItemClickListener;
    invoke-static {p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;->access$000(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView$OnItemClickListener;

    move-result-object p1

    iget v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView$a;->a:I

    iget-object v1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView$a;->b:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    invoke-interface {p1, v0, v1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView$OnItemClickListener;->onItemClick(ILandroid/view/View;)V

    :cond_32
    return-void
.end method
