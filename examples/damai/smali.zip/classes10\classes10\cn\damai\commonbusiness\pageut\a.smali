.class public Lcn/damai/commonbusiness/pageut/a;
.super Ljava/lang/Object;
.source "Taobao"


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

.field private static final c:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lcn/damai/commonbusiness/pageut/a;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private a:Lcn/damai/common/user/a$b;

.field private b:Lcn/damai/common/user/a$b;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lcn/damai/commonbusiness/pageut/a;->c:Ljava/util/HashMap;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a(Landroid/app/Activity;)V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/pageut/a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "8"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    invoke-static {p0}, Lcn/damai/commonbusiness/pageut/a;->f(Landroid/app/Activity;)Lcn/damai/commonbusiness/pageut/a;

    move-result-object v0

    if-eqz v0, :cond_1d

    .line 2
    invoke-virtual {v0, p0}, Lcn/damai/commonbusiness/pageut/a;->c(Landroid/app/Activity;)V

    :cond_1d
    return-void
.end method

.method public static b(Landroid/app/Activity;)V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/pageut/a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "7"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    invoke-static {p0}, Lcn/damai/commonbusiness/pageut/a;->f(Landroid/app/Activity;)Lcn/damai/commonbusiness/pageut/a;

    move-result-object v0

    if-eqz v0, :cond_1d

    .line 2
    invoke-virtual {v0, p0}, Lcn/damai/commonbusiness/pageut/a;->d(Landroid/app/Activity;)V

    :cond_1d
    return-void
.end method

.method public static f(Landroid/app/Activity;)Lcn/damai/commonbusiness/pageut/a;
    .registers 5
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/pageut/a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "10"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcn/damai/commonbusiness/pageut/a;

    return-object p0

    :cond_17
    if-nez p0, :cond_1b

    const/4 p0, 0x0

    return-object p0

    .line 1
    :cond_1b
    sget-object v0, Lcn/damai/commonbusiness/pageut/a;->c:Ljava/util/HashMap;

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcn/damai/commonbusiness/pageut/a;

    return-object p0
.end method

.method public static h(Landroid/app/Activity;Lcn/damai/common/user/a$b;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/pageut/a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "9"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 p0, 0x1

    aput-object p1, v2, p0

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_17
    if-eqz p0, :cond_25

    if-nez p1, :cond_1c

    goto :goto_25

    .line 1
    :cond_1c
    invoke-static {p0}, Lcn/damai/commonbusiness/pageut/a;->f(Landroid/app/Activity;)Lcn/damai/commonbusiness/pageut/a;

    move-result-object v0

    if-eqz v0, :cond_25

    .line 2
    invoke-virtual {v0, p0, p1}, Lcn/damai/commonbusiness/pageut/a;->e(Landroid/app/Activity;Lcn/damai/common/user/a$b;)V

    :cond_25
    :goto_25
    return-void
.end method

.method public static i(Landroid/app/Activity;)V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/pageut/a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    sget-object v0, Lcn/damai/commonbusiness/pageut/a;->c:Ljava/util/HashMap;

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    new-instance v1, Lcn/damai/commonbusiness/pageut/a;

    invoke-direct {v1}, Lcn/damai/commonbusiness/pageut/a;-><init>()V

    invoke-virtual {v0, p0, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public static j(Landroid/app/Activity;)V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/pageut/a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    sget-object v0, Lcn/damai/commonbusiness/pageut/a;->c:Ljava/util/HashMap;

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public c(Landroid/app/Activity;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/pageut/a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/pageut/a;->a:Lcn/damai/common/user/a$b;

    if-eqz v0, :cond_24

    .line 2
    iput-object v0, p0, Lcn/damai/commonbusiness/pageut/a;->b:Lcn/damai/common/user/a$b;

    .line 3
    invoke-static {}, Lcn/damai/common/user/c;->d()Lcn/damai/common/user/c;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcn/damai/common/user/c;->o(Landroid/app/Activity;)V

    :cond_24
    const/4 p1, 0x0

    .line 4
    iput-object p1, p0, Lcn/damai/commonbusiness/pageut/a;->a:Lcn/damai/common/user/a$b;

    return-void
.end method

.method public d(Landroid/app/Activity;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/pageut/a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/pageut/a;->b:Lcn/damai/common/user/a$b;

    if-eqz v0, :cond_2f

    iget-object v0, p0, Lcn/damai/commonbusiness/pageut/a;->a:Lcn/damai/common/user/a$b;

    if-nez v0, :cond_2f

    .line 2
    invoke-static {}, Lcn/damai/common/user/c;->d()Lcn/damai/common/user/c;

    move-result-object v0

    iget-object v1, p0, Lcn/damai/commonbusiness/pageut/a;->b:Lcn/damai/common/user/a$b;

    invoke-virtual {v0, p1, v1}, Lcn/damai/common/user/c;->m(Landroid/app/Activity;Lcn/damai/common/user/a$b;)V

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/pageut/a;->b:Lcn/damai/common/user/a$b;

    iput-object p1, p0, Lcn/damai/commonbusiness/pageut/a;->a:Lcn/damai/common/user/a$b;

    const/4 p1, 0x0

    .line 4
    iput-object p1, p0, Lcn/damai/commonbusiness/pageut/a;->b:Lcn/damai/common/user/a$b;

    :cond_2f
    return-void
.end method

.method public e(Landroid/app/Activity;Lcn/damai/common/user/a$b;)V
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/pageut/a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1a
    iget-object v0, p0, Lcn/damai/commonbusiness/pageut/a;->a:Lcn/damai/common/user/a$b;

    if-nez v0, :cond_2b

    .line 2
    iput-object p2, p0, Lcn/damai/commonbusiness/pageut/a;->a:Lcn/damai/common/user/a$b;

    .line 3
    invoke-static {}, Lcn/damai/common/user/c;->d()Lcn/damai/common/user/c;

    move-result-object p2

    iget-object v0, p0, Lcn/damai/commonbusiness/pageut/a;->a:Lcn/damai/common/user/a$b;

    invoke-virtual {p2, p1, v0}, Lcn/damai/common/user/c;->m(Landroid/app/Activity;Lcn/damai/common/user/a$b;)V

    goto/16 :goto_d7

    :cond_2b
    if-eq v0, p2, :cond_d7

    .line 4
    instance-of v1, p1, Lcn/damai/commonbusiness/pageut/PageUtExecutor$FragmentPropertiesProvider;

    const-string v2, " ,page : "

    const-string v3, "abtest"

    if-eqz v1, :cond_7b

    .line 5
    move-object v4, p1

    check-cast v4, Lcn/damai/commonbusiness/pageut/PageUtExecutor$FragmentPropertiesProvider;

    invoke-virtual {v0}, Lcn/damai/common/user/a$b;->m()Lcn/damai/common/user/a;

    move-result-object v0

    invoke-virtual {v0}, Lcn/damai/common/user/a;->t()Ljava/lang/String;

    move-result-object v0

    invoke-interface {v4, v0}, Lcn/damai/commonbusiness/pageut/PageUtExecutor$FragmentPropertiesProvider;->get(Ljava/lang/String;)Ljava/util/Map;

    move-result-object v0

    if-eqz v0, :cond_76

    .line 6
    invoke-static {}, Lcn/damai/common/user/c;->d()Lcn/damai/common/user/c;

    move-result-object v4

    invoke-virtual {v4, p1, v0}, Lcn/damai/common/user/c;->F(Ljava/lang/Object;Ljava/util/Map;)V

    .line 7
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "doPageViewResume: 1 onFragmentyPause FragmentPropertiesProvider , size :"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-interface {v0}, Ljava/util/Map;->size()I

    move-result v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lcn/damai/commonbusiness/pageut/a;->a:Lcn/damai/common/user/a$b;

    invoke-virtual {v0}, Lcn/damai/common/user/a$b;->m()Lcn/damai/common/user/a;

    move-result-object v0

    invoke-virtual {v0}, Lcn/damai/common/user/a;->t()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_7b

    :cond_76
    const-string v0, "doPageViewResume: 2 onFragmentyPause FragmentPropertiesProvider , size null !!!"

    .line 8
    invoke-static {v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 9
    :cond_7b
    :goto_7b
    invoke-static {}, Lcn/damai/common/user/c;->d()Lcn/damai/common/user/c;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcn/damai/common/user/c;->o(Landroid/app/Activity;)V

    .line 10
    iget-object v0, p0, Lcn/damai/commonbusiness/pageut/a;->a:Lcn/damai/common/user/a$b;

    iput-object v0, p0, Lcn/damai/commonbusiness/pageut/a;->b:Lcn/damai/common/user/a$b;

    .line 11
    iput-object p2, p0, Lcn/damai/commonbusiness/pageut/a;->a:Lcn/damai/common/user/a$b;

    if-eqz v1, :cond_ce

    .line 12
    move-object v0, p1

    check-cast v0, Lcn/damai/commonbusiness/pageut/PageUtExecutor$FragmentPropertiesProvider;

    invoke-virtual {p2}, Lcn/damai/common/user/a$b;->m()Lcn/damai/common/user/a;

    move-result-object v1

    invoke-virtual {v1}, Lcn/damai/common/user/a;->t()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Lcn/damai/commonbusiness/pageut/PageUtExecutor$FragmentPropertiesProvider;->get(Ljava/lang/String;)Ljava/util/Map;

    move-result-object v0

    if-eqz v0, :cond_c9

    .line 13
    invoke-static {}, Lcn/damai/common/user/c;->d()Lcn/damai/common/user/c;

    move-result-object v1

    invoke-virtual {v1, p1, v0}, Lcn/damai/common/user/c;->F(Ljava/lang/Object;Ljava/util/Map;)V

    .line 14
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "doPageViewResume: 3 onFragmentResume FragmentPropertiesProvider , size :"

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-interface {v0}, Ljava/util/Map;->size()I

    move-result v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Lcn/damai/common/user/a$b;->m()Lcn/damai/common/user/a;

    move-result-object p2

    invoke-virtual {p2}, Lcn/damai/common/user/a;->t()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {v3, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_ce

    :cond_c9
    const-string p2, "doPageViewResume: 4 onFragmentResume FragmentPropertiesProvider , size null !!!"

    .line 15
    invoke-static {v3, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 16
    :cond_ce
    :goto_ce
    invoke-static {}, Lcn/damai/common/user/c;->d()Lcn/damai/common/user/c;

    move-result-object p2

    iget-object v0, p0, Lcn/damai/commonbusiness/pageut/a;->a:Lcn/damai/common/user/a$b;

    invoke-virtual {p2, p1, v0}, Lcn/damai/common/user/c;->m(Landroid/app/Activity;Lcn/damai/common/user/a$b;)V

    :cond_d7
    :goto_d7
    return-void
.end method

.method public g()Lcn/damai/common/user/a$b;
    .registers 5
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/pageut/a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/common/user/a$b;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/pageut/a;->a:Lcn/damai/common/user/a$b;

    return-object v0
.end method
