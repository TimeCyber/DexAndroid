.class public Lcn/damai/commonbusiness/fission/bean/FissionParam;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon; = null

.field private static final serialVersionUID:J = 0x1L


# instance fields
.field public channelType:Ljava/lang/String;

.field public imageUrl:Ljava/lang/String;

.field public loadingState:Ljava/lang/String;

.field public mainMessage:Ljava/lang/String;

.field public projectName:Ljava/lang/String;

.field public sceneTip:Ljava/lang/String;

.field public sceneType:Ljava/lang/String;

.field public shareUrl:Ljava/lang/String;

.field public subMessage:Ljava/lang/String;

.field public uniqueIdent:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public getUniqueIdent()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/fission/bean/FissionParam;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    :cond_17
    const-wide/16 v0, 0x0

    .line 1
    :try_start_19
    iget-object v2, p0, Lcn/damai/commonbusiness/fission/bean/FissionParam;->uniqueIdent:Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0
    :try_end_1f
    .catch Ljava/lang/Exception; {:try_start_19 .. :try_end_1f} :catch_1f

    .line 2
    :catch_1f
    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
