.class public Lcn/damai/commonbusiness/calendar/CalendarPopView$b;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/calendar/CalendarPopView;->u()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/calendar/CalendarPopView;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/calendar/CalendarPopView;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$b;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 12

    sget-object v0, Lcn/damai/commonbusiness/calendar/CalendarPopView$b;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object v4, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$b;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    iget v5, v4, Lcn/damai/commonbusiness/calendar/CalendarPopView;->r:I

    const/4 p1, -0x1

    const-string v0, ""

    if-eq v5, p1, :cond_43

    const/4 p1, 0x5

    if-eq v5, p1, :cond_43

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    .line 2
    invoke-static {v4}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->n(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Ljava/lang/String;

    move-result-object v9

    invoke-static/range {v4 .. v9}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->o(Lcn/damai/commonbusiness/calendar/CalendarPopView;ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;)V

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$b;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {p1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->c(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Ltb/sr1;

    move-result-object p1

    if-eqz p1, :cond_42

    .line 4
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$b;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {p1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->c(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Ltb/sr1;

    move-result-object p1

    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$b;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    iget v1, v1, Lcn/damai/commonbusiness/calendar/CalendarPopView;->r:I

    invoke-virtual {p1, v1, v0, v0}, Ltb/sr1;->e(ILjava/lang/String;Ljava/lang/String;)V

    :cond_42
    return-void

    .line 5
    :cond_43
    invoke-static {v4}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->g(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Lcn/damai/commonbusiness/calendar/bean/Day;

    move-result-object p1

    if-nez p1, :cond_5b

    .line 6
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$b;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->f(Lcn/damai/commonbusiness/calendar/CalendarPopView;Ljava/util/List;)Ljava/util/List;

    .line 7
    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$b;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-string v6, "\u5168\u90e8\u65f6\u95f4"

    invoke-static/range {v1 .. v6}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->o(Lcn/damai/commonbusiness/calendar/CalendarPopView;ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;)V

    return-void

    .line 8
    :cond_5b
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$b;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {p1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->g(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Lcn/damai/commonbusiness/calendar/bean/Day;

    move-result-object p1

    invoke-virtual {p1}, Lcn/damai/commonbusiness/calendar/bean/Day;->toShortDateString()Ljava/lang/String;

    move-result-object p1

    .line 9
    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$b;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {v1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->j(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Lcn/damai/commonbusiness/calendar/bean/Day;

    move-result-object v1

    if-nez v1, :cond_77

    .line 10
    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$b;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {v1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->g(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Lcn/damai/commonbusiness/calendar/bean/Day;

    move-result-object v2

    invoke-static {v1, v2}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->k(Lcn/damai/commonbusiness/calendar/CalendarPopView;Lcn/damai/commonbusiness/calendar/bean/Day;)Lcn/damai/commonbusiness/calendar/bean/Day;

    goto :goto_95

    .line 11
    :cond_77
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "-"

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$b;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {p1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->j(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Lcn/damai/commonbusiness/calendar/bean/Day;

    move-result-object p1

    invoke-virtual {p1}, Lcn/damai/commonbusiness/calendar/bean/Day;->toShortDateString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    :goto_95
    move-object v6, p1

    .line 12
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$b;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {p1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->c(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Ltb/sr1;

    move-result-object p1

    if-eqz p1, :cond_c7

    .line 13
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$b;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {p1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->c(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Ltb/sr1;

    move-result-object p1

    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$b;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    iget v2, v1, Lcn/damai/commonbusiness/calendar/CalendarPopView;->r:I

    invoke-static {v1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->g(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Lcn/damai/commonbusiness/calendar/bean/Day;

    move-result-object v1

    invoke-virtual {v1}, Lcn/damai/commonbusiness/calendar/bean/Day;->toSimpleDateString()Ljava/lang/String;

    move-result-object v1

    iget-object v3, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$b;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {v3}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->j(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Lcn/damai/commonbusiness/calendar/bean/Day;

    move-result-object v3

    if-nez v3, :cond_ba

    move-object v3, v0

    goto :goto_c4

    :cond_ba
    iget-object v3, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$b;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {v3}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->j(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Lcn/damai/commonbusiness/calendar/bean/Day;

    move-result-object v3

    invoke-virtual {v3}, Lcn/damai/commonbusiness/calendar/bean/Day;->toSimpleDateString()Ljava/lang/String;

    move-result-object v3

    :goto_c4
    invoke-virtual {p1, v2, v1, v3}, Ltb/sr1;->e(ILjava/lang/String;Ljava/lang/String;)V

    .line 14
    :cond_c7
    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$b;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    const/4 v2, 0x5

    .line 15
    invoke-static {v1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->g(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Lcn/damai/commonbusiness/calendar/bean/Day;

    move-result-object p1

    invoke-virtual {p1}, Lcn/damai/commonbusiness/calendar/bean/Day;->toSimpleDateString()Ljava/lang/String;

    move-result-object v3

    .line 16
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$b;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {p1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->j(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Lcn/damai/commonbusiness/calendar/bean/Day;

    move-result-object p1

    if-nez p1, :cond_db

    goto :goto_e5

    :cond_db
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$b;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {p1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->j(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Lcn/damai/commonbusiness/calendar/bean/Day;

    move-result-object p1

    invoke-virtual {p1}, Lcn/damai/commonbusiness/calendar/bean/Day;->toSimpleDateString()Ljava/lang/String;

    move-result-object v0

    :goto_e5
    move-object v4, v0

    const/4 v5, 0x0

    .line 17
    invoke-static/range {v1 .. v6}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->o(Lcn/damai/commonbusiness/calendar/CalendarPopView;ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;)V

    return-void
.end method
