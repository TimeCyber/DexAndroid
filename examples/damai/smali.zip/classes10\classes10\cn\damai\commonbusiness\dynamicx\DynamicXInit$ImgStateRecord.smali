.class public Lcn/damai/commonbusiness/dynamicx/DynamicXInit$ImgStateRecord;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/dynamicx/DynamicXInit;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "ImgStateRecord"
.end annotation


# instance fields
.field public isShouldUseDefault:Z


# direct methods
.method public constructor <init>(Z)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-boolean p1, p0, Lcn/damai/commonbusiness/dynamicx/DynamicXInit$ImgStateRecord;->isShouldUseDefault:Z

    return-void
.end method
