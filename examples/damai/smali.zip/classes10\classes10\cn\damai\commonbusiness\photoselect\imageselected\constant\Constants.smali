.class public interface abstract Lcn/damai/commonbusiness/photoselect/imageselected/constant/Constants;
.super Ljava/lang/Object;
.source "Taobao"


# static fields
.field public static final IS_CONFIRM:Ljava/lang/String; = "is_confirm"

.field public static final IS_SINGLE:Ljava/lang/String; = "is_single"

.field public static final MAX_SELECT_COUNT:Ljava/lang/String; = "max_select_count"

.field public static final POSITION:Ljava/lang/String; = "position"

.field public static final REQUEST_PREVIEW_IMAGE_CODE:I = 0x12

.field public static final SELECTED:Ljava/lang/String; = "selected"

.field public static final TYPE:Ljava/lang/String; = "type"
