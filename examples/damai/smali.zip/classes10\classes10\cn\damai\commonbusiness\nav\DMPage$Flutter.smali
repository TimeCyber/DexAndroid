.class public interface abstract Lcn/damai/commonbusiness/nav/DMPage$Flutter;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/nav/DMPage;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "Flutter"
.end annotation


# static fields
.field public static final ODER_DETAIL:Ljava/lang/String; = "dm_order_detail"

.field public static final ORDER_LIST:Ljava/lang/String; = "dm_order_list"
