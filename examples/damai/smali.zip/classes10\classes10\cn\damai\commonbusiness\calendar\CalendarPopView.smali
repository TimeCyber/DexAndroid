.class public Lcn/damai/commonbusiness/calendar/CalendarPopView;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/calendar/CalendarPopView$OnDateClickListener;
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon; = null

.field public static final STR_ONE_WEEK:Ljava/lang/String; = "\u4e00\u5468\u5185"


# instance fields
.field private a:Landroid/content/Context;

.field private b:Landroid/view/View;

.field private c:Landroid/view/View;

.field private d:Landroid/view/ViewGroup;

.field private e:Landroid/widget/TextView;

.field private f:Landroid/widget/TextView;

.field private g:Landroid/widget/TextView;

.field private h:Landroid/widget/TextView;

.field private i:Landroidx/recyclerview/widget/RecyclerView;

.field private j:Landroid/view/ViewGroup;

.field private k:Landroid/widget/TextView;

.field private l:Landroid/widget/TextView;

.field private m:Lcn/damai/commonbusiness/calendar/adapter/CalendarListAdapter;

.field private n:Lcn/damai/commonbusiness/calendar/bean/CalendarBean;

.field private o:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/calendar/bean/Day;",
            ">;"
        }
    .end annotation
.end field

.field private p:I

.field private q:Z

.field public r:I

.field private s:Ljava/lang/String;

.field private t:Z

.field private u:I

.field private v:Lcn/damai/commonbusiness/calendar/CalendarPopView$OnDateClickListener;

.field private w:Lcn/damai/commonbusiness/calendar/bean/Day;

.field private x:Lcn/damai/commonbusiness/calendar/bean/Day;

.field private y:Ltb/sr1;


# direct methods
.method public constructor <init>(Landroid/content/Context;ZZILcn/damai/commonbusiness/calendar/CalendarPopView$OnDateClickListener;)V
    .registers 14

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->p:I

    const/4 v0, -0x1

    .line 3
    iput v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->r:I

    const/4 v7, 0x0

    move-object v1, p0

    move-object v2, p1

    move v3, p2

    move v4, p3

    move v5, p4

    move-object v6, p5

    .line 4
    invoke-direct/range {v1 .. v7}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->v(Landroid/content/Context;ZZILcn/damai/commonbusiness/calendar/CalendarPopView$OnDateClickListener;Ljava/util/List;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;ZZILcn/damai/commonbusiness/calendar/CalendarPopView$OnDateClickListener;Ljava/util/List;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "ZZI",
            "Lcn/damai/commonbusiness/calendar/CalendarPopView$OnDateClickListener;",
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/calendar/bean/CalendarYearBean;",
            ">;)V"
        }
    .end annotation

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 6
    iput v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->p:I

    const/4 v0, -0x1

    .line 7
    iput v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->r:I

    .line 8
    invoke-direct/range {p0 .. p6}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->v(Landroid/content/Context;ZZILcn/damai/commonbusiness/calendar/CalendarPopView$OnDateClickListener;Ljava/util/List;)V

    return-void
.end method

.method private B()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "15"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->i:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    instance-of v0, v0, Landroid/widget/LinearLayout;

    if-eqz v0, :cond_3b

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->i:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_3b

    .line 3
    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_3b

    .line 4
    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_3b

    .line 5
    invoke-direct {p0, v0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->D(Landroid/view/ViewGroup;)V

    :cond_3b
    return-void
.end method

.method private C(Ljava/util/List;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/calendar/bean/Day;",
            ">;)V"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "10"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->o:Ljava/util/List;

    .line 2
    invoke-static {p1}, Ltb/mw5;->f(Ljava/util/List;)I

    move-result v0

    if-lez v0, :cond_2e

    .line 3
    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/calendar/bean/Day;

    if-eqz p1, :cond_31

    .line 4
    invoke-static {p1}, Ltb/lt;->f(Lcn/damai/commonbusiness/calendar/bean/Day;)I

    move-result p1

    iput p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->p:I

    goto :goto_31

    :cond_2e
    const/4 p1, -0x1

    .line 5
    iput p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->p:I

    .line 6
    :cond_31
    :goto_31
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->m:Lcn/damai/commonbusiness/calendar/adapter/CalendarListAdapter;

    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->n:Lcn/damai/commonbusiness/calendar/bean/CalendarBean;

    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->o:Ljava/util/List;

    invoke-virtual {p1, v0, v1}, Lcn/damai/commonbusiness/calendar/adapter/CalendarListAdapter;->a(Lcn/damai/commonbusiness/calendar/bean/CalendarBean;Ljava/util/List;)V

    return-void
.end method

.method private D(Landroid/view/ViewGroup;)V
    .registers 8

    sget-object v0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "16"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v2, :cond_17

    new-array v2, v3, [Ljava/lang/Object;

    aput-object p0, v2, v5

    aput-object p1, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_17
    if-eqz p1, :cond_6e

    .line 1
    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    if-lt v0, v3, :cond_6e

    .line 2
    invoke-virtual {p1, v5}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    instance-of v0, v0, Landroid/widget/TextView;

    if-eqz v0, :cond_6e

    .line 3
    invoke-virtual {p1, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    instance-of v0, v0, Landroid/widget/TextView;

    if-eqz v0, :cond_6e

    .line 4
    invoke-virtual {p1, v5}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    .line 5
    invoke-virtual {p1, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    .line 6
    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->k:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 7
    invoke-virtual {p1}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v0

    if-eqz v0, :cond_67

    invoke-virtual {p1}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v0

    invoke-interface {v0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_67

    .line 8
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->l:Landroid/widget/TextView;

    invoke-virtual {p1}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 9
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->l:Landroid/widget/TextView;

    invoke-virtual {p1, v5}, Landroid/widget/TextView;->setVisibility(I)V

    goto :goto_6e

    .line 10
    :cond_67
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->l:Landroid/widget/TextView;

    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setVisibility(I)V

    :cond_6e
    :goto_6e
    return-void
.end method

.method private F()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "9"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    sget v1, Lcn/damai/commonbusiness/R$anim;->common_calendar_anim:I

    invoke-static {v0, v1}, Landroid/view/animation/AnimationUtils;->loadAnimation(Landroid/content/Context;I)Landroid/view/animation/Animation;

    move-result-object v0

    .line 2
    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->c:Landroid/view/View;

    invoke-virtual {v1, v0}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    return-void
.end method

.method private G()V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "18"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->r:I

    const/4 v1, -0x1

    if-eqz v0, :cond_18d

    const/4 v2, 0x4

    if-eq v0, v2, :cond_132

    const/16 v2, 0x9

    if-eq v0, v2, :cond_d6

    const/16 v2, 0xa

    if-eq v0, v2, :cond_7a

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->e:Landroid/widget/TextView;

    sget v2, Lcn/damai/commonbusiness/R$drawable;->common_date_normal_bg:I

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->f:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->g:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->h:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 6
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->e:Landroid/widget/TextView;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    sget v3, Lcn/damai/commonbusiness/R$color;->color_000000:I

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 7
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->f:Landroid/widget/TextView;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 8
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->g:Landroid/widget/TextView;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 9
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->h:Landroid/widget/TextView;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    goto/16 :goto_1e7

    .line 10
    :cond_7a
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->e:Landroid/widget/TextView;

    sget v2, Lcn/damai/commonbusiness/R$drawable;->common_date_normal_bg:I

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 11
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->f:Landroid/widget/TextView;

    sget v3, Lcn/damai/commonbusiness/R$drawable;->common_date_select_bg:I

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 12
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->g:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 13
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->h:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 14
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->e:Landroid/widget/TextView;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    sget v3, Lcn/damai/commonbusiness/R$color;->color_000000:I

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 15
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->f:Landroid/widget/TextView;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    sget v4, Lcn/damai/commonbusiness/R$color;->color_FF2D79:I

    invoke-virtual {v2, v4}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 16
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->g:Landroid/widget/TextView;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 17
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->h:Landroid/widget/TextView;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 18
    iput v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->p:I

    goto/16 :goto_1e7

    .line 19
    :cond_d6
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->e:Landroid/widget/TextView;

    sget v2, Lcn/damai/commonbusiness/R$drawable;->common_date_normal_bg:I

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 20
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->f:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 21
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->g:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 22
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->h:Landroid/widget/TextView;

    sget v2, Lcn/damai/commonbusiness/R$drawable;->common_date_select_bg:I

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 23
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->e:Landroid/widget/TextView;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    sget v3, Lcn/damai/commonbusiness/R$color;->color_000000:I

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 24
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->f:Landroid/widget/TextView;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 25
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->g:Landroid/widget/TextView;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 26
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->h:Landroid/widget/TextView;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    sget v3, Lcn/damai/commonbusiness/R$color;->color_FF2D79:I

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 27
    iput v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->p:I

    goto/16 :goto_1e7

    .line 28
    :cond_132
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->e:Landroid/widget/TextView;

    sget v2, Lcn/damai/commonbusiness/R$drawable;->common_date_normal_bg:I

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 29
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->f:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 30
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->g:Landroid/widget/TextView;

    sget v3, Lcn/damai/commonbusiness/R$drawable;->common_date_select_bg:I

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 31
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->h:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 32
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->e:Landroid/widget/TextView;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    sget v3, Lcn/damai/commonbusiness/R$color;->color_000000:I

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 33
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->f:Landroid/widget/TextView;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 34
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->g:Landroid/widget/TextView;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    sget v4, Lcn/damai/commonbusiness/R$color;->color_FF2D79:I

    invoke-virtual {v2, v4}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 35
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->h:Landroid/widget/TextView;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 36
    iput v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->p:I

    goto :goto_1e7

    .line 37
    :cond_18d
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->e:Landroid/widget/TextView;

    sget v2, Lcn/damai/commonbusiness/R$drawable;->common_date_select_bg:I

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 38
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->f:Landroid/widget/TextView;

    sget v2, Lcn/damai/commonbusiness/R$drawable;->common_date_normal_bg:I

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 39
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->g:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 40
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->h:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 41
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->e:Landroid/widget/TextView;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    sget v3, Lcn/damai/commonbusiness/R$color;->color_FF2D79:I

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 42
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->f:Landroid/widget/TextView;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    sget v3, Lcn/damai/commonbusiness/R$color;->color_000000:I

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 43
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->g:Landroid/widget/TextView;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 44
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->h:Landroid/widget/TextView;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 45
    iput v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->p:I

    .line 46
    :goto_1e7
    iget v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->r:I

    const/4 v2, 0x5

    if-ne v0, v2, :cond_250

    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->s:Ljava/lang/String;

    const-string v2, "\u4e00\u5468\u5185"

    invoke-static {v2, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_250

    .line 47
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->e:Landroid/widget/TextView;

    sget v2, Lcn/damai/commonbusiness/R$drawable;->common_date_normal_bg:I

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 48
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->f:Landroid/widget/TextView;

    sget v3, Lcn/damai/commonbusiness/R$drawable;->common_date_select_bg:I

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 49
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->g:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 50
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->h:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 51
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->e:Landroid/widget/TextView;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    sget v3, Lcn/damai/commonbusiness/R$color;->color_000000:I

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 52
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->f:Landroid/widget/TextView;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    sget v4, Lcn/damai/commonbusiness/R$color;->color_FF2D79:I

    invoke-virtual {v2, v4}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 53
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->g:Landroid/widget/TextView;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 54
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->h:Landroid/widget/TextView;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 55
    iput v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->p:I

    :cond_250
    return-void
.end method

.method static synthetic a(Lcn/damai/commonbusiness/calendar/CalendarPopView;)I
    .registers 1

    .line 1
    iget p0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->p:I

    return p0
.end method

.method static synthetic b(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Landroidx/recyclerview/widget/RecyclerView;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->i:Landroidx/recyclerview/widget/RecyclerView;

    return-object p0
.end method

.method static synthetic c(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Ltb/sr1;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->y:Ltb/sr1;

    return-object p0
.end method

.method static synthetic d(Lcn/damai/commonbusiness/calendar/CalendarPopView;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->G()V

    return-void
.end method

.method static synthetic e(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Ljava/util/List;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->o:Ljava/util/List;

    return-object p0
.end method

.method static synthetic f(Lcn/damai/commonbusiness/calendar/CalendarPopView;Ljava/util/List;)Ljava/util/List;
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->o:Ljava/util/List;

    return-object p1
.end method

.method static synthetic g(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Lcn/damai/commonbusiness/calendar/bean/Day;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->w:Lcn/damai/commonbusiness/calendar/bean/Day;

    return-object p0
.end method

.method static synthetic h(Lcn/damai/commonbusiness/calendar/CalendarPopView;Lcn/damai/commonbusiness/calendar/bean/Day;)Lcn/damai/commonbusiness/calendar/bean/Day;
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->w:Lcn/damai/commonbusiness/calendar/bean/Day;

    return-object p1
.end method

.method static synthetic i(Lcn/damai/commonbusiness/calendar/CalendarPopView;Ljava/util/List;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->C(Ljava/util/List;)V

    return-void
.end method

.method static synthetic j(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Lcn/damai/commonbusiness/calendar/bean/Day;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->x:Lcn/damai/commonbusiness/calendar/bean/Day;

    return-object p0
.end method

.method static synthetic k(Lcn/damai/commonbusiness/calendar/CalendarPopView;Lcn/damai/commonbusiness/calendar/bean/Day;)Lcn/damai/commonbusiness/calendar/bean/Day;
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->x:Lcn/damai/commonbusiness/calendar/bean/Day;

    return-object p1
.end method

.method static synthetic l(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Z
    .registers 1

    .line 1
    iget-boolean p0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->t:Z

    return p0
.end method

.method static synthetic m(Lcn/damai/commonbusiness/calendar/CalendarPopView;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->B()V

    return-void
.end method

.method static synthetic n(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Ljava/lang/String;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->s:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic o(Lcn/damai/commonbusiness/calendar/CalendarPopView;ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;)V
    .registers 6

    .line 1
    invoke-direct/range {p0 .. p5}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->y(ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;)V

    return-void
.end method

.method private r(Lcn/damai/commonbusiness/calendar/bean/CalendarBean;)Ljava/util/List;
    .registers 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcn/damai/commonbusiness/calendar/bean/CalendarBean;",
            ")",
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/calendar/bean/Day;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "8"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v2, :cond_1a

    new-array v2, v4, [Ljava/lang/Object;

    aput-object p0, v2, v3

    aput-object p1, v2, v5

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/List;

    return-object p1

    .line 1
    :cond_1a
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    if-eqz p1, :cond_9d

    .line 2
    iget-object v1, p1, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->startDate:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_2a

    goto :goto_9d

    .line 3
    :cond_2a
    iget-object v1, p1, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->startDate:Ljava/lang/String;

    invoke-static {v1}, Ltb/lt;->s(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v1

    .line 4
    iget-object v2, p1, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->endDate:Ljava/lang/String;

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_3c

    .line 5
    iget-object v2, p1, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->startDate:Ljava/lang/String;

    iput-object v2, p1, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->endDate:Ljava/lang/String;

    .line 6
    :cond_3c
    iget-object p1, p1, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->endDate:Ljava/lang/String;

    invoke-static {p1}, Ltb/lt;->s(Ljava/lang/String;)Ljava/util/Date;

    move-result-object p1

    if-nez v1, :cond_45

    return-object v0

    .line 7
    :cond_45
    invoke-virtual {v1}, Ljava/util/Date;->getTime()J

    move-result-wide v6

    .line 8
    invoke-virtual {p1}, Ljava/util/Date;->getTime()J

    move-result-wide v8

    sub-long/2addr v8, v6

    const-wide/32 v6, 0x5265c00

    .line 9
    div-long/2addr v8, v6

    long-to-int p1, v8

    .line 10
    sget-object v2, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "\u4e24\u4e2a\u65f6\u95f4\u4e4b\u95f4\u7684\u5929\u6570\u5dee\u4e3a\uff1a"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    const-string v2, "GMT+8"

    .line 11
    invoke-static {v2}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v2

    invoke-static {v2}, Ljava/util/Calendar;->getInstance(Ljava/util/TimeZone;)Ljava/util/Calendar;

    move-result-object v2

    :goto_73
    if-gt v3, p1, :cond_9d

    .line 12
    invoke-virtual {v2, v1}, Ljava/util/Calendar;->setTime(Ljava/util/Date;)V

    const/4 v6, 0x5

    .line 13
    invoke-virtual {v2, v6, v3}, Ljava/util/Calendar;->add(II)V

    .line 14
    new-instance v7, Lcn/damai/commonbusiness/calendar/bean/Day;

    invoke-virtual {v2, v5}, Ljava/util/Calendar;->get(I)I

    move-result v8

    invoke-virtual {v2, v4}, Ljava/util/Calendar;->get(I)I

    move-result v9

    add-int/2addr v9, v5

    invoke-virtual {v2, v6}, Ljava/util/Calendar;->get(I)I

    move-result v6

    invoke-direct {v7, v8, v9, v6}, Lcn/damai/commonbusiness/calendar/bean/Day;-><init>(III)V

    .line 15
    invoke-interface {v0, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    if-nez v3, :cond_96

    .line 16
    iput-object v7, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->w:Lcn/damai/commonbusiness/calendar/bean/Day;

    goto :goto_9a

    :cond_96
    if-ne v3, p1, :cond_9a

    .line 17
    iput-object v7, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->x:Lcn/damai/commonbusiness/calendar/bean/Day;

    :cond_9a
    :goto_9a
    add-int/lit8 v3, v3, 0x1

    goto :goto_73

    :cond_9d
    :goto_9d
    return-object v0
.end method

.method private u()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "12"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->b:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->item_filter_confirm:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v1, Lcn/damai/commonbusiness/calendar/CalendarPopView$b;

    invoke-direct {v1, p0}, Lcn/damai/commonbusiness/calendar/CalendarPopView$b;-><init>(Lcn/damai/commonbusiness/calendar/CalendarPopView;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->b:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->item_filter_reset:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v1, Lcn/damai/commonbusiness/calendar/CalendarPopView$c;

    invoke-direct {v1, p0}, Lcn/damai/commonbusiness/calendar/CalendarPopView$c;-><init>(Lcn/damai/commonbusiness/calendar/CalendarPopView;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method private v(Landroid/content/Context;ZZILcn/damai/commonbusiness/calendar/CalendarPopView$OnDateClickListener;Ljava/util/List;)V
    .registers 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "ZZI",
            "Lcn/damai/commonbusiness/calendar/CalendarPopView$OnDateClickListener;",
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/calendar/bean/CalendarYearBean;",
            ">;)V"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_32

    const/4 v2, 0x7

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x5

    aput-object p5, v2, p1

    const/4 p1, 0x6

    aput-object p6, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_32
    iput-boolean p2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->t:Z

    .line 2
    iput-boolean p3, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->q:Z

    .line 3
    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p1

    sget p2, Lcn/damai/commonbusiness/R$layout;->common_calendar_pop:I

    const/4 p3, 0x0

    invoke-virtual {p1, p2, p3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object p1

    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->b:Landroid/view/View;

    const/16 p2, 0x8

    .line 4
    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    .line 5
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->b:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    int-to-float p2, p4

    .line 6
    invoke-static {p1, p2}, Lcom/ali/user/mobile/utils/ScreenUtil;->dip2px(Landroid/content/Context;F)I

    move-result p1

    iput p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->u:I

    .line 7
    iput-object p5, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->v:Lcn/damai/commonbusiness/calendar/CalendarPopView$OnDateClickListener;

    if-eqz p6, :cond_65

    .line 8
    new-instance p1, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;

    invoke-direct {p1}, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;-><init>()V

    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->n:Lcn/damai/commonbusiness/calendar/bean/CalendarBean;

    .line 9
    iput-object p6, p1, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->calendar:Ljava/util/List;

    goto :goto_7c

    :cond_65
    :try_start_65
    const-string p1, "calendar_data"

    .line 10
    invoke-static {p1}, Ltb/ty0;->A(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_7c

    .line 11
    const-class p2, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;

    invoke-static {p1, p2}, Lcom/alibaba/fastjson/JSON;->parseObject(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;

    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->n:Lcn/damai/commonbusiness/calendar/bean/CalendarBean;
    :try_end_77
    .catch Ljava/lang/Exception; {:try_start_65 .. :try_end_77} :catch_78

    goto :goto_7c

    :catch_78
    move-exception p1

    .line 12
    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    .line 13
    :cond_7c
    :goto_7c
    invoke-direct {p0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->x()V

    return-void
.end method

.method private w()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "13"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->b:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->layout_fourdate:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->d:Landroid/view/ViewGroup;

    .line 2
    iget-boolean v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->q:Z

    if-eqz v1, :cond_83

    .line 3
    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->setVisibility(I)V

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->d:Landroid/view/ViewGroup;

    sget v1, Lcn/damai/commonbusiness/R$id;->tv_time1:I

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->e:Landroid/widget/TextView;

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->d:Landroid/view/ViewGroup;

    sget v1, Lcn/damai/commonbusiness/R$id;->tv_time2:I

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->f:Landroid/widget/TextView;

    .line 6
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->d:Landroid/view/ViewGroup;

    sget v1, Lcn/damai/commonbusiness/R$id;->tv_time3:I

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->g:Landroid/widget/TextView;

    .line 7
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->d:Landroid/view/ViewGroup;

    sget v1, Lcn/damai/commonbusiness/R$id;->tv_time4:I

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->h:Landroid/widget/TextView;

    .line 8
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->e:Landroid/widget/TextView;

    new-instance v1, Lcn/damai/commonbusiness/calendar/CalendarPopView$d;

    invoke-direct {v1, p0}, Lcn/damai/commonbusiness/calendar/CalendarPopView$d;-><init>(Lcn/damai/commonbusiness/calendar/CalendarPopView;)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 9
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->f:Landroid/widget/TextView;

    new-instance v1, Lcn/damai/commonbusiness/calendar/CalendarPopView$e;

    invoke-direct {v1, p0}, Lcn/damai/commonbusiness/calendar/CalendarPopView$e;-><init>(Lcn/damai/commonbusiness/calendar/CalendarPopView;)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 10
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->g:Landroid/widget/TextView;

    new-instance v1, Lcn/damai/commonbusiness/calendar/CalendarPopView$f;

    invoke-direct {v1, p0}, Lcn/damai/commonbusiness/calendar/CalendarPopView$f;-><init>(Lcn/damai/commonbusiness/calendar/CalendarPopView;)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 11
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->h:Landroid/widget/TextView;

    new-instance v1, Lcn/damai/commonbusiness/calendar/CalendarPopView$g;

    invoke-direct {v1, p0}, Lcn/damai/commonbusiness/calendar/CalendarPopView$g;-><init>(Lcn/damai/commonbusiness/calendar/CalendarPopView;)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 12
    invoke-direct {p0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->G()V

    goto :goto_88

    :cond_83
    const/16 v1, 0x8

    .line 13
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->setVisibility(I)V

    :goto_88
    return-void
.end method

.method private x()V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "11"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_14

    new-array v2, v3, [Ljava/lang/Object;

    aput-object p0, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->b:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->layout_calendar:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->c:Landroid/view/View;

    .line 2
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 3
    iget v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->u:I

    invoke-virtual {v0, v4, v4, v4, v1}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->b:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->layout_guding:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->j:Landroid/view/ViewGroup;

    .line 5
    iget-boolean v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->t:Z

    if-eqz v1, :cond_3d

    .line 6
    invoke-virtual {v0, v4}, Landroid/view/ViewGroup;->setVisibility(I)V

    goto :goto_42

    :cond_3d
    const/16 v1, 0x8

    .line 7
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->setVisibility(I)V

    .line 8
    :goto_42
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->b:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->tv_calendar_month:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->k:Landroid/widget/TextView;

    .line 9
    new-instance v0, Ljava/text/SimpleDateFormat;

    sget-object v1, Ljava/util/Locale;->CHINA:Ljava/util/Locale;

    const-string v2, "yyyy/MM"

    invoke-direct {v0, v2, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    const-string v1, "GMT+08:00"

    .line 10
    invoke-static {v1}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/text/SimpleDateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    const-string v1, "GMT+8"

    .line 11
    invoke-static {v1}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Calendar;->getInstance(Ljava/util/TimeZone;)Ljava/util/Calendar;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    .line 12
    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->k:Landroid/widget/TextView;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 13
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->b:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->tv_shenhua:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->l:Landroid/widget/TextView;

    .line 14
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->b:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->pop_irc:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->i:Landroidx/recyclerview/widget/RecyclerView;

    .line 15
    new-instance v1, Landroidx/recyclerview/widget/LinearLayoutManager;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-direct {v1, v2, v3, v4}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(Landroid/content/Context;IZ)V

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;)V

    .line 16
    new-instance v0, Lcn/damai/commonbusiness/calendar/adapter/CalendarListAdapter;

    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    new-instance v2, Lcn/damai/commonbusiness/calendar/CalendarPopView$a;

    invoke-direct {v2, p0}, Lcn/damai/commonbusiness/calendar/CalendarPopView$a;-><init>(Lcn/damai/commonbusiness/calendar/CalendarPopView;)V

    invoke-direct {v0, v1, v2}, Lcn/damai/commonbusiness/calendar/adapter/CalendarListAdapter;-><init>(Landroid/content/Context;Landroid/view/View$OnClickListener;)V

    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->m:Lcn/damai/commonbusiness/calendar/adapter/CalendarListAdapter;

    .line 17
    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->i:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    .line 18
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->i:Landroidx/recyclerview/widget/RecyclerView;

    new-instance v1, Lcn/damai/commonbusiness/calendar/CalendarPopView$3;

    invoke-direct {v1, p0}, Lcn/damai/commonbusiness/calendar/CalendarPopView$3;-><init>(Lcn/damai/commonbusiness/calendar/CalendarPopView;)V

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->addOnScrollListener(Landroidx/recyclerview/widget/RecyclerView$OnScrollListener;)V

    .line 19
    invoke-direct {p0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->w()V

    .line 20
    invoke-direct {p0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->u()V

    .line 21
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->m:Lcn/damai/commonbusiness/calendar/adapter/CalendarListAdapter;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    return-void
.end method

.method private y(ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;)V
    .registers 15

    sget-object v0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "19"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    if-eqz v2, :cond_2b

    const/4 v2, 0x6

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v7

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v6

    aput-object p2, v2, v5

    aput-object p3, v2, v4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    aput-object p5, v2, v8

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_2b
    if-ne p1, v8, :cond_32

    .line 1
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->i:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, v7}, Landroidx/recyclerview/widget/RecyclerView;->scrollToPosition(I)V

    :cond_32
    const/16 v0, 0xa

    if-ne p1, v0, :cond_3d

    .line 2
    invoke-static {}, Ltb/lt;->i()Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->o:Ljava/util/List;

    goto :goto_5c

    :cond_3d
    if-ne p1, v3, :cond_49

    .line 3
    invoke-static {}, Ltb/lt;->j()Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->o:Ljava/util/List;

    const-string v0, "\u4e00\u6708\u5185"

    const/4 v4, 0x2

    goto :goto_5f

    :cond_49
    const/16 v0, 0x9

    if-ne p1, v0, :cond_56

    .line 4
    invoke-static {}, Ltb/lt;->p()Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->o:Ljava/util/List;

    const-string v0, "\u672c\u5468\u672b"

    goto :goto_5f

    :cond_56
    if-nez p1, :cond_5c

    const-string v0, "\u5168\u90e8\u65f6\u95f4"

    const/4 v4, 0x0

    goto :goto_5f

    :cond_5c
    :goto_5c
    const-string v0, "\u4e00\u5468\u5185"

    const/4 v4, 0x1

    .line 5
    :goto_5f
    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->y:Ltb/sr1;

    if-eqz v1, :cond_68

    if-eq p1, v8, :cond_68

    .line 6
    invoke-virtual {v1, v0, v4}, Ltb/sr1;->f(Ljava/lang/String;I)V

    .line 7
    :cond_68
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->m:Lcn/damai/commonbusiness/calendar/adapter/CalendarListAdapter;

    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->n:Lcn/damai/commonbusiness/calendar/bean/CalendarBean;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->o:Ljava/util/List;

    invoke-virtual {v0, v1, v2}, Lcn/damai/commonbusiness/calendar/adapter/CalendarListAdapter;->a(Lcn/damai/commonbusiness/calendar/bean/CalendarBean;Ljava/util/List;)V

    .line 8
    iput p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->r:I

    .line 9
    iput-object p5, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->s:Ljava/lang/String;

    .line 10
    iget-boolean v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->q:Z

    if-eqz v0, :cond_7c

    .line 11
    invoke-direct {p0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->G()V

    .line 12
    :cond_7c
    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->v:Lcn/damai/commonbusiness/calendar/CalendarPopView$OnDateClickListener;

    if-eqz v1, :cond_88

    move v2, p1

    move-object v3, p2

    move-object v4, p3

    move v5, p4

    move-object v6, p5

    .line 13
    invoke-interface/range {v1 .. v6}, Lcn/damai/commonbusiness/calendar/CalendarPopView$OnDateClickListener;->onDateClick(ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;)V

    :cond_88
    return-void
.end method


# virtual methods
.method public A(Ltb/sr1;)Ltb/sr1;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ltb/sr1;

    return-object p1

    .line 1
    :cond_1a
    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->y:Ltb/sr1;

    return-object p1
.end method

.method public E()V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->b:Landroid/view/View;

    invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V

    .line 2
    invoke-direct {p0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->F()V

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->m:Lcn/damai/commonbusiness/calendar/adapter/CalendarListAdapter;

    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->n:Lcn/damai/commonbusiness/calendar/bean/CalendarBean;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->o:Ljava/util/List;

    invoke-virtual {v0, v1, v2}, Lcn/damai/commonbusiness/calendar/adapter/CalendarListAdapter;->a(Lcn/damai/commonbusiness/calendar/bean/CalendarBean;Ljava/util/List;)V

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    invoke-static {v0}, Lcom/alibaba/wireless/security/aopsdk/replace/android/util/DisplayMetrics;->getwidthPixels(Landroid/util/DisplayMetrics;)I

    move-result v0

    .line 5
    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    const/high16 v2, 0x41900000    # 18.0f

    invoke-static {v1, v2}, Lcom/ali/user/mobile/utils/ScreenUtil;->dip2px(Landroid/content/Context;F)I

    move-result v1

    sub-int/2addr v0, v1

    div-int/lit8 v0, v0, 0x7

    add-int/lit8 v0, v0, -0x6

    mul-int/lit8 v0, v0, 0x38

    .line 6
    div-int/lit8 v0, v0, 0x2d

    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a:Landroid/content/Context;

    const/high16 v2, 0x41800000    # 16.0f

    invoke-static {v1, v2}, Lcom/ali/user/mobile/utils/ScreenUtil;->dip2px(Landroid/content/Context;F)I

    move-result v1

    add-int/2addr v0, v1

    .line 7
    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->o:Ljava/util/List;

    invoke-static {v1}, Ltb/mw5;->f(Ljava/util/List;)I

    move-result v1

    if-lez v1, :cond_65

    .line 8
    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->o:Ljava/util/List;

    invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcn/damai/commonbusiness/calendar/bean/Day;

    if-eqz v1, :cond_65

    .line 9
    invoke-static {v1}, Ltb/lt;->f(Lcn/damai/commonbusiness/calendar/bean/Day;)I

    move-result v1

    iput v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->p:I

    .line 10
    :cond_65
    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->i:Landroidx/recyclerview/widget/RecyclerView;

    new-instance v2, Lcn/damai/commonbusiness/calendar/CalendarPopView$1;

    invoke-direct {v2, p0, v0}, Lcn/damai/commonbusiness/calendar/CalendarPopView$1;-><init>(Lcn/damai/commonbusiness/calendar/CalendarPopView;I)V

    const-wide/16 v3, 0x64

    invoke-virtual {v1, v2, v3, v4}, Landroid/view/ViewGroup;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public p()Ljava/util/List;
    .registers 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/calendar/bean/Day;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "14"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_17

    new-array v2, v4, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    return-object v0

    .line 1
    :cond_17
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const-string v1, "GMT+8"

    .line 2
    invoke-static {v1}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Calendar;->getInstance(Ljava/util/TimeZone;)Ljava/util/Calendar;

    move-result-object v1

    .line 3
    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->w:Lcn/damai/commonbusiness/calendar/bean/Day;

    iget v5, v2, Lcn/damai/commonbusiness/calendar/bean/Day;->year:I

    iget v6, v2, Lcn/damai/commonbusiness/calendar/bean/Day;->month:I

    sub-int/2addr v6, v4

    iget v2, v2, Lcn/damai/commonbusiness/calendar/bean/Day;->day:I

    invoke-virtual {v1, v5, v6, v2}, Ljava/util/Calendar;->set(III)V

    const/4 v2, 0x6

    .line 4
    invoke-virtual {v1, v2}, Ljava/util/Calendar;->get(I)I

    .line 5
    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->w:Lcn/damai/commonbusiness/calendar/bean/Day;

    invoke-virtual {v2}, Lcn/damai/commonbusiness/calendar/bean/Day;->toSimpleDate()Ljava/util/Date;

    move-result-object v2

    .line 6
    iget-object v5, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->x:Lcn/damai/commonbusiness/calendar/bean/Day;

    invoke-virtual {v5}, Lcn/damai/commonbusiness/calendar/bean/Day;->toSimpleDate()Ljava/util/Date;

    move-result-object v5

    if-eqz v2, :cond_96

    if-nez v5, :cond_47

    goto :goto_96

    .line 7
    :cond_47
    invoke-virtual {v2}, Ljava/util/Date;->getTime()J

    move-result-wide v6

    .line 8
    invoke-virtual {v5}, Ljava/util/Date;->getTime()J

    move-result-wide v8

    sub-long/2addr v8, v6

    const-wide/32 v5, 0x5265c00

    .line 9
    div-long/2addr v8, v5

    long-to-int v2, v8

    .line 10
    sget-object v5, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "\u4e24\u4e2a\u65f6\u95f4\u4e4b\u95f4\u7684\u5929\u6570\u5dee\u4e3a\uff1a"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    :goto_6b
    if-gt v3, v2, :cond_96

    .line 11
    iget-object v5, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->w:Lcn/damai/commonbusiness/calendar/bean/Day;

    iget v6, v5, Lcn/damai/commonbusiness/calendar/bean/Day;->year:I

    iget v7, v5, Lcn/damai/commonbusiness/calendar/bean/Day;->month:I

    sub-int/2addr v7, v4

    iget v5, v5, Lcn/damai/commonbusiness/calendar/bean/Day;->day:I

    invoke-virtual {v1, v6, v7, v5}, Ljava/util/Calendar;->set(III)V

    const/4 v5, 0x5

    .line 12
    invoke-virtual {v1, v5, v3}, Ljava/util/Calendar;->add(II)V

    .line 13
    new-instance v6, Lcn/damai/commonbusiness/calendar/bean/Day;

    invoke-virtual {v1, v4}, Ljava/util/Calendar;->get(I)I

    move-result v7

    const/4 v8, 0x2

    invoke-virtual {v1, v8}, Ljava/util/Calendar;->get(I)I

    move-result v8

    add-int/2addr v8, v4

    invoke-virtual {v1, v5}, Ljava/util/Calendar;->get(I)I

    move-result v5

    invoke-direct {v6, v7, v8, v5}, Lcn/damai/commonbusiness/calendar/bean/Day;-><init>(III)V

    .line 14
    invoke-interface {v0, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_6b

    :cond_96
    :goto_96
    return-object v0
.end method

.method public q()Ltb/sr1;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltb/sr1;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->y:Ltb/sr1;

    return-object v0
.end method

.method public s()Landroid/view/View;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->b:Landroid/view/View;

    return-object v0
.end method

.method public t()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->b:Landroid/view/View;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->x:Lcn/damai/commonbusiness/calendar/bean/Day;

    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->w:Lcn/damai/commonbusiness/calendar/bean/Day;

    return-void
.end method

.method public z(Lcn/damai/commonbusiness/calendar/bean/CalendarBean;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "7"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_17
    if-nez p1, :cond_1a

    return-void

    .line 1
    :cond_1a
    :try_start_1a
    iget-object v0, p1, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->dateType:Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3
    :try_end_20
    .catch Ljava/lang/NumberFormatException; {:try_start_1a .. :try_end_20} :catch_21

    goto :goto_25

    :catch_21
    move-exception v0

    .line 2
    invoke-virtual {v0}, Ljava/lang/NumberFormatException;->printStackTrace()V

    :goto_25
    const/16 v0, 0xa

    if-ne v3, v0, :cond_30

    .line 3
    invoke-static {}, Ltb/lt;->i()Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->o:Ljava/util/List;

    goto :goto_58

    :cond_30
    const/4 v0, 0x4

    if-ne v3, v0, :cond_3a

    .line 4
    invoke-static {}, Ltb/lt;->j()Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->o:Ljava/util/List;

    goto :goto_58

    :cond_3a
    const/16 v0, 0x9

    if-ne v3, v0, :cond_45

    .line 5
    invoke-static {}, Ltb/lt;->p()Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->o:Ljava/util/List;

    goto :goto_58

    :cond_45
    const/4 v0, 0x5

    if-ne v3, v0, :cond_4f

    .line 6
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->r(Lcn/damai/commonbusiness/calendar/bean/CalendarBean;)Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->o:Ljava/util/List;

    goto :goto_58

    :cond_4f
    if-nez v3, :cond_58

    .line 7
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->o:Ljava/util/List;

    .line 8
    :cond_58
    :goto_58
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->m:Lcn/damai/commonbusiness/calendar/adapter/CalendarListAdapter;

    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->n:Lcn/damai/commonbusiness/calendar/bean/CalendarBean;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->o:Ljava/util/List;

    invoke-virtual {v0, v1, v2}, Lcn/damai/commonbusiness/calendar/adapter/CalendarListAdapter;->a(Lcn/damai/commonbusiness/calendar/bean/CalendarBean;Ljava/util/List;)V

    .line 9
    iput v3, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->r:I

    .line 10
    iget-object p1, p1, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->name:Ljava/lang/String;

    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->s:Ljava/lang/String;

    .line 11
    iget-boolean p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView;->q:Z

    if-eqz p1, :cond_6e

    .line 12
    invoke-direct {p0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->G()V

    :cond_6e
    return-void
.end method
