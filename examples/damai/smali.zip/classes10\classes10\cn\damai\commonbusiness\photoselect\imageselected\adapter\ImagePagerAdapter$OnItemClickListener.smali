.class public interface abstract Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter$OnItemClickListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnItemClickListener"
.end annotation


# virtual methods
.method public abstract onItemClick(ILcn/damai/commonbusiness/photoselect/imageselected/entry/Image;)V
.end method
