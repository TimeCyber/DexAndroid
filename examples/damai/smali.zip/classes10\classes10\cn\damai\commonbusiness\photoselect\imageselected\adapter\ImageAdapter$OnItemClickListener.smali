.class public interface abstract Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$OnItemClickListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnItemClickListener"
.end annotation


# virtual methods
.method public abstract OnItemClick(Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;I)V
.end method
