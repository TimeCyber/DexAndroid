.class public Lcn/damai/commonbusiness/poplayer/view/h5/PopLayerWebView$b;
.super Landroid/text/style/ClickableSpan;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/poplayer/view/h5/PopLayerWebView;->getInfo()Landroid/text/SpannableStringBuilder;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcom/alibaba/poplayer/trigger/BaseConfigItem;

.field final synthetic b:Lcn/damai/commonbusiness/poplayer/view/h5/PopLayerWebView;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/poplayer/view/h5/PopLayerWebView;Lcom/alibaba/poplayer/trigger/BaseConfigItem;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/poplayer/view/h5/PopLayerWebView$b;->b:Lcn/damai/commonbusiness/poplayer/view/h5/PopLayerWebView;

    iput-object p2, p0, Lcn/damai/commonbusiness/poplayer/view/h5/PopLayerWebView$b;->a:Lcom/alibaba/poplayer/trigger/BaseConfigItem;

    invoke-direct {p0}, Landroid/text/style/ClickableSpan;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/poplayer/view/h5/PopLayerWebView$b;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    aput-object p1, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    new-instance p1, Landroid/app/AlertDialog$Builder;

    iget-object v0, p0, Lcn/damai/commonbusiness/poplayer/view/h5/PopLayerWebView$b;->b:Lcn/damai/commonbusiness/poplayer/view/h5/PopLayerWebView;

    invoke-virtual {v0}, Landroid/widget/FrameLayout;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v1, 0x3

    invoke-direct {p1, v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/poplayer/view/h5/PopLayerWebView$b;->a:Lcom/alibaba/poplayer/trigger/BaseConfigItem;

    invoke-virtual {v0}, Lcom/alibaba/poplayer/trigger/BaseConfigItem;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    new-array v0, v4, [Ljava/lang/Object;

    iget-object v1, p0, Lcn/damai/commonbusiness/poplayer/view/h5/PopLayerWebView$b;->a:Lcom/alibaba/poplayer/trigger/BaseConfigItem;

    iget-object v1, v1, Lcom/alibaba/poplayer/trigger/BaseConfigItem;->uuid:Ljava/lang/String;

    aput-object v1, v0, v3

    const-string v1, "Configuration DescItem for %s"

    .line 3
    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object p1

    .line 4
    invoke-virtual {p1}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/16 v1, 0x7f6

    invoke-virtual {v0, v1}, Landroid/view/Window;->setType(I)V

    .line 5
    invoke-virtual {p1}, Landroid/app/AlertDialog;->show()V

    return-void
.end method
