.class public Lcn/damai/commonbusiness/brand/BrandOptimizationDO;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon; = null

.field private static final TYPE_COMING_PERFORMANCE:Ljava/lang/String; = "3"

.field private static final TYPE_MOST_HOT:Ljava/lang/String; = "1"

.field private static final TYPE_NEW_SALE:Ljava/lang/String; = "2"

.field public static final serialVersionUID:J = 0x5e8cd4196a66aedbL


# instance fields
.field public city:Ljava/lang/String;

.field public cover:Ljava/lang/String;

.field public id:Ljava/lang/String;

.field public itemName:Ljava/lang/String;

.field public lable:Ljava/lang/String;

.field public local:Z

.field public schema:Ljava/lang/String;

.field public tagUrl:Ljava/lang/String;

.field public type:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private getDMLabelType()Lcn/damai/uikit/view/DMLabelType;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/brand/BrandOptimizationDO;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_17

    new-array v2, v3, [Ljava/lang/Object;

    aput-object p0, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/uikit/view/DMLabelType;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/brand/BrandOptimizationDO;->type:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    const/4 v2, -0x1

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v5

    packed-switch v5, :pswitch_data_50

    :goto_24
    const/4 v3, -0x1

    goto :goto_42

    :pswitch_26
    const-string v1, "3"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2f

    goto :goto_24

    :cond_2f
    const/4 v3, 0x2

    goto :goto_42

    :pswitch_31
    const-string v1, "2"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_42

    goto :goto_24

    :pswitch_3a
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_41

    goto :goto_24

    :cond_41
    const/4 v3, 0x0

    :cond_42
    :goto_42
    packed-switch v3, :pswitch_data_5a

    const/4 v0, 0x0

    return-object v0

    .line 2
    :pswitch_47
    sget-object v0, Lcn/damai/uikit/view/DMLabelType;->LABEL_TYPE_UPCOMING_PERFORMANCE:Lcn/damai/uikit/view/DMLabelType;

    return-object v0

    .line 3
    :pswitch_4a
    sget-object v0, Lcn/damai/uikit/view/DMLabelType;->LABEL_TYPE_NEW_SALE:Lcn/damai/uikit/view/DMLabelType;

    return-object v0

    .line 4
    :pswitch_4d
    sget-object v0, Lcn/damai/uikit/view/DMLabelType;->LABEL_TYPE_HIGHEST_HOT:Lcn/damai/uikit/view/DMLabelType;

    return-object v0

    :pswitch_data_50
    .packed-switch 0x31
        :pswitch_3a
        :pswitch_31
        :pswitch_26
    .end packed-switch

    :pswitch_data_5a
    .packed-switch 0x0
        :pswitch_4d
        :pswitch_4a
        :pswitch_47
    .end packed-switch
.end method


# virtual methods
.method public updatePosterView(Lcn/damai/uikit/view/DMPosterView;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/brand/BrandOptimizationDO;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_17
    if-nez p1, :cond_1a

    return-void

    .line 1
    :cond_1a
    iget-object v0, p0, Lcn/damai/commonbusiness/brand/BrandOptimizationDO;->cover:Ljava/lang/String;

    invoke-virtual {p1, v0}, Lcom/alibaba/pictures/bricks/view/DMPosterView;->setImageUrl(Ljava/lang/String;)V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/brand/BrandOptimizationDO;->city:Ljava/lang/String;

    invoke-virtual {p1, v0}, Lcom/alibaba/pictures/bricks/view/DMPosterView;->setCategoryTagName(Ljava/lang/String;)V

    .line 3
    invoke-direct {p0}, Lcn/damai/commonbusiness/brand/BrandOptimizationDO;->getDMLabelType()Lcn/damai/uikit/view/DMLabelType;

    move-result-object v0

    invoke-virtual {p1, v0}, Lcom/alibaba/pictures/bricks/view/DMPosterView;->setLabelType(Lcn/damai/uikit/view/DMLabelType;)V

    return-void
.end method
