.class public Lcn/damai/commonbusiness/city/CitySelectActivity$b;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/text/TextWatcher;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/city/CitySelectActivity;->initSearchView()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/city/CitySelectActivity;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/city/CitySelectActivity;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/city/CitySelectActivity$b;->a:Lcn/damai/commonbusiness/city/CitySelectActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static synthetic a(Lcn/damai/commonbusiness/city/CitySelectActivity$b;Ljava/util/List;)V
    .registers 2

    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/city/CitySelectActivity$b;->b(Ljava/util/List;)V

    return-void
.end method

.method private synthetic b(Ljava/util/List;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lcn/damai/commonbusiness/city/CitySelectActivity$b;->a:Lcn/damai/commonbusiness/city/CitySelectActivity;

    invoke-static {v0, p1}, Lcn/damai/commonbusiness/city/CitySelectActivity;->access$1600(Lcn/damai/commonbusiness/city/CitySelectActivity;Ljava/util/List;)V

    return-void
.end method


# virtual methods
.method public afterTextChanged(Landroid/text/Editable;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/city/CitySelectActivity$b;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_16

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    :cond_16
    return-void
.end method

.method public beforeTextChanged(Ljava/lang/CharSequence;III)V
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/city/CitySelectActivity$b;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_2b

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2b
    return-void
.end method

.method public onTextChanged(Ljava/lang/CharSequence;III)V
    .registers 10

    sget-object v0, Lcn/damai/commonbusiness/city/CitySelectActivity$b;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_2c

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_2c
    invoke-interface {p1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    .line 2
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    if-eqz p2, :cond_61

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/city/CitySelectActivity$b;->a:Lcn/damai/commonbusiness/city/CitySelectActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/city/CitySelectActivity;->access$1100(Lcn/damai/commonbusiness/city/CitySelectActivity;)Landroid/widget/LinearLayout;

    move-result-object p1

    const/16 p2, 0x8

    invoke-virtual {p1, p2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 4
    iget-object p1, p0, Lcn/damai/commonbusiness/city/CitySelectActivity$b;->a:Lcn/damai/commonbusiness/city/CitySelectActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/city/CitySelectActivity;->access$1200(Lcn/damai/commonbusiness/city/CitySelectActivity;)Lcn/damai/uikit/iconfont/DMIconFontTextView;

    move-result-object p1

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setVisibility(I)V

    .line 5
    iget-object p1, p0, Lcn/damai/commonbusiness/city/CitySelectActivity$b;->a:Lcn/damai/commonbusiness/city/CitySelectActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/city/CitySelectActivity;->access$1300(Lcn/damai/commonbusiness/city/CitySelectActivity;)Landroidx/recyclerview/widget/RecyclerView;

    move-result-object p1

    invoke-virtual {p1, p2}, Landroid/view/ViewGroup;->setVisibility(I)V

    .line 6
    iget-object p1, p0, Lcn/damai/commonbusiness/city/CitySelectActivity$b;->a:Lcn/damai/commonbusiness/city/CitySelectActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/city/CitySelectActivity;->access$1400(Lcn/damai/commonbusiness/city/CitySelectActivity;)Landroid/widget/LinearLayout;

    move-result-object p1

    invoke-virtual {p1, p2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    goto :goto_81

    .line 7
    :cond_61
    iget-object p2, p0, Lcn/damai/commonbusiness/city/CitySelectActivity$b;->a:Lcn/damai/commonbusiness/city/CitySelectActivity;

    invoke-static {p2}, Lcn/damai/commonbusiness/city/CitySelectActivity;->access$1200(Lcn/damai/commonbusiness/city/CitySelectActivity;)Lcn/damai/uikit/iconfont/DMIconFontTextView;

    move-result-object p2

    invoke-virtual {p2, v4}, Landroid/widget/TextView;->setVisibility(I)V

    .line 8
    new-instance p2, Lcn/damai/commonbusiness/city/CityFilterTask;

    iget-object p3, p0, Lcn/damai/commonbusiness/city/CitySelectActivity$b;->a:Lcn/damai/commonbusiness/city/CitySelectActivity;

    invoke-static {p3}, Lcn/damai/commonbusiness/city/CitySelectActivity;->access$1500(Lcn/damai/commonbusiness/city/CitySelectActivity;)Ljava/util/List;

    move-result-object p3

    new-instance p4, Ltb/b10;

    invoke-direct {p4, p0}, Ltb/b10;-><init>(Lcn/damai/commonbusiness/city/CitySelectActivity$b;)V

    invoke-direct {p2, p3, p4}, Lcn/damai/commonbusiness/city/CityFilterTask;-><init>(Ljava/util/List;Lcn/damai/commonbusiness/city/CityFilterTask$OnResultListener;)V

    new-array p3, v3, [Ljava/lang/String;

    aput-object p1, p3, v4

    .line 9
    invoke-virtual {p2, p3}, Landroid/os/AsyncTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    :goto_81
    return-void
.end method
