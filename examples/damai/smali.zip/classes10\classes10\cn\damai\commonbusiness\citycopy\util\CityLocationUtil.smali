.class public Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil$LocaltionListener;
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private a:Landroid/content/Context;

.field public b:Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil$LocaltionListener;

.field private c:J

.field private d:Ljava/lang/Double;

.field private e:Ljava/lang/Double;

.field private f:Ljava/lang/String;

.field private g:Ljava/lang/String;

.field private h:Z

.field private i:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil$LocaltionListener;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->h:Z

    const/4 v0, 0x1

    .line 3
    iput-boolean v0, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->i:Z

    .line 4
    iput-object p1, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->a:Landroid/content/Context;

    .line 5
    iput-object p2, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->b:Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil$LocaltionListener;

    return-void
.end method

.method static synthetic a(Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;)Ljava/lang/Double;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->d:Ljava/lang/Double;

    return-object p0
.end method

.method static synthetic b(Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;Ljava/lang/Double;)Ljava/lang/Double;
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->d:Ljava/lang/Double;

    return-object p1
.end method

.method static synthetic c(Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;)Ljava/lang/Double;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->e:Ljava/lang/Double;

    return-object p0
.end method

.method static synthetic d(Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;Ljava/lang/Double;)Ljava/lang/Double;
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->e:Ljava/lang/Double;

    return-object p1
.end method

.method static synthetic e(Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->f:Ljava/lang/String;

    return-object p1
.end method

.method static synthetic f(Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;)Ljava/lang/String;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->g:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic g(Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->g:Ljava/lang/String;

    return-object p1
.end method

.method static synthetic h(Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;Ljava/lang/String;)J
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->l(Ljava/lang/String;)J

    move-result-wide p0

    return-wide p0
.end method

.method static synthetic i(Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;J)J
    .registers 3

    .line 1
    iput-wide p1, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->c:J

    return-wide p1
.end method

.method static synthetic j(Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;)Z
    .registers 1

    .line 1
    iget-boolean p0, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->i:Z

    return p0
.end method

.method static synthetic k(Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;)Z
    .registers 1

    .line 1
    iget-boolean p0, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->h:Z

    return p0
.end method

.method private l(Ljava/lang/String;)J
    .registers 12

    sget-object v0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Long;

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    return-wide v0

    .line 1
    :cond_1e
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const-wide/16 v1, 0x0

    if-eqz v0, :cond_27

    return-wide v1

    .line 2
    :cond_27
    :try_start_27
    sget-object v0, Ltb/a90;->INSTANCE:Ltb/a90;

    invoke-virtual {v0}, Ltb/a90;->a()Lcom/alibaba/pictures/bricks/channel/bridge/ComponentFilterBridge;

    move-result-object v0

    invoke-interface {v0}, Lcom/alibaba/pictures/bricks/channel/bridge/ComponentFilterBridge;->getLocalCityList()Lcn/damai/commonbusiness/citycopy/net/CityListResponse;

    move-result-object v0

    if-nez v0, :cond_34

    return-wide v1

    .line 3
    :cond_34
    invoke-virtual {v0}, Lcn/damai/commonbusiness/citycopy/net/CityListResponse;->getGroups()Ljava/util/List;

    move-result-object v4

    .line 4
    invoke-static {v4}, Ltb/ak5;->c(Ljava/util/Collection;)I

    move-result v5

    if-gtz v5, :cond_3f

    return-wide v1

    :cond_3f
    const/4 v5, 0x0

    .line 5
    :goto_40
    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v6

    if-ge v5, v6, :cond_a4

    .line 6
    invoke-interface {v4, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcn/damai/commonbusiness/citycopy/model/GroupsBean;

    if-eqz v6, :cond_a1

    .line 7
    invoke-virtual {v6}, Lcn/damai/commonbusiness/citycopy/model/GroupsBean;->getSites()Ljava/util/List;

    move-result-object v6

    .line 8
    invoke-static {v6}, Ltb/ak5;->c(Ljava/util/Collection;)I

    move-result v7

    if-lez v7, :cond_a1

    const/4 v7, 0x0

    .line 9
    :goto_59
    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v8

    if-ge v7, v8, :cond_a1

    .line 10
    invoke-interface {v6, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcn/damai/commonbusiness/citycopy/model/SitesBean;

    if-eqz v8, :cond_9e

    .line 11
    invoke-virtual {v8}, Lcn/damai/commonbusiness/citycopy/model/SitesBean;->getCityName()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_9e

    .line 12
    invoke-virtual {v8}, Lcn/damai/commonbusiness/citycopy/model/SitesBean;->getCityName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_9e

    .line 13
    invoke-virtual {v8}, Lcn/damai/commonbusiness/citycopy/model/SitesBean;->getCityId()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_9e

    .line 14
    invoke-virtual {v8}, Lcn/damai/commonbusiness/citycopy/model/SitesBean;->getCityId()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_9e

    .line 15
    sget-object p1, Ltb/kw5;->INSTANCE:Ltb/kw5;

    invoke-virtual {v8}, Lcn/damai/commonbusiness/citycopy/model/SitesBean;->getCityId()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0, v1, v2}, Ltb/kw5;->j(Ljava/lang/String;J)J

    move-result-wide v0

    return-wide v0

    :cond_9e
    add-int/lit8 v7, v7, 0x1

    goto :goto_59

    :cond_a1
    add-int/lit8 v5, v5, 0x1

    goto :goto_40

    .line 16
    :cond_a4
    invoke-virtual {v0}, Lcn/damai/commonbusiness/citycopy/net/CityListResponse;->getHotCity()Ljava/util/List;

    move-result-object v0

    .line 17
    invoke-static {v4}, Ltb/ak5;->c(Ljava/util/Collection;)I

    move-result v4

    if-gtz v4, :cond_af

    return-wide v1

    .line 18
    :cond_af
    :goto_af
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v4

    if-ge v3, v4, :cond_fa

    .line 19
    invoke-interface {v0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcn/damai/commonbusiness/citycopy/model/HotCityBean;

    if-eqz v4, :cond_f3

    .line 20
    invoke-virtual {v4}, Lcn/damai/commonbusiness/citycopy/model/HotCityBean;->getCityName()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_f3

    .line 21
    invoke-virtual {v4}, Lcn/damai/commonbusiness/citycopy/model/HotCityBean;->getCityName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_f3

    .line 22
    invoke-virtual {v4}, Lcn/damai/commonbusiness/citycopy/model/HotCityBean;->getCityId()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_f3

    .line 23
    invoke-virtual {v4}, Lcn/damai/commonbusiness/citycopy/model/HotCityBean;->getCityId()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_f3

    .line 24
    invoke-virtual {v4}, Lcn/damai/commonbusiness/citycopy/model/HotCityBean;->getCityId()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p1
    :try_end_f1
    .catch Ljava/lang/Exception; {:try_start_27 .. :try_end_f1} :catch_f6

    int-to-long v0, p1

    return-wide v0

    :cond_f3
    add-int/lit8 v3, v3, 0x1

    goto :goto_af

    :catch_f6
    move-exception p1

    .line 25
    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    :cond_fa
    return-wide v1
.end method


# virtual methods
.method public m()V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_14

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_14
    const-wide/32 v0, 0x493e0

    .line 1
    invoke-static {}, Ltb/nc0;->f()Ltb/k20;

    move-result-object v2

    const-string v4, "city_location_use_cache_time"

    const-string v5, "on"

    invoke-virtual {v2, v4, v5, v3}, Ltb/k20;->isExpected(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v2

    .line 2
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "useCacheTime\uff1a"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz v2, :cond_32

    const-string v4, "\u4f7f\u75285\u5206\u949f\u5b9a\u4f4d\u7f13\u5b58"

    goto :goto_34

    :cond_32
    const-string v4, "\u672a\u4f7f\u7528\u5b9a\u4f4d\u7f13\u5b58"

    :goto_34
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, "CityLocationUtil"

    invoke-static {v4, v3}, Ltb/fv2;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 3
    sget-object v3, Ltb/ic6;->INSTANCE:Ltb/ic6;

    iget-object v4, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->a:Landroid/content/Context;

    invoke-virtual {v3, v4}, Ltb/ic6;->f(Landroid/content/Context;)Z

    move-result v3

    if-eqz v3, :cond_65

    .line 4
    new-instance v3, Ltb/st2;

    invoke-direct {v3}, Ltb/st2;-><init>()V

    if-eqz v2, :cond_52

    goto :goto_54

    :cond_52
    const-wide/16 v0, 0x0

    .line 5
    :goto_54
    invoke-virtual {v3, v0, v1}, Ltb/st2;->e(J)V

    .line 6
    sget-object v0, Ltb/eu2;->INSTANCE:Ltb/eu2;

    invoke-virtual {v0}, Ltb/eu2;->e()Lcom/alibaba/pictures/piclocation/LocationInterface;

    move-result-object v0

    new-instance v1, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil$a;

    invoke-direct {v1, p0}, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil$a;-><init>(Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;)V

    invoke-interface {v0, v1, v3}, Lcom/alibaba/pictures/piclocation/LocationInterface;->startLocation(Lcom/alibaba/pictures/piclocation/listener/LocateGpsPicListener;Ltb/st2;)V

    :cond_65
    return-void
.end method

.method public n()V
    .registers 14

    sget-object v0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-wide v5, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->c:J

    const-wide/16 v0, 0x0

    cmp-long v2, v5, v0

    if-eqz v2, :cond_3b

    .line 2
    new-instance v0, Lcom/alibaba/pictures/bricks/channel/bean/LocationInfo;

    iget-object v1, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->d:Ljava/lang/Double;

    .line 3
    invoke-virtual {v1}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v7

    iget-object v1, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->e:Ljava/lang/Double;

    invoke-virtual {v1}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v9

    iget-object v11, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->f:Ljava/lang/String;

    iget-object v12, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->g:Ljava/lang/String;

    move-object v4, v0

    invoke-direct/range {v4 .. v12}, Lcom/alibaba/pictures/bricks/channel/bean/LocationInfo;-><init>(JDDLjava/lang/String;Ljava/lang/String;)V

    .line 4
    sget-object v1, Ltb/a90;->INSTANCE:Ltb/a90;

    invoke-virtual {v1}, Ltb/a90;->a()Lcom/alibaba/pictures/bricks/channel/bridge/ComponentFilterBridge;

    move-result-object v1

    invoke-interface {v1, v0}, Lcom/alibaba/pictures/bricks/channel/bridge/ComponentFilterBridge;->saveLocationInfo(Lcom/alibaba/pictures/bricks/channel/bean/LocationInfo;)V

    :cond_3b
    return-void
.end method

.method public o(Z)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iput-boolean p1, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->h:Z

    return-void
.end method

.method public p()V
    .registers 13

    sget-object v0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-wide v5, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->c:J

    const-wide/16 v0, 0x0

    cmp-long v2, v5, v0

    if-eqz v2, :cond_39

    .line 2
    new-instance v0, Lcom/alibaba/pictures/bricks/channel/bean/NewLocationInfo;

    iget-object v7, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->g:Ljava/lang/String;

    iget-object v1, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->d:Ljava/lang/Double;

    invoke-virtual {v1}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v8

    iget-object v1, p0, Lcn/damai/commonbusiness/citycopy/util/CityLocationUtil;->e:Ljava/lang/Double;

    invoke-virtual {v1}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v10

    move-object v4, v0

    invoke-direct/range {v4 .. v11}, Lcom/alibaba/pictures/bricks/channel/bean/NewLocationInfo;-><init>(JLjava/lang/String;DD)V

    .line 3
    sget-object v1, Ltb/a90;->INSTANCE:Ltb/a90;

    invoke-virtual {v1}, Ltb/a90;->a()Lcom/alibaba/pictures/bricks/channel/bridge/ComponentFilterBridge;

    move-result-object v1

    invoke-interface {v1, v0}, Lcom/alibaba/pictures/bricks/channel/bridge/ComponentFilterBridge;->setNewLocationData(Lcom/alibaba/pictures/bricks/channel/bean/NewLocationInfo;)V

    :cond_39
    return-void
.end method
