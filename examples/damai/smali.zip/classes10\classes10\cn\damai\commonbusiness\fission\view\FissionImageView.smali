.class public Lcn/damai/commonbusiness/fission/view/FissionImageView;
.super Landroid/widget/RelativeLayout;
.source "Taobao"


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private cb_main_message:Landroid/widget/TextView;

.field private cb_my_invite_content:Landroid/widget/TextView;

.field private cb_sub_message:Landroid/widget/TextView;

.field private cb_user_icon:Lcn/damai/uikit/view/DMAvatar;

.field private cb_user_layout:Landroid/widget/LinearLayout;

.field private cb_user_name:Landroid/widget/TextView;

.field private context:Landroid/content/Context;

.field private fission_content_up_bg:Landroid/view/View;

.field private fission_image:Landroid/widget/ImageView;

.field private fission_image_bg:Landroid/widget/LinearLayout;

.field private fission_mask_layout:Landroid/widget/RelativeLayout;

.field private holecardView:Lcn/damai/uikit/view/HoleCardView;

.field private layout:Landroid/widget/RelativeLayout;

.field private maskDownBgView:Landroid/view/View;

.field private partent:Landroid/view/View;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, p1, v0}, Lcn/damai/commonbusiness/fission/view/FissionImageView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 4

    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, p1, p2, v0}, Lcn/damai/commonbusiness/fission/view/FissionImageView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4

    .line 3
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 4
    iput-object p1, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->context:Landroid/content/Context;

    .line 5
    invoke-direct {p0}, Lcn/damai/commonbusiness/fission/view/FissionImageView;->initView()V

    return-void
.end method

.method private initView()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->context:Landroid/content/Context;

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    sget v1, Lcn/damai/commonbusiness/R$layout;->fission_image_layout:I

    invoke-virtual {v0, v1, p0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->partent:Landroid/view/View;

    .line 2
    sget v1, Lcn/damai/commonbusiness/R$id;->layout:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/RelativeLayout;

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->layout:Landroid/widget/RelativeLayout;

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->partent:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->holecardView:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcn/damai/uikit/view/HoleCardView;

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->holecardView:Lcn/damai/uikit/view/HoleCardView;

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->partent:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->fission_image_bg:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->fission_image_bg:Landroid/widget/LinearLayout;

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->partent:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->fission_image:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->fission_image:Landroid/widget/ImageView;

    .line 6
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->partent:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->cb_my_invite_content:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_my_invite_content:Landroid/widget/TextView;

    .line 7
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->partent:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->cb_user_layout:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_user_layout:Landroid/widget/LinearLayout;

    .line 8
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->partent:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->cb_user_icon:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcn/damai/uikit/view/DMAvatar;

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_user_icon:Lcn/damai/uikit/view/DMAvatar;

    .line 9
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->partent:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->cb_user_name:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_user_name:Landroid/widget/TextView;

    .line 10
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_user_icon:Lcn/damai/uikit/view/DMAvatar;

    sget-object v1, Lcom/alibaba/pictures/bricks/view/DMAvatar$DMAvatarSize;->SIZE_40x40:Lcom/alibaba/pictures/bricks/view/DMAvatar$DMAvatarSize;

    invoke-virtual {v0, v1}, Lcom/alibaba/pictures/bricks/view/DMAvatar;->setAvatarSize(Lcom/alibaba/pictures/bricks/view/DMAvatar$DMAvatarSize;)V

    .line 11
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->partent:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->fission_mask_layout:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/RelativeLayout;

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->fission_mask_layout:Landroid/widget/RelativeLayout;

    .line 12
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->partent:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->cb_sub_message:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_sub_message:Landroid/widget/TextView;

    .line 13
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->partent:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->cb_main_message:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_main_message:Landroid/widget/TextView;

    .line 14
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->partent:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->fission_content_up_bg:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->fission_content_up_bg:Landroid/view/View;

    .line 15
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->partent:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->fission_content_down_bg:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->maskDownBgView:Landroid/view/View;

    return-void
.end method

.method private setBackGround(II)Landroid/graphics/drawable/GradientDrawable;
    .registers 10

    sget-object v0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-eqz v2, :cond_25

    new-array v2, v3, [Ljava/lang/Object;

    aput-object p0, v2, v5

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v4

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v6

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/graphics/drawable/GradientDrawable;

    return-object p1

    .line 1
    :cond_25
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    sget-object v1, Landroid/graphics/drawable/GradientDrawable$Orientation;->TOP_BOTTOM:Landroid/graphics/drawable/GradientDrawable$Orientation;

    new-array v2, v6, [I

    aput p1, v2, v5

    aput p2, v2, v4

    invoke-direct {v0, v1, v2}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    const/16 p1, 0x8

    new-array p1, p1, [F

    .line 2
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->context:Landroid/content/Context;

    const/high16 v1, 0x41c00000    # 24.0f

    invoke-static {p2, v1}, Ltb/g31;->a(Landroid/content/Context;F)I

    move-result p2

    int-to-float p2, p2

    aput p2, p1, v5

    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->context:Landroid/content/Context;

    invoke-static {p2, v1}, Ltb/g31;->a(Landroid/content/Context;F)I

    move-result p2

    int-to-float p2, p2

    aput p2, p1, v4

    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->context:Landroid/content/Context;

    .line 3
    invoke-static {p2, v1}, Ltb/g31;->a(Landroid/content/Context;F)I

    move-result p2

    int-to-float p2, p2

    aput p2, p1, v6

    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->context:Landroid/content/Context;

    invoke-static {p2, v1}, Ltb/g31;->a(Landroid/content/Context;F)I

    move-result p2

    int-to-float p2, p2

    aput p2, p1, v3

    const/4 p2, 0x4

    const/4 v1, 0x0

    aput v1, p1, p2

    const/4 p2, 0x5

    aput v1, p1, p2

    const/4 p2, 0x6

    aput v1, p1, p2

    const/4 p2, 0x7

    aput v1, p1, p2

    .line 4
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadii([F)V

    return-object v0
.end method


# virtual methods
.method public getColorWithAlpha(FI)I
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_29

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    return p1

    :cond_29
    const/16 v0, 0xff

    const/high16 v1, 0x437f0000    # 255.0f

    mul-float p1, p1, v1

    float-to-int p1, p1

    .line 1
    invoke-static {v3, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    invoke-static {v0, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    shl-int/lit8 p1, p1, 0x18

    const v0, 0xffffff

    and-int/2addr p2, v0

    add-int/2addr p1, p2

    return p1
.end method

.method public update(Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;IIIZ)V
    .registers 13

    sget-object v0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-eqz v2, :cond_33

    const/4 v2, 0x6

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v6

    aput-object p1, v2, v4

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 p2, 0x3

    aput-object p1, v2, p2

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v5

    const/4 p1, 0x5

    invoke-static {p5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_33
    if-nez p1, :cond_36

    return-void

    .line 1
    :cond_36
    iget-object p4, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->holecardView:Lcn/damai/uikit/view/HoleCardView;

    if-eqz p5, :cond_3b

    goto :goto_3c

    :cond_3b
    const/4 v3, 0x1

    :goto_3c
    invoke-virtual {p4, v3}, Lcn/damai/uikit/view/HoleCardView;->setLayerTypeMode(I)V

    .line 2
    iget-object p4, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->fission_image_bg:Landroid/widget/LinearLayout;

    invoke-virtual {p4}, Landroid/widget/LinearLayout;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p4

    check-cast p4, Landroid/widget/RelativeLayout$LayoutParams;

    .line 3
    iput p3, p4, Landroid/widget/RelativeLayout$LayoutParams;->height:I

    .line 4
    iput p2, p4, Landroid/widget/RelativeLayout$LayoutParams;->width:I

    .line 5
    iget-object p4, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->maskDownBgView:Landroid/view/View;

    invoke-virtual {p4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p4

    check-cast p4, Landroid/widget/RelativeLayout$LayoutParams;

    const-string p5, "#00000000"

    .line 6
    invoke-static {p5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p5

    const v0, 0x3f19999a    # 0.6f

    .line 7
    iget v2, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->bgColor:I

    invoke-virtual {p0, v0, v2}, Lcn/damai/commonbusiness/fission/view/FissionImageView;->getColorWithAlpha(FI)I

    move-result v0

    .line 8
    iget-object v2, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->channel:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_83

    const-string p5, "#33000000"

    .line 9
    invoke-static {p5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p5

    .line 10
    iget v0, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->bgColor:I

    mul-int/lit8 v1, p2, 0x3

    .line 11
    div-int/2addr v1, v5

    sub-int/2addr p3, v1

    .line 12
    iget-object v2, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->context:Landroid/content/Context;

    const/high16 v3, 0x41a00000    # 20.0f

    invoke-static {v2, v3}, Ltb/g31;->a(Landroid/content/Context;F)I

    move-result v2

    add-int/2addr p3, v2

    iput p3, p4, Landroid/widget/RelativeLayout$LayoutParams;->height:I

    move p3, v1

    goto :goto_8d

    .line 13
    :cond_83
    iget-object v1, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->context:Landroid/content/Context;

    const/high16 v2, 0x42c80000    # 100.0f

    invoke-static {v1, v2}, Ltb/g31;->a(Landroid/content/Context;F)I

    move-result v1

    iput v1, p4, Landroid/widget/RelativeLayout$LayoutParams;->height:I

    .line 14
    :goto_8d
    iget-object p4, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->mainMessage:Ljava/lang/String;

    invoke-static {p4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p4

    const/16 v1, 0x8

    if-nez p4, :cond_a4

    .line 15
    iget-object p4, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_main_message:Landroid/widget/TextView;

    invoke-virtual {p4, v6}, Landroid/widget/TextView;->setVisibility(I)V

    .line 16
    iget-object p4, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_main_message:Landroid/widget/TextView;

    iget-object v2, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->mainMessage:Ljava/lang/String;

    invoke-virtual {p4, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_a9

    .line 17
    :cond_a4
    iget-object p4, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_main_message:Landroid/widget/TextView;

    invoke-virtual {p4, v1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 18
    :goto_a9
    iget-object p4, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->subMessage:Ljava/lang/String;

    invoke-static {p4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p4

    if-nez p4, :cond_be

    .line 19
    iget-object p4, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_sub_message:Landroid/widget/TextView;

    invoke-virtual {p4, v6}, Landroid/widget/TextView;->setVisibility(I)V

    .line 20
    iget-object p4, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_sub_message:Landroid/widget/TextView;

    iget-object v2, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->subMessage:Ljava/lang/String;

    invoke-virtual {p4, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_c3

    .line 21
    :cond_be
    iget-object p4, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_sub_message:Landroid/widget/TextView;

    invoke-virtual {p4, v1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 22
    :goto_c3
    iget-object p4, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->fission_image:Landroid/widget/ImageView;

    invoke-virtual {p4}, Landroid/widget/ImageView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p4

    check-cast p4, Landroid/widget/LinearLayout$LayoutParams;

    .line 23
    iput p2, p4, Landroid/widget/LinearLayout$LayoutParams;->width:I

    .line 24
    iput p3, p4, Landroid/widget/LinearLayout$LayoutParams;->height:I

    .line 25
    iget-object p2, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->bitmap:Landroid/graphics/Bitmap;

    if-eqz p2, :cond_d9

    .line 26
    iget-object p3, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->fission_image:Landroid/widget/ImageView;

    invoke-virtual {p3, p2}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    goto :goto_e4

    .line 27
    :cond_d9
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->fission_image:Landroid/widget/ImageView;

    const-string p3, "#f5f5f5"

    invoke-static {p3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p3

    invoke-virtual {p2, p3}, Landroid/widget/ImageView;->setBackgroundColor(I)V

    .line 28
    :goto_e4
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 p3, 0x10

    if-lt p2, p3, :cond_f4

    .line 29
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->fission_content_up_bg:Landroid/view/View;

    invoke-direct {p0, p5, v0}, Lcn/damai/commonbusiness/fission/view/FissionImageView;->setBackGround(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p3

    invoke-virtual {p2, p3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_fd

    .line 30
    :cond_f4
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->fission_content_up_bg:Landroid/view/View;

    invoke-direct {p0, p5, v0}, Lcn/damai/commonbusiness/fission/view/FissionImageView;->setBackGround(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p3

    invoke-virtual {p2, p3}, Landroid/view/View;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 31
    :goto_fd
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->maskDownBgView:Landroid/view/View;

    invoke-virtual {p2, v0}, Landroid/view/View;->setBackgroundColor(I)V

    .line 32
    iget-object p2, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->chickenSoup:Ljava/lang/String;

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    if-nez p2, :cond_117

    .line 33
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_my_invite_content:Landroid/widget/TextView;

    invoke-virtual {p2, v6}, Landroid/widget/TextView;->setVisibility(I)V

    .line 34
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_my_invite_content:Landroid/widget/TextView;

    iget-object p3, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->chickenSoup:Ljava/lang/String;

    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_11c

    .line 35
    :cond_117
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_my_invite_content:Landroid/widget/TextView;

    invoke-virtual {p2, v5}, Landroid/widget/TextView;->setVisibility(I)V

    .line 36
    :goto_11c
    iget-object p2, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->userInfo:Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;

    if-eqz p2, :cond_175

    iget-object p2, p2, Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;->nickname:Ljava/lang/String;

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    if-eqz p2, :cond_129

    goto :goto_175

    .line 37
    :cond_129
    iget-object p2, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->userInfo:Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;

    iget-object p2, p2, Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;->nickname:Ljava/lang/String;

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    if-nez p2, :cond_142

    .line 38
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_user_name:Landroid/widget/TextView;

    invoke-virtual {p2, v6}, Landroid/widget/TextView;->setVisibility(I)V

    .line 39
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_user_name:Landroid/widget/TextView;

    iget-object p3, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->userInfo:Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;

    iget-object p3, p3, Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;->nickname:Ljava/lang/String;

    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_147

    .line 40
    :cond_142
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_user_name:Landroid/widget/TextView;

    invoke-virtual {p2, v1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 41
    :goto_147
    iget-object p2, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->userInfo:Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;

    iget-object p2, p2, Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;->portraitUrl:Ljava/lang/String;

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    if-nez p2, :cond_15b

    .line 42
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_user_icon:Lcn/damai/uikit/view/DMAvatar;

    iget-object p3, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->userInfo:Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;

    iget-object p3, p3, Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;->portraitUrl:Ljava/lang/String;

    invoke-virtual {p2, p3}, Lcom/alibaba/pictures/bricks/view/DMAvatar;->setAvatar(Ljava/lang/String;)V

    goto :goto_162

    .line 43
    :cond_15b
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_user_icon:Lcn/damai/uikit/view/DMAvatar;

    sget p3, Lcn/damai/commonbusiness/R$drawable;->uikit_user_default_icon:I

    invoke-virtual {p2, p3}, Lcom/alibaba/pictures/bricks/view/DMAvatar;->setAvatarPlaceholder(I)V

    .line 44
    :goto_162
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_user_icon:Lcn/damai/uikit/view/DMAvatar;

    iget-object p1, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->userInfo:Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;

    iget-object p1, p1, Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;->performFilmVipDO:Lcn/damai/commonbusiness/yymember/bean/PerformFilmVipDO;

    if-eqz p1, :cond_16d

    iget-object p1, p1, Lcn/damai/commonbusiness/yymember/bean/PerformFilmVipDO;->memberFlag:Ljava/lang/String;

    goto :goto_171

    :cond_16d
    invoke-static {}, Ltb/w27;->h()Ljava/lang/String;

    move-result-object p1

    :goto_171
    invoke-virtual {p2, v6, p1}, Lcom/alibaba/pictures/bricks/view/DMAvatar;->setYYMemberTagView(ZLjava/lang/String;)V

    goto :goto_18c

    .line 45
    :cond_175
    :goto_175
    iget-object p1, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_user_name:Landroid/widget/TextView;

    const-string p2, "\u5927\u9ea6"

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 46
    iget-object p1, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_user_icon:Lcn/damai/uikit/view/DMAvatar;

    sget p2, Lcn/damai/commonbusiness/R$drawable;->mine_account_default:I

    invoke-virtual {p1, p2}, Lcom/alibaba/pictures/bricks/view/DMAvatar;->setAvatar(I)V

    .line 47
    iget-object p1, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_user_icon:Lcn/damai/uikit/view/DMAvatar;

    invoke-static {}, Ltb/w27;->h()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, v6, p2}, Lcom/alibaba/pictures/bricks/view/DMAvatar;->setYYMemberTagView(ZLjava/lang/String;)V

    .line 48
    :goto_18c
    iget-object p1, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_user_icon:Lcn/damai/uikit/view/DMAvatar;

    invoke-virtual {p1, v1}, Lcom/alibaba/pictures/bricks/view/DMAvatar;->setAvatarCrownVisibility(I)V

    .line 49
    iget-object p1, p0, Lcn/damai/commonbusiness/fission/view/FissionImageView;->cb_user_icon:Lcn/damai/uikit/view/DMAvatar;

    invoke-virtual {p1, v1}, Lcom/alibaba/pictures/bricks/view/DMAvatar;->setAvatarBorderVisibility(I)V

    return-void
.end method
