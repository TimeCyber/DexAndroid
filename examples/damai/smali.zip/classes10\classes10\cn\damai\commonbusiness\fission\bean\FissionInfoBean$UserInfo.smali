.class public Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/fission/bean/FissionInfoBean;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "UserInfo"
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x1L


# instance fields
.field public nickname:Ljava/lang/String;

.field public performFilmVipDO:Lcn/damai/commonbusiness/yymember/bean/PerformFilmVipDO;

.field public portraitUrl:Ljava/lang/String;

.field public shareCode:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
