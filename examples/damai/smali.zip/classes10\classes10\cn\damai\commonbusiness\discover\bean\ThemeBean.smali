.class public Lcn/damai/commonbusiness/discover/bean/ThemeBean;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x1L


# instance fields
.field public backgroundImg:Ljava/lang/String;

.field public colorGroup:Lcn/damai/commonbusiness/discover/bean/CircleStyle;

.field public hasJoin:Z

.field public headImage:Ljava/lang/String;

.field public id:Ljava/lang/String;

.field public joinHeadPics:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public joinTotal:Ljava/lang/String;

.field public themeDesc:Ljava/lang/String;

.field public themeName:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
