.class public Lcn/damai/commonbusiness/citycopy/adapter/CitySelectAdapter$a;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/citycopy/adapter/CitySelectAdapter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/citycopy/adapter/CitySelectAdapter;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/citycopy/adapter/CitySelectAdapter;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/citycopy/adapter/CitySelectAdapter$a;->a:Lcn/damai/commonbusiness/citycopy/adapter/CitySelectAdapter;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/citycopy/adapter/CitySelectAdapter$a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-static {}, Ltb/e95;->e()Z

    move-result v0

    if-eqz v0, :cond_1e

    return-void

    .line 2
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/citycopy/adapter/CitySelectAdapter$a;->a:Lcn/damai/commonbusiness/citycopy/adapter/CitySelectAdapter;

    invoke-static {v0}, Lcn/damai/commonbusiness/citycopy/adapter/CitySelectAdapter;->g(Lcn/damai/commonbusiness/citycopy/adapter/CitySelectAdapter;)Lcn/damai/commonbusiness/citycopy/listener/OnCityListItemClickListener;

    move-result-object v0

    if-nez v0, :cond_27

    return-void

    .line 3
    :cond_27
    invoke-virtual {p1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object p1

    .line 4
    instance-of v0, p1, Ltb/d10;

    if-eqz v0, :cond_5d

    .line 5
    check-cast p1, Ltb/d10;

    .line 6
    iget v0, p1, Ltb/d10;->c:I

    const/16 v1, 0x66

    if-eq v0, v1, :cond_54

    const/16 v1, 0x88

    if-eq v0, v1, :cond_3c

    goto :goto_5d

    .line 7
    :cond_3c
    invoke-virtual {p1}, Ltb/d10;->b()Lcn/damai/commonbusiness/citycopy/model/SitesBean;

    move-result-object p1

    if-eqz p1, :cond_5d

    .line 8
    iget-object v0, p0, Lcn/damai/commonbusiness/citycopy/adapter/CitySelectAdapter$a;->a:Lcn/damai/commonbusiness/citycopy/adapter/CitySelectAdapter;

    invoke-static {v0}, Lcn/damai/commonbusiness/citycopy/adapter/CitySelectAdapter;->g(Lcn/damai/commonbusiness/citycopy/adapter/CitySelectAdapter;)Lcn/damai/commonbusiness/citycopy/listener/OnCityListItemClickListener;

    move-result-object v0

    invoke-virtual {p1}, Lcn/damai/commonbusiness/citycopy/model/SitesBean;->getCityId()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1}, Lcn/damai/commonbusiness/citycopy/model/SitesBean;->getCityName()Ljava/lang/String;

    move-result-object p1

    invoke-interface {v0, v1, p1}, Lcn/damai/commonbusiness/citycopy/listener/OnCityListItemClickListener;->onLocationCityClick(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_5d

    .line 9
    :cond_54
    iget-object p1, p0, Lcn/damai/commonbusiness/citycopy/adapter/CitySelectAdapter$a;->a:Lcn/damai/commonbusiness/citycopy/adapter/CitySelectAdapter;

    invoke-static {p1}, Lcn/damai/commonbusiness/citycopy/adapter/CitySelectAdapter;->g(Lcn/damai/commonbusiness/citycopy/adapter/CitySelectAdapter;)Lcn/damai/commonbusiness/citycopy/listener/OnCityListItemClickListener;

    move-result-object p1

    invoke-interface {p1}, Lcn/damai/commonbusiness/citycopy/listener/OnCityListItemClickListener;->onRequestLocationPermission()V

    :cond_5d
    :goto_5d
    return-void
.end method
