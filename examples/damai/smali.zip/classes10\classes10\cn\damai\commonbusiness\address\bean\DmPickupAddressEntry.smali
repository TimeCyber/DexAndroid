.class public Lcn/damai/commonbusiness/address/bean/DmPickupAddressEntry;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public address:Ljava/lang/String;

.field public businessHours:Ljava/lang/String;

.field public distance:Ljava/lang/String;

.field public name:Ljava/lang/String;

.field public pickupAdressId:Ljava/lang/String;

.field public tag:Ljava/lang/String;

.field public tel:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
