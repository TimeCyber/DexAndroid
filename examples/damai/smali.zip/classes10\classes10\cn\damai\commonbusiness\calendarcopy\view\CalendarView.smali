.class public Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;
.super Landroid/view/ViewGroup;
.source "Taobao"


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private mBubbleColumn:I

.field private mBubbleRow:I

.field private mContext:Landroid/content/Context;

.field private mDayHeigth:I

.field private mDayWidth:I

.field private mDays:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/calendarcopy/bean/Day;",
            ">;"
        }
    .end annotation
.end field

.field private mIsCurrentMonth:Z

.field mIsPioneer:Z

.field private mItemClickListener:Landroid/view/View$OnClickListener;

.field private mMonth:I

.field private mProjectTag:Ljava/lang/String;

.field private mRowNum:I

.field private mStartWeek:I

.field private mWidth:I

.field private mYear:I


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, p1, v0}, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 2
    invoke-direct {p0}, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->initPioneer()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 3

    .line 3
    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 p2, 0x0

    .line 4
    iput p2, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mBubbleRow:I

    .line 5
    iput p2, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mBubbleColumn:I

    .line 6
    iput-boolean p2, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mIsPioneer:Z

    .line 7
    iput-object p1, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mContext:Landroid/content/Context;

    .line 8
    invoke-direct {p0}, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->initPioneer()V

    return-void
.end method

.method private fakeday(Lcn/damai/commonbusiness/calendarcopy/bean/Day;)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "8"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v2, :cond_17

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    aput-object p1, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget v0, p1, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->day:I

    rem-int/lit8 v1, v0, 0x3

    const-string v2, ""

    if-nez v1, :cond_22

    .line 2
    iput-object v2, p1, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->tip:Ljava/lang/String;

    goto :goto_2f

    .line 3
    :cond_22
    rem-int/lit8 v1, v0, 0x3

    if-ne v1, v4, :cond_2b

    const-string v1, "\u4e00\u4e8c\u4e09\u56db"

    .line 4
    iput-object v1, p1, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->tip:Ljava/lang/String;

    goto :goto_2f

    :cond_2b
    const-string v1, "\u4e00\u4e8c\u4e09\u56db\u4e94\u516d\u4e03"

    .line 5
    iput-object v1, p1, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->tip:Ljava/lang/String;

    .line 6
    :goto_2f
    rem-int/lit8 v1, v0, 0x3

    iput v1, p1, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->dayType:I

    .line 7
    rem-int/lit8 v1, v0, 0x2

    if-nez v1, :cond_3c

    const-string v1, "\u56fd\u5e86\u8282"

    .line 8
    iput-object v1, p1, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->tag:Ljava/lang/String;

    goto :goto_42

    .line 9
    :cond_3c
    rem-int/lit8 v1, v0, 0x3

    if-ne v1, v4, :cond_42

    .line 10
    iput-object v2, p1, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->tag:Ljava/lang/String;

    .line 11
    :cond_42
    :goto_42
    rem-int/lit8 v0, v0, 0x4

    if-eqz v0, :cond_5d

    if-eq v0, v4, :cond_58

    if-eq v0, v3, :cond_53

    const/4 v1, 0x3

    if-eq v0, v1, :cond_4e

    goto :goto_61

    .line 12
    :cond_4e
    sget-object v0, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;->PURPLE:Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

    iput-object v0, p1, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->tipBg:Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

    goto :goto_61

    .line 13
    :cond_53
    sget-object v0, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;->YELLOW:Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

    iput-object v0, p1, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->tipBg:Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

    goto :goto_61

    .line 14
    :cond_58
    sget-object v0, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;->PINK:Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

    iput-object v0, p1, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->tipBg:Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

    goto :goto_61

    .line 15
    :cond_5d
    sget-object v0, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;->BLUE:Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

    iput-object v0, p1, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->tipBg:Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

    :goto_61
    return-void
.end method

.method private initPioneer()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    sget-object v0, Ltb/oa;->INSTANCE:Ltb/oa;

    invoke-virtual {v0}, Ltb/oa;->getAppConfigProvider()Lcom/alibaba/pictures/cornerstone/common/IAppConfigProvider;

    move-result-object v1

    if-eqz v1, :cond_26

    .line 2
    invoke-virtual {v0}, Ltb/oa;->getAppConfigProvider()Lcom/alibaba/pictures/cornerstone/common/IAppConfigProvider;

    move-result-object v0

    invoke-interface {v0}, Lcom/alibaba/pictures/cornerstone/common/IAppConfigProvider;->getIsPioneerOpen()Z

    move-result v0

    iput-boolean v0, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mIsPioneer:Z

    :cond_26
    return-void
.end method

.method private rePaintView()V
    .registers 17

    move-object/from16 v0, p0

    sget-object v1, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v2, "7"

    invoke-static {v1, v2}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v3

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v3, :cond_16

    new-array v3, v5, [Ljava/lang/Object;

    aput-object v0, v3, v4

    invoke-interface {v1, v2, v3}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_16
    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 2
    iget-object v1, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mContext:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    invoke-static {v1}, Lcom/alibaba/wireless/security/aopsdk/replace/android/util/DisplayMetrics;->getwidthPixels(Landroid/util/DisplayMetrics;)I

    move-result v1

    iput v1, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mWidth:I

    .line 3
    iget-object v2, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mContext:Landroid/content/Context;

    const/high16 v3, 0x41900000    # 18.0f

    invoke-static {v2, v3}, Ltb/e95;->a(Landroid/content/Context;F)I

    move-result v2

    sub-int/2addr v1, v2

    const/4 v2, 0x7

    div-int/2addr v1, v2

    iput v1, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mDayWidth:I

    add-int/lit8 v1, v1, -0x6

    mul-int/lit8 v1, v1, 0x38

    .line 4
    div-int/lit8 v1, v1, 0x2d

    iget-object v3, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mContext:Landroid/content/Context;

    const/high16 v6, 0x41800000    # 16.0f

    invoke-static {v3, v6}, Ltb/e95;->a(Landroid/content/Context;F)I

    move-result v3

    add-int/2addr v1, v3

    iput v1, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mDayHeigth:I

    .line 5
    iget-object v1, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mContext:Landroid/content/Context;

    const/high16 v3, 0x42a40000    # 82.0f

    invoke-static {v1, v3}, Ltb/e95;->a(Landroid/content/Context;F)I

    move-result v1

    .line 6
    iget v3, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mDayHeigth:I

    invoke-static {v1, v3}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mDayHeigth:I

    .line 7
    iget-object v1, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mDays:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    iget v3, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mStartWeek:I

    add-int/2addr v1, v3

    sub-int/2addr v1, v5

    rem-int/2addr v1, v2

    if-nez v1, :cond_72

    .line 8
    iget-object v1, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mDays:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    iget v3, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mStartWeek:I

    add-int/2addr v1, v3

    sub-int/2addr v1, v5

    div-int/2addr v1, v2

    iput v1, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mRowNum:I

    goto :goto_80

    .line 9
    :cond_72
    iget-object v1, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mDays:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    iget v3, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mStartWeek:I

    add-int/2addr v1, v3

    sub-int/2addr v1, v5

    div-int/2addr v1, v2

    add-int/2addr v1, v5

    iput v1, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mRowNum:I

    :goto_80
    const/4 v1, 0x0

    .line 10
    :goto_81
    iget-object v3, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mDays:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    if-ge v1, v3, :cond_203

    .line 11
    iget-object v3, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mDays:Ljava/util/List;

    invoke-interface {v3, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcn/damai/commonbusiness/calendarcopy/bean/Day;

    if-nez v3, :cond_95

    goto/16 :goto_1fd

    .line 12
    :cond_95
    iget-boolean v7, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mIsCurrentMonth:Z

    const/4 v8, 0x2

    if-eqz v7, :cond_b3

    .line 13
    invoke-static {}, Ltb/it;->m()I

    move-result v7

    iget v9, v3, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->day:I

    if-le v7, v9, :cond_a5

    .line 14
    iput v4, v3, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->showType:I

    goto :goto_b5

    .line 15
    :cond_a5
    invoke-static {}, Ltb/it;->m()I

    move-result v7

    iget v9, v3, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->day:I

    if-ne v7, v9, :cond_b0

    .line 16
    iput v5, v3, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->showType:I

    goto :goto_b5

    .line 17
    :cond_b0
    iput v8, v3, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->showType:I

    goto :goto_b5

    .line 18
    :cond_b3
    iput v8, v3, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->showType:I

    .line 19
    :goto_b5
    invoke-static {}, Ltb/e01;->a()Ltb/e01;

    move-result-object v7

    iget-object v9, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mContext:Landroid/content/Context;

    invoke-virtual {v7, v9, v3}, Ltb/e01;->b(Landroid/content/Context;Lcn/damai/commonbusiness/calendarcopy/bean/Day;)Landroid/view/View;

    move-result-object v7

    .line 20
    invoke-virtual {v7, v3}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 21
    iget-object v9, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mItemClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v7, v9}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 22
    invoke-virtual {v0, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 23
    sget v9, Lcom/alibaba/pictures/R$id;->view_bg:I

    invoke-virtual {v7, v9}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v10

    invoke-virtual {v10}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v10

    iget v11, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mDayWidth:I

    iget-object v12, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mContext:Landroid/content/Context;

    const/high16 v13, 0x40c00000    # 6.0f

    invoke-static {v12, v13}, Ltb/e95;->a(Landroid/content/Context;F)I

    move-result v12

    sub-int/2addr v11, v12

    iput v11, v10, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 24
    invoke-virtual {v7, v9}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v10

    invoke-virtual {v10}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v10

    iget v11, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mDayHeigth:I

    iget-object v12, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mContext:Landroid/content/Context;

    invoke-static {v12, v6}, Ltb/e95;->a(Landroid/content/Context;F)I

    move-result v12

    sub-int/2addr v11, v12

    iput v11, v10, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 25
    sget v10, Lcom/alibaba/pictures/R$drawable;->copy_common_calendar_day_select_bg:I

    .line 26
    iget-boolean v11, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mIsPioneer:Z

    if-eqz v11, :cond_fc

    .line 27
    sget v10, Lcom/alibaba/pictures/R$drawable;->copy_common_calendar_day_select_pioneer_bg:I

    .line 28
    :cond_fc
    invoke-virtual {v7, v9}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v9

    invoke-virtual {v9, v10}, Landroid/view/View;->setBackgroundResource(I)V

    .line 29
    sget v9, Lcom/alibaba/pictures/R$id;->view_long_select:I

    invoke-virtual {v7, v9}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v10

    invoke-virtual {v10}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v10

    iget v11, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mDayWidth:I

    iput v11, v10, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 30
    invoke-virtual {v7, v9}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v10

    invoke-virtual {v10}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v10

    iget v11, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mDayHeigth:I

    iget-object v12, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mContext:Landroid/content/Context;

    invoke-static {v12, v6}, Ltb/e95;->a(Landroid/content/Context;F)I

    move-result v12

    sub-int/2addr v11, v12

    iput v11, v10, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 31
    sget v10, Lcom/alibaba/pictures/R$drawable;->copy_common_calendar_day_long_select_bg_all:I

    .line 32
    sget v11, Lcom/alibaba/pictures/R$drawable;->copy_common_calendar_day_long_select_bg_left:I

    .line 33
    sget v12, Lcom/alibaba/pictures/R$drawable;->copy_common_calendar_day_long_select_bg_right:I

    .line 34
    sget v13, Lcom/alibaba/pictures/R$drawable;->copy_common_calendar_day_long_select_bg:I

    .line 35
    iget-boolean v14, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mIsPioneer:Z

    if-eqz v14, :cond_138

    .line 36
    sget v10, Lcom/alibaba/pictures/R$drawable;->copy_common_calendar_day_long_select_pioneer_bg_all:I

    .line 37
    sget v11, Lcom/alibaba/pictures/R$drawable;->copy_common_calendar_day_long_select_pioneer_bg_left:I

    .line 38
    sget v12, Lcom/alibaba/pictures/R$drawable;->copy_common_calendar_day_long_select_pioneer_bg_right:I

    .line 39
    sget v13, Lcom/alibaba/pictures/R$drawable;->copy_common_calendar_day_long_select_pioneer_bg:I

    .line 40
    :cond_138
    invoke-virtual {v7, v9}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    check-cast v7, Landroid/widget/FrameLayout;

    .line 41
    iget v9, v3, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->selectType:I

    if-lez v9, :cond_1f4

    const-string v9, "GMT+8"

    .line 42
    invoke-static {v9}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v9

    invoke-static {v9}, Ljava/util/Calendar;->getInstance(Ljava/util/TimeZone;)Ljava/util/Calendar;

    move-result-object v9

    .line 43
    iget v14, v3, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->year:I

    iget v15, v3, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->month:I

    sub-int/2addr v15, v5

    iget v6, v3, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->day:I

    invoke-virtual {v9, v14, v15, v6}, Ljava/util/Calendar;->set(III)V

    .line 44
    invoke-virtual {v9, v2}, Ljava/util/Calendar;->get(I)I

    move-result v6

    const/4 v14, 0x5

    .line 45
    invoke-virtual {v9, v14}, Ljava/util/Calendar;->get(I)I

    move-result v15

    .line 46
    invoke-virtual {v9, v14}, Ljava/util/Calendar;->getActualMaximum(I)I

    move-result v9

    if-ne v15, v9, :cond_167

    const/4 v9, 0x1

    goto :goto_168

    :cond_167
    const/4 v9, 0x0

    :goto_168
    const/4 v14, 0x4

    if-eqz v9, :cond_171

    .line 47
    iget v4, v3, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->selectType:I

    if-ne v4, v14, :cond_171

    if-eq v6, v5, :cond_179

    :cond_171
    if-ne v15, v5, :cond_185

    iget v4, v3, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->selectType:I

    if-ne v4, v14, :cond_185

    if-ne v6, v2, :cond_185

    .line 48
    :cond_179
    sget v3, Lcom/alibaba/pictures/R$id;->view_long_select_inner:I

    invoke-virtual {v7, v3}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v3, v10}, Landroid/view/View;->setBackgroundResource(I)V

    :goto_182
    const/4 v4, 0x0

    goto/16 :goto_1fd

    .line 49
    :cond_185
    iget v3, v3, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->selectType:I

    if-ne v3, v8, :cond_18b

    if-nez v9, :cond_198

    :cond_18b
    if-ne v3, v8, :cond_18f

    if-eq v6, v2, :cond_198

    :cond_18f
    const/4 v4, 0x3

    if-ne v3, v4, :cond_194

    if-eq v6, v5, :cond_198

    :cond_194
    if-ne v3, v4, :cond_19e

    if-ne v15, v5, :cond_19e

    :cond_198
    const/16 v3, 0x8

    .line 50
    invoke-virtual {v7, v3}, Landroid/widget/FrameLayout;->setVisibility(I)V

    goto :goto_182

    :cond_19e
    const/high16 v10, 0x40400000    # 3.0f

    if-eq v6, v5, :cond_1e0

    if-ne v15, v5, :cond_1a5

    goto :goto_1e0

    :cond_1a5
    if-eq v6, v2, :cond_1cc

    if-eqz v9, :cond_1aa

    goto :goto_1cc

    :cond_1aa
    if-ne v3, v8, :cond_1b6

    .line 51
    sget v3, Lcom/alibaba/pictures/R$id;->view_long_select_inner:I

    invoke-virtual {v7, v3}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v3, v11}, Landroid/view/View;->setBackgroundResource(I)V

    goto :goto_182

    :cond_1b6
    if-ne v3, v4, :cond_1c2

    .line 52
    sget v3, Lcom/alibaba/pictures/R$id;->view_long_select_inner:I

    invoke-virtual {v7, v3}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v3, v12}, Landroid/view/View;->setBackgroundResource(I)V

    goto :goto_182

    .line 53
    :cond_1c2
    sget v3, Lcom/alibaba/pictures/R$id;->view_long_select_inner:I

    invoke-virtual {v7, v3}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v3, v13}, Landroid/view/View;->setBackgroundResource(I)V

    goto :goto_182

    .line 54
    :cond_1cc
    :goto_1cc
    iget-object v3, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mContext:Landroid/content/Context;

    invoke-static {v3, v10}, Ltb/e95;->a(Landroid/content/Context;F)I

    move-result v3

    const/4 v4, 0x0

    invoke-virtual {v7, v4, v4, v3, v4}, Landroid/widget/FrameLayout;->setPadding(IIII)V

    .line 55
    sget v3, Lcom/alibaba/pictures/R$id;->view_long_select_inner:I

    invoke-virtual {v7, v3}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v3, v12}, Landroid/view/View;->setBackgroundResource(I)V

    goto :goto_1fd

    :cond_1e0
    :goto_1e0
    const/4 v4, 0x0

    .line 56
    iget-object v3, v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mContext:Landroid/content/Context;

    invoke-static {v3, v10}, Ltb/e95;->a(Landroid/content/Context;F)I

    move-result v3

    invoke-virtual {v7, v3, v4, v4, v4}, Landroid/widget/FrameLayout;->setPadding(IIII)V

    .line 57
    sget v3, Lcom/alibaba/pictures/R$id;->view_long_select_inner:I

    invoke-virtual {v7, v3}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v3, v11}, Landroid/view/View;->setBackgroundResource(I)V

    goto :goto_1fd

    .line 58
    :cond_1f4
    sget v3, Lcom/alibaba/pictures/R$id;->view_long_select_inner:I

    invoke-virtual {v7, v3}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v3, v13}, Landroid/view/View;->setBackgroundResource(I)V

    :goto_1fd
    add-int/lit8 v1, v1, 0x1

    const/high16 v6, 0x41800000    # 16.0f

    goto/16 :goto_81

    :cond_203
    return-void
.end method

.method private reSetProjectName()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_14
    const/4 v0, 0x0

    .line 1
    iput-object v0, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mProjectTag:Ljava/lang/String;

    .line 2
    iput v3, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mBubbleRow:I

    .line 3
    iput v3, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mBubbleColumn:I

    return-void
.end method


# virtual methods
.method public getDayWidth()I
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget v0, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mDayWidth:I

    return v0
.end method

.method public getLocation()[I
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_17

    new-array v2, v3, [Ljava/lang/Object;

    aput-object p0, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [I

    return-object v0

    :cond_17
    const/4 v0, 0x2

    new-array v0, v0, [I

    .line 1
    iget v1, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mBubbleRow:I

    aput v1, v0, v4

    iget v1, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mBubbleColumn:I

    aput v1, v0, v3

    return-object v0
.end method

.method public getProjectTag()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mProjectTag:Ljava/lang/String;

    return-object v0
.end method

.method protected onLayout(ZIIII)V
    .registers 11

    sget-object v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "10"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_37

    const/4 v2, 0x6

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v4

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x5

    invoke-static {p5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_37
    iget-object p1, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mContext:Landroid/content/Context;

    const/high16 p2, 0x41100000    # 9.0f

    invoke-static {p1, p2}, Ltb/e95;->a(Landroid/content/Context;F)I

    move-result p1

    .line 2
    :goto_3f
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p2

    if-ge v3, p2, :cond_74

    .line 3
    invoke-virtual {p0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p2

    .line 4
    iget p3, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mStartWeek:I

    add-int p4, v3, p3

    sub-int/2addr p4, v4

    rem-int/lit8 p4, p4, 0x7

    iget p5, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mDayWidth:I

    mul-int p4, p4, p5

    add-int/2addr p4, p1

    iget v0, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mDayHeigth:I

    add-int v1, v3, p3

    sub-int/2addr v1, v4

    div-int/lit8 v1, v1, 0x7

    mul-int v1, v1, v0

    add-int v2, v3, p3

    sub-int/2addr v2, v4

    rem-int/lit8 v2, v2, 0x7

    add-int/2addr v2, v4

    mul-int v2, v2, p5

    add-int/2addr v2, p1

    add-int/2addr p3, v3

    sub-int/2addr p3, v4

    div-int/lit8 p3, p3, 0x7

    add-int/2addr p3, v4

    mul-int v0, v0, p3

    invoke-virtual {p2, p4, v1, v2, v0}, Landroid/view/View;->layout(IIII)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_3f

    :cond_74
    return-void
.end method

.method protected onMeasure(II)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "9"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_22

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_22
    invoke-super {p0, p1, p2}, Landroid/view/ViewGroup;->onMeasure(II)V

    .line 2
    :goto_25
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p1

    if-ge v3, p1, :cond_4b

    .line 3
    invoke-virtual {p0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p1

    .line 4
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p1

    .line 5
    iget p1, p1, Landroid/view/ViewGroup$LayoutParams;->height:I

    const/high16 p2, 0x40000000    # 2.0f

    invoke-static {p1, p2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p1

    .line 6
    iget v0, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mDayWidth:I

    invoke-static {v0, p2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p2

    .line 7
    invoke-virtual {p0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0, p2, p1}, Landroid/view/View;->measure(II)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_25

    .line 8
    :cond_4b
    iget p1, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mWidth:I

    iget p2, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mRowNum:I

    iget v0, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mDayHeigth:I

    mul-int p2, p2, v0

    invoke-virtual {p0, p1, p2}, Landroid/view/ViewGroup;->setMeasuredDimension(II)V

    return-void
.end method

.method public setMonth(IILjava/util/List;Lcn/damai/commonbusiness/calendarcopy/bean/CalendarMonthBean;Landroid/view/View$OnClickListener;)V
    .registers 11
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "NewApi"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II",
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/calendarcopy/bean/Day;",
            ">;",
            "Lcn/damai/commonbusiness/calendarcopy/bean/CalendarMonthBean;",
            "Landroid/view/View$OnClickListener;",
            ")V"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_2b

    const/4 v2, 0x6

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v4

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    aput-object p3, v2, p1

    const/4 p1, 0x4

    aput-object p4, v2, p1

    const/4 p1, 0x5

    aput-object p5, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_2b
    invoke-direct {p0}, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->reSetProjectName()V

    .line 2
    iput-object p5, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mItemClickListener:Landroid/view/View$OnClickListener;

    .line 3
    iput p1, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mYear:I

    .line 4
    iput p2, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mMonth:I

    .line 5
    invoke-static {p1, p2}, Ltb/it;->r(II)Z

    move-result p5

    iput-boolean p5, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mIsCurrentMonth:Z

    .line 6
    invoke-static {p1, p2, p3, p4}, Ltb/it;->c(IILjava/util/List;Lcn/damai/commonbusiness/calendarcopy/bean/CalendarMonthBean;)Ljava/util/List;

    move-result-object p3

    iput-object p3, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mDays:Ljava/util/List;

    .line 7
    invoke-static {p1, p2}, Ltb/it;->h(II)I

    move-result p1

    iput p1, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mStartWeek:I

    .line 8
    :goto_46
    iget-object p1, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mDays:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    if-ge v3, p1, :cond_86

    .line 9
    iget-object p1, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mDays:Ljava/util/List;

    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    if-eqz p1, :cond_83

    .line 10
    iget-object p1, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mDays:Ljava/util/List;

    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/calendarcopy/bean/Day;

    iget-object p1, p1, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->projectName:Ljava/lang/String;

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez p1, :cond_83

    .line 11
    iget-object p1, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mDays:Ljava/util/List;

    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/calendarcopy/bean/Day;

    iget-object p1, p1, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->projectName:Ljava/lang/String;

    iput-object p1, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mProjectTag:Ljava/lang/String;

    .line 12
    iget p1, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mStartWeek:I

    add-int p2, v3, p1

    sub-int/2addr p2, v4

    div-int/lit8 p2, p2, 0x7

    add-int/2addr p2, v4

    iput p2, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mBubbleRow:I

    add-int/2addr p1, v3

    sub-int/2addr p1, v4

    .line 13
    rem-int/lit8 p1, p1, 0x7

    add-int/2addr p1, v4

    iput p1, p0, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->mBubbleColumn:I

    :cond_83
    add-int/lit8 v3, v3, 0x1

    goto :goto_46

    .line 14
    :cond_86
    invoke-virtual {p0}, Landroid/view/ViewGroup;->isInEditMode()Z

    move-result p1

    if-nez p1, :cond_8f

    .line 15
    invoke-direct {p0}, Lcn/damai/commonbusiness/calendarcopy/view/CalendarView;->rePaintView()V

    .line 16
    :cond_8f
    invoke-virtual {p0}, Landroid/view/ViewGroup;->requestLayout()V

    return-void
.end method
