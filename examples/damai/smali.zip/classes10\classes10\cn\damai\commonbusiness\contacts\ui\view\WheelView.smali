.class public Lcn/damai/commonbusiness/contacts/ui/view/WheelView;
.super Landroid/widget/ScrollView;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/contacts/ui/view/WheelView$b;
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon; = null

.field public static final OFF_SET_DEFAULT:I = 0x1

.field private static final SCROLL_DIRECTION_DOWN:I = 0x1

.field private static final SCROLL_DIRECTION_UP:I

.field public static final TAG:Ljava/lang/String;


# instance fields
.field displayItemCount:I

.field initialY:I

.field itemHeight:I

.field items:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field newCheck:I

.field offset:I

.field private onWheelViewListener:Lcn/damai/commonbusiness/contacts/ui/view/WheelView$b;

.field paint:Landroid/graphics/Paint;

.field private scrollDirection:I

.field scrollerTask:Ljava/lang/Runnable;

.field selectedAreaBorder:[I

.field selectedIndex:I

.field viewWidth:I

.field private views:Landroid/widget/LinearLayout;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    const-class v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->TAG:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    const/4 v0, 0x1

    .line 2
    iput v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->offset:I

    .line 3
    iput v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->selectedIndex:I

    const/16 v0, 0x32

    .line 4
    iput v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->newCheck:I

    const/4 v0, 0x0

    .line 5
    iput v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->itemHeight:I

    const/4 v0, -0x1

    .line 6
    iput v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->scrollDirection:I

    .line 7
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->init(Landroid/content/Context;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 3

    .line 8
    invoke-direct {p0, p1, p2}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 p2, 0x1

    .line 9
    iput p2, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->offset:I

    .line 10
    iput p2, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->selectedIndex:I

    const/16 p2, 0x32

    .line 11
    iput p2, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->newCheck:I

    const/4 p2, 0x0

    .line 12
    iput p2, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->itemHeight:I

    const/4 p2, -0x1

    .line 13
    iput p2, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->scrollDirection:I

    .line 14
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->init(Landroid/content/Context;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4

    .line 15
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 p2, 0x1

    .line 16
    iput p2, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->offset:I

    .line 17
    iput p2, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->selectedIndex:I

    const/16 p2, 0x32

    .line 18
    iput p2, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->newCheck:I

    const/4 p2, 0x0

    .line 19
    iput p2, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->itemHeight:I

    const/4 p2, -0x1

    .line 20
    iput p2, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->scrollDirection:I

    .line 21
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->init(Landroid/content/Context;)V

    return-void
.end method

.method static synthetic access$000(Lcn/damai/commonbusiness/contacts/ui/view/WheelView;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->onSeletedCallBack()V

    return-void
.end method

.method static synthetic access$100(Lcn/damai/commonbusiness/contacts/ui/view/WheelView;)[I
    .registers 1

    .line 1
    invoke-direct {p0}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->obtainSelectedAreaBorder()[I

    move-result-object p0

    return-object p0
.end method

.method private createView(Ljava/lang/String;)Landroid/widget/TextView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "8"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    return-object p1

    .line 1
    :cond_1a
    new-instance v0, Landroid/widget/TextView;

    invoke-virtual {p0}, Landroid/widget/ScrollView;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2
    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v2, -0x2

    const/4 v4, -0x1

    invoke-direct {v1, v4, v2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 3
    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setSingleLine(Z)V

    const/high16 v1, 0x41800000    # 16.0f

    .line 4
    invoke-virtual {v0, v3, v1}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 5
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 p1, 0x11

    .line 6
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setGravity(I)V

    .line 7
    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setBackgroundColor(I)V

    const/high16 p1, 0x41700000    # 15.0f

    .line 8
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->dip2px(F)I

    move-result p1

    .line 9
    invoke-virtual {v0, p1, p1, p1, p1}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 10
    iget p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->itemHeight:I

    if-nez p1, :cond_79

    .line 11
    invoke-direct {p0, v0}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->getViewMeasuredHeight(Landroid/view/View;)I

    move-result p1

    iput p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->itemHeight:I

    .line 12
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->views:Landroid/widget/LinearLayout;

    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    iget v2, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->itemHeight:I

    iget v3, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->displayItemCount:I

    mul-int v2, v2, v3

    invoke-direct {v1, v4, v2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p1, v1}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 13
    invoke-virtual {p0}, Landroid/widget/ScrollView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p1

    check-cast p1, Landroid/widget/LinearLayout$LayoutParams;

    .line 14
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    iget p1, p1, Landroid/widget/LinearLayout$LayoutParams;->width:I

    iget v2, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->itemHeight:I

    iget v3, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->displayItemCount:I

    mul-int v2, v2, v3

    invoke-direct {v1, p1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p0, v1}, Landroid/widget/ScrollView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_79
    return-object v0
.end method

.method private dip2px(F)I
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "22"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_22

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    return p1

    .line 1
    :cond_22
    invoke-virtual {p0}, Landroid/widget/ScrollView;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    mul-float p1, p1, v0

    const/high16 v0, 0x3f000000    # 0.5f

    add-float/2addr p1, v0

    float-to-int p1, p1

    return p1
.end method

.method private getItems()Ljava/util/List;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->items:Ljava/util/List;

    return-object v0
.end method

.method private getViewMeasuredHeight(Landroid/view/View;)I
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "23"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    return p1

    .line 1
    :cond_1e
    invoke-static {v3, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v0

    const v1, 0x1fffffff

    const/high16 v2, -0x80000000

    .line 2
    invoke-static {v1, v2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v1

    .line 3
    invoke-virtual {p1, v0, v1}, Landroid/view/View;->measure(II)V

    .line 4
    invoke-virtual {p1}, Landroid/view/View;->getMeasuredHeight()I

    move-result p1

    return p1
.end method

.method private init(Landroid/content/Context;)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "parent: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Landroid/widget/ScrollView;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 2
    invoke-virtual {p0, v4}, Landroid/widget/ScrollView;->setVerticalScrollBarEnabled(Z)V

    .line 3
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->views:Landroid/widget/LinearLayout;

    .line 4
    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 5
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->views:Landroid/widget/LinearLayout;

    invoke-virtual {p0, p1}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 6
    new-instance p1, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$1;

    invoke-direct {p1, p0}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$1;-><init>(Lcn/damai/commonbusiness/contacts/ui/view/WheelView;)V

    iput-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->scrollerTask:Ljava/lang/Runnable;

    return-void
.end method

.method private initData()V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "7"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_14

    new-array v2, v4, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->offset:I

    mul-int/lit8 v0, v0, 0x2

    add-int/2addr v0, v4

    iput v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->displayItemCount:I

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->items:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_21
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_37

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 3
    iget-object v2, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->views:Landroid/widget/LinearLayout;

    invoke-direct {p0, v1}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->createView(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    goto :goto_21

    .line 4
    :cond_37
    invoke-direct {p0, v3}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->refreshItemView(I)V

    return-void
.end method

.method private obtainSelectedAreaBorder()[I
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "11"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_17

    new-array v2, v4, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [I

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->selectedAreaBorder:[I

    if-nez v0, :cond_2d

    const/4 v0, 0x2

    new-array v0, v0, [I

    .line 2
    iput-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->selectedAreaBorder:[I

    .line 3
    iget v1, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->itemHeight:I

    iget v2, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->offset:I

    mul-int v5, v1, v2

    aput v5, v0, v3

    add-int/2addr v2, v4

    mul-int v1, v1, v2

    aput v1, v0, v4

    .line 4
    :cond_2d
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->selectedAreaBorder:[I

    return-object v0
.end method

.method private onSeletedCallBack()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "14"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->onWheelViewListener:Lcn/damai/commonbusiness/contacts/ui/view/WheelView$b;

    if-eqz v0, :cond_25

    .line 2
    iget v1, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->selectedIndex:I

    iget-object v2, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->items:Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$b;->a(ILjava/lang/String;)V

    :cond_25
    return-void
.end method

.method private refreshItemView(I)V
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "10"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v2, :cond_1b

    new-array v2, v4, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v5

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iget v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->itemHeight:I

    div-int v1, p1, v0

    iget v2, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->offset:I

    add-int/2addr v1, v2

    .line 2
    rem-int v6, p1, v0

    .line 3
    div-int/2addr p1, v0

    if-nez v6, :cond_2a

    add-int v1, p1, v2

    goto :goto_30

    .line 4
    :cond_2a
    div-int/2addr v0, v4

    if-le v6, v0, :cond_30

    add-int/2addr p1, v2

    add-int/lit8 v1, p1, 0x1

    .line 5
    :cond_30
    :goto_30
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->views:Landroid/widget/LinearLayout;

    invoke-virtual {p1}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result p1

    :goto_36
    if-ge v3, p1, :cond_5b

    .line 6
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->views:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    if-nez v0, :cond_43

    return-void

    :cond_43
    if-ne v1, v3, :cond_4f

    const-string v2, "#222222"

    .line 7
    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    goto :goto_58

    :cond_4f
    const-string v2, "#999999"

    .line 8
    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    :goto_58
    add-int/lit8 v3, v3, 0x1

    goto :goto_36

    :cond_5b
    return-void
.end method


# virtual methods
.method public fling(I)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "18"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    div-int/lit8 p1, p1, 0x3

    invoke-super {p0, p1}, Landroid/widget/ScrollView;->fling(I)V

    return-void
.end method

.method public getOffset()I
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->offset:I

    return v0
.end method

.method public getOnWheelViewListener()Lcn/damai/commonbusiness/contacts/ui/view/WheelView$b;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "20"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$b;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->onWheelViewListener:Lcn/damai/commonbusiness/contacts/ui/view/WheelView$b;

    return-object v0
.end method

.method public getSeletedIndex()I
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "17"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->selectedIndex:I

    iget v1, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->offset:I

    sub-int/2addr v0, v1

    return v0
.end method

.method public getSeletedItem()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "16"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->items:Ljava/util/List;

    iget v1, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->selectedIndex:I

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0
.end method

.method protected onScrollChanged(IIII)V
    .registers 10

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "9"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_30

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v4

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_30
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/ScrollView;->onScrollChanged(IIII)V

    .line 2
    invoke-direct {p0, p2}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->refreshItemView(I)V

    if-le p2, p4, :cond_3b

    .line 3
    iput v3, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->scrollDirection:I

    goto :goto_3d

    .line 4
    :cond_3b
    iput v4, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->scrollDirection:I

    :goto_3d
    return-void
.end method

.method protected onSizeChanged(IIII)V
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "13"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_30

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_30
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/ScrollView;->onSizeChanged(IIII)V

    .line 2
    iput p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->viewWidth:I

    const/4 p1, 0x0

    .line 3
    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "19"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    return p1

    .line 1
    :cond_1e
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    if-ne v0, v3, :cond_27

    .line 2
    invoke-virtual {p0}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->startScrollerTask()V

    .line 3
    :cond_27
    invoke-super {p0, p1}, Landroid/widget/ScrollView;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    return p1
.end method

.method public setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "12"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->viewWidth:I

    if-nez p1, :cond_2f

    .line 2
    invoke-virtual {p0}, Landroid/widget/ScrollView;->getContext()Landroid/content/Context;

    move-result-object p1

    check-cast p1, Landroid/app/Activity;

    invoke-virtual {p1}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    move-result-object p1

    invoke-interface {p1}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/Display;->getWidth()I

    move-result p1

    iput p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->viewWidth:I

    .line 3
    :cond_2f
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->paint:Landroid/graphics/Paint;

    if-nez p1, :cond_4f

    .line 4
    new-instance p1, Landroid/graphics/Paint;

    invoke-direct {p1}, Landroid/graphics/Paint;-><init>()V

    iput-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->paint:Landroid/graphics/Paint;

    const-string v0, "#f2f3f4"

    .line 5
    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 6
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->paint:Landroid/graphics/Paint;

    const/high16 v0, 0x3f000000    # 0.5f

    invoke-direct {p0, v0}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->dip2px(F)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 7
    :cond_4f
    new-instance p1, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$a;

    invoke-direct {p1, p0}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$a;-><init>(Lcn/damai/commonbusiness/contacts/ui/view/WheelView;)V

    .line 8
    invoke-super {p0, p1}, Landroid/widget/ScrollView;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public setItems(Ljava/util/List;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->items:Ljava/util/List;

    if-nez v0, :cond_22

    .line 2
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->items:Ljava/util/List;

    .line 3
    :cond_22
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->items:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->items:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    const/4 p1, 0x0

    .line 5
    :goto_2d
    iget v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->offset:I

    if-ge p1, v0, :cond_40

    .line 6
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->items:Ljava/util/List;

    const-string v1, ""

    invoke-interface {v0, v3, v1}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 7
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->items:Ljava/util/List;

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 p1, p1, 0x1

    goto :goto_2d

    .line 8
    :cond_40
    invoke-direct {p0}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->initData()V

    return-void
.end method

.method public setOffset(I)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iput p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->offset:I

    return-void
.end method

.method public setOnWheelViewListener(Lcn/damai/commonbusiness/contacts/ui/view/WheelView$b;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "21"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->onWheelViewListener:Lcn/damai/commonbusiness/contacts/ui/view/WheelView$b;

    return-void
.end method

.method public setSeletion(I)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "15"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iget v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->offset:I

    add-int/2addr v0, p1

    iput v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->selectedIndex:I

    .line 2
    new-instance v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$3;

    invoke-direct {v0, p0, p1}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$3;-><init>(Lcn/damai/commonbusiness/contacts/ui/view/WheelView;I)V

    invoke-virtual {p0, v0}, Landroid/widget/ScrollView;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public startScrollerTask()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    invoke-virtual {p0}, Landroid/widget/ScrollView;->getScrollY()I

    move-result v0

    iput v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->initialY:I

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->scrollerTask:Ljava/lang/Runnable;

    iget v1, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->newCheck:I

    int-to-long v1, v1

    invoke-virtual {p0, v0, v1, v2}, Landroid/widget/ScrollView;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
