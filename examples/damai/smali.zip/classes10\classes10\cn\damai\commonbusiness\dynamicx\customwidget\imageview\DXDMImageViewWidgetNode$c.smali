.class public Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$c;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field public a:[I

.field public b:I

.field public c:I

.field public d:Z

.field public e:Ljava/lang/String;

.field public f:Ljava/lang/String;

.field public g:Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$ImageLoadListener;

.field private h:Z

.field private i:Z

.field private j:Z

.field private k:Z

.field private l:Z

.field private m:Z

.field private n:Z

.field private o:Z


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$c;->d:Z

    return-void
.end method

.method static synthetic a(Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$c;Z)Z
    .registers 2

    .line 1
    iput-boolean p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$c;->m:Z

    return p1
.end method

.method static synthetic b(Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$c;Z)Z
    .registers 2

    .line 1
    iput-boolean p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$c;->n:Z

    return p1
.end method

.method static synthetic c(Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$c;Z)Z
    .registers 2

    .line 1
    iput-boolean p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$c;->k:Z

    return p1
.end method

.method static synthetic d(Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$c;Z)Z
    .registers 2

    .line 1
    iput-boolean p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$c;->j:Z

    return p1
.end method

.method static synthetic e(Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$c;Z)Z
    .registers 2

    .line 1
    iput-boolean p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$c;->i:Z

    return p1
.end method

.method static synthetic f(Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$c;Z)Z
    .registers 2

    .line 1
    iput-boolean p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$c;->l:Z

    return p1
.end method

.method static synthetic g(Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$c;Z)Z
    .registers 2

    .line 1
    iput-boolean p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$c;->h:Z

    return p1
.end method

.method static synthetic h(Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$c;Z)Z
    .registers 2

    .line 1
    iput-boolean p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$c;->o:Z

    return p1
.end method


# virtual methods
.method public i()Z
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$c;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget-boolean v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$c;->o:Z

    return v0
.end method

.method public j()Z
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$c;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget-boolean v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$c;->k:Z

    return v0
.end method

.method public k()Z
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$c;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget-boolean v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$c;->n:Z

    return v0
.end method
