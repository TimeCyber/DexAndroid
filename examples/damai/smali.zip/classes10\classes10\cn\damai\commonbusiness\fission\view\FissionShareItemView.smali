.class public Lcn/damai/commonbusiness/fission/view/FissionShareItemView;
.super Landroid/widget/LinearLayout;
.source "Taobao"


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private context:Landroid/content/Context;

.field private desc:Ljava/lang/String;

.field private iconfont:Ljava/lang/String;

.field private partent:Landroid/view/View;

.field private tvShareDesc:Landroid/widget/TextView;

.field private tvShareIcon:Lcn/damai/uikit/iconfont/DMIconFontTextView;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, p1, v0}, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 4

    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, p1, p2, v0}, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4

    .line 3
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 4
    iput-object p1, p0, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->context:Landroid/content/Context;

    const/4 p3, 0x1

    .line 5
    invoke-virtual {p0, p3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 6
    sget-object p3, Lcn/damai/commonbusiness/R$styleable;->fissionAttrs:[I

    invoke-virtual {p1, p2, p3}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    if-eqz p1, :cond_24

    .line 7
    sget p2, Lcn/damai/commonbusiness/R$styleable;->fissionAttrs_iconfont:I

    invoke-virtual {p1, p2}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object p2

    iput-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->iconfont:Ljava/lang/String;

    .line 8
    sget p2, Lcn/damai/commonbusiness/R$styleable;->fissionAttrs_desc:I

    invoke-virtual {p1, p2}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object p2

    iput-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->desc:Ljava/lang/String;

    .line 9
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 10
    :cond_24
    invoke-direct {p0}, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->initView()V

    return-void
.end method

.method private gradienCircle(I)Landroid/graphics/drawable/GradientDrawable;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/graphics/drawable/GradientDrawable;

    return-object p1

    .line 1
    :cond_1e
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 2
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 3
    invoke-virtual {v0, v3}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    return-object v0
.end method

.method private initView()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->context:Landroid/content/Context;

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    sget v1, Lcn/damai/commonbusiness/R$layout;->commonbusiness_fission_share_layout:I

    invoke-virtual {v0, v1, p0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->partent:Landroid/view/View;

    .line 2
    sget v1, Lcn/damai/commonbusiness/R$id;->share_icon:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcn/damai/uikit/iconfont/DMIconFontTextView;

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->tvShareIcon:Lcn/damai/uikit/iconfont/DMIconFontTextView;

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->partent:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->share_icon_desc:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->tvShareDesc:Landroid/widget/TextView;

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->iconfont:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_47

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->tvShareIcon:Lcn/damai/uikit/iconfont/DMIconFontTextView;

    iget-object v1, p0, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->iconfont:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 6
    :cond_47
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->desc:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_56

    .line 7
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->tvShareDesc:Landroid/widget/TextView;

    iget-object v1, p0, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->desc:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_56
    return-void
.end method


# virtual methods
.method public setListener(Landroid/view/View$OnClickListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-virtual {p0, p1}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method public update(I)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x10

    if-lt v0, v1, :cond_2b

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->tvShareIcon:Lcn/damai/uikit/iconfont/DMIconFontTextView;

    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->gradienCircle(I)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_34

    .line 3
    :cond_2b
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->tvShareIcon:Lcn/damai/uikit/iconfont/DMIconFontTextView;

    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->gradienCircle(I)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    :goto_34
    return-void
.end method

.method public update(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V
    .registers 8

    sget-object v0, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_1a

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 4
    :cond_1a
    new-instance p1, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {p1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 5
    invoke-virtual {p1, p2}, Landroid/graphics/drawable/GradientDrawable;->setColors([I)V

    .line 6
    invoke-virtual {p1, v3}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 7
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionShareItemView;->tvShareIcon:Lcn/damai/uikit/iconfont/DMIconFontTextView;

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method
