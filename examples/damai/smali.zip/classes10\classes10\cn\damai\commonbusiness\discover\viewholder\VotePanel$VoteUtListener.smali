.class public interface abstract Lcn/damai/commonbusiness/discover/viewholder/VotePanel$VoteUtListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/discover/viewholder/VotePanel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "VoteUtListener"
.end annotation


# virtual methods
.method public abstract ut4CancelVoteClick(Lcn/damai/commonbusiness/discover/bean/VoteInfoBean;)V
.end method

.method public abstract ut4VoteCardExposure(Landroid/view/View;Lcn/damai/commonbusiness/discover/bean/VoteInfoBean;I)V
.end method

.method public abstract ut4VoteClick(Lcn/damai/commonbusiness/discover/bean/VoteInfoBean;Lcn/damai/commonbusiness/discover/bean/VoteBean;I)V
.end method
