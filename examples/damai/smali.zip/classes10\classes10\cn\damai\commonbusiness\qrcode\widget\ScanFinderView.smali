.class public Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;
.super Landroid/view/View;
.source "Taobao"


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon; = null

.field public static final KEY_SUPPORT_MANUAL:Ljava/lang/String; = "key_support_manual"

.field public static final TAG:Ljava/lang/String; = "ScanFinderView"


# instance fields
.field private LINE_COLOR:I

.field private angle_leftTop:Landroid/graphics/Bitmap;

.field private dLineWidth:I

.field private mSupportManual:Z

.field private matrix:Landroid/graphics/Matrix;

.field private paint:Landroid/graphics/Paint;

.field private showScanRect:Z

.field private targetBottom:I

.field private targetLeft:I

.field private targetRight:I

.field private targetTop:I

.field private xFerPaint:Landroid/graphics/Paint;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, p1, v0}, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 4

    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, p1, p2, v0}, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4

    .line 3
    invoke-direct {p0, p1, p2, p3}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 p2, 0x2

    .line 4
    iput p2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->dLineWidth:I

    const-string p2, "#108EE9"

    .line 5
    invoke-static {p2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p2

    iput p2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->LINE_COLOR:I

    .line 6
    new-instance p2, Landroid/graphics/Matrix;

    invoke-direct {p2}, Landroid/graphics/Matrix;-><init>()V

    iput-object p2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->matrix:Landroid/graphics/Matrix;

    .line 7
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->initAngleBitmap(Landroid/content/Context;)V

    .line 8
    invoke-direct {p0}, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->initPaint()V

    .line 9
    invoke-direct {p0}, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->init()V

    const/4 p1, 0x1

    .line 10
    iput-boolean p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->showScanRect:Z

    return-void
.end method

.method private drawAngle(Landroid/graphics/Canvas;)V
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eqz v2, :cond_17

    new-array v2, v4, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->paint:Landroid/graphics/Paint;

    const/16 v1, 0xff

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v0

    mul-int/lit8 v0, v0, 0xe

    div-int/lit8 v0, v0, 0x3c

    div-int/2addr v0, v4

    add-int/2addr v0, v3

    .line 3
    iget-object v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    iget v2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->targetLeft:I

    sub-int/2addr v2, v0

    int-to-float v2, v2

    iget v3, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->targetTop:I

    sub-int/2addr v3, v0

    int-to-float v3, v3

    iget-object v5, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v1, v2, v3, v5}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 4
    iget-object v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->matrix:Landroid/graphics/Matrix;

    invoke-virtual {v1}, Landroid/graphics/Matrix;->reset()V

    .line 5
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 6
    iget-object v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->matrix:Landroid/graphics/Matrix;

    const/high16 v2, 0x42b40000    # 90.0f

    iget-object v3, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    invoke-virtual {v3}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v3

    div-int/2addr v3, v4

    int-to-float v3, v3

    iget-object v5, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    .line 7
    invoke-virtual {v5}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v5

    div-int/2addr v5, v4

    int-to-float v5, v5

    .line 8
    invoke-virtual {v1, v2, v3, v5}, Landroid/graphics/Matrix;->setRotate(FFF)V

    .line 9
    iget v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->targetRight:I

    iget-object v2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v2

    sub-int/2addr v1, v2

    add-int/2addr v1, v0

    int-to-float v1, v1

    iget v2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->targetTop:I

    sub-int/2addr v2, v0

    int-to-float v2, v2

    invoke-virtual {p1, v1, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 10
    iget-object v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    iget-object v2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->matrix:Landroid/graphics/Matrix;

    iget-object v3, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v1, v2, v3}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Matrix;Landroid/graphics/Paint;)V

    .line 11
    iget v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->targetBottom:I

    iget v2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->targetTop:I

    sub-int/2addr v1, v2

    iget-object v2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v2

    sub-int/2addr v1, v2

    mul-int/lit8 v0, v0, 0x2

    add-int/2addr v1, v0

    int-to-float v1, v1

    const/4 v2, 0x0

    invoke-virtual {p1, v2, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 12
    iget-object v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->matrix:Landroid/graphics/Matrix;

    const/high16 v3, 0x43340000    # 180.0f

    iget-object v5, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    invoke-virtual {v5}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v5

    div-int/2addr v5, v4

    int-to-float v5, v5

    iget-object v6, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    .line 13
    invoke-virtual {v6}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v6

    div-int/2addr v6, v4

    int-to-float v6, v6

    .line 14
    invoke-virtual {v1, v3, v5, v6}, Landroid/graphics/Matrix;->setRotate(FFF)V

    .line 15
    iget-object v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    iget-object v3, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->matrix:Landroid/graphics/Matrix;

    iget-object v5, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v1, v3, v5}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Matrix;Landroid/graphics/Paint;)V

    .line 16
    iget v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->targetRight:I

    iget v3, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->targetLeft:I

    sub-int/2addr v1, v3

    iget-object v3, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    invoke-virtual {v3}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v3

    sub-int/2addr v1, v3

    add-int/2addr v1, v0

    neg-int v0, v1

    int-to-float v0, v0

    invoke-virtual {p1, v0, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 17
    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->matrix:Landroid/graphics/Matrix;

    const/high16 v1, 0x43870000    # 270.0f

    iget-object v2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v2

    div-int/2addr v2, v4

    int-to-float v2, v2

    iget-object v3, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    .line 18
    invoke-virtual {v3}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v3

    div-int/2addr v3, v4

    int-to-float v3, v3

    .line 19
    invoke-virtual {v0, v1, v2, v3}, Landroid/graphics/Matrix;->setRotate(FFF)V

    .line 20
    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    iget-object v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->matrix:Landroid/graphics/Matrix;

    iget-object v2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1, v2}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Matrix;Landroid/graphics/Paint;)V

    .line 21
    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    return-void
.end method

.method private drawRect(Landroid/graphics/Canvas;)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "7"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    new-instance v0, Landroid/graphics/Rect;

    iget v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->targetLeft:I

    iget v2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->targetTop:I

    iget v3, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->targetRight:I

    iget v4, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->targetBottom:I

    invoke-direct {v0, v1, v2, v3, v4}, Landroid/graphics/Rect;-><init>(IIII)V

    iget-object v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->xFerPaint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->drawRect(Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    return-void
.end method

.method private drawRectSide(Landroid/graphics/Canvas;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "8"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->paint:Landroid/graphics/Paint;

    iget v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->LINE_COLOR:I

    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->paint:Landroid/graphics/Paint;

    iget v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->dLineWidth:I

    int-to-float v0, v0

    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    return-void
.end method

.method private init()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_14
    const/4 v0, 0x2

    const/4 v1, 0x0

    .line 1
    invoke-virtual {p0, v0, v1}, Landroid/view/View;->setLayerType(ILandroid/graphics/Paint;)V

    return-void
.end method

.method private initAngleBitmap(Landroid/content/Context;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    .line 2
    sget v0, Lcn/damai/commonbusiness/R$drawable;->qrcode_corner_left_top:I

    invoke-static {p1, v0}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object p1

    iput-object p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    return-void
.end method

.method private initPaint()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_14

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->paint:Landroid/graphics/Paint;

    .line 2
    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 3
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->xFerPaint:Landroid/graphics/Paint;

    .line 4
    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->xFerPaint:Landroid/graphics/Paint;

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 6
    new-instance v0, Landroid/graphics/PorterDuffXfermode;

    sget-object v1, Landroid/graphics/PorterDuff$Mode;->DST_OUT:Landroid/graphics/PorterDuff$Mode;

    invoke-direct {v0, v1}, Landroid/graphics/PorterDuffXfermode;-><init>(Landroid/graphics/PorterDuff$Mode;)V

    .line 7
    iget-object v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->xFerPaint:Landroid/graphics/Paint;

    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    return-void
.end method


# virtual methods
.method public onDraw(Landroid/graphics/Canvas;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-super {p0, p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    .line 2
    iget-boolean v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->showScanRect:Z

    if-eqz v0, :cond_27

    .line 3
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->drawRect(Landroid/graphics/Canvas;)V

    .line 4
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->drawRectSide(Landroid/graphics/Canvas;)V

    .line 5
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->drawAngle(Landroid/graphics/Canvas;)V

    :cond_27
    return-void
.end method

.method public setShowScanRect(Z)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "9"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iput-boolean p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->showScanRect:Z

    return-void
.end method

.method public setTargetLocation(IIII)V
    .registers 14

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    if-eqz v2, :cond_30

    new-array v2, v3, [Ljava/lang/Object;

    aput-object p0, v2, v8

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v7

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v6

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v5

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_30
    const/16 v0, 0x8

    new-array v0, v0, [Ljava/lang/Object;

    const-string v1, "setTargetLocation: left="

    aput-object v1, v0, v8

    .line 1
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v0, v7

    const-string v1, ", top="

    aput-object v1, v0, v6

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v0, v5

    const-string v1, ", right="

    aput-object v1, v0, v4

    .line 2
    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v0, v3

    const/4 v1, 0x6

    const-string v2, ", bottom="

    aput-object v2, v0, v1

    const/4 v1, 0x7

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v0, v1

    const-string v1, "ScanFinderView"

    .line 3
    invoke-static {v1, v0}, Lcom/alipay/mobile/bqcscanservice/MPaasLogger;->d(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 4
    iget v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->targetLeft:I

    if-ne p1, v0, :cond_74

    iget v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->targetRight:I

    if-ne v0, p3, :cond_74

    iget v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->targetTop:I

    if-ne v0, p2, :cond_74

    iget v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->targetBottom:I

    if-ne v0, p4, :cond_74

    return-void

    .line 5
    :cond_74
    iput p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->targetLeft:I

    .line 6
    iput p3, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->targetRight:I

    .line 7
    iput p2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->targetTop:I

    .line 8
    iput p4, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanFinderView;->targetBottom:I

    return-void
.end method
