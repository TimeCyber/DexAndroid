.class public Lcn/damai/commonbusiness/address/bean/AddressBean;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/os/Parcelable;


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcn/damai/commonbusiness/address/bean/AddressBean;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private addressDetail:Ljava/lang/String;

.field private addressId:Ljava/lang/String;

.field private addressName:Ljava/lang/String;

.field private addressStatus:Ljava/lang/String;

.field private checked:Ljava/lang/Boolean;

.field private city:Ljava/lang/String;

.field private cityCode:Ljava/lang/String;

.field private consigneeName:Ljava/lang/String;

.field private county:Ljava/lang/String;

.field private countyCode:Ljava/lang/String;

.field private dmCity:Ljava/lang/String;

.field private dmCityCode:Ljava/lang/String;

.field private dmCounty:Ljava/lang/String;

.field private dmCountyCode:Ljava/lang/String;

.field private dmProvince:Ljava/lang/String;

.field private dmProvinceCode:Ljava/lang/String;

.field private email:Ljava/lang/String;

.field private gmtCreate:Ljava/lang/String;

.field private gmtModified:Ljava/lang/String;

.field private isDefault:Ljava/lang/String;

.field private match:Ljava/lang/String;

.field private mobile:Ljava/lang/String;

.field private nationPrefix:Ljava/lang/String;

.field private needImprove:Ljava/lang/String;

.field private province:Ljava/lang/String;

.field private provinceCode:Ljava/lang/String;

.field private street:Ljava/lang/String;

.field private streetCode:Ljava/lang/String;

.field private telephone:Ljava/lang/String;

.field private userId:Ljava/lang/String;

.field private version:Ljava/lang/String;

.field private zipCode:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lcn/damai/commonbusiness/address/bean/AddressBean$1;

    invoke-direct {v0}, Lcn/damai/commonbusiness/address/bean/AddressBean$1;-><init>()V

    sput-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->checked:Ljava/lang/Boolean;

    return-void
.end method

.method protected constructor <init>(Landroid/os/Parcel;)V
    .registers 3

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->checked:Ljava/lang/Boolean;

    .line 5
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->nationPrefix:Ljava/lang/String;

    .line 6
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->addressDetail:Ljava/lang/String;

    .line 7
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->addressId:Ljava/lang/String;

    .line 8
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->addressName:Ljava/lang/String;

    .line 9
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->addressStatus:Ljava/lang/String;

    .line 10
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->city:Ljava/lang/String;

    .line 11
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->cityCode:Ljava/lang/String;

    .line 12
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->consigneeName:Ljava/lang/String;

    .line 13
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->county:Ljava/lang/String;

    .line 14
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->countyCode:Ljava/lang/String;

    .line 15
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->gmtCreate:Ljava/lang/String;

    .line 16
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->gmtModified:Ljava/lang/String;

    .line 17
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->isDefault:Ljava/lang/String;

    .line 18
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->mobile:Ljava/lang/String;

    .line 19
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->needImprove:Ljava/lang/String;

    .line 20
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->province:Ljava/lang/String;

    .line 21
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->provinceCode:Ljava/lang/String;

    .line 22
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->street:Ljava/lang/String;

    .line 23
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->streetCode:Ljava/lang/String;

    .line 24
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->userId:Ljava/lang/String;

    .line 25
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->email:Ljava/lang/String;

    .line 26
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->zipCode:Ljava/lang/String;

    .line 27
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->telephone:Ljava/lang/String;

    .line 28
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->dmProvince:Ljava/lang/String;

    .line 29
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->dmProvinceCode:Ljava/lang/String;

    .line 30
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->dmCity:Ljava/lang/String;

    .line 31
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->dmCityCode:Ljava/lang/String;

    .line 32
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->dmCounty:Ljava/lang/String;

    .line 33
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->dmCountyCode:Ljava/lang/String;

    .line 34
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->version:Ljava/lang/String;

    .line 35
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->match:Ljava/lang/String;

    .line 36
    const-class v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readValue(Ljava/lang/ClassLoader;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->checked:Ljava/lang/Boolean;

    return-void
.end method


# virtual methods
.method public describeContents()I
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "65"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0

    :cond_1b
    return v3
.end method

.method public getAddressDetail()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->addressDetail:Ljava/lang/String;

    return-object v0
.end method

.method public getAddressId()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "7"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->addressId:Ljava/lang/String;

    return-object v0
.end method

.method public getAddressName()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "9"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->addressName:Ljava/lang/String;

    return-object v0
.end method

.method public getAddressStatus()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "11"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->addressStatus:Ljava/lang/String;

    return-object v0
.end method

.method public getChecked()Ljava/lang/Boolean;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->checked:Ljava/lang/Boolean;

    return-object v0
.end method

.method public getCity()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "13"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->city:Ljava/lang/String;

    return-object v0
.end method

.method public getCityCode()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "15"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->cityCode:Ljava/lang/String;

    return-object v0
.end method

.method public getConsigneeName()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "17"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->consigneeName:Ljava/lang/String;

    return-object v0
.end method

.method public getCounty()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "19"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->county:Ljava/lang/String;

    return-object v0
.end method

.method public getCountyCode()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "21"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->countyCode:Ljava/lang/String;

    return-object v0
.end method

.method public getDmCity()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "51"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->dmCity:Ljava/lang/String;

    return-object v0
.end method

.method public getDmCityCode()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "53"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->dmCityCode:Ljava/lang/String;

    return-object v0
.end method

.method public getDmCounty()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "55"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->dmCounty:Ljava/lang/String;

    return-object v0
.end method

.method public getDmCountyCode()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "57"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->dmCountyCode:Ljava/lang/String;

    return-object v0
.end method

.method public getDmProvince()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "47"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->dmProvince:Ljava/lang/String;

    return-object v0
.end method

.method public getDmProvinceCode()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "49"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->dmProvinceCode:Ljava/lang/String;

    return-object v0
.end method

.method public getEmail()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "41"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->email:Ljava/lang/String;

    return-object v0
.end method

.method public getGmtCreate()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "23"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->gmtCreate:Ljava/lang/String;

    return-object v0
.end method

.method public getGmtModified()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "25"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->gmtModified:Ljava/lang/String;

    return-object v0
.end method

.method public getIsDefault()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "27"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->isDefault:Ljava/lang/String;

    return-object v0
.end method

.method public getMatch()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "63"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->match:Ljava/lang/String;

    return-object v0
.end method

.method public getMobile()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "29"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->mobile:Ljava/lang/String;

    return-object v0
.end method

.method public getNationPrefix()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->nationPrefix:Ljava/lang/String;

    return-object v0
.end method

.method public getNeedImprove()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "31"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->needImprove:Ljava/lang/String;

    return-object v0
.end method

.method public getProvince()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "33"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->province:Ljava/lang/String;

    return-object v0
.end method

.method public getProvinceCode()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "35"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->provinceCode:Ljava/lang/String;

    return-object v0
.end method

.method public getStreet()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "61"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->street:Ljava/lang/String;

    return-object v0
.end method

.method public getStreetCode()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "37"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->streetCode:Ljava/lang/String;

    return-object v0
.end method

.method public getTelephone()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "45"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->telephone:Ljava/lang/String;

    return-object v0
.end method

.method public getUserId()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "39"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->userId:Ljava/lang/String;

    return-object v0
.end method

.method public getVersion()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "59"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->version:Ljava/lang/String;

    return-object v0
.end method

.method public getZipCode()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "43"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->zipCode:Ljava/lang/String;

    return-object v0
.end method

.method public setAddressDetail(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->addressDetail:Ljava/lang/String;

    return-void
.end method

.method public setAddressId(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "8"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->addressId:Ljava/lang/String;

    return-void
.end method

.method public setAddressName(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "10"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->addressName:Ljava/lang/String;

    return-void
.end method

.method public setAddressStatus(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "12"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->addressStatus:Ljava/lang/String;

    return-void
.end method

.method public setChecked(Ljava/lang/Boolean;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->checked:Ljava/lang/Boolean;

    return-void
.end method

.method public setCity(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "14"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->city:Ljava/lang/String;

    return-void
.end method

.method public setCityCode(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "16"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->cityCode:Ljava/lang/String;

    return-void
.end method

.method public setConsigneeName(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "18"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->consigneeName:Ljava/lang/String;

    return-void
.end method

.method public setCounty(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "20"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->county:Ljava/lang/String;

    return-void
.end method

.method public setCountyCode(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "22"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->countyCode:Ljava/lang/String;

    return-void
.end method

.method public setDmCity(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "52"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->dmCity:Ljava/lang/String;

    return-void
.end method

.method public setDmCityCode(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "54"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->dmCityCode:Ljava/lang/String;

    return-void
.end method

.method public setDmCounty(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "56"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->dmCounty:Ljava/lang/String;

    return-void
.end method

.method public setDmCountyCode(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "58"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->dmCountyCode:Ljava/lang/String;

    return-void
.end method

.method public setDmProvince(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "48"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->dmProvince:Ljava/lang/String;

    return-void
.end method

.method public setDmProvinceCode(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "50"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->dmProvinceCode:Ljava/lang/String;

    return-void
.end method

.method public setEmail(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "42"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->email:Ljava/lang/String;

    return-void
.end method

.method public setGmtCreate(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "24"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->gmtCreate:Ljava/lang/String;

    return-void
.end method

.method public setGmtModified(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "26"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->gmtModified:Ljava/lang/String;

    return-void
.end method

.method public setIsDefault(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "28"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->isDefault:Ljava/lang/String;

    return-void
.end method

.method public setMatch(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "64"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->match:Ljava/lang/String;

    return-void
.end method

.method public setMobile(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "30"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->mobile:Ljava/lang/String;

    return-void
.end method

.method public setNationPrefix(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->nationPrefix:Ljava/lang/String;

    return-void
.end method

.method public setNeedImprove(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "32"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->needImprove:Ljava/lang/String;

    return-void
.end method

.method public setProvince(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "34"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->province:Ljava/lang/String;

    return-void
.end method

.method public setProvinceCode(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "36"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->provinceCode:Ljava/lang/String;

    return-void
.end method

.method public setStreet(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "62"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->street:Ljava/lang/String;

    return-void
.end method

.method public setStreetCode(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "38"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->streetCode:Ljava/lang/String;

    return-void
.end method

.method public setTelephone(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "46"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->telephone:Ljava/lang/String;

    return-void
.end method

.method public setUserId(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "40"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->userId:Ljava/lang/String;

    return-void
.end method

.method public setVersion(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "60"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->version:Ljava/lang/String;

    return-void
.end method

.method public setZipCode(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "44"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->zipCode:Ljava/lang/String;

    return-void
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/address/bean/AddressBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "66"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1e
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->nationPrefix:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 2
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->addressDetail:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 3
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->addressId:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 4
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->addressName:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 5
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->addressStatus:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 6
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->city:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 7
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->cityCode:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 8
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->consigneeName:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 9
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->county:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 10
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->countyCode:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 11
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->gmtCreate:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 12
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->gmtModified:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 13
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->isDefault:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 14
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->mobile:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 15
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->needImprove:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 16
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->province:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 17
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->provinceCode:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 18
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->street:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 19
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->streetCode:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 20
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->userId:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 21
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->email:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 22
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->zipCode:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 23
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->telephone:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 24
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->dmProvince:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 25
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->dmProvinceCode:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 26
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->dmCity:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 27
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->dmCityCode:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 28
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->dmCounty:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 29
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->dmCountyCode:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 30
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->version:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 31
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->match:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 32
    iget-object p2, p0, Lcn/damai/commonbusiness/address/bean/AddressBean;->checked:Ljava/lang/Boolean;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeValue(Ljava/lang/Object;)V

    return-void
.end method
