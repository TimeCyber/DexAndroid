.class public Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "FlingRunnable"
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private mCurrentX:I

.field private mCurrentY:I

.field private final mScroller:Landroid/widget/OverScroller;

.field final synthetic this$0:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;


# direct methods
.method public constructor <init>(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;Landroid/content/Context;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;->this$0:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance p1, Landroid/widget/OverScroller;

    invoke-direct {p1, p2}, Landroid/widget/OverScroller;-><init>(Landroid/content/Context;)V

    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;->mScroller:Landroid/widget/OverScroller;

    return-void
.end method


# virtual methods
.method public cancelFling()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_14

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;->mScroller:Landroid/widget/OverScroller;

    invoke-virtual {v0, v3}, Landroid/widget/OverScroller;->forceFinished(Z)V

    return-void
.end method

.method public fling(IIII)V
    .registers 21

    move-object/from16 v0, p0

    sget-object v1, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v2, "2"

    invoke-static {v1, v2}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_32

    const/4 v3, 0x5

    new-array v3, v3, [Ljava/lang/Object;

    aput-object v0, v3, v4

    const/4 v4, 0x1

    invoke-static/range {p1 .. p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x2

    invoke-static/range {p2 .. p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x3

    invoke-static/range {p3 .. p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x4

    invoke-static/range {p4 .. p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v3, v4

    invoke-interface {v1, v2, v3}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_32
    iget-object v1, v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;->this$0:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-virtual {v1}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->E()Landroid/graphics/RectF;

    move-result-object v1

    if-nez v1, :cond_3b

    return-void

    .line 2
    :cond_3b
    iget v2, v1, Landroid/graphics/RectF;->left:F

    neg-float v2, v2

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v6

    move/from16 v2, p1

    int-to-float v2, v2

    .line 3
    invoke-virtual {v1}, Landroid/graphics/RectF;->width()F

    move-result v3

    cmpg-float v3, v2, v3

    if-gez v3, :cond_59

    .line 4
    invoke-virtual {v1}, Landroid/graphics/RectF;->width()F

    move-result v3

    sub-float/2addr v3, v2

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v2

    move v11, v2

    const/4 v10, 0x0

    goto :goto_5b

    :cond_59
    move v10, v6

    move v11, v10

    .line 5
    :goto_5b
    iget v2, v1, Landroid/graphics/RectF;->top:F

    neg-float v2, v2

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v7

    move/from16 v2, p2

    int-to-float v2, v2

    .line 6
    invoke-virtual {v1}, Landroid/graphics/RectF;->height()F

    move-result v3

    cmpg-float v3, v2, v3

    if-gez v3, :cond_79

    .line 7
    invoke-virtual {v1}, Landroid/graphics/RectF;->height()F

    move-result v1

    sub-float/2addr v1, v2

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    move v13, v1

    const/4 v12, 0x0

    goto :goto_7b

    :cond_79
    move v12, v7

    move v13, v12

    .line 8
    :goto_7b
    iput v6, v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;->mCurrentX:I

    .line 9
    iput v7, v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;->mCurrentY:I

    if-ne v6, v11, :cond_83

    if-eq v7, v13, :cond_8e

    .line 10
    :cond_83
    iget-object v5, v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;->mScroller:Landroid/widget/OverScroller;

    const/4 v14, 0x0

    const/4 v15, 0x0

    move/from16 v8, p3

    move/from16 v9, p4

    invoke-virtual/range {v5 .. v15}, Landroid/widget/OverScroller;->fling(IIIIIIIIII)V

    :cond_8e
    return-void
.end method

.method public run()V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;->mScroller:Landroid/widget/OverScroller;

    invoke-virtual {v0}, Landroid/widget/OverScroller;->isFinished()Z

    move-result v0

    if-eqz v0, :cond_1d

    return-void

    .line 2
    :cond_1d
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;->mScroller:Landroid/widget/OverScroller;

    invoke-virtual {v0}, Landroid/widget/OverScroller;->computeScrollOffset()Z

    move-result v0

    if-eqz v0, :cond_54

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;->mScroller:Landroid/widget/OverScroller;

    invoke-virtual {v0}, Landroid/widget/OverScroller;->getCurrX()I

    move-result v0

    .line 4
    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;->mScroller:Landroid/widget/OverScroller;

    invoke-virtual {v1}, Landroid/widget/OverScroller;->getCurrY()I

    move-result v1

    .line 5
    iget-object v2, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;->this$0:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-static {v2}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->m(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Landroid/graphics/Matrix;

    move-result-object v2

    iget v3, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;->mCurrentX:I

    sub-int/2addr v3, v0

    int-to-float v3, v3

    iget v4, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;->mCurrentY:I

    sub-int/2addr v4, v1

    int-to-float v4, v4

    invoke-virtual {v2, v3, v4}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    .line 6
    iget-object v2, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;->this$0:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-static {v2}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->s(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)V

    .line 7
    iput v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;->mCurrentX:I

    .line 8
    iput v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;->mCurrentY:I

    .line 9
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;->this$0:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->t(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Landroid/widget/ImageView;

    move-result-object v0

    invoke-static {v0, p0}, Ltb/l80;->a(Landroid/view/View;Ljava/lang/Runnable;)V

    :cond_54
    return-void
.end method
