.class public Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$j;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "j"
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private a:Landroid/app/Dialog;

.field final synthetic b:Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;


# direct methods
.method public constructor <init>(Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;Landroid/app/Dialog;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$j;->b:Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p2, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$j;->a:Landroid/app/Dialog;

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$j;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result p1

    .line 2
    sget v0, Lcn/damai/commonbusiness/R$id;->add_contacts_cancel_btn:I

    if-ne p1, v0, :cond_27

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$j;->a:Landroid/app/Dialog;

    if-eqz p1, :cond_3b

    .line 4
    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    goto :goto_3b

    .line 5
    :cond_27
    sget v0, Lcn/damai/commonbusiness/R$id;->add_contacts_confirm_btn:I

    if-ne p1, v0, :cond_3b

    .line 6
    iget-object p1, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$j;->b:Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;->access$800(Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;)Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$i;

    move-result-object p1

    invoke-virtual {p1, v3}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    .line 7
    iget-object p1, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$j;->a:Landroid/app/Dialog;

    if-eqz p1, :cond_3b

    .line 8
    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    :cond_3b
    :goto_3b
    return-void
.end method
