.class public Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;
.super Landroid/widget/FrameLayout;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private mCardNumDataTv:Landroid/widget/TextView;

.field private mCardNumTipTv:Landroid/widget/TextView;

.field private mCardTypeDataTv:Landroid/widget/TextView;

.field private mCardTypeTipTv:Landroid/widget/TextView;

.field private mNameDataTv:Landroid/widget/TextView;

.field private mNameTipTv:Landroid/widget/TextView;

.field private mRenewalNumberDataTv:Landroid/widget/TextView;

.field private mRenewalNumberLl:Landroid/widget/LinearLayout;

.field private mRenewalNumberTipTv:Landroid/widget/TextView;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, p1, v0}, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 4
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, p1, p2, v0}, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .line 3
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 4
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;->initView(Landroid/content/Context;)V

    return-void
.end method

.method private initView(Landroid/content/Context;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p1

    sget v0, Lcom/alibaba/pictures/picturesbiz/R$layout;->add_contacts_double_check_view:I

    invoke-virtual {p1, v0, p0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    .line 2
    sget p1, Lcom/alibaba/pictures/picturesbiz/R$id;->tv_name_tip:I

    invoke-virtual {p0, p1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;->mNameTipTv:Landroid/widget/TextView;

    .line 3
    sget p1, Lcom/alibaba/pictures/picturesbiz/R$id;->tv_name_data:I

    invoke-virtual {p0, p1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;->mNameDataTv:Landroid/widget/TextView;

    .line 4
    sget p1, Lcom/alibaba/pictures/picturesbiz/R$id;->tv_card_type_tip:I

    invoke-virtual {p0, p1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;->mCardTypeTipTv:Landroid/widget/TextView;

    .line 5
    sget p1, Lcom/alibaba/pictures/picturesbiz/R$id;->tv_card_type_data:I

    invoke-virtual {p0, p1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;->mCardTypeDataTv:Landroid/widget/TextView;

    .line 6
    sget p1, Lcom/alibaba/pictures/picturesbiz/R$id;->tv_card_num_tips:I

    invoke-virtual {p0, p1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;->mCardNumTipTv:Landroid/widget/TextView;

    .line 7
    sget p1, Lcom/alibaba/pictures/picturesbiz/R$id;->tv_card_num_data:I

    invoke-virtual {p0, p1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;->mCardNumDataTv:Landroid/widget/TextView;

    .line 8
    sget p1, Lcom/alibaba/pictures/picturesbiz/R$id;->ll_renewal_number:I

    invoke-virtual {p0, p1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/LinearLayout;

    iput-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;->mRenewalNumberLl:Landroid/widget/LinearLayout;

    .line 9
    sget p1, Lcom/alibaba/pictures/picturesbiz/R$id;->tv_renewal_number_tips:I

    invoke-virtual {p0, p1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;->mRenewalNumberTipTv:Landroid/widget/TextView;

    .line 10
    sget p1, Lcom/alibaba/pictures/picturesbiz/R$id;->tv_renewal_number_data:I

    invoke-virtual {p0, p1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;->mRenewalNumberDataTv:Landroid/widget/TextView;

    return-void
.end method


# virtual methods
.method public setData(Ljava/util/List;)V
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;",
            ">;)V"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v2, :cond_17

    new-array v2, v4, [Ljava/lang/Object;

    aput-object p0, v2, v5

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x3

    if-lt v0, v1, :cond_fa

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;->mNameTipTv:Landroid/widget/TextView;

    invoke-interface {p1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;

    iget-object v2, v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;->a:Ljava/lang/String;

    const-string v6, ""

    if-nez v2, :cond_2e

    move-object v2, v6

    goto :goto_36

    :cond_2e
    invoke-interface {p1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;

    iget-object v2, v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;->a:Ljava/lang/String;

    :goto_36
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;->mNameDataTv:Landroid/widget/TextView;

    invoke-interface {p1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;

    iget-object v2, v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;->b:Ljava/lang/String;

    if-nez v2, :cond_47

    move-object v2, v6

    goto :goto_4f

    :cond_47
    invoke-interface {p1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;

    iget-object v2, v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;->b:Ljava/lang/String;

    :goto_4f
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;->mCardTypeTipTv:Landroid/widget/TextView;

    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;

    iget-object v2, v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;->a:Ljava/lang/String;

    if-nez v2, :cond_60

    move-object v2, v6

    goto :goto_68

    :cond_60
    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;

    iget-object v2, v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;->a:Ljava/lang/String;

    :goto_68
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;->mCardTypeDataTv:Landroid/widget/TextView;

    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;

    iget-object v2, v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;->b:Ljava/lang/String;

    if-nez v2, :cond_79

    move-object v2, v6

    goto :goto_81

    :cond_79
    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;

    iget-object v2, v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;->b:Ljava/lang/String;

    :goto_81
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 6
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;->mCardNumTipTv:Landroid/widget/TextView;

    invoke-interface {p1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;

    iget-object v2, v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;->a:Ljava/lang/String;

    if-nez v2, :cond_92

    move-object v2, v6

    goto :goto_9a

    :cond_92
    invoke-interface {p1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;

    iget-object v2, v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;->a:Ljava/lang/String;

    :goto_9a
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 7
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;->mCardNumDataTv:Landroid/widget/TextView;

    invoke-interface {p1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;

    iget-object v2, v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;->b:Ljava/lang/String;

    if-nez v2, :cond_ab

    move-object v2, v6

    goto :goto_b3

    :cond_ab
    invoke-interface {p1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;

    iget-object v2, v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;->b:Ljava/lang/String;

    :goto_b3
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 8
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-le v0, v1, :cond_f3

    .line 9
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;->mRenewalNumberLl:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v5}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 10
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;->mRenewalNumberTipTv:Landroid/widget/TextView;

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;

    iget-object v2, v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;->a:Ljava/lang/String;

    if-nez v2, :cond_cf

    move-object v2, v6

    goto :goto_d7

    :cond_cf
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;

    iget-object v2, v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;->a:Ljava/lang/String;

    :goto_d7
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 11
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;->mRenewalNumberDataTv:Landroid/widget/TextView;

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;

    iget-object v2, v2, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;->b:Ljava/lang/String;

    if-nez v2, :cond_e7

    goto :goto_ef

    :cond_e7
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;

    iget-object v6, p1, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView$a;->b:Ljava/lang/String;

    :goto_ef
    invoke-virtual {v0, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_fa

    .line 12
    :cond_f3
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;->mRenewalNumberLl:Landroid/widget/LinearLayout;

    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->setVisibility(I)V

    :cond_fa
    :goto_fa
    return-void
.end method
