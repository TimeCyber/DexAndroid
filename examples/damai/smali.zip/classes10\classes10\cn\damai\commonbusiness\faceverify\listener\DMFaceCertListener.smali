.class public interface abstract Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertListener;
.super Ljava/lang/Object;
.source "Taobao"


# virtual methods
.method public abstract onAuditResult(Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult;)V
.end method
