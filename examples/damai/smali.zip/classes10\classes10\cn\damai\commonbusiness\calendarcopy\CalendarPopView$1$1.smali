.class public Lcn/damai/commonbusiness/calendarcopy/CalendarPopView$1$1;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/calendarcopy/CalendarPopView$1;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic this$1:Lcn/damai/commonbusiness/calendarcopy/CalendarPopView$1;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/calendarcopy/CalendarPopView$1;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/calendarcopy/CalendarPopView$1$1;->this$1:Lcn/damai/commonbusiness/calendarcopy/CalendarPopView$1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 8

    sget-object v0, Lcn/damai/commonbusiness/calendarcopy/CalendarPopView$1$1;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    invoke-static {}, Ltb/it;->p()I

    move-result v0

    invoke-static {}, Ltb/it;->n()I

    move-result v1

    invoke-static {v0, v1}, Ltb/it;->h(II)I

    move-result v0

    .line 2
    invoke-static {}, Ltb/it;->m()I

    move-result v1

    .line 3
    iget-object v2, p0, Lcn/damai/commonbusiness/calendarcopy/CalendarPopView$1$1;->this$1:Lcn/damai/commonbusiness/calendarcopy/CalendarPopView$1;

    iget-object v2, v2, Lcn/damai/commonbusiness/calendarcopy/CalendarPopView$1;->this$0:Lcn/damai/commonbusiness/calendarcopy/CalendarPopView;

    invoke-static {v2}, Lcn/damai/commonbusiness/calendarcopy/CalendarPopView;->f(Lcn/damai/commonbusiness/calendarcopy/CalendarPopView;)Ljava/util/List;

    move-result-object v2

    invoke-static {v2}, Ltb/ak5;->c(Ljava/util/Collection;)I

    move-result v2

    if-lez v2, :cond_5f

    .line 4
    iget-object v2, p0, Lcn/damai/commonbusiness/calendarcopy/CalendarPopView$1$1;->this$1:Lcn/damai/commonbusiness/calendarcopy/CalendarPopView$1;

    iget-object v2, v2, Lcn/damai/commonbusiness/calendarcopy/CalendarPopView$1;->this$0:Lcn/damai/commonbusiness/calendarcopy/CalendarPopView;

    invoke-static {v2}, Lcn/damai/commonbusiness/calendarcopy/CalendarPopView;->f(Lcn/damai/commonbusiness/calendarcopy/CalendarPopView;)Ljava/util/List;

    move-result-object v2

    invoke-interface {v2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/damai/commonbusiness/calendarcopy/bean/Day;

    if-eqz v2, :cond_5f

    .line 5
    iget v0, v2, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->year:I

    iget v1, v2, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->month:I

    invoke-static {v0, v1}, Ltb/it;->h(II)I

    move-result v0

    const-string v1, "GMT+8"

    .line 6
    invoke-static {v1}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Calendar;->getInstance(Ljava/util/TimeZone;)Ljava/util/Calendar;

    move-result-object v1

    .line 7
    iget v4, v2, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->year:I

    iget v5, v2, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->month:I

    iget v6, v2, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->day:I

    invoke-virtual {v1, v4, v5, v6}, Ljava/util/Calendar;->set(III)V

    .line 8
    iget v1, v2, Lcn/damai/commonbusiness/calendarcopy/bean/Day;->day:I

    :cond_5f
    add-int/2addr v0, v1

    add-int/lit8 v0, v0, -0x2

    .line 9
    div-int/lit8 v0, v0, 0x7

    .line 10
    iget-object v1, p0, Lcn/damai/commonbusiness/calendarcopy/CalendarPopView$1$1;->this$1:Lcn/damai/commonbusiness/calendarcopy/CalendarPopView$1;

    iget-object v1, v1, Lcn/damai/commonbusiness/calendarcopy/CalendarPopView$1;->this$0:Lcn/damai/commonbusiness/calendarcopy/CalendarPopView;

    invoke-static {v1}, Lcn/damai/commonbusiness/calendarcopy/CalendarPopView;->b(Lcn/damai/commonbusiness/calendarcopy/CalendarPopView;)Landroidx/recyclerview/widget/RecyclerView;

    move-result-object v1

    iget-object v2, p0, Lcn/damai/commonbusiness/calendarcopy/CalendarPopView$1$1;->this$1:Lcn/damai/commonbusiness/calendarcopy/CalendarPopView$1;

    iget v2, v2, Lcn/damai/commonbusiness/calendarcopy/CalendarPopView$1;->val$mDayHeigth:I

    mul-int v2, v2, v0

    invoke-virtual {v1, v3, v2}, Landroidx/recyclerview/widget/RecyclerView;->scrollBy(II)V

    return-void
.end method
