.class public Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$1;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->countDown()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic this$0:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$1;->this$0:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$1;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_14

    new-array v2, v4, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    :goto_14
    :try_start_14
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$1;->this$0:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    # getter for: Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->isContinue:Z
    invoke-static {v0}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->access$000(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;)Z

    move-result v0

    if-eqz v0, :cond_6e

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$1;->this$0:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    # operator-- for: Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->timeStamp:J
    invoke-static {v0}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->access$110(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;)J

    move-result-wide v1

    const-wide/16 v5, 0x1

    cmp-long v7, v1, v5

    if-lez v7, :cond_2a

    const/4 v1, 0x1

    goto :goto_2b

    :cond_2a
    const/4 v1, 0x0

    :goto_2b
    # setter for: Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->isContinue:Z
    invoke-static {v0, v1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->access$002(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;Z)Z

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$1;->this$0:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    # getter for: Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->timeStamp:J
    invoke-static {v0}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->access$100(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;)J

    move-result-wide v0

    invoke-static {v0, v1}, Ltb/yn0;->a(J)[Ljava/lang/String;

    move-result-object v0

    .line 4
    new-instance v1, Landroid/os/Message;

    invoke-direct {v1}, Landroid/os/Message;-><init>()V

    .line 5
    iput-object v0, v1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/16 v0, 0x65

    .line 6
    iput v0, v1, Landroid/os/Message;->what:I

    .line 7
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$1;->this$0:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    # getter for: Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->myHandler:Landroid/os/Handler;
    invoke-static {v0}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->access$200(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;)Landroid/os/Handler;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    const-wide/16 v0, 0x3e8

    .line 8
    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V

    const-string v0, "DMDXCountDownView"

    .line 9
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "timeStamp = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$1;->this$0:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    # getter for: Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->timeStamp:J
    invoke-static {v2}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->access$100(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;)J

    move-result-wide v5

    invoke-virtual {v1, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Ltb/av2;->b(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_14

    .line 10
    :cond_6e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$1;->this$0:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    # setter for: Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->isContinue:Z
    invoke-static {v0, v4}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->access$002(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;Z)Z
    :try_end_73
    .catch Ljava/lang/Exception; {:try_start_14 .. :try_end_73} :catch_74

    goto :goto_78

    :catch_74
    move-exception v0

    .line 11
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :goto_78
    return-void
.end method
