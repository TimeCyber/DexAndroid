.class public final Lcn/damai/commonbusiness/calendar/remind/a;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/calendar/remind/a$a;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    bv = {}
    d1 = {
        "\u0000\u000c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\u0018\u0000 \u00022\u00020\u0001:\u0001\u0003\u00a8\u0006\u0004"
    }
    d2 = {
        "Lcn/damai/commonbusiness/calendar/remind/a;",
        "",
        "Companion",
        "a",
        "picturesbiz_release"
    }
    k = 0x1
    mv = {
        0x1,
        0x7,
        0x1
    }
.end annotation


# static fields
.field public static final Companion:Lcn/damai/commonbusiness/calendar/remind/a$a;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcn/damai/commonbusiness/calendar/remind/a$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcn/damai/commonbusiness/calendar/remind/a$a;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcn/damai/commonbusiness/calendar/remind/a;->Companion:Lcn/damai/commonbusiness/calendar/remind/a$a;

    return-void
.end method
