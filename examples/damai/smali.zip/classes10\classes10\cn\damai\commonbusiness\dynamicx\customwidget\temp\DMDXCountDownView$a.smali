.class public Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$a;
.super Landroid/os/Handler;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private final a:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Landroid/os/Handler;-><init>()V

    .line 2
    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$a;->a:Ljava/lang/ref/WeakReference;

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v2, :cond_17

    new-array v2, v4, [Ljava/lang/Object;

    aput-object p0, v2, v3

    aput-object p1, v2, v5

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-super {p0, p1}, Landroid/os/Handler;->handleMessage(Landroid/os/Message;)V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$a;->a:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    if-nez v0, :cond_25

    return-void

    .line 3
    :cond_25
    iget v1, p1, Landroid/os/Message;->what:I

    const/16 v2, 0x65

    if-eq v1, v2, :cond_2c

    goto :goto_77

    .line 4
    :cond_2c
    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    if-eqz p1, :cond_64

    .line 5
    check-cast p1, [Ljava/lang/String;

    const/4 v1, 0x0

    .line 6
    :goto_33
    array-length v2, p1

    if-ge v1, v2, :cond_5d

    if-eqz v1, :cond_51

    if-eq v1, v5, :cond_47

    if-eq v1, v4, :cond_3d

    goto :goto_5a

    .line 7
    :cond_3d
    aget-object v2, p1, v4

    # getter for: Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;
    invoke-static {v0}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->access$600(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;)Landroid/widget/TextView;

    move-result-object v6

    # invokes: Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->updateTvText(Ljava/lang/String;Landroid/widget/TextView;)V
    invoke-static {v0, v2, v6}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->access$400(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;Ljava/lang/String;Landroid/widget/TextView;)V

    goto :goto_5a

    .line 8
    :cond_47
    aget-object v2, p1, v5

    # getter for: Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;
    invoke-static {v0}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->access$500(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;)Landroid/widget/TextView;

    move-result-object v6

    # invokes: Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->updateTvText(Ljava/lang/String;Landroid/widget/TextView;)V
    invoke-static {v0, v2, v6}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->access$400(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;Ljava/lang/String;Landroid/widget/TextView;)V

    goto :goto_5a

    .line 9
    :cond_51
    aget-object v2, p1, v3

    # getter for: Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;
    invoke-static {v0}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->access$300(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;)Landroid/widget/TextView;

    move-result-object v6

    # invokes: Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->updateTvText(Ljava/lang/String;Landroid/widget/TextView;)V
    invoke-static {v0, v2, v6}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->access$400(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;Ljava/lang/String;Landroid/widget/TextView;)V

    :goto_5a
    add-int/lit8 v1, v1, 0x1

    goto :goto_33

    :cond_5d
    const-string p1, "DMDXCountDownView"

    const-string v1, "handleMessage"

    .line 10
    invoke-static {p1, v1}, Ltb/av2;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 11
    :cond_64
    # getter for: Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->isContinue:Z
    invoke-static {v0}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->access$000(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;)Z

    move-result p1

    if-nez p1, :cond_77

    .line 12
    # getter for: Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->countDownEndListener:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownEndListener;
    invoke-static {v0}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->access$700(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownEndListener;

    move-result-object p1

    if-eqz p1, :cond_77

    .line 13
    # getter for: Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->countDownEndListener:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownEndListener;
    invoke-static {v0}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->access$700(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownEndListener;

    move-result-object p1

    invoke-interface {p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownEndListener;->onCountDownEnd()V

    :cond_77
    :goto_77
    return-void
.end method
