.class public interface abstract Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$OnStreetDivisionChangedListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnStreetDivisionChangedListener"
.end annotation


# virtual methods
.method public abstract onStreetDivisionChanged(Lcn/damai/commonbusiness/address/bean/DivisionBean;)V
.end method
