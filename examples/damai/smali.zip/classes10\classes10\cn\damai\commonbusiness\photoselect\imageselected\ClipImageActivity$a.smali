.class public Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity$a;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->e()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity$a;->a:Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity$a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity$a;->a:Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->a(Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;)Lcn/damai/commonbusiness/photoselect/imageselected/view/ClipImageView;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    if-eqz p1, :cond_39

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity$a;->a:Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->b(Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;)Landroid/widget/FrameLayout;

    move-result-object p1

    invoke-virtual {p1, v3}, Landroid/widget/FrameLayout;->setEnabled(Z)V

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity$a;->a:Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->a(Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;)Lcn/damai/commonbusiness/photoselect/imageselected/view/ClipImageView;

    move-result-object v0

    invoke-virtual {v0}, Lcn/damai/commonbusiness/photoselect/imageselected/view/ClipImageView;->clipImage()Landroid/graphics/Bitmap;

    move-result-object v0

    invoke-static {p1, v0}, Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;->c(Lcn/damai/commonbusiness/photoselect/imageselected/ClipImageActivity;Landroid/graphics/Bitmap;)V

    :cond_39
    return-void
.end method
