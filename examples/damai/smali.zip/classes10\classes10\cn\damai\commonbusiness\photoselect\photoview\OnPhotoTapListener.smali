.class public interface abstract Lcn/damai/commonbusiness/photoselect/photoview/OnPhotoTapListener;
.super Ljava/lang/Object;
.source "Taobao"


# virtual methods
.method public abstract onPhotoTap(Landroid/widget/ImageView;FF)V
.end method
