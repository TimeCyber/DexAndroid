.class public Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$b;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;->initListener()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$b;->a:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$b;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$b;->a:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;->access$000(Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;)Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;

    move-result-object v0

    invoke-virtual {v0}, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;->g()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$b;->a:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;

    invoke-static {v0, p1, v3}, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;->access$100(Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;Ljava/util/ArrayList;I)V

    return-void
.end method
