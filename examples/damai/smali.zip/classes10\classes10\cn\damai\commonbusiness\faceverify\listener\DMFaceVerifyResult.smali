.class public Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;
    }
.end annotation


# instance fields
.field public a:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:Ljava/lang/String;

.field public f:Ljava/lang/String;

.field public g:Ljava/lang/String;

.field public h:Z


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    sget-object v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;->SUCCESS:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;

    iput-object v0, p0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;->a:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;

    return-void
.end method
