.class public final synthetic Lcn/damai/commonbusiness/photoselect/imageselected/adapter/a;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;

.field public final synthetic b:Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;

.field public final synthetic c:Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$d;

.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$d;I)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/a;->a:Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;

    iput-object p2, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/a;->b:Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;

    iput-object p3, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/a;->c:Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$d;

    iput p4, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/a;->d:I

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 6

    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/a;->a:Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;

    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/a;->b:Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;

    iget-object v2, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/a;->c:Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$d;

    iget v3, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/a;->d:I

    invoke-static {v0, v1, v2, v3, p1}, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;->a(Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$d;ILandroid/view/View;)V

    return-void
.end method
