.class public interface abstract Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView$OnItemClickListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnItemClickListener"
.end annotation


# virtual methods
.method public abstract onItemClick(ILandroid/view/View;)V
.end method
