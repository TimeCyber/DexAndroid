.class public Lcn/damai/commonbusiness/contacts/view/RealNameTipView;
.super Landroid/widget/LinearLayout;
.source "Taobao"


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private checkBox:Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

.field private icon:Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

.field private textView:Landroid/widget/TextView;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, p1, v0}, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 4
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, p1, p2, v0}, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .line 3
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 4
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->initView(Landroid/content/Context;)V

    return-void
.end method

.method static synthetic access$000(Lcn/damai/commonbusiness/contacts/view/RealNameTipView;ZLandroid/content/Context;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->updateCheckState(ZLandroid/content/Context;)V

    return-void
.end method

.method private initView(Landroid/content/Context;)V
    .registers 10

    sget-object v0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v2, :cond_17

    new-array v2, v3, [Ljava/lang/Object;

    aput-object p0, v2, v5

    aput-object p1, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-virtual {p0, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v0, 0x10

    .line 2
    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 3
    new-instance v1, Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

    invoke-direct {v1, p1}, Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->icon:Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

    const/high16 v2, 0x41400000    # 12.0f

    .line 4
    invoke-virtual {v1, v4, v2}, Landroidx/appcompat/widget/AppCompatTextView;->setTextSize(IF)V

    .line 5
    iget-object v1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->icon:Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

    const-string v6, "#CCCCCC"

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v1, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 6
    iget-object v1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->icon:Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    sget v7, Lcom/alibaba/pictures/picturesbiz/R$string;->iconfont_tishimian_:I

    invoke-virtual {v6, v7}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 7
    iget-object v1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->icon:Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

    invoke-virtual {p0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 8
    new-instance v1, Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

    invoke-direct {v1, p1}, Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->checkBox:Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

    .line 9
    iget-object v1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->icon:Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

    const/high16 v6, 0x41800000    # 16.0f

    invoke-virtual {v1, v4, v6}, Landroidx/appcompat/widget/AppCompatTextView;->setTextSize(IF)V

    .line 10
    sget-object v1, Ltb/f31;->INSTANCE:Ltb/f31;

    invoke-virtual {v1, p1, v0}, Ltb/f31;->b(Landroid/content/Context;I)I

    move-result v0

    .line 11
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v6, v0, v0}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 12
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->checkBox:Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

    invoke-virtual {v0, v6}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 13
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->checkBox:Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 14
    invoke-direct {p0, v5, p1}, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->updateCheckState(ZLandroid/content/Context;)V

    .line 15
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->checkBox:Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

    new-instance v6, Lcn/damai/commonbusiness/contacts/view/RealNameTipView$a;

    invoke-direct {v6, p0, p1}, Lcn/damai/commonbusiness/contacts/view/RealNameTipView$a;-><init>(Lcn/damai/commonbusiness/contacts/view/RealNameTipView;Landroid/content/Context;)V

    invoke-virtual {v0, v6}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 16
    invoke-virtual {p0, v5}, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->updateIconVis(Z)V

    .line 17
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->textView:Landroid/widget/TextView;

    const/4 v6, 0x3

    .line 18
    invoke-virtual {v1, p1, v6}, Ltb/f31;->b(Landroid/content/Context;I)I

    move-result v6

    invoke-virtual {v1, p1, v3}, Ltb/f31;->b(Landroid/content/Context;I)I

    move-result p1

    invoke-virtual {v0, v6, v5, v5, p1}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 19
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->textView:Landroid/widget/TextView;

    invoke-virtual {p1, v4, v2}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 20
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->textView:Landroid/widget/TextView;

    const-string v0, "#8890A0"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 21
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->textView:Landroid/widget/TextView;

    invoke-virtual {p0, p1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void
.end method

.method private declared-synchronized updateCheckState(ZLandroid/content/Context;)V
    .registers 7

    monitor-enter p0

    :try_start_1
    sget-object v0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_22

    const-string v1, "2"

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_20
    .catchall {:try_start_1 .. :try_end_20} :catchall_74

    monitor-exit p0

    return-void

    .line 1
    :cond_22
    :try_start_22
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->checkBox:Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTag(Ljava/lang/Object;)V

    if-eqz p1, :cond_5c

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->checkBox:Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

    sget v0, Lcom/alibaba/pictures/picturesbiz/R$string;->iconfont_xf_xuanzhongchenggong:I

    invoke-virtual {p2, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3
    sget-object p1, Ltb/oa;->INSTANCE:Ltb/oa;

    invoke-virtual {p1}, Ltb/oa;->getAppConfigProvider()Lcom/alibaba/pictures/cornerstone/common/IAppConfigProvider;

    move-result-object p1

    invoke-interface {p1}, Lcom/alibaba/pictures/cornerstone/common/IAppConfigProvider;->getIsPioneerOpen()Z

    move-result p1

    if-eqz p1, :cond_50

    .line 4
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->checkBox:Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

    sget v0, Lcom/alibaba/pictures/picturesbiz/R$color;->color_FF7600:I

    invoke-static {p2, v0}, Landroidx/core/content/ContextCompat;->getColor(Landroid/content/Context;I)I

    move-result p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setTextColor(I)V

    goto :goto_72

    .line 5
    :cond_50
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->checkBox:Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

    sget v0, Lcom/alibaba/pictures/picturesbiz/R$color;->color_FF2D79:I

    invoke-static {p2, v0}, Landroidx/core/content/ContextCompat;->getColor(Landroid/content/Context;I)I

    move-result p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setTextColor(I)V

    goto :goto_72

    .line 6
    :cond_5c
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->checkBox:Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

    sget v0, Lcom/alibaba/pictures/picturesbiz/R$string;->iconfont_xf_weixuanzhong:I

    invoke-virtual {p2, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 7
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->checkBox:Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

    sget v0, Lcom/alibaba/pictures/picturesbiz/R$color;->color_999999:I

    invoke-static {p2, v0}, Landroidx/core/content/ContextCompat;->getColor(Landroid/content/Context;I)I

    move-result p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setTextColor(I)V
    :try_end_72
    .catchall {:try_start_22 .. :try_end_72} :catchall_74

    .line 8
    :goto_72
    monitor-exit p0

    return-void

    :catchall_74
    move-exception p1

    monitor-exit p0

    throw p1
.end method


# virtual methods
.method public getCheckState()Z
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->checkBox:Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

    if-eqz v0, :cond_32

    invoke-virtual {v0}, Landroid/widget/TextView;->getVisibility()I

    move-result v0

    if-nez v0, :cond_32

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->checkBox:Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->getTag()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    return v0

    :cond_32
    return v3
.end method

.method public setText(Ljava/lang/String;Ljava/lang/String;)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1a

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1a
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->textView:Landroid/widget/TextView;

    if-eqz v0, :cond_56

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_56

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_2b

    goto :goto_56

    .line 2
    :cond_2b
    invoke-virtual {p1, p2}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v0

    .line 3
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result p2

    add-int/2addr p2, v0

    .line 4
    new-instance v1, Landroid/text/SpannableStringBuilder;

    invoke-direct {v1, p1}, Landroid/text/SpannableStringBuilder;-><init>(Ljava/lang/CharSequence;)V

    .line 5
    new-instance v2, Lcn/damai/commonbusiness/contacts/view/RealNameTipView$b;

    invoke-direct {v2, p0, p1}, Lcn/damai/commonbusiness/contacts/view/RealNameTipView$b;-><init>(Lcn/damai/commonbusiness/contacts/view/RealNameTipView;Ljava/lang/String;)V

    const/16 p1, 0x12

    .line 6
    invoke-virtual {v1, v2, v0, p2, p1}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    .line 7
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->textView:Landroid/widget/TextView;

    invoke-virtual {p1, v3}, Landroid/widget/TextView;->setHighlightColor(I)V

    .line 8
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->textView:Landroid/widget/TextView;

    invoke-static {}, Landroid/text/method/LinkMovementMethod;->getInstance()Landroid/text/method/MovementMethod;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setMovementMethod(Landroid/text/method/MovementMethod;)V

    .line 9
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->textView:Landroid/widget/TextView;

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_56
    :goto_56
    return-void
.end method

.method public updateCheckState(Z)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 9
    :cond_1b
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->checkBox:Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

    if-eqz v0, :cond_26

    .line 10
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-direct {p0, p1, v0}, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->updateCheckState(ZLandroid/content/Context;)V

    :cond_26
    return-void
.end method

.method public updateIconVis(Z)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_1b
    const/16 v0, 0x8

    if-eqz p1, :cond_2a

    .line 1
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->checkBox:Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

    invoke-virtual {p1, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->icon:Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setVisibility(I)V

    goto :goto_34

    .line 3
    :cond_2a
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->checkBox:Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setVisibility(I)V

    .line 4
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->icon:Lcom/alibaba/pictures/bricks/view/BricksIconFontTextView;

    invoke-virtual {p1, v3}, Landroid/widget/TextView;->setVisibility(I)V

    :goto_34
    return-void
.end method
