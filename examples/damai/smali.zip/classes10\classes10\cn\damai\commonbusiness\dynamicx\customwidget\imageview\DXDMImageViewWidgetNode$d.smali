.class public Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode$d;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/dynamicx/customwidget/imageview/DXDMImageViewWidgetNode;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
