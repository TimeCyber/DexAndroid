.class public Lcn/damai/commonbusiness/fission/util/FissionUtil;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/fission/util/FissionUtil$FissionViewInterface;
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon; = null

.field public static final FISSION_CHANNEL_TYPE_LIVE:Ljava/lang/String; = "4"

.field public static final FISSION_HIDE_PROGRESS:Ljava/lang/String; = "0"

.field public static final FISSION_SCENE_TYPE_LIVE:Ljava/lang/String; = "3"

.field public static final FISSION_SHOW_PROGRESS:Ljava/lang/String; = "1"


# instance fields
.field private a:Lcn/damai/commonbusiness/fission/util/FissionUtil$FissionViewInterface;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic a(Lcn/damai/commonbusiness/fission/util/FissionUtil;Ljava/lang/String;)Z
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/fission/util/FissionUtil;->g(Ljava/lang/String;)Z

    move-result p0

    return p0
.end method

.method static synthetic b(Lcn/damai/commonbusiness/fission/util/FissionUtil;)Lcn/damai/commonbusiness/fission/util/FissionUtil$FissionViewInterface;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/fission/util/FissionUtil;->a:Lcn/damai/commonbusiness/fission/util/FissionUtil$FissionViewInterface;

    return-object p0
.end method

.method static synthetic c(Lcn/damai/commonbusiness/fission/util/FissionUtil;Landroid/content/Context;Lcn/damai/commonbusiness/fission/bean/FissionInfoBean;Lcn/damai/commonbusiness/fission/bean/FissionParam;)V
    .registers 4

    .line 1
    invoke-direct {p0, p1, p2, p3}, Lcn/damai/commonbusiness/fission/util/FissionUtil;->e(Landroid/content/Context;Lcn/damai/commonbusiness/fission/bean/FissionInfoBean;Lcn/damai/commonbusiness/fission/bean/FissionParam;)V

    return-void
.end method

.method static synthetic d(Lcn/damai/commonbusiness/fission/util/FissionUtil;ZZLjava/lang/String;Ljava/lang/String;)V
    .registers 5

    .line 1
    invoke-direct {p0, p1, p2, p3, p4}, Lcn/damai/commonbusiness/fission/util/FissionUtil;->j(ZZLjava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method private e(Landroid/content/Context;Lcn/damai/commonbusiness/fission/bean/FissionInfoBean;Lcn/damai/commonbusiness/fission/bean/FissionParam;)V
    .registers 8

    sget-object v0, Lcn/damai/commonbusiness/fission/util/FissionUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1d

    const/4 v2, 0x4

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    aput-object p3, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1d
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const-string v1, "fissionParam"

    .line 2
    invoke-virtual {v0, v1, p3}, Landroid/os/Bundle;->putSerializable(Ljava/lang/String;Ljava/io/Serializable;)V

    const-string p3, "fissionResult"

    .line 3
    invoke-virtual {v0, p3, p2}, Landroid/os/Bundle;->putSerializable(Ljava/lang/String;Ljava/io/Serializable;)V

    .line 4
    invoke-static {p1}, Lcn/damai/common/nav/DMNav;->from(Landroid/content/Context;)Lcn/damai/common/nav/DMNav;

    move-result-object p1

    invoke-virtual {p1, v0}, Lcn/damai/common/nav/DMNav;->withExtras(Landroid/os/Bundle;)Lcn/damai/common/nav/DMNav;

    move-result-object p1

    const-string p2, "fission_beautify_share"

    invoke-static {p2}, Lcn/damai/common/nav/NavUri;->e(Ljava/lang/String;)Lcn/damai/common/nav/NavUri;

    move-result-object p2

    invoke-virtual {p1, p2}, Lcn/damai/common/nav/DMNav;->toUri(Lcn/damai/common/nav/NavUri;)Z

    return-void
.end method

.method private g(Ljava/lang/String;)Z
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/fission/util/FissionUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    return p1

    :cond_1e
    const-string v0, "1"

    .line 1
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method private j(ZZLjava/lang/String;Ljava/lang/String;)V
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/fission/util/FissionUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_28

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    aput-object p3, v2, p1

    const/4 p1, 0x4

    aput-object p4, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_28
    if-eqz p1, :cond_3b

    .line 1
    iget-object p1, p0, Lcn/damai/commonbusiness/fission/util/FissionUtil;->a:Lcn/damai/commonbusiness/fission/util/FissionUtil$FissionViewInterface;

    if-eqz p1, :cond_38

    if-eqz p2, :cond_34

    .line 2
    invoke-interface {p1}, Lcn/damai/commonbusiness/fission/util/FissionUtil$FissionViewInterface;->showEmptyPage()V

    goto :goto_3b

    .line 3
    :cond_34
    invoke-interface {p1, p3, p4}, Lcn/damai/commonbusiness/fission/util/FissionUtil$FissionViewInterface;->showErrorView(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_3b

    .line 4
    :cond_38
    invoke-direct {p0}, Lcn/damai/commonbusiness/fission/util/FissionUtil;->k()V

    :cond_3b
    :goto_3b
    return-void
.end method

.method private k()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/fission/util/FissionUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_14
    const-string v0, "\u7f51\u7edc\u4e0d\u592a\u987a\u7545\u54e6\uff5e"

    .line 1
    invoke-static {v0}, Lcn/damai/common/util/ToastUtil;->i(Ljava/lang/CharSequence;)V

    return-void
.end method


# virtual methods
.method public f(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcn/damai/commonbusiness/fission/bean/FissionParam;
    .registers 15

    sget-object v0, Lcn/damai/commonbusiness/fission/util/FissionUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_39

    const/16 v2, 0xb

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    aput-object p3, v2, p1

    const/4 p1, 0x4

    aput-object p4, v2, p1

    const/4 p1, 0x5

    aput-object p5, v2, p1

    const/4 p1, 0x6

    aput-object p6, v2, p1

    const/4 p1, 0x7

    aput-object p7, v2, p1

    const/16 p1, 0x8

    aput-object p8, v2, p1

    const/16 p1, 0x9

    aput-object p9, v2, p1

    const/16 p1, 0xa

    aput-object p10, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/fission/bean/FissionParam;

    return-object p1

    .line 1
    :cond_39
    new-instance v0, Lcn/damai/commonbusiness/fission/bean/FissionParam;

    invoke-direct {v0}, Lcn/damai/commonbusiness/fission/bean/FissionParam;-><init>()V

    .line 2
    iput-object p3, v0, Lcn/damai/commonbusiness/fission/bean/FissionParam;->projectName:Ljava/lang/String;

    .line 3
    iput-object p5, v0, Lcn/damai/commonbusiness/fission/bean/FissionParam;->subMessage:Ljava/lang/String;

    .line 4
    iput-object p1, v0, Lcn/damai/commonbusiness/fission/bean/FissionParam;->imageUrl:Ljava/lang/String;

    .line 5
    iput-object p2, v0, Lcn/damai/commonbusiness/fission/bean/FissionParam;->uniqueIdent:Ljava/lang/String;

    .line 6
    iput-object p4, v0, Lcn/damai/commonbusiness/fission/bean/FissionParam;->mainMessage:Ljava/lang/String;

    .line 7
    iput-object p6, v0, Lcn/damai/commonbusiness/fission/bean/FissionParam;->sceneTip:Ljava/lang/String;

    .line 8
    iput-object p7, v0, Lcn/damai/commonbusiness/fission/bean/FissionParam;->shareUrl:Ljava/lang/String;

    .line 9
    iput-object p8, v0, Lcn/damai/commonbusiness/fission/bean/FissionParam;->channelType:Ljava/lang/String;

    .line 10
    iput-object p9, v0, Lcn/damai/commonbusiness/fission/bean/FissionParam;->sceneType:Ljava/lang/String;

    .line 11
    iput-object p10, v0, Lcn/damai/commonbusiness/fission/bean/FissionParam;->loadingState:Ljava/lang/String;

    return-object v0
.end method

.method public h(Landroid/content/Context;Lcn/damai/commonbusiness/fission/bean/FissionParam;)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/fission/util/FissionUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_1a
    if-nez p2, :cond_1d

    return-void

    :cond_1d
    if-eqz p1, :cond_31

    .line 1
    iget-object v0, p2, Lcn/damai/commonbusiness/fission/bean/FissionParam;->loadingState:Ljava/lang/String;

    invoke-direct {p0, v0}, Lcn/damai/commonbusiness/fission/util/FissionUtil;->g(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_31

    instance-of v0, p1, Lcn/damai/commonbusiness/base/DamaiBaseActivity;

    if-eqz v0, :cond_31

    .line 2
    move-object v0, p1

    check-cast v0, Lcn/damai/commonbusiness/base/DamaiBaseActivity;

    invoke-virtual {v0}, Lcn/damai/common/app/base/BaseActivity;->startProgressDialog()V

    .line 3
    :cond_31
    new-instance v0, Lcn/damai/commonbusiness/fission/bean/FissionDataRequest;

    invoke-direct {v0}, Lcn/damai/commonbusiness/fission/bean/FissionDataRequest;-><init>()V

    .line 4
    iget-object v1, p2, Lcn/damai/commonbusiness/fission/bean/FissionParam;->channelType:Ljava/lang/String;

    iput-object v1, v0, Lcn/damai/commonbusiness/fission/bean/FissionDataRequest;->channelType:Ljava/lang/String;

    .line 5
    iget-object v1, p2, Lcn/damai/commonbusiness/fission/bean/FissionParam;->sceneType:Ljava/lang/String;

    iput-object v1, v0, Lcn/damai/commonbusiness/fission/bean/FissionDataRequest;->sceneType:Ljava/lang/String;

    .line 6
    new-instance v1, Lcn/damai/commonbusiness/fission/util/FissionUtil$1;

    const-class v2, Lcn/damai/commonbusiness/fission/bean/FissionInfoBean;

    invoke-direct {v1, p0, v2, p1, p2}, Lcn/damai/commonbusiness/fission/util/FissionUtil$1;-><init>(Lcn/damai/commonbusiness/fission/util/FissionUtil;Ljava/lang/Class;Landroid/content/Context;Lcn/damai/commonbusiness/fission/bean/FissionParam;)V

    .line 7
    invoke-virtual {v0, v1}, Lcn/damai/common/net/mtop/netfit/DMBaseMtopRequest;->request(Lcom/taobao/tao/remotebusiness/IRemoteBaseListener;)Lcom/taobao/tao/remotebusiness/MtopBusiness;

    return-void
.end method

.method public i(Lcn/damai/commonbusiness/fission/util/FissionUtil$FissionViewInterface;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/fission/util/FissionUtil;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "7"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/fission/util/FissionUtil;->a:Lcn/damai/commonbusiness/fission/util/FissionUtil$FissionViewInterface;

    return-void
.end method
