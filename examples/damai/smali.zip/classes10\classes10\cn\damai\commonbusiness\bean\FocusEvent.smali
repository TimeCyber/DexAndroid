.class public Lcn/damai/commonbusiness/bean/FocusEvent;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon; = null

.field public static final EVENT_NAME_NOTE_FOCUS_CHANGED:Ljava/lang/String; = "EVENT_NAME_NOTE_FOCUS_CHANGED"

.field public static final EVENT_NAME_PROJECT_FOCUS_CHANGED:Ljava/lang/String; = "EVENT_NAME_PROJECT_FOCUS_CHANGED"


# instance fields
.field public isFollowNow:Z

.field public itemId:Ljava/lang/String;
    .annotation build Landroidx/annotation/Nullable;
    .end annotation
.end field

.field public final type:Ljava/lang/String;


# direct methods
.method private constructor <init>(Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lcn/damai/commonbusiness/bean/FocusEvent;->type:Ljava/lang/String;

    return-void
.end method

.method public static noteFocusChanged()Lcn/damai/commonbusiness/bean/FocusEvent;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/bean/FocusEvent;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/bean/FocusEvent;

    return-object v0

    .line 1
    :cond_14
    new-instance v0, Lcn/damai/commonbusiness/bean/FocusEvent;

    const-string v1, "EVENT_NAME_NOTE_FOCUS_CHANGED"

    invoke-direct {v0, v1}, Lcn/damai/commonbusiness/bean/FocusEvent;-><init>(Ljava/lang/String;)V

    return-object v0
.end method

.method public static projectFocusChanged()Lcn/damai/commonbusiness/bean/FocusEvent;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/bean/FocusEvent;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/bean/FocusEvent;

    return-object v0

    .line 1
    :cond_14
    new-instance v0, Lcn/damai/commonbusiness/bean/FocusEvent;

    const-string v1, "EVENT_NAME_PROJECT_FOCUS_CHANGED"

    invoke-direct {v0, v1}, Lcn/damai/commonbusiness/bean/FocusEvent;-><init>(Ljava/lang/String;)V

    return-object v0
.end method

.method public static projectFocusChanged(Ljava/lang/String;Z)Lcn/damai/commonbusiness/bean/FocusEvent;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/bean/FocusEvent;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 p0, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, p0

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcn/damai/commonbusiness/bean/FocusEvent;

    return-object p0

    .line 2
    :cond_1e
    new-instance v0, Lcn/damai/commonbusiness/bean/FocusEvent;

    const-string v1, "EVENT_NAME_PROJECT_FOCUS_CHANGED"

    invoke-direct {v0, v1}, Lcn/damai/commonbusiness/bean/FocusEvent;-><init>(Ljava/lang/String;)V

    .line 3
    iput-object p0, v0, Lcn/damai/commonbusiness/bean/FocusEvent;->itemId:Ljava/lang/String;

    .line 4
    iput-boolean p1, v0, Lcn/damai/commonbusiness/bean/FocusEvent;->isFollowNow:Z

    return-object v0
.end method
