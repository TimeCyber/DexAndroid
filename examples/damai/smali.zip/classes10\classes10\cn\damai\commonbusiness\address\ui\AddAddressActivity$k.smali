.class public Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/address/ui/AddAddressActivity;->initListeners()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/address/ui/AddAddressActivity;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/address/ui/AddAddressActivity;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k;->a:Lcn/damai/commonbusiness/address/ui/AddAddressActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-static {p1}, Ltb/wj1;->a(Landroid/view/View;)Z

    move-result p1

    if-eqz p1, :cond_1e

    return-void

    .line 2
    :cond_1e
    sget-object p1, Ltb/oa;->INSTANCE:Ltb/oa;

    invoke-virtual {p1}, Ltb/oa;->getAppClientName()Ljava/lang/String;

    move-result-object p1

    sget-object v0, Lcom/alibaba/pictures/cornerstone/APPClient;->TPP:Lcom/alibaba/pictures/cornerstone/APPClient;

    invoke-virtual {v0}, Lcom/alibaba/pictures/cornerstone/APPClient;->getClientName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_76

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k;->a:Lcn/damai/commonbusiness/address/ui/AddAddressActivity;

    sget v0, Lcom/alibaba/pictures/picturesbiz/R$id;->address_protocol_checkbox:I

    invoke-virtual {p1, v0}, Landroidx/appcompat/app/AppCompatActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/CheckBox;

    if-eqz p1, :cond_76

    .line 4
    invoke-virtual {p1}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v0

    if-nez v0, :cond_76

    .line 5
    new-instance v0, Lcn/damai/common/app/widget/DMDialog;

    iget-object v1, p0, Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k;->a:Lcn/damai/commonbusiness/address/ui/AddAddressActivity;

    invoke-direct {v0, v1}, Lcn/damai/common/app/widget/DMDialog;-><init>(Landroid/content/Context;)V

    .line 6
    invoke-virtual {v0}, Lcn/damai/common/app/widget/DMDialog;->A()Lcn/damai/common/app/widget/DMDialog;

    const-string v1, "\u8bf7\u9605\u8bfb\u5e76\u540c\u610f"

    .line 7
    invoke-virtual {v0, v1}, Lcn/damai/common/app/widget/DMDialog;->z(Ljava/lang/CharSequence;)Lcn/damai/common/app/widget/DMDialog;

    const-string v1, "#2e333e"

    .line 8
    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    const/high16 v2, 0x41700000    # 15.0f

    const-string v3, "\u90e8\u5206\u7968\u52a1\u53ca\u5546\u54c1\u9700\u5feb\u9012\u90ae\u5bc4\uff0c\u8bf7\u586b\u5199\u5e76\u6388\u6743\u6dd8\u7968\u7968\uff08APP\u3001\u5c0f\u7a0b\u5e8f\uff09\u6536\u96c6\u60a8\u7684\u6536\u8d27\u5730\u5740\uff0c\u7528\u4e8e\u5728\u6dd8\u7968\u7968\u5404\u6e20\u9053\u4e0b\u5355\u65f6\u5411\u60a8\u5feb\u901f\u5c55\u793a/\u9009\u62e9\u6536\u8d27\u4fe1\u606f\u3002\u60a8\u53ef\u5728\u6dd8\u7968\u7968APP\u6216\u652f\u4ed8\u5b9d-\u201c\u6dd8\u7968\u7968\u201d\u5c0f\u7a0b\u5e8f-\u201c\u6536\u8d27\u5730\u5740\u201d\u4e2d\u8fdb\u884c\u67e5\u770b\u548c\u7ba1\u7406\u3002"

    invoke-virtual {v0, v3, v1, v2}, Lcn/damai/common/app/widget/DMDialog;->v(Ljava/lang/CharSequence;IF)Lcn/damai/common/app/widget/DMDialog;

    .line 9
    new-instance v1, Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k$a;

    invoke-direct {v1, p0, p1}, Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k$a;-><init>(Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k;Landroid/widget/CheckBox;)V

    const-string p1, "\u540c\u610f\u5e76\u4fdd\u5b58"

    invoke-virtual {v0, p1, v1}, Lcn/damai/common/app/widget/DMDialog;->r(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Lcn/damai/common/app/widget/DMDialog;

    .line 10
    new-instance p1, Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k$b;

    invoke-direct {p1, p0}, Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k$b;-><init>(Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k;)V

    const-string v1, "\u4e0d\u540c\u610f"

    invoke-virtual {v0, v1, p1}, Lcn/damai/common/app/widget/DMDialog;->m(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Lcn/damai/common/app/widget/DMDialog;

    .line 11
    invoke-virtual {v0}, Lcn/damai/common/app/widget/DMDialog;->show()V

    return-void

    .line 12
    :cond_76
    iget-object p1, p0, Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k;->a:Lcn/damai/commonbusiness/address/ui/AddAddressActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/address/ui/AddAddressActivity;->access$000(Lcn/damai/commonbusiness/address/ui/AddAddressActivity;)V

    .line 13
    iget-object p1, p0, Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k;->a:Lcn/damai/commonbusiness/address/ui/AddAddressActivity;

    invoke-static {p1}, Ltb/d41;->f(Landroid/app/Activity;)V

    return-void
.end method
