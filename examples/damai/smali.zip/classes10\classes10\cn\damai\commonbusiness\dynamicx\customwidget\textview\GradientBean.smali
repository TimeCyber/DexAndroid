.class public Lcn/damai/commonbusiness/dynamicx/customwidget/textview/GradientBean;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public angle:F

.field public endColor:I

.field public startColor:I


# direct methods
.method public constructor <init>(IIF)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/textview/GradientBean;->startColor:I

    .line 3
    iput p2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/textview/GradientBean;->endColor:I

    .line 4
    iput p3, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/textview/GradientBean;->angle:F

    return-void
.end method
