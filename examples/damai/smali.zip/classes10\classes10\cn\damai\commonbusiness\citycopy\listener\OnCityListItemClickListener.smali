.class public interface abstract Lcn/damai/commonbusiness/citycopy/listener/OnCityListItemClickListener;
.super Ljava/lang/Object;
.source "Taobao"


# virtual methods
.method public abstract onGroupCityClick(Ljava/lang/String;Ljava/lang/String;)V
.end method

.method public abstract onHotCityClick(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
.end method

.method public abstract onLocationCityClick(Ljava/lang/String;Ljava/lang/String;)V
.end method

.method public abstract onRequestLocationPermission()V
.end method
