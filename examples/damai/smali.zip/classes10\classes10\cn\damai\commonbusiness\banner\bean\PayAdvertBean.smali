.class public Lcn/damai/commonbusiness/banner/bean/PayAdvertBean;
.super Ljava/lang/Object;
.source "Taobao"


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field public advertisement:Lcn/damai/commonbusiness/banner/bean/PageBanner;

.field public baccount:Lcn/damai/commonbusiness/search/bean/BaccountInfo;

.field public vipActivityInfo:Lcn/damai/commonbusiness/banner/bean/PageVipInfo;

.field public vipScore:Lcn/damai/commonbusiness/banner/bean/PayVipScore;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public isVipMember()Z
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/banner/bean/PayAdvertBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_1b

    new-array v2, v3, [Ljava/lang/Object;

    aput-object p0, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget-object v0, p0, Lcn/damai/commonbusiness/banner/bean/PayAdvertBean;->vipScore:Lcn/damai/commonbusiness/banner/bean/PayVipScore;

    if-nez v0, :cond_20

    return v4

    .line 2
    :cond_20
    iget v0, v0, Lcn/damai/commonbusiness/banner/bean/PayVipScore;->memberFlag:I

    if-nez v0, :cond_25

    return v4

    :cond_25
    return v3
.end method
