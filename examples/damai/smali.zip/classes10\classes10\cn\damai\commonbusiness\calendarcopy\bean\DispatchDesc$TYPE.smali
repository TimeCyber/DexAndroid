.class public final enum Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;
.super Ljava/lang/Enum;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "TYPE"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

.field public static final enum BLUE:Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

.field public static final enum PINK:Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

.field public static final enum PURPLE:Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

.field public static final enum YELLOW:Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;


# instance fields
.field private index:I

.field private typeName:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 9

    .line 1
    new-instance v0, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

    const-string v1, "YELLOW"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v1, v2}, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;-><init>(Ljava/lang/String;ILjava/lang/String;I)V

    sput-object v0, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;->YELLOW:Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

    new-instance v1, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

    const-string v3, "PINK"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4, v3, v4}, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;-><init>(Ljava/lang/String;ILjava/lang/String;I)V

    sput-object v1, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;->PINK:Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

    new-instance v3, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

    const-string v5, "PURPLE"

    const/4 v6, 0x2

    invoke-direct {v3, v5, v6, v5, v6}, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;-><init>(Ljava/lang/String;ILjava/lang/String;I)V

    sput-object v3, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;->PURPLE:Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

    new-instance v5, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

    const-string v7, "BLUE"

    const/4 v8, 0x3

    invoke-direct {v5, v7, v8, v7, v8}, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;-><init>(Ljava/lang/String;ILjava/lang/String;I)V

    sput-object v5, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;->BLUE:Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

    const/4 v7, 0x4

    new-array v7, v7, [Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

    aput-object v0, v7, v2

    aput-object v1, v7, v4

    aput-object v3, v7, v6

    aput-object v5, v7, v8

    .line 2
    sput-object v7, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;->$VALUES:[Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;I)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 p1, 0x0

    .line 2
    iput p1, p0, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;->index:I

    .line 3
    iput-object p3, p0, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;->typeName:Ljava/lang/String;

    .line 4
    iput p4, p0, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;->index:I

    return-void
.end method

.method public static fromTypeName(Ljava/lang/String;)Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;
    .registers 6

    .line 1
    invoke-static {}, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;->values()[Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

    move-result-object v0

    array-length v1, v0

    const/4 v2, 0x0

    :goto_6
    if-ge v2, v1, :cond_18

    aget-object v3, v0, v2

    .line 2
    invoke-virtual {v3}, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;->getTypeName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_15

    return-object v3

    :cond_15
    add-int/lit8 v2, v2, 0x1

    goto :goto_6

    .line 3
    :cond_18
    sget-object p0, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;->PINK:Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;
    .registers 2

    .line 1
    const-class v0, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

    return-object p0
.end method

.method public static values()[Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;
    .registers 1

    .line 1
    sget-object v0, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;->$VALUES:[Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

    invoke-virtual {v0}, [Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;

    return-object v0
.end method


# virtual methods
.method public equals(Ljava/lang/String;)Z
    .registers 3

    .line 1
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_8

    const/4 p1, 0x0

    return p1

    .line 2
    :cond_8
    iget-object v0, p0, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;->typeName:Ljava/lang/String;

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public getTypeName()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;->typeName:Ljava/lang/String;

    return-object v0
.end method

.method public toIndex()I
    .registers 2

    .line 1
    iget v0, p0, Lcn/damai/commonbusiness/calendarcopy/bean/DispatchDesc$TYPE;->index:I

    return v0
.end method
