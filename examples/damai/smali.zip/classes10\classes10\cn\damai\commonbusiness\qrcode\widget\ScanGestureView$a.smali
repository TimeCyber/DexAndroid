.class public Lcn/damai/commonbusiness/qrcode/widget/ScanGestureView$a;
.super Landroid/os/Handler;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/qrcode/widget/ScanGestureView;->init()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/qrcode/widget/ScanGestureView;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/qrcode/widget/ScanGestureView;Landroid/os/Looper;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanGestureView$a;->a:Lcn/damai/commonbusiness/qrcode/widget/ScanGestureView;

    invoke-direct {p0, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .registers 8

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScanGestureView$a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v2, :cond_17

    new-array v2, v3, [Ljava/lang/Object;

    aput-object p0, v2, v5

    aput-object p1, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_17
    const/16 v0, 0x9

    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "handleMessage: msg("

    aput-object v1, v0, v5

    .line 1
    iget v1, p1, Landroid/os/Message;->what:I

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v4

    const-string v1, ", "

    aput-object v1, v0, v3

    const/4 v2, 0x3

    iget v3, p1, Landroid/os/Message;->arg1:I

    .line 2
    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v0, v2

    const/4 v2, 0x4

    aput-object v1, v0, v2

    const/4 v2, 0x5

    iget v3, p1, Landroid/os/Message;->arg2:I

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v0, v2

    const/4 v2, 0x6

    aput-object v1, v0, v2

    const/4 v1, 0x7

    iget-object v2, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 3
    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    const/16 v1, 0x8

    const-string v2, ")"

    aput-object v2, v0, v1

    const-string v1, "ScanGestureView"

    .line 4
    invoke-static {v1, v0}, Lcom/alipay/mobile/bqcscanservice/MPaasLogger;->d(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 5
    iget v0, p1, Landroid/os/Message;->what:I

    # getter for: Lcn/damai/commonbusiness/qrcode/widget/ScanGestureView;->MSG_CLICK:I
    invoke-static {}, Lcn/damai/commonbusiness/qrcode/widget/ScanGestureView;->access$000()I

    move-result v1

    if-ne v0, v1, :cond_7c

    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    instance-of v1, v0, Ljava/lang/Long;

    if-eqz v1, :cond_7c

    check-cast v0, Ljava/lang/Long;

    iget-object v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanGestureView$a;->a:Lcn/damai/commonbusiness/qrcode/widget/ScanGestureView;

    .line 6
    # getter for: Lcn/damai/commonbusiness/qrcode/widget/ScanGestureView;->lastActionUp:J
    invoke-static {v1}, Lcn/damai/commonbusiness/qrcode/widget/ScanGestureView;->access$100(Lcn/damai/commonbusiness/qrcode/widget/ScanGestureView;)J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/Long;->compareTo(Ljava/lang/Long;)I

    move-result v0

    if-nez v0, :cond_7c

    .line 7
    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScanGestureView$a;->a:Lcn/damai/commonbusiness/qrcode/widget/ScanGestureView;

    # invokes: Lcn/damai/commonbusiness/qrcode/widget/ScanGestureView;->onFinderClickHappen(Landroid/os/Message;)V
    invoke-static {v0, p1}, Lcn/damai/commonbusiness/qrcode/widget/ScanGestureView;->access$200(Lcn/damai/commonbusiness/qrcode/widget/ScanGestureView;Landroid/os/Message;)V

    :cond_7c
    return-void
.end method
