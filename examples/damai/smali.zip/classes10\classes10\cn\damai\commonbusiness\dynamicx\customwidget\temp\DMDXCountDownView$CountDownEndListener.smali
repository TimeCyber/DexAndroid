.class public interface abstract Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownEndListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "CountDownEndListener"
.end annotation


# virtual methods
.method public abstract onCountDownEnd()V
.end method
