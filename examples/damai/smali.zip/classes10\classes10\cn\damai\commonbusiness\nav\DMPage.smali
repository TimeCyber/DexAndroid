.class public Lcn/damai/commonbusiness/nav/DMPage;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/nav/DMPage$Flutter;
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon; = null

.field public static A:Ljava/lang/String; = "login"

.field public static final ARTISTID_THEME:Ljava/lang/String; = "userprofile"

.field public static final ARTIST_DETAIL:Ljava/lang/String; = "artist_detail"

.field public static B:Ljava/lang/String; = "auth_third"

.field public static final BRAND:Ljava/lang/String; = "brand"

.field public static C:Ljava/lang/String; = "home_message"

.field public static final CITY_SELECTED:Ljava/lang/String; = "home_cityselect"

.field public static final COMMON_ALBUM:Ljava/lang/String; = "album_common"

.field public static final COUPON_ITEM_SEARCH:Ljava/lang/String; = "coupon_project_search"

.field public static final COUPON_ORDER_CONFIRM:Ljava/lang/String; = "coupon_order_confirm"

.field public static final COUPON_ORDER_DETAIL:Ljava/lang/String; = "coupon_order_detail"

.field public static D:Ljava/lang/String; = "message_follow_comment"

.field public static final DISCOVER_CIRCLE_THEME_PAGE:Ljava/lang/String; = "discover_circle_activity"

.field public static final DISCOVER_CONTENT_DETAIL:Ljava/lang/String; = "discover_content_detail"

.field public static final DISCOVER_MEDIA_PAGER:Ljava/lang/String; = "discover_media_pager"

.field public static final DISCOVER_THEME:Ljava/lang/String; = "discover_theme_activity"

.field public static final DRAMA_COMMING:Ljava/lang/String; = "drama_comming"

.field public static E:Ljava/lang/String; = "add_contact"

.field public static F:Ljava/lang/String; = "perform_calendar"

.field public static G:Ljava/lang/String; = "rank_square"

.field public static H:Ljava/lang/String; = "ranking"

.field public static I:Ljava/lang/String; = "rank"

.field public static final IP_DRAMA:Ljava/lang/String; = "ipdrama"

.field public static J:Ljava/lang/String; = "detailed_list"

.field public static K:Ljava/lang/String; = "sku"

.field public static L:Ljava/lang/String; = "user_center"

.field public static final LIVE_HOUSE_SECOND_PAGE:Ljava/lang/String; = "live_house_second_page"

.field public static M:Ljava/lang/String; = "relation"

.field public static final MESSAGE_PUSH_SETTING:Ljava/lang/String; = "message_push_setting"

.field public static N:Ljava/lang/String; = "my_want_see"

.field public static final NEW_SHOW_CALENDAR:Ljava/lang/String; = "cms_common_second_v2"

.field public static O:Ljava/lang/String; = "want_praise"

.field public static P:Ljava/lang/String; = "editaccount"

.field public static final PAGE_ARTIST_OFFICAL_CONTENT_LIST:Ljava/lang/String; = "artist_official_content_list_page"

.field public static final PAGE_DISCOVER:Ljava/lang/String; = "discover"

.field public static final PAGE_FILM_DETAIL:Ljava/lang/String; = "show_detail"

.field public static final PAGE_IMAGE_BROWSE:Ljava/lang/String; = "image_browse"

.field public static final PAGE_QILIN_JPG_REGION:Ljava/lang/String; = "ql_jpg_region_activity"

.field public static final PAGE_QILIN_JPG_SEAT:Ljava/lang/String; = "ql_jpg_seat_activity"

.field public static final PAGE_QILIN_SVG_SEAT:Ljava/lang/String; = "ql_svg_seat_activity"

.field public static final PAGE_USER_HOME:Ljava/lang/String; = "user_home"

.field public static final PERMISSION_ENTRANCE:Ljava/lang/String; = "permission_entrance"

.field public static final PERSONAL_RESERVATION:Ljava/lang/String; = "grab_list"

.field public static final PRIVACY_SETTING:Ljava/lang/String; = "privacy_setting"

.field public static final PROJECT_VENUE_MAP:Ljava/lang/String; = "venuemap"

.field public static Q:Ljava/lang/String; = "account_safe"

.field public static R:Ljava/lang/String; = "mycomment"

.field public static final RANK_SQUARE_CMS_HOST:Ljava/lang/String; = "cms_rank_square"

.field public static final REAL_NAME_TICKET_LIST:Ljava/lang/String; = "real_name_ticket_list"

.field public static final REPORT:Ljava/lang/String; = "report"

.field public static S:Ljava/lang/String; = "logistics"

.field public static final SCENIC_BUY_POP:Ljava/lang/String; = "scenic_buy"

.field public static final SCENIC_DETAIL:Ljava/lang/String; = "scenic_detail"

.field public static final SCRIPT_COUPON_DETAIL:Ljava/lang/String; = "script_coupon_detail"

.field public static final SCRIPT_COUPON_PAY_RESULT:Ljava/lang/String; = "coupon_pay_result"

.field public static final SCRIPT_DETAIL:Ljava/lang/String; = "script_detail"

.field public static final SCRIPT_SELECT:Ljava/lang/String; = "script_selector"

.field public static final SCRIPT_SHOP_DETAIL:Ljava/lang/String; = "script_shop_detail"

.field public static final SEARCH_RESULT:Ljava/lang/String; = "search_result"

.field public static final SHARE_ORDER:Ljava/lang/String; = "share_order"

.field public static final SHOW_CALENDAR_V3:Ljava/lang/String; = "cms_common_second_v3"

.field public static final SHOW_FILM_LIST:Ljava/lang/String; = "show_film_list"

.field public static T:Ljava/lang/String; = "my_address_list"

.field public static final TICKET_E_SOUNENVIR:Ljava/lang/String; = "ticklet_e_sounenvir"

.field public static final TICKET_NOTICE:Ljava/lang/String; = "ticket_notice"

.field public static final TICKET_SOUNENVIR:Ljava/lang/String; = "ticklet_sounenvir"

.field public static final TICKET_VENUEPOINT:Ljava/lang/String; = "ticket_venuepoint"

.field public static U:Ljava/lang/String; = "user_extras_data"

.field public static V:Ljava/lang/String; = "addaddress"

.field private static W:Ljava/lang/String; = "coupons"

.field private static X:Ljava/lang/String; = "coupon_detail"

.field public static Y:Ljava/lang/String; = "customers"

.field public static Z:Ljava/lang/String; = "my_integral"

.field public static a:Ljava/lang/String; = "damai://"

.field private static a0:Ljava/lang/String; = "nameauth"

.field public static b:Ljava/lang/String; = "damai"

.field public static b0:Ljava/lang/String; = "settings"

.field public static c:Ljava/lang/String; = "tbmovie"

.field public static c0:Ljava/lang/String; = "evaluate_list"

.field public static d:Ljava/lang/String; = "http"

.field public static d0:Ljava/lang/String; = "issue"

.field public static e:Ljava/lang/String; = "https"

.field public static e0:Ljava/lang/String; = "commentdetail"

.field public static f:Ljava/lang/String; = "projectdetail"

.field public static f0:Ljava/lang/String; = "userprofile"

.field public static g:Ljava/lang/String; = "ultron"

.field public static g0:Ljava/lang/String; = "member_ticketwalletlist"

.field public static h:Ljava/lang/String; = "purchase_address_list"

.field public static h0:Ljava/lang/String; = "member_ticketwalletinfo"

.field public static i:Ljava/lang/String; = "purchase_pay_success"

.field public static i0:Ljava/lang/String; = "ticklet"

.field public static j:Ljava/lang/String; = "my_showorder"

.field public static k:Ljava/lang/String; = "my_orderdetails"

.field public static l:Ljava/lang/String; = "order_modify_address"

.field public static m:Ljava/lang/String; = "my_hn_orderdetails"

.field public static n:Ljava/lang/String; = "order_detail_progress"

.field public static o:Ljava/lang/String; = "order_modify_address"

.field public static p:Ljava/lang/String; = "hn_order_create_invoice"

.field public static q:Ljava/lang/String; = "hn_order_invoice_detail"

.field public static r:Ljava/lang/String; = "channel"

.field public static s:Ljava/lang/String; = "home"

.field public static t:Ljava/lang/String; = "home_search"

.field public static u:Ljava/lang/String; = "category"
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static v:Ljava/lang/String; = "yy_member_tab"

.field public static w:Ljava/lang/String; = "new_star_list2"
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static x:Ljava/lang/String; = "new_brand_list2"
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static y:Ljava/lang/String; = "webview"

.field public static z:Ljava/lang/String; = "new_webview"


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public static a()Lcn/damai/common/nav/NavUri;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/common/nav/NavUri;

    return-object v0

    .line 1
    :cond_14
    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->f:Ljava/lang/String;

    invoke-static {v0}, Lcn/damai/common/nav/NavUri;->e(Ljava/lang/String;)Lcn/damai/common/nav/NavUri;

    move-result-object v0

    return-object v0
.end method

.method public static b()Lcn/damai/common/nav/NavUri;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "11"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/common/nav/NavUri;

    return-object v0

    .line 1
    :cond_14
    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->V:Ljava/lang/String;

    invoke-static {v0}, Lcn/damai/common/nav/NavUri;->e(Ljava/lang/String;)Lcn/damai/common/nav/NavUri;

    move-result-object v0

    return-object v0
.end method

.method public static c()Lcn/damai/common/nav/NavUri;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "13"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/common/nav/NavUri;

    return-object v0

    .line 1
    :cond_14
    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->X:Ljava/lang/String;

    invoke-static {v0}, Lcn/damai/common/nav/NavUri;->e(Ljava/lang/String;)Lcn/damai/common/nav/NavUri;

    move-result-object v0

    return-object v0
.end method

.method public static d()Lcn/damai/common/nav/NavUri;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "12"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/common/nav/NavUri;

    return-object v0

    .line 1
    :cond_14
    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->W:Ljava/lang/String;

    invoke-static {v0}, Lcn/damai/common/nav/NavUri;->e(Ljava/lang/String;)Lcn/damai/common/nav/NavUri;

    move-result-object v0

    return-object v0
.end method

.method public static e()Lcn/damai/common/nav/NavUri;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "17"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/common/nav/NavUri;

    return-object v0

    :cond_14
    const-string v0, "image_browse"

    .line 1
    invoke-static {v0}, Lcn/damai/common/nav/NavUri;->e(Ljava/lang/String;)Lcn/damai/common/nav/NavUri;

    move-result-object v0

    return-object v0
.end method

.method public static f()Lcn/damai/common/nav/NavUri;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/common/nav/NavUri;

    return-object v0

    .line 1
    :cond_14
    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->A:Ljava/lang/String;

    invoke-static {v0}, Lcn/damai/common/nav/NavUri;->e(Ljava/lang/String;)Lcn/damai/common/nav/NavUri;

    move-result-object v0

    return-object v0
.end method

.method public static g()Lcn/damai/common/nav/NavUri;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "9"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/common/nav/NavUri;

    return-object v0

    .line 1
    :cond_14
    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->T:Ljava/lang/String;

    invoke-static {v0}, Lcn/damai/common/nav/NavUri;->e(Ljava/lang/String;)Lcn/damai/common/nav/NavUri;

    move-result-object v0

    return-object v0
.end method

.method public static h()Lcn/damai/common/nav/NavUri;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "10"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/common/nav/NavUri;

    return-object v0

    .line 1
    :cond_14
    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->U:Ljava/lang/String;

    invoke-static {v0}, Lcn/damai/common/nav/NavUri;->e(Ljava/lang/String;)Lcn/damai/common/nav/NavUri;

    move-result-object v0

    return-object v0
.end method

.method public static i()Lcn/damai/common/nav/NavUri;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "14"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/common/nav/NavUri;

    return-object v0

    .line 1
    :cond_14
    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->Z:Ljava/lang/String;

    invoke-static {v0}, Lcn/damai/common/nav/NavUri;->e(Ljava/lang/String;)Lcn/damai/common/nav/NavUri;

    move-result-object v0

    return-object v0
.end method

.method public static j()Lcn/damai/common/nav/NavUri;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/common/nav/NavUri;

    return-object v0

    .line 1
    :cond_14
    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->N:Ljava/lang/String;

    invoke-static {v0}, Lcn/damai/common/nav/NavUri;->e(Ljava/lang/String;)Lcn/damai/common/nav/NavUri;

    move-result-object v0

    return-object v0
.end method

.method public static k()Lcn/damai/common/nav/NavUri;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "15"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/common/nav/NavUri;

    return-object v0

    .line 1
    :cond_14
    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->a0:Ljava/lang/String;

    invoke-static {v0}, Lcn/damai/common/nav/NavUri;->e(Ljava/lang/String;)Lcn/damai/common/nav/NavUri;

    move-result-object v0

    return-object v0
.end method

.method public static l()Lcn/damai/common/nav/NavUri;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/common/nav/NavUri;

    return-object v0

    .line 1
    :cond_14
    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->M:Ljava/lang/String;

    invoke-static {v0}, Lcn/damai/common/nav/NavUri;->e(Ljava/lang/String;)Lcn/damai/common/nav/NavUri;

    move-result-object v0

    return-object v0
.end method

.method public static m()Lcn/damai/common/nav/NavUri;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "16"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/common/nav/NavUri;

    return-object v0

    .line 1
    :cond_14
    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->b0:Ljava/lang/String;

    invoke-static {v0}, Lcn/damai/common/nav/NavUri;->e(Ljava/lang/String;)Lcn/damai/common/nav/NavUri;

    move-result-object v0

    return-object v0
.end method

.method public static n()Lcn/damai/common/nav/NavUri;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "8"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/common/nav/NavUri;

    return-object v0

    .line 1
    :cond_14
    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->R:Ljava/lang/String;

    invoke-static {v0}, Lcn/damai/common/nav/NavUri;->e(Ljava/lang/String;)Lcn/damai/common/nav/NavUri;

    move-result-object v0

    return-object v0
.end method

.method public static o()Lcn/damai/common/nav/NavUri;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/common/nav/NavUri;

    return-object v0

    .line 1
    :cond_14
    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->L:Ljava/lang/String;

    invoke-static {v0}, Lcn/damai/common/nav/NavUri;->e(Ljava/lang/String;)Lcn/damai/common/nav/NavUri;

    move-result-object v0

    return-object v0
.end method

.method public static p()Lcn/damai/common/nav/NavUri;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "7"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/common/nav/NavUri;

    return-object v0

    .line 1
    :cond_14
    sget-object v0, Lcn/damai/commonbusiness/nav/DMPage;->O:Ljava/lang/String;

    invoke-static {v0}, Lcn/damai/common/nav/NavUri;->e(Ljava/lang/String;)Lcn/damai/common/nav/NavUri;

    move-result-object v0

    return-object v0
.end method
