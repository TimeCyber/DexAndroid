.class public Lcn/damai/commonbusiness/model/ProjectListItem;
.super Ljava/lang/Object;
.source "Taobao"


# instance fields
.field public BuySum:I

.field public CategoryID:I

.field public CityId:I

.field public CityName:Ljava/lang/String;

.field public IsOnlyXuanZuo:Z

.field public IsToBeAboutTo:Z

.field public IsXuanZuo:I

.field public Seating:Ljava/lang/String;

.field public Summary:Ljava/lang/String;

.field public VenId:I

.field public VenName:Ljava/lang/String;

.field public b:J

.field public d:Ljava/lang/String;

.field public heightWord:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public i:J

.field public n:Ljava/lang/String;

.field public openSum:I

.field public p:Ljava/lang/String;

.field public priceName:Ljava/lang/String;

.field public promotionTags:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public s:I

.field public showCity:Z

.field public showTag:Ljava/lang/String;

.field public subHead:Ljava/lang/String;

.field public t:Ljava/lang/String;

.field public time:Ljava/lang/String;

.field public v:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Lcn/damai/commonbusiness/model/ProjectListItem;->showCity:Z

    return-void
.end method
