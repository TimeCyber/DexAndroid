.class public Lcn/damai/commonbusiness/contacts/view/RealNameTipView$a;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->initView(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Lcn/damai/commonbusiness/contacts/view/RealNameTipView;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/contacts/view/RealNameTipView;Landroid/content/Context;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView$a;->b:Lcn/damai/commonbusiness/contacts/view/RealNameTipView;

    iput-object p2, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView$a;->a:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView$a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView$a;->b:Lcn/damai/commonbusiness/contacts/view/RealNameTipView;

    invoke-virtual {p1}, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->getCheckState()Z

    move-result v0

    xor-int/2addr v0, v3

    iget-object v1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView$a;->a:Landroid/content/Context;

    # invokes: Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->updateCheckState(ZLandroid/content/Context;)V
    invoke-static {p1, v0, v1}, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->access$000(Lcn/damai/commonbusiness/contacts/view/RealNameTipView;ZLandroid/content/Context;)V

    return-void
.end method
