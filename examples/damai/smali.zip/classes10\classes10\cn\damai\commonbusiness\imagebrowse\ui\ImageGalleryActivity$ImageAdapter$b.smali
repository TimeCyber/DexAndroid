.class public Lcn/damai/commonbusiness/imagebrowse/ui/ImageGalleryActivity$ImageAdapter$b;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/imagebrowse/ui/ImageGalleryActivity$ImageAdapter;->onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:I

.field final synthetic b:Lcn/damai/commonbusiness/imagebrowse/ui/ImageGalleryActivity$ImageAdapter;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/imagebrowse/ui/ImageGalleryActivity$ImageAdapter;I)V
    .registers 3

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/imagebrowse/ui/ImageGalleryActivity$ImageAdapter$b;->b:Lcn/damai/commonbusiness/imagebrowse/ui/ImageGalleryActivity$ImageAdapter;

    iput p2, p0, Lcn/damai/commonbusiness/imagebrowse/ui/ImageGalleryActivity$ImageAdapter$b;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/imagebrowse/ui/ImageGalleryActivity$ImageAdapter$b;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/imagebrowse/ui/ImageGalleryActivity$ImageAdapter$b;->b:Lcn/damai/commonbusiness/imagebrowse/ui/ImageGalleryActivity$ImageAdapter;

    iget-object v0, v0, Lcn/damai/commonbusiness/imagebrowse/ui/ImageGalleryActivity$ImageAdapter;->a:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_24
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3c

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 3
    new-instance v2, Lcn/damai/commonbusiness/imagebrowse/bean/PicInfo;

    invoke-direct {v2}, Lcn/damai/commonbusiness/imagebrowse/bean/PicInfo;-><init>()V

    .line 4
    invoke-virtual {v2, v1}, Lcn/damai/commonbusiness/imagebrowse/bean/PicInfo;->setPicUrl(Ljava/lang/String;)V

    .line 5
    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_24

    .line 6
    :cond_3c
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const-string v1, "pic_info"

    .line 7
    invoke-virtual {v0, v1, p1}, Landroid/os/Bundle;->putParcelableArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    .line 8
    iget p1, p0, Lcn/damai/commonbusiness/imagebrowse/ui/ImageGalleryActivity$ImageAdapter$b;->a:I

    const-string v1, "position"

    invoke-virtual {v0, v1, p1}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 9
    iget-object p1, p0, Lcn/damai/commonbusiness/imagebrowse/ui/ImageGalleryActivity$ImageAdapter$b;->b:Lcn/damai/commonbusiness/imagebrowse/ui/ImageGalleryActivity$ImageAdapter;

    iget-object p1, p1, Lcn/damai/commonbusiness/imagebrowse/ui/ImageGalleryActivity$ImageAdapter;->d:Lcn/damai/commonbusiness/imagebrowse/ui/ImageGalleryActivity;

    iget-object p1, p1, Lcn/damai/common/app/base/BaseActivity;->mContext:Landroid/content/Context;

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1}, Lcn/damai/common/nav/DMNav;->from(Landroid/content/Context;)Lcn/damai/common/nav/DMNav;

    move-result-object p1

    invoke-virtual {p1, v0}, Lcn/damai/common/nav/DMNav;->withExtras(Landroid/os/Bundle;)Lcn/damai/common/nav/DMNav;

    move-result-object p1

    const-string v0, "videobrowse"

    invoke-static {v0}, Lcn/damai/common/nav/NavUri;->e(Ljava/lang/String;)Lcn/damai/common/nav/NavUri;

    move-result-object v0

    invoke-virtual {p1, v0}, Lcn/damai/common/nav/DMNav;->toUri(Lcn/damai/common/nav/NavUri;)Z

    return-void
.end method
