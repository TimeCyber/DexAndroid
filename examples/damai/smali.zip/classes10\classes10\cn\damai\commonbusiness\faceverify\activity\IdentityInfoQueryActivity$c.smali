.class public Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$c;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnFocusChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;->setListener()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$c;->a:Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onFocusChange(Landroid/view/View;Z)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$c;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1e
    iget-object p1, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$c;->a:Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;->access$100(Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;)Landroid/widget/EditText;

    move-result-object p1

    iget-object p2, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$c;->a:Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;

    invoke-static {p2}, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;->access$100(Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;)Landroid/widget/EditText;

    move-result-object p2

    invoke-virtual {p2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method
