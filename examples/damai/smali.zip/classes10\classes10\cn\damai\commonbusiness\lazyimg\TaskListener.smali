.class public interface abstract Lcn/damai/commonbusiness/lazyimg/TaskListener;
.super Ljava/lang/Object;
.source "Taobao"


# virtual methods
.method public abstract onTaskLoadFinish(Ltb/cj2;)V
.end method
