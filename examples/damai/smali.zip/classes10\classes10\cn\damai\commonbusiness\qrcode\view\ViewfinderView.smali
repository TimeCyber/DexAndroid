.class public final Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;
.super Landroid/view/View;
.source "Taobao"


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon; = null

.field private static final OPAQUE:I = 0xff


# instance fields
.field public ANIMATION_DELAY:J

.field private CORNER_PADDING:I

.field public SPEEN_DISTANCE:I

.field private bitmapCornerBottomLeft:Landroid/graphics/Bitmap;

.field private bitmapCornerBottomRight:Landroid/graphics/Bitmap;

.field private bitmapCornerTopleft:Landroid/graphics/Bitmap;

.field private bitmapCornerTopright:Landroid/graphics/Bitmap;

.field private isFirst:Z

.field private mContext:Landroid/content/Context;

.field private maskColor:I

.field private metrics:Landroid/util/DisplayMetrics;

.field private final paint:Landroid/graphics/Paint;

.field private saomiao:Landroid/graphics/Bitmap;

.field private slideTop:I


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 5

    .line 1
    invoke-direct {p0, p1, p2}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const-wide/16 v0, 0x14

    .line 2
    iput-wide v0, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->ANIMATION_DELAY:J

    const/4 p2, 0x0

    .line 3
    iput-boolean p2, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->isFirst:Z

    .line 4
    iput-object p1, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->mContext:Landroid/content/Context;

    .line 5
    new-instance p2, Landroid/graphics/Paint;

    const/4 v0, 0x1

    invoke-direct {p2, v0}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p2, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->paint:Landroid/graphics/Paint;

    .line 6
    iget-object p2, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->mContext:Landroid/content/Context;

    invoke-virtual {p2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p2

    invoke-virtual {p2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p2

    iput-object p2, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->metrics:Landroid/util/DisplayMetrics;

    const/4 p2, 0x0

    .line 7
    invoke-static {p1, p2}, Ltb/g31;->a(Landroid/content/Context;F)I

    move-result p1

    iput p1, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->CORNER_PADDING:I

    .line 8
    iget-object p1, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->metrics:Landroid/util/DisplayMetrics;

    iget p1, p1, Landroid/util/DisplayMetrics;->density:F

    const/high16 p2, 0x41200000    # 10.0f

    mul-float p1, p1, p2

    float-to-int p1, p1

    iput p1, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->SPEEN_DISTANCE:I

    .line 9
    invoke-direct {p0}, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->initCornerIcon()V

    return-void
.end method

.method private drawRectEdges(Landroid/graphics/Canvas;Landroid/graphics/Rect;)V
    .registers 8

    sget-object v0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "7"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x2

    if-eqz v2, :cond_1a

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    const/4 v4, 0x1

    aput-object p1, v2, v4

    aput-object p2, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1a
    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->paint:Landroid/graphics/Paint;

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->paint:Landroid/graphics/Paint;

    const/16 v1, 0xff

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->bitmapCornerTopleft:Landroid/graphics/Bitmap;

    iget v1, p2, Landroid/graphics/Rect;->left:I

    iget v2, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->CORNER_PADDING:I

    add-int/2addr v1, v2

    int-to-float v1, v1

    iget v2, p2, Landroid/graphics/Rect;->top:I

    int-to-float v2, v2

    iget-object v4, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1, v2, v4}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->bitmapCornerTopright:Landroid/graphics/Bitmap;

    iget v1, p2, Landroid/graphics/Rect;->right:I

    iget v2, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->CORNER_PADDING:I

    sub-int/2addr v1, v2

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v2

    sub-int/2addr v1, v2

    int-to-float v1, v1

    iget v2, p2, Landroid/graphics/Rect;->top:I

    int-to-float v2, v2

    iget-object v4, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1, v2, v4}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->bitmapCornerBottomLeft:Landroid/graphics/Bitmap;

    iget v1, p2, Landroid/graphics/Rect;->left:I

    iget v2, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->CORNER_PADDING:I

    add-int/2addr v1, v2

    int-to-float v1, v1

    iget v4, p2, Landroid/graphics/Rect;->bottom:I

    sub-int/2addr v4, v2

    .line 6
    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v2

    sub-int/2addr v4, v2

    add-int/2addr v4, v3

    int-to-float v2, v4

    iget-object v4, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->paint:Landroid/graphics/Paint;

    .line 7
    invoke-virtual {p1, v0, v1, v2, v4}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 8
    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->bitmapCornerBottomRight:Landroid/graphics/Bitmap;

    iget v1, p2, Landroid/graphics/Rect;->right:I

    iget v2, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->CORNER_PADDING:I

    sub-int/2addr v1, v2

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v2

    sub-int/2addr v1, v2

    int-to-float v1, v1

    iget p2, p2, Landroid/graphics/Rect;->bottom:I

    iget v2, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->CORNER_PADDING:I

    sub-int/2addr p2, v2

    iget-object v2, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->bitmapCornerBottomRight:Landroid/graphics/Bitmap;

    .line 9
    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v2

    sub-int/2addr p2, v2

    add-int/2addr p2, v3

    int-to-float p2, p2

    iget-object v2, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->paint:Landroid/graphics/Paint;

    .line 10
    invoke-virtual {p1, v0, v1, p2, v2}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    return-void
.end method

.method private drawScanningLine(Landroid/graphics/Canvas;Landroid/graphics/Rect;)V
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "8"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1a

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1a
    iget v0, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->slideTop:I

    iget v1, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->SPEEN_DISTANCE:I

    add-int/2addr v0, v1

    iput v0, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->slideTop:I

    .line 2
    iget v1, p2, Landroid/graphics/Rect;->bottom:I

    if-lt v0, v1, :cond_29

    .line 3
    iget v0, p2, Landroid/graphics/Rect;->top:I

    iput v0, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->slideTop:I

    .line 4
    :cond_29
    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    .line 5
    new-instance v1, Landroid/graphics/Rect;

    invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V

    .line 6
    iget v2, p2, Landroid/graphics/Rect;->left:I

    int-to-float v4, v2

    iput v4, v0, Landroid/graphics/RectF;->left:F

    .line 7
    iget v4, p2, Landroid/graphics/Rect;->right:I

    int-to-float v5, v4

    iput v5, v0, Landroid/graphics/RectF;->right:F

    .line 8
    iget p2, p2, Landroid/graphics/Rect;->top:I

    int-to-float p2, p2

    iput p2, v0, Landroid/graphics/RectF;->top:F

    .line 9
    iget p2, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->slideTop:I

    int-to-float p2, p2

    iput p2, v0, Landroid/graphics/RectF;->bottom:F

    .line 10
    iput v2, v1, Landroid/graphics/Rect;->left:I

    .line 11
    iput v4, v1, Landroid/graphics/Rect;->right:I

    .line 12
    iget-object p2, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->saomiao:Landroid/graphics/Bitmap;

    invoke-virtual {p2}, Landroid/graphics/Bitmap;->getHeight()I

    move-result p2

    int-to-float p2, p2

    invoke-virtual {v0}, Landroid/graphics/RectF;->height()F

    move-result v2

    sub-float/2addr p2, v2

    float-to-int p2, p2

    iput p2, v1, Landroid/graphics/Rect;->top:I

    .line 13
    iget-object p2, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->saomiao:Landroid/graphics/Bitmap;

    invoke-virtual {p2}, Landroid/graphics/Bitmap;->getHeight()I

    move-result p2

    iput p2, v1, Landroid/graphics/Rect;->bottom:I

    .line 14
    iget p2, v1, Landroid/graphics/Rect;->top:I

    if-gez p2, :cond_72

    .line 15
    iput v3, v1, Landroid/graphics/Rect;->top:I

    .line 16
    iget p2, v0, Landroid/graphics/RectF;->bottom:F

    invoke-static {v1}, Lcom/alibaba/wireless/security/aopsdk/replace/android/graphics/Rect;->height(Landroid/graphics/Rect;)I

    move-result v1

    int-to-float v1, v1

    sub-float/2addr p2, v1

    iput p2, v0, Landroid/graphics/RectF;->top:F

    .line 17
    :cond_72
    iget-object p2, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->saomiao:Landroid/graphics/Bitmap;

    const/4 v1, 0x0

    iget-object v2, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, p2, v1, v0, v2}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    return-void
.end method

.method private getScreenSize()Landroid/graphics/Point;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/graphics/Point;

    return-object v0

    .line 1
    :cond_17
    new-instance v0, Landroid/graphics/Point;

    iget-object v1, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->metrics:Landroid/util/DisplayMetrics;

    invoke-static {v1}, Lcom/alibaba/wireless/security/aopsdk/replace/android/util/DisplayMetrics;->getwidthPixels(Landroid/util/DisplayMetrics;)I

    move-result v2

    invoke-static {v1}, Lcom/alibaba/wireless/security/aopsdk/replace/android/util/DisplayMetrics;->getheightPixels(Landroid/util/DisplayMetrics;)I

    move-result v1

    invoke-direct {v0, v2, v1}, Landroid/graphics/Point;-><init>(II)V

    return-object v0
.end method

.method private getViewFinderRect()Landroid/graphics/Rect;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/graphics/Rect;

    return-object v0

    .line 1
    :cond_17
    invoke-direct {p0}, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->getScreenSize()Landroid/graphics/Point;

    move-result-object v0

    .line 2
    invoke-virtual {p0}, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->getViewfinderSize()I

    move-result v1

    .line 3
    invoke-virtual {p0}, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->getViewfinderSize()I

    move-result v2

    .line 4
    invoke-static {v0}, Lcom/alibaba/wireless/security/aopsdk/replace/android/graphics/Point;->getx(Landroid/graphics/Point;)I

    move-result v3

    sub-int/2addr v3, v1

    div-int/lit8 v3, v3, 0x2

    .line 5
    invoke-static {v0}, Lcom/alibaba/wireless/security/aopsdk/replace/android/graphics/Point;->gety(Landroid/graphics/Point;)I

    move-result v0

    sub-int/2addr v0, v2

    div-int/lit8 v0, v0, 0x2

    .line 6
    new-instance v4, Landroid/graphics/Rect;

    add-int/2addr v1, v3

    add-int/2addr v2, v0

    invoke-direct {v4, v3, v0, v1, v2}, Landroid/graphics/Rect;-><init>(IIII)V

    return-object v4
.end method

.method private initCornerIcon()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const-string v1, "#60000000"

    .line 2
    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->maskColor:I

    .line 3
    sget v1, Lcn/damai/commonbusiness/R$drawable;->qrcode_corner_left_top:I

    invoke-static {v0, v1}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v1

    iput-object v1, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->bitmapCornerTopleft:Landroid/graphics/Bitmap;

    .line 4
    sget v1, Lcn/damai/commonbusiness/R$drawable;->qrcode_corner_right_top:I

    invoke-static {v0, v1}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v1

    iput-object v1, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->bitmapCornerTopright:Landroid/graphics/Bitmap;

    .line 5
    sget v1, Lcn/damai/commonbusiness/R$drawable;->qrcode_corner_left_bottom:I

    invoke-static {v0, v1}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v1

    iput-object v1, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->bitmapCornerBottomLeft:Landroid/graphics/Bitmap;

    .line 6
    sget v1, Lcn/damai/commonbusiness/R$drawable;->qrcode_corner_right_bottom:I

    invoke-static {v0, v1}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v1

    iput-object v1, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->bitmapCornerBottomRight:Landroid/graphics/Bitmap;

    .line 7
    sget v1, Lcn/damai/commonbusiness/R$drawable;->qrcode_scan_icon:I

    invoke-static {v0, v1}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->saomiao:Landroid/graphics/Bitmap;

    return-void
.end method


# virtual methods
.method public drawViewfinder()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "9"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public getViewfinderSize()I
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->metrics:Landroid/util/DisplayMetrics;

    invoke-static {v0}, Lcom/alibaba/wireless/security/aopsdk/replace/android/util/DisplayMetrics;->getwidthPixels(Landroid/util/DisplayMetrics;)I

    move-result v0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/high16 v2, 0x42a00000    # 80.0f

    invoke-static {v1, v2}, Ltb/g31;->a(Landroid/content/Context;F)I

    move-result v1

    sub-int/2addr v0, v1

    return v0
.end method

.method protected onDetachedFromWindow()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    invoke-super {p0}, Landroid/view/View;->onDetachedFromWindow()V

    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->mContext:Landroid/content/Context;

    .line 3
    iput-boolean v3, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->isFirst:Z

    .line 4
    iput-object v0, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->metrics:Landroid/util/DisplayMetrics;

    return-void
.end method

.method public onDraw(Landroid/graphics/Canvas;)V
    .registers 13

    sget-object v0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v7, 0x1

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    aput-object p1, v2, v7

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    :try_start_17
    invoke-direct {p0}, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->getViewFinderRect()Landroid/graphics/Rect;

    move-result-object v8

    if-nez v8, :cond_1e

    return-void

    .line 2
    :cond_1e
    iget-boolean v0, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->isFirst:Z

    if-nez v0, :cond_28

    .line 3
    iput-boolean v7, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->isFirst:Z

    .line 4
    iget v0, v8, Landroid/graphics/Rect;->top:I

    iput v0, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->slideTop:I

    .line 5
    :cond_28
    invoke-virtual {p1}, Landroid/graphics/Canvas;->getWidth()I

    move-result v0

    .line 6
    invoke-virtual {p1}, Landroid/graphics/Canvas;->getHeight()I

    move-result v9

    .line 7
    iget-object v1, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->paint:Landroid/graphics/Paint;

    iget v2, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->maskColor:I

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v1, 0x0

    const/4 v2, 0x0

    int-to-float v10, v0

    .line 8
    iget v0, v8, Landroid/graphics/Rect;->top:I

    int-to-float v4, v0

    iget-object v5, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->paint:Landroid/graphics/Paint;

    move-object v0, p1

    move v3, v10

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    const/4 v1, 0x0

    .line 9
    iget v0, v8, Landroid/graphics/Rect;->top:I

    int-to-float v2, v0

    iget v0, v8, Landroid/graphics/Rect;->left:I

    int-to-float v3, v0

    iget v0, v8, Landroid/graphics/Rect;->bottom:I

    add-int/2addr v0, v7

    int-to-float v4, v0

    iget-object v5, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->paint:Landroid/graphics/Paint;

    move-object v0, p1

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 10
    iget v0, v8, Landroid/graphics/Rect;->right:I

    add-int/2addr v0, v7

    int-to-float v1, v0

    iget v0, v8, Landroid/graphics/Rect;->top:I

    int-to-float v2, v0

    iget v0, v8, Landroid/graphics/Rect;->bottom:I

    add-int/2addr v0, v7

    int-to-float v4, v0

    iget-object v5, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->paint:Landroid/graphics/Paint;

    move-object v0, p1

    move v3, v10

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    const/4 v1, 0x0

    .line 11
    iget v0, v8, Landroid/graphics/Rect;->bottom:I

    add-int/2addr v0, v7

    int-to-float v2, v0

    int-to-float v4, v9

    iget-object v5, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->paint:Landroid/graphics/Paint;

    move-object v0, p1

    move v3, v10

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 12
    invoke-direct {p0, p1, v8}, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->drawRectEdges(Landroid/graphics/Canvas;Landroid/graphics/Rect;)V

    .line 13
    invoke-direct {p0, p1, v8}, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->drawScanningLine(Landroid/graphics/Canvas;Landroid/graphics/Rect;)V

    .line 14
    iget-wide v1, p0, Lcn/damai/commonbusiness/qrcode/view/ViewfinderView;->ANIMATION_DELAY:J

    iget v3, v8, Landroid/graphics/Rect;->left:I

    iget v4, v8, Landroid/graphics/Rect;->top:I

    iget v5, v8, Landroid/graphics/Rect;->right:I

    iget v6, v8, Landroid/graphics/Rect;->bottom:I

    move-object v0, p0

    invoke-virtual/range {v0 .. v6}, Landroid/view/View;->postInvalidateDelayed(JIIII)V
    :try_end_88
    .catch Ljava/lang/Exception; {:try_start_17 .. :try_end_88} :catch_88

    :catch_88
    return-void
.end method
