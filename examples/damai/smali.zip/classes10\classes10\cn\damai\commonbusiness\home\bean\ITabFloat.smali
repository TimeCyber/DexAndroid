.class public interface abstract Lcn/damai/commonbusiness/home/bean/ITabFloat;
.super Ljava/lang/Object;
.source "Taobao"


# virtual methods
.method public abstract getArtisPic()Ljava/lang/String;
.end method

.method public abstract getContent()Ljava/lang/String;
.end method

.method public abstract getTagPic()Ljava/lang/String;
.end method

.method public abstract makeFindBundleIfNeed()Landroid/os/Bundle;
.end method
