.class public interface abstract Lcn/damai/commonbusiness/city/view/LetterSortBar$OnTouchingLetterChangedListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/city/view/LetterSortBar;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnTouchingLetterChangedListener"
.end annotation


# virtual methods
.method public abstract onClickLetterChanged(Ljava/lang/String;I)V
.end method

.method public abstract onDraggingLetterChanged(Ljava/lang/String;I)V
.end method
