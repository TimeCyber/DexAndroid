.class public interface abstract Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView$OnFinderMoveListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnFinderMoveListener"
.end annotation


# virtual methods
.method public abstract onMove(I)V
.end method
