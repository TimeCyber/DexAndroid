.class public Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$DataCallback;
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic access$000(Landroid/content/Context;Ljava/util/ArrayList;)Ljava/util/ArrayList;
    .registers 2

    .line 1
    invoke-static {p0, p1}, Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel;->splitFolder(Landroid/content/Context;Ljava/util/ArrayList;)Ljava/util/ArrayList;

    move-result-object p0

    return-object p0
.end method

.method public static getExtensionName(Ljava/lang/String;)Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_17

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0

    :cond_17
    if-eqz p0, :cond_35

    .line 1
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_35

    const/16 v0, 0x2e

    .line 2
    invoke-virtual {p0, v0}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v0

    const/4 v1, -0x1

    if-le v0, v1, :cond_35

    .line 3
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    sub-int/2addr v1, v3

    if-ge v0, v1, :cond_35

    add-int/2addr v0, v3

    .line 4
    invoke-virtual {p0, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_35
    const-string p0, ""

    return-object p0
.end method

.method private static getFolder(Ljava/lang/String;Ljava/util/List;)Ltb/ww1;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ltb/ww1;",
            ">;)",
            "Ltb/ww1;"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 p0, 0x1

    aput-object p1, v2, p0

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ltb/ww1;

    return-object p0

    .line 1
    :cond_1a
    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_3a

    .line 2
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    :goto_24
    if-ge v3, v0, :cond_3a

    .line 3
    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltb/ww1;

    .line 4
    invoke-virtual {v1}, Ltb/ww1;->c()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_37

    return-object v1

    :cond_37
    add-int/lit8 v3, v3, 0x1

    goto :goto_24

    .line 5
    :cond_3a
    new-instance v0, Ltb/ww1;

    invoke-direct {v0, p0}, Ltb/ww1;-><init>(Ljava/lang/String;)V

    .line 6
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-object v0
.end method

.method public static getFolderName(Ljava/lang/String;)Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0

    .line 1
    :cond_17
    invoke-static {p0}, Ltb/mw5;->i(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_2c

    .line 2
    sget-object v0, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {p0, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    .line 3
    array-length v0, p0

    const/4 v1, 0x2

    if-lt v0, v1, :cond_2c

    .line 4
    array-length v0, p0

    sub-int/2addr v0, v1

    aget-object p0, p0, v0

    return-object p0

    :cond_2c
    const-string p0, ""

    return-object p0
.end method

.method public static loadImageForSDCard(Landroid/content/Context;Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$DataCallback;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 p0, 0x1

    aput-object p1, v2, p0

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$1;

    invoke-direct {v1, p0, p1}, Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$1;-><init>(Landroid/content/Context;Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel$DataCallback;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 2
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method private static splitFolder(Landroid/content/Context;Ljava/util/ArrayList;)Ljava/util/ArrayList;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/ArrayList<",
            "Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;",
            ">;)",
            "Ljava/util/ArrayList<",
            "Ltb/ww1;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 p0, 0x1

    aput-object p1, v2, p0

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/ArrayList;

    return-object p0

    .line 1
    :cond_1a
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    if-eqz p0, :cond_2c

    .line 2
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    sget v1, Lcn/damai/commonbusiness/R$string;->damai_all_image:I

    invoke-virtual {p0, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    goto :goto_2e

    :cond_2c
    const-string p0, "\u6240\u6709\u7167\u7247"

    .line 3
    :goto_2e
    new-instance v1, Ltb/ww1;

    invoke-direct {v1, p0, p1}, Ltb/ww1;-><init>(Ljava/lang/String;Ljava/util/ArrayList;)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-eqz p1, :cond_68

    .line 4
    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p0

    if-nez p0, :cond_68

    .line 5
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p0

    :goto_42
    if-ge v3, p0, :cond_68

    .line 6
    invoke-virtual {p1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;

    invoke-virtual {v1}, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;->getPath()Ljava/lang/String;

    move-result-object v1

    .line 7
    invoke-static {v1}, Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel;->getFolderName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 8
    invoke-static {v1}, Ltb/mw5;->i(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_65

    .line 9
    invoke-static {v1, v0}, Lcn/damai/commonbusiness/photoselect/imageselected/model/ImageModel;->getFolder(Ljava/lang/String;Ljava/util/List;)Ltb/ww1;

    move-result-object v1

    .line 10
    invoke-virtual {p1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;

    invoke-virtual {v1, v2}, Ltb/ww1;->a(Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;)V

    :cond_65
    add-int/lit8 v3, v3, 0x1

    goto :goto_42

    :cond_68
    return-object v0
.end method
