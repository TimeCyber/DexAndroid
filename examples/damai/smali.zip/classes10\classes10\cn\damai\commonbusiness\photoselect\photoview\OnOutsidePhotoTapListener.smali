.class public interface abstract Lcn/damai/commonbusiness/photoselect/photoview/OnOutsidePhotoTapListener;
.super Ljava/lang/Object;
.source "Taobao"


# virtual methods
.method public abstract onOutsidePhotoTap(Landroid/widget/ImageView;)V
.end method
