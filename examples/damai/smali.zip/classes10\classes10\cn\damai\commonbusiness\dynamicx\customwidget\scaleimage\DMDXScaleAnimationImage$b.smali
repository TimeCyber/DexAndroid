.class public Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$b;
.super Landroid/os/Handler;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private final a:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Landroid/os/Handler;-><init>()V

    .line 2
    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$b;->a:Ljava/lang/ref/WeakReference;

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$b;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-super {p0, p1}, Landroid/os/Handler;->handleMessage(Landroid/os/Message;)V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$b;->a:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;

    .line 3
    iget p1, p1, Landroid/os/Message;->what:I

    # invokes: Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->run(I)V
    invoke-static {v0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->access$800(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;I)V

    return-void
.end method
