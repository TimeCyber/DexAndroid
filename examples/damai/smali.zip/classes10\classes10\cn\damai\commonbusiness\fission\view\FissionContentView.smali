.class public Lcn/damai/commonbusiness/fission/view/FissionContentView;
.super Landroid/widget/RelativeLayout;
.source "Taobao"


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private cb_invite_code:Landroid/widget/TextView;

.field private cb_main_message:Landroid/widget/TextView;

.field private cb_my_invite_content:Landroid/widget/TextView;

.field private cb_sub_message:Landroid/widget/TextView;

.field private cb_user_icon:Lcn/damai/uikit/view/DMAvatar;

.field private cb_user_layout:Landroid/widget/LinearLayout;

.field private cb_user_name:Landroid/widget/TextView;

.field private context:Landroid/content/Context;

.field private fission_content_bg:Landroid/view/View;

.field private fission_image_bg:Landroid/widget/ImageView;

.field private holecardView:Lcn/damai/uikit/view/HoleCardView;

.field private layout:Landroid/widget/RelativeLayout;

.field private partent:Landroid/view/View;

.field private quotation_icon:Lcn/damai/uikit/iconfont/DMIconFontTextView;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, p1, v0}, Lcn/damai/commonbusiness/fission/view/FissionContentView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 4

    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, p1, p2, v0}, Lcn/damai/commonbusiness/fission/view/FissionContentView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4

    .line 3
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 4
    iput-object p1, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->context:Landroid/content/Context;

    .line 5
    invoke-direct {p0}, Lcn/damai/commonbusiness/fission/view/FissionContentView;->initView()V

    return-void
.end method

.method private initView()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->context:Landroid/content/Context;

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    sget v1, Lcn/damai/commonbusiness/R$layout;->fission_content_layout:I

    invoke-virtual {v0, v1, p0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->partent:Landroid/view/View;

    .line 2
    sget v1, Lcn/damai/commonbusiness/R$id;->layout:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/RelativeLayout;

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->layout:Landroid/widget/RelativeLayout;

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->partent:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->holecardView:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcn/damai/uikit/view/HoleCardView;

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->holecardView:Lcn/damai/uikit/view/HoleCardView;

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->partent:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->fission_image_bg:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->fission_image_bg:Landroid/widget/ImageView;

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->partent:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->cb_my_invite_content:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_my_invite_content:Landroid/widget/TextView;

    .line 6
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->partent:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->cb_user_layout:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_user_layout:Landroid/widget/LinearLayout;

    .line 7
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->partent:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->cb_user_icon:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcn/damai/uikit/view/DMAvatar;

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_user_icon:Lcn/damai/uikit/view/DMAvatar;

    .line 8
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->partent:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->cb_user_name:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_user_name:Landroid/widget/TextView;

    .line 9
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->partent:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->quotation_icon:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcn/damai/uikit/iconfont/DMIconFontTextView;

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->quotation_icon:Lcn/damai/uikit/iconfont/DMIconFontTextView;

    .line 10
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_user_icon:Lcn/damai/uikit/view/DMAvatar;

    sget-object v1, Lcom/alibaba/pictures/bricks/view/DMAvatar$DMAvatarSize;->SIZE_40x40:Lcom/alibaba/pictures/bricks/view/DMAvatar$DMAvatarSize;

    invoke-virtual {v0, v1}, Lcom/alibaba/pictures/bricks/view/DMAvatar;->setAvatarSize(Lcom/alibaba/pictures/bricks/view/DMAvatar$DMAvatarSize;)V

    .line 11
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->partent:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->cb_sub_message:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_sub_message:Landroid/widget/TextView;

    .line 12
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->partent:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->cb_main_message:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_main_message:Landroid/widget/TextView;

    .line 13
    iget-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->partent:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->fission_content_bg:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->fission_content_bg:Landroid/view/View;

    return-void
.end method


# virtual methods
.method public update(Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;IIIZ)V
    .registers 12

    sget-object v0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v2, :cond_33

    const/4 v2, 0x6

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v5

    aput-object p1, v2, v4

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x5

    invoke-static {p5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_33
    if-nez p1, :cond_36

    return-void

    .line 1
    :cond_36
    iget-object p4, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->holecardView:Lcn/damai/uikit/view/HoleCardView;

    if-eqz p5, :cond_3b

    goto :goto_3c

    :cond_3b
    const/4 v3, 0x1

    :goto_3c
    invoke-virtual {p4, v3}, Lcn/damai/uikit/view/HoleCardView;->setLayerTypeMode(I)V

    .line 2
    iget-object p4, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->fission_content_bg:Landroid/view/View;

    invoke-virtual {p4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p4

    check-cast p4, Landroid/widget/RelativeLayout$LayoutParams;

    .line 3
    iget-object p5, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->context:Landroid/content/Context;

    const/high16 v0, 0x41a00000    # 20.0f

    invoke-static {p5, v0}, Ltb/g31;->a(Landroid/content/Context;F)I

    move-result p5

    add-int/2addr p3, p5

    iput p3, p4, Landroid/widget/RelativeLayout$LayoutParams;->height:I

    .line 4
    iput p2, p4, Landroid/widget/RelativeLayout$LayoutParams;->width:I

    .line 5
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->fission_content_bg:Landroid/view/View;

    invoke-virtual {p2, p4}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 6
    new-instance p2, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {p2}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 7
    iget p3, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->bgColor:I

    invoke-virtual {p2, p3}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 8
    iget-object p3, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->context:Landroid/content/Context;

    const/high16 p4, 0x41c00000    # 24.0f

    invoke-static {p3, p4}, Ltb/g31;->a(Landroid/content/Context;F)I

    move-result p3

    int-to-float p3, p3

    invoke-virtual {p2, p3}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 9
    sget p3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 p4, 0x10

    if-lt p3, p4, :cond_7b

    .line 10
    iget-object p3, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->fission_content_bg:Landroid/view/View;

    invoke-virtual {p3, p2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_80

    .line 11
    :cond_7b
    iget-object p3, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->fission_content_bg:Landroid/view/View;

    invoke-virtual {p3, p2}, Landroid/view/View;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 12
    :goto_80
    iget-object p2, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->mainMessage:Ljava/lang/String;

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/16 p3, 0x8

    if-nez p2, :cond_97

    .line 13
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_main_message:Landroid/widget/TextView;

    invoke-virtual {p2, v5}, Landroid/widget/TextView;->setVisibility(I)V

    .line 14
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_main_message:Landroid/widget/TextView;

    iget-object p4, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->mainMessage:Ljava/lang/String;

    invoke-virtual {p2, p4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_9c

    .line 15
    :cond_97
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_main_message:Landroid/widget/TextView;

    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 16
    :goto_9c
    iget-object p2, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->subMessage:Ljava/lang/String;

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    if-nez p2, :cond_b1

    .line 17
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_sub_message:Landroid/widget/TextView;

    invoke-virtual {p2, v5}, Landroid/widget/TextView;->setVisibility(I)V

    .line 18
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_sub_message:Landroid/widget/TextView;

    iget-object p4, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->subMessage:Ljava/lang/String;

    invoke-virtual {p2, p4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_b6

    .line 19
    :cond_b1
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_sub_message:Landroid/widget/TextView;

    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 20
    :goto_b6
    iget-object p2, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->bitmap:Landroid/graphics/Bitmap;

    if-eqz p2, :cond_c0

    .line 21
    iget-object p4, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->fission_image_bg:Landroid/widget/ImageView;

    invoke-virtual {p4, p2}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    goto :goto_c7

    .line 22
    :cond_c0
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->fission_image_bg:Landroid/widget/ImageView;

    sget p4, Lcn/damai/commonbusiness/R$drawable;->bricks_uikit_default_image_bg_gradient:I

    invoke-virtual {p2, p4}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 23
    :goto_c7
    iget-object p2, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->chickenSoup:Ljava/lang/String;

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    if-nez p2, :cond_dc

    .line 24
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_my_invite_content:Landroid/widget/TextView;

    invoke-virtual {p2, v5}, Landroid/widget/TextView;->setVisibility(I)V

    .line 25
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_my_invite_content:Landroid/widget/TextView;

    iget-object p4, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->chickenSoup:Ljava/lang/String;

    invoke-virtual {p2, p4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_e1

    .line 26
    :cond_dc
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_my_invite_content:Landroid/widget/TextView;

    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 27
    :goto_e1
    iget-object p2, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->userInfo:Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;

    if-eqz p2, :cond_144

    iget-object p2, p2, Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;->nickname:Ljava/lang/String;

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    if-eqz p2, :cond_f8

    iget-object p2, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->userInfo:Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;

    iget-object p2, p2, Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;->shareCode:Ljava/lang/String;

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    if-eqz p2, :cond_f8

    goto :goto_144

    .line 28
    :cond_f8
    iget-object p2, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->userInfo:Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;

    iget-object p2, p2, Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;->nickname:Ljava/lang/String;

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    if-nez p2, :cond_111

    .line 29
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_user_name:Landroid/widget/TextView;

    invoke-virtual {p2, v5}, Landroid/widget/TextView;->setVisibility(I)V

    .line 30
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_user_name:Landroid/widget/TextView;

    iget-object p4, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->userInfo:Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;

    iget-object p4, p4, Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;->nickname:Ljava/lang/String;

    invoke-virtual {p2, p4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_116

    .line 31
    :cond_111
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_user_name:Landroid/widget/TextView;

    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 32
    :goto_116
    iget-object p2, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->userInfo:Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;

    iget-object p2, p2, Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;->portraitUrl:Ljava/lang/String;

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    if-nez p2, :cond_12a

    .line 33
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_user_icon:Lcn/damai/uikit/view/DMAvatar;

    iget-object p4, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->userInfo:Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;

    iget-object p4, p4, Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;->portraitUrl:Ljava/lang/String;

    invoke-virtual {p2, p4}, Lcom/alibaba/pictures/bricks/view/DMAvatar;->setAvatar(Ljava/lang/String;)V

    goto :goto_131

    .line 34
    :cond_12a
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_user_icon:Lcn/damai/uikit/view/DMAvatar;

    sget p4, Lcn/damai/commonbusiness/R$drawable;->uikit_user_default_icon:I

    invoke-virtual {p2, p4}, Lcom/alibaba/pictures/bricks/view/DMAvatar;->setAvatarPlaceholder(I)V

    .line 35
    :goto_131
    iget-object p2, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_user_icon:Lcn/damai/uikit/view/DMAvatar;

    iget-object p1, p1, Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;->userInfo:Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;

    iget-object p1, p1, Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;->performFilmVipDO:Lcn/damai/commonbusiness/yymember/bean/PerformFilmVipDO;

    if-eqz p1, :cond_13c

    iget-object p1, p1, Lcn/damai/commonbusiness/yymember/bean/PerformFilmVipDO;->memberFlag:Ljava/lang/String;

    goto :goto_140

    :cond_13c
    invoke-static {}, Ltb/w27;->h()Ljava/lang/String;

    move-result-object p1

    :goto_140
    invoke-virtual {p2, v5, p1}, Lcom/alibaba/pictures/bricks/view/DMAvatar;->setYYMemberTagView(ZLjava/lang/String;)V

    goto :goto_15b

    .line 36
    :cond_144
    :goto_144
    iget-object p1, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_user_name:Landroid/widget/TextView;

    const-string p2, "\u5927\u9ea6"

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 37
    iget-object p1, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_user_icon:Lcn/damai/uikit/view/DMAvatar;

    sget p2, Lcn/damai/commonbusiness/R$drawable;->mine_account_default:I

    invoke-virtual {p1, p2}, Lcom/alibaba/pictures/bricks/view/DMAvatar;->setAvatar(I)V

    .line 38
    iget-object p1, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_user_icon:Lcn/damai/uikit/view/DMAvatar;

    invoke-static {}, Ltb/w27;->h()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, v5, p2}, Lcom/alibaba/pictures/bricks/view/DMAvatar;->setYYMemberTagView(ZLjava/lang/String;)V

    .line 39
    :goto_15b
    iget-object p1, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_user_icon:Lcn/damai/uikit/view/DMAvatar;

    invoke-virtual {p1, p3}, Lcom/alibaba/pictures/bricks/view/DMAvatar;->setAvatarCrownVisibility(I)V

    .line 40
    iget-object p1, p0, Lcn/damai/commonbusiness/fission/view/FissionContentView;->cb_user_icon:Lcn/damai/uikit/view/DMAvatar;

    invoke-virtual {p1, p3}, Lcom/alibaba/pictures/bricks/view/DMAvatar;->setAvatarBorderVisibility(I)V

    return-void
.end method
