.class public Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$e;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;->submitRealNameAuth()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$e;->c:Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;

    iput-object p2, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$e;->a:Ljava/lang/String;

    iput-object p3, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$e;->b:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .registers 8

    sget-object v0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$e;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_1e

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    aput-object p1, v2, v4

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1e
    iget-object p1, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$e;->c:Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;->access$200(Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;)Lcn/damai/commonbusiness/contacts/view/RealNameTipView;

    move-result-object p1

    invoke-virtual {p1, v4}, Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->updateCheckState(Z)V

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$e;->c:Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;->access$300(Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;)Landroid/widget/TextView;

    move-result-object p1

    invoke-virtual {p1, v3}, Landroid/widget/TextView;->setClickable(Z)V

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$e;->c:Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;

    iget-object p2, p1, Lcn/damai/common/app/base/BaseActivity;->mPresenter:Lcn/damai/common/app/base/a;

    check-cast p2, Lcn/damai/commonbusiness/faceverify/presenter/IdentityInfoQueryPresenter;

    iget-object v0, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$e;->a:Ljava/lang/String;

    iget-object v1, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$e;->b:Ljava/lang/String;

    invoke-static {p1}, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;->access$400(Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, v0, v1, p1}, Lcn/damai/commonbusiness/faceverify/presenter/IdentityInfoQueryPresenter;->queryIdentityInfo(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method
