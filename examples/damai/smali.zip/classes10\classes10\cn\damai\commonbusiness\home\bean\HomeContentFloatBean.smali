.class public Lcn/damai/commonbusiness/home/bean/HomeContentFloatBean;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/home/bean/HomeContentFloatBean$Data;
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon; = null

.field public static final HIGH_LIGHT_CARD_JSON:Ljava/lang/String; = "high_light_card_json"


# instance fields
.field public data:Ljava/lang/String;

.field public msg:Ljava/lang/String;

.field public pic:Ljava/lang/String;

.field public target:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static getValidBean(Lcom/alibaba/fastjson/JSONObject;)Lcn/damai/commonbusiness/home/bean/TabExtraBean;
    .registers 5
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/home/bean/HomeContentFloatBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcn/damai/commonbusiness/home/bean/TabExtraBean;

    return-object p0

    :cond_17
    if-eqz p0, :cond_4b

    .line 1
    const-class v0, Lcn/damai/commonbusiness/home/bean/HomeContentFloatBean;

    invoke-static {p0, v0}, Ltb/zn2;->d(Lcom/alibaba/fastjson/JSON;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcn/damai/commonbusiness/home/bean/HomeContentFloatBean;

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/home/bean/HomeContentFloatBean;->data:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_4b

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/home/bean/HomeContentFloatBean;->data:Ljava/lang/String;

    const-class v1, Lcn/damai/commonbusiness/home/bean/HomeContentFloatBean$Data;

    invoke-static {v0, v1}, Ltb/zn2;->a(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/home/bean/HomeContentFloatBean$Data;

    if-eqz v0, :cond_4b

    .line 4
    invoke-virtual {v0}, Lcn/damai/commonbusiness/home/bean/HomeContentFloatBean$Data;->isValid()Z

    move-result v1

    if-eqz v1, :cond_4b

    .line 5
    new-instance v1, Lcn/damai/commonbusiness/home/bean/TabExtraBean;

    invoke-direct {v1}, Lcn/damai/commonbusiness/home/bean/TabExtraBean;-><init>()V

    .line 6
    iget-object v2, p0, Lcn/damai/commonbusiness/home/bean/HomeContentFloatBean;->pic:Ljava/lang/String;

    iput-object v2, v1, Lcn/damai/commonbusiness/home/bean/TabExtraBean;->iconUrl:Ljava/lang/String;

    .line 7
    iget-object p0, p0, Lcn/damai/commonbusiness/home/bean/HomeContentFloatBean;->msg:Ljava/lang/String;

    iput-object p0, v1, Lcn/damai/commonbusiness/home/bean/TabExtraBean;->msg:Ljava/lang/String;

    .line 8
    iput-object v0, v1, Lcn/damai/commonbusiness/home/bean/TabExtraBean;->mFind:Lcn/damai/commonbusiness/home/bean/HomeContentFloatBean$Data;

    return-object v1

    :cond_4b
    const/4 p0, 0x0

    return-object p0
.end method
