.class public Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$ActivityInfo;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/fission/bean/FissionInfoBean;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "ActivityInfo"
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x1L


# instance fields
.field public bgImageUrl:Ljava/lang/String;

.field public chickenSoup:Ljava/lang/String;

.field public detailLinkUrl:Ljava/lang/String;

.field public mainTitle:Ljava/lang/String;

.field public ruleUrl:Ljava/lang/String;

.field public seatInfo:Ljava/lang/String;

.field public shareType:Ljava/lang/String;

.field public shareUrl:Ljava/lang/String;

.field public subTitleHighlight:Ljava/lang/String;

.field public subTitlePrefix:Ljava/lang/String;

.field public subTitleSuffix:Ljava/lang/String;

.field public venue:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
