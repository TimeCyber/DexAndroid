.class public interface abstract Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter$OnImageLongClickListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnImageLongClickListener"
.end annotation


# virtual methods
.method public abstract onLongClick(I)V
.end method
