.class public final Lcn/damai/commonbusiness/R$plurals;
.super Ljava/lang/Object;
.source "Taobao"


# static fields
.field public static final mtrl_badge_content_description:I = 0x7f100000


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
