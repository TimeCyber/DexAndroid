.class public Lcn/damai/commonbusiness/calendar/CalendarPopView$1;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/calendar/CalendarPopView;->E()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic this$0:Lcn/damai/commonbusiness/calendar/CalendarPopView;

.field final synthetic val$mDayHeigth:I


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/calendar/CalendarPopView;I)V
    .registers 3

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$1;->this$0:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    iput p2, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$1;->val$mDayHeigth:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/calendar/CalendarPopView$1;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_14

    new-array v2, v4, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$1;->this$0:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {v0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a(Lcn/damai/commonbusiness/calendar/CalendarPopView;)I

    move-result v0

    if-ge v0, v4, :cond_26

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$1;->this$0:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {v0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->b(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Landroidx/recyclerview/widget/RecyclerView;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroidx/recyclerview/widget/RecyclerView;->scrollToPosition(I)V

    goto :goto_36

    .line 3
    :cond_26
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$1;->this$0:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {v0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->b(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Landroidx/recyclerview/widget/RecyclerView;

    move-result-object v0

    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$1;->this$0:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {v1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->a(Lcn/damai/commonbusiness/calendar/CalendarPopView;)I

    move-result v1

    sub-int/2addr v1, v4

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->scrollToPosition(I)V

    .line 4
    :goto_36
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$1;->this$0:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {v0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->b(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Landroidx/recyclerview/widget/RecyclerView;

    move-result-object v0

    new-instance v1, Lcn/damai/commonbusiness/calendar/CalendarPopView$1$1;

    invoke-direct {v1, p0}, Lcn/damai/commonbusiness/calendar/CalendarPopView$1$1;-><init>(Lcn/damai/commonbusiness/calendar/CalendarPopView$1;)V

    const-wide/16 v2, 0x64

    invoke-virtual {v0, v1, v2, v3}, Landroid/view/ViewGroup;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
