.class public final Lcn/damai/commonbusiness/R$layout;
.super Ljava/lang/Object;
.source "Taobao"


# static fields
.field public static final abc_action_bar_title_item:I = 0x7f0d0000

.field public static final abc_action_bar_up_container:I = 0x7f0d0001

.field public static final abc_action_menu_item_layout:I = 0x7f0d0002

.field public static final abc_action_menu_layout:I = 0x7f0d0003

.field public static final abc_action_mode_bar:I = 0x7f0d0004

.field public static final abc_action_mode_close_item_material:I = 0x7f0d0005

.field public static final abc_activity_chooser_view:I = 0x7f0d0006

.field public static final abc_activity_chooser_view_list_item:I = 0x7f0d0007

.field public static final abc_alert_dialog_button_bar_material:I = 0x7f0d0008

.field public static final abc_alert_dialog_material:I = 0x7f0d0009

.field public static final abc_alert_dialog_title_material:I = 0x7f0d000a

.field public static final abc_cascading_menu_item_layout:I = 0x7f0d000b

.field public static final abc_dialog_title_material:I = 0x7f0d000c

.field public static final abc_expanded_menu_layout:I = 0x7f0d000d

.field public static final abc_list_menu_item_checkbox:I = 0x7f0d000e

.field public static final abc_list_menu_item_icon:I = 0x7f0d000f

.field public static final abc_list_menu_item_layout:I = 0x7f0d0010

.field public static final abc_list_menu_item_radio:I = 0x7f0d0011

.field public static final abc_popup_menu_header_item_layout:I = 0x7f0d0012

.field public static final abc_popup_menu_item_layout:I = 0x7f0d0013

.field public static final abc_screen_content_include:I = 0x7f0d0014

.field public static final abc_screen_simple:I = 0x7f0d0015

.field public static final abc_screen_simple_overlay_action_mode:I = 0x7f0d0016

.field public static final abc_screen_toolbar:I = 0x7f0d0017

.field public static final abc_search_dropdown_item_icons_2line:I = 0x7f0d0018

.field public static final abc_search_view:I = 0x7f0d0019

.field public static final abc_select_dialog_material:I = 0x7f0d001a

.field public static final abc_tooltip:I = 0x7f0d001b

.field public static final ability_kit_loading:I = 0x7f0d001c

.field public static final account_album_item:I = 0x7f0d001e

.field public static final action_button_bg_layout:I = 0x7f0d0020

.field public static final activity_aad_contacts:I = 0x7f0d0021

.field public static final activity_album_common:I = 0x7f0d0022

.field public static final activity_area_code_choose:I = 0x7f0d0023

.field public static final activity_artist:I = 0x7f0d0024

.field public static final activity_artist_select:I = 0x7f0d0025

.field public static final activity_base:I = 0x7f0d0026

.field public static final activity_city_select:I = 0x7f0d0028

.field public static final activity_clip_image:I = 0x7f0d0029

.field public static final activity_common_nav_bar:I = 0x7f0d002a

.field public static final activity_component:I = 0x7f0d002d

.field public static final activity_coupon_search_layout:I = 0x7f0d002f

.field public static final activity_delete_preview:I = 0x7f0d0032

.field public static final activity_drama_comming:I = 0x7f0d0036

.field public static final activity_editorphone:I = 0x7f0d0039

.field public static final activity_endisable_service:I = 0x7f0d003a

.field public static final activity_faceverify_realname_auth_layout:I = 0x7f0d003b

.field public static final activity_image_browse_layout:I = 0x7f0d0044

.field public static final activity_image_folder_select:I = 0x7f0d0045

.field public static final activity_image_gallery:I = 0x7f0d0046

.field public static final activity_image_select:I = 0x7f0d0047

.field public static final activity_image_select_confirm:I = 0x7f0d0048

.field public static final activity_new_calendar_v2:I = 0x7f0d0052

.field public static final activity_new_show_calendar:I = 0x7f0d0054

.field public static final activity_off_single_check:I = 0x7f0d0056

.field public static final activity_order_address_modfity:I = 0x7f0d0057

.field public static final activity_oversea_account_login_intercept:I = 0x7f0d005e

.field public static final activity_permission_base:I = 0x7f0d0061

.field public static final activity_pick_picture:I = 0x7f0d0063

.field public static final activity_presale_hint:I = 0x7f0d0066

.field public static final activity_preview:I = 0x7f0d0067

.field public static final activity_rank_square_cmsactivity:I = 0x7f0d006b

.field public static final activity_report:I = 0x7f0d0071

.field public static final activity_scan:I = 0x7f0d0072

.field public static final activity_screen_shot:I = 0x7f0d0075

.field public static final activity_script_murder_coupon_detail:I = 0x7f0d0076

.field public static final activity_scriptkill_layout_root:I = 0x7f0d0078

.field public static final activity_simplified_business:I = 0x7f0d007e

.field public static final activity_sku_ncov:I = 0x7f0d007f

.field public static final activity_so_group_install:I = 0x7f0d0080

.field public static final activity_so_lib_install_layout:I = 0x7f0d0081

.field public static final activity_taomai_h5_container_layout:I = 0x7f0d0083

.field public static final activity_taomai_pha:I = 0x7f0d0084

.field public static final activity_template_preview:I = 0x7f0d0085

.field public static final activity_tetris_default:I = 0x7f0d0086

.field public static final activity_third_auth:I = 0x7f0d008a

.field public static final activity_ticket_remind:I = 0x7f0d008d

.field public static final activity_unified_pay:I = 0x7f0d0092

.field public static final activity_user_extras:I = 0x7f0d0094

.field public static final activity_venue_detail:I = 0x7f0d0097

.field public static final activity_video_image_browse_layout:I = 0x7f0d0098

.field public static final activity_weex:I = 0x7f0d009a

.field public static final activty_show_film_list:I = 0x7f0d009e

.field public static final actor_album_item:I = 0x7f0d009f

.field public static final actor_single_layout:I = 0x7f0d00a0

.field public static final ad_popup_window:I = 0x7f0d00a1

.field public static final adapter_folder:I = 0x7f0d00a2

.field public static final adapter_image:I = 0x7f0d00a3

.field public static final adapter_images_item:I = 0x7f0d00a4

.field public static final add_contacts_double_check_view:I = 0x7f0d00a5

.field public static final add_contacts_info_layout:I = 0x7f0d00a6

.field public static final add_contacts_select_id_type_layout:I = 0x7f0d00a7

.field public static final address_item:I = 0x7f0d00ab

.field public static final address_list_activity:I = 0x7f0d00ac

.field public static final address_list_invalid_prompt_layout:I = 0x7f0d00ad

.field public static final ali_pay_fragment:I = 0x7f0d00ae

.field public static final ali_user_multi_login_fragment:I = 0x7f0d00b0

.field public static final ali_user_qr_code_view:I = 0x7f0d00b1

.field public static final ali_user_register_region:I = 0x7f0d00b2

.field public static final ali_user_scan_fragment:I = 0x7f0d00b3

.field public static final ali_user_sso_guide_activity:I = 0x7f0d00b4

.field public static final ali_user_sso_guide_base_activity:I = 0x7f0d00b5

.field public static final ali_vsdk_activity_verify:I = 0x7f0d00b6

.field public static final ali_vsdk_activity_verify_call:I = 0x7f0d00b7

.field public static final ali_vsdk_activity_verify_nocaptcha:I = 0x7f0d00b8

.field public static final ali_vsdk_activity_verify_sms:I = 0x7f0d00b9

.field public static final ali_vsdk_call_tips:I = 0x7f0d00ba

.field public static final aliuser_activity_container:I = 0x7f0d00bb

.field public static final aliuser_activity_frame_content:I = 0x7f0d00bc

.field public static final aliuser_activity_parent_default_content:I = 0x7f0d00bd

.field public static final aliuser_activity_permission:I = 0x7f0d00be

.field public static final aliuser_activity_transparent_webview:I = 0x7f0d00bf

.field public static final aliuser_activity_webview:I = 0x7f0d00c0

.field public static final aliuser_alert_confirm_dialog:I = 0x7f0d00c1

.field public static final aliuser_bind_mobile_dialog:I = 0x7f0d00c2

.field public static final aliuser_bottom_area:I = 0x7f0d00c3

.field public static final aliuser_cbu_register_dialog:I = 0x7f0d00c4

.field public static final aliuser_check_protocol:I = 0x7f0d00c5

.field public static final aliuser_contact_list_head:I = 0x7f0d00c6

.field public static final aliuser_dialog_layout:I = 0x7f0d00c7

.field public static final aliuser_face_fragment:I = 0x7f0d00c8

.field public static final aliuser_finger_fragment:I = 0x7f0d00c9

.field public static final aliuser_fragment_bottom_menu:I = 0x7f0d00ca

.field public static final aliuser_fragment_email_register:I = 0x7f0d00cb

.field public static final aliuser_fragment_fingerprint_dialog:I = 0x7f0d00cc

.field public static final aliuser_fragment_mobile_login:I = 0x7f0d00cd

.field public static final aliuser_fragment_mobile_register:I = 0x7f0d00ce

.field public static final aliuser_fragment_onekey_login:I = 0x7f0d00cf

.field public static final aliuser_fragment_onekey_register:I = 0x7f0d00d0

.field public static final aliuser_fragment_recommend_login:I = 0x7f0d00d1

.field public static final aliuser_fragment_register_sms_verification:I = 0x7f0d00d2

.field public static final aliuser_fragment_sms_login_verification:I = 0x7f0d00d3

.field public static final aliuser_fragment_two_step_mobile_login:I = 0x7f0d00d4

.field public static final aliuser_fragment_two_step_mobile_register:I = 0x7f0d00d5

.field public static final aliuser_fragment_user_login:I = 0x7f0d00d6

.field public static final aliuser_history:I = 0x7f0d00d7

.field public static final aliuser_letter_popupwindow:I = 0x7f0d00d8

.field public static final aliuser_login_toolbar:I = 0x7f0d00d9

.field public static final aliuser_login_web_trans:I = 0x7f0d00da

.field public static final aliuser_menu_item:I = 0x7f0d00db

.field public static final aliuser_multiaccount_list_item_layout:I = 0x7f0d00dc

.field public static final aliuser_multiaccount_list_layout:I = 0x7f0d00dd

.field public static final aliuser_new_qr_code_part:I = 0x7f0d00de

.field public static final aliuser_progress_dialog:I = 0x7f0d00df

.field public static final aliuser_reg_protocol_dialog:I = 0x7f0d00e0

.field public static final aliuser_region:I = 0x7f0d00e1

.field public static final aliuser_register_region:I = 0x7f0d00e2

.field public static final aliuser_register_region_fragment:I = 0x7f0d00e3

.field public static final aliuser_toolbar:I = 0x7f0d00e4

.field public static final aliuser_transient_notification:I = 0x7f0d00e5

.field public static final aliuser_web_trans:I = 0x7f0d00e6

.field public static final amap_map3d_expand_header:I = 0x7f0d00e7

.field public static final amap_map3d_mapdialog_layout:I = 0x7f0d00e8

.field public static final amap_map3d_offlinemap_child:I = 0x7f0d00e9

.field public static final amap_map3d_offlinemap_group:I = 0x7f0d00ea

.field public static final amap_map3d_service_offlinemap_layout:I = 0x7f0d00eb

.field public static final anchor_index_item:I = 0x7f0d00ec

.field public static final anchor_index_item_pioneer:I = 0x7f0d00ed

.field public static final anchor_index_item_pioneer_film:I = 0x7f0d00ee

.field public static final anchor_lottie_index_item:I = 0x7f0d00f0

.field public static final appstore_dialog:I = 0x7f0d00f1

.field public static final area_code_choose_item:I = 0x7f0d00f2

.field public static final aritst_content_item_layout:I = 0x7f0d00f3

.field public static final aritst_info_more_layout:I = 0x7f0d00f4

.field public static final aritst_pro_item_layout:I = 0x7f0d00f5

.field public static final arrow_down_pop_layout:I = 0x7f0d00f6

.field public static final arrow_up_pop_layout:I = 0x7f0d00f7

.field public static final artist_detail_artist_name_tips:I = 0x7f0d00f8

.field public static final asr_animation_item_view:I = 0x7f0d00f9

.field public static final associate_film_view:I = 0x7f0d00fa

.field public static final attention_view:I = 0x7f0d00fb

.field public static final audience_divide_view:I = 0x7f0d00fc

.field public static final audience_name_textview:I = 0x7f0d00fd

.field public static final audience_typename_idcard_textview:I = 0x7f0d00fe

.field public static final badge_layout_default:I = 0x7f0d0102

.field public static final banner:I = 0x7f0d0103

.field public static final banner_image:I = 0x7f0d0104

.field public static final base_header_view:I = 0x7f0d0105

.field public static final bottom_sheet_menu:I = 0x7f0d010a

.field public static final bottom_sheet_menu_item:I = 0x7f0d010b

.field public static final brand_header_video_layout:I = 0x7f0d010f

.field public static final brciks_anchor_index_item:I = 0x7f0d0113

.field public static final brciks_fragment_notice:I = 0x7f0d0114

.field public static final bricks_activity_search_v2:I = 0x7f0d0115

.field public static final bricks_artist_banner_child_view:I = 0x7f0d0116

.field public static final bricks_artist_big_project_card_view:I = 0x7f0d0117

.field public static final bricks_artist_head_in_tour:I = 0x7f0d0118

.field public static final bricks_artist_horizontal_container:I = 0x7f0d0119

.field public static final bricks_artist_merch_card_item_view:I = 0x7f0d011a

.field public static final bricks_banner_child_view_v2:I = 0x7f0d011b

.field public static final bricks_bottom_action_dialog:I = 0x7f0d011c

.field public static final bricks_bottom_one_action_view:I = 0x7f0d011d

.field public static final bricks_channel_artist_active_task:I = 0x7f0d011e

.field public static final bricks_channel_artist_active_task_item:I = 0x7f0d011f

.field public static final bricks_channel_artist_city:I = 0x7f0d0120

.field public static final bricks_channel_brand_and_venue_item_view:I = 0x7f0d0121

.field public static final bricks_channel_brand_and_venue_layout:I = 0x7f0d0122

.field public static final bricks_channel_brand_project_view:I = 0x7f0d0123

.field public static final bricks_channel_brand_venue_tab:I = 0x7f0d0124

.field public static final bricks_channel_brand_view:I = 0x7f0d0125

.field public static final bricks_channel_float_city_cluster_select:I = 0x7f0d0126

.field public static final bricks_channel_grab_flippercontent:I = 0x7f0d0127

.field public static final bricks_channel_grab_flippercontent_pioneer:I = 0x7f0d0128

.field public static final bricks_channel_grabhot_project_item:I = 0x7f0d0129

.field public static final bricks_channel_grabhot_project_item_pioneer:I = 0x7f0d012a

.field public static final bricks_channel_grabhot_project_switch_item:I = 0x7f0d012b

.field public static final bricks_channel_page_activity_layout:I = 0x7f0d012c

.field public static final bricks_channel_page_bar_text:I = 0x7f0d012d

.field public static final bricks_channel_page_tab_fragment:I = 0x7f0d012e

.field public static final bricks_channel_page_title_bar:I = 0x7f0d012f

.field public static final bricks_channel_project_two_item:I = 0x7f0d0130

.field public static final bricks_channel_venue_view:I = 0x7f0d0131

.field public static final bricks_common_base_icon_button:I = 0x7f0d0132

.field public static final bricks_common_bottom_sheet_container:I = 0x7f0d0133

.field public static final bricks_common_bottom_sheet_dialog_container:I = 0x7f0d0134

.field public static final bricks_common_city_want_lottie_icon_button:I = 0x7f0d0135

.field public static final bricks_common_horizontal_list_round:I = 0x7f0d0136

.field public static final bricks_common_score_star_layoutv:I = 0x7f0d0137

.field public static final bricks_common_scroll_title:I = 0x7f0d0138

.field public static final bricks_common_tags_layout:I = 0x7f0d0139

.field public static final bricks_common_tags_layout_home:I = 0x7f0d013a

.field public static final bricks_component_artist:I = 0x7f0d013b

.field public static final bricks_component_artist_city_view:I = 0x7f0d013c

.field public static final bricks_component_artist_feed_header:I = 0x7f0d013d

.field public static final bricks_component_artist_future:I = 0x7f0d013e

.field public static final bricks_component_artist_header:I = 0x7f0d013f

.field public static final bricks_component_artist_history_ip:I = 0x7f0d0140

.field public static final bricks_component_artist_now_title:I = 0x7f0d0141

.field public static final bricks_component_artist_photo_detail:I = 0x7f0d0142

.field public static final bricks_component_artist_project:I = 0x7f0d0143

.field public static final bricks_component_artist_show_footer:I = 0x7f0d0144

.field public static final bricks_component_artist_tab:I = 0x7f0d0145

.field public static final bricks_component_artist_tab_article:I = 0x7f0d0146

.field public static final bricks_component_artist_tab_item:I = 0x7f0d0147

.field public static final bricks_component_artist_tab_project:I = 0x7f0d0148

.field public static final bricks_component_artist_tab_see_more:I = 0x7f0d0149

.field public static final bricks_component_artist_task_tour:I = 0x7f0d014a

.field public static final bricks_component_artist_tour:I = 0x7f0d014b

.field public static final bricks_component_atmosphere_banner:I = 0x7f0d014c

.field public static final bricks_component_banner_card:I = 0x7f0d014d

.field public static final bricks_component_banner_my_reservation:I = 0x7f0d014e

.field public static final bricks_component_banner_my_reservation_child:I = 0x7f0d014f

.field public static final bricks_component_bottom_corner:I = 0x7f0d0150

.field public static final bricks_component_brand_layout:I = 0x7f0d0151

.field public static final bricks_component_channel_atmosphere:I = 0x7f0d0152

.field public static final bricks_component_common_card_img:I = 0x7f0d0153

.field public static final bricks_component_common_fold_textview:I = 0x7f0d0154

.field public static final bricks_component_common_header_channel:I = 0x7f0d0155

.field public static final bricks_component_common_header_dm:I = 0x7f0d0156

.field public static final bricks_component_common_header_home_dm:I = 0x7f0d0157

.field public static final bricks_component_common_header_search:I = 0x7f0d0159

.field public static final bricks_component_common_header_search_pioneer:I = 0x7f0d015a

.field public static final bricks_component_common_horizontal_dm_round:I = 0x7f0d015b

.field public static final bricks_component_common_horizontal_transparent:I = 0x7f0d015c

.field public static final bricks_component_common_tab_channel_dm:I = 0x7f0d015d

.field public static final bricks_component_common_tab_home_dm:I = 0x7f0d015e

.field public static final bricks_component_dm_list:I = 0x7f0d015f

.field public static final bricks_component_empty:I = 0x7f0d0160

.field public static final bricks_component_feed_note:I = 0x7f0d0161

.field public static final bricks_component_feed_project:I = 0x7f0d0162

.field public static final bricks_component_footer_search:I = 0x7f0d0164

.field public static final bricks_component_gaiax_intercept_touch:I = 0x7f0d0165

.field public static final bricks_component_header_artist:I = 0x7f0d0166

.field public static final bricks_component_home_calendar_card:I = 0x7f0d0167

.field public static final bricks_component_home_favourite_project:I = 0x7f0d0168

.field public static final bricks_component_home_half_price:I = 0x7f0d0169

.field public static final bricks_component_home_marketing_card:I = 0x7f0d016a

.field public static final bricks_component_home_super_brand_week:I = 0x7f0d016b

.field public static final bricks_component_home_welfare_new_container:I = 0x7f0d016c

.field public static final bricks_component_homepage_recommend_common_coupon:I = 0x7f0d016d

.field public static final bricks_component_homepage_waterflow_recmmend_note:I = 0x7f0d016e

.field public static final bricks_component_homepage_waterflow_recommend_ranklist:I = 0x7f0d016f

.field public static final bricks_component_homepage_waterflow_recommend_theme:I = 0x7f0d0170

.field public static final bricks_component_hor_rank_card:I = 0x7f0d0171

.field public static final bricks_component_info_root:I = 0x7f0d0172

.field public static final bricks_component_ip_brand_artist_item:I = 0x7f0d0173

.field public static final bricks_component_ip_brand_info:I = 0x7f0d0174

.field public static final bricks_component_ip_layout:I = 0x7f0d0175

.field public static final bricks_component_item_discover_feed_circle:I = 0x7f0d0176

.field public static final bricks_component_item_discover_feed_project_home_shell:I = 0x7f0d0177

.field public static final bricks_component_item_feed_vote:I = 0x7f0d0178

.field public static final bricks_component_live_artist_wish_mustsee_brand_container:I = 0x7f0d0179

.field public static final bricks_component_live_brand_item:I = 0x7f0d017a

.field public static final bricks_component_live_venue_item:I = 0x7f0d017b

.field public static final bricks_component_loop_banner_artist:I = 0x7f0d017c

.field public static final bricks_component_new_live_remind_statistics:I = 0x7f0d017d

.field public static final bricks_component_new_live_remind_statistics_item:I = 0x7f0d017e

.field public static final bricks_component_one_project_item_view:I = 0x7f0d017f

.field public static final bricks_component_project_filter_layout:I = 0x7f0d0181

.field public static final bricks_component_project_filter_with_tab_layout:I = 0x7f0d0182

.field public static final bricks_component_project_info:I = 0x7f0d0183

.field public static final bricks_component_project_tips:I = 0x7f0d0184

.field public static final bricks_component_richtext_container:I = 0x7f0d0185

.field public static final bricks_component_scenic_album_view:I = 0x7f0d0186

.field public static final bricks_component_script_view_info_header:I = 0x7f0d0188

.field public static final bricks_component_search_query_tip:I = 0x7f0d0189

.field public static final bricks_component_search_result_dispatch_tab:I = 0x7f0d018a

.field public static final bricks_component_search_result_no_more:I = 0x7f0d018b

.field public static final bricks_component_search_script:I = 0x7f0d018c

.field public static final bricks_component_search_script_coupon:I = 0x7f0d018d

.field public static final bricks_component_search_script_shop:I = 0x7f0d018e

.field public static final bricks_component_section_footer:I = 0x7f0d018f

.field public static final bricks_component_timer_layout:I = 0x7f0d0190

.field public static final bricks_component_tour_info:I = 0x7f0d0191

.field public static final bricks_component_tour_project_item_layout:I = 0x7f0d0192

.field public static final bricks_component_venue:I = 0x7f0d0193

.field public static final bricks_component_venue_banner:I = 0x7f0d0194

.field public static final bricks_component_venue_cell_coupon_item:I = 0x7f0d0195

.field public static final bricks_component_venue_cell_layout:I = 0x7f0d0196

.field public static final bricks_component_venue_item_layout:I = 0x7f0d0197

.field public static final bricks_component_venue_ka:I = 0x7f0d0198

.field public static final bricks_component_venue_legend:I = 0x7f0d0199

.field public static final bricks_component_wish_city_view:I = 0x7f0d019e

.field public static final bricks_components_live_aiyi_entrance:I = 0x7f0d019f

.field public static final bricks_components_live_baochang_entrance:I = 0x7f0d01a0

.field public static final bricks_components_live_calendar_entrance:I = 0x7f0d01a1

.field public static final bricks_components_live_groupbuy_entrance:I = 0x7f0d01a2

.field public static final bricks_coupon_info_view:I = 0x7f0d01a3

.field public static final bricks_coupon_one_question_view:I = 0x7f0d01a4

.field public static final bricks_coupon_one_rule_view:I = 0x7f0d01a5

.field public static final bricks_coupon_order_confirm_detail_pop_item_view:I = 0x7f0d01a6

.field public static final bricks_coupon_order_confirm_detail_pop_layout:I = 0x7f0d01a7

.field public static final bricks_coupon_order_confirm_fragment:I = 0x7f0d01a8

.field public static final bricks_coupon_order_confirm_numprice_layout:I = 0x7f0d01a9

.field public static final bricks_coupon_order_detail_fragment:I = 0x7f0d01aa

.field public static final bricks_coupon_order_result_recommend_title:I = 0x7f0d01ab

.field public static final bricks_coupon_pay_result_fragment:I = 0x7f0d01ac

.field public static final bricks_coupon_question_view:I = 0x7f0d01ad

.field public static final bricks_coupon_service_rule_view:I = 0x7f0d01ae

.field public static final bricks_customprogressdialog:I = 0x7f0d01af

.field public static final bricks_damai_dialog:I = 0x7f0d01b0

.field public static final bricks_default_action_bar:I = 0x7f0d01b1

.field public static final bricks_demo_sheet_content:I = 0x7f0d01b2

.field public static final bricks_demo_sheet_img_vh:I = 0x7f0d01b3

.field public static final bricks_dialog_bottom_list:I = 0x7f0d01b4

.field public static final bricks_dm_cert_info_tag_layout:I = 0x7f0d01b5

.field public static final bricks_dm_channel_page_bar_text:I = 0x7f0d01b6

.field public static final bricks_dm_common_price_view:I = 0x7f0d01b7

.field public static final bricks_dm_discount_label:I = 0x7f0d01b8

.field public static final bricks_dm_home_water_flow_tab_layout_item:I = 0x7f0d01b9

.field public static final bricks_dm_homepage_base_guide_bar:I = 0x7f0d01ba

.field public static final bricks_dm_homepage_fragment_v2:I = 0x7f0d01bb

.field public static final bricks_dm_live_water_flow_tab_layout_item:I = 0x7f0d01bc

.field public static final bricks_dm_pioneer_refresh_footer:I = 0x7f0d01bd

.field public static final bricks_dm_pionner_refresh_header:I = 0x7f0d01be

.field public static final bricks_dm_project_broadcast_coming:I = 0x7f0d01bf

.field public static final bricks_dm_project_broadcast_coming_pioneer:I = 0x7f0d01c0

.field public static final bricks_dm_project_broadcast_switch_container:I = 0x7f0d01c1

.field public static final bricks_dm_refresh_footer:I = 0x7f0d01c2

.field public static final bricks_dm_refresh_header:I = 0x7f0d01c3

.field public static final bricks_dna_popup_window:I = 0x7f0d01c4

.field public static final bricks_filter_single_date_hor_btn:I = 0x7f0d01c5

.field public static final bricks_follow_inner_view:I = 0x7f0d01c6

.field public static final bricks_fragment_artist:I = 0x7f0d01c7

.field public static final bricks_fragment_bottom_city_dialog:I = 0x7f0d01c8

.field public static final bricks_fragment_live:I = 0x7f0d01c9

.field public static final bricks_fragment_movie_channel:I = 0x7f0d01ca

.field public static final bricks_fragment_new_calendar_v2:I = 0x7f0d01cb

.field public static final bricks_fragment_new_channel:I = 0x7f0d01cc

.field public static final bricks_fragment_order_script_murder_list_layout:I = 0x7f0d01cd

.field public static final bricks_fragment_order_script_murder_order_layout:I = 0x7f0d01ce

.field public static final bricks_fragment_ranklist:I = 0x7f0d01cf

.field public static final bricks_fragment_script_murder_script_detail:I = 0x7f0d01d0

.field public static final bricks_fragment_search_rank_word:I = 0x7f0d01d1

.field public static final bricks_grabhot_project_item:I = 0x7f0d01d2

.field public static final bricks_group_coupons_layout:I = 0x7f0d01d3

.field public static final bricks_group_notices_layout:I = 0x7f0d01d4

.field public static final bricks_header_search_v2_input:I = 0x7f0d01d5

.field public static final bricks_home_ball_component:I = 0x7f0d01d6

.field public static final bricks_home_ball_component_live:I = 0x7f0d01d7

.field public static final bricks_home_calendar_content:I = 0x7f0d01d8

.field public static final bricks_home_grab_flippercontent:I = 0x7f0d01d9

.field public static final bricks_home_grab_hotrecommend_component:I = 0x7f0d01da

.field public static final bricks_home_horizontal_colorbg:I = 0x7f0d01db

.field public static final bricks_home_horizontal_colorbg_pioneer:I = 0x7f0d01dc

.field public static final bricks_home_horizontal_pager:I = 0x7f0d01dd

.field public static final bricks_home_price_extend_view:I = 0x7f0d01de

.field public static final bricks_home_price_extend_view_v2:I = 0x7f0d01df

.field public static final bricks_home_project_item:I = 0x7f0d01e0

.field public static final bricks_home_project_item_coming_show:I = 0x7f0d01e1

.field public static final bricks_home_snapup_component:I = 0x7f0d01e2

.field public static final bricks_home_welfare_component:I = 0x7f0d01e3

.field public static final bricks_homepage_calendar:I = 0x7f0d01e4

.field public static final bricks_homepage_calendar_v2:I = 0x7f0d01e5

.field public static final bricks_homepage_notice:I = 0x7f0d01e6

.field public static final bricks_homepage_waterflow_recommend_brand:I = 0x7f0d01e7

.field public static final bricks_horizontalraw_component:I = 0x7f0d01e8

.field public static final bricks_ip_wish_add_city:I = 0x7f0d01e9

.field public static final bricks_ip_wish_horizontal_list_container:I = 0x7f0d01ea

.field public static final bricks_ip_wish_main_card:I = 0x7f0d01eb

.field public static final bricks_ip_wish_next_page_view:I = 0x7f0d01ec

.field public static final bricks_ip_wish_one_city:I = 0x7f0d01ed

.field public static final bricks_item_coupons_layout:I = 0x7f0d01ee

.field public static final bricks_item_default_avatar_in_list:I = 0x7f0d01ef

.field public static final bricks_item_discover_feed_note:I = 0x7f0d01f0

.field public static final bricks_item_discover_feed_project_home:I = 0x7f0d01f1

.field public static final bricks_item_discover_feed_project_home_shell:I = 0x7f0d01f2

.field public static final bricks_item_dm_project:I = 0x7f0d01f3

.field public static final bricks_item_dm_project_for_tour_artist:I = 0x7f0d01f4

.field public static final bricks_item_ededed_line:I = 0x7f0d01f5

.field public static final bricks_item_empty_layout:I = 0x7f0d01f6

.field public static final bricks_item_history_arrow_view:I = 0x7f0d01f7

.field public static final bricks_item_home_product_small:I = 0x7f0d01f8

.field public static final bricks_item_layout_egg_show_list:I = 0x7f0d01f9

.field public static final bricks_item_one_history_word:I = 0x7f0d01fa

.field public static final bricks_item_order_tips_layout:I = 0x7f0d01fb

.field public static final bricks_item_rank_feed_project:I = 0x7f0d01fc

.field public static final bricks_item_search_rank_word:I = 0x7f0d01fd

.field public static final bricks_item_simple_title:I = 0x7f0d01fe

.field public static final bricks_item_single_vote_bar:I = 0x7f0d01ff

.field public static final bricks_item_tourism_line:I = 0x7f0d0200

.field public static final bricks_item_vote_layout:I = 0x7f0d0201

.field public static final bricks_layout_center_toast:I = 0x7f0d0202

.field public static final bricks_layout_head_atmosphere:I = 0x7f0d0203

.field public static final bricks_layout_irecyclerview_classic_refresh_header:I = 0x7f0d0204

.field public static final bricks_layout_irecyclerview_load_more_footer:I = 0x7f0d0205

.field public static final bricks_layout_irecyclerview_load_more_footer_error_view:I = 0x7f0d0206

.field public static final bricks_layout_irecyclerview_load_more_footer_loading_view:I = 0x7f0d0207

.field public static final bricks_layout_irecyclerview_load_more_footer_the_end_view:I = 0x7f0d0208

.field public static final bricks_layout_irecyclerview_load_more_footer_view:I = 0x7f0d0209

.field public static final bricks_layout_pop_artist_desc:I = 0x7f0d020a

.field public static final bricks_layout_pop_artist_descheader:I = 0x7f0d020b

.field public static final bricks_layout_search_timer:I = 0x7f0d020d

.field public static final bricks_layout_service_notice_item:I = 0x7f0d020e

.field public static final bricks_layout_service_notice_rl:I = 0x7f0d020f

.field public static final bricks_layoutl_score_cate_poster:I = 0x7f0d0210

.field public static final bricks_layoutl_score_star_poster:I = 0x7f0d0211

.field public static final bricks_live_horizontalraw_component:I = 0x7f0d0212

.field public static final bricks_marquee_label_text_view:I = 0x7f0d0213

.field public static final bricks_merch_item_layout:I = 0x7f0d0214

.field public static final bricks_mo_banner_child_view:I = 0x7f0d0215

.field public static final bricks_nested_banner_item_normal_frame:I = 0x7f0d0216

.field public static final bricks_nested_banner_item_super_frame:I = 0x7f0d0217

.field public static final bricks_nested_banner_layout:I = 0x7f0d0218

.field public static final bricks_new_component_head_atmosphere:I = 0x7f0d0219

.field public static final bricks_new_component_head_atmosphere_v2:I = 0x7f0d021a

.field public static final bricks_new_person_gift_progressbar:I = 0x7f0d021b

.field public static final bricks_new_person_gift_view:I = 0x7f0d021c

.field public static final bricks_new_person_gift_viewstub:I = 0x7f0d021d

.field public static final bricks_one_notice_view:I = 0x7f0d021e

.field public static final bricks_pioneer_home_nested_banner_layout:I = 0x7f0d021f

.field public static final bricks_pioneer_pull_to_refresh_layout:I = 0x7f0d0220

.field public static final bricks_pull_to_refresh_arrow_loading_layout:I = 0x7f0d0221

.field public static final bricks_pull_to_refresh_layout:I = 0x7f0d0222

.field public static final bricks_purchase_instructions:I = 0x7f0d0223

.field public static final bricks_rank_fragment_titlebar:I = 0x7f0d0224

.field public static final bricks_ranklist_header:I = 0x7f0d0225

.field public static final bricks_script_select_fragment:I = 0x7f0d0226

.field public static final bricks_script_select_scrpit:I = 0x7f0d0227

.field public static final bricks_script_select_shop:I = 0x7f0d0228

.field public static final bricks_search_all_info_item:I = 0x7f0d0229

.field public static final bricks_search_all_info_item_more:I = 0x7f0d022a

.field public static final bricks_search_egg_recommend_list:I = 0x7f0d022b

.field public static final bricks_search_list_history:I = 0x7f0d022c

.field public static final bricks_search_list_nodata:I = 0x7f0d022d

.field public static final bricks_search_list_project:I = 0x7f0d022e

.field public static final bricks_search_list_project_wrapper:I = 0x7f0d022f

.field public static final bricks_search_list_word:I = 0x7f0d0230

.field public static final bricks_search_tour_city_arch_item:I = 0x7f0d0231

.field public static final bricks_search_v2_word_suggest_layout:I = 0x7f0d0232

.field public static final bricks_sku_info:I = 0x7f0d0234

.field public static final bricks_splice_head_first:I = 0x7f0d0235

.field public static final bricks_splice_head_second:I = 0x7f0d0236

.field public static final bricks_text_input_dialog:I = 0x7f0d0237

.field public static final bricks_theme_dialog:I = 0x7f0d0238

.field public static final bricks_uikit_category_tag_view:I = 0x7f0d0239

.field public static final bricks_uikit_damai_avatar:I = 0x7f0d023a

.field public static final bricks_uikit_live_room:I = 0x7f0d023b

.field public static final bricks_uikit_load_view:I = 0x7f0d023c

.field public static final bricks_uikit_star_pop_layout:I = 0x7f0d023d

.field public static final bricks_venue_album_view:I = 0x7f0d023e

.field public static final bricks_venue_basic_info_view:I = 0x7f0d023f

.field public static final bricks_venue_item_project_horizontal_item:I = 0x7f0d0240

.field public static final bricks_venue_list_empty_item:I = 0x7f0d0241

.field public static final bui_badge_bubble_left:I = 0x7f0d0242

.field public static final calendar_fragment_headview2:I = 0x7f0d0249

.field public static final calendar_fragment_headview_item:I = 0x7f0d024a

.field public static final calendar_hint_dialog:I = 0x7f0d024c

.field public static final calendar_list_item_sale:I = 0x7f0d024d

.field public static final card_brand_header_common:I = 0x7f0d0250

.field public static final card_brand_ip_item_horizontal:I = 0x7f0d0251

.field public static final card_brand_ip_item_vertical:I = 0x7f0d0252

.field public static final card_brand_quick_report:I = 0x7f0d0253

.field public static final card_brand_quick_report_normal_item:I = 0x7f0d0254

.field public static final category_list_title:I = 0x7f0d0261

.field public static final category_star_jour_layout:I = 0x7f0d026b

.field public static final cert_info_tag_layout:I = 0x7f0d0275

.field public static final cineam_collect_dialog:I = 0x7f0d0278

.field public static final cinema_banner_image:I = 0x7f0d0279

.field public static final cinema_card_container:I = 0x7f0d027a

.field public static final cinema_card_item_view:I = 0x7f0d027b

.field public static final cinema_card_single_view:I = 0x7f0d027c

.field public static final cinema_card_view:I = 0x7f0d027d

.field public static final cinema_favorite_tips:I = 0x7f0d027e

.field public static final cinema_feature_view:I = 0x7f0d027f

.field public static final cinema_filter_cell_pop_container:I = 0x7f0d0280

.field public static final cinema_filter_element_item:I = 0x7f0d0281

.field public static final cinema_filter_flex_list:I = 0x7f0d0282

.field public static final cinema_filter_group_view:I = 0x7f0d0283

.field public static final cinema_filter_item:I = 0x7f0d0284

.field public static final cinema_filter_linear_item:I = 0x7f0d0285

.field public static final cinema_filter_list_item:I = 0x7f0d0286

.field public static final cinema_filter_member_item:I = 0x7f0d0287

.field public static final cinema_filter_pop_container:I = 0x7f0d0288

.field public static final cinema_filter_pop_flexgroup_container:I = 0x7f0d0289

.field public static final cinema_filter_pop_lineargroup_container:I = 0x7f0d028a

.field public static final cinema_filter_sub_type_item:I = 0x7f0d028b

.field public static final cinema_list_blank_item:I = 0x7f0d028c

.field public static final cinema_list_filter_pop_confirm_cancel_layout:I = 0x7f0d028d

.field public static final cinema_list_filter_pop_confirm_cancel_pioneer_layout:I = 0x7f0d028e

.field public static final cinema_list_group:I = 0x7f0d028f

.field public static final cinema_list_load_more_item:I = 0x7f0d0290

.field public static final cinema_list_login_toast_item:I = 0x7f0d0291

.field public static final cinema_list_with_film_recent_best_schedules:I = 0x7f0d0292

.field public static final cinema_list_with_flim_best_schedule_scene:I = 0x7f0d0293

.field public static final cinema_list_with_recomment_cinema_item:I = 0x7f0d0294

.field public static final cinema_locate_tip_item:I = 0x7f0d0295

.field public static final cinema_main_container:I = 0x7f0d0296

.field public static final cinema_show_location_view:I = 0x7f0d0297

.field public static final cinema_sort_filter_tips:I = 0x7f0d0298

.field public static final cinemas_fragment:I = 0x7f0d029a

.field public static final cinemas_tab_fragment:I = 0x7f0d029b

.field public static final circle_card_img_item:I = 0x7f0d029c

.field public static final citypass_experience_item:I = 0x7f0d029d

.field public static final citypass_open_item:I = 0x7f0d029e

.field public static final citypass_overdue_layout:I = 0x7f0d029f

.field public static final combolist_item_emptydata:I = 0x7f0d02a0

.field public static final combolist_item_exception:I = 0x7f0d02a1

.field public static final comlist_item_loading:I = 0x7f0d02a2

.field public static final comment_expandable_textview:I = 0x7f0d02a5

.field public static final comment_report_dialog_view:I = 0x7f0d02a7

.field public static final comment_share_middle_layout:I = 0x7f0d02a8

.field public static final common_activity:I = 0x7f0d02a9

.field public static final common_banner_view:I = 0x7f0d02aa

.field public static final common_black_container:I = 0x7f0d02ab

.field public static final common_bottom_slide_tips:I = 0x7f0d02ac

.field public static final common_business_division_item_layout:I = 0x7f0d02ad

.field public static final common_business_select_division_layout:I = 0x7f0d02ae

.field public static final common_business_select_street_division_layout:I = 0x7f0d02af

.field public static final common_business_want_see_recommend_item_layout:I = 0x7f0d02b0

.field public static final common_business_want_see_recommend_layout:I = 0x7f0d02b1

.field public static final common_business_want_see_recommend_vh_layout:I = 0x7f0d02b2

.field public static final common_calendar_day_view:I = 0x7f0d02b3

.field public static final common_calendar_pop:I = 0x7f0d02b4

.field public static final common_calendar_pop_item:I = 0x7f0d02b5

.field public static final common_choose_header_view:I = 0x7f0d02b6

.field public static final common_cinemas_login:I = 0x7f0d02b7

.field public static final common_close_tips:I = 0x7f0d02b8

.field public static final common_combo_lottie_button:I = 0x7f0d02b9

.field public static final common_combobutton:I = 0x7f0d02ba

.field public static final common_container:I = 0x7f0d02bb

.field public static final common_count_down_flash_layout:I = 0x7f0d02bc

.field public static final common_coupon_exchange_item:I = 0x7f0d02bd

.field public static final common_coupon_luck_item:I = 0x7f0d02be

.field public static final common_coupon_not_use_item:I = 0x7f0d02bf

.field public static final common_coupon_view:I = 0x7f0d02c0

.field public static final common_detail_extend_text:I = 0x7f0d02c1

.field public static final common_dialog:I = 0x7f0d02c2

.field public static final common_expandable_textview:I = 0x7f0d02c3

.field public static final common_expandable_textview2:I = 0x7f0d02c4

.field public static final common_expandable_textview2v2:I = 0x7f0d02c5

.field public static final common_expandable_tips_view:I = 0x7f0d02c6

.field public static final common_film_container:I = 0x7f0d02c7

.field public static final common_film_container_v2:I = 0x7f0d02c8

.field public static final common_fourdate:I = 0x7f0d02cb

.field public static final common_fragment_layout_loading:I = 0x7f0d02cc

.field public static final common_fragment_layout_loading_webp:I = 0x7f0d02cd

.field public static final common_fragment_layout_state_error:I = 0x7f0d02ce

.field public static final common_fragment_layout_state_no_data:I = 0x7f0d02cf

.field public static final common_fragment_layout_state_no_network:I = 0x7f0d02d0

.field public static final common_input_dialog:I = 0x7f0d02d1

.field public static final common_login_bottom_view:I = 0x7f0d02d2

.field public static final common_magic_tag_container:I = 0x7f0d02d3

.field public static final common_module_title:I = 0x7f0d02d4

.field public static final common_order_area_sale_presale_item:I = 0x7f0d02d5

.field public static final common_overlay_scrollview_layout:I = 0x7f0d02d6

.field public static final common_pop_calendar_week:I = 0x7f0d02d7

.field public static final common_problem_item:I = 0x7f0d02d8

.field public static final common_rank_item:I = 0x7f0d02d9

.field public static final common_rank_item_v2:I = 0x7f0d02da

.field public static final common_recyclerview_layout:I = 0x7f0d02db

.field public static final common_reply_content_container:I = 0x7f0d02dc

.field public static final common_schedule_dateoff_view:I = 0x7f0d02dd

.field public static final common_schedule_pre_schedule_view:I = 0x7f0d02de

.field public static final common_score_star_dx:I = 0x7f0d02df

.field public static final common_score_star_layout:I = 0x7f0d02e0

.field public static final common_score_star_layoutv:I = 0x7f0d02e1

.field public static final common_scroll_title:I = 0x7f0d02e2

.field public static final common_search_bar:I = 0x7f0d02e3

.field public static final common_search_result_film_card_item_cms:I = 0x7f0d02e4

.field public static final common_search_result_film_item:I = 0x7f0d02e5

.field public static final common_shopdetail_top_banner:I = 0x7f0d02e6

.field public static final common_simple_tableview:I = 0x7f0d02e7

.field public static final common_tab_view:I = 0x7f0d02e8

.field public static final common_tags_layout:I = 0x7f0d02e9

.field public static final common_ticklet_toast_layout:I = 0x7f0d02eb

.field public static final common_tips_ratingbar:I = 0x7f0d02ec

.field public static final common_tips_view:I = 0x7f0d02ed

.field public static final common_title_mark_view:I = 0x7f0d02ee

.field public static final common_toast_image_text_dialog:I = 0x7f0d02ef

.field public static final common_toast_text_dialog:I = 0x7f0d02f0

.field public static final common_toolbar_activity:I = 0x7f0d02f1

.field public static final common_used_phone_item:I = 0x7f0d02f2

.field public static final common_user_icon_layout:I = 0x7f0d02f3

.field public static final common_view_icon_text:I = 0x7f0d02f4

.field public static final common_viewpager:I = 0x7f0d02f5

.field public static final common_warning_tips:I = 0x7f0d02f6

.field public static final common_widget_user_nick:I = 0x7f0d02f7

.field public static final common_widget_user_nick2_v2:I = 0x7f0d02f9

.field public static final commonbusiness_activity_add_modify_address:I = 0x7f0d02fa

.field public static final commonbusiness_fission_layout:I = 0x7f0d02fb

.field public static final commonbusiness_fission_share_layout:I = 0x7f0d02fc

.field public static final commonbusiness_fission_upgrade_large_view:I = 0x7f0d02fd

.field public static final commonbusiness_fission_upgrade_layout:I = 0x7f0d02fe

.field public static final commonbusiness_member_auth_pop_layout:I = 0x7f0d02ff

.field public static final commonbusiness_member_auth_pop_view:I = 0x7f0d0300

.field public static final commonbusiness_member_auth_protocol_line:I = 0x7f0d0301

.field public static final commonbusiness_title_layout:I = 0x7f0d0302

.field public static final commonbusinesss_hot_item:I = 0x7f0d0303

.field public static final commonbusinesss_image_item:I = 0x7f0d0304

.field public static final commonbusinesss_sales_item:I = 0x7f0d0305

.field public static final component_artist_benefit_card:I = 0x7f0d0340

.field public static final component_artist_benefit_card_single:I = 0x7f0d0341

.field public static final component_artist_benefit_switch_layout:I = 0x7f0d0342

.field public static final component_artist_more_list_more:I = 0x7f0d0343

.field public static final component_artist_sticky_tab:I = 0x7f0d0344

.field public static final component_bottom_corner:I = 0x7f0d0345

.field public static final component_bricks_artist_box_office:I = 0x7f0d0346

.field public static final component_bricks_artist_box_office_container:I = 0x7f0d0347

.field public static final component_bricks_artist_history_works_container:I = 0x7f0d0348

.field public static final component_bricks_artist_history_works_h:I = 0x7f0d0349

.field public static final component_bricks_artist_history_works_loading:I = 0x7f0d034a

.field public static final component_bricks_artist_history_works_v:I = 0x7f0d034b

.field public static final component_bricks_preview_video:I = 0x7f0d034c

.field public static final component_channel_benefit_card:I = 0x7f0d034d

.field public static final component_channel_benefit_single_card:I = 0x7f0d034e

.field public static final component_channel_divider_layout:I = 0x7f0d034f

.field public static final component_channel_venue_horizontal_round:I = 0x7f0d0352

.field public static final component_common_banner:I = 0x7f0d0353

.field public static final component_common_card_img:I = 0x7f0d0354

.field public static final component_common_coming_show_horizontal_list:I = 0x7f0d0355

.field public static final component_common_empty:I = 0x7f0d0356

.field public static final component_common_flextab:I = 0x7f0d0357

.field public static final component_common_footer:I = 0x7f0d0358

.field public static final component_common_gaiax:I = 0x7f0d0359

.field public static final component_common_grid:I = 0x7f0d035a

.field public static final component_common_grid_channel_nav:I = 0x7f0d035b

.field public static final component_common_grid_film_detail:I = 0x7f0d035c

.field public static final component_common_grid_home_nav:I = 0x7f0d035d

.field public static final component_common_header:I = 0x7f0d035e

.field public static final component_common_header_dm:I = 0x7f0d035f

.field public static final component_common_header_movie_round:I = 0x7f0d0360

.field public static final component_common_header_round:I = 0x7f0d0361

.field public static final component_common_horizontal:I = 0x7f0d0362

.field public static final component_common_horizontal_dm:I = 0x7f0d0363

.field public static final component_common_horizontal_dm_round:I = 0x7f0d0364

.field public static final component_common_more:I = 0x7f0d0365

.field public static final component_common_more_movie:I = 0x7f0d0366

.field public static final component_common_pager_grid:I = 0x7f0d0367

.field public static final component_common_snap_horizontal_list:I = 0x7f0d0368

.field public static final component_common_tab:I = 0x7f0d0369

.field public static final component_common_tab_dm:I = 0x7f0d036a

.field public static final component_common_tab_movie:I = 0x7f0d036b

.field public static final component_common_tab_pager:I = 0x7f0d036c

.field public static final component_common_tab_round:I = 0x7f0d036d

.field public static final component_common_title_horizontal_list:I = 0x7f0d036e

.field public static final component_divider:I = 0x7f0d036f

.field public static final component_dm_hot_movie_card:I = 0x7f0d0372

.field public static final component_dm_list:I = 0x7f0d0373

.field public static final component_empty:I = 0x7f0d0374

.field public static final component_feed_note:I = 0x7f0d0375

.field public static final component_feed_project:I = 0x7f0d0376

.field public static final component_film_danmaku_wall:I = 0x7f0d0377

.field public static final component_film_detail_component_bottom_corner:I = 0x7f0d0378

.field public static final component_film_detail_group_booking:I = 0x7f0d0379

.field public static final component_film_detail_horizontal_list:I = 0x7f0d037a

.field public static final component_film_detail_page_top_corner:I = 0x7f0d037b

.field public static final component_film_detail_photo_list:I = 0x7f0d037c

.field public static final component_film_detail_souvenir_ticket:I = 0x7f0d037e

.field public static final component_film_detail_staffinfo:I = 0x7f0d037f

.field public static final component_film_detail_sticky_tab:I = 0x7f0d0380

.field public static final component_film_detail_tab:I = 0x7f0d0381

.field public static final component_film_detail_tips:I = 0x7f0d0382

.field public static final component_film_detail_video_list:I = 0x7f0d0384

.field public static final component_film_list_more:I = 0x7f0d0385

.field public static final component_film_video_list_more:I = 0x7f0d0386

.field public static final component_generic_banner_item:I = 0x7f0d0387

.field public static final component_header_pioneer_titlecolor:I = 0x7f0d0389

.field public static final component_home_calender_pager:I = 0x7f0d038a

.field public static final component_home_hot_grab:I = 0x7f0d038c

.field public static final component_home_page_horizontal_list:I = 0x7f0d038d

.field public static final component_home_recommend_article:I = 0x7f0d0390

.field public static final component_home_recommend_coming_soon:I = 0x7f0d0391

.field public static final component_home_recommend_video:I = 0x7f0d0393

.field public static final component_hor_film_cms_view:I = 0x7f0d039b

.field public static final component_horizontal_tags_view_container:I = 0x7f0d039c

.field public static final component_ip_brand_artist_item:I = 0x7f0d039d

.field public static final component_ip_brand_info:I = 0x7f0d039e

.field public static final component_item_tour_spots_layout:I = 0x7f0d03a2

.field public static final component_loop_banner:I = 0x7f0d03a4

.field public static final component_loop_banner_channel:I = 0x7f0d03a5

.field public static final component_loop_banner_channel_v2:I = 0x7f0d03a6

.field public static final component_loop_banner_v2:I = 0x7f0d03a7

.field public static final component_market_detail_horizental_list:I = 0x7f0d03a8

.field public static final component_no_more:I = 0x7f0d03ab

.field public static final component_one_evaluate_item_view:I = 0x7f0d03ac

.field public static final component_one_project_item_view:I = 0x7f0d03ad

.field public static final component_pay_result_ticket_area:I = 0x7f0d03af

.field public static final component_performance_empty:I = 0x7f0d03b2

.field public static final component_performance_flex_tab:I = 0x7f0d03b3

.field public static final component_pure_tab:I = 0x7f0d03d7

.field public static final component_script_coupon_info_view:I = 0x7f0d03d8

.field public static final component_script_murder_banner:I = 0x7f0d03d9

.field public static final component_script_shop_info_view:I = 0x7f0d03da

.field public static final component_script_shop_tip:I = 0x7f0d03db

.field public static final component_script_tag:I = 0x7f0d03dc

.field public static final component_script_venue_info_view:I = 0x7f0d03dd

.field public static final component_search_artist:I = 0x7f0d03de

.field public static final component_search_cinema:I = 0x7f0d03df

.field public static final component_search_divider:I = 0x7f0d03e0

.field public static final component_search_film:I = 0x7f0d03e1

.field public static final component_search_information:I = 0x7f0d03e2

.field public static final component_search_result_dispatch_tab_container:I = 0x7f0d03e3

.field public static final component_search_result_footer:I = 0x7f0d03e4

.field public static final component_search_result_no_more:I = 0x7f0d03e5

.field public static final component_search_tour_spots_horizontal:I = 0x7f0d03e6

.field public static final component_section_footer:I = 0x7f0d03e7

.field public static final component_section_header:I = 0x7f0d03e8

.field public static final component_staff_photo_horizontal_list:I = 0x7f0d03e9

.field public static final component_sticky_header:I = 0x7f0d03ea

.field public static final component_sticky_header_dm:I = 0x7f0d03eb

.field public static final component_sticky_header_script:I = 0x7f0d03ec

.field public static final component_sticky_header_venue:I = 0x7f0d03ed

.field public static final component_test:I = 0x7f0d03ef

.field public static final component_top_corner:I = 0x7f0d03fa

.field public static final component_tourism_ranking_tab_horizontal:I = 0x7f0d03fb

.field public static final component_tourism_spots_horizontal:I = 0x7f0d03fc

.field public static final component_travel_icon_horizontal:I = 0x7f0d03fd

.field public static final component_venue:I = 0x7f0d03fe

.field public static final component_venue_comment_wrapper:I = 0x7f0d03ff

.field public static final component_venue_project_wrapper:I = 0x7f0d0400

.field public static final component_vertical_tab:I = 0x7f0d0401

.field public static final component_vertical_tab_dm:I = 0x7f0d0402

.field public static final component_vertical_tab_live:I = 0x7f0d0403

.field public static final component_zoom_banner:I = 0x7f0d0404

.field public static final componet_photos_end_more_info:I = 0x7f0d0405

.field public static final console_body:I = 0x7f0d0406

.field public static final console_choose_log_tag:I = 0x7f0d0407

.field public static final console_drop_down_item:I = 0x7f0d0408

.field public static final console_log:I = 0x7f0d0409

.field public static final console_poplayer_info:I = 0x7f0d040a

.field public static final console_spinner_text:I = 0x7f0d040b

.field public static final console_tools:I = 0x7f0d040c

.field public static final console_window:I = 0x7f0d040d

.field public static final contacts_toast_layout:I = 0x7f0d040e

.field public static final copy_activity_city_select:I = 0x7f0d0412

.field public static final copy_common_calendar_day_view:I = 0x7f0d0413

.field public static final copy_common_calendar_pop:I = 0x7f0d0414

.field public static final copy_common_calendar_pop_item:I = 0x7f0d0415

.field public static final copy_common_fourdate:I = 0x7f0d0416

.field public static final copy_common_pop_calendar_week:I = 0x7f0d0417

.field public static final copy_filter_hor_day_item:I = 0x7f0d0418

.field public static final copy_item_filter_btn_view:I = 0x7f0d0419

.field public static final copy_item_filter_category_float_new:I = 0x7f0d041a

.field public static final copy_item_filter_category_new_main:I = 0x7f0d041b

.field public static final copy_item_filter_category_new_sub:I = 0x7f0d041c

.field public static final copy_item_filter_fast_btn:I = 0x7f0d041d

.field public static final copy_item_filter_filter_float:I = 0x7f0d041e

.field public static final copy_item_filter_one_filter_container:I = 0x7f0d041f

.field public static final copy_item_filter_one_filter_item:I = 0x7f0d0420

.field public static final copy_item_filter_reset_and_confirm_layout:I = 0x7f0d0421

.field public static final copy_item_filter_sort_float:I = 0x7f0d0422

.field public static final copy_item_filter_sort_float_item:I = 0x7f0d0423

.field public static final copy_item_filter_title_layout:I = 0x7f0d0424

.field public static final copy_item_filter_view_container:I = 0x7f0d0425

.field public static final copy_layout_select_city_group_list:I = 0x7f0d0426

.field public static final copy_layout_select_city_group_list_item:I = 0x7f0d0427

.field public static final copy_layout_select_city_hot_list:I = 0x7f0d0428

.field public static final copy_layout_select_city_hot_list_item:I = 0x7f0d0429

.field public static final copy_layout_select_city_location:I = 0x7f0d042a

.field public static final coupon_detail_top_banner:I = 0x7f0d042c

.field public static final coupon_top_banner_item_view:I = 0x7f0d0431

.field public static final create_contacts_name:I = 0x7f0d0433

.field public static final cube_ptr_classic_default_header:I = 0x7f0d0434

.field public static final cube_ptr_simple_loading:I = 0x7f0d0435

.field public static final custom_dialog:I = 0x7f0d0439

.field public static final custom_dialog_layout:I = 0x7f0d043a

.field public static final custom_service_layout:I = 0x7f0d043b

.field public static final custom_update_dialog:I = 0x7f0d043c

.field public static final customer_item:I = 0x7f0d043d

.field public static final customprogressdialog:I = 0x7f0d043f

.field public static final damai_asr_dialog:I = 0x7f0d0440

.field public static final damai_capture_activity:I = 0x7f0d0441

.field public static final damai_comment_empty_layout:I = 0x7f0d0442

.field public static final damai_dialog:I = 0x7f0d0443

.field public static final damai_gift_dialog:I = 0x7f0d0444

.field public static final damai_pageview_errorview:I = 0x7f0d0445

.field public static final damai_pageview_footer_empty:I = 0x7f0d0446

.field public static final damai_protocol_dialog:I = 0x7f0d0447

.field public static final damai_protocol_dialog_text_item:I = 0x7f0d0448

.field public static final damai_theme_action_layout:I = 0x7f0d044b

.field public static final damai_theme_dialog:I = 0x7f0d044c

.field public static final damai_theme_dialog_v2:I = 0x7f0d044d

.field public static final datepicker_layout_calendar_view:I = 0x7f0d044e

.field public static final datepicker_week_bar:I = 0x7f0d044f

.field public static final datepicker_widget:I = 0x7f0d0450

.field public static final default_header:I = 0x7f0d0452

.field public static final deletable_icon_tag_view:I = 0x7f0d0453

.field public static final delete_customer_alert:I = 0x7f0d0454

.field public static final design_bottom_navigation_item:I = 0x7f0d0455

.field public static final design_bottom_sheet_dialog:I = 0x7f0d0456

.field public static final design_layout_snackbar:I = 0x7f0d0457

.field public static final design_layout_snackbar_include:I = 0x7f0d0458

.field public static final design_layout_tab_icon:I = 0x7f0d0459

.field public static final design_layout_tab_text:I = 0x7f0d045a

.field public static final design_menu_item_action_area:I = 0x7f0d045b

.field public static final design_navigation_item:I = 0x7f0d045c

.field public static final design_navigation_item_header:I = 0x7f0d045d

.field public static final design_navigation_item_separator:I = 0x7f0d045e

.field public static final design_navigation_item_subheader:I = 0x7f0d045f

.field public static final design_navigation_menu:I = 0x7f0d0460

.field public static final design_navigation_menu_item:I = 0x7f0d0461

.field public static final design_text_input_end_icon:I = 0x7f0d0462

.field public static final design_text_input_start_icon:I = 0x7f0d0463

.field public static final dialog_bottom_action_list:I = 0x7f0d0464

.field public static final dialog_bottom_list:I = 0x7f0d0466

.field public static final dialog_card_recharge_pay:I = 0x7f0d0467

.field public static final dialog_item_action:I = 0x7f0d0471

.field public static final dialog_lottery:I = 0x7f0d0475

.field public static final dialog_member_auth_pop:I = 0x7f0d0476

.field public static final dialog_member_black_upgrade:I = 0x7f0d0477

.field public static final dialog_member_guide_pop:I = 0x7f0d0478

.field public static final dialog_member_pop:I = 0x7f0d0479

.field public static final dialog_member_upgrade:I = 0x7f0d047a

.field public static final dialog_modify_personal_info_layout:I = 0x7f0d047b

.field public static final dialog_myfavor_mediaaccount_guide:I = 0x7f0d047c

.field public static final dialog_order_result_cash_back:I = 0x7f0d047f

.field public static final dialog_order_result_happy_coin:I = 0x7f0d0480

.field public static final dialog_password_cilp_data:I = 0x7f0d0481

.field public static final dialog_pioneer_progressdialog:I = 0x7f0d0483

.field public static final dialog_pioneer_progressdialog_gray:I = 0x7f0d0484

.field public static final dialog_pionner_real_name_auth:I = 0x7f0d0486

.field public static final dialog_pionner_real_name_auth_success:I = 0x7f0d0489

.field public static final dialog_pionner_real_name_authing:I = 0x7f0d048a

.field public static final dialog_purchased_ticked_layout:I = 0x7f0d048c

.field public static final dialog_schedule_luck:I = 0x7f0d048e

.field public static final dialog_scratch_view:I = 0x7f0d048f

.field public static final dialog_taobao_bind_and_auth:I = 0x7f0d0490

.field public static final dialog_want_see_pop:I = 0x7f0d0491

.field public static final dialog_want_see_poster_tips:I = 0x7f0d0492

.field public static final dialog_want_see_tips:I = 0x7f0d0493

.field public static final dialog_wheel_picker:I = 0x7f0d0494

.field public static final dialog_yueying_user_info_layout:I = 0x7f0d0495

.field public static final dinamic:I = 0x7f0d0496

.field public static final discount_popupwindow_view:I = 0x7f0d0497

.field public static final divider_item:I = 0x7f0d04a0

.field public static final dm_ali_user_sso_guide_activity:I = 0x7f0d04a1

.field public static final dm_aliuser_fragment_mobile_login:I = 0x7f0d04a2

.field public static final dm_aliuser_fragment_mobile_register:I = 0x7f0d04a3

.field public static final dm_aliuser_fragment_user_login:I = 0x7f0d04a4

.field public static final dm_discount_label:I = 0x7f0d04a7

.field public static final dm_header_video_item:I = 0x7f0d04aa

.field public static final dm_header_video_item_single:I = 0x7f0d04ab

.field public static final dm_pioneer_homepage_tile_mini_type_calendar:I = 0x7f0d04b7

.field public static final dm_pioneer_homepage_tile_mini_type_coupon:I = 0x7f0d04b8

.field public static final dm_pioneer_homepage_tile_mini_type_ranking:I = 0x7f0d04b9

.field public static final dm_pioneer_homepage_tile_type_calendar:I = 0x7f0d04ba

.field public static final dm_pioneer_homepage_tile_type_coupon:I = 0x7f0d04bb

.field public static final dm_pioneer_homepage_tile_type_lottery:I = 0x7f0d04bc

.field public static final dm_pioneer_homepage_tile_type_lottery_with_button:I = 0x7f0d04bd

.field public static final dm_pioneer_homepage_tile_type_ranking:I = 0x7f0d04be

.field public static final dm_purchase_indicator_item:I = 0x7f0d04c2

.field public static final dm_service_notice:I = 0x7f0d04c4

.field public static final dm_user_protocol:I = 0x7f0d04c7

.field public static final dna_popup_window:I = 0x7f0d04c8

.field public static final drama_chennel_fragment:I = 0x7f0d04c9

.field public static final dx_scrollable_load_more_bottom:I = 0x7f0d04ca

.field public static final electronic_item_layout:I = 0x7f0d04cd

.field public static final equity_card_container:I = 0x7f0d04ce

.field public static final equity_card_item:I = 0x7f0d04cf

.field public static final evaluate_grade_card_layout:I = 0x7f0d04d3

.field public static final evaluate_item_bottom_view:I = 0x7f0d04d4

.field public static final evaluate_item_layout:I = 0x7f0d04d5

.field public static final evaluate_item_layout_wrapper:I = 0x7f0d04d8

.field public static final evaluate_label_item_v2:I = 0x7f0d04da

.field public static final evaluate_list_head_layout:I = 0x7f0d04db

.field public static final evaluate_list_head_layout_v2:I = 0x7f0d04dc

.field public static final evaluate_list_layout_v2:I = 0x7f0d04dd

.field public static final evaluate_praise_layout:I = 0x7f0d04de

.field public static final evaluate_project_layout:I = 0x7f0d04df

.field public static final evaluate_score_distribute_reputation:I = 0x7f0d04e0

.field public static final evaluate_title:I = 0x7f0d04e5

.field public static final evaluate_username_vip_layout:I = 0x7f0d04e7

.field public static final exchange_schedule_broadcast_item:I = 0x7f0d04e8

.field public static final exchange_schedule_promotion_item:I = 0x7f0d04e9

.field public static final exchange_schedule_user_right_item:I = 0x7f0d04ea

.field public static final exchange_ticket_choose_tip_item:I = 0x7f0d04eb

.field public static final exchange_ticket_popup_load_more_item_layout:I = 0x7f0d04ec

.field public static final exchange_ticket_popup_text_item_layout:I = 0x7f0d04ed

.field public static final exchange_ticket_popup_title_item_layout:I = 0x7f0d04ee

.field public static final exchange_ticket_popup_top_item_layout:I = 0x7f0d04ef

.field public static final exchange_ticket_popup_window_layout:I = 0x7f0d04f0

.field public static final fast_filter_item:I = 0x7f0d04f2

.field public static final feed_maintenance_item:I = 0x7f0d04f9

.field public static final feed_media_and_praise_layout:I = 0x7f0d04fa

.field public static final feed_relative_video_layout2:I = 0x7f0d04fc

.field public static final festival_open_card_dialog:I = 0x7f0d0500

.field public static final film_comment_rule_tips:I = 0x7f0d0503

.field public static final film_comment_rule_tips_v2:I = 0x7f0d0504

.field public static final film_detail_anchor_tab_layout_item:I = 0x7f0d0505

.field public static final film_detail_film_name_tips:I = 0x7f0d0506

.field public static final film_detail_market_item:I = 0x7f0d0507

.field public static final film_image_player:I = 0x7f0d050c

.field public static final film_image_player_new:I = 0x7f0d050d

.field public static final film_review_activity:I = 0x7f0d050e

.field public static final film_surrounding_item_layout:I = 0x7f0d050f

.field public static final filter_brand_pop_container:I = 0x7f0d0511

.field public static final filter_cinema_pop_container:I = 0x7f0d0512

.field public static final fission_content_layout:I = 0x7f0d0513

.field public static final fission_image_layout:I = 0x7f0d0514

.field public static final fission_upgrade_bitmap_image:I = 0x7f0d0515

.field public static final flash_red_packet_item:I = 0x7f0d0516

.field public static final flex_key_item:I = 0x7f0d0517

.field public static final flex_key_item_68:I = 0x7f0d0518

.field public static final flex_key_view:I = 0x7f0d0519

.field public static final fontsize_spinner_item:I = 0x7f0d051a

.field public static final footer_item:I = 0x7f0d051c

.field public static final fragment_address_list:I = 0x7f0d051d

.field public static final fragment_album_common:I = 0x7f0d051e

.field public static final fragment_album_tag_common:I = 0x7f0d051f

.field public static final fragment_customers:I = 0x7f0d0522

.field public static final fragment_film_pinterest:I = 0x7f0d052a

.field public static final fragment_grab_list:I = 0x7f0d052b

.field public static final fragment_multiple_list:I = 0x7f0d0537

.field public static final fragment_my_want_see:I = 0x7f0d0538

.field public static final fragment_notice_detail_list:I = 0x7f0d053a

.field public static final fragment_notice_detail_list_item:I = 0x7f0d053b

.field public static final fragment_order_result:I = 0x7f0d053c

.field public static final fragment_ordering_new:I = 0x7f0d053d

.field public static final fragment_pinterest:I = 0x7f0d053f

.field public static final fragment_project_sku_bottom:I = 0x7f0d0549

.field public static final fragment_project_sku_date_item:I = 0x7f0d054a

.field public static final fragment_sales_list:I = 0x7f0d0550

.field public static final fragment_sales_order:I = 0x7f0d0551

.field public static final fragment_schedule_page:I = 0x7f0d0554

.field public static final fragment_script_murder_coupon_detail:I = 0x7f0d0556

.field public static final fragment_script_murder_shop_detail:I = 0x7f0d0557

.field public static final fragment_script_murder_venue_detail:I = 0x7f0d0558

.field public static final fragment_select_perform_buy_right_now:I = 0x7f0d055b

.field public static final fragment_sku_ncov:I = 0x7f0d0560

.field public static final fragment_sku_ncov_bottom:I = 0x7f0d0561

.field public static final fragment_sku_ncov_bottom_splice_go_buy:I = 0x7f0d0562

.field public static final fragment_sku_ncov_bottom_splice_type_choice:I = 0x7f0d0563

.field public static final fragment_sku_ncov_date:I = 0x7f0d0564

.field public static final fragment_sku_ncov_perform:I = 0x7f0d0565

.field public static final fragment_sku_ncov_price:I = 0x7f0d0566

.field public static final fragment_sku_ncov_price_bottom_promotion:I = 0x7f0d0567

.field public static final fragment_sku_ncov_promotion:I = 0x7f0d0568

.field public static final fragment_sku_ncov_promotion_item_bottom:I = 0x7f0d0569

.field public static final fragment_sku_ncov_promotion_item_foot:I = 0x7f0d056a

.field public static final fragment_sku_ncov_see_heat:I = 0x7f0d056c

.field public static final fragment_sku_ncov_see_heat_icon:I = 0x7f0d056d

.field public static final fragment_sku_ncov_see_heat_item:I = 0x7f0d056e

.field public static final fragment_sku_ncov_simple_date:I = 0x7f0d056f

.field public static final fragment_sku_ncov_simple_date_item:I = 0x7f0d0570

.field public static final fragment_sku_ncov_title:I = 0x7f0d0571

.field public static final fragment_sku_ncov_top:I = 0x7f0d0572

.field public static final fragment_sku_price_detail_layout:I = 0x7f0d0573

.field public static final fragment_sku_price_detail_step:I = 0x7f0d0574

.field public static final fragment_sku_price_detail_step_item:I = 0x7f0d0575

.field public static final fragment_taomai_h5_container_layout:I = 0x7f0d0579

.field public static final fragment_taomai_h5_container_sys_layout:I = 0x7f0d057a

.field public static final fragment_tetris_default:I = 0x7f0d057b

.field public static final fragment_venue_detail:I = 0x7f0d0583

.field public static final fragment_vip_creadit_exchange_pop_layout:I = 0x7f0d0586

.field public static final fragment_wanna2_see:I = 0x7f0d0587

.field public static final friend_activity:I = 0x7f0d0589

.field public static final fullscreen_qr_code:I = 0x7f0d058b

.field public static final gaiax_fast_preview_activity:I = 0x7f0d058c

.field public static final gaiax_inner_lottie:I = 0x7f0d058d

.field public static final gaiax_inner_lottie_auto_play:I = 0x7f0d058e

.field public static final generic_progress_dialog:I = 0x7f0d058f

.field public static final guide_dialog_title_layout:I = 0x7f0d0598

.field public static final h5_container_titlebar_left_button_item:I = 0x7f0d059a

.field public static final h5_container_titlebar_right_button_item:I = 0x7f0d059b

.field public static final h5_input_dialog:I = 0x7f0d059c

.field public static final h5_share_activity:I = 0x7f0d059d

.field public static final h5_toolbar:I = 0x7f0d059e

.field public static final half_solid_tag_view_layout:I = 0x7f0d059f

.field public static final half_solid_tag_view_layout_v2:I = 0x7f0d05a0

.field public static final happy_coin_dialog_contain:I = 0x7f0d05a1

.field public static final hcomment_hl_flipper_item:I = 0x7f0d05a3

.field public static final header_calendar:I = 0x7f0d05a5

.field public static final header_video:I = 0x7f0d05ba

.field public static final home_default_tab_widget:I = 0x7f0d05c1

.field public static final home_select_seat_new_dialog_item:I = 0x7f0d05c2

.field public static final home_share_container:I = 0x7f0d05c3

.field public static final home_tab_layout:I = 0x7f0d05c4

.field public static final home_tabview_custom:I = 0x7f0d05c5

.field public static final homepage_activity:I = 0x7f0d05c7

.field public static final homepage_anchor_index_item:I = 0x7f0d05c9

.field public static final homepage_announcement:I = 0x7f0d05ca

.field public static final homepage_banner_item:I = 0x7f0d05cb

.field public static final homepage_component_count_down_timer_view:I = 0x7f0d05cc

.field public static final homepage_grab_ticket_item:I = 0x7f0d05cf

.field public static final homepage_grab_ticket_notice:I = 0x7f0d05d0

.field public static final homepage_module_title:I = 0x7f0d05d4

.field public static final homepage_rank:I = 0x7f0d05d7

.field public static final homepage_rank_item:I = 0x7f0d05d8

.field public static final homepage_rank_top:I = 0x7f0d05d9

.field public static final homepage_rank_top_item:I = 0x7f0d05da

.field public static final homepage_recent:I = 0x7f0d05db

.field public static final homepage_recent_list:I = 0x7f0d05dc

.field public static final homepage_star_tour:I = 0x7f0d05de

.field public static final homepage_star_tour_tab_item:I = 0x7f0d05df

.field public static final homepage_to_evaluate_layout:I = 0x7f0d05e4

.field public static final homepage_video:I = 0x7f0d05e5

.field public static final homepage_video_item:I = 0x7f0d05e6

.field public static final homepage_video_item_artist:I = 0x7f0d05e7

.field public static final homepage_video_itemv2:I = 0x7f0d05e8

.field public static final homepage_video_v2:I = 0x7f0d05e9

.field public static final homepage_viewholder_banner:I = 0x7f0d05ea

.field public static final homepage_want_see:I = 0x7f0d05eb

.field public static final homepage_waterflow_title:I = 0x7f0d05f8

.field public static final horizontal_topics_item:I = 0x7f0d05fb

.field public static final hwpush_trans_activity:I = 0x7f0d05fd

.field public static final image_browse_item_layout:I = 0x7f0d0601

.field public static final image_tag_view:I = 0x7f0d0602

.field public static final image_tag_view_radius:I = 0x7f0d0603

.field public static final immersion_common_layout:I = 0x7f0d0604

.field public static final include_abc_pull_list:I = 0x7f0d0605

.field public static final include_movie_videoview_control:I = 0x7f0d0606

.field public static final include_off_single_step:I = 0x7f0d0607

.field public static final include_verify_code:I = 0x7f0d0608

.field public static final include_verify_ticket:I = 0x7f0d0609

.field public static final ip_brand_card_dynnews_flipper_item:I = 0x7f0d0617

.field public static final ip_video_album_item:I = 0x7f0d0618

.field public static final item:I = 0x7f0d061e

.field public static final item_back_btn_right_city_select:I = 0x7f0d061f

.field public static final item_big_vote_layout:I = 0x7f0d0621

.field public static final item_bottom_check_box_ui:I = 0x7f0d0622

.field public static final item_bricks_artist_city_holder:I = 0x7f0d0623

.field public static final item_bricks_artist_city_holder_pioneer:I = 0x7f0d0624

.field public static final item_bricks_artist_city_more_holder:I = 0x7f0d0625

.field public static final item_bricks_artist_city_more_holder_poineer:I = 0x7f0d0626

.field public static final item_bricks_one_shop_tag:I = 0x7f0d0627

.field public static final item_bricks_tour_city_more_holder:I = 0x7f0d0628

.field public static final item_calendar_pop:I = 0x7f0d0629

.field public static final item_card_drama:I = 0x7f0d062a

.field public static final item_card_title_layout:I = 0x7f0d062b

.field public static final item_category_ball_half_layout:I = 0x7f0d062c

.field public static final item_category_ball_icon_layout:I = 0x7f0d062d

.field public static final item_category_ball_icon_switch_layout:I = 0x7f0d062e

.field public static final item_category_ball_quarter_layout:I = 0x7f0d062f

.field public static final item_category_ball_third_layout:I = 0x7f0d0630

.field public static final item_category_tourism_spots_layout:I = 0x7f0d0631

.field public static final item_circle_card:I = 0x7f0d0633

.field public static final item_circle_rank_list:I = 0x7f0d0634

.field public static final item_circle_title:I = 0x7f0d0635

.field public static final item_city_map_mark:I = 0x7f0d0636

.field public static final item_city_mark_filter_city:I = 0x7f0d0637

.field public static final item_city_mark_share:I = 0x7f0d0638

.field public static final item_city_music_festival_brand_prefix:I = 0x7f0d0639

.field public static final item_city_music_festival_brand_tab:I = 0x7f0d063a

.field public static final item_city_music_project_mark:I = 0x7f0d063b

.field public static final item_credit_exchange_audience_view:I = 0x7f0d0641

.field public static final item_credit_exchange_header_view:I = 0x7f0d0642

.field public static final item_credit_exchange_info_view:I = 0x7f0d0643

.field public static final item_daily_mark_poster_list_layout:I = 0x7f0d0644

.field public static final item_default_avatar_in_list:I = 0x7f0d0645

.field public static final item_discover_feed_big_note:I = 0x7f0d064a

.field public static final item_discover_feed_big_note_shell:I = 0x7f0d064b

.field public static final item_discover_feed_big_theme:I = 0x7f0d064c

.field public static final item_discover_feed_circle:I = 0x7f0d064d

.field public static final item_discover_feed_note:I = 0x7f0d064e

.field public static final item_discover_feed_note_pionner:I = 0x7f0d064f

.field public static final item_discover_feed_project:I = 0x7f0d0650

.field public static final item_discover_feed_project_home:I = 0x7f0d0651

.field public static final item_discover_feed_project_home_shell:I = 0x7f0d0652

.field public static final item_discover_feed_theme:I = 0x7f0d0653

.field public static final item_discover_feed_time_line:I = 0x7f0d0654

.field public static final item_discover_head_comment_item:I = 0x7f0d0655

.field public static final item_discover_head_fixed:I = 0x7f0d0656

.field public static final item_discover_head_simple_card:I = 0x7f0d0657

.field public static final item_discover_head_simple_item:I = 0x7f0d0658

.field public static final item_discover_theme_banner:I = 0x7f0d0659

.field public static final item_discover_theme_banner_item:I = 0x7f0d065a

.field public static final item_drama_focus_lottie:I = 0x7f0d065b

.field public static final item_ededed_line:I = 0x7f0d065c

.field public static final item_feed_big_vote:I = 0x7f0d065e

.field public static final item_feed_discuss:I = 0x7f0d065f

.field public static final item_feed_vote:I = 0x7f0d0663

.field public static final item_film_big_card_4_dm_artist:I = 0x7f0d0664

.field public static final item_filmdetail_danmaku_wall_common:I = 0x7f0d0665

.field public static final item_filmdetail_danmaku_wall_creator:I = 0x7f0d0666

.field public static final item_filmdetail_danmaku_wall_mine:I = 0x7f0d0667

.field public static final item_filmdetail_danmaku_wall_mine_dominate:I = 0x7f0d0668

.field public static final item_filmdetail_danmaku_wall_notice:I = 0x7f0d0669

.field public static final item_filter_btn_view:I = 0x7f0d066a

.field public static final item_filter_category_float:I = 0x7f0d066b

.field public static final item_filter_category_float_new:I = 0x7f0d066c

.field public static final item_filter_category_new_main:I = 0x7f0d066d

.field public static final item_filter_category_new_sub:I = 0x7f0d066e

.field public static final item_filter_fast_btn:I = 0x7f0d066f

.field public static final item_filter_filter_float:I = 0x7f0d0670

.field public static final item_filter_main:I = 0x7f0d0671

.field public static final item_filter_one_category_item:I = 0x7f0d0672

.field public static final item_filter_one_filter_container:I = 0x7f0d0673

.field public static final item_filter_one_filter_item:I = 0x7f0d0674

.field public static final item_filter_reset_and_confirm_layout:I = 0x7f0d0675

.field public static final item_filter_sort_float:I = 0x7f0d0676

.field public static final item_filter_tag:I = 0x7f0d0677

.field public static final item_filter_view_container:I = 0x7f0d0678

.field public static final item_home_movie_tab:I = 0x7f0d067f

.field public static final item_hor_project_card_view:I = 0x7f0d0680

.field public static final item_horizontal_circle_layout:I = 0x7f0d0681

.field public static final item_info_shopdetail_order_info:I = 0x7f0d0682

.field public static final item_new_simple_title:I = 0x7f0d068a

.field public static final item_nine_single_item:I = 0x7f0d068b

.field public static final item_one_actor_header_layout:I = 0x7f0d068c

.field public static final item_one_splice_price_layout:I = 0x7f0d068e

.field public static final item_online_title_layout:I = 0x7f0d068f

.field public static final item_order_card:I = 0x7f0d0690

.field public static final item_page_loading_horizontal:I = 0x7f0d0692

.field public static final item_page_loading_vertical:I = 0x7f0d0693

.field public static final item_pioneer_search_tab_item_view_layout:I = 0x7f0d069b

.field public static final item_pop_ordering_member_reduce:I = 0x7f0d06a5

.field public static final item_rank_feed_project:I = 0x7f0d06a8

.field public static final item_rank_select_list:I = 0x7f0d06a9

.field public static final item_search_grey_line:I = 0x7f0d06ac

.field public static final item_search_iconlist_grid_layout:I = 0x7f0d06ad

.field public static final item_share_brand_or_artist:I = 0x7f0d06ba

.field public static final item_simple_circle_pic_ui:I = 0x7f0d06bb

.field public static final item_simple_title:I = 0x7f0d06bc

.field public static final item_single_vote_bar:I = 0x7f0d06bd

.field public static final item_stargrid_layout:I = 0x7f0d06be

.field public static final item_tetris_anchor_floating:I = 0x7f0d06bf

.field public static final item_tetris_anchor_item:I = 0x7f0d06c0

.field public static final item_tetris_discover_feed_head_plugin:I = 0x7f0d06c1

.field public static final item_tetris_drama_by_month:I = 0x7f0d06c2

.field public static final item_tetris_drama_card:I = 0x7f0d06c3

.field public static final item_tetris_drama_card_v2:I = 0x7f0d06c4

.field public static final item_tetris_drama_coming:I = 0x7f0d06c5

.field public static final item_tetris_drama_hor_card:I = 0x7f0d06c6

.field public static final item_tetris_drama_horizontal_list:I = 0x7f0d06c7

.field public static final item_tetris_drama_project_broadcast:I = 0x7f0d06c8

.field public static final item_tetris_drama_worth_2_see:I = 0x7f0d06c9

.field public static final item_tetris_filter_calendar_container:I = 0x7f0d06ca

.field public static final item_tetris_loop_viewpager_banner:I = 0x7f0d06cb

.field public static final item_tetris_loop_viewpager_banner_withtitle:I = 0x7f0d06cc

.field public static final item_tetris_month_tab:I = 0x7f0d06cd

.field public static final item_tetris_music_festival_hot:I = 0x7f0d06ce

.field public static final item_tetris_music_festival_map_layout:I = 0x7f0d06cf

.field public static final item_tetris_online_card:I = 0x7f0d06d0

.field public static final item_tetris_online_pro_layout:I = 0x7f0d06d1

.field public static final item_tetris_poster_card_with_stack_bg:I = 0x7f0d06d2

.field public static final item_tetris_project_broadcast_list:I = 0x7f0d06d3

.field public static final item_tetris_project_filter_layout:I = 0x7f0d06d4

.field public static final item_tetris_project_filter_ui:I = 0x7f0d06d5

.field public static final item_tetris_project_filter_ui_mask:I = 0x7f0d06d6

.field public static final item_tetris_rank_empty_layout:I = 0x7f0d06d7

.field public static final item_tetris_rank_filter_layout:I = 0x7f0d06d8

.field public static final item_tetris_rank_one_sub_filter:I = 0x7f0d06d9

.field public static final item_tetris_rank_select_card:I = 0x7f0d06da

.field public static final item_tetris_vertical_drama_month:I = 0x7f0d06db

.field public static final item_tetris_x_banner_item:I = 0x7f0d06dc

.field public static final item_text_tab:I = 0x7f0d06dd

.field public static final item_theme_project_loop:I = 0x7f0d06df

.field public static final item_theme_rank_list:I = 0x7f0d06e0

.field public static final item_theme_rank_user:I = 0x7f0d06e1

.field public static final item_tourism_ranking_list:I = 0x7f0d06e2

.field public static final item_tourism_ranking_tab_layout:I = 0x7f0d06e3

.field public static final item_tourism_vacation_package_layout:I = 0x7f0d06e4

.field public static final item_tourism_vacation_package_list:I = 0x7f0d06e5

.field public static final item_tpp_loading:I = 0x7f0d06e6

.field public static final item_user_center_empty_item_view:I = 0x7f0d06e7

.field public static final item_user_center_publish_holder:I = 0x7f0d06e8

.field public static final item_user_center_publish_layout:I = 0x7f0d06e9

.field public static final item_vote_layout:I = 0x7f0d06ef

.field public static final item_youku_ad:I = 0x7f0d06f0

.field public static final label_layout:I = 0x7f0d06f2

.field public static final layout_actoralbum_ip:I = 0x7f0d06f5

.field public static final layout_add_contacts_progress:I = 0x7f0d06f6

.field public static final layout_add_contatcs_error_tip:I = 0x7f0d06f7

.field public static final layout_album_common_footer:I = 0x7f0d06f9

.field public static final layout_album_photo_item:I = 0x7f0d06fa

.field public static final layout_appbar:I = 0x7f0d06fb

.field public static final layout_artist_sticky_tab_item:I = 0x7f0d06fc

.field public static final layout_base_share_dialog:I = 0x7f0d06fd

.field public static final layout_bricks_preview_video:I = 0x7f0d0700

.field public static final layout_candidate_refund_dialog:I = 0x7f0d0701

.field public static final layout_category_list_item_discount_label:I = 0x7f0d0702

.field public static final layout_center_toast:I = 0x7f0d0703

.field public static final layout_channel_float_select_group_list:I = 0x7f0d0704

.field public static final layout_channel_float_select_group_list_item:I = 0x7f0d0705

.field public static final layout_channel_tour_tab_item:I = 0x7f0d0706

.field public static final layout_cinema_filter_city:I = 0x7f0d0707

.field public static final layout_cinema_list_buyone_giveone_decorate:I = 0x7f0d0708

.field public static final layout_cinema_list_distance_mall_metro_des:I = 0x7f0d0709

.field public static final layout_cinema_list_favorite_cover:I = 0x7f0d070a

.field public static final layout_cinema_list_presale_tips:I = 0x7f0d070b

.field public static final layout_cinema_list_recomment_tag:I = 0x7f0d070c

.field public static final layout_cinema_list_roll_tip:I = 0x7f0d070d

.field public static final layout_cinema_list_schedules:I = 0x7f0d070e

.field public static final layout_cinema_list_special_schedule:I = 0x7f0d070f

.field public static final layout_cms_state_view:I = 0x7f0d0710

.field public static final layout_cms_state_view_loading:I = 0x7f0d0711

.field public static final layout_combined_image:I = 0x7f0d0715

.field public static final layout_common_account_album:I = 0x7f0d0717

.field public static final layout_common_error_page:I = 0x7f0d0718

.field public static final layout_common_login_view:I = 0x7f0d0719

.field public static final layout_common_redbtn_dialog:I = 0x7f0d071a

.field public static final layout_condition_excel_item:I = 0x7f0d071b

.field public static final layout_conditional_tab_item:I = 0x7f0d071c

.field public static final layout_coupon_common_card:I = 0x7f0d0722

.field public static final layout_coupon_common_card_w:I = 0x7f0d0723

.field public static final layout_day_category_view:I = 0x7f0d0724

.field public static final layout_day_view:I = 0x7f0d0725

.field public static final layout_detail_like_popup:I = 0x7f0d0726

.field public static final layout_empty_page:I = 0x7f0d072c

.field public static final layout_error_page:I = 0x7f0d072f

.field public static final layout_error_text:I = 0x7f0d0730

.field public static final layout_evaluate_excerpt:I = 0x7f0d0731

.field public static final layout_fans_love_rank_list:I = 0x7f0d0732

.field public static final layout_fans_love_rank_list_item:I = 0x7f0d0733

.field public static final layout_film_item_adapter_danmaku_wall:I = 0x7f0d0734

.field public static final layout_flash_red_packet:I = 0x7f0d0735

.field public static final layout_generate_comment_image:I = 0x7f0d0736

.field public static final layout_generate_discount_ticket_image:I = 0x7f0d0737

.field public static final layout_generate_evaluate_image:I = 0x7f0d0738

.field public static final layout_generate_evaluate_image_v2:I = 0x7f0d0739

.field public static final layout_generate_fission_share_image:I = 0x7f0d073a

.field public static final layout_generate_fission_upgrade_share_image:I = 0x7f0d073b

.field public static final layout_generate_live_share_image:I = 0x7f0d073c

.field public static final layout_generate_new_project_image:I = 0x7f0d073d

.field public static final layout_generate_nft_card_image:I = 0x7f0d073e

.field public static final layout_generate_project_image:I = 0x7f0d073f

.field public static final layout_home_marketing_card_item_view_holder:I = 0x7f0d0747

.field public static final layout_home_movie_tabs:I = 0x7f0d0748

.field public static final layout_horizontal_project:I = 0x7f0d0749

.field public static final layout_ip_bottombar:I = 0x7f0d074c

.field public static final layout_ip_bottombar_tip:I = 0x7f0d074d

.field public static final layout_ip_brandcard:I = 0x7f0d074e

.field public static final layout_ip_citytour:I = 0x7f0d074f

.field public static final layout_irecyclerview_classic_refresh_header:I = 0x7f0d0750

.field public static final layout_irecyclerview_load_more_footer:I = 0x7f0d0751

.field public static final layout_irecyclerview_load_more_footer_error_view:I = 0x7f0d0752

.field public static final layout_irecyclerview_load_more_footer_loading_view:I = 0x7f0d0753

.field public static final layout_irecyclerview_load_more_footer_the_end_view:I = 0x7f0d0754

.field public static final layout_irecyclerview_load_more_footer_view:I = 0x7f0d0755

.field public static final layout_live_room:I = 0x7f0d0759

.field public static final layout_login_action_dialog:I = 0x7f0d075a

.field public static final layout_lottie_image:I = 0x7f0d075c

.field public static final layout_mo_tip_with_close_popwindow:I = 0x7f0d076d

.field public static final layout_modify_address_dialog:I = 0x7f0d076e

.field public static final layout_mult_artist:I = 0x7f0d0771

.field public static final layout_popup_ip_scoretip:I = 0x7f0d0789

.field public static final layout_popup_ip_tag:I = 0x7f0d078a

.field public static final layout_popup_ip_tags:I = 0x7f0d078b

.field public static final layout_popup_ip_tour:I = 0x7f0d078c

.field public static final layout_popup_ip_tour_item:I = 0x7f0d078d

.field public static final layout_product_cell:I = 0x7f0d078e

.field public static final layout_product_item:I = 0x7f0d078f

.field public static final layout_product_item_container:I = 0x7f0d0790

.field public static final layout_progress_loading:I = 0x7f0d0791

.field public static final layout_project_ticket_notice:I = 0x7f0d0793

.field public static final layout_queue_view_flipper:I = 0x7f0d0794

.field public static final layout_queue_view_flipper_venue:I = 0x7f0d0795

.field public static final layout_rank_want_see_tip:I = 0x7f0d0797

.field public static final layout_refresh_empty_view:I = 0x7f0d079a

.field public static final layout_search_timer:I = 0x7f0d07ab

.field public static final layout_search_timer_simple:I = 0x7f0d07ac

.field public static final layout_select_artist_group_list:I = 0x7f0d07ad

.field public static final layout_select_artist_group_list_item:I = 0x7f0d07ae

.field public static final layout_select_artist_list_stick_title:I = 0x7f0d07af

.field public static final layout_select_city_group_list:I = 0x7f0d07b0

.field public static final layout_select_city_group_list_item:I = 0x7f0d07b1

.field public static final layout_select_city_hot_list:I = 0x7f0d07b2

.field public static final layout_select_city_hot_list_item:I = 0x7f0d07b3

.field public static final layout_select_city_location:I = 0x7f0d07b4

.field public static final layout_select_float_list_stick_title:I = 0x7f0d07b6

.field public static final layout_service_notice:I = 0x7f0d07b7

.field public static final layout_service_notice_conditional_refund:I = 0x7f0d07b8

.field public static final layout_service_notice_item:I = 0x7f0d07b9

.field public static final layout_service_notice_item_action:I = 0x7f0d07ba

.field public static final layout_service_notice_item_new:I = 0x7f0d07bb

.field public static final layout_service_notice_rl:I = 0x7f0d07bc

.field public static final layout_service_notice_sheet_item:I = 0x7f0d07bd

.field public static final layout_service_notice_title:I = 0x7f0d07be

.field public static final layout_share_delete:I = 0x7f0d07bf

.field public static final layout_share_delete_view:I = 0x7f0d07c0

.field public static final layout_share_edit_view:I = 0x7f0d07c1

.field public static final layout_share_wxmini_image:I = 0x7f0d07c2

.field public static final layout_share_wxmoments_image:I = 0x7f0d07c3

.field public static final layout_shimmer:I = 0x7f0d07c4

.field public static final layout_shimmer_default_item:I = 0x7f0d07c5

.field public static final layout_star_card_tourinfo:I = 0x7f0d07c6

.field public static final layout_star_card_tourinfo_projinfo:I = 0x7f0d07c7

.field public static final layout_star_tour_cityitem:I = 0x7f0d07c8

.field public static final layout_tetris_gap:I = 0x7f0d07ca

.field public static final layout_uikit_common_card:I = 0x7f0d07d9

.field public static final layout_uikit_common_card_w:I = 0x7f0d07da

.field public static final layout_uikit_vip_card:I = 0x7f0d07db

.field public static final layout_uikit_vip_card_w:I = 0x7f0d07dc

.field public static final layout_ultron_sell_desc:I = 0x7f0d07dd

.field public static final layout_videoalbum_ip:I = 0x7f0d07e4

.field public static final layout_videoheader_ip:I = 0x7f0d07e5

.field public static final layout_videoinfo_ip:I = 0x7f0d07e6

.field public static final layout_videoinfo_ip_awardsitem:I = 0x7f0d07e7

.field public static final layout_videoinfo_ip_tag:I = 0x7f0d07e8

.field public static final layout_view_one_key_receive_88vip:I = 0x7f0d07e9

.field public static final layout_vip_switcher:I = 0x7f0d07ec

.field public static final layout_want_see_guide_tips:I = 0x7f0d07ef

.field public static final layout_want_see_poster_tips:I = 0x7f0d07f0

.field public static final layout_want_see_with_gift:I = 0x7f0d07f1

.field public static final layout_wbshare:I = 0x7f0d07f2

.field public static final layoutl_score_cate_poster:I = 0x7f0d07f3

.field public static final layoutl_score_digit_star:I = 0x7f0d07f4

.field public static final layoutl_score_star_digit:I = 0x7f0d07f5

.field public static final layoutl_score_star_poster:I = 0x7f0d07f6

.field public static final like_item:I = 0x7f0d07f7

.field public static final list_item_calendar:I = 0x7f0d07f8

.field public static final list_item_city:I = 0x7f0d07f9

.field public static final list_loading_item:I = 0x7f0d07fb

.field public static final listitem_big_emptydata:I = 0x7f0d07fc

.field public static final listitem_black_loading:I = 0x7f0d07fd

.field public static final listitem_cinema_histry:I = 0x7f0d07fe

.field public static final listitem_emptydata:I = 0x7f0d07ff

.field public static final listitem_exception:I = 0x7f0d0800

.field public static final listitem_smart_video_loading:I = 0x7f0d0801

.field public static final listitem_smart_video_transparent_loading:I = 0x7f0d0802

.field public static final listitem_vertical_loading:I = 0x7f0d0803

.field public static final live_banner_config_item:I = 0x7f0d0806

.field public static final live_banner_layout:I = 0x7f0d0807

.field public static final live_banner_topic_item:I = 0x7f0d0808

.field public static final live_brand_container:I = 0x7f0d0809

.field public static final live_component_common_horizontal:I = 0x7f0d080b

.field public static final live_header_banner_item:I = 0x7f0d0823

.field public static final live_header_layout:I = 0x7f0d0824

.field public static final live_header_layout1:I = 0x7f0d0825

.field public static final live_popwindow_weexlog:I = 0x7f0d0827

.field public static final live_venue_container:I = 0x7f0d082a

.field public static final livehous_atist_layout:I = 0x7f0d082b

.field public static final livehouse_actor_item_layout:I = 0x7f0d082c

.field public static final ll_common_comment_highlight_view:I = 0x7f0d082d

.field public static final ll_dm_tag_view:I = 0x7f0d082e

.field public static final ll_seat_promotion_item:I = 0x7f0d082f

.field public static final loading_dialog:I = 0x7f0d0832

.field public static final loading_state_movie_in_dm:I = 0x7f0d0833

.field public static final loading_view_layout:I = 0x7f0d0834

.field public static final local_search_item:I = 0x7f0d0835

.field public static final mall_subway_group_item:I = 0x7f0d083e

.field public static final mantls_permission_tips_view:I = 0x7f0d083f

.field public static final material_chip_input_combo:I = 0x7f0d0840

.field public static final material_clock_display:I = 0x7f0d0841

.field public static final material_clock_display_divider:I = 0x7f0d0842

.field public static final material_clock_period_toggle:I = 0x7f0d0843

.field public static final material_clock_period_toggle_land:I = 0x7f0d0844

.field public static final material_clockface_textview:I = 0x7f0d0845

.field public static final material_clockface_view:I = 0x7f0d0846

.field public static final material_radial_view_group:I = 0x7f0d0847

.field public static final material_textinput_timepicker:I = 0x7f0d0848

.field public static final material_time_chip:I = 0x7f0d0849

.field public static final material_time_input:I = 0x7f0d084a

.field public static final material_timepicker:I = 0x7f0d084b

.field public static final material_timepicker_dialog:I = 0x7f0d084c

.field public static final material_timepicker_textinput_display:I = 0x7f0d084d

.field public static final mcard_detail_popupwindow:I = 0x7f0d084e

.field public static final mcard_detail_popupwindow_mcard_activity_item:I = 0x7f0d084f

.field public static final mcard_detail_popupwindow_mcard_benefit_item:I = 0x7f0d0850

.field public static final mcard_detail_popupwindow_mcard_item:I = 0x7f0d0851

.field public static final mcard_detail_popupwindow_result:I = 0x7f0d0852

.field public static final mcard_union_buy_dialog:I = 0x7f0d0853

.field public static final member_sdk_activity_webview:I = 0x7f0d0856

.field public static final member_sdk_progress_dialog:I = 0x7f0d0857

.field public static final member_sdk_ucc_dialog_layout:I = 0x7f0d0858

.field public static final member_sdk_ucc_pop_layout:I = 0x7f0d0859

.field public static final member_sdk_ucc_webview:I = 0x7f0d085a

.field public static final mid_action_sheet_item_layout:I = 0x7f0d0867

.field public static final mid_action_sheet_layout:I = 0x7f0d0868

.field public static final mine_brand_bestchoice:I = 0x7f0d086b

.field public static final mine_brand_project_item:I = 0x7f0d086e

.field public static final mine_customers_layout:I = 0x7f0d0874

.field public static final mine_grablist_item:I = 0x7f0d0877

.field public static final mine_grablist_item_more:I = 0x7f0d0878

.field public static final mine_grablist_item_title:I = 0x7f0d0879

.field public static final mine_starindex_fragment_header_common:I = 0x7f0d0892

.field public static final mine_starindex_fragment_header_tab:I = 0x7f0d0893

.field public static final mine_starindex_moreprojects_layout:I = 0x7f0d0899

.field public static final mine_starindex_xunyan_flipper_block:I = 0x7f0d089c

.field public static final mine_starindex_xunyan_flipper_item:I = 0x7f0d089d

.field public static final mine_starindex_xunyan_layout:I = 0x7f0d089e

.field public static final mine_title_header:I = 0x7f0d08a0

.field public static final mmediacontraol:I = 0x7f0d08ae

.field public static final mo_alert_dialog_layout:I = 0x7f0d08af

.field public static final mo_itemview_des_img_layout:I = 0x7f0d08b0

.field public static final mo_itemview_icon_des_layout:I = 0x7f0d08b1

.field public static final mo_itemview_normal_text_layout:I = 0x7f0d08b2

.field public static final mo_recyclerview_fragment:I = 0x7f0d08b3

.field public static final mock_params_error_dialog:I = 0x7f0d08b4

.field public static final movie_empty_statemanage:I = 0x7f0d08b7

.field public static final movie_toast_view:I = 0x7f0d08b9

.field public static final mtoolbar:I = 0x7f0d08ba

.field public static final mtrl_alert_dialog:I = 0x7f0d08bb

.field public static final mtrl_alert_dialog_actions:I = 0x7f0d08bc

.field public static final mtrl_alert_dialog_title:I = 0x7f0d08bd

.field public static final mtrl_alert_select_dialog_item:I = 0x7f0d08be

.field public static final mtrl_alert_select_dialog_multichoice:I = 0x7f0d08bf

.field public static final mtrl_alert_select_dialog_singlechoice:I = 0x7f0d08c0

.field public static final mtrl_calendar_day:I = 0x7f0d08c2

.field public static final mtrl_calendar_day_of_week:I = 0x7f0d08c3

.field public static final mtrl_calendar_days_of_week:I = 0x7f0d08c4

.field public static final mtrl_calendar_horizontal:I = 0x7f0d08c5

.field public static final mtrl_calendar_month:I = 0x7f0d08c6

.field public static final mtrl_calendar_month_labeled:I = 0x7f0d08c7

.field public static final mtrl_calendar_month_navigation:I = 0x7f0d08c8

.field public static final mtrl_calendar_months:I = 0x7f0d08c9

.field public static final mtrl_calendar_vertical:I = 0x7f0d08ca

.field public static final mtrl_calendar_year:I = 0x7f0d08cb

.field public static final mtrl_layout_snackbar:I = 0x7f0d08cc

.field public static final mtrl_layout_snackbar_include:I = 0x7f0d08cd

.field public static final mtrl_navigation_rail_item:I = 0x7f0d08ce

.field public static final mtrl_picker_actions:I = 0x7f0d08cf

.field public static final mtrl_picker_dialog:I = 0x7f0d08d0

.field public static final mtrl_picker_fullscreen:I = 0x7f0d08d1

.field public static final mtrl_picker_header_dialog:I = 0x7f0d08d2

.field public static final mtrl_picker_header_fullscreen:I = 0x7f0d08d3

.field public static final mtrl_picker_header_selection_text:I = 0x7f0d08d4

.field public static final mtrl_picker_header_title_text:I = 0x7f0d08d5

.field public static final mtrl_picker_header_toggle:I = 0x7f0d08d6

.field public static final mtrl_picker_text_input_date:I = 0x7f0d08d7

.field public static final mtrl_picker_text_input_date_range:I = 0x7f0d08d8

.field public static final multi_line_input_view:I = 0x7f0d08d9

.field public static final multiple_list_cinema_filter_pop_container:I = 0x7f0d08da

.field public static final mute_bottom_layer:I = 0x7f0d08db

.field public static final my_want_see_ip_item:I = 0x7f0d08dd

.field public static final my_want_see_rank_item:I = 0x7f0d08de

.field public static final my_want_toolbar_activity:I = 0x7f0d08df

.field public static final new_evaluate_activity:I = 0x7f0d08e1

.field public static final notification_action:I = 0x7f0d08f7

.field public static final notification_action_tombstone:I = 0x7f0d08f8

.field public static final notification_media_action:I = 0x7f0d08f9

.field public static final notification_media_cancel_action:I = 0x7f0d08fa

.field public static final notification_template_big_media:I = 0x7f0d08fb

.field public static final notification_template_big_media_custom:I = 0x7f0d08fc

.field public static final notification_template_big_media_narrow:I = 0x7f0d08fd

.field public static final notification_template_big_media_narrow_custom:I = 0x7f0d08fe

.field public static final notification_template_custom_big:I = 0x7f0d08ff

.field public static final notification_template_icon_group:I = 0x7f0d0900

.field public static final notification_template_lines_media:I = 0x7f0d0901

.field public static final notification_template_media:I = 0x7f0d0902

.field public static final notification_template_media_custom:I = 0x7f0d0903

.field public static final notification_template_part_chronometer:I = 0x7f0d0904

.field public static final notification_template_part_time:I = 0x7f0d0905

.field public static final one_arch_fragment_layout:I = 0x7f0d0907

.field public static final onearch_fragment_lazy_load:I = 0x7f0d0908

.field public static final onearch_tab_layout_item:I = 0x7f0d0909

.field public static final onearch_tab_layout_item_film_detail:I = 0x7f0d090a

.field public static final online_card_title_layout:I = 0x7f0d090b

.field public static final online_daojishi:I = 0x7f0d090c

.field public static final online_header_layout:I = 0x7f0d090d

.field public static final online_headpic:I = 0x7f0d090e

.field public static final online_star_layout_mul:I = 0x7f0d090f

.field public static final online_star_pro_pic:I = 0x7f0d0910

.field public static final online_timer_layout:I = 0x7f0d0911

.field public static final onlive_tag_view:I = 0x7f0d0912

.field public static final opr_subtitle_layout:I = 0x7f0d0913

.field public static final order_address_modify_item:I = 0x7f0d0914

.field public static final order_container:I = 0x7f0d0917

.field public static final order_container_new:I = 0x7f0d0918

.field public static final order_coupon_item:I = 0x7f0d0919

.field public static final order_detail_best_price_item:I = 0x7f0d0922

.field public static final order_detail_best_price_item1:I = 0x7f0d0923

.field public static final order_dialog_vip_exchange_coupon:I = 0x7f0d0950

.field public static final order_food_ticket_item:I = 0x7f0d0952

.field public static final order_goods_payresult_fragment:I = 0x7f0d0953

.field public static final order_goods_payresult_status_item:I = 0x7f0d0954

.field public static final order_mcard_select_item:I = 0x7f0d0965

.field public static final order_ordering_blank_item_layout:I = 0x7f0d0968

.field public static final order_ordering_common_sale_item:I = 0x7f0d0969

.field public static final order_ordering_common_sale_price_list_item:I = 0x7f0d096a

.field public static final order_ordering_frag_payment_chargecard_common:I = 0x7f0d096b

.field public static final order_ordering_frag_payment_coupon_package_bottom_item:I = 0x7f0d096c

.field public static final order_ordering_frag_payment_tool_bottom_panel_905:I = 0x7f0d096d

.field public static final order_ordering_frag_payment_tool_item_88_vip:I = 0x7f0d096e

.field public static final order_ordering_frag_payment_tool_item_bank_reduce:I = 0x7f0d096f

.field public static final order_ordering_frag_payment_tool_item_bogo:I = 0x7f0d0970

.field public static final order_ordering_frag_payment_tool_item_bottom_dummy:I = 0x7f0d0971

.field public static final order_ordering_frag_payment_tool_item_bottom_dummy85:I = 0x7f0d0972

.field public static final order_ordering_frag_payment_tool_item_bottom_dummy_125:I = 0x7f0d0973

.field public static final order_ordering_frag_payment_tool_item_card:I = 0x7f0d0974

.field public static final order_ordering_frag_payment_tool_item_card_sale:I = 0x7f0d0975

.field public static final order_ordering_frag_payment_tool_item_cinema_coupons_package:I = 0x7f0d0976

.field public static final order_ordering_frag_payment_tool_item_cinema_coupons_package_item:I = 0x7f0d0977

.field public static final order_ordering_frag_payment_tool_item_cinema_mcard_item:I = 0x7f0d0978

.field public static final order_ordering_frag_payment_tool_item_citypass_open_layout:I = 0x7f0d0979

.field public static final order_ordering_frag_payment_tool_item_citypass_use_layout:I = 0x7f0d097a

.field public static final order_ordering_frag_payment_tool_item_coupon:I = 0x7f0d097b

.field public static final order_ordering_frag_payment_tool_item_coupon_saleorder:I = 0x7f0d097c

.field public static final order_ordering_frag_payment_tool_item_divider:I = 0x7f0d097d

.field public static final order_ordering_frag_payment_tool_item_endorse_equity:I = 0x7f0d097e

.field public static final order_ordering_frag_payment_tool_item_endorse_fee:I = 0x7f0d097f

.field public static final order_ordering_frag_payment_tool_item_endorse_oriprice:I = 0x7f0d0980

.field public static final order_ordering_frag_payment_tool_item_endorse_sale_selected_69:I = 0x7f0d0981

.field public static final order_ordering_frag_payment_tool_item_glass:I = 0x7f0d0982

.field public static final order_ordering_frag_payment_tool_item_logo:I = 0x7f0d0983

.field public static final order_ordering_frag_payment_tool_item_m_card:I = 0x7f0d0984

.field public static final order_ordering_frag_payment_tool_item_market_bottom:I = 0x7f0d0985

.field public static final order_ordering_frag_payment_tool_item_market_title:I = 0x7f0d0986

.field public static final order_ordering_frag_payment_tool_item_more_good:I = 0x7f0d0987

.field public static final order_ordering_frag_payment_tool_item_notice_dvd:I = 0x7f0d0988

.field public static final order_ordering_frag_payment_tool_item_notice_item:I = 0x7f0d0989

.field public static final order_ordering_frag_payment_tool_item_notice_new:I = 0x7f0d098a

.field public static final order_ordering_frag_payment_tool_item_notice_sale:I = 0x7f0d098b

.field public static final order_ordering_frag_payment_tool_item_notice_title:I = 0x7f0d098c

.field public static final order_ordering_frag_payment_tool_item_open_mcard_73:I = 0x7f0d098d

.field public static final order_ordering_frag_payment_tool_item_open_mcard_sales:I = 0x7f0d098e

.field public static final order_ordering_frag_payment_tool_item_open_union_mcard:I = 0x7f0d098f

.field public static final order_ordering_frag_payment_tool_item_phone:I = 0x7f0d0990

.field public static final order_ordering_frag_payment_tool_item_presalecode:I = 0x7f0d0991

.field public static final order_ordering_frag_payment_tool_item_reduce_coupon:I = 0x7f0d0992

.field public static final order_ordering_frag_payment_tool_item_reduce_vip:I = 0x7f0d0993

.field public static final order_ordering_frag_payment_tool_item_sale:I = 0x7f0d0994

.field public static final order_ordering_frag_payment_tool_item_sale_activity:I = 0x7f0d0995

.field public static final order_ordering_frag_payment_tool_item_sale_bottom_dummy:I = 0x7f0d0996

.field public static final order_ordering_frag_payment_tool_item_sale_bottom_dummy_95:I = 0x7f0d0997

.field public static final order_ordering_frag_payment_tool_item_sale_order:I = 0x7f0d0998

.field public static final order_ordering_frag_payment_tool_item_sale_price:I = 0x7f0d0999

.field public static final order_ordering_frag_payment_tool_item_sale_reduce_coupon:I = 0x7f0d099a

.field public static final order_ordering_frag_payment_tool_item_sale_shortcut:I = 0x7f0d099b

.field public static final order_ordering_frag_payment_tool_item_salepresalecode:I = 0x7f0d099c

.field public static final order_ordering_frag_payment_tool_item_special_price:I = 0x7f0d099d

.field public static final order_ordering_frag_payment_tool_item_split_devide:I = 0x7f0d099e

.field public static final order_ordering_frag_payment_tool_item_split_devide2:I = 0x7f0d099f

.field public static final order_ordering_frag_payment_tool_item_split_dummy:I = 0x7f0d09a0

.field public static final order_ordering_frag_payment_tool_item_total:I = 0x7f0d09a1

.field public static final order_ordering_frag_payment_tool_item_unioncard:I = 0x7f0d09a2

.field public static final order_ordering_frag_payment_tool_item_vip_coupon:I = 0x7f0d09a3

.field public static final order_ordering_frag_scene_toolbar:I = 0x7f0d09a4

.field public static final order_ordering_popupwindow_add_ticket_item:I = 0x7f0d09a5

.field public static final order_ordering_popupwindow_big_item_emptydata:I = 0x7f0d09a6

.field public static final order_ordering_popupwindow_blank_item:I = 0x7f0d09a7

.field public static final order_ordering_popupwindow_blank_item3:I = 0x7f0d09a8

.field public static final order_ordering_popupwindow_bogo_tip_item:I = 0x7f0d09a9

.field public static final order_ordering_popupwindow_common_blank_item:I = 0x7f0d09aa

.field public static final order_ordering_popupwindow_common_text_item:I = 0x7f0d09ab

.field public static final order_ordering_popupwindow_core_view:I = 0x7f0d09ac

.field public static final order_ordering_popupwindow_detail:I = 0x7f0d09ad

.field public static final order_ordering_popupwindow_detail_dummy_item:I = 0x7f0d09ae

.field public static final order_ordering_popupwindow_detail_item_69:I = 0x7f0d09af

.field public static final order_ordering_popupwindow_detail_item_icon_card_69:I = 0x7f0d09b0

.field public static final order_ordering_popupwindow_detail_item_icon_pop_69:I = 0x7f0d09b1

.field public static final order_ordering_popupwindow_detail_sale_item_795:I = 0x7f0d09b2

.field public static final order_ordering_popupwindow_detail_sale_item_795_tag:I = 0x7f0d09b3

.field public static final order_ordering_popupwindow_detail_title_item:I = 0x7f0d09b4

.field public static final order_ordering_popupwindow_endorse_refund_item:I = 0x7f0d09b5

.field public static final order_ordering_popupwindow_header_item2:I = 0x7f0d09b6

.field public static final order_ordering_popupwindow_header_item3:I = 0x7f0d09b7

.field public static final order_ordering_popupwindow_member_endorse_refund_item:I = 0x7f0d09b8

.field public static final order_ordering_popupwindow_payment_detail:I = 0x7f0d09b9

.field public static final order_ordering_popupwindow_reduce_row:I = 0x7f0d09ba

.field public static final order_ordering_popupwindow_sale_item:I = 0x7f0d09bb

.field public static final order_ordering_popupwindow_selector_bank_item_two_line:I = 0x7f0d09bc

.field public static final order_ordering_popupwindow_selector_common:I = 0x7f0d09bd

.field public static final order_ordering_popupwindow_selector_item_mcard_header:I = 0x7f0d09be

.field public static final order_ordering_popupwindow_selector_item_mcard_recharge_item:I = 0x7f0d09bf

.field public static final order_ordering_popupwindow_selector_item_one_line:I = 0x7f0d09c0

.field public static final order_ordering_popupwindow_selector_item_reduce:I = 0x7f0d09c1

.field public static final order_ordering_popupwindow_selector_item_reduce_check:I = 0x7f0d09c2

.field public static final order_ordering_popupwindow_selector_item_reduce_coupon:I = 0x7f0d09c3

.field public static final order_ordering_popupwindow_selector_item_reduce_row:I = 0x7f0d09c4

.field public static final order_ordering_popupwindow_selector_item_reduce_tip:I = 0x7f0d09c5

.field public static final order_ordering_popupwindow_selector_item_two_line:I = 0x7f0d09c6

.field public static final order_ordering_popupwindow_selector_item_two_line2:I = 0x7f0d09c7

.field public static final order_ordering_popupwindow_selector_item_unioncard:I = 0x7f0d09c8

.field public static final order_ordering_popupwindow_text_tip_item:I = 0x7f0d09c9

.field public static final order_ordering_popupwindow_vip_endorse_refund_rule_item:I = 0x7f0d09ca

.field public static final order_ordering_popwindow_refund_change:I = 0x7f0d09cb

.field public static final order_ordering_vip_exchange_film_show:I = 0x7f0d09cc

.field public static final order_ordering_vip_exchange_post_img:I = 0x7f0d09cd

.field public static final order_ordering_vip_exchange_profit_desc:I = 0x7f0d09ce

.field public static final order_ordering_vip_exchange_rule:I = 0x7f0d09cf

.field public static final order_pay_option_item:I = 0x7f0d09d0

.field public static final order_promotion_popupwindow_header_item:I = 0x7f0d09d1

.field public static final order_promotion_popupwindow_item:I = 0x7f0d09d2

.field public static final order_result_guess_you_like_view:I = 0x7f0d09d4

.field public static final order_result_happy_coin_dialog_content_large:I = 0x7f0d09d5

.field public static final order_result_happy_coin_dialog_content_middle:I = 0x7f0d09d6

.field public static final order_result_happy_coin_dialog_content_small:I = 0x7f0d09d7

.field public static final order_result_happy_coin_dialog_double:I = 0x7f0d09d8

.field public static final order_result_happy_coin_dialog_double_item:I = 0x7f0d09d9

.field public static final order_result_happy_coin_top:I = 0x7f0d09da

.field public static final order_result_happy_coin_wheel_item:I = 0x7f0d09db

.field public static final order_result_mission_progress_item:I = 0x7f0d09dc

.field public static final order_result_recommend_item:I = 0x7f0d09dd

.field public static final order_result_souvenir_tip:I = 0x7f0d09de

.field public static final order_result_youku:I = 0x7f0d09df

.field public static final order_result_zero_popwindow:I = 0x7f0d09e0

.field public static final order_risk_alert_dialog:I = 0x7f0d09e1

.field public static final order_risk_alert_dialog_item:I = 0x7f0d09e2

.field public static final order_sale_list_number_title_item:I = 0x7f0d09e3

.field public static final order_sale_number_title_item:I = 0x7f0d09e4

.field public static final order_sale_ordering_block_bottom:I = 0x7f0d09e5

.field public static final order_sale_ordering_header:I = 0x7f0d09e6

.field public static final order_salelist_frag_item_split_devide:I = 0x7f0d09e7

.field public static final order_sales_frag_item_title:I = 0x7f0d09e8

.field public static final order_select_seat_notice_head:I = 0x7f0d09e9

.field public static final order_success_mem_corn_dialog:I = 0x7f0d09ea

.field public static final order_success_mem_corn_layout:I = 0x7f0d09eb

.field public static final order_success_vip_benefit_item_large:I = 0x7f0d09ec

.field public static final order_success_vip_benefit_item_small:I = 0x7f0d09ed

.field public static final order_success_vip_benefit_merge:I = 0x7f0d09ee

.field public static final order_success_vip_coin_benefit_layout:I = 0x7f0d09ef

.field public static final order_ticket_popupwindow_refund_endorse_rule_item:I = 0x7f0d09f0

.field public static final order_ticket_popupwindow_refund_endorse_user_level_item:I = 0x7f0d09f1

.field public static final order_time_out_view:I = 0x7f0d09f2

.field public static final order_tool_item_ordering_vip_rights:I = 0x7f0d09f3

.field public static final order_tool_item_refund_endorse_upgrade:I = 0x7f0d09f4

.field public static final order_ui_blank_item:I = 0x7f0d09f5

.field public static final order_ui_divider_item:I = 0x7f0d09f6

.field public static final order_ui_frag_ordering_result_button_item:I = 0x7f0d09f7

.field public static final order_ui_frag_ordering_result_festival_item:I = 0x7f0d09f8

.field public static final order_ui_frag_ordering_result_status_item:I = 0x7f0d09f9

.field public static final order_ui_recommend_title_item:I = 0x7f0d09fa

.field public static final order_ui_space3_item:I = 0x7f0d09fb

.field public static final order_ui_space6_item:I = 0x7f0d09fc

.field public static final order_ui_space_item:I = 0x7f0d09fd

.field public static final ordering_header_view:I = 0x7f0d09fe

.field public static final ordering_header_view_73:I = 0x7f0d09ff

.field public static final ordering_header_view_95:I = 0x7f0d0a00

.field public static final ordering_mtoolbar_layout:I = 0x7f0d0a01

.field public static final ordering_timer_73_layout:I = 0x7f0d0a02

.field public static final ordering_union_card_tiplayout:I = 0x7f0d0a03

.field public static final oscar_adapter_feed_info_remind:I = 0x7f0d0a04

.field public static final oscar_article_favor_menu:I = 0x7f0d0a08

.field public static final oscar_article_immerse_video_item:I = 0x7f0d0a09

.field public static final oscar_article_item:I = 0x7f0d0a0a

.field public static final oscar_article_magic_comment_item:I = 0x7f0d0a0b

.field public static final oscar_article_magic_date_item:I = 0x7f0d0a0c

.field public static final oscar_article_magic_mark_item:I = 0x7f0d0a0d

.field public static final oscar_article_recomment_item:I = 0x7f0d0a0f

.field public static final oscar_article_theme_all_topic_item:I = 0x7f0d0a10

.field public static final oscar_article_theme_article_item:I = 0x7f0d0a11

.field public static final oscar_article_theme_four_image_item:I = 0x7f0d0a12

.field public static final oscar_article_theme_media_item:I = 0x7f0d0a13

.field public static final oscar_article_theme_nine_image_item:I = 0x7f0d0a14

.field public static final oscar_article_theme_poster_item:I = 0x7f0d0a15

.field public static final oscar_article_theme_text_item:I = 0x7f0d0a16

.field public static final oscar_cinema_activity_cinemadetail_evaluate_ineer_item:I = 0x7f0d0a17

.field public static final oscar_cinema_activity_cinemalist_amap:I = 0x7f0d0a18

.field public static final oscar_cinema_activity_tag:I = 0x7f0d0a19

.field public static final oscar_cinema_activity_tag_red_packet:I = 0x7f0d0a1a

.field public static final oscar_cinema_appraise_overview:I = 0x7f0d0a1b

.field public static final oscar_cinema_frag_poster_gallery_item:I = 0x7f0d0a1c

.field public static final oscar_cinema_frag_schedule_activity_container:I = 0x7f0d0a1d

.field public static final oscar_cinema_frag_schedule_error_page:I = 0x7f0d0a1e

.field public static final oscar_cinema_frag_schedule_list:I = 0x7f0d0a1f

.field public static final oscar_cinema_frag_schedule_one_activity_container:I = 0x7f0d0a20

.field public static final oscar_cinema_frag_schedule_union_activity_container:I = 0x7f0d0a21

.field public static final oscar_cinema_group_listview_child_amap_item_old:I = 0x7f0d0a22

.field public static final oscar_cinema_group_listview_child_item:I = 0x7f0d0a23

.field public static final oscar_cinema_list_filter_item:I = 0x7f0d0a24

.field public static final oscar_cinema_list_schedule_view:I = 0x7f0d0a25

.field public static final oscar_cinema_list_schedule_view_v2:I = 0x7f0d0a26

.field public static final oscar_cinema_marker_window:I = 0x7f0d0a27

.field public static final oscar_cinema_schedule_food_ticket_item:I = 0x7f0d0a28

.field public static final oscar_cinema_search_activity:I = 0x7f0d0a29

.field public static final oscar_cinemas_score_tag_block:I = 0x7f0d0a2a

.field public static final oscar_cinemas_search_item:I = 0x7f0d0a2b

.field public static final oscar_cinenalist_cinema_no_score:I = 0x7f0d0a2c

.field public static final oscar_common_comment_2:I = 0x7f0d0a2f

.field public static final oscar_common_comment_block:I = 0x7f0d0a30

.field public static final oscar_common_comment_imglist:I = 0x7f0d0a31

.field public static final oscar_common_comment_tag_expand_view:I = 0x7f0d0a32

.field public static final oscar_common_comment_v2:I = 0x7f0d0a33

.field public static final oscar_common_comment_v2_container:I = 0x7f0d0a34

.field public static final oscar_common_tag_v2:I = 0x7f0d0a35

.field public static final oscar_feed_favor_menu:I = 0x7f0d0a39

.field public static final oscar_film_adapter_empty_comment:I = 0x7f0d0a3a

.field public static final oscar_film_adapter_error_comment:I = 0x7f0d0a3b

.field public static final oscar_film_article_item:I = 0x7f0d0a3c

.field public static final oscar_film_derivation_item:I = 0x7f0d0a3d

.field public static final oscar_film_derivation_item2:I = 0x7f0d0a3e

.field public static final oscar_film_detail_bottom_item_cms:I = 0x7f0d0a3f

.field public static final oscar_film_detail_boxing_office_v2:I = 0x7f0d0a41

.field public static final oscar_film_detail_comment_banner_v2:I = 0x7f0d0a42

.field public static final oscar_film_detail_comment_count_v2:I = 0x7f0d0a43

.field public static final oscar_film_detail_comment_head_block_v2:I = 0x7f0d0a44

.field public static final oscar_film_detail_comment_tag_block_v2:I = 0x7f0d0a45

.field public static final oscar_film_detail_info_block_v2:I = 0x7f0d0a46

.field public static final oscar_film_detail_no_comment_v2:I = 0x7f0d0a47

.field public static final oscar_film_detail_profile_item_v2:I = 0x7f0d0a48

.field public static final oscar_film_detail_surrounding_view_v2:I = 0x7f0d0a49

.field public static final oscar_film_detail_video_dynamic_v2:I = 0x7f0d0a4a

.field public static final oscar_film_frag_list_banner_image_item:I = 0x7f0d0a4b

.field public static final oscar_film_frag_list_mode:I = 0x7f0d0a4c

.field public static final oscar_film_frag_list_nowplaying_or_upcoming_item:I = 0x7f0d0a4d

.field public static final oscar_film_luckdraw_result_empty_item:I = 0x7f0d0a4f

.field public static final oscar_film_luckdraw_result_item:I = 0x7f0d0a50

.field public static final oscar_film_payment_lottery_rights:I = 0x7f0d0a51

.field public static final oscar_film_payment_result_items:I = 0x7f0d0a52

.field public static final oscar_film_payment_result_rights:I = 0x7f0d0a53

.field public static final oscar_film_topic_item:I = 0x7f0d0a54

.field public static final oscar_further_comment_item:I = 0x7f0d0a55

.field public static final oscar_further_comment_item_v2:I = 0x7f0d0a56

.field public static final oscar_media_header:I = 0x7f0d0a57

.field public static final oscar_member_card_info_item:I = 0x7f0d0a58

.field public static final oscar_new_cinemas_page_list_item:I = 0x7f0d0a59

.field public static final oscar_recycle_item_more_magic_tips:I = 0x7f0d0a5a

.field public static final oscar_remote_search_activity:I = 0x7f0d0a5b

.field public static final oscar_schedule_page_list_container:I = 0x7f0d0a5c

.field public static final oscar_theme_topic_item:I = 0x7f0d0a5d

.field public static final oscar_topic_item:I = 0x7f0d0a5e

.field public static final oscar_topic_item_article:I = 0x7f0d0a5f

.field public static final oscar_wanted_film_frag_stiky_list:I = 0x7f0d0a60

.field public static final overlay_common_layout:I = 0x7f0d0a61

.field public static final pager_navigator_layout:I = 0x7f0d0a62

.field public static final pager_navigator_layout_no_scroll:I = 0x7f0d0a63

.field public static final pay_option_list_bottom_sheet:I = 0x7f0d0a65

.field public static final pay_option_list_item:I = 0x7f0d0a66

.field public static final pay_option_list_panel:I = 0x7f0d0a67

.field public static final people_see_tags_layout:I = 0x7f0d0a69

.field public static final pha_taomai_fragment_layout:I = 0x7f0d0a6a

.field public static final photo_picker_dialog:I = 0x7f0d0a6b

.field public static final pic_discount_excel_layout:I = 0x7f0d0a6c

.field public static final pic_discount_price_layout:I = 0x7f0d0a6d

.field public static final pic_kit_dialog_default_layout:I = 0x7f0d0a6e

.field public static final pic_promotion_discount_excel_item:I = 0x7f0d0a6f

.field public static final pic_promotion_title_item:I = 0x7f0d0a70

.field public static final pic_ticket_discount_card_layout:I = 0x7f0d0a71

.field public static final pic_to_dialog_base_layout:I = 0x7f0d0a72

.field public static final picture_activity:I = 0x7f0d0a73

.field public static final picture_theme_dialog:I = 0x7f0d0a74

.field public static final picture_theme_dialog_pioneer:I = 0x7f0d0a75

.field public static final picture_viewpager_fragment:I = 0x7f0d0a76

.field public static final picturesbiz_component_performance_more:I = 0x7f0d0a77

.field public static final picturesbiz_layout_combined_image:I = 0x7f0d0a78

.field public static final pinterest_image_view:I = 0x7f0d0a79

.field public static final pioneer_component_common_tab_home_dm:I = 0x7f0d0a82

.field public static final pioneer_count_down_flash_layout:I = 0x7f0d0a85

.field public static final pioneer_count_down_flash_layout_v2:I = 0x7f0d0a86

.field public static final pioneer_count_down_flash_layout_v3:I = 0x7f0d0a87

.field public static final pioneer_damai_dialog:I = 0x7f0d0a88

.field public static final pioneer_film_image_tags_player:I = 0x7f0d0a89

.field public static final pioneer_home_grab_block_title_mix_want_sore:I = 0x7f0d0a95

.field public static final pioneer_live_ipstore_entrance:I = 0x7f0d0ab3

.field public static final pioneer_live_ipstore_item_card:I = 0x7f0d0ab4

.field public static final pioneer_onearch_tab_layout_item:I = 0x7f0d0ab7

.field public static final pioneer_tags_layout_home:I = 0x7f0d0abe

.field public static final pioneer_tags_layout_home_tpp:I = 0x7f0d0abf

.field public static final play_ui_layer:I = 0x7f0d0ac1

.field public static final pop:I = 0x7f0d0ac2

.field public static final pop_cinema_list_blank_item:I = 0x7f0d0ac3

.field public static final pop_dialog_container:I = 0x7f0d0ac4

.field public static final pop_fragment_sku_join_splice_layout:I = 0x7f0d0ac5

.field public static final pop_fragment_sku_start_splice_layout:I = 0x7f0d0ac6

.field public static final pop_fragment_splice_join_team_layout:I = 0x7f0d0ac7

.field public static final pop_fragment_splice_pop_window_title:I = 0x7f0d0ac8

.field public static final pop_layer_container:I = 0x7f0d0ac9

.field public static final pop_layer_sando_layer:I = 0x7f0d0aca

.field public static final popup_view:I = 0x7f0d0acb

.field public static final popup_view_sub:I = 0x7f0d0acc

.field public static final popwindow_location_tip:I = 0x7f0d0acd

.field public static final popwindow_mo_tip:I = 0x7f0d0ace

.field public static final praise_item_layout:I = 0x7f0d0ad0

.field public static final price_popup_item:I = 0x7f0d0ad1

.field public static final price_popup_summary_item:I = 0x7f0d0ad2

.field public static final price_popup_window:I = 0x7f0d0ad3

.field public static final privileged_audience_reminder_view:I = 0x7f0d0ad6

.field public static final product_coupon_first_item:I = 0x7f0d0ad8

.field public static final profile_my_benefit_youku:I = 0x7f0d0ad9

.field public static final profile_titlebar_custom_login:I = 0x7f0d0ada

.field public static final progress_layer:I = 0x7f0d0adb

.field public static final project_activity_view_hor:I = 0x7f0d0add

.field public static final project_buynow_price_layout:I = 0x7f0d0ae7

.field public static final project_calendar_topbar:I = 0x7f0d0ae8

.field public static final project_calendar_week:I = 0x7f0d0ae9

.field public static final project_detail_perform_layout:I = 0x7f0d0af1

.field public static final project_detail_perform_text:I = 0x7f0d0af2

.field public static final project_detail_perfrom:I = 0x7f0d0af3

.field public static final project_extra_benefit_layout:I = 0x7f0d0afc

.field public static final pull_down_view:I = 0x7f0d0b3f

.field public static final pull_listview_fragment:I = 0x7f0d0b40

.field public static final pull_recyclerview_fragment:I = 0x7f0d0b41

.field public static final pull_refresh_fragment:I = 0x7f0d0b42

.field public static final pull_scrollview_fragment:I = 0x7f0d0b43

.field public static final pull_to_refresh_arrow_loading_layout:I = 0x7f0d0b44

.field public static final pull_to_refresh_head_vertical_damai:I = 0x7f0d0b45

.field public static final pull_to_refresh_header:I = 0x7f0d0b46

.field public static final pull_to_refresh_header_horizontal:I = 0x7f0d0b47

.field public static final pull_to_refresh_header_vertical:I = 0x7f0d0b48

.field public static final pull_to_refresh_layout:I = 0x7f0d0b49

.field public static final pull_up_dialog_default_view:I = 0x7f0d0b4a

.field public static final pull_up_dialog_view:I = 0x7f0d0b4b

.field public static final pullrefresh_overview:I = 0x7f0d0b4c

.field public static final push_expandable_big_image_notification:I = 0x7f0d0b4e

.field public static final push_expandable_big_text_notification:I = 0x7f0d0b4f

.field public static final push_pure_pic_notification_f6:I = 0x7f0d0b50

.field public static final push_pure_pic_notification_f7:I = 0x7f0d0b51

.field public static final push_pure_pic_notification_f8:I = 0x7f0d0b52

.field public static final push_pure_pic_notification_f9:I = 0x7f0d0b53

.field public static final push_pure_pic_notification_f9_275:I = 0x7f0d0b54

.field public static final push_pure_pic_notification_f9_337:I = 0x7f0d0b55

.field public static final qr_code_result_activity:I = 0x7f0d0b56

.field public static final qrcode_view_finder_layout:I = 0x7f0d0b57

.field public static final rank_project_component:I = 0x7f0d0b5b

.field public static final rank_project_item:I = 0x7f0d0b5c

.field public static final rank_rank_component:I = 0x7f0d0b5d

.field public static final rank_tag_view:I = 0x7f0d0b65

.field public static final rank_word_item_view:I = 0x7f0d0b66

.field public static final ranklist_footer_empty_new:I = 0x7f0d0b6c

.field public static final realname_auth_base_title:I = 0x7f0d0b6d

.field public static final realname_autherror_view:I = 0x7f0d0b71

.field public static final realname_faceverify_failed_layout:I = 0x7f0d0b74

.field public static final realname_notice_bar:I = 0x7f0d0b75

.field public static final refresh_empty_view:I = 0x7f0d0b76

.field public static final refund_and_endorse_dialog:I = 0x7f0d0b78

.field public static final report_list_item:I = 0x7f0d0b83

.field public static final rich_zoom_iamgeview:I = 0x7f0d0b87

.field public static final rp_alrealidentity_activity_rp_preview_photo:I = 0x7f0d0b89

.field public static final rp_alrealidentity_activity_rp_take_photo:I = 0x7f0d0b8a

.field public static final rp_alrealidentity_activity_rph5:I = 0x7f0d0b8b

.field public static final rp_alrealidentity_alert_dialog:I = 0x7f0d0b8c

.field public static final rp_alrealidentity_top_bar:I = 0x7f0d0b8d

.field public static final rp_face_dialog:I = 0x7f0d0b8e

.field public static final rp_face_liveness_activity:I = 0x7f0d0b8f

.field public static final rp_face_loading_activity:I = 0x7f0d0b90

.field public static final rp_face_widget_detectaction_biometrics:I = 0x7f0d0b91

.field public static final rp_face_widget_detectactionresult:I = 0x7f0d0b92

.field public static final rp_face_widget_guide:I = 0x7f0d0b93

.field public static final rp_face_widget_privacy:I = 0x7f0d0b94

.field public static final rp_face_widget_titlebar:I = 0x7f0d0b95

.field public static final sale_union_activity_view:I = 0x7f0d0b96

.field public static final sales_list_bottom_panel:I = 0x7f0d0b97

.field public static final sales_list_header_item:I = 0x7f0d0b98

.field public static final sales_order_activity_item:I = 0x7f0d0b99

.field public static final sales_order_activity_item_sales:I = 0x7f0d0b9a

.field public static final sales_order_expire_time_item:I = 0x7f0d0b9b

.field public static final sales_order_refund:I = 0x7f0d0b9c

.field public static final sales_order_union_activity_item:I = 0x7f0d0b9d

.field public static final sales_order_valid_date:I = 0x7f0d0b9e

.field public static final sales_ordering_popupwindow_detail_title_item:I = 0x7f0d0b9f

.field public static final sales_ordering_popupwindow_payment_detail:I = 0x7f0d0ba0

.field public static final sales_price_item:I = 0x7f0d0ba1

.field public static final scan_title_bar:I = 0x7f0d0ba2

.field public static final schedule_activity_tag_item:I = 0x7f0d0ba4

.field public static final schedule_activity_view:I = 0x7f0d0ba5

.field public static final schedule_and_food_tab_custom_view:I = 0x7f0d0ba6

.field public static final schedule_card_dialog:I = 0x7f0d0ba7

.field public static final schedule_card_tag_view:I = 0x7f0d0ba8

.field public static final schedule_cinema_info_header_new:I = 0x7f0d0ba9

.field public static final schedule_citypass_tag_item:I = 0x7f0d0baa

.field public static final schedule_coupon_dialog:I = 0x7f0d0bab

.field public static final schedule_expandable_textview:I = 0x7f0d0bac

.field public static final schedule_film_detail_info_item:I = 0x7f0d0bad

.field public static final schedule_group_buy_item:I = 0x7f0d0bae

.field public static final schedule_group_buy_view_container:I = 0x7f0d0baf

.field public static final schedule_happy_money_item:I = 0x7f0d0bb0

.field public static final schedule_promotion_info_activity:I = 0x7f0d0bb1

.field public static final schedule_promotion_tag_view:I = 0x7f0d0bb2

.field public static final schedule_promotion_vip_discount:I = 0x7f0d0bb3

.field public static final schedule_root_container:I = 0x7f0d0bb4

.field public static final schedule_sale_goods_title:I = 0x7f0d0bb5

.field public static final schedule_sale_number_title_item:I = 0x7f0d0bb6

.field public static final schedule_sale_union_card_item:I = 0x7f0d0bb7

.field public static final schedule_tag_container:I = 0x7f0d0bb8

.field public static final schedule_tip_view:I = 0x7f0d0bb9

.field public static final schedule_union_card_item:I = 0x7f0d0bba

.field public static final schedule_union_popupwindow_item:I = 0x7f0d0bbb

.field public static final schedule_user_right_tag_view:I = 0x7f0d0bbc

.field public static final score_distribute:I = 0x7f0d0bbd

.field public static final score_distribute_reputation:I = 0x7f0d0bbe

.field public static final screen_shot_share:I = 0x7f0d0bbf

.field public static final search_hot_list_view_layout:I = 0x7f0d0bc3

.field public static final search_info_video_controller:I = 0x7f0d0bc4

.field public static final search_result_film_banner_image:I = 0x7f0d0bd3

.field public static final search_toolbar:I = 0x7f0d0bd5

.field public static final seat_activity_select_seat:I = 0x7f0d0bd8

.field public static final seat_frag_select_mutilseat:I = 0x7f0d0bd9

.field public static final seat_frag_select_seat_button_panel:I = 0x7f0d0bda

.field public static final seat_frag_select_seat_indicator_item:I = 0x7f0d0bdb

.field public static final seat_frag_select_seat_price_item:I = 0x7f0d0bdc

.field public static final seat_frag_select_seat_recommend_item:I = 0x7f0d0bdd

.field public static final sec_container_activity_h5:I = 0x7f0d0be4

.field public static final sec_container_top_bar:I = 0x7f0d0be5

.field public static final select_amount_view:I = 0x7f0d0be6

.field public static final select_dialog_item_material:I = 0x7f0d0be7

.field public static final select_dialog_multichoice_material:I = 0x7f0d0be8

.field public static final select_dialog_singlechoice_material:I = 0x7f0d0be9

.field public static final select_seat_area_tip_dialog:I = 0x7f0d0bea

.field public static final select_seat_info_view:I = 0x7f0d0beb

.field public static final select_seat_notice:I = 0x7f0d0bec

.field public static final select_seat_notice_item:I = 0x7f0d0bed

.field public static final select_seat_recommend_success_tip:I = 0x7f0d0bee

.field public static final select_seat_vip_new_tips:I = 0x7f0d0bef

.field public static final select_seat_vip_special_common_dialog:I = 0x7f0d0bf0

.field public static final select_single_contain:I = 0x7f0d0bf1

.field public static final senior_vip_addition_view:I = 0x7f0d0bf2

.field public static final senior_vip_tag:I = 0x7f0d0bf3

.field public static final share_activity:I = 0x7f0d0bf5

.field public static final share_channel_item:I = 0x7f0d0bf6

.field public static final share_channel_recycler_item:I = 0x7f0d0bf7

.field public static final share_channel_recycler_item_custom:I = 0x7f0d0bf8

.field public static final share_custom_item:I = 0x7f0d0bf9

.field public static final share_ext_item:I = 0x7f0d0bfa

.field public static final share_middle_main:I = 0x7f0d0bfb

.field public static final share_order_activity:I = 0x7f0d0bfc

.field public static final share_sina_fragment:I = 0x7f0d0bfd

.field public static final shedule_activity_view_tip:I = 0x7f0d0bfe

.field public static final simple_refresh_footer:I = 0x7f0d0c01

.field public static final simple_refresh_header:I = 0x7f0d0c02

.field public static final simple_video_view_controller:I = 0x7f0d0c03

.field public static final sku_calendar_day_view:I = 0x7f0d0c05

.field public static final sku_calendar_topbar:I = 0x7f0d0c06

.field public static final sku_calendar_week:I = 0x7f0d0c07

.field public static final sku_goods_register_toast_layout:I = 0x7f0d0c08

.field public static final sku_ncov_itembox_perform:I = 0x7f0d0c09

.field public static final sku_ncov_itembox_tag:I = 0x7f0d0c0a

.field public static final sku_ncov_itembox_text:I = 0x7f0d0c0b

.field public static final sku_ncov_tag:I = 0x7f0d0c0c

.field public static final sku_perform_remark_time_layout:I = 0x7f0d0c0d

.field public static final sku_perform_text:I = 0x7f0d0c0e

.field public static final sku_price_text:I = 0x7f0d0c0f

.field public static final sku_splice_join_splice_team_item:I = 0x7f0d0c10

.field public static final sku_splice_join_splice_team_shortcut:I = 0x7f0d0c11

.field public static final sku_splice_launch_one_team_item:I = 0x7f0d0c12

.field public static final sku_splice_notice_flipper_view_layout:I = 0x7f0d0c13

.field public static final sku_splice_order_activity_level_block:I = 0x7f0d0c14

.field public static final sliding_action_item:I = 0x7f0d0c15

.field public static final sliding_tag_image_view:I = 0x7f0d0c16

.field public static final sliding_tag_item:I = 0x7f0d0c17

.field public static final sliding_tag_item_scenic:I = 0x7f0d0c18

.field public static final sliding_venue_tag_item:I = 0x7f0d0c19

.field public static final sls_layout:I = 0x7f0d0c1a

.field public static final smooth_progressbar:I = 0x7f0d0c1b

.field public static final special_schedule_item:I = 0x7f0d0c1d

.field public static final special_schedule_popupwindow:I = 0x7f0d0c1e

.field public static final spring_banner_image:I = 0x7f0d0c22

.field public static final spring_banner_item:I = 0x7f0d0c23

.field public static final spring_open_card_dialog:I = 0x7f0d0c24

.field public static final spring_open_card_dialog_content:I = 0x7f0d0c25

.field public static final srl_classics_footer:I = 0x7f0d0c28

.field public static final srl_classics_header:I = 0x7f0d0c29

.field public static final state_manager_item:I = 0x7f0d0c2d

.field public static final statemanager_empty:I = 0x7f0d0c2e

.field public static final statemanager_error:I = 0x7f0d0c2f

.field public static final statemanager_feed_info_common_error_layout:I = 0x7f0d0c30

.field public static final statemanager_feed_info_loading_layout:I = 0x7f0d0c31

.field public static final statemanager_loading:I = 0x7f0d0c32

.field public static final statemanager_order_exception_layout:I = 0x7f0d0c33

.field public static final statemanager_order_loading_layout:I = 0x7f0d0c34

.field public static final statemanager_pioneer_cinama_empty_layout:I = 0x7f0d0c35

.field public static final statemanager_session_empty:I = 0x7f0d0c36

.field public static final subgroup_3column_item:I = 0x7f0d0c37

.field public static final subgroup_3column_layout:I = 0x7f0d0c38

.field public static final subgroup_banner_item:I = 0x7f0d0c39

.field public static final subgroup_galley_layout:I = 0x7f0d0c3a

.field public static final subscribe_topic_item:I = 0x7f0d0c3b

.field public static final suitable_cinema_filter_list:I = 0x7f0d0c3c

.field public static final suitable_cinema_list_fragment:I = 0x7f0d0c3d

.field public static final support_simple_spinner_dropdown_item:I = 0x7f0d0c40

.field public static final surprise_red_coupon:I = 0x7f0d0c41

.field public static final surprise_red_coupon_viewstub:I = 0x7f0d0c42

.field public static final tab_bg:I = 0x7f0d0c43

.field public static final tagitem:I = 0x7f0d0c44

.field public static final test_action_chip:I = 0x7f0d0c47

.field public static final test_add_same_view:I = 0x7f0d0c48

.field public static final test_chip_zero_corner_radius:I = 0x7f0d0c49

.field public static final test_design_checkbox:I = 0x7f0d0c4a

.field public static final test_design_radiobutton:I = 0x7f0d0c4b

.field public static final test_navigation_bar_item_layout:I = 0x7f0d0c4d

.field public static final test_reflow_chipgroup:I = 0x7f0d0c4e

.field public static final test_toolbar:I = 0x7f0d0c4f

.field public static final test_toolbar_custom_background:I = 0x7f0d0c50

.field public static final test_toolbar_elevation:I = 0x7f0d0c51

.field public static final test_toolbar_surface:I = 0x7f0d0c52

.field public static final tetris_common_errorview:I = 0x7f0d0c53

.field public static final tetris_common_list_title:I = 0x7f0d0c54

.field public static final tetris_core_defalut_layer_wrapper:I = 0x7f0d0c55

.field public static final tetris_core_gaia_container:I = 0x7f0d0c56

.field public static final tetris_core_linear_proxy:I = 0x7f0d0c57

.field public static final tetris_dm_base_content_list_item:I = 0x7f0d0c58

.field public static final tetris_dm_base_content_main:I = 0x7f0d0c59

.field public static final tetris_dm_base_content_main_title_layout:I = 0x7f0d0c5a

.field public static final tetris_star_base_content_free_main:I = 0x7f0d0c5b

.field public static final tetris_star_official_content_feed_main:I = 0x7f0d0c5c

.field public static final text_icon_view:I = 0x7f0d0c5d

.field public static final text_view_with_line_height_from_appearance:I = 0x7f0d0c5e

.field public static final text_view_with_line_height_from_layout:I = 0x7f0d0c5f

.field public static final text_view_with_line_height_from_style:I = 0x7f0d0c60

.field public static final text_view_with_theme_line_height:I = 0x7f0d0c61

.field public static final text_view_without_line_height:I = 0x7f0d0c62

.field public static final theme_circle_head:I = 0x7f0d0c64

.field public static final theme_circle_head_vote:I = 0x7f0d0c65

.field public static final theme_expandable_textview:I = 0x7f0d0c66

.field public static final theme_image_view:I = 0x7f0d0c68

.field public static final theme_multiple_image_view:I = 0x7f0d0c69

.field public static final theme_project_loop:I = 0x7f0d0c6a

.field public static final ticket_activity_tag_view:I = 0x7f0d0c6b

.field public static final ticket_area_card_title_bar_view:I = 0x7f0d0c6c

.field public static final ticket_area_card_view:I = 0x7f0d0c6d

.field public static final ticket_code_item:I = 0x7f0d0c6e

.field public static final ticket_gb_qrcode_block_inpop_view:I = 0x7f0d0c70

.field public static final ticket_gb_qrcode_block_view:I = 0x7f0d0c71

.field public static final ticket_gb_qrcode_info_inpop_view:I = 0x7f0d0c72

.field public static final ticket_gb_qrcode_info_view:I = 0x7f0d0c73

.field public static final ticket_remind_code_view:I = 0x7f0d0c74

.field public static final ticket_share_menu:I = 0x7f0d0c75

.field public static final ticklet_perform_alert:I = 0x7f0d0ca6

.field public static final ticklet_perform_dialog_layout:I = 0x7f0d0ca8

.field public static final ticklet_perform_new_alert:I = 0x7f0d0cab

.field public static final ticklet_perform_popwindow:I = 0x7f0d0cac

.field public static final ticklet_ticket_nft_share_item:I = 0x7f0d0cc9

.field public static final tips_popup_venue_window:I = 0x7f0d0ce9

.field public static final tips_popup_window_left:I = 0x7f0d0cea

.field public static final tips_popup_window_mid:I = 0x7f0d0ceb

.field public static final tips_popup_window_right:I = 0x7f0d0cec

.field public static final title_pop_layer:I = 0x7f0d0cee

.field public static final titlebar:I = 0x7f0d0cef

.field public static final titlebar_custom:I = 0x7f0d0cf0

.field public static final titlebar_left_button_item:I = 0x7f0d0cf1

.field public static final titlebar_multi_title:I = 0x7f0d0cf2

.field public static final titlebar_multi_title_filmdetail:I = 0x7f0d0cf3

.field public static final titlebar_right_button_item:I = 0x7f0d0cf5

.field public static final titlebar_right_combo_button_item:I = 0x7f0d0cf6

.field public static final tm_vip_expand_item:I = 0x7f0d0cf7

.field public static final tm_vip_profit_card_layout:I = 0x7f0d0cf8

.field public static final tm_vip_right_profit_layout:I = 0x7f0d0cf9

.field public static final tm_vip_top_image_item:I = 0x7f0d0cfa

.field public static final toast_custom:I = 0x7f0d0cfb

.field public static final toast_custom_img:I = 0x7f0d0cfc

.field public static final toast_custom_lottie:I = 0x7f0d0cfd

.field public static final toast_custom_lottie_v2:I = 0x7f0d0cfe

.field public static final toast_transient_notification:I = 0x7f0d0cff

.field public static final toast_view:I = 0x7f0d0d00

.field public static final token_film_item:I = 0x7f0d0d01

.field public static final topic_kind_item:I = 0x7f0d0d02

.field public static final topic_layout_view:I = 0x7f0d0d03

.field public static final topic_layout_view_article:I = 0x7f0d0d04

.field public static final topic_more_item:I = 0x7f0d0d05

.field public static final torch_layout:I = 0x7f0d0d06

.field public static final tpp_generic_progress_dialog:I = 0x7f0d0d07

.field public static final tpp_generic_progress_dialog_pioneer:I = 0x7f0d0d08

.field public static final tpp_layout_queue_view_flipper:I = 0x7f0d0d09

.field public static final tpp_pull_refresh_fragment:I = 0x7f0d0d0a

.field public static final tpp_pullrefresh_overview:I = 0x7f0d0d0b

.field public static final type_calendar_content:I = 0x7f0d0d1a

.field public static final uik_choice_divider:I = 0x7f0d0d1e

.field public static final uik_image_save_choice:I = 0x7f0d0d1f

.field public static final uik_image_save_dialog:I = 0x7f0d0d20

.field public static final uik_swipe_refresh_footer:I = 0x7f0d0d21

.field public static final uik_swipe_refresh_header:I = 0x7f0d0d22

.field public static final uikit_category_tag_view:I = 0x7f0d0d23

.field public static final uikit_damai_avatar:I = 0x7f0d0d24

.field public static final uikit_damai_avatar_v2:I = 0x7f0d0d25

.field public static final uikit_divider_v:I = 0x7f0d0d26

.field public static final uikit_live_room:I = 0x7f0d0d27

.field public static final uikit_load_more_view:I = 0x7f0d0d28

.field public static final uikit_load_view:I = 0x7f0d0d29

.field public static final uikit_star_pop_layout:I = 0x7f0d0d2a

.field public static final upcoming_banner_image:I = 0x7f0d0d3b

.field public static final update_coerce:I = 0x7f0d0d3c

.field public static final update_dialog:I = 0x7f0d0d3d

.field public static final update_manage_dialog:I = 0x7f0d0d3e

.field public static final update_notification:I = 0x7f0d0d3f

.field public static final user_avatar_overlay_list_item:I = 0x7f0d0d40

.field public static final user_nick_extra_view:I = 0x7f0d0d50

.field public static final user_scan_activity:I = 0x7f0d0d51

.field public static final user_scan_transparent_activity:I = 0x7f0d0d52

.field public static final venuepage_component_venuebrand_card:I = 0x7f0d0d54

.field public static final venuepage_component_venuebrand_card_info:I = 0x7f0d0d55

.field public static final video_artist_decor:I = 0x7f0d0d56

.field public static final video_fragment_layout:I = 0x7f0d0d57

.field public static final video_home_decor:I = 0x7f0d0d58

.field public static final video_project_layer_layout:I = 0x7f0d0d59

.field public static final video_tag_view:I = 0x7f0d0d5a

.field public static final video_tag_view_v2:I = 0x7f0d0d5b

.field public static final view_banner_item_view:I = 0x7f0d0d5c

.field public static final view_coupon_tag:I = 0x7f0d0d5d

.field public static final view_generate_evaluate_script_kill_shop_info:I = 0x7f0d0d60

.field public static final view_group_booking_member:I = 0x7f0d0d61

.field public static final view_ma_tool_top:I = 0x7f0d0d62

.field public static final view_movie_refresh_header:I = 0x7f0d0d63

.field public static final view_pager:I = 0x7f0d0d64

.field public static final view_taomai_h5_container_titlebar:I = 0x7f0d0d69

.field public static final vip_exchange_entrance_view:I = 0x7f0d0d6a

.field public static final wanted_dialog:I = 0x7f0d0d6f

.field public static final wanted_dialog_market_item:I = 0x7f0d0d70

.field public static final wanted_dialog_market_tips_item:I = 0x7f0d0d71

.field public static final wanted_dialog_marketing:I = 0x7f0d0d72

.field public static final wanted_film_list_filter_popup_win:I = 0x7f0d0d73

.field public static final wanted_list_item:I = 0x7f0d0d74

.field public static final wanted_list_item_v2:I = 0x7f0d0d75

.field public static final wanted_normal_dialog:I = 0x7f0d0d76

.field public static final wanted_normal_dialog_v2:I = 0x7f0d0d77

.field public static final webview_activity:I = 0x7f0d0d7b

.field public static final webview_activity2:I = 0x7f0d0d7c

.field public static final webview_fragment:I = 0x7f0d0d7d

.field public static final webview_item:I = 0x7f0d0d7e

.field public static final widget_schedule_vip_discount:I = 0x7f0d0d81

.field public static final widget_schedule_vip_price:I = 0x7f0d0d82

.field public static final widget_user_info_view:I = 0x7f0d0d84

.field public static final wx_pay_activity:I = 0x7f0d0d85

.field public static final x_banner_item:I = 0x7f0d0d86

.field public static final x_banner_layout:I = 0x7f0d0d87

.field public static final yk_mock_item:I = 0x7f0d0d88

.field public static final yk_mock_test:I = 0x7f0d0d89

.field public static final yk_player_bottombar:I = 0x7f0d0d8a

.field public static final yk_player_discover_handler_layout:I = 0x7f0d0d8b

.field public static final yk_player_error_view:I = 0x7f0d0d8c

.field public static final yk_player_handler_layout:I = 0x7f0d0d8d

.field public static final yk_player_home_bottombar:I = 0x7f0d0d8e

.field public static final yk_player_home_handler_layout:I = 0x7f0d0d8f

.field public static final yk_player_muteonly_bottom_layout:I = 0x7f0d0d90

.field public static final yk_player_topbar:I = 0x7f0d0d91

.field public static final you_may_like_banner_item_layout:I = 0x7f0d0d92

.field public static final youkuplayer:I = 0x7f0d0d93

.field public static final zoomimage_activity:I = 0x7f0d0d9a


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
