.class public Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter$b$a;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter$b;->a(Ljava/lang/String;Landroid/graphics/Bitmap;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter$b;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter$b;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter$b$a;->a:Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter$b;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onLongClick(Landroid/view/View;)Z
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter$b$a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    return p1

    .line 1
    :cond_1e
    iget-object p1, p0, Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter$b$a;->a:Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter$b;

    iget-object p1, p1, Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter$b;->d:Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter;

    invoke-static {p1}, Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter;->e(Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter;)Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter$OnImageLongClickListener;

    move-result-object p1

    if-eqz p1, :cond_40

    .line 2
    invoke-static {}, Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter;->d()Ljava/lang/String;

    move-result-object p1

    const-string v0, "image long click."

    invoke-static {p1, v0}, Ltb/av2;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter$b$a;->a:Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter$b;

    iget-object p1, p1, Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter$b;->d:Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter;

    invoke-static {p1}, Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter;->e(Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter;)Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter$OnImageLongClickListener;

    move-result-object p1

    iget-object v0, p0, Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter$b$a;->a:Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter$b;

    iget v0, v0, Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter$b;->c:I

    invoke-interface {p1, v0}, Lcn/damai/commonbusiness/imagebrowse/adapter/ImageBrowseAdapter$OnImageLongClickListener;->onLongClick(I)V

    :cond_40
    return v3
.end method
