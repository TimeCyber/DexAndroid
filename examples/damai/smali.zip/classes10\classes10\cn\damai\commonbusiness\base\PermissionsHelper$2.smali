.class public Lcn/damai/commonbusiness/base/PermissionsHelper$2;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/base/PermissionsHelper;->b(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic val$activity:Landroid/app/Activity;

.field final synthetic val$cancelListener:Landroid/content/DialogInterface$OnClickListener;

.field final synthetic val$cancelText:Ljava/lang/String;

.field final synthetic val$permissionTypeMessage:Ljava/lang/String;

.field final synthetic val$sureListener:Landroid/content/DialogInterface$OnClickListener;

.field final synthetic val$sureText:Ljava/lang/String;


# direct methods
.method constructor <init>(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;Ljava/lang/String;Landroid/content/DialogInterface$OnClickListener;)V
    .registers 7

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/base/PermissionsHelper$2;->val$activity:Landroid/app/Activity;

    iput-object p2, p0, Lcn/damai/commonbusiness/base/PermissionsHelper$2;->val$permissionTypeMessage:Ljava/lang/String;

    iput-object p3, p0, Lcn/damai/commonbusiness/base/PermissionsHelper$2;->val$sureText:Ljava/lang/String;

    iput-object p4, p0, Lcn/damai/commonbusiness/base/PermissionsHelper$2;->val$sureListener:Landroid/content/DialogInterface$OnClickListener;

    iput-object p5, p0, Lcn/damai/commonbusiness/base/PermissionsHelper$2;->val$cancelText:Ljava/lang/String;

    iput-object p6, p0, Lcn/damai/commonbusiness/base/PermissionsHelper$2;->val$cancelListener:Landroid/content/DialogInterface$OnClickListener;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/base/PermissionsHelper$2;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_14

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    new-instance v0, Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;

    iget-object v1, p0, Lcn/damai/commonbusiness/base/PermissionsHelper$2;->val$activity:Landroid/app/Activity;

    invoke-direct {v0, v1}, Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;-><init>(Landroid/content/Context;)V

    sget-object v1, Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog$TMDialogPermissionType;->THEME_PERMISSION_NOTIFICATION:Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog$TMDialogPermissionType;

    .line 2
    invoke-virtual {v0, v1}, Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;->u(Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog$TMDialogPermissionType;)Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;

    move-result-object v0

    .line 3
    invoke-virtual {v0, v3}, Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;->m(Z)Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;

    move-result-object v0

    iget-object v1, p0, Lcn/damai/commonbusiness/base/PermissionsHelper$2;->val$permissionTypeMessage:Ljava/lang/String;

    .line 4
    invoke-virtual {v0, v1}, Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;->q(Ljava/lang/CharSequence;)Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;

    move-result-object v0

    iget-object v1, p0, Lcn/damai/commonbusiness/base/PermissionsHelper$2;->val$sureText:Ljava/lang/String;

    iget-object v2, p0, Lcn/damai/commonbusiness/base/PermissionsHelper$2;->val$sureListener:Landroid/content/DialogInterface$OnClickListener;

    .line 5
    invoke-virtual {v0, v1, v2}, Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;->o(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;

    move-result-object v0

    iget-object v1, p0, Lcn/damai/commonbusiness/base/PermissionsHelper$2;->val$cancelText:Ljava/lang/String;

    iget-object v2, p0, Lcn/damai/commonbusiness/base/PermissionsHelper$2;->val$cancelListener:Landroid/content/DialogInterface$OnClickListener;

    .line 6
    invoke-virtual {v0, v1, v2}, Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;->k(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;

    move-result-object v0

    .line 7
    invoke-virtual {v0}, Lcom/alibaba/pictures/bricks/util/permissiondialog/PicturePermissionDialog;->show()V

    return-void
.end method
