.class public Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;
.super Ljava/lang/Object;
.source "Taobao"


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

.field private static d:Landroid/os/Handler;


# instance fields
.field private volatile a:Z

.field private b:Lcn/damai/commonbusiness/qrcode/QRCodeActivity;

.field private final c:I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v0, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;->d:Landroid/os/Handler;

    return-void
.end method

.method public constructor <init>(Lcn/damai/commonbusiness/qrcode/QRCodeActivity;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0xa

    .line 2
    iput v0, p0, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;->c:I

    .line 3
    iput-object p1, p0, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;->b:Lcn/damai/commonbusiness/qrcode/QRCodeActivity;

    return-void
.end method

.method static synthetic a(Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;III)V
    .registers 4

    .line 1
    invoke-direct {p0, p1, p2, p3}, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;->e(III)V

    return-void
.end method

.method static synthetic b(Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;Z)Z
    .registers 2

    .line 1
    iput-boolean p1, p0, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;->a:Z

    return p1
.end method

.method private d(II)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_22

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_22
    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;->d:Landroid/os/Handler;

    new-instance v1, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator$1;

    invoke-direct {v1, p0, p1, p2}, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator$1;-><init>(Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;II)V

    const-wide/16 p1, 0x14

    invoke-virtual {v0, v1, p1, p2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method private e(III)V
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_29

    const/4 v2, 0x4

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_29
    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;->b:Lcn/damai/commonbusiness/qrcode/QRCodeActivity;

    if-nez v0, :cond_2e

    return-void

    .line 2
    :cond_2e
    invoke-virtual {v0, p1}, Lcn/damai/commonbusiness/qrcode/QRCodeActivity;->setZoom(I)V

    add-int/2addr p2, v3

    .line 3
    invoke-direct {p0, p2, p3}, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;->d(II)V

    return-void
.end method


# virtual methods
.method public c()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_14
    const/4 v0, 0x0

    .line 1
    iput-object v0, p0, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;->b:Lcn/damai/commonbusiness/qrcode/QRCodeActivity;

    return-void
.end method

.method public f(FI)V
    .registers 8

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_22

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v4

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_22
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "startAutoZoom : rate is "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v1, ", curIndex is "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "AutoZoomOperator"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    cmpg-float v0, p1, v0

    if-ltz v0, :cond_55

    .line 2
    iget-boolean v0, p0, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;->a:Z

    if-nez v0, :cond_55

    const/16 v0, 0xa

    if-lt p2, v0, :cond_4e

    goto :goto_55

    .line 3
    :cond_4e
    iput-boolean v3, p0, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;->a:Z

    float-to-int p1, p1

    .line 4
    invoke-direct {p0, v4, p1}, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;->d(II)V

    return-void

    .line 5
    :cond_55
    :goto_55
    iput-boolean v4, p0, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;->a:Z

    return-void
.end method
