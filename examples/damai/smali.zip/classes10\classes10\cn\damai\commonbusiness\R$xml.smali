.class public final Lcn/damai/commonbusiness/R$xml;
.super Ljava/lang/Object;
.source "Taobao"


# static fields
.field public static final apk_paths:I = 0x7f160000

.field public static final file_paths:I = 0x7f160002

.field public static final file_provider:I = 0x7f160003

.field public static final filepaths:I = 0x7f160004

.field public static final h5_file_paths:I = 0x7f160006

.field public static final provider_file_paths:I = 0x7f16000a

.field public static final sg_apk_path:I = 0x7f16000b

.field public static final standalone_badge:I = 0x7f16000c

.field public static final standalone_badge_gravity_bottom_end:I = 0x7f16000d

.field public static final standalone_badge_gravity_bottom_start:I = 0x7f16000e

.field public static final standalone_badge_gravity_top_start:I = 0x7f16000f

.field public static final standalone_badge_offset:I = 0x7f160010

.field public static final tencent_filepaths:I = 0x7f160011


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
