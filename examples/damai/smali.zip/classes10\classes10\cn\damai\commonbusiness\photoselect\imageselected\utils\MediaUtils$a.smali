.class Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "a"
.end annotation


# instance fields
.field a:Z

.field b:Ljava/lang/String;

.field final synthetic c:Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;


# direct methods
.method public constructor <init>(Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils$a;->c:Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
