.class public interface abstract Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView$OnZoomOperatedListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnZoomOperatedListener"
.end annotation


# virtual methods
.method public abstract onZoomReverted()V
.end method

.method public abstract setZoom(F)V
.end method

.method public abstract startContinuousZoom(F)V
.end method
