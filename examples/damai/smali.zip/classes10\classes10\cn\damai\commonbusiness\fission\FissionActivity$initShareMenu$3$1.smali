.class public final Lcn/damai/commonbusiness/fission/FissionActivity$initShareMenu$3$1;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/widget/SeekBar$OnSeekBarChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/fission/FissionActivity;->initShareMenu()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000%\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0003*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J\"\u0010\u0002\u001a\u00020\u00032\u0008\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u0008\u001a\u00020\tH\u0016J\u0012\u0010\n\u001a\u00020\u00032\u0008\u0010\u0004\u001a\u0004\u0018\u00010\u0005H\u0016J\u0012\u0010\u000b\u001a\u00020\u00032\u0008\u0010\u0004\u001a\u0004\u0018\u00010\u0005H\u0016\u00a8\u0006\u000c"
    }
    d2 = {
        "cn/damai/commonbusiness/fission/FissionActivity$initShareMenu$3$1",
        "Landroid/widget/SeekBar$OnSeekBarChangeListener;",
        "onProgressChanged",
        "",
        "seekBar",
        "Landroid/widget/SeekBar;",
        "progress",
        "",
        "fromUser",
        "",
        "onStartTrackingTouch",
        "onStopTrackingTouch",
        "commonbusiness_release"
    }
    k = 0x1
    mv = {
        0x1,
        0x7,
        0x1
    }
    xi = 0x30
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic $this_apply:Landroidx/appcompat/widget/AppCompatSeekBar;

.field final synthetic this$0:Lcn/damai/commonbusiness/fission/FissionActivity;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/fission/FissionActivity;Landroidx/appcompat/widget/AppCompatSeekBar;)V
    .registers 3

    iput-object p1, p0, Lcn/damai/commonbusiness/fission/FissionActivity$initShareMenu$3$1;->this$0:Lcn/damai/commonbusiness/fission/FissionActivity;

    iput-object p2, p0, Lcn/damai/commonbusiness/fission/FissionActivity$initShareMenu$3$1;->$this_apply:Landroidx/appcompat/widget/AppCompatSeekBar;

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onProgressChanged(Landroid/widget/SeekBar;IZ)V
    .registers 8
    .param p1    # Landroid/widget/SeekBar;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param

    sget-object v0, Lcn/damai/commonbusiness/fission/FissionActivity$initShareMenu$3$1;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_25

    const/4 v2, 0x4

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_25
    iget-object p1, p0, Lcn/damai/commonbusiness/fission/FissionActivity$initShareMenu$3$1;->this$0:Lcn/damai/commonbusiness/fission/FissionActivity;

    invoke-static {p1, p2}, Lcn/damai/commonbusiness/fission/FissionActivity;->access$setCurProgress$p(Lcn/damai/commonbusiness/fission/FissionActivity;I)V

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/fission/FissionActivity$initShareMenu$3$1;->this$0:Lcn/damai/commonbusiness/fission/FissionActivity;

    invoke-static {p1, p2}, Lcn/damai/commonbusiness/fission/FissionActivity;->access$translationXThumbLottie(Lcn/damai/commonbusiness/fission/FissionActivity;I)V

    return-void
.end method

.method public onStartTrackingTouch(Landroid/widget/SeekBar;)V
    .registers 6
    .param p1    # Landroid/widget/SeekBar;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param

    sget-object v0, Lcn/damai/commonbusiness/fission/FissionActivity$initShareMenu$3$1;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object p1, p0, Lcn/damai/commonbusiness/fission/FissionActivity$initShareMenu$3$1;->this$0:Lcn/damai/commonbusiness/fission/FissionActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/fission/FissionActivity;->access$getImgWantLight$p(Lcn/damai/commonbusiness/fission/FissionActivity;)Lcom/alibaba/pictures/moimage/MoImageView;

    move-result-object p1

    if-eqz p1, :cond_2d

    .line 2
    invoke-virtual {p1}, Landroid/widget/ImageView;->getAnimation()Landroid/view/animation/Animation;

    move-result-object v0

    if-eqz v0, :cond_28

    invoke-virtual {v0}, Landroid/view/animation/Animation;->cancel()V

    :cond_28
    const/16 v0, 0x8

    .line 3
    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    :cond_2d
    return-void
.end method

.method public onStopTrackingTouch(Landroid/widget/SeekBar;)V
    .registers 6
    .param p1    # Landroid/widget/SeekBar;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param

    sget-object v0, Lcn/damai/commonbusiness/fission/FissionActivity$initShareMenu$3$1;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object p1, p0, Lcn/damai/commonbusiness/fission/FissionActivity$initShareMenu$3$1;->this$0:Lcn/damai/commonbusiness/fission/FissionActivity;

    iget-object v0, p0, Lcn/damai/commonbusiness/fission/FissionActivity$initShareMenu$3$1;->$this_apply:Landroidx/appcompat/widget/AppCompatSeekBar;

    invoke-virtual {v0}, Landroid/widget/SeekBar;->getProgress()I

    move-result v0

    const/4 v1, 0x5

    if-le v0, v1, :cond_25

    const-string v0, "1"

    goto :goto_27

    :cond_25
    const-string v0, "0"

    :goto_27
    iget-object v2, p0, Lcn/damai/commonbusiness/fission/FissionActivity$initShareMenu$3$1;->this$0:Lcn/damai/commonbusiness/fission/FissionActivity;

    invoke-static {v2}, Lcn/damai/commonbusiness/fission/FissionActivity;->access$getUniqueIdent$p(Lcn/damai/commonbusiness/fission/FissionActivity;)Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_31

    const-string v2, ""

    :cond_31
    invoke-static {p1, v0, v2}, Lcn/damai/commonbusiness/fission/FissionActivity;->access$markWantSee(Lcn/damai/commonbusiness/fission/FissionActivity;Ljava/lang/String;Ljava/lang/String;)V

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/fission/FissionActivity$initShareMenu$3$1;->this$0:Lcn/damai/commonbusiness/fission/FissionActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/fission/FissionActivity;->access$getImgWantTitle$p(Lcn/damai/commonbusiness/fission/FissionActivity;)Lcom/alibaba/pictures/moimage/MoImageView;

    move-result-object p1

    if-eqz p1, :cond_58

    sget-object v0, Ltb/l81;->INSTANCE:Ltb/l81;

    const/high16 v2, 0x41700000    # 15.0f

    invoke-virtual {v0, v2}, Ltb/l81;->b(F)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    .line 3
    iget-object v2, p0, Lcn/damai/commonbusiness/fission/FissionActivity$initShareMenu$3$1;->$this_apply:Landroidx/appcompat/widget/AppCompatSeekBar;

    invoke-virtual {v2}, Landroid/widget/SeekBar;->getProgress()I

    move-result v2

    if-le v2, v1, :cond_53

    const-string v1, "https://gw.alicdn.com/imgextra/i2/O1CN01DuW3xC1rjXMtfVnry_!!6000000005667-2-tps-372-44.png"

    goto :goto_55

    :cond_53
    const-string v1, "https://gw.alicdn.com/imgextra/i2/O1CN01WTXk3X1lExE4Fo8Ff_!!6000000004788-2-tps-359-44.png"

    .line 4
    :goto_55
    invoke-static {p1, v0, v1}, Lcom/alibaba/pictures/moimage/MoImageExtensionsKt;->b(Lcom/alibaba/pictures/moimage/MoImageView;Ljava/lang/Integer;Ljava/lang/String;)V

    :cond_58
    return-void
.end method
