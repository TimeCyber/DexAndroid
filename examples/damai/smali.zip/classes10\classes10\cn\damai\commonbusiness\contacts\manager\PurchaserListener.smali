.class public interface abstract Lcn/damai/commonbusiness/contacts/manager/PurchaserListener;
.super Ljava/lang/Object;
.source "Taobao"


# virtual methods
.method public abstract onPurchaserListFail(Ljava/lang/String;Ljava/lang/String;)V
.end method

.method public abstract onPurchaserListSuccess(Lcn/damai/commonbusiness/contacts/bean/PurchaserListBean;)V
.end method
