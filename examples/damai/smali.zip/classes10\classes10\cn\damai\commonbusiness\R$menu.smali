.class public final Lcn/damai/commonbusiness/R$menu;
.super Ljava/lang/Object;
.source "Taobao"


# static fields
.field public static final aliuser_menu:I = 0x7f0e0000

.field public static final aliuser_reg_menu:I = 0x7f0e0001

.field public static final cinemas_popup_toolbar_menu:I = 0x7f0e0002


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
