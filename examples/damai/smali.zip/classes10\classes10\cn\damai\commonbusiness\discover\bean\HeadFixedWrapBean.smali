.class public Lcn/damai/commonbusiness/discover/bean/HeadFixedWrapBean;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field public circleList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/discover/bean/HeadFixedBean;",
            ">;"
        }
    .end annotation
.end field

.field public commentList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/discover/bean/HeadFixedBean;",
            ">;"
        }
    .end annotation
.end field

.field public mTitleBean:Lcn/damai/tetris/component/drama/bean/CardTitleBean;

.field public markets:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/discover/bean/HeadFixedBean;",
            ">;"
        }
    .end annotation
.end field

.field public pos:I


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcn/damai/commonbusiness/discover/bean/HeadFixedWrapBean;->circleList:Ljava/util/List;

    .line 3
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcn/damai/commonbusiness/discover/bean/HeadFixedWrapBean;->commentList:Ljava/util/List;

    return-void
.end method

.method private isComment(Lcn/damai/commonbusiness/discover/bean/HeadFixedBean;)Z
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/discover/bean/HeadFixedWrapBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    return p1

    .line 1
    :cond_1e
    iget p1, p1, Lcn/damai/commonbusiness/discover/bean/HeadFixedBean;->type:I

    if-eqz p1, :cond_23

    goto :goto_24

    :cond_23
    const/4 v3, 0x0

    :goto_24
    return v3
.end method


# virtual methods
.method public handleData()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/discover/bean/HeadFixedWrapBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/discover/bean/HeadFixedWrapBean;->markets:Ljava/util/List;

    if-eqz v0, :cond_53

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-nez v0, :cond_1f

    goto :goto_53

    .line 2
    :cond_1f
    :goto_1f
    iget-object v0, p0, Lcn/damai/commonbusiness/discover/bean/HeadFixedWrapBean;->markets:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-ge v3, v0, :cond_53

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/discover/bean/HeadFixedWrapBean;->markets:Ljava/util/List;

    invoke-interface {v0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/discover/bean/HeadFixedBean;

    invoke-direct {p0, v0}, Lcn/damai/commonbusiness/discover/bean/HeadFixedWrapBean;->isComment(Lcn/damai/commonbusiness/discover/bean/HeadFixedBean;)Z

    move-result v0

    if-eqz v0, :cond_43

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/discover/bean/HeadFixedWrapBean;->commentList:Ljava/util/List;

    iget-object v1, p0, Lcn/damai/commonbusiness/discover/bean/HeadFixedWrapBean;->markets:Ljava/util/List;

    invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcn/damai/commonbusiness/discover/bean/HeadFixedBean;

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_50

    .line 5
    :cond_43
    iget-object v0, p0, Lcn/damai/commonbusiness/discover/bean/HeadFixedWrapBean;->circleList:Ljava/util/List;

    iget-object v1, p0, Lcn/damai/commonbusiness/discover/bean/HeadFixedWrapBean;->markets:Ljava/util/List;

    invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcn/damai/commonbusiness/discover/bean/HeadFixedBean;

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_50
    add-int/lit8 v3, v3, 0x1

    goto :goto_1f

    :cond_53
    :goto_53
    return-void
.end method
