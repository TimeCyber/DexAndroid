.class public Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$l;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$l;->a:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$l;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1e
    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$l;->a:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;->access$500(Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;)Z

    move-result p1

    if-eqz p1, :cond_2e

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$l;->a:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;

    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    :cond_2e
    return-void
.end method
