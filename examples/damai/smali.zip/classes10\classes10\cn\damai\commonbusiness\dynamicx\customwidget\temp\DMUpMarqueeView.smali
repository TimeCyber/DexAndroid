.class public Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;
.super Landroid/widget/ViewFlipper;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView$OnItemClickListener;
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private onItemClickListener:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView$OnItemClickListener;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Landroid/widget/ViewFlipper;-><init>(Landroid/content/Context;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 3

    .line 2
    invoke-direct {p0, p1, p2}, Landroid/widget/ViewFlipper;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method static synthetic access$000(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView$OnItemClickListener;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;->onItemClickListener:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView$OnItemClickListener;

    return-object p0
.end method


# virtual methods
.method public setAnimationDuration(J)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    invoke-virtual {p0}, Landroid/widget/ViewFlipper;->getContext()Landroid/content/Context;

    move-result-object v0

    sget v1, Lcom/alibaba/pictures/picturesbiz/R$anim;->damai_marquee_in:I

    invoke-static {v0, v1}, Landroid/view/animation/AnimationUtils;->loadAnimation(Landroid/content/Context;I)Landroid/view/animation/Animation;

    move-result-object v0

    const-wide/16 v1, 0x0

    cmp-long v3, p1, v1

    if-lez v3, :cond_2e

    .line 2
    invoke-virtual {v0, p1, p2}, Landroid/view/animation/Animation;->setDuration(J)V

    .line 3
    :cond_2e
    invoke-virtual {p0, v0}, Landroid/widget/ViewFlipper;->setInAnimation(Landroid/view/animation/Animation;)V

    .line 4
    invoke-virtual {p0}, Landroid/widget/ViewFlipper;->getContext()Landroid/content/Context;

    move-result-object v0

    sget v1, Lcom/alibaba/pictures/picturesbiz/R$anim;->damai_marquee_out:I

    invoke-static {v0, v1}, Landroid/view/animation/AnimationUtils;->loadAnimation(Landroid/content/Context;I)Landroid/view/animation/Animation;

    move-result-object v0

    if-lez v3, :cond_40

    .line 5
    invoke-virtual {v0, p1, p2}, Landroid/view/animation/Animation;->setDuration(J)V

    .line 6
    :cond_40
    invoke-virtual {p0, v0}, Landroid/widget/ViewFlipper;->setOutAnimation(Landroid/view/animation/Animation;)V

    return-void
.end method

.method public setItems(Ljava/util/List;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/view/View;",
            ">;)V"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    aput-object p1, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_17
    if-eqz p1, :cond_66

    .line 1
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-nez v0, :cond_20

    goto :goto_66

    .line 2
    :cond_20
    invoke-virtual {p0}, Landroid/widget/ViewFlipper;->removeAllViews()V

    .line 3
    :goto_23
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-ge v3, v0, :cond_54

    .line 4
    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    new-instance v1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView$a;

    invoke-direct {v1, p0, v3, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView$a;-><init>(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;ILjava/util/List;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 5
    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_48

    .line 6
    invoke-virtual {v0}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 7
    :cond_48
    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-virtual {p0, v0}, Landroid/widget/ViewFlipper;->addView(Landroid/view/View;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_23

    .line 8
    :cond_54
    invoke-virtual {p0}, Landroid/widget/ViewFlipper;->isFlipping()Z

    move-result v0

    if-eqz v0, :cond_5d

    .line 9
    invoke-virtual {p0}, Landroid/widget/ViewFlipper;->stopFlipping()V

    .line 10
    :cond_5d
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    if-le p1, v4, :cond_66

    .line 11
    invoke-virtual {p0}, Landroid/widget/ViewFlipper;->startFlipping()V

    :cond_66
    :goto_66
    return-void
.end method

.method public setOnItemClickListener(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView$OnItemClickListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView;->onItemClickListener:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMUpMarqueeView$OnItemClickListener;

    return-void
.end method
