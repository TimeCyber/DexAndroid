.class public Lcn/damai/commonbusiness/calendar/CalendarPopView$e;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/calendar/CalendarPopView;->w()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/calendar/CalendarPopView;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/calendar/CalendarPopView;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$e;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/calendar/CalendarPopView$e;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$e;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->f(Lcn/damai/commonbusiness/calendar/CalendarPopView;Ljava/util/List;)Ljava/util/List;

    .line 2
    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$e;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    const/16 v2, 0xa

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string v6, "\u4e00\u5468\u5185"

    invoke-static/range {v1 .. v6}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->o(Lcn/damai/commonbusiness/calendar/CalendarPopView;ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;)V

    return-void
.end method
