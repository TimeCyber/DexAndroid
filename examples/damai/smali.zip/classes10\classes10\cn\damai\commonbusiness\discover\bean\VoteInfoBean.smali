.class public Lcn/damai/commonbusiness/discover/bean/VoteInfoBean;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon; = null

.field private static final serialVersionUID:J = 0x1L


# instance fields
.field public activityOptions:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/discover/bean/VoteBean;",
            ">;"
        }
    .end annotation
.end field

.field public activityTag:Ljava/lang/String;

.field public backColor:Ljava/lang/String;

.field public circleBackground:Ljava/lang/String;

.field public feedBackground:Ljava/lang/String;

.field public hasVote:Z

.field public id:Ljava/lang/String;

.field public joinTotal:Ljava/lang/String;

.field public name:Ljava/lang/String;

.field public posInFeedList:I

.field public total:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public computeItemProgressIntIfNeed()V
    .registers 10

    sget-object v0, Lcn/damai/commonbusiness/discover/bean/VoteInfoBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/discover/bean/VoteInfoBean;->activityOptions:Ljava/util/List;

    invoke-static {v0}, Ltb/ck5;->d(Ljava/util/Collection;)Z

    move-result v0

    if-nez v0, :cond_55

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/discover/bean/VoteInfoBean;->activityOptions:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_23
    if-ge v1, v0, :cond_55

    .line 3
    iget-object v2, p0, Lcn/damai/commonbusiness/discover/bean/VoteInfoBean;->activityOptions:Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/damai/commonbusiness/discover/bean/VoteBean;

    .line 4
    iput v1, v2, Lcn/damai/commonbusiness/discover/bean/VoteBean;->posInVoteList:I

    .line 5
    iget-boolean v4, p0, Lcn/damai/commonbusiness/discover/bean/VoteInfoBean;->hasVote:Z

    if-eqz v4, :cond_52

    .line 6
    iget-object v4, p0, Lcn/damai/commonbusiness/discover/bean/VoteInfoBean;->total:Ljava/lang/String;

    const-wide/16 v5, 0x0

    invoke-static {v4, v5, v6}, Ltb/yj3;->m(Ljava/lang/String;J)J

    move-result-wide v7

    cmp-long v4, v7, v5

    if-gtz v4, :cond_42

    .line 7
    iput v3, v2, Lcn/damai/commonbusiness/discover/bean/VoteBean;->progressInt:I

    goto :goto_52

    .line 8
    :cond_42
    iget-object v4, v2, Lcn/damai/commonbusiness/discover/bean/VoteBean;->total:Ljava/lang/String;

    invoke-static {v4, v3}, Ltb/yj3;->l(Ljava/lang/String;I)I

    move-result v4

    int-to-float v4, v4

    long-to-float v5, v7

    div-float/2addr v4, v5

    const/high16 v5, 0x42c80000    # 100.0f

    mul-float v4, v4, v5

    float-to-int v4, v4

    .line 9
    iput v4, v2, Lcn/damai/commonbusiness/discover/bean/VoteBean;->progressInt:I

    :cond_52
    :goto_52
    add-int/lit8 v1, v1, 0x1

    goto :goto_23

    :cond_55
    return-void
.end method

.method public getPeopleCountText(Z)Ljava/lang/String;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/discover/bean/VoteInfoBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    return-object p1

    :cond_1e
    if-eqz p1, :cond_59

    .line 1
    iget-object p1, p0, Lcn/damai/commonbusiness/discover/bean/VoteInfoBean;->total:Ljava/lang/String;

    const/4 v0, 0x0

    invoke-static {p1, v0}, Ltb/yj3;->k(Ljava/lang/String;F)F

    move-result p1

    const v0, 0x461c4000    # 10000.0f

    div-float v1, p1, v0

    float-to-double v1, v1

    .line 2
    invoke-static {v1, v2}, Ljava/math/BigDecimal;->valueOf(D)Ljava/math/BigDecimal;

    move-result-object v1

    sget-object v2, Ljava/math/RoundingMode;->HALF_UP:Ljava/math/RoundingMode;

    invoke-virtual {v1, v3, v2}, Ljava/math/BigDecimal;->setScale(ILjava/math/RoundingMode;)Ljava/math/BigDecimal;

    move-result-object v1

    invoke-virtual {v1}, Ljava/math/BigDecimal;->doubleValue()D

    move-result-wide v1

    cmpl-float p1, p1, v0

    if-ltz p1, :cond_56

    .line 3
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, ""

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    const-string v0, "\u4e07"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    .line 4
    :cond_56
    iget-object p1, p0, Lcn/damai/commonbusiness/discover/bean/VoteInfoBean;->total:Ljava/lang/String;

    return-object p1

    .line 5
    :cond_59
    iget-object p1, p0, Lcn/damai/commonbusiness/discover/bean/VoteInfoBean;->joinTotal:Ljava/lang/String;

    return-object p1
.end method

.method public getVoteBgDrawable()Landroid/graphics/drawable/Drawable;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/discover/bean/VoteInfoBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/graphics/drawable/Drawable;

    return-object v0

    :cond_17
    const/high16 v0, -0x1000000

    .line 1
    :try_start_19
    iget-object v1, p0, Lcn/damai/commonbusiness/discover/bean/VoteInfoBean;->feedBackground:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_3c

    iget-object v1, p0, Lcn/damai/commonbusiness/discover/bean/VoteInfoBean;->backColor:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1
    :try_end_27
    .catch Ljava/lang/Exception; {:try_start_19 .. :try_end_27} :catch_5c

    if-nez v1, :cond_3c

    .line 2
    :try_start_29
    iget-object v1, p0, Lcn/damai/commonbusiness/discover/bean/VoteInfoBean;->backColor:Ljava/lang/String;

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1
    :try_end_2f
    .catch Ljava/lang/Exception; {:try_start_29 .. :try_end_2f} :catch_30

    goto :goto_36

    :catch_30
    move-exception v1

    .line 3
    :try_start_31
    invoke-virtual {v1}, Ljava/lang/Exception;->printStackTrace()V

    const/high16 v1, -0x1000000

    .line 4
    :goto_36
    new-instance v2, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {v2, v1}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    return-object v2

    .line 5
    :cond_3c
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x15

    if-lt v1, v2, :cond_4d

    .line 6
    invoke-static {}, Ltb/o52;->a()Landroid/app/Application;

    move-result-object v1

    sget v2, Lcn/damai/commonbusiness/R$drawable;->bg_vote_none_img_shape:I

    invoke-virtual {v1, v2}, Landroid/app/Application;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    return-object v0

    .line 7
    :cond_4d
    invoke-static {}, Ltb/o52;->a()Landroid/app/Application;

    move-result-object v1

    invoke-virtual {v1}, Landroid/app/Application;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    sget v2, Lcn/damai/commonbusiness/R$drawable;->bg_vote_none_img_shape:I

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0
    :try_end_5b
    .catch Ljava/lang/Exception; {:try_start_31 .. :try_end_5b} :catch_5c

    return-object v0

    :catch_5c
    move-exception v1

    .line 8
    invoke-virtual {v1}, Ljava/lang/Exception;->printStackTrace()V

    .line 9
    new-instance v1, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {v1, v0}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    return-object v1
.end method

.method public getVotedItemId()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/discover/bean/VoteInfoBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/discover/bean/VoteInfoBean;->activityOptions:Ljava/util/List;

    invoke-static {v0}, Ltb/ck5;->d(Ljava/util/Collection;)Z

    move-result v0

    if-nez v0, :cond_38

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/discover/bean/VoteInfoBean;->activityOptions:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_25
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_38

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcn/damai/commonbusiness/discover/bean/VoteBean;

    .line 3
    iget-boolean v2, v1, Lcn/damai/commonbusiness/discover/bean/VoteBean;->hasVote:Z

    if-eqz v2, :cond_25

    .line 4
    iget-object v0, v1, Lcn/damai/commonbusiness/discover/bean/VoteBean;->id:Ljava/lang/String;

    return-object v0

    :cond_38
    const/4 v0, 0x0

    return-object v0
.end method
