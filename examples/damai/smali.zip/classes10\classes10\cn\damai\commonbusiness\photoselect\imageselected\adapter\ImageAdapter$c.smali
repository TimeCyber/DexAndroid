.class public Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$c;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;->j(Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$d;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;

.field final synthetic b:Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$d;

.field final synthetic c:Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$d;)V
    .registers 4

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$c;->c:Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;

    iput-object p2, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$c;->a:Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;

    iput-object p3, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$c;->b:Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$d;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$c;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$c;->c:Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;

    invoke-static {p1}, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;->b(Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;)Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$OnItemClickListener;

    move-result-object p1

    if-eqz p1, :cond_4d

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$c;->a:Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;

    invoke-virtual {p1}, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;->getType()Ljava/lang/String;

    move-result-object p1

    const-string v0, "2"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_3c

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$c;->a:Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;

    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$c;->c:Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;->c(Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;)Landroid/app/Activity;

    move-result-object v0

    invoke-virtual {p1, v0}, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;->isImageLimit(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_3c

    return-void

    .line 4
    :cond_3c
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$c;->c:Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;

    invoke-static {p1}, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;->b(Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;)Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$OnItemClickListener;

    move-result-object p1

    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$c;->a:Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;

    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$c;->b:Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$d;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->getAdapterPosition()I

    move-result v1

    invoke-interface {p1, v0, v1}, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter$OnItemClickListener;->OnItemClick(Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;I)V

    :cond_4d
    return-void
.end method
