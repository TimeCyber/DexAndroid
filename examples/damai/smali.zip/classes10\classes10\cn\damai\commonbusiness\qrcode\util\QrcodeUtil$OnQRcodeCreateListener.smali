.class public interface abstract Lcn/damai/commonbusiness/qrcode/util/QrcodeUtil$OnQRcodeCreateListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/qrcode/util/QrcodeUtil;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnQRcodeCreateListener"
.end annotation


# virtual methods
.method public abstract onFailure()V
.end method

.method public abstract onSuccess(Landroid/graphics/Bitmap;)V
.end method
