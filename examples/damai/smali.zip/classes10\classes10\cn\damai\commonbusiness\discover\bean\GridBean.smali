.class public Lcn/damai/commonbusiness/discover/bean/GridBean;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon; = null

.field public static final TYPE_PIC_URL:I = 0x113

.field public static final TYPE_VIDEO_COVER:I = 0x112

.field public static final TYPE_VIDEO_UNDER_REVIEW:I = 0x111


# instance fields
.field public countRightBottomTag:I

.field public formatVideoTime:Ljava/lang/String;

.field public itemCount:I

.field public final picUrl:Ljava/lang/String;

.field public final type:I


# direct methods
.method public constructor <init>(ILjava/lang/String;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    .line 2
    iput v0, p0, Lcn/damai/commonbusiness/discover/bean/GridBean;->countRightBottomTag:I

    .line 3
    iput p1, p0, Lcn/damai/commonbusiness/discover/bean/GridBean;->type:I

    .line 4
    iput-object p2, p0, Lcn/damai/commonbusiness/discover/bean/GridBean;->picUrl:Ljava/lang/String;

    return-void
.end method

.method public static ensureItemCountMemberVar(Ljava/util/List;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/discover/bean/GridBean;",
            ">;)V"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/discover/bean/GridBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    invoke-static {p0}, Ltb/ck5;->d(Ljava/util/Collection;)Z

    move-result v0

    if-nez v0, :cond_31

    .line 2
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    .line 3
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_22
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_31

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcn/damai/commonbusiness/discover/bean/GridBean;

    .line 4
    iput v0, v1, Lcn/damai/commonbusiness/discover/bean/GridBean;->itemCount:I

    goto :goto_22

    :cond_31
    return-void
.end method

.method public static formImgList(Ljava/util/List;)Ljava/util/List;
    .registers 5
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/discover/bean/GridBean;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/discover/bean/GridBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/List;

    return-object p0

    .line 1
    :cond_17
    invoke-static {p0}, Ltb/ck5;->d(Ljava/util/Collection;)Z

    move-result v0

    if-eqz v0, :cond_1f

    const/4 p0, 0x0

    return-object p0

    .line 2
    :cond_1f
    new-instance v0, Ljava/util/ArrayList;

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 3
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_2c
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_43

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 4
    new-instance v2, Lcn/damai/commonbusiness/discover/bean/GridBean;

    const/16 v3, 0x113

    invoke-direct {v2, v3, v1}, Lcn/damai/commonbusiness/discover/bean/GridBean;-><init>(ILjava/lang/String;)V

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_2c

    :cond_43
    return-object v0
.end method

.method public static fromVideo(Lcn/damai/comment/bean/CommentsVideoBean;)Lcn/damai/commonbusiness/discover/bean/GridBean;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/discover/bean/GridBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcn/damai/commonbusiness/discover/bean/GridBean;

    return-object p0

    :cond_17
    const/4 v0, 0x0

    if-eqz p0, :cond_47

    .line 1
    invoke-virtual {p0}, Lcn/damai/comment/bean/CommentsVideoBean;->isVideoStatusUnReview()Z

    move-result v1

    if-eqz v1, :cond_28

    .line 2
    new-instance p0, Lcn/damai/commonbusiness/discover/bean/GridBean;

    const/16 v1, 0x111

    invoke-direct {p0, v1, v0}, Lcn/damai/commonbusiness/discover/bean/GridBean;-><init>(ILjava/lang/String;)V

    return-object p0

    .line 3
    :cond_28
    invoke-virtual {p0}, Lcn/damai/comment/bean/CommentsVideoBean;->getCoverUrl()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_47

    invoke-virtual {p0}, Lcn/damai/comment/bean/CommentsVideoBean;->getUrl()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_47

    .line 4
    invoke-virtual {p0}, Lcn/damai/comment/bean/CommentsVideoBean;->getCoverUrl()Ljava/lang/String;

    move-result-object p0

    .line 5
    new-instance v0, Lcn/damai/commonbusiness/discover/bean/GridBean;

    const/16 v1, 0x112

    invoke-direct {v0, v1, p0}, Lcn/damai/commonbusiness/discover/bean/GridBean;-><init>(ILjava/lang/String;)V

    :cond_47
    return-object v0
.end method

.method public static fromVideo2(Lcn/damai/tetris/component/discover/bean/VideoInfo;)Lcn/damai/commonbusiness/discover/bean/GridBean;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/discover/bean/GridBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcn/damai/commonbusiness/discover/bean/GridBean;

    return-object p0

    :cond_17
    const/4 v0, 0x0

    if-eqz p0, :cond_47

    .line 1
    invoke-virtual {p0}, Lcn/damai/tetris/component/discover/bean/VideoInfo;->isVideoUnderReviewStatus()Z

    move-result v1

    if-eqz v1, :cond_28

    .line 2
    new-instance p0, Lcn/damai/commonbusiness/discover/bean/GridBean;

    const/16 v1, 0x111

    invoke-direct {p0, v1, v0}, Lcn/damai/commonbusiness/discover/bean/GridBean;-><init>(ILjava/lang/String;)V

    return-object p0

    .line 3
    :cond_28
    iget-object v1, p0, Lcn/damai/tetris/component/discover/bean/VideoInfo;->coverUrl:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_47

    iget-object v1, p0, Lcn/damai/tetris/component/discover/bean/VideoInfo;->url:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_47

    .line 4
    new-instance v0, Lcn/damai/commonbusiness/discover/bean/GridBean;

    const/16 v1, 0x112

    iget-object v2, p0, Lcn/damai/tetris/component/discover/bean/VideoInfo;->coverUrl:Ljava/lang/String;

    invoke-direct {v0, v1, v2}, Lcn/damai/commonbusiness/discover/bean/GridBean;-><init>(ILjava/lang/String;)V

    .line 5
    invoke-virtual {p0}, Lcn/damai/tetris/component/discover/bean/VideoInfo;->formatVideoTime()Ljava/lang/String;

    move-result-object p0

    iput-object p0, v0, Lcn/damai/commonbusiness/discover/bean/GridBean;->formatVideoTime:Ljava/lang/String;

    :cond_47
    return-object v0
.end method
