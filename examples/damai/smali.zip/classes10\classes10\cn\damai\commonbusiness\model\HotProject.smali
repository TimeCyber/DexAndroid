.class public Lcn/damai/commonbusiness/model/HotProject;
.super Ljava/lang/Object;
.source "Taobao"


# instance fields
.field public IsXuanZuo:I

.field public Name:Ljava/lang/String;

.field public PriceStr:Ljava/lang/String;

.field public ProjectID:J

.field public ShowTime:Ljava/lang/String;

.field public SiteStatus:I

.field public Summary:Ljava/lang/String;

.field public VenId:I

.field public VenName:Ljava/lang/String;

.field public cityname:Ljava/lang/String;

.field public openSum:I

.field public priceName:Ljava/lang/String;

.field public promotionTags:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public recommendation:Ljava/lang/String;

.field public showFirst:Ljava/lang/String;

.field public showTag:Ljava/lang/String;

.field public tag:Ljava/lang/String;

.field public temp:Ljava/lang/String;

.field public trace_id:Ljava/lang/String;

.field public typeName:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "false"

    .line 2
    iput-object v0, p0, Lcn/damai/commonbusiness/model/HotProject;->showFirst:Ljava/lang/String;

    return-void
.end method
