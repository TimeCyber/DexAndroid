.class public final enum Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;
.super Ljava/lang/Enum;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "CountDownViewGravity"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

.field public static final enum GRAVITY_BOTTOM:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

.field public static final enum GRAVITY_CENTER:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

.field public static final enum GRAVITY_LEFT:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

.field public static final enum GRAVITY_RIGHT:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

.field public static final enum GRAVITY_TOP:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;


# direct methods
.method static constructor <clinit>()V
    .registers 11

    .line 1
    new-instance v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    const-string v1, "GRAVITY_CENTER"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_CENTER:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    .line 2
    new-instance v1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    const-string v3, "GRAVITY_LEFT"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;-><init>(Ljava/lang/String;I)V

    sput-object v1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_LEFT:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    .line 3
    new-instance v3, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    const-string v5, "GRAVITY_RIGHT"

    const/4 v6, 0x2

    invoke-direct {v3, v5, v6}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;-><init>(Ljava/lang/String;I)V

    sput-object v3, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_RIGHT:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    .line 4
    new-instance v5, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    const-string v7, "GRAVITY_TOP"

    const/4 v8, 0x3

    invoke-direct {v5, v7, v8}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;-><init>(Ljava/lang/String;I)V

    sput-object v5, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_TOP:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    .line 5
    new-instance v7, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    const-string v9, "GRAVITY_BOTTOM"

    const/4 v10, 0x4

    invoke-direct {v7, v9, v10}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;-><init>(Ljava/lang/String;I)V

    sput-object v7, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_BOTTOM:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    const/4 v9, 0x5

    new-array v9, v9, [Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    aput-object v0, v9, v2

    aput-object v1, v9, v4

    aput-object v3, v9, v6

    aput-object v5, v9, v8

    aput-object v7, v9, v10

    .line 6
    sput-object v9, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->$VALUES:[Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;
    .registers 2

    .line 1
    const-class v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    return-object p0
.end method

.method public static values()[Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;
    .registers 1

    .line 1
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->$VALUES:[Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    invoke-virtual {v0}, [Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    return-object v0
.end method
