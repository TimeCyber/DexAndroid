.class public interface abstract Lcn/damai/commonbusiness/discover/bean/IFeedProjectBean;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract getAtmospheric()Ljava/lang/String;
.end method

.method public abstract getLiveStatus()I
.end method

.method public abstract getPostPic()Ljava/lang/String;
.end method

.method public abstract getProjectDate()Ljava/lang/String;
.end method

.method public abstract getProjectName()Ljava/lang/String;
.end method

.method public abstract getRankText()Ljava/lang/String;
.end method

.method public abstract getRaw()Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation
.end method

.method public abstract getScoreStar()D
.end method

.method public abstract getShowPrice()Ljava/lang/String;
.end method

.method public abstract getTagList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/discover/bean/TagBean;",
            ">;"
        }
    .end annotation
.end method

.method public abstract isPendingPrice()Z
.end method

.method public abstract isShowVideoIcon()Z
.end method

.method public abstract isShowWannaSeeTag()Z
.end method
