.class public interface abstract Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask2$Listener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "Listener"
.end annotation


# virtual methods
.method public abstract onSuccess(Landroid/widget/ImageView;Landroid/graphics/Bitmap;)V
.end method
