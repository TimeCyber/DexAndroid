.class public interface abstract Lcn/damai/commonbusiness/address/manager/AddressListener;
.super Ljava/lang/Object;
.source "Taobao"


# virtual methods
.method public abstract onAddressListFail(Ljava/lang/String;Ljava/lang/String;)V
.end method

.method public abstract onAddressListSuccess(Lcn/damai/commonbusiness/address/bean/AddressListBean;)V
.end method
