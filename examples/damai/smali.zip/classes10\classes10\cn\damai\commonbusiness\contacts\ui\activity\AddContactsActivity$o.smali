.class public Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$o;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "o"
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private a:Landroid/app/Dialog;

.field final synthetic b:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;


# direct methods
.method public constructor <init>(Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;Landroid/app/Dialog;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$o;->b:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p2, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$o;->a:Landroid/app/Dialog;

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$o;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result p1

    .line 2
    sget v0, Lcom/alibaba/pictures/picturesbiz/R$id;->add_contacts_cancel_btn:I

    if-ne p1, v0, :cond_27

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$o;->a:Landroid/app/Dialog;

    if-eqz p1, :cond_74

    .line 4
    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    goto :goto_74

    .line 5
    :cond_27
    sget v0, Lcom/alibaba/pictures/picturesbiz/R$id;->add_contacts_confirm_btn:I

    if-ne p1, v0, :cond_74

    .line 6
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$o;->b:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;->access$900(Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;)I

    move-result p1

    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$o;->b:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;->access$1000(Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;)I

    move-result v0

    if-eq p1, v0, :cond_6d

    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$o;->b:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;->access$700(Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;)Ljava/util/List;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$o;->b:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;->access$1000(Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;)I

    move-result v0

    if-le p1, v0, :cond_6d

    .line 7
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$o;->b:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;->access$600(Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;)Landroid/widget/TextView;

    move-result-object p1

    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$o;->b:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;->access$700(Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;)Ljava/util/List;

    move-result-object v0

    iget-object v1, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$o;->b:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;

    invoke-static {v1}, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;->access$1000(Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;)I

    move-result v1

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTag(Ljava/lang/Object;)V

    .line 8
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$o;->b:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;->access$1100(Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;)Landroid/os/Handler;

    move-result-object p1

    invoke-virtual {p1, v3}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    .line 9
    :cond_6d
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$o;->a:Landroid/app/Dialog;

    if-eqz p1, :cond_74

    .line 10
    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    :cond_74
    :goto_74
    return-void
.end method
