.class public Lcn/damai/commonbusiness/calendar/bean/CalendarBean;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon; = null

.field public static final DATETYPE_ALL:I = 0x0

.field public static final DATETYPE_FREE:I = 0x5

.field public static final DATETYPE_MONTH:I = 0x4

.field public static final DATETYPE_WEEK:I = 0xa

.field public static final DATETYPE_WEEKEND:I = 0x9

.field public static final NAME_DEFAULT_ALLTIME:Ljava/lang/String; = "\u5168\u90e8\u65f6\u95f4"

.field private static final serialVersionUID:J = 0x57f534df79543912L


# instance fields
.field public calendar:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/calendar/bean/CalendarYearBean;",
            ">;"
        }
    .end annotation
.end field

.field public dateType:Ljava/lang/String;

.field public endDate:Ljava/lang/String;

.field public name:Ljava/lang/String;

.field public startDate:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .registers 3

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->name:Ljava/lang/String;

    .line 4
    iput-object p2, p0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->dateType:Ljava/lang/String;

    return-void
.end method

.method public static defaultAllTime()Lcn/damai/commonbusiness/calendar/bean/CalendarBean;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;

    return-object v0

    .line 1
    :cond_14
    new-instance v0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;

    const-string v1, "\u5168\u90e8\u65f6\u95f4"

    const-string v2, "0"

    invoke-direct {v0, v1, v2}, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    return-object v0
.end method

.method public static friday2SunDay()Lcn/damai/commonbusiness/calendar/bean/CalendarBean;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;

    return-object v0

    .line 1
    :cond_14
    new-instance v0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;

    const-string v1, "\u672c\u5468\u672b"

    const-string v2, "9"

    invoke-direct {v0, v1, v2}, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    return-object v0
.end method

.method public static to30Days()Lcn/damai/commonbusiness/calendar/bean/CalendarBean;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;

    return-object v0

    .line 1
    :cond_14
    new-instance v0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;

    const-string v1, "\u4e00\u6708\u5185"

    const-string v2, "4"

    invoke-direct {v0, v1, v2}, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    return-object v0
.end method

.method public static to7days()Lcn/damai/commonbusiness/calendar/bean/CalendarBean;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;

    return-object v0

    .line 1
    :cond_14
    new-instance v0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;

    const-string v1, "\u4e00\u5468\u5185"

    const-string v2, "10"

    invoke-direct {v0, v1, v2}, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    return-object v0
.end method

.method public static transfer2ConstantCalendarBeanIfCann(Lcn/damai/commonbusiness/calendar/bean/CalendarBean;)Lcn/damai/commonbusiness/calendar/bean/CalendarBean;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "7"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;

    return-object p0

    .line 1
    :cond_17
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 2
    invoke-static {}, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->defaultAllTime()Lcn/damai/commonbusiness/calendar/bean/CalendarBean;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 3
    invoke-static {}, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->to7days()Lcn/damai/commonbusiness/calendar/bean/CalendarBean;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 4
    invoke-static {}, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->to30Days()Lcn/damai/commonbusiness/calendar/bean/CalendarBean;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 5
    invoke-static {}, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->friday2SunDay()Lcn/damai/commonbusiness/calendar/bean/CalendarBean;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 6
    invoke-interface {v0, p0}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v1

    if-ltz v1, :cond_44

    .line 7
    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;

    :cond_44
    return-object p0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    return p1

    :cond_1e
    if-ne p0, p1, :cond_21

    return v3

    :cond_21
    if-eqz p1, :cond_51

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    if-eq v0, v1, :cond_2e

    goto :goto_51

    .line 2
    :cond_2e
    check-cast p1, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->dateType:Ljava/lang/String;

    iget-object v1, p1, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->dateType:Ljava/lang/String;

    invoke-static {v0, v1}, Ltb/lk3;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4f

    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->startDate:Ljava/lang/String;

    iget-object v1, p1, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->startDate:Ljava/lang/String;

    invoke-static {v0, v1}, Ltb/lk3;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4f

    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->endDate:Ljava/lang/String;

    iget-object p1, p1, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->endDate:Ljava/lang/String;

    invoke-static {v0, p1}, Ltb/lk3;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_4f

    goto :goto_50

    :cond_4f
    const/4 v3, 0x0

    :goto_50
    return v3

    :cond_51
    :goto_51
    return v4
.end method

.method public hashCode()I
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_1b

    new-array v2, v3, [Ljava/lang/Object;

    aput-object p0, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0

    :cond_1b
    const/4 v0, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    .line 1
    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->dateType:Ljava/lang/String;

    aput-object v1, v0, v4

    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->startDate:Ljava/lang/String;

    aput-object v1, v0, v3

    const/4 v1, 0x2

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/bean/CalendarBean;->endDate:Ljava/lang/String;

    aput-object v2, v0, v1

    invoke-static {v0}, Ltb/lk3;->b([Ljava/lang/Object;)I

    move-result v0

    return v0
.end method
