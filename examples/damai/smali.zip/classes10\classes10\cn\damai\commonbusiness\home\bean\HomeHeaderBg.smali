.class public Lcn/damai/commonbusiness/home/bean/HomeHeaderBg;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x333f85b387c2370L


# instance fields
.field public categoryId:Ljava/lang/String;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public headBackgroudPic:Ljava/lang/String;

.field public headColor:Ljava/lang/String;

.field public headLottie:Lcn/damai/commonbusiness/home/bean/HeadLottieBean;

.field public type:I

.field public weiyiId:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lcn/damai/commonbusiness/home/bean/HomeTabBean;Ljava/lang/String;Ljava/lang/String;)V
    .registers 5

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-eqz p1, :cond_d

    .line 8
    iget-object v0, p1, Lcn/damai/commonbusiness/home/bean/HomeTabBean;->categoryId:Ljava/lang/String;

    iput-object v0, p0, Lcn/damai/commonbusiness/home/bean/HomeHeaderBg;->categoryId:Ljava/lang/String;

    .line 9
    iget p1, p1, Lcn/damai/commonbusiness/home/bean/HomeTabBean;->type:I

    iput p1, p0, Lcn/damai/commonbusiness/home/bean/HomeHeaderBg;->type:I

    .line 10
    :cond_d
    iput-object p2, p0, Lcn/damai/commonbusiness/home/bean/HomeHeaderBg;->headBackgroudPic:Ljava/lang/String;

    .line 11
    iput-object p3, p0, Lcn/damai/commonbusiness/home/bean/HomeHeaderBg;->headColor:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V
    .registers 5

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iput-object p1, p0, Lcn/damai/commonbusiness/home/bean/HomeHeaderBg;->categoryId:Ljava/lang/String;

    .line 4
    iput p2, p0, Lcn/damai/commonbusiness/home/bean/HomeHeaderBg;->type:I

    .line 5
    iput-object p3, p0, Lcn/damai/commonbusiness/home/bean/HomeHeaderBg;->headBackgroudPic:Ljava/lang/String;

    .line 6
    iput-object p4, p0, Lcn/damai/commonbusiness/home/bean/HomeHeaderBg;->headColor:Ljava/lang/String;

    return-void
.end method
