.class public interface abstract Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter$OnFolderSelectListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnFolderSelectListener"
.end annotation


# virtual methods
.method public abstract OnFolderSelect(Ltb/ww1;)I
.end method

.method public abstract OnFolderSelect(I)V
.end method
