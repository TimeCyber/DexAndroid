.class public Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;
.super Landroid/widget/FrameLayout;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$OnStreetDivisionChangedListener;,
        Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$OnStreetDivisionSelectedListener;
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private isScrolling:Z

.field private mOnCompletedClickListener:Landroid/view/View$OnClickListener;

.field private mOnStreetDivisionChangedListener:Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$OnStreetDivisionChangedListener;

.field private mOnStreetDivisionSelectedListener:Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$OnStreetDivisionSelectedListener;

.field private mOnStreetWheelScrollListener:Lcn/damai/uikit/wheel/OnWheelScrollListener;

.field private mSelectedStreet:Lcn/damai/commonbusiness/address/bean/DivisionBean;

.field private mStreetDivisionAdapter:Ltb/t81;

.field private mStreetDivisionList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/address/bean/DivisionBean;",
            ">;"
        }
    .end annotation
.end field

.field private mTvCancel:Landroid/widget/TextView;

.field private mTvConfirm:Landroid/widget/TextView;

.field private mWheelViewStreet:Lcn/damai/uikit/wheel/WheelView;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 2
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->init(Landroid/content/Context;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 3
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .line 3
    invoke-direct {p0, p1, p2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 4
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->init(Landroid/content/Context;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .line 5
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 6
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->init(Landroid/content/Context;)V

    return-void
.end method

.method static synthetic access$000(Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;)Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$OnStreetDivisionSelectedListener;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mOnStreetDivisionSelectedListener:Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$OnStreetDivisionSelectedListener;

    return-object p0
.end method

.method static synthetic access$100(Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;)Lcn/damai/commonbusiness/address/bean/DivisionBean;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mSelectedStreet:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    return-object p0
.end method

.method static synthetic access$102(Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;Lcn/damai/commonbusiness/address/bean/DivisionBean;)Lcn/damai/commonbusiness/address/bean/DivisionBean;
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mSelectedStreet:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    return-object p1
.end method

.method static synthetic access$200(Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;)Z
    .registers 1

    .line 1
    iget-boolean p0, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->isScrolling:Z

    return p0
.end method

.method static synthetic access$202(Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;Z)Z
    .registers 2

    .line 1
    iput-boolean p1, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->isScrolling:Z

    return p1
.end method

.method static synthetic access$300(Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;)Ljava/util/List;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mStreetDivisionList:Ljava/util/List;

    return-object p0
.end method

.method private getSelectedDivisionIndex(Ljava/util/List;Lcn/damai/commonbusiness/address/bean/DivisionBean;)I
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/address/bean/DivisionBean;",
            ">;",
            "Lcn/damai/commonbusiness/address/bean/DivisionBean;",
            ")I"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "8"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_21

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    return p1

    :cond_21
    if-eqz p2, :cond_4a

    .line 1
    invoke-virtual {p2}, Lcn/damai/commonbusiness/address/bean/DivisionBean;->getDivisionId()Ljava/lang/String;

    move-result-object p2

    .line 2
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_4a

    .line 3
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_32
    if-ge v1, v0, :cond_4a

    .line 4
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/damai/commonbusiness/address/bean/DivisionBean;

    if-eqz v2, :cond_47

    .line 5
    invoke-virtual {v2}, Lcn/damai/commonbusiness/address/bean/DivisionBean;->getDivisionId()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p2, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_47

    return v1

    :cond_47
    add-int/lit8 v1, v1, 0x1

    goto :goto_32

    :cond_4a
    return v3
.end method

.method private init(Landroid/content/Context;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p1

    sget v0, Lcom/alibaba/pictures/picturesbiz/R$layout;->common_business_select_street_division_layout:I

    invoke-virtual {p1, v0, p0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    .line 2
    sget p1, Lcom/alibaba/pictures/picturesbiz/R$id;->common_business_street_select_cancel_tv:I

    invoke-virtual {p0, p1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mTvCancel:Landroid/widget/TextView;

    .line 3
    sget p1, Lcom/alibaba/pictures/picturesbiz/R$id;->common_business_street_select_completed_tv:I

    invoke-virtual {p0, p1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mTvConfirm:Landroid/widget/TextView;

    .line 4
    sget p1, Lcom/alibaba/pictures/picturesbiz/R$id;->common_business_street_wheel_view:I

    invoke-virtual {p0, p1}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Lcn/damai/uikit/wheel/WheelView;

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mWheelViewStreet:Lcn/damai/uikit/wheel/WheelView;

    .line 5
    invoke-direct {p0}, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->initListeners()V

    .line 6
    invoke-direct {p0}, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->setupListeners()V

    return-void
.end method

.method private initListeners()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    new-instance v0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$a;

    invoke-direct {v0, p0}, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$a;-><init>(Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;)V

    iput-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mOnCompletedClickListener:Landroid/view/View$OnClickListener;

    .line 2
    new-instance v0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$b;

    invoke-direct {v0, p0}, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$b;-><init>(Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;)V

    iput-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mOnStreetWheelScrollListener:Lcn/damai/uikit/wheel/OnWheelScrollListener;

    return-void
.end method

.method private setupListeners()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mTvConfirm:Landroid/widget/TextView;

    iget-object v1, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mOnCompletedClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mWheelViewStreet:Lcn/damai/uikit/wheel/WheelView;

    iget-object v1, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mOnStreetWheelScrollListener:Lcn/damai/uikit/wheel/OnWheelScrollListener;

    invoke-virtual {v0, v1}, Lcn/damai/uikit/wheel/WheelView;->addScrollingListener(Lcn/damai/uikit/wheel/OnWheelScrollListener;)V

    return-void
.end method


# virtual methods
.method public setOnCancelClickListener(Landroid/view/View$OnClickListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mTvCancel:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method public setOnStreetDivisionChangedListener(Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$OnStreetDivisionChangedListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "7"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mOnStreetDivisionChangedListener:Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$OnStreetDivisionChangedListener;

    return-void
.end method

.method public setOnStreetDivisionSelectedListener(Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$OnStreetDivisionSelectedListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mOnStreetDivisionSelectedListener:Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$OnStreetDivisionSelectedListener;

    return-void
.end method

.method public setStreetDivisionList(Ljava/util/List;Lcn/damai/commonbusiness/address/bean/DivisionBean;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/address/bean/DivisionBean;",
            ">;",
            "Lcn/damai/commonbusiness/address/bean/DivisionBean;",
            ")V"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_1a
    if-eqz p1, :cond_55

    .line 1
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-lez v0, :cond_55

    .line 2
    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mStreetDivisionList:Ljava/util/List;

    .line 3
    new-instance p1, Ltb/t81;

    invoke-virtual {p0}, Landroid/widget/FrameLayout;->getContext()Landroid/content/Context;

    move-result-object v0

    iget-object v1, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mStreetDivisionList:Ljava/util/List;

    invoke-direct {p1, v0, v1}, Ltb/t81;-><init>(Landroid/content/Context;Ljava/util/List;)V

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mStreetDivisionAdapter:Ltb/t81;

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mWheelViewStreet:Lcn/damai/uikit/wheel/WheelView;

    invoke-virtual {v0, p1}, Lcn/damai/uikit/wheel/WheelView;->setViewAdapter(Lcn/damai/uikit/wheel/adapters/WheelViewAdapter;)V

    .line 5
    iget-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mStreetDivisionList:Ljava/util/List;

    invoke-direct {p0, p1, p2}, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->getSelectedDivisionIndex(Ljava/util/List;Lcn/damai/commonbusiness/address/bean/DivisionBean;)I

    move-result p1

    .line 6
    iget-object p2, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mWheelViewStreet:Lcn/damai/uikit/wheel/WheelView;

    invoke-virtual {p2, p1}, Lcn/damai/uikit/wheel/WheelView;->setCurrentItem(I)V

    .line 7
    iget-object p2, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mStreetDivisionList:Ljava/util/List;

    invoke-interface {p2, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/address/bean/DivisionBean;

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mSelectedStreet:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    .line 8
    iget-object p2, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mOnStreetDivisionChangedListener:Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$OnStreetDivisionChangedListener;

    if-eqz p2, :cond_71

    if-eqz p1, :cond_71

    .line 9
    invoke-interface {p2, p1}, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView$OnStreetDivisionChangedListener;->onStreetDivisionChanged(Lcn/damai/commonbusiness/address/bean/DivisionBean;)V

    goto :goto_71

    :cond_55
    const/4 p1, 0x0

    .line 10
    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mSelectedStreet:Lcn/damai/commonbusiness/address/bean/DivisionBean;

    .line 11
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mStreetDivisionList:Ljava/util/List;

    .line 12
    new-instance p1, Ltb/t81;

    invoke-virtual {p0}, Landroid/widget/FrameLayout;->getContext()Landroid/content/Context;

    move-result-object p2

    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mStreetDivisionList:Ljava/util/List;

    invoke-direct {p1, p2, v0}, Ltb/t81;-><init>(Landroid/content/Context;Ljava/util/List;)V

    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mStreetDivisionAdapter:Ltb/t81;

    .line 13
    iget-object p2, p0, Lcn/damai/commonbusiness/address/view/AddressStreetSelectView;->mWheelViewStreet:Lcn/damai/uikit/wheel/WheelView;

    invoke-virtual {p2, p1}, Lcn/damai/uikit/wheel/WheelView;->setViewAdapter(Lcn/damai/uikit/wheel/adapters/WheelViewAdapter;)V

    :cond_71
    :goto_71
    return-void
.end method
