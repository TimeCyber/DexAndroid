.class public Lcn/damai/commonbusiness/poplayer/DMLayerMgrAdapter$1;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/poplayer/DMLayerMgrAdapter;->initializeConfigContainer(Lcom/alibaba/poplayer/layermanager/e;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private mRetryCount:I

.field final synthetic this$0:Lcn/damai/commonbusiness/poplayer/DMLayerMgrAdapter;

.field final synthetic val$layerManager:Lcom/alibaba/poplayer/layermanager/e;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/poplayer/DMLayerMgrAdapter;Lcom/alibaba/poplayer/layermanager/e;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/poplayer/DMLayerMgrAdapter$1;->this$0:Lcn/damai/commonbusiness/poplayer/DMLayerMgrAdapter;

    iput-object p2, p0, Lcn/damai/commonbusiness/poplayer/DMLayerMgrAdapter$1;->val$layerManager:Lcom/alibaba/poplayer/layermanager/e;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p1, 0x0

    .line 2
    iput p1, p0, Lcn/damai/commonbusiness/poplayer/DMLayerMgrAdapter$1;->mRetryCount:I

    return-void
.end method


# virtual methods
.method public run()V
    .registers 6

    const-string v0, "orange_fucking_silly_bug"

    const-string v1, "DMPopLayer"

    sget-object v2, Lcn/damai/commonbusiness/poplayer/DMLayerMgrAdapter$1;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v3, "1"

    invoke-static {v2, v3}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_18

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v1, 0x0

    aput-object p0, v0, v1

    invoke-interface {v2, v3, v0}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_18
    :try_start_18
    iget v2, p0, Lcn/damai/commonbusiness/poplayer/DMLayerMgrAdapter$1;->mRetryCount:I

    add-int/lit8 v3, v2, 0x1

    iput v3, p0, Lcn/damai/commonbusiness/poplayer/DMLayerMgrAdapter$1;->mRetryCount:I

    const/16 v3, 0xa

    if-le v2, v3, :cond_28

    const-string v0, "TBFaceAdapter$Runnable.run.retry.upToLimit"

    .line 2
    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    .line 3
    :cond_28
    invoke-static {}, Lcom/taobao/orange/OrangeConfig;->getInstance()Lcom/taobao/orange/OrangeConfig;

    move-result-object v2

    const-string v3, "android_layermanager"

    const-string v4, "layer_manager_config"

    invoke-virtual {v2, v3, v4, v0}, Lcom/taobao/orange/OrangeConfig;->getConfig(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 4
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4b

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/poplayer/DMLayerMgrAdapter$1;->this$0:Lcn/damai/commonbusiness/poplayer/DMLayerMgrAdapter;

    invoke-static {v0}, Lcn/damai/commonbusiness/poplayer/DMLayerMgrAdapter;->a(Lcn/damai/commonbusiness/poplayer/DMLayerMgrAdapter;)Landroid/os/Handler;

    move-result-object v0

    const-wide/16 v2, 0x3e8

    invoke-virtual {v0, p0, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    const-string v0, "TBFaceAdapter$Runnable.run.retry"

    .line 6
    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    .line 7
    :cond_4b
    iget-object v0, p0, Lcn/damai/commonbusiness/poplayer/DMLayerMgrAdapter$1;->val$layerManager:Lcom/alibaba/poplayer/layermanager/e;

    invoke-virtual {v0}, Lcom/alibaba/poplayer/layermanager/e;->n()V

    const-string v0, "TBFaceAdapter$Runnable.run.configurationGetted:)"

    .line 8
    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_55
    .catchall {:try_start_18 .. :try_end_55} :catchall_56

    goto :goto_5b

    :catchall_56
    const-string v0, "TBFaceAdapter$Runnable.run.continuousGetConfiguration.fail"

    .line 9
    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :goto_5b
    return-void
.end method
