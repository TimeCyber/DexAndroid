.class public final enum Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$VideoType;
.super Ljava/lang/Enum;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "VideoType"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$VideoType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$VideoType;

.field public static final enum VIDEO_URL:Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$VideoType;

.field public static final enum VIDEO_VID:Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$VideoType;


# direct methods
.method static constructor <clinit>()V
    .registers 5

    .line 1
    new-instance v0, Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$VideoType;

    const-string v1, "VIDEO_VID"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$VideoType;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$VideoType;->VIDEO_VID:Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$VideoType;

    .line 2
    new-instance v1, Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$VideoType;

    const-string v3, "VIDEO_URL"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4}, Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$VideoType;-><init>(Ljava/lang/String;I)V

    sput-object v1, Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$VideoType;->VIDEO_URL:Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$VideoType;

    const/4 v3, 0x2

    new-array v3, v3, [Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$VideoType;

    aput-object v0, v3, v2

    aput-object v1, v3, v4

    .line 3
    sput-object v3, Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$VideoType;->$VALUES:[Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$VideoType;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$VideoType;
    .registers 2

    .line 1
    const-class v0, Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$VideoType;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$VideoType;

    return-object p0
.end method

.method public static values()[Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$VideoType;
    .registers 1

    .line 1
    sget-object v0, Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$VideoType;->$VALUES:[Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$VideoType;

    invoke-virtual {v0}, [Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$VideoType;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$VideoType;

    return-object v0
.end method
