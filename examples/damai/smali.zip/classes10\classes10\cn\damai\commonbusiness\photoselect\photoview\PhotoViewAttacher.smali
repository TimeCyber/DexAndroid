.class public Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnLayoutChangeListener;
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;,
        Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon; = null

.field private static E:F = 3.0f

.field private static F:F = 1.75f

.field private static G:F = 1.0f

.field private static H:I = 0xc8

.field private static I:I = 0x1


# instance fields
.field private A:F

.field private B:Z

.field private C:Landroid/widget/ImageView$ScaleType;

.field private D:Lcn/damai/commonbusiness/photoselect/photoview/OnGestureListener;

.field private a:Landroid/view/animation/Interpolator;

.field private b:I

.field private c:F

.field private d:F

.field private e:F

.field private f:Z

.field private g:Z

.field private h:Landroid/widget/ImageView;

.field private i:Landroid/view/GestureDetector;

.field private j:Lcn/damai/commonbusiness/photoselect/photoview/a;

.field private final k:Landroid/graphics/Matrix;

.field private final l:Landroid/graphics/Matrix;

.field private final m:Landroid/graphics/Matrix;

.field private final n:Landroid/graphics/RectF;

.field private final o:[F

.field private p:Lcn/damai/commonbusiness/photoselect/photoview/OnMatrixChangedListener;

.field private q:Lcn/damai/commonbusiness/photoselect/photoview/OnPhotoTapListener;

.field private r:Lcn/damai/commonbusiness/photoselect/photoview/OnOutsidePhotoTapListener;

.field private s:Lcn/damai/commonbusiness/photoselect/photoview/OnViewTapListener;

.field private t:Landroid/view/View$OnClickListener;

.field private u:Landroid/view/View$OnLongClickListener;

.field private v:Lcn/damai/commonbusiness/photoselect/photoview/OnScaleChangedListener;

.field private w:Lcn/damai/commonbusiness/photoselect/photoview/OnSingleFlingListener;

.field private x:Lcn/damai/commonbusiness/photoselect/photoview/OnViewDragListener;

.field private y:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;

.field private z:I


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>(Landroid/widget/ImageView;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Landroid/view/animation/AccelerateDecelerateInterpolator;

    invoke-direct {v0}, Landroid/view/animation/AccelerateDecelerateInterpolator;-><init>()V

    iput-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->a:Landroid/view/animation/Interpolator;

    .line 3
    sget v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->H:I

    iput v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->b:I

    .line 4
    sget v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->G:F

    iput v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->c:F

    .line 5
    sget v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->F:F

    iput v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->d:F

    .line 6
    sget v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->E:F

    iput v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->e:F

    const/4 v0, 0x1

    .line 7
    iput-boolean v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->f:Z

    const/4 v1, 0x0

    .line 8
    iput-boolean v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->g:Z

    .line 9
    new-instance v1, Landroid/graphics/Matrix;

    invoke-direct {v1}, Landroid/graphics/Matrix;-><init>()V

    iput-object v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->k:Landroid/graphics/Matrix;

    .line 10
    new-instance v1, Landroid/graphics/Matrix;

    invoke-direct {v1}, Landroid/graphics/Matrix;-><init>()V

    iput-object v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->l:Landroid/graphics/Matrix;

    .line 11
    new-instance v1, Landroid/graphics/Matrix;

    invoke-direct {v1}, Landroid/graphics/Matrix;-><init>()V

    iput-object v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->m:Landroid/graphics/Matrix;

    .line 12
    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    iput-object v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->n:Landroid/graphics/RectF;

    const/16 v1, 0x9

    new-array v1, v1, [F

    .line 13
    iput-object v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->o:[F

    const/4 v1, 0x2

    .line 14
    iput v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->z:I

    .line 15
    iput-boolean v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->B:Z

    .line 16
    sget-object v0, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    iput-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->C:Landroid/widget/ImageView$ScaleType;

    .line 17
    new-instance v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$a;

    invoke-direct {v0, p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$a;-><init>(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)V

    iput-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->D:Lcn/damai/commonbusiness/photoselect/photoview/OnGestureListener;

    .line 18
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->h:Landroid/widget/ImageView;

    .line 19
    invoke-virtual {p1, p0}, Landroid/widget/ImageView;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 20
    invoke-virtual {p1, p0}, Landroid/widget/ImageView;->addOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    .line 21
    invoke-virtual {p1}, Landroid/widget/ImageView;->isInEditMode()Z

    move-result v0

    if-eqz v0, :cond_61

    return-void

    :cond_61
    const/4 v0, 0x0

    .line 22
    iput v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->A:F

    .line 23
    new-instance v0, Lcn/damai/commonbusiness/photoselect/photoview/a;

    invoke-virtual {p1}, Landroid/widget/ImageView;->getContext()Landroid/content/Context;

    move-result-object v1

    iget-object v2, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->D:Lcn/damai/commonbusiness/photoselect/photoview/OnGestureListener;

    invoke-direct {v0, v1, v2}, Lcn/damai/commonbusiness/photoselect/photoview/a;-><init>(Landroid/content/Context;Lcn/damai/commonbusiness/photoselect/photoview/OnGestureListener;)V

    iput-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->j:Lcn/damai/commonbusiness/photoselect/photoview/a;

    .line 24
    new-instance v0, Landroid/view/GestureDetector;

    invoke-virtual {p1}, Landroid/widget/ImageView;->getContext()Landroid/content/Context;

    move-result-object p1

    new-instance v1, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$b;

    invoke-direct {v1, p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$b;-><init>(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)V

    invoke-direct {v0, p1, v1}, Landroid/view/GestureDetector;-><init>(Landroid/content/Context;Landroid/view/GestureDetector$OnGestureListener;)V

    iput-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->i:Landroid/view/GestureDetector;

    .line 25
    new-instance p1, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;

    invoke-direct {p1, p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;-><init>(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)V

    invoke-virtual {v0, p1}, Landroid/view/GestureDetector;->setOnDoubleTapListener(Landroid/view/GestureDetector$OnDoubleTapListener;)V

    return-void
.end method

.method private A()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "51"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->y:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;

    if-eqz v0, :cond_1e

    .line 2
    invoke-virtual {v0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;->cancelFling()V

    const/4 v0, 0x0

    .line 3
    iput-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->y:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;

    :cond_1e
    return-void
.end method

.method private B()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "45"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    invoke-direct {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->C()Z

    move-result v0

    if-eqz v0, :cond_21

    .line 2
    invoke-direct {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->G()Landroid/graphics/Matrix;

    move-result-object v0

    invoke-direct {p0, v0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->W(Landroid/graphics/Matrix;)V

    :cond_21
    return-void
.end method

.method private C()Z
    .registers 13

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "48"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_1b

    new-array v2, v4, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    return v0

    .line 1
    :cond_1b
    invoke-direct {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->G()Landroid/graphics/Matrix;

    move-result-object v0

    invoke-direct {p0, v0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->F(Landroid/graphics/Matrix;)Landroid/graphics/RectF;

    move-result-object v0

    if-nez v0, :cond_26

    return v3

    .line 2
    :cond_26
    invoke-virtual {v0}, Landroid/graphics/RectF;->height()F

    move-result v1

    invoke-virtual {v0}, Landroid/graphics/RectF;->width()F

    move-result v2

    .line 3
    iget-object v5, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->h:Landroid/widget/ImageView;

    invoke-direct {p0, v5}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->I(Landroid/widget/ImageView;)I

    move-result v5

    int-to-float v5, v5

    const/high16 v6, 0x40000000    # 2.0f

    const/4 v7, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x0

    cmpg-float v10, v1, v5

    if-gtz v10, :cond_59

    .line 4
    sget-object v10, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$d;->a:[I

    iget-object v11, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->C:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v11}, Landroid/widget/ImageView$ScaleType;->ordinal()I

    move-result v11

    aget v10, v10, v11

    if-eq v10, v8, :cond_56

    if-eq v10, v7, :cond_51

    sub-float/2addr v5, v1

    div-float/2addr v5, v6

    .line 5
    iget v1, v0, Landroid/graphics/RectF;->top:F

    goto :goto_54

    :cond_51
    sub-float/2addr v5, v1

    .line 6
    iget v1, v0, Landroid/graphics/RectF;->top:F

    :goto_54
    sub-float/2addr v5, v1

    goto :goto_69

    .line 7
    :cond_56
    iget v1, v0, Landroid/graphics/RectF;->top:F

    goto :goto_5f

    .line 8
    :cond_59
    iget v1, v0, Landroid/graphics/RectF;->top:F

    cmpl-float v10, v1, v9

    if-lez v10, :cond_61

    :goto_5f
    neg-float v5, v1

    goto :goto_69

    .line 9
    :cond_61
    iget v1, v0, Landroid/graphics/RectF;->bottom:F

    cmpg-float v10, v1, v5

    if-gez v10, :cond_68

    goto :goto_54

    :cond_68
    const/4 v5, 0x0

    .line 10
    :goto_69
    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->h:Landroid/widget/ImageView;

    invoke-direct {p0, v1}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->J(Landroid/widget/ImageView;)I

    move-result v1

    int-to-float v1, v1

    cmpg-float v10, v2, v1

    if-gtz v10, :cond_94

    .line 11
    sget-object v3, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$d;->a:[I

    iget-object v9, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->C:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v9}, Landroid/widget/ImageView$ScaleType;->ordinal()I

    move-result v9

    aget v3, v3, v9

    if-eq v3, v8, :cond_8d

    if-eq v3, v7, :cond_87

    sub-float/2addr v1, v2

    div-float/2addr v1, v6

    .line 12
    iget v0, v0, Landroid/graphics/RectF;->left:F

    goto :goto_8a

    :cond_87
    sub-float/2addr v1, v2

    .line 13
    iget v0, v0, Landroid/graphics/RectF;->left:F

    :goto_8a
    sub-float/2addr v1, v0

    move v9, v1

    goto :goto_91

    .line 14
    :cond_8d
    iget v0, v0, Landroid/graphics/RectF;->left:F

    neg-float v0, v0

    move v9, v0

    .line 15
    :goto_91
    iput v8, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->z:I

    goto :goto_ac

    .line 16
    :cond_94
    iget v2, v0, Landroid/graphics/RectF;->left:F

    cmpl-float v6, v2, v9

    if-lez v6, :cond_9e

    .line 17
    iput v3, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->z:I

    neg-float v9, v2

    goto :goto_ac

    .line 18
    :cond_9e
    iget v0, v0, Landroid/graphics/RectF;->right:F

    cmpg-float v2, v0, v1

    if-gez v2, :cond_a9

    sub-float v9, v1, v0

    .line 19
    iput v4, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->z:I

    goto :goto_ac

    :cond_a9
    const/4 v0, -0x1

    .line 20
    iput v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->z:I

    .line 21
    :goto_ac
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->m:Landroid/graphics/Matrix;

    invoke-virtual {v0, v9, v5}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    return v4
.end method

.method private F(Landroid/graphics/Matrix;)Landroid/graphics/RectF;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "46"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/graphics/RectF;

    return-object p1

    .line 1
    :cond_1a
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->h:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-eqz v0, :cond_3a

    .line 2
    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->n:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v2

    int-to-float v2, v2

    .line 3
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v0

    int-to-float v0, v0

    const/4 v3, 0x0

    .line 4
    invoke-virtual {v1, v3, v3, v2, v0}, Landroid/graphics/RectF;->set(FFFF)V

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->n:Landroid/graphics/RectF;

    invoke-virtual {p1, v0}, Landroid/graphics/Matrix;->mapRect(Landroid/graphics/RectF;)Z

    .line 6
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->n:Landroid/graphics/RectF;

    return-object p1

    :cond_3a
    const/4 p1, 0x0

    return-object p1
.end method

.method private G()Landroid/graphics/Matrix;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "39"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/graphics/Matrix;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->l:Landroid/graphics/Matrix;

    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->k:Landroid/graphics/Matrix;

    invoke-virtual {v0, v1}, Landroid/graphics/Matrix;->set(Landroid/graphics/Matrix;)V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->l:Landroid/graphics/Matrix;

    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->m:Landroid/graphics/Matrix;

    invoke-virtual {v0, v1}, Landroid/graphics/Matrix;->postConcat(Landroid/graphics/Matrix;)Z

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->l:Landroid/graphics/Matrix;

    return-object v0
.end method

.method private I(Landroid/widget/ImageView;)I
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "50"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    return p1

    .line 1
    :cond_1e
    invoke-virtual {p1}, Landroid/widget/ImageView;->getHeight()I

    move-result v0

    invoke-virtual {p1}, Landroid/widget/ImageView;->getPaddingTop()I

    move-result v1

    sub-int/2addr v0, v1

    invoke-virtual {p1}, Landroid/widget/ImageView;->getPaddingBottom()I

    move-result p1

    sub-int/2addr v0, p1

    return v0
.end method

.method private J(Landroid/widget/ImageView;)I
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "49"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    return p1

    .line 1
    :cond_1e
    invoke-virtual {p1}, Landroid/widget/ImageView;->getWidth()I

    move-result v0

    invoke-virtual {p1}, Landroid/widget/ImageView;->getPaddingLeft()I

    move-result v1

    sub-int/2addr v0, v1

    invoke-virtual {p1}, Landroid/widget/ImageView;->getPaddingRight()I

    move-result p1

    sub-int/2addr v0, p1

    return v0
.end method

.method private Q(Landroid/graphics/Matrix;I)F
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "42"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_25

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Float;

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    return p1

    .line 1
    :cond_25
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->o:[F

    invoke-virtual {p1, v0}, Landroid/graphics/Matrix;->getValues([F)V

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->o:[F

    aget p1, p1, p2

    return p1
.end method

.method private T()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "43"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->m:Landroid/graphics/Matrix;

    invoke-virtual {v0}, Landroid/graphics/Matrix;->reset()V

    .line 2
    iget v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->A:F

    invoke-virtual {p0, v0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->k0(F)V

    .line 3
    invoke-direct {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->G()Landroid/graphics/Matrix;

    move-result-object v0

    invoke-direct {p0, v0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->W(Landroid/graphics/Matrix;)V

    .line 4
    invoke-direct {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->C()Z

    return-void
.end method

.method private W(Landroid/graphics/Matrix;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "44"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->h:Landroid/widget/ImageView;

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setImageMatrix(Landroid/graphics/Matrix;)V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->p:Lcn/damai/commonbusiness/photoselect/photoview/OnMatrixChangedListener;

    if-eqz v0, :cond_2b

    .line 3
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->F(Landroid/graphics/Matrix;)Landroid/graphics/RectF;

    move-result-object p1

    if-eqz p1, :cond_2b

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->p:Lcn/damai/commonbusiness/photoselect/photoview/OnMatrixChangedListener;

    invoke-interface {v0, p1}, Lcn/damai/commonbusiness/photoselect/photoview/OnMatrixChangedListener;->onMatrixChanged(Landroid/graphics/RectF;)V

    :cond_2b
    return-void
.end method

.method static synthetic a(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Lcn/damai/commonbusiness/photoselect/photoview/a;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->j:Lcn/damai/commonbusiness/photoselect/photoview/a;

    return-object p0
.end method

.method static synthetic b(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Lcn/damai/commonbusiness/photoselect/photoview/OnViewDragListener;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->x:Lcn/damai/commonbusiness/photoselect/photoview/OnViewDragListener;

    return-object p0
.end method

.method static synthetic c(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;Landroid/widget/ImageView;)I
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->I(Landroid/widget/ImageView;)I

    move-result p0

    return p0
.end method

.method static synthetic d(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)F
    .registers 1

    .line 1
    iget p0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->e:F

    return p0
.end method

.method static synthetic e(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)F
    .registers 1

    .line 1
    iget p0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->c:F

    return p0
.end method

.method static synthetic f(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Lcn/damai/commonbusiness/photoselect/photoview/OnScaleChangedListener;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->v:Lcn/damai/commonbusiness/photoselect/photoview/OnScaleChangedListener;

    return-object p0
.end method

.method static synthetic g(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Landroid/view/View$OnLongClickListener;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->u:Landroid/view/View$OnLongClickListener;

    return-object p0
.end method

.method static synthetic h(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Lcn/damai/commonbusiness/photoselect/photoview/OnSingleFlingListener;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->w:Lcn/damai/commonbusiness/photoselect/photoview/OnSingleFlingListener;

    return-object p0
.end method

.method static synthetic i()F
    .registers 1

    .line 1
    sget v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->G:F

    return v0
.end method

.method static synthetic j()I
    .registers 1

    .line 1
    sget v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->I:I

    return v0
.end method

.method static synthetic k(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Landroid/view/View$OnClickListener;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->t:Landroid/view/View$OnClickListener;

    return-object p0
.end method

.method static synthetic l(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Lcn/damai/commonbusiness/photoselect/photoview/OnViewTapListener;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->s:Lcn/damai/commonbusiness/photoselect/photoview/OnViewTapListener;

    return-object p0
.end method

.method static synthetic m(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Landroid/graphics/Matrix;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->m:Landroid/graphics/Matrix;

    return-object p0
.end method

.method static synthetic n(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Lcn/damai/commonbusiness/photoselect/photoview/OnPhotoTapListener;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->q:Lcn/damai/commonbusiness/photoselect/photoview/OnPhotoTapListener;

    return-object p0
.end method

.method static synthetic o(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Lcn/damai/commonbusiness/photoselect/photoview/OnOutsidePhotoTapListener;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->r:Lcn/damai/commonbusiness/photoselect/photoview/OnOutsidePhotoTapListener;

    return-object p0
.end method

.method static synthetic p(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Lcn/damai/commonbusiness/photoselect/photoview/OnGestureListener;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->D:Lcn/damai/commonbusiness/photoselect/photoview/OnGestureListener;

    return-object p0
.end method

.method static synthetic q(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)I
    .registers 1

    .line 1
    iget p0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->b:I

    return p0
.end method

.method static synthetic r(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Landroid/view/animation/Interpolator;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->a:Landroid/view/animation/Interpolator;

    return-object p0
.end method

.method static synthetic s(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->B()V

    return-void
.end method

.method static synthetic t(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Landroid/widget/ImageView;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->h:Landroid/widget/ImageView;

    return-object p0
.end method

.method static synthetic u(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Z
    .registers 1

    .line 1
    iget-boolean p0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->f:Z

    return p0
.end method

.method private u0(Landroid/graphics/drawable/Drawable;)V
    .registers 12

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "47"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eqz v2, :cond_17

    new-array v2, v4, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_17
    if-nez p1, :cond_1a

    return-void

    .line 1
    :cond_1a
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->h:Landroid/widget/ImageView;

    invoke-direct {p0, v0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->J(Landroid/widget/ImageView;)I

    move-result v0

    int-to-float v0, v0

    .line 2
    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->h:Landroid/widget/ImageView;

    invoke-direct {p0, v1}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->I(Landroid/widget/ImageView;)I

    move-result v1

    int-to-float v1, v1

    .line 3
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v2

    .line 4
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result p1

    .line 5
    iget-object v5, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->k:Landroid/graphics/Matrix;

    invoke-virtual {v5}, Landroid/graphics/Matrix;->reset()V

    int-to-float v2, v2

    div-float v5, v0, v2

    int-to-float p1, p1

    div-float v6, v1, p1

    .line 6
    iget-object v7, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->C:Landroid/widget/ImageView$ScaleType;

    sget-object v8, Landroid/widget/ImageView$ScaleType;->CENTER:Landroid/widget/ImageView$ScaleType;

    const/high16 v9, 0x40000000    # 2.0f

    if-ne v7, v8, :cond_4e

    .line 7
    iget-object v3, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->k:Landroid/graphics/Matrix;

    sub-float/2addr v0, v2

    div-float/2addr v0, v9

    sub-float/2addr v1, p1

    div-float/2addr v1, v9

    invoke-virtual {v3, v0, v1}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    goto/16 :goto_d5

    .line 8
    :cond_4e
    sget-object v8, Landroid/widget/ImageView$ScaleType;->CENTER_CROP:Landroid/widget/ImageView$ScaleType;

    if-ne v7, v8, :cond_69

    .line 9
    invoke-static {v5, v6}, Ljava/lang/Math;->max(FF)F

    move-result v3

    .line 10
    iget-object v4, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->k:Landroid/graphics/Matrix;

    invoke-virtual {v4, v3, v3}, Landroid/graphics/Matrix;->postScale(FF)Z

    .line 11
    iget-object v4, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->k:Landroid/graphics/Matrix;

    mul-float v2, v2, v3

    sub-float/2addr v0, v2

    div-float/2addr v0, v9

    mul-float p1, p1, v3

    sub-float/2addr v1, p1

    div-float/2addr v1, v9

    invoke-virtual {v4, v0, v1}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    goto :goto_d5

    .line 12
    :cond_69
    sget-object v8, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    if-ne v7, v8, :cond_8a

    const/high16 v3, 0x3f800000    # 1.0f

    .line 13
    invoke-static {v5, v6}, Ljava/lang/Math;->min(FF)F

    move-result v4

    invoke-static {v3, v4}, Ljava/lang/Math;->min(FF)F

    move-result v3

    .line 14
    iget-object v4, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->k:Landroid/graphics/Matrix;

    invoke-virtual {v4, v3, v3}, Landroid/graphics/Matrix;->postScale(FF)Z

    .line 15
    iget-object v4, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->k:Landroid/graphics/Matrix;

    mul-float v2, v2, v3

    sub-float/2addr v0, v2

    div-float/2addr v0, v9

    mul-float p1, p1, v3

    sub-float/2addr v1, p1

    div-float/2addr v1, v9

    invoke-virtual {v4, v0, v1}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    goto :goto_d5

    .line 16
    :cond_8a
    new-instance v5, Landroid/graphics/RectF;

    const/4 v6, 0x0

    invoke-direct {v5, v6, v6, v2, p1}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 17
    new-instance v7, Landroid/graphics/RectF;

    invoke-direct {v7, v6, v6, v0, v1}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 18
    iget v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->A:F

    float-to-int v0, v0

    rem-int/lit16 v0, v0, 0xb4

    if-eqz v0, :cond_a1

    .line 19
    new-instance v5, Landroid/graphics/RectF;

    invoke-direct {v5, v6, v6, p1, v2}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 20
    :cond_a1
    sget-object p1, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$d;->a:[I

    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->C:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v0}, Landroid/widget/ImageView$ScaleType;->ordinal()I

    move-result v0

    aget p1, p1, v0

    if-eq p1, v3, :cond_ce

    if-eq p1, v4, :cond_c6

    const/4 v0, 0x3

    if-eq p1, v0, :cond_be

    const/4 v0, 0x4

    if-eq p1, v0, :cond_b6

    goto :goto_d5

    .line 21
    :cond_b6
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->k:Landroid/graphics/Matrix;

    sget-object v0, Landroid/graphics/Matrix$ScaleToFit;->FILL:Landroid/graphics/Matrix$ScaleToFit;

    invoke-virtual {p1, v5, v7, v0}, Landroid/graphics/Matrix;->setRectToRect(Landroid/graphics/RectF;Landroid/graphics/RectF;Landroid/graphics/Matrix$ScaleToFit;)Z

    goto :goto_d5

    .line 22
    :cond_be
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->k:Landroid/graphics/Matrix;

    sget-object v0, Landroid/graphics/Matrix$ScaleToFit;->END:Landroid/graphics/Matrix$ScaleToFit;

    invoke-virtual {p1, v5, v7, v0}, Landroid/graphics/Matrix;->setRectToRect(Landroid/graphics/RectF;Landroid/graphics/RectF;Landroid/graphics/Matrix$ScaleToFit;)Z

    goto :goto_d5

    .line 23
    :cond_c6
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->k:Landroid/graphics/Matrix;

    sget-object v0, Landroid/graphics/Matrix$ScaleToFit;->START:Landroid/graphics/Matrix$ScaleToFit;

    invoke-virtual {p1, v5, v7, v0}, Landroid/graphics/Matrix;->setRectToRect(Landroid/graphics/RectF;Landroid/graphics/RectF;Landroid/graphics/Matrix$ScaleToFit;)Z

    goto :goto_d5

    .line 24
    :cond_ce
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->k:Landroid/graphics/Matrix;

    sget-object v0, Landroid/graphics/Matrix$ScaleToFit;->CENTER:Landroid/graphics/Matrix$ScaleToFit;

    invoke-virtual {p1, v5, v7, v0}, Landroid/graphics/Matrix;->setRectToRect(Landroid/graphics/RectF;Landroid/graphics/RectF;Landroid/graphics/Matrix$ScaleToFit;)Z

    .line 25
    :goto_d5
    invoke-direct {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->T()V

    return-void
.end method

.method static synthetic v(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Z
    .registers 1

    .line 1
    iget-boolean p0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->g:Z

    return p0
.end method

.method static synthetic w(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)I
    .registers 1

    .line 1
    iget p0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->z:I

    return p0
.end method

.method static synthetic x(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->y:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;

    return-object p0
.end method

.method static synthetic y(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;)Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->y:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$FlingRunnable;

    return-object p1
.end method

.method static synthetic z(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;Landroid/widget/ImageView;)I
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->J(Landroid/widget/ImageView;)I

    move-result p0

    return p0
.end method


# virtual methods
.method public D(Landroid/graphics/Matrix;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "37"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-direct {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->G()Landroid/graphics/Matrix;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/graphics/Matrix;->set(Landroid/graphics/Matrix;)V

    return-void
.end method

.method public E()Landroid/graphics/RectF;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/graphics/RectF;

    return-object v0

    .line 1
    :cond_17
    invoke-direct {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->C()Z

    .line 2
    invoke-direct {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->G()Landroid/graphics/Matrix;

    move-result-object v0

    invoke-direct {p0, v0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->F(Landroid/graphics/Matrix;)Landroid/graphics/RectF;

    move-result-object v0

    return-object v0
.end method

.method public H()Landroid/graphics/Matrix;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "40"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/graphics/Matrix;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->l:Landroid/graphics/Matrix;

    return-object v0
.end method

.method public K()F
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "12"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Float;

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->e:F

    return v0
.end method

.method public L()F
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "11"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Float;

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->d:F

    return v0
.end method

.method public M()F
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "10"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Float;

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->c:F

    return v0
.end method

.method public N()F
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "13"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Float;

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->m:Landroid/graphics/Matrix;

    invoke-direct {p0, v0, v3}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->Q(Landroid/graphics/Matrix;I)F

    move-result v0

    float-to-double v0, v0

    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v0

    double-to-float v0, v0

    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->m:Landroid/graphics/Matrix;

    const/4 v4, 0x3

    invoke-direct {p0, v1, v4}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->Q(Landroid/graphics/Matrix;I)F

    move-result v1

    float-to-double v4, v1

    invoke-static {v4, v5, v2, v3}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v1

    double-to-float v1, v1

    add-float/2addr v0, v1

    float-to-double v0, v0

    invoke-static {v0, v1}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v0

    double-to-float v0, v0

    return v0
.end method

.method public O()Landroid/widget/ImageView$ScaleType;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "14"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView$ScaleType;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->C:Landroid/widget/ImageView$ScaleType;

    return-object v0
.end method

.method public P(Landroid/graphics/Matrix;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "38"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->m:Landroid/graphics/Matrix;

    invoke-virtual {p1, v0}, Landroid/graphics/Matrix;->set(Landroid/graphics/Matrix;)V

    return-void
.end method

.method public R()Z
    .registers 5
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget-boolean v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->B:Z

    return v0
.end method

.method public S()Z
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "34"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget-boolean v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->B:Z

    return v0
.end method

.method public U(Z)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "17"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iput-boolean p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->f:Z

    return-void
.end method

.method public V(Landroid/graphics/Matrix;)Z
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    return p1

    :cond_1e
    if-eqz p1, :cond_32

    .line 1
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->h:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-nez v0, :cond_29

    return v4

    .line 2
    :cond_29
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->m:Landroid/graphics/Matrix;

    invoke-virtual {v0, p1}, Landroid/graphics/Matrix;->set(Landroid/graphics/Matrix;)V

    .line 3
    invoke-direct {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->B()V

    return v3

    .line 4
    :cond_32
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "Matrix cannot be null"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public X(F)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "20"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iget v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->c:F

    iget v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->d:F

    invoke-static {v0, v1, p1}, Lcn/damai/commonbusiness/photoselect/photoview/b;->a(FFF)V

    .line 2
    iput p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->e:F

    return-void
.end method

.method public Y(F)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "19"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iget v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->c:F

    iget v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->e:F

    invoke-static {v0, p1, v1}, Lcn/damai/commonbusiness/photoselect/photoview/b;->a(FFF)V

    .line 2
    iput p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->d:F

    return-void
.end method

.method public Z(F)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "18"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iget v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->d:F

    iget v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->e:F

    invoke-static {p1, v0, v1}, Lcn/damai/commonbusiness/photoselect/photoview/b;->a(FFF)V

    .line 2
    iput p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->c:F

    return-void
.end method

.method public a0(Landroid/view/View$OnClickListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "23"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->t:Landroid/view/View$OnClickListener;

    return-void
.end method

.method public b0(Landroid/view/GestureDetector$OnDoubleTapListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->i:Landroid/view/GestureDetector;

    invoke-virtual {v0, p1}, Landroid/view/GestureDetector;->setOnDoubleTapListener(Landroid/view/GestureDetector$OnDoubleTapListener;)V

    return-void
.end method

.method public c0(Landroid/view/View$OnLongClickListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "22"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->u:Landroid/view/View$OnLongClickListener;

    return-void
.end method

.method public d0(Lcn/damai/commonbusiness/photoselect/photoview/OnMatrixChangedListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "24"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->p:Lcn/damai/commonbusiness/photoselect/photoview/OnMatrixChangedListener;

    return-void
.end method

.method public e0(Lcn/damai/commonbusiness/photoselect/photoview/OnOutsidePhotoTapListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "26"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->r:Lcn/damai/commonbusiness/photoselect/photoview/OnOutsidePhotoTapListener;

    return-void
.end method

.method public f0(Lcn/damai/commonbusiness/photoselect/photoview/OnPhotoTapListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "25"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->q:Lcn/damai/commonbusiness/photoselect/photoview/OnPhotoTapListener;

    return-void
.end method

.method public g0(Lcn/damai/commonbusiness/photoselect/photoview/OnScaleChangedListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->v:Lcn/damai/commonbusiness/photoselect/photoview/OnScaleChangedListener;

    return-void
.end method

.method public h0(Lcn/damai/commonbusiness/photoselect/photoview/OnSingleFlingListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->w:Lcn/damai/commonbusiness/photoselect/photoview/OnSingleFlingListener;

    return-void
.end method

.method public i0(Lcn/damai/commonbusiness/photoselect/photoview/OnViewDragListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "28"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->x:Lcn/damai/commonbusiness/photoselect/photoview/OnViewDragListener;

    return-void
.end method

.method public j0(Lcn/damai/commonbusiness/photoselect/photoview/OnViewTapListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "27"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->s:Lcn/damai/commonbusiness/photoselect/photoview/OnViewTapListener;

    return-void
.end method

.method public k0(F)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "9"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->m:Landroid/graphics/Matrix;

    const/high16 v1, 0x43b40000    # 360.0f

    rem-float/2addr p1, v1

    invoke-virtual {v0, p1}, Landroid/graphics/Matrix;->postRotate(F)Z

    .line 2
    invoke-direct {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->B()V

    return-void
.end method

.method public l0(F)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "8"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->m:Landroid/graphics/Matrix;

    const/high16 v1, 0x43b40000    # 360.0f

    rem-float/2addr p1, v1

    invoke-virtual {v0, p1}, Landroid/graphics/Matrix;->setRotate(F)V

    .line 2
    invoke-direct {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->B()V

    return-void
.end method

.method public m0(F)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "29"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    invoke-virtual {p0, p1, v3}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->o0(FZ)V

    return-void
.end method

.method public n0(FFFZ)V
    .registers 12

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "31"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_30

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_30
    iget v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->c:F

    cmpg-float v0, p1, v0

    if-ltz v0, :cond_5b

    iget v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->e:F

    cmpl-float v0, p1, v0

    if-gtz v0, :cond_5b

    if-eqz p4, :cond_52

    .line 2
    iget-object p4, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->h:Landroid/widget/ImageView;

    new-instance v6, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;

    invoke-virtual {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->N()F

    move-result v2

    move-object v0, v6

    move-object v1, p0

    move v3, p1

    move v4, p2

    move v5, p3

    invoke-direct/range {v0 .. v5}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;-><init>(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;FFFF)V

    invoke-virtual {p4, v6}, Landroid/widget/ImageView;->post(Ljava/lang/Runnable;)Z

    goto :goto_5a

    .line 3
    :cond_52
    iget-object p4, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->m:Landroid/graphics/Matrix;

    invoke-virtual {p4, p1, p1, p2, p3}, Landroid/graphics/Matrix;->setScale(FFFF)V

    .line 4
    invoke-direct {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->B()V

    :goto_5a
    return-void

    .line 5
    :cond_5b
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "Scale must be within the range of minScale and maxScale"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public o0(FZ)V
    .registers 8

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "30"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x2

    if-eqz v2, :cond_22

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    const/4 v4, 0x1

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    aput-object p1, v2, v4

    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_22
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->h:Landroid/widget/ImageView;

    .line 2
    invoke-virtual {v0}, Landroid/widget/ImageView;->getRight()I

    move-result v0

    div-int/2addr v0, v3

    int-to-float v0, v0

    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->h:Landroid/widget/ImageView;

    .line 3
    invoke-virtual {v1}, Landroid/widget/ImageView;->getBottom()I

    move-result v1

    div-int/2addr v1, v3

    int-to-float v1, v1

    .line 4
    invoke-virtual {p0, p1, v0, v1, p2}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->n0(FFFZ)V

    return-void
.end method

.method public onLayoutChange(Landroid/view/View;IIIIIIII)V
    .registers 14

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "15"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_52

    const/16 v2, 0xa

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x5

    invoke-static {p5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x6

    invoke-static {p6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x7

    invoke-static {p7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/16 p1, 0x8

    invoke-static {p8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/16 p1, 0x9

    invoke-static {p9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_52
    if-ne p2, p6, :cond_5a

    if-ne p3, p7, :cond_5a

    if-ne p4, p8, :cond_5a

    if-eq p5, p9, :cond_63

    .line 1
    :cond_5a
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->h:Landroid/widget/ImageView;

    invoke-virtual {p1}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->u0(Landroid/graphics/drawable/Drawable;)V

    :cond_63
    return-void
.end method

.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .registers 15

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "16"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v2, :cond_21

    new-array v2, v3, [Ljava/lang/Object;

    aput-object p0, v2, v4

    aput-object p1, v2, v5

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    return p1

    .line 1
    :cond_21
    iget-boolean v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->B:Z

    if-eqz v0, :cond_dc

    move-object v0, p1

    check-cast v0, Landroid/widget/ImageView;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/photoview/b;->c(Landroid/widget/ImageView;)Z

    move-result v0

    if-eqz v0, :cond_dc

    .line 2
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    if-eqz v0, :cond_8c

    if-eq v0, v5, :cond_39

    if-eq v0, v3, :cond_39

    goto :goto_98

    .line 3
    :cond_39
    invoke-virtual {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->N()F

    move-result v0

    iget v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->c:F

    cmpg-float v0, v0, v1

    if-gez v0, :cond_62

    .line 4
    invoke-virtual {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->E()Landroid/graphics/RectF;

    move-result-object v0

    if-eqz v0, :cond_98

    .line 5
    new-instance v1, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;

    invoke-virtual {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->N()F

    move-result v8

    iget v9, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->c:F

    .line 6
    invoke-virtual {v0}, Landroid/graphics/RectF;->centerX()F

    move-result v10

    invoke-virtual {v0}, Landroid/graphics/RectF;->centerY()F

    move-result v11

    move-object v6, v1

    move-object v7, p0

    invoke-direct/range {v6 .. v11}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;-><init>(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;FFFF)V

    .line 7
    invoke-virtual {p1, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    goto :goto_8a

    .line 8
    :cond_62
    invoke-virtual {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->N()F

    move-result v0

    iget v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->e:F

    cmpl-float v0, v0, v1

    if-lez v0, :cond_98

    .line 9
    invoke-virtual {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->E()Landroid/graphics/RectF;

    move-result-object v0

    if-eqz v0, :cond_98

    .line 10
    new-instance v1, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;

    invoke-virtual {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->N()F

    move-result v8

    iget v9, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->e:F

    .line 11
    invoke-virtual {v0}, Landroid/graphics/RectF;->centerX()F

    move-result v10

    invoke-virtual {v0}, Landroid/graphics/RectF;->centerY()F

    move-result v11

    move-object v6, v1

    move-object v7, p0

    invoke-direct/range {v6 .. v11}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$AnimatedZoomRunnable;-><init>(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;FFFF)V

    .line 12
    invoke-virtual {p1, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :goto_8a
    const/4 p1, 0x1

    goto :goto_99

    .line 13
    :cond_8c
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    if-eqz p1, :cond_95

    .line 14
    invoke-interface {p1, v5}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 15
    :cond_95
    invoke-direct {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->A()V

    :cond_98
    :goto_98
    const/4 p1, 0x0

    .line 16
    :goto_99
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->j:Lcn/damai/commonbusiness/photoselect/photoview/a;

    if-eqz v0, :cond_d0

    .line 17
    invoke-virtual {v0}, Lcn/damai/commonbusiness/photoselect/photoview/a;->e()Z

    move-result p1

    .line 18
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->j:Lcn/damai/commonbusiness/photoselect/photoview/a;

    invoke-virtual {v0}, Lcn/damai/commonbusiness/photoselect/photoview/a;->d()Z

    move-result v0

    .line 19
    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->j:Lcn/damai/commonbusiness/photoselect/photoview/a;

    invoke-virtual {v1, p2}, Lcn/damai/commonbusiness/photoselect/photoview/a;->f(Landroid/view/MotionEvent;)Z

    move-result v1

    if-nez p1, :cond_b9

    .line 20
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->j:Lcn/damai/commonbusiness/photoselect/photoview/a;

    invoke-virtual {p1}, Lcn/damai/commonbusiness/photoselect/photoview/a;->e()Z

    move-result p1

    if-nez p1, :cond_b9

    const/4 p1, 0x1

    goto :goto_ba

    :cond_b9
    const/4 p1, 0x0

    :goto_ba
    if-nez v0, :cond_c6

    .line 21
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->j:Lcn/damai/commonbusiness/photoselect/photoview/a;

    invoke-virtual {v0}, Lcn/damai/commonbusiness/photoselect/photoview/a;->d()Z

    move-result v0

    if-nez v0, :cond_c6

    const/4 v0, 0x1

    goto :goto_c7

    :cond_c6
    const/4 v0, 0x0

    :goto_c7
    if-eqz p1, :cond_cc

    if-eqz v0, :cond_cc

    const/4 v4, 0x1

    .line 22
    :cond_cc
    iput-boolean v4, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->g:Z

    move v4, v1

    goto :goto_d1

    :cond_d0
    move v4, p1

    .line 23
    :goto_d1
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->i:Landroid/view/GestureDetector;

    if-eqz p1, :cond_dc

    invoke-virtual {p1, p2}, Landroid/view/GestureDetector;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    if-eqz p1, :cond_dc

    const/4 v4, 0x1

    :cond_dc
    return v4
.end method

.method public p0(FFF)V
    .registers 8

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "21"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_29

    const/4 v2, 0x4

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_29
    invoke-static {p1, p2, p3}, Lcn/damai/commonbusiness/photoselect/photoview/b;->a(FFF)V

    .line 2
    iput p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->c:F

    .line 3
    iput p2, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->d:F

    .line 4
    iput p3, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->e:F

    return-void
.end method

.method public q0(Landroid/widget/ImageView$ScaleType;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "33"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-static {p1}, Lcn/damai/commonbusiness/photoselect/photoview/b;->d(Landroid/widget/ImageView$ScaleType;)Z

    move-result v0

    if-eqz v0, :cond_26

    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->C:Landroid/widget/ImageView$ScaleType;

    if-eq p1, v0, :cond_26

    .line 2
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->C:Landroid/widget/ImageView$ScaleType;

    .line 3
    invoke-virtual {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->t0()V

    :cond_26
    return-void
.end method

.method public r0(I)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "41"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iput p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->b:I

    return-void
.end method

.method public s0(Z)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "35"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iput-boolean p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->B:Z

    .line 2
    invoke-virtual {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->t0()V

    return-void
.end method

.method public t0()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "36"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-boolean v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->B:Z

    if-eqz v0, :cond_22

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->h:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-direct {p0, v0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->u0(Landroid/graphics/drawable/Drawable;)V

    goto :goto_25

    .line 3
    :cond_22
    invoke-direct {p0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->T()V

    :goto_25
    return-void
.end method
