.class public interface abstract Lcn/damai/commonbusiness/address/api/AddressApi;
.super Ljava/lang/Object;
.source "Taobao"


# static fields
.field public static final API_ADD_ADDRESS:Ljava/lang/String; = "mtop.damai.wireless.user.shippingaddress.add"

.field public static final API_GET_ADDRESS_LIST:Ljava/lang/String; = "mtop.damai.wireless.user.shippingaddress.getUserAddressList"

.field public static final API_MODIFY_ADDRESS:Ljava/lang/String; = "mtop.damai.wireless.user.shippingaddress.modify"

.field public static final API_PHONE_ALLOWABLE_QUERY:Ljava/lang/String; = "mtop.damai.wireless.user.phone.allowable.query"

.field public static final API_RETRIEVE_DIVISION_CHILDREN:Ljava/lang/String; = "mtop.damai.maitix.division.getdisivionchildrenspecial"
