.class public Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter$a;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter;->b(Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter$b;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:I

.field final synthetic b:Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter;I)V
    .registers 3

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter$a;->b:Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter;

    iput p2, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter$a;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter$a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter$a;->b:Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter$a;->b:Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter;

    invoke-static {p1}, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter;->a(Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter;)Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter$OnFolderSelectListener;

    move-result-object p1

    if-eqz p1, :cond_2f

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter$a;->b:Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter;

    invoke-static {p1}, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter;->a(Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter;)Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter$OnFolderSelectListener;

    move-result-object p1

    iget v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter$a;->a:I

    invoke-interface {p1, v0}, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/FolderAdapter$OnFolderSelectListener;->OnFolderSelect(I)V

    :cond_2f
    return-void
.end method
