.class public Lcn/damai/commonbusiness/poplayer/DMConfigAdapter$1;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/poplayer/DMConfigAdapter;->initializeConfigContainer(Landroid/content/Context;Lcom/alibaba/poplayer/PopLayer;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private mRetryCount:I

.field final synthetic this$0:Lcn/damai/commonbusiness/poplayer/DMConfigAdapter;

.field final synthetic val$popLayer:Lcom/alibaba/poplayer/PopLayer;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/poplayer/DMConfigAdapter;Lcom/alibaba/poplayer/PopLayer;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/poplayer/DMConfigAdapter$1;->this$0:Lcn/damai/commonbusiness/poplayer/DMConfigAdapter;

    iput-object p2, p0, Lcn/damai/commonbusiness/poplayer/DMConfigAdapter$1;->val$popLayer:Lcom/alibaba/poplayer/PopLayer;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p1, 0x0

    .line 2
    iput p1, p0, Lcn/damai/commonbusiness/poplayer/DMConfigAdapter$1;->mRetryCount:I

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    const-string v0, "orange_fucking_silly_bug"

    sget-object v1, Lcn/damai/commonbusiness/poplayer/DMConfigAdapter$1;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v2, "1"

    invoke-static {v1, v2}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_16

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v0, v3

    invoke-interface {v1, v2, v0}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_16
    :try_start_16
    iget v1, p0, Lcn/damai/commonbusiness/poplayer/DMConfigAdapter$1;->mRetryCount:I

    add-int/lit8 v2, v1, 0x1

    iput v2, p0, Lcn/damai/commonbusiness/poplayer/DMConfigAdapter$1;->mRetryCount:I

    const/16 v2, 0xa

    if-le v1, v2, :cond_21

    return-void

    .line 2
    :cond_21
    invoke-static {}, Lcom/taobao/orange/OrangeConfig;->getInstance()Lcom/taobao/orange/OrangeConfig;

    move-result-object v1

    iget-object v2, p0, Lcn/damai/commonbusiness/poplayer/DMConfigAdapter$1;->this$0:Lcn/damai/commonbusiness/poplayer/DMConfigAdapter;

    invoke-static {v2}, Lcn/damai/commonbusiness/poplayer/DMConfigAdapter;->a(Lcn/damai/commonbusiness/poplayer/DMConfigAdapter;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "anyone"

    invoke-virtual {v1, v2, v3, v0}, Lcom/taobao/orange/OrangeConfig;->getConfig(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 3
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_43

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/poplayer/DMConfigAdapter$1;->this$0:Lcn/damai/commonbusiness/poplayer/DMConfigAdapter;

    invoke-static {v0}, Lcn/damai/commonbusiness/poplayer/DMConfigAdapter;->b(Lcn/damai/commonbusiness/poplayer/DMConfigAdapter;)Landroid/os/Handler;

    move-result-object v0

    const-wide/16 v1, 0x3e8

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    .line 5
    :cond_43
    iget-object v0, p0, Lcn/damai/commonbusiness/poplayer/DMConfigAdapter$1;->val$popLayer:Lcom/alibaba/poplayer/PopLayer;

    iget-object v1, p0, Lcn/damai/commonbusiness/poplayer/DMConfigAdapter$1;->this$0:Lcn/damai/commonbusiness/poplayer/DMConfigAdapter;

    invoke-static {v1}, Lcn/damai/commonbusiness/poplayer/DMConfigAdapter;->c(Lcn/damai/commonbusiness/poplayer/DMConfigAdapter;)I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/alibaba/poplayer/PopLayer;->updateCacheConfigAsync(I)V
    :try_end_4e
    .catchall {:try_start_16 .. :try_end_4e} :catchall_4e

    :catchall_4e
    return-void
.end method
