.class Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$d;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "d"
.end annotation


# static fields
.field private static final a:Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;-><init>(Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$1;)V

    sput-object v0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$d;->a:Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;

    return-void
.end method

.method static synthetic a()Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;
    .registers 1

    .line 1
    sget-object v0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$d;->a:Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;

    return-object v0
.end method
