.class public final Lcn/damai/commonbusiness/R$raw;
.super Ljava/lang/Object;
.source "Taobao"


# static fields
.field public static final anim_first_like:I = 0x7f110000

.field public static final anim_first_like_pioneer:I = 0x7f110001

.field public static final artist_city_want:I = 0x7f110002

.field public static final artist_city_want_cancel:I = 0x7f110003

.field public static final artist_city_want_cancel_pioneer:I = 0x7f110004

.field public static final artist_city_want_cancel_pioneer_white:I = 0x7f110005

.field public static final artist_city_want_cancel_white:I = 0x7f110006

.field public static final artist_city_want_pioneer:I = 0x7f110007

.field public static final artist_city_want_pioneer_white:I = 0x7f110008

.field public static final artist_city_want_white:I = 0x7f110009

.field public static final artist_component_config:I = 0x7f11000a

.field public static final bottom_tip_heart_pop:I = 0x7f11000b

.field public static final bricks_circle_allround:I = 0x7f11000c

.field public static final bricks_circle_allround_pioneer:I = 0x7f11000d

.field public static final bricks_dm_home_cms_local_data:I = 0x7f11000e

.field public static final bricks_new_person_gift_top_lottie:I = 0x7f11000f

.field public static final bricks_uikit_loading_color:I = 0x7f110010

.field public static final common_loading:I = 0x7f110012

.field public static final components:I = 0x7f110013

.field public static final damai_coupon_search_component_config:I = 0x7f110015

.field public static final damai_pioneer_search_result_tab_list:I = 0x7f110016

.field public static final damai_search_all_tab_component_config:I = 0x7f110017

.field public static final damai_search_component_config:I = 0x7f110018

.field public static final damai_search_result_tab_list:I = 0x7f110019

.field public static final default_channel_tab:I = 0x7f11001c

.field public static final default_channel_tab_merger:I = 0x7f11001d

.field public static final default_tab_category_normal2selected:I = 0x7f11001f

.field public static final default_tab_category_selected2normal:I = 0x7f110020

.field public static final default_tab_find_normal2selected:I = 0x7f110021

.field public static final default_tab_find_selected2normal:I = 0x7f110022

.field public static final default_tab_home_normal2selected:I = 0x7f110023

.field public static final default_tab_home_selected2normal:I = 0x7f110024

.field public static final default_tab_home_selected2top:I = 0x7f110025

.field public static final default_tab_home_top2normal:I = 0x7f110026

.field public static final default_tab_home_top2selected:I = 0x7f110027

.field public static final default_tab_mine_normal2selected:I = 0x7f110028

.field public static final default_tab_mine_selected2normal:I = 0x7f110029

.field public static final default_tab_ticklet_normal2selected:I = 0x7f11002a

.field public static final default_tab_ticklet_selected2normal:I = 0x7f11002b

.field public static final dicovery_cid_home_head_banner:I = 0x7f11002c

.field public static final dicovery_cid_home_head_pic:I = 0x7f11002d

.field public static final dm_artist_fans_ranking:I = 0x7f11002e

.field public static final dm_artist_main_official_content:I = 0x7f11002f

.field public static final dm_artist_main_yuehua_content:I = 0x7f110030

.field public static final dm_artist_shop_item:I = 0x7f110031

.field public static final dm_artist_tour_info:I = 0x7f110032

.field public static final dm_artist_vip_buy_show:I = 0x7f110033

.field public static final dm_artists_head_default:I = 0x7f110034

.field public static final dm_artists_head_special:I = 0x7f110035

.field public static final dm_artists_head_update:I = 0x7f110036

.field public static final dm_banner_row1_girl:I = 0x7f110037

.field public static final dm_banner_videoheader_ip:I = 0x7f110038

.field public static final dm_banner_with_title:I = 0x7f110039

.field public static final dm_base_content_free:I = 0x7f11003a

.field public static final dm_base_content_free_test:I = 0x7f11003b

.field public static final dm_base_content_vip:I = 0x7f11003c

.field public static final dm_base_tab:I = 0x7f11003d

.field public static final dm_brand_head_video:I = 0x7f11003e

.field public static final dm_brand_ip_artist:I = 0x7f11003f

.field public static final dm_brand_new_content:I = 0x7f110040

.field public static final dm_card_actoralbum:I = 0x7f110041

.field public static final dm_card_category_title:I = 0x7f110042

.field public static final dm_card_common_title:I = 0x7f110043

.field public static final dm_card_drama_calendar_horizontal:I = 0x7f110044

.field public static final dm_card_expandtext:I = 0x7f110045

.field public static final dm_card_ip_bottombar:I = 0x7f110046

.field public static final dm_card_ip_brand:I = 0x7f110047

.field public static final dm_card_ip_city_station:I = 0x7f110048

.field public static final dm_card_ip_info:I = 0x7f110049

.field public static final dm_card_ip_videoalbum:I = 0x7f11004a

.field public static final dm_card_productcell:I = 0x7f11004b

.field public static final dm_card_project_horizontal:I = 0x7f11004c

.field public static final dm_card_ranklist_horizontal:I = 0x7f11004d

.field public static final dm_clique_head:I = 0x7f11004e

.field public static final dm_common_loop_banner:I = 0x7f11004f

.field public static final dm_common_loop_banner_with_size:I = 0x7f110050

.field public static final dm_discover_head_banner:I = 0x7f110051

.field public static final dm_discover_head_fixed_3:I = 0x7f110052

.field public static final dm_discover_hot_clique:I = 0x7f110053

.field public static final dm_discover_hot_theme:I = 0x7f110054

.field public static final dm_drama_calendar_vertical:I = 0x7f110055

.field public static final dm_drama_list_worth_to_see:I = 0x7f110056

.field public static final dm_feed_big_note:I = 0x7f110057

.field public static final dm_feed_big_theme:I = 0x7f110058

.field public static final dm_feed_big_vote:I = 0x7f110059

.field public static final dm_feed_discuss:I = 0x7f11005a

.field public static final dm_feed_note:I = 0x7f11005b

.field public static final dm_feed_project:I = 0x7f11005c

.field public static final dm_feed_theme:I = 0x7f11005d

.field public static final dm_feed_vote:I = 0x7f11005e

.field public static final dm_floating_anchor_point_bar:I = 0x7f11005f

.field public static final dm_header_video:I = 0x7f110060

.field public static final dm_home_banner:I = 0x7f110061

.field public static final dm_home_mustseerank3:I = 0x7f110062

.field public static final dm_home_recentproject:I = 0x7f110063

.field public static final dm_home_tour:I = 0x7f110064

.field public static final dm_home_video:I = 0x7f110065

.field public static final dm_home_wantsee:I = 0x7f110066

.field public static final dm_home_warningmessage:I = 0x7f110067

.field public static final dm_home_weinituijian_title:I = 0x7f110068

.field public static final dm_homepage_component_config:I = 0x7f110069

.field public static final dm_list_card_ranking:I = 0x7f11006a

.field public static final dm_live_white_border_cancel_favourite:I = 0x7f11006b

.field public static final dm_live_white_border_favourite:I = 0x7f11006c

.field public static final dm_livehouse_artist_list:I = 0x7f11006d

.field public static final dm_music_festival_map_view:I = 0x7f11006e

.field public static final dm_music_ip_tour_info:I = 0x7f11006f

.field public static final dm_no_tour_project:I = 0x7f110070

.field public static final dm_official_content_feed:I = 0x7f110071

.field public static final dm_order_create_failed_lottie_classic:I = 0x7f110072

.field public static final dm_order_create_failed_lottie_pier:I = 0x7f110073

.field public static final dm_player_plugins_small:I = 0x7f11007e

.field public static final dm_productcard_row2column3_girl:I = 0x7f11007f

.field public static final dm_project_broadcast_horizontal_list:I = 0x7f110080

.field public static final dm_project_filter_option:I = 0x7f110081

.field public static final dm_project_filter_panel:I = 0x7f110082

.field public static final dm_rank_square_empty_view:I = 0x7f110083

.field public static final dm_rank_square_filter_view:I = 0x7f110084

.field public static final dm_rank_square_movie_vertical_list_item:I = 0x7f110085

.field public static final dm_rank_square_project_vertical_list_item:I = 0x7f110086

.field public static final dm_rank_square_rank_header_list:I = 0x7f110087

.field public static final dm_red_book_water_fall_feed_plugin:I = 0x7f110088

.field public static final dm_scene_type_config:I = 0x7f110089

.field public static final dm_tour_project_more:I = 0x7f11008a

.field public static final dm_view_commonerror:I = 0x7f11008b

.field public static final evaluate_excerpt_like:I = 0x7f11008c

.field public static final film_detail_tab_lottie:I = 0x7f11008e

.field public static final ic_lover_seats:I = 0x7f1100a1

.field public static final ic_pioneer_loading:I = 0x7f1100a2

.field public static final ic_pioneer_loading_tpp:I = 0x7f1100a3

.field public static final keep:I = 0x7f1100a4

.field public static final live_component_config:I = 0x7f1100a5

.field public static final live_header:I = 0x7f1100a6

.field public static final live_logo:I = 0x7f1100a7

.field public static final live_mock_data:I = 0x7f1100a8

.field public static final live_perform_announce:I = 0x7f1100a9

.field public static final live_perform_online_star:I = 0x7f1100aa

.field public static final lottie_artist_header:I = 0x7f1100ab

.field public static final lottie_dian_zan:I = 0x7f1100ac

.field public static final lottie_dian_zan_dismiss:I = 0x7f1100ad

.field public static final lottie_favorite_cancel:I = 0x7f1100ae

.field public static final lottie_favorite_guide:I = 0x7f1100af

.field public static final lottie_favorite_guide_black:I = 0x7f1100b0

.field public static final lottie_favorite_guide_pioneer:I = 0x7f1100b1

.field public static final lottie_favourite_cancel_pioneer:I = 0x7f1100b2

.field public static final lottie_favourite_click:I = 0x7f1100b3

.field public static final lottie_favourite_click_pioneer:I = 0x7f1100b4

.field public static final lottie_homepage_issue_star:I = 0x7f1100b6

.field public static final lottie_ip_wish_yingguangbang:I = 0x7f1100b7

.field public static final lottie_issue_star:I = 0x7f1100b8

.field public static final lottie_live_sound_wave:I = 0x7f1100b9

.field public static final lottie_live_sound_wave_grey:I = 0x7f1100ba

.field public static final lottie_liwu:I = 0x7f1100bb

.field public static final lottie_project_detail_default_share_pioneer:I = 0x7f1100bd

.field public static final lottie_project_detail_my_want_btn_cancel_pioneer:I = 0x7f1100bf

.field public static final lottie_project_detail_my_want_btn_want_pioneer:I = 0x7f1100c1

.field public static final lottie_red_sound_wave:I = 0x7f1100c2

.field public static final lottie_yinlang:I = 0x7f1100c3

.field public static final mock_data_coupon_detail:I = 0x7f1100ca

.field public static final mock_query_tip_data:I = 0x7f1100cb

.field public static final mock_yu_0520_discover:I = 0x7f1100cc

.field public static final new_channel_component_config:I = 0x7f1100cd

.field public static final pioneer_home_feed_tab:I = 0x7f1100d7

.field public static final pioneer_refresh_header_lottie:I = 0x7f1100d8

.field public static final qrcode_completed:I = 0x7f1100d9

.field public static final ranklist_component_config:I = 0x7f1100da

.field public static final real_name_authing:I = 0x7f1100db

.field public static final rp_face_blink:I = 0x7f1100dc

.field public static final rp_face_ding:I = 0x7f1100dd

.field public static final rp_face_open_mouth:I = 0x7f1100de

.field public static final rp_face_pitch_up:I = 0x7f1100df

.field public static final rp_face_yaw_left_right:I = 0x7f1100e0

.field public static final script_murder_coupon_detail_component_config:I = 0x7f1100e3

.field public static final script_murder_script_detail_component_config:I = 0x7f1100e4

.field public static final script_murder_shop_detail_component_config:I = 0x7f1100e5

.field public static final search_result_component_config_pioneer:I = 0x7f1100e6

.field public static final show_film_list_component_config:I = 0x7f1100e7

.field public static final toast_lottie_peach_heart:I = 0x7f1100f7

.field public static final toast_success:I = 0x7f1100f8

.field public static final token:I = 0x7f1100f9

.field public static final tpp_scene_type_config:I = 0x7f1100fa

.field public static final trade_prompt_strategy:I = 0x7f1100fc

.field public static final uikit_loading_color:I = 0x7f1100fe

.field public static final uikit_loading_white:I = 0x7f1100ff

.field public static final universally_component_config:I = 0x7f110100

.field public static final venue_detail_component_config:I = 0x7f110101

.field public static final want_see_bottom_tip_heart_pop:I = 0x7f110102

.field public static final want_see_bottom_tips_big_heart_pop:I = 0x7f110103

.field public static final want_see_bottom_tips_big_heart_pop_pioneer:I = 0x7f110104

.field public static final want_see_cancle_dark:I = 0x7f110105

.field public static final want_see_cancle_dark_black:I = 0x7f110106

.field public static final want_see_cancle_dark_green:I = 0x7f110107

.field public static final want_see_dark:I = 0x7f110108

.field public static final want_see_dark_black:I = 0x7f110109

.field public static final want_see_dark_green:I = 0x7f11010a

.field public static final want_see_guide_dark:I = 0x7f11010b

.field public static final want_see_guide_dark_green:I = 0x7f11010c


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
