.class public interface abstract Lcn/damai/commonbusiness/home/OnCityChangedListener;
.super Ljava/lang/Object;
.source "Taobao"


# virtual methods
.method public abstract onCityIdChanged()V
.end method
