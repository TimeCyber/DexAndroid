.class public Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$a;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->initListeners()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$a;->a:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$a;->a:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;

    # getter for: Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mOnProvinceCityCountySelectedListener:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnProvinceCityCountySelectedListener;
    invoke-static {p1}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->access$000(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;)Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnProvinceCityCountySelectedListener;

    move-result-object p1

    if-eqz p1, :cond_52

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$a;->a:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;

    # getter for: Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->isProvinceScrolling:Z
    invoke-static {p1}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->access$100(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;)Z

    move-result p1

    if-nez p1, :cond_52

    iget-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$a;->a:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;

    # getter for: Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->isCityScrolling:Z
    invoke-static {p1}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->access$200(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;)Z

    move-result p1

    if-nez p1, :cond_52

    iget-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$a;->a:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;

    # getter for: Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->isCountyScrolling:Z
    invoke-static {p1}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->access$300(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;)Z

    move-result p1

    if-nez p1, :cond_52

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$a;->a:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;

    # getter for: Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mOnProvinceCityCountySelectedListener:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnProvinceCityCountySelectedListener;
    invoke-static {p1}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->access$000(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;)Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnProvinceCityCountySelectedListener;

    move-result-object p1

    iget-object v0, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$a;->a:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;

    .line 4
    # getter for: Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedProvince:Lcn/damai/commonbusiness/address/bean/DivisionBean;
    invoke-static {v0}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->access$400(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;)Lcn/damai/commonbusiness/address/bean/DivisionBean;

    move-result-object v0

    iget-object v1, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$a;->a:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;

    # getter for: Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedCity:Lcn/damai/commonbusiness/address/bean/DivisionBean;
    invoke-static {v1}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->access$500(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;)Lcn/damai/commonbusiness/address/bean/DivisionBean;

    move-result-object v1

    iget-object v2, p0, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$a;->a:Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;

    # getter for: Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->mSelectedCounty:Lcn/damai/commonbusiness/address/bean/DivisionBean;
    invoke-static {v2}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;->access$600(Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;)Lcn/damai/commonbusiness/address/bean/DivisionBean;

    move-result-object v2

    invoke-interface {p1, v0, v1, v2}, Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnProvinceCityCountySelectedListener;->onDivisionsSelected(Lcn/damai/commonbusiness/address/bean/DivisionBean;Lcn/damai/commonbusiness/address/bean/DivisionBean;Lcn/damai/commonbusiness/address/bean/DivisionBean;)V

    :cond_52
    return-void
.end method
