.class public Lcn/damai/commonbusiness/fission/FissionUpgradeActivity$c;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;->setShareListener()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/fission/FissionUpgradeActivity$c;->a:Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 14

    sget-object v0, Lcn/damai/commonbusiness/fission/FissionUpgradeActivity$c;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz v2, :cond_17

    new-array v2, v4, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-static {}, Lcn/damai/common/user/c;->d()Lcn/damai/common/user/c;

    move-result-object v0

    invoke-static {}, Ltb/ks1;->g()Ltb/ks1;

    move-result-object v1

    const-string v2, "weibo"

    invoke-virtual {v1, v4, v2, v3}, Ltb/ks1;->j(ILjava/lang/String;Z)Lcn/damai/common/user/a$b;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcn/damai/common/user/c;->r(Lcn/damai/common/user/a$b;)V

    .line 2
    iget-object v5, p0, Lcn/damai/commonbusiness/fission/FissionUpgradeActivity$c;->a:Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;

    invoke-static {v5}, Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;->access$000(Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;)Ljava/lang/String;

    move-result-object v6

    iget-object v0, p0, Lcn/damai/commonbusiness/fission/FissionUpgradeActivity$c;->a:Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;->access$100(Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;)Lcn/damai/commonbusiness/fission/bean/FissionParam;

    move-result-object v0

    iget-object v7, v0, Lcn/damai/commonbusiness/fission/bean/FissionParam;->imageUrl:Ljava/lang/String;

    iget-object v0, p0, Lcn/damai/commonbusiness/fission/FissionUpgradeActivity$c;->a:Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;->access$100(Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;)Lcn/damai/commonbusiness/fission/bean/FissionParam;

    move-result-object v0

    iget-object v8, v0, Lcn/damai/commonbusiness/fission/bean/FissionParam;->projectName:Ljava/lang/String;

    iget-object v0, p0, Lcn/damai/commonbusiness/fission/FissionUpgradeActivity$c;->a:Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;->access$100(Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;)Lcn/damai/commonbusiness/fission/bean/FissionParam;

    move-result-object v0

    iget-object v9, v0, Lcn/damai/commonbusiness/fission/bean/FissionParam;->subMessage:Ljava/lang/String;

    iget-object v0, p0, Lcn/damai/commonbusiness/fission/FissionUpgradeActivity$c;->a:Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;->access$100(Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;)Lcn/damai/commonbusiness/fission/bean/FissionParam;

    move-result-object v0

    invoke-virtual {v0}, Lcn/damai/commonbusiness/fission/bean/FissionParam;->getUniqueIdent()Ljava/lang/String;

    move-result-object v10

    iget-object v0, p0, Lcn/damai/commonbusiness/fission/FissionUpgradeActivity$c;->a:Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;->access$300(Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;)Ljava/lang/String;

    move-result-object v11

    const-string v3, "weibo"

    move-object v2, v5

    move-object v4, p1

    invoke-static/range {v2 .. v11}, Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;->access$400(Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;Ljava/lang/String;Landroid/view/View;Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/fission/FissionUpgradeActivity$c;->a:Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;

    invoke-virtual {p1}, Lcn/damai/commonbusiness/fission/FissionUpgradeActivity;->onBackPresss()V

    return-void
.end method
