.class public Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$11$1;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$11;->onSuccess(Ljava/util/ArrayList;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic this$1:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$11;

.field final synthetic val$folders:Ljava/util/ArrayList;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$11;Ljava/util/ArrayList;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$11$1;->this$1:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$11;

    iput-object p2, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$11$1;->val$folders:Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$11$1;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$11$1;->val$folders:Ljava/util/ArrayList;

    if-eqz v0, :cond_61

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_61

    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$11$1;->val$folders:Ljava/util/ArrayList;

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_61

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$11$1;->val$folders:Ljava/util/ArrayList;

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltb/ww1;

    invoke-virtual {v0}, Ltb/ww1;->b()Ljava/util/ArrayList;

    move-result-object v0

    if-eqz v0, :cond_5a

    .line 3
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_5a

    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$11$1;->this$1:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$11;

    iget-object v1, v1, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$11;->a:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;

    invoke-static {v1}, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;->access$000(Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;)Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;

    move-result-object v1

    if-eqz v1, :cond_5a

    .line 4
    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$11$1;->this$1:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$11;

    iget-object v1, v1, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$11;->a:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;

    invoke-static {v1}, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;->access$1000(Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;)Landroidx/recyclerview/widget/RecyclerView;

    move-result-object v1

    invoke-virtual {v1, v3}, Landroidx/recyclerview/widget/RecyclerView;->scrollToPosition(I)V

    .line 5
    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$11$1;->this$1:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$11;

    iget-object v1, v1, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$11;->a:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;

    invoke-static {v1}, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;->access$000(Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;)Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;->m(Ljava/util/ArrayList;)V

    .line 6
    :cond_5a
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$11$1;->this$1:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$11;

    iget-object v0, v0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$11;->a:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;->access$900(Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;)V

    :cond_61
    return-void
.end method
