.class public Lcn/damai/commonbusiness/discover/bean/VoteBean;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public hasVote:Z

.field public id:Ljava/lang/String;

.field public name:Ljava/lang/String;

.field public posInVoteList:I

.field public progressInt:I

.field public total:Ljava/lang/String;

.field public totalDesc:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lcn/damai/commonbusiness/discover/bean/VoteBean;->progressInt:I

    return-void
.end method
