.class public Lcn/damai/commonbusiness/city/model/PinYinBean;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field public alphabet:Ljava/lang/String;

.field public pinYin:Ljava/lang/String;

.field public pinyinWithSpace:Ljava/lang/String;

.field public singleLegth:[I


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static parsePinyinOfHanzi(Ljava/lang/String;)Lcn/damai/commonbusiness/city/model/PinYinBean;
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/city/model/PinYinBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcn/damai/commonbusiness/city/model/PinYinBean;

    return-object p0

    .line 1
    :cond_17
    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_23

    .line 2
    new-instance p0, Lcn/damai/commonbusiness/city/model/PinYinBean;

    invoke-direct {p0}, Lcn/damai/commonbusiness/city/model/PinYinBean;-><init>()V

    return-object p0

    .line 3
    :cond_23
    new-instance v0, Lcn/damai/commonbusiness/city/model/PinYinBean;

    invoke-direct {v0}, Lcn/damai/commonbusiness/city/model/PinYinBean;-><init>()V

    .line 4
    invoke-static {p0}, Ltb/rw;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcn/damai/commonbusiness/city/model/PinYinBean;->pinYin:Ljava/lang/String;

    const-string v1, ".{1}(?!$)"

    const-string v2, "$0 "

    .line 5
    invoke-virtual {p0, v1, v2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ltb/rw;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcn/damai/commonbusiness/city/model/PinYinBean;->pinyinWithSpace:Ljava/lang/String;

    const-string v2, " "

    .line 6
    invoke-virtual {v1, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    .line 7
    array-length v2, v1

    new-array v2, v2, [I

    iput-object v2, v0, Lcn/damai/commonbusiness/city/model/PinYinBean;->singleLegth:[I

    const/4 v2, 0x0

    .line 8
    :goto_48
    array-length v4, v1

    if-ge v2, v4, :cond_63

    .line 9
    iget-object v4, v0, Lcn/damai/commonbusiness/city/model/PinYinBean;->singleLegth:[I

    aget-object v5, v1, v2

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v5

    if-nez v2, :cond_57

    const/4 v6, 0x0

    goto :goto_5d

    :cond_57
    iget-object v6, v0, Lcn/damai/commonbusiness/city/model/PinYinBean;->singleLegth:[I

    add-int/lit8 v7, v2, -0x1

    aget v6, v6, v7

    :goto_5d
    add-int/2addr v5, v6

    aput v5, v4, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_48

    .line 10
    :cond_63
    invoke-static {p0}, Ltb/rw;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    iput-object p0, v0, Lcn/damai/commonbusiness/city/model/PinYinBean;->alphabet:Ljava/lang/String;

    return-object v0
.end method
