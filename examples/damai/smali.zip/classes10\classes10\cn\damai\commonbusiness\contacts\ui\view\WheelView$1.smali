.class public Lcn/damai/commonbusiness/contacts/ui/view/WheelView$1;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->init(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic this$0:Lcn/damai/commonbusiness/contacts/ui/view/WheelView;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/contacts/ui/view/WheelView;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$1;->this$0:Lcn/damai/commonbusiness/contacts/ui/view/WheelView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$1;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$1;->this$0:Lcn/damai/commonbusiness/contacts/ui/view/WheelView;

    invoke-virtual {v0}, Landroid/widget/ScrollView;->getScrollY()I

    move-result v0

    .line 2
    iget-object v1, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$1;->this$0:Lcn/damai/commonbusiness/contacts/ui/view/WheelView;

    iget v2, v1, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->initialY:I

    sub-int v0, v2, v0

    if-nez v0, :cond_48

    .line 3
    iget v0, v1, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->itemHeight:I

    rem-int v3, v2, v0

    .line 4
    div-int/2addr v2, v0

    if-nez v3, :cond_32

    .line 5
    iget v0, v1, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->offset:I

    add-int/2addr v2, v0

    iput v2, v1, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->selectedIndex:I

    .line 6
    # invokes: Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->onSeletedCallBack()V
    invoke-static {v1}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->access$000(Lcn/damai/commonbusiness/contacts/ui/view/WheelView;)V

    goto :goto_58

    .line 7
    :cond_32
    div-int/lit8 v0, v0, 0x2

    if-le v3, v0, :cond_3f

    .line 8
    new-instance v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$1$1;

    invoke-direct {v0, p0, v3, v2}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$1$1;-><init>(Lcn/damai/commonbusiness/contacts/ui/view/WheelView$1;II)V

    invoke-virtual {v1, v0}, Landroid/widget/ScrollView;->post(Ljava/lang/Runnable;)Z

    goto :goto_58

    .line 9
    :cond_3f
    new-instance v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$1$2;

    invoke-direct {v0, p0, v3, v2}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$1$2;-><init>(Lcn/damai/commonbusiness/contacts/ui/view/WheelView$1;II)V

    invoke-virtual {v1, v0}, Landroid/widget/ScrollView;->post(Ljava/lang/Runnable;)Z

    goto :goto_58

    .line 10
    :cond_48
    invoke-virtual {v1}, Landroid/widget/ScrollView;->getScrollY()I

    move-result v0

    iput v0, v1, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->initialY:I

    .line 11
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$1;->this$0:Lcn/damai/commonbusiness/contacts/ui/view/WheelView;

    iget-object v1, v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->scrollerTask:Ljava/lang/Runnable;

    iget v2, v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->newCheck:I

    int-to-long v2, v2

    invoke-virtual {v0, v1, v2, v3}, Landroid/widget/ScrollView;->postDelayed(Ljava/lang/Runnable;J)Z

    :goto_58
    return-void
.end method
