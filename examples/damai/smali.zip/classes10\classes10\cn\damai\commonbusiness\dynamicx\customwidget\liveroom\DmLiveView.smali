.class public Lcn/damai/commonbusiness/dynamicx/customwidget/liveroom/DmLiveView;
.super Landroid/widget/LinearLayout;
.source "Taobao"


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private final LIVE_ROOM_VALUE:Ljava/lang/String;

.field mLiveAnimView:Lcom/airbnb/lottie/LottieAnimationView;

.field mLiveName:Landroid/widget/TextView;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param

    .line 1
    invoke-direct {p0, p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const-string p1, "2"

    .line 2
    iput-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/liveroom/DmLiveView;->LIVE_ROOM_VALUE:Ljava/lang/String;

    .line 3
    invoke-direct {p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/liveroom/DmLiveView;->initView()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .line 4
    invoke-direct {p0, p1, p2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const-string p1, "2"

    .line 5
    iput-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/liveroom/DmLiveView;->LIVE_ROOM_VALUE:Ljava/lang/String;

    .line 6
    invoke-direct {p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/liveroom/DmLiveView;->initView()V

    return-void
.end method

.method private initView()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/liveroom/DmLiveView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    invoke-virtual {p0, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 3
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    sget v1, Lcom/alibaba/pictures/picturesbiz/R$layout;->layout_live_room:I

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    .line 4
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x1

    invoke-direct {v1, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 5
    sget v2, Lcom/alibaba/pictures/picturesbiz/R$id;->live_icon:I

    invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lcom/airbnb/lottie/LottieAnimationView;

    iput-object v2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/liveroom/DmLiveView;->mLiveAnimView:Lcom/airbnb/lottie/LottieAnimationView;

    .line 6
    sget v2, Lcom/alibaba/pictures/picturesbiz/R$id;->tag_view_name:I

    invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/liveroom/DmLiveView;->mLiveName:Landroid/widget/TextView;

    .line 7
    invoke-virtual {p0, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method


# virtual methods
.method public updateLiveType(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/liveroom/DmLiveView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/liveroom/DmLiveView;->mLiveName:Landroid/widget/TextView;

    if-eqz v0, :cond_4d

    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/liveroom/DmLiveView;->mLiveAnimView:Lcom/airbnb/lottie/LottieAnimationView;

    if-nez v0, :cond_20

    goto :goto_4d

    .line 2
    :cond_20
    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_3f

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/liveroom/DmLiveView;->mLiveAnimView:Lcom/airbnb/lottie/LottieAnimationView;

    invoke-virtual {p1, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 4
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/liveroom/DmLiveView;->mLiveAnimView:Lcom/airbnb/lottie/LottieAnimationView;

    sget v0, Lcom/alibaba/pictures/picturesbiz/R$raw;->lottie_live_sound_wave:I

    invoke-virtual {p1, v0}, Lcom/airbnb/lottie/LottieAnimationView;->setAnimation(I)V

    .line 5
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/liveroom/DmLiveView;->mLiveAnimView:Lcom/airbnb/lottie/LottieAnimationView;

    invoke-virtual {p1}, Lcom/airbnb/lottie/LottieAnimationView;->playAnimation()V

    .line 6
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/liveroom/DmLiveView;->mLiveName:Landroid/widget/TextView;

    const-string v0, "\u76f4\u64ad\u4e2d"

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_4d

    .line 7
    :cond_3f
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/liveroom/DmLiveView;->mLiveAnimView:Lcom/airbnb/lottie/LottieAnimationView;

    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 8
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/liveroom/DmLiveView;->mLiveName:Landroid/widget/TextView;

    const-string v0, "\u76f4\u64ad"

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_4d
    :goto_4d
    return-void
.end method
