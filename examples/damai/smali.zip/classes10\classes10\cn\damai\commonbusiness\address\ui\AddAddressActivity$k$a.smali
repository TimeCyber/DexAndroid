.class public Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k$a;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k;->onClick(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Landroid/widget/CheckBox;

.field final synthetic b:Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k;Landroid/widget/CheckBox;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k$a;->b:Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k;

    iput-object p2, p0, Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k$a;->a:Landroid/widget/CheckBox;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .registers 8

    sget-object v0, Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k$a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_1e

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1e
    iget-object p2, p0, Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k$a;->a:Landroid/widget/CheckBox;

    invoke-virtual {p2, v3}, Landroid/widget/CheckBox;->setChecked(Z)V

    .line 2
    iget-object p2, p0, Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k$a;->b:Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k;

    iget-object p2, p2, Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k;->a:Lcn/damai/commonbusiness/address/ui/AddAddressActivity;

    invoke-static {p2}, Lcn/damai/commonbusiness/address/ui/AddAddressActivity;->access$000(Lcn/damai/commonbusiness/address/ui/AddAddressActivity;)V

    .line 3
    iget-object p2, p0, Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k$a;->b:Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k;

    iget-object p2, p2, Lcn/damai/commonbusiness/address/ui/AddAddressActivity$k;->a:Lcn/damai/commonbusiness/address/ui/AddAddressActivity;

    invoke-static {p2}, Ltb/d41;->f(Landroid/app/Activity;)V

    .line 4
    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    return-void
.end method
