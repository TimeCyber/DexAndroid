.class public final enum Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;
.super Ljava/lang/Enum;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "State"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;

.field public static final enum EMPTY:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;

.field public static final enum FAIL:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;

.field public static final enum SUCCESS:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;


# direct methods
.method static constructor <clinit>()V
    .registers 7

    .line 1
    new-instance v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;

    const-string v1, "SUCCESS"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;->SUCCESS:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;

    new-instance v1, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;

    const-string v3, "FAIL"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4}, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;-><init>(Ljava/lang/String;I)V

    sput-object v1, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;->FAIL:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;

    new-instance v3, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;

    const-string v5, "EMPTY"

    const/4 v6, 0x2

    invoke-direct {v3, v5, v6}, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;-><init>(Ljava/lang/String;I)V

    sput-object v3, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;->EMPTY:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;

    const/4 v5, 0x3

    new-array v5, v5, [Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;

    aput-object v0, v5, v2

    aput-object v1, v5, v4

    aput-object v3, v5, v6

    .line 2
    sput-object v5, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;->$VALUES:[Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;
    .registers 2

    .line 1
    const-class v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;

    return-object p0
.end method

.method public static values()[Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;
    .registers 1

    .line 1
    sget-object v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;->$VALUES:[Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;

    invoke-virtual {v0}, [Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;

    return-object v0
.end method
