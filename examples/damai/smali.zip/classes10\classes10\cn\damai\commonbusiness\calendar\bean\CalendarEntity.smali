.class public Lcn/damai/commonbusiness/calendar/bean/CalendarEntity;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x4a01644cce55b324L


# instance fields
.field public isSelected:Z

.field public month:I

.field public year:I


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
