.class public Lcn/damai/commonbusiness/banner/bean/PageBanner;
.super Ljava/lang/Object;
.source "Taobao"


# instance fields
.field public picUrl:Ljava/lang/String;

.field public schema:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
