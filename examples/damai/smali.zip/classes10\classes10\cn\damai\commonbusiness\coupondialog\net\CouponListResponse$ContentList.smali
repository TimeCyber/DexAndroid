.class public Lcn/damai/commonbusiness/coupondialog/net/CouponListResponse$ContentList;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/coupondialog/net/CouponListResponse;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "ContentList"
.end annotation


# instance fields
.field public appButtonAction:Ljava/lang/String;

.field public buttonName:Ljava/lang/String;

.field public cityName:Ljava/lang/String;

.field public desText:Ljava/lang/String;

.field public eventTrack:Ljava/lang/String;

.field public footer:Ljava/lang/String;

.field public header:Ljava/lang/String;

.field public id:Ljava/lang/String;

.field public itemId:Ljava/lang/String;

.field public itemList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/coupondialog/net/CouponListResponse$Coupon;",
            ">;"
        }
    .end annotation
.end field

.field public itemName:Ljava/lang/String;

.field public itemScore:Ljava/lang/String;

.field public performTime:Ljava/lang/String;

.field public projectDatetime:Ljava/lang/String;

.field public projectPic:Ljava/lang/String;

.field public targetId:Ljava/lang/String;

.field public title:Ljava/lang/String;

.field public venuesName:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
