.class public Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/GestureDetector$OnDoubleTapListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;-><init>(Landroid/widget/ImageView;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onDoubleTap(Landroid/view/MotionEvent;)Z
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    return p1

    .line 1
    :cond_1e
    :try_start_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-virtual {v0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->N()F

    move-result v0

    .line 2
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    .line 3
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    .line 4
    iget-object v2, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-virtual {v2}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->L()F

    move-result v2

    cmpg-float v2, v0, v2

    if-gez v2, :cond_40

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-virtual {v0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->L()F

    move-result v2

    invoke-virtual {v0, v2, v1, p1, v3}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->n0(FFFZ)V

    goto :goto_67

    .line 6
    :cond_40
    iget-object v2, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-virtual {v2}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->L()F

    move-result v2

    cmpl-float v2, v0, v2

    if-ltz v2, :cond_5e

    iget-object v2, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-virtual {v2}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->K()F

    move-result v2

    cmpg-float v0, v0, v2

    if-gez v0, :cond_5e

    .line 7
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-virtual {v0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->K()F

    move-result v2

    invoke-virtual {v0, v2, v1, p1, v3}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->n0(FFFZ)V

    goto :goto_67

    .line 8
    :cond_5e
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-virtual {v0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->M()F

    move-result v2

    invoke-virtual {v0, v2, v1, p1, v3}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->n0(FFFZ)V
    :try_end_67
    .catch Ljava/lang/ArrayIndexOutOfBoundsException; {:try_start_1e .. :try_end_67} :catch_67

    :catch_67
    :goto_67
    return v3
.end method

.method public onDoubleTapEvent(Landroid/view/MotionEvent;)Z
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    return p1

    :cond_1e
    return v3
.end method

.method public onSingleTapConfirmed(Landroid/view/MotionEvent;)Z
    .registers 8

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    return p1

    .line 1
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->k(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Landroid/view/View$OnClickListener;

    move-result-object v0

    if-eqz v0, :cond_35

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->k(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Landroid/view/View$OnClickListener;

    move-result-object v0

    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-static {v1}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->t(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Landroid/widget/ImageView;

    move-result-object v1

    invoke-interface {v0, v1}, Landroid/view/View$OnClickListener;->onClick(Landroid/view/View;)V

    .line 3
    :cond_35
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-virtual {v0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->E()Landroid/graphics/RectF;

    move-result-object v0

    .line 4
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    .line 5
    iget-object v2, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-static {v2}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->l(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Lcn/damai/commonbusiness/photoselect/photoview/OnViewTapListener;

    move-result-object v2

    if-eqz v2, :cond_5a

    .line 6
    iget-object v2, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-static {v2}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->l(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Lcn/damai/commonbusiness/photoselect/photoview/OnViewTapListener;

    move-result-object v2

    iget-object v5, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-static {v5}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->t(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Landroid/widget/ImageView;

    move-result-object v5

    invoke-interface {v2, v5, v1, p1}, Lcn/damai/commonbusiness/photoselect/photoview/OnViewTapListener;->onViewTap(Landroid/view/View;FF)V

    :cond_5a
    if-eqz v0, :cond_a1

    .line 7
    invoke-virtual {v0, v1, p1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v2

    if-eqz v2, :cond_8a

    .line 8
    iget v2, v0, Landroid/graphics/RectF;->left:F

    sub-float/2addr v1, v2

    .line 9
    invoke-virtual {v0}, Landroid/graphics/RectF;->width()F

    move-result v2

    div-float/2addr v1, v2

    .line 10
    iget v2, v0, Landroid/graphics/RectF;->top:F

    sub-float/2addr p1, v2

    .line 11
    invoke-virtual {v0}, Landroid/graphics/RectF;->height()F

    move-result v0

    div-float/2addr p1, v0

    .line 12
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->n(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Lcn/damai/commonbusiness/photoselect/photoview/OnPhotoTapListener;

    move-result-object v0

    if-eqz v0, :cond_89

    .line 13
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->n(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Lcn/damai/commonbusiness/photoselect/photoview/OnPhotoTapListener;

    move-result-object v0

    iget-object v2, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-static {v2}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->t(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Landroid/widget/ImageView;

    move-result-object v2

    invoke-interface {v0, v2, v1, p1}, Lcn/damai/commonbusiness/photoselect/photoview/OnPhotoTapListener;->onPhotoTap(Landroid/widget/ImageView;FF)V

    :cond_89
    return v3

    .line 14
    :cond_8a
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-static {p1}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->o(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Lcn/damai/commonbusiness/photoselect/photoview/OnOutsidePhotoTapListener;

    move-result-object p1

    if-eqz p1, :cond_a1

    .line 15
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-static {p1}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->o(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Lcn/damai/commonbusiness/photoselect/photoview/OnOutsidePhotoTapListener;

    move-result-object p1

    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$c;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->t(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Landroid/widget/ImageView;

    move-result-object v0

    invoke-interface {p1, v0}, Lcn/damai/commonbusiness/photoselect/photoview/OnOutsidePhotoTapListener;->onOutsidePhotoTap(Landroid/widget/ImageView;)V

    :cond_a1
    return v4
.end method
