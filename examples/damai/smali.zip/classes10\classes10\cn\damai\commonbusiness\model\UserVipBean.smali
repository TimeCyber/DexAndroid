.class public Lcn/damai/commonbusiness/model/UserVipBean;
.super Ljava/lang/Object;
.source "Taobao"


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private isVip:Z

.field private vipLevel:Ljava/lang/String;

.field private vipLevelIcon:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lcn/damai/commonbusiness/model/UserData;)V
    .registers 3

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-eqz p1, :cond_22

    .line 3
    invoke-virtual {p1}, Lcn/damai/commonbusiness/model/UserData;->getUserBaseInfo()Lcn/damai/commonbusiness/model/UserBaseInfoBean;

    move-result-object v0

    if-eqz v0, :cond_22

    .line 4
    invoke-virtual {p1}, Lcn/damai/commonbusiness/model/UserData;->getUserBaseInfo()Lcn/damai/commonbusiness/model/UserBaseInfoBean;

    move-result-object p1

    .line 5
    invoke-virtual {p1}, Lcn/damai/commonbusiness/model/UserBaseInfoBean;->isVip()Z

    move-result v0

    iput-boolean v0, p0, Lcn/damai/commonbusiness/model/UserVipBean;->isVip:Z

    .line 6
    invoke-virtual {p1}, Lcn/damai/commonbusiness/model/UserBaseInfoBean;->getVipLevel()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/model/UserVipBean;->vipLevel:Ljava/lang/String;

    .line 7
    invoke-virtual {p1}, Lcn/damai/commonbusiness/model/UserBaseInfoBean;->getVipLevelIcon()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcn/damai/commonbusiness/model/UserVipBean;->vipLevelIcon:Ljava/lang/String;

    goto :goto_2c

    :cond_22
    const/4 p1, 0x0

    .line 8
    iput-boolean p1, p0, Lcn/damai/commonbusiness/model/UserVipBean;->isVip:Z

    const-string p1, "0"

    .line 9
    iput-object p1, p0, Lcn/damai/commonbusiness/model/UserVipBean;->vipLevel:Ljava/lang/String;

    const/4 p1, 0x0

    .line 10
    iput-object p1, p0, Lcn/damai/commonbusiness/model/UserVipBean;->vipLevelIcon:Ljava/lang/String;

    :goto_2c
    return-void
.end method

.method public constructor <init>(ZLjava/lang/String;Ljava/lang/String;)V
    .registers 4

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    iput-boolean p1, p0, Lcn/damai/commonbusiness/model/UserVipBean;->isVip:Z

    .line 13
    iput-object p2, p0, Lcn/damai/commonbusiness/model/UserVipBean;->vipLevel:Ljava/lang/String;

    .line 14
    iput-object p3, p0, Lcn/damai/commonbusiness/model/UserVipBean;->vipLevelIcon:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public getVipLevelInt()I
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/model/UserVipBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget-object v0, p0, Lcn/damai/commonbusiness/model/UserVipBean;->vipLevel:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_24

    return v3

    .line 2
    :cond_24
    :try_start_24
    iget-object v0, p0, Lcn/damai/commonbusiness/model/UserVipBean;->vipLevel:Ljava/lang/String;

    invoke-static {v0, v3}, Ltb/mw5;->l(Ljava/lang/String;I)I

    move-result v0
    :try_end_2a
    .catch Ljava/lang/Exception; {:try_start_24 .. :try_end_2a} :catch_2b

    return v0

    :catch_2b
    return v3
.end method
