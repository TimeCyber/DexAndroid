.class public Lcn/damai/commonbusiness/contacts/ui/view/WheelView$a;
.super Landroid/graphics/drawable/Drawable;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/contacts/ui/view/WheelView;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/contacts/ui/view/WheelView;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$a;->a:Lcn/damai/commonbusiness/contacts/ui/view/WheelView;

    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    return-void
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;)V
    .registers 13

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_17
    const/4 v6, 0x0

    .line 1
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$a;->a:Lcn/damai/commonbusiness/contacts/ui/view/WheelView;

    # invokes: Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->obtainSelectedAreaBorder()[I
    invoke-static {v0}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->access$100(Lcn/damai/commonbusiness/contacts/ui/view/WheelView;)[I

    move-result-object v0

    aget v0, v0, v4

    int-to-float v7, v0

    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$a;->a:Lcn/damai/commonbusiness/contacts/ui/view/WheelView;

    iget v1, v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->viewWidth:I

    int-to-float v8, v1

    # invokes: Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->obtainSelectedAreaBorder()[I
    invoke-static {v0}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->access$100(Lcn/damai/commonbusiness/contacts/ui/view/WheelView;)[I

    move-result-object v0

    aget v0, v0, v4

    int-to-float v9, v0

    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$a;->a:Lcn/damai/commonbusiness/contacts/ui/view/WheelView;

    iget-object v10, v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->paint:Landroid/graphics/Paint;

    move-object v5, p1

    invoke-virtual/range {v5 .. v10}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$a;->a:Lcn/damai/commonbusiness/contacts/ui/view/WheelView;

    # invokes: Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->obtainSelectedAreaBorder()[I
    invoke-static {v0}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->access$100(Lcn/damai/commonbusiness/contacts/ui/view/WheelView;)[I

    move-result-object v0

    aget v0, v0, v3

    int-to-float v7, v0

    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$a;->a:Lcn/damai/commonbusiness/contacts/ui/view/WheelView;

    iget v1, v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->viewWidth:I

    int-to-float v8, v1

    # invokes: Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->obtainSelectedAreaBorder()[I
    invoke-static {v0}, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->access$100(Lcn/damai/commonbusiness/contacts/ui/view/WheelView;)[I

    move-result-object v0

    aget v0, v0, v3

    int-to-float v9, v0

    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$a;->a:Lcn/damai/commonbusiness/contacts/ui/view/WheelView;

    iget-object v10, v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView;->paint:Landroid/graphics/Paint;

    invoke-virtual/range {v5 .. v10}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    return-void
.end method

.method public getOpacity()I
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0

    :cond_1b
    return v3
.end method

.method public setAlpha(I)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1a
    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/view/WheelView$a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_16

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    :cond_16
    return-void
.end method
