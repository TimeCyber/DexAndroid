.class public final enum Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;
.super Ljava/lang/Enum;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "State"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;

.field public static final enum EMPTY:Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;

.field public static final enum FAIL:Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;

.field public static final enum SUCCESS:Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;

.field public static final enum TOKEN_FIAL:Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;


# direct methods
.method static constructor <clinit>()V
    .registers 9

    .line 1
    new-instance v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;

    const-string v1, "SUCCESS"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;->SUCCESS:Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;

    new-instance v1, Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;

    const-string v3, "TOKEN_FIAL"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4}, Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;-><init>(Ljava/lang/String;I)V

    sput-object v1, Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;->TOKEN_FIAL:Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;

    new-instance v3, Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;

    const-string v5, "FAIL"

    const/4 v6, 0x2

    invoke-direct {v3, v5, v6}, Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;-><init>(Ljava/lang/String;I)V

    sput-object v3, Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;->FAIL:Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;

    new-instance v5, Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;

    const-string v7, "EMPTY"

    const/4 v8, 0x3

    invoke-direct {v5, v7, v8}, Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;-><init>(Ljava/lang/String;I)V

    sput-object v5, Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;->EMPTY:Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;

    const/4 v7, 0x4

    new-array v7, v7, [Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;

    aput-object v0, v7, v2

    aput-object v1, v7, v4

    aput-object v3, v7, v6

    aput-object v5, v7, v8

    .line 2
    sput-object v7, Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;->$VALUES:[Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;
    .registers 2

    .line 1
    const-class v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;

    return-object p0
.end method

.method public static values()[Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;
    .registers 1

    .line 1
    sget-object v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;->$VALUES:[Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;

    invoke-virtual {v0}, [Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcn/damai/commonbusiness/faceverify/listener/DMFaceCertResult$State;

    return-object v0
.end method
