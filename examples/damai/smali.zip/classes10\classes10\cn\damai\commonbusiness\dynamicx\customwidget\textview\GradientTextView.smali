.class public Lcn/damai/commonbusiness/dynamicx/customwidget/textview/GradientTextView;
.super Landroid/widget/TextView;
.source "Taobao"


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private mGIndex:I

.field private mLastH:I

.field private mLastW:I


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, p1, v0}, Lcn/damai/commonbusiness/dynamicx/customwidget/textview/GradientTextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 4
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, p1, p2, v0}, Lcn/damai/commonbusiness/dynamicx/customwidget/textview/GradientTextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .line 3
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 p1, -0x1

    .line 4
    iput p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/textview/GradientTextView;->mLastW:I

    .line 5
    iput p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/textview/GradientTextView;->mLastH:I

    .line 6
    iput p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/textview/GradientTextView;->mGIndex:I

    .line 7
    invoke-static {}, Ltb/qb3;->c()Ltb/qb3;

    move-result-object p1

    invoke-virtual {p1}, Ltb/qb3;->b()I

    move-result p1

    iput p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/textview/GradientTextView;->mGIndex:I

    return-void
.end method


# virtual methods
.method public getGradientIndex()I
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/textview/GradientTextView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/textview/GradientTextView;->mGIndex:I

    return v0
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .registers 18

    move-object/from16 v0, p0

    sget-object v1, Lcn/damai/commonbusiness/dynamicx/customwidget/textview/GradientTextView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v2, "2"

    invoke-static {v1, v2}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v3

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-eqz v3, :cond_19

    new-array v3, v6, [Ljava/lang/Object;

    aput-object v0, v3, v5

    aput-object p1, v3, v4

    invoke-interface {v1, v2, v3}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_19
    invoke-virtual/range {p0 .. p0}, Landroid/widget/TextView;->getWidth()I

    move-result v1

    .line 2
    invoke-virtual/range {p0 .. p0}, Landroid/widget/TextView;->getHeight()I

    move-result v2

    .line 3
    iget v3, v0, Lcn/damai/commonbusiness/dynamicx/customwidget/textview/GradientTextView;->mLastW:I

    if-ne v1, v3, :cond_29

    iget v3, v0, Lcn/damai/commonbusiness/dynamicx/customwidget/textview/GradientTextView;->mLastH:I

    if-eq v2, v3, :cond_51

    .line 4
    :cond_29
    invoke-static {}, Ltb/qb3;->c()Ltb/qb3;

    move-result-object v3

    iget v7, v0, Lcn/damai/commonbusiness/dynamicx/customwidget/textview/GradientTextView;->mGIndex:I

    invoke-virtual {v3, v7}, Ltb/qb3;->a(I)Lcn/damai/commonbusiness/dynamicx/customwidget/textview/GradientBean;

    move-result-object v3

    .line 5
    new-instance v15, Landroid/graphics/LinearGradient;

    const/4 v8, 0x0

    const/4 v9, 0x0

    int-to-float v10, v1

    int-to-float v11, v2

    new-array v12, v6, [I

    iget v6, v3, Lcn/damai/commonbusiness/dynamicx/customwidget/textview/GradientBean;->startColor:I

    aput v6, v12, v5

    iget v3, v3, Lcn/damai/commonbusiness/dynamicx/customwidget/textview/GradientBean;->endColor:I

    aput v3, v12, v4

    const/4 v13, 0x0

    sget-object v14, Landroid/graphics/Shader$TileMode;->REPEAT:Landroid/graphics/Shader$TileMode;

    move-object v7, v15

    invoke-direct/range {v7 .. v14}, Landroid/graphics/LinearGradient;-><init>(FFFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 6
    invoke-virtual/range {p0 .. p0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    move-result-object v3

    invoke-virtual {v3, v15}, Landroid/text/TextPaint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 7
    :cond_51
    iput v1, v0, Lcn/damai/commonbusiness/dynamicx/customwidget/textview/GradientTextView;->mLastW:I

    .line 8
    iput v2, v0, Lcn/damai/commonbusiness/dynamicx/customwidget/textview/GradientTextView;->mLastH:I

    .line 9
    invoke-super/range {p0 .. p1}, Landroid/widget/TextView;->onDraw(Landroid/graphics/Canvas;)V

    return-void
.end method
