.class public interface abstract Lcn/damai/commonbusiness/photoselect/photoview/OnViewDragListener;
.super Ljava/lang/Object;
.source "Taobao"


# virtual methods
.method public abstract onDrag(FF)V
.end method
