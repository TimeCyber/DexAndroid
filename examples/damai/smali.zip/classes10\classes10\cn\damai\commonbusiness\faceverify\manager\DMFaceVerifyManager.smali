.class public Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$d;
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private a:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyListener;

.field private b:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$1;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;-><init>()V

    return-void
.end method

.method static synthetic a(Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 5

    .line 1
    invoke-direct {p0, p1, p2, p3, p4}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->j(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic b(Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;Lcn/damai/commonbusiness/faceverify/bean/IdentityInfoQueryBean;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->k(Lcn/damai/commonbusiness/faceverify/bean/IdentityInfoQueryBean;)V

    return-void
.end method

.method static synthetic c(Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 6

    .line 1
    invoke-direct/range {p0 .. p5}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->o(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic d(Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;Ljava/lang/String;Ljava/lang/String;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->s(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic e(Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;Landroid/content/Context;Lcn/damai/commonbusiness/faceverify/bean/FaceVerifyTokenBean;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 7

    .line 1
    invoke-direct/range {p0 .. p6}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->y(Landroid/content/Context;Lcn/damai/commonbusiness/faceverify/bean/FaceVerifyTokenBean;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic f(Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;Lcom/alibaba/security/rp/RPSDK$AUDIT;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 7

    .line 1
    invoke-direct/range {p0 .. p6}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->p(Lcom/alibaba/security/rp/RPSDK$AUDIT;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic g(Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 6

    .line 1
    invoke-direct/range {p0 .. p5}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->l(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic h(Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 5

    .line 1
    invoke-direct {p0, p1, p2, p3, p4}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->m(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic i(Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->t()V

    return-void
.end method

.method private j(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "14"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_20

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    aput-object p3, v2, p1

    const/4 p1, 0x4

    aput-object p4, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_20
    new-instance p1, Lcn/damai/commonbusiness/faceverify/request/AccountRealNameAuthRequest;

    invoke-direct {p1}, Lcn/damai/commonbusiness/faceverify/request/AccountRealNameAuthRequest;-><init>()V

    .line 2
    invoke-static {}, Ltb/ty0;->s()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p1, Lcn/damai/commonbusiness/faceverify/request/AccountRealNameAuthRequest;->loginKey:Ljava/lang/String;

    .line 3
    iput-object p2, p1, Lcn/damai/commonbusiness/faceverify/request/AccountRealNameAuthRequest;->idCard:Ljava/lang/String;

    .line 4
    iput-object p4, p1, Lcn/damai/commonbusiness/faceverify/request/AccountRealNameAuthRequest;->name:Ljava/lang/String;

    .line 5
    iput-object p3, p1, Lcn/damai/commonbusiness/faceverify/request/AccountRealNameAuthRequest;->idCardType:Ljava/lang/String;

    .line 6
    new-instance p2, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$8;

    const-class p3, Lcn/damai/commonbusiness/faceverify/bean/BaseFaceVerifyBean;

    invoke-direct {p2, p0, p3}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$8;-><init>(Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;Ljava/lang/Class;)V

    .line 7
    invoke-virtual {p1, p2}, Lcn/damai/common/net/mtop/netfit/DMBaseMtopRequest;->request(Lcom/taobao/tao/remotebusiness/IRemoteBaseListener;)Lcom/taobao/tao/remotebusiness/MtopBusiness;

    return-void
.end method

.method private k(Lcn/damai/commonbusiness/faceverify/bean/IdentityInfoQueryBean;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "15"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->b:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;

    if-nez v0, :cond_22

    .line 2
    new-instance v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;

    invoke-direct {v0}, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;-><init>()V

    iput-object v0, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->b:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;

    .line 3
    :cond_22
    iget-object v0, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->b:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;

    invoke-virtual {p1}, Lcn/damai/commonbusiness/faceverify/bean/IdentityInfoQueryBean;->getIdCard()Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;->d:Ljava/lang/String;

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->b:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;

    invoke-virtual {p1}, Lcn/damai/commonbusiness/faceverify/bean/IdentityInfoQueryBean;->getIdCardType()Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;->e:Ljava/lang/String;

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->b:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;

    invoke-virtual {p1}, Lcn/damai/commonbusiness/faceverify/bean/IdentityInfoQueryBean;->getName()Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;->f:Ljava/lang/String;

    .line 6
    iget-object v0, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->b:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;

    invoke-virtual {p1}, Lcn/damai/commonbusiness/faceverify/bean/IdentityInfoQueryBean;->getIdentityHash()Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;->g:Ljava/lang/String;

    .line 7
    iget-object v0, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->b:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;

    invoke-virtual {p1}, Lcn/damai/commonbusiness/faceverify/bean/IdentityInfoQueryBean;->isNeedFaceVerify()Z

    move-result p1

    iput-boolean p1, v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;->h:Z

    return-void
.end method

.method private l(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 14

    sget-object v0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "12"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_23

    const/4 v2, 0x6

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    aput-object p3, v2, p1

    const/4 p1, 0x4

    aput-object p4, v2, p1

    const/4 p1, 0x5

    aput-object p5, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_23
    new-instance v0, Lcn/damai/commonbusiness/faceverify/request/CustomerAccountVerifyRequest;

    invoke-direct {v0}, Lcn/damai/commonbusiness/faceverify/request/CustomerAccountVerifyRequest;-><init>()V

    .line 2
    iput-object p5, v0, Lcn/damai/commonbusiness/faceverify/request/CustomerAccountVerifyRequest;->scene:Ljava/lang/String;

    .line 3
    new-instance p5, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$5;

    const-class v3, Lcn/damai/commonbusiness/faceverify/bean/CustomerAccountVerifyBean;

    move-object v1, p5

    move-object v2, p0

    move-object v4, p1

    move-object v5, p2

    move-object v6, p3

    move-object v7, p4

    invoke-direct/range {v1 .. v7}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$5;-><init>(Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;Ljava/lang/Class;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 4
    invoke-virtual {v0, p5}, Lcn/damai/common/net/mtop/netfit/DMBaseMtopRequest;->request(Lcom/taobao/tao/remotebusiness/IRemoteBaseListener;)Lcom/taobao/tao/remotebusiness/MtopBusiness;

    return-void
.end method

.method private m(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 15

    sget-object v0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "13"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_20

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    aput-object p3, v2, p1

    const/4 p1, 0x4

    aput-object p4, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_20
    invoke-static {}, Ltb/x3;->b()Ltb/x3;

    move-result-object v0

    invoke-virtual {v0}, Ltb/x3;->c()Landroid/app/Activity;

    move-result-object v0

    if-eqz v0, :cond_58

    .line 2
    new-instance v1, Ltb/r6;

    invoke-direct {v1, v0}, Ltb/r6;-><init>(Landroid/content/Context;)V

    new-instance v0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$c;

    move-object v4, v0

    move-object v5, p0

    move-object v6, p1

    move-object v7, p2

    move-object v8, p3

    move-object v9, p4

    invoke-direct/range {v4 .. v9}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$c;-><init>(Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string p1, "\u662f"

    .line 3
    invoke-virtual {v1, p1, v0}, Ltb/r6;->g(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Ltb/r6;

    move-result-object p1

    new-instance p2, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$b;

    invoke-direct {p2, p0}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$b;-><init>(Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;)V

    const-string p3, "\u5426"

    .line 4
    invoke-virtual {p1, p3, p2}, Ltb/r6;->f(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Ltb/r6;

    move-result-object p1

    const-string p2, "\u5c06\u8be5\u4eba\u8138\u4fe1\u606f\u8865\u5145\u5230\u60a8\u7684\u8d26\u53f7\u5b9e\u540d\u8ba4\u8bc1\uff1f"

    .line 5
    invoke-virtual {p1, p2}, Ltb/r6;->e(Ljava/lang/CharSequence;)Ltb/r6;

    move-result-object p1

    .line 6
    invoke-virtual {p1, v3}, Ltb/r6;->d(Z)Ltb/r6;

    move-result-object p1

    .line 7
    invoke-virtual {p1}, Ltb/r6;->i()Lcn/damai/common/app/widget/DMDialog;

    :cond_58
    return-void
.end method

.method public static n()Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;

    return-object v0

    .line 1
    :cond_14
    invoke-static {}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$d;->a()Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;

    move-result-object v0

    return-object v0
.end method

.method private o(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 16

    sget-object v0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "9"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_23

    const/4 v2, 0x6

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    aput-object p3, v2, p1

    const/4 p1, 0x4

    aput-object p4, v2, p1

    const/4 p1, 0x5

    aput-object p5, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_23
    new-instance v0, Lcn/damai/commonbusiness/faceverify/request/FaceVerifyTokenRequest;

    invoke-direct {v0}, Lcn/damai/commonbusiness/faceverify/request/FaceVerifyTokenRequest;-><init>()V

    .line 2
    invoke-static {}, Ltb/ty0;->s()Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcn/damai/commonbusiness/faceverify/request/FaceVerifyTokenRequest;->loginKey:Ljava/lang/String;

    .line 3
    iput-object p4, v0, Lcn/damai/commonbusiness/faceverify/request/FaceVerifyTokenRequest;->name:Ljava/lang/String;

    .line 4
    iput-object p2, v0, Lcn/damai/commonbusiness/faceverify/request/FaceVerifyTokenRequest;->idCard:Ljava/lang/String;

    .line 5
    iput-object p3, v0, Lcn/damai/commonbusiness/faceverify/request/FaceVerifyTokenRequest;->idCardType:Ljava/lang/String;

    .line 6
    iput-object p5, v0, Lcn/damai/commonbusiness/faceverify/request/FaceVerifyTokenRequest;->scene:Ljava/lang/String;

    .line 7
    new-instance v1, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$2;

    const-class v4, Lcn/damai/commonbusiness/faceverify/bean/FaceVerifyTokenBean;

    move-object v2, v1

    move-object v3, p0

    move-object v5, p1

    move-object v6, p2

    move-object v7, p3

    move-object v8, p4

    move-object v9, p5

    invoke-direct/range {v2 .. v9}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$2;-><init>(Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;Ljava/lang/Class;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 8
    invoke-virtual {v0, v1}, Lcn/damai/common/net/mtop/netfit/DMBaseMtopRequest;->request(Lcom/taobao/tao/remotebusiness/IRemoteBaseListener;)Lcom/taobao/tao/remotebusiness/MtopBusiness;

    return-void
.end method

.method private p(Lcom/alibaba/security/rp/RPSDK$AUDIT;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 18

    move-object/from16 v8, p6

    sget-object v0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "11"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_28

    const/4 v2, 0x7

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 v3, 0x2

    aput-object p2, v2, v3

    const/4 v3, 0x3

    aput-object p3, v2, v3

    const/4 v3, 0x4

    aput-object p4, v2, v3

    const/4 v3, 0x5

    aput-object p5, v2, v3

    const/4 v3, 0x6

    aput-object v8, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_28
    new-instance v9, Lcn/damai/commonbusiness/faceverify/request/FaceVerifyNextStepRequest;

    invoke-direct {v9}, Lcn/damai/commonbusiness/faceverify/request/FaceVerifyNextStepRequest;-><init>()V

    .line 2
    iput-object v8, v9, Lcn/damai/commonbusiness/faceverify/request/FaceVerifyNextStepRequest;->scene:Ljava/lang/String;

    .line 3
    invoke-static {}, Ltb/ty0;->s()Ljava/lang/String;

    move-result-object v0

    iput-object v0, v9, Lcn/damai/commonbusiness/faceverify/request/FaceVerifyNextStepRequest;->loginKey:Ljava/lang/String;

    .line 4
    new-instance v10, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$4;

    const-class v2, Lcn/damai/commonbusiness/faceverify/bean/BaseFaceVerifyBean;

    move-object v0, v10

    move-object v1, p0

    move-object v3, p1

    move-object v4, p2

    move-object v5, p3

    move-object v6, p4

    move-object/from16 v7, p5

    move-object/from16 v8, p6

    invoke-direct/range {v0 .. v8}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$4;-><init>(Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;Ljava/lang/Class;Lcom/alibaba/security/rp/RPSDK$AUDIT;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 5
    invoke-virtual {v9, v10}, Lcn/damai/common/net/mtop/netfit/DMBaseMtopRequest;->request(Lcom/taobao/tao/remotebusiness/IRemoteBaseListener;)Lcom/taobao/tao/remotebusiness/MtopBusiness;

    return-void
.end method

.method private q(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 11

    sget-object v0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "8"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_26

    const/4 v2, 0x7

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    aput-object p3, v2, p1

    const/4 p1, 0x4

    aput-object p4, v2, p1

    const/4 p1, 0x5

    aput-object p5, v2, p1

    const/4 p1, 0x6

    aput-object p6, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_26
    new-instance v0, Lcn/damai/commonbusiness/faceverify/request/IdentityInfoQueryRequest;

    invoke-direct {v0}, Lcn/damai/commonbusiness/faceverify/request/IdentityInfoQueryRequest;-><init>()V

    .line 2
    iput-object p2, v0, Lcn/damai/commonbusiness/faceverify/request/IdentityInfoQueryRequest;->idCard:Ljava/lang/String;

    .line 3
    iput-object p4, v0, Lcn/damai/commonbusiness/faceverify/request/IdentityInfoQueryRequest;->name:Ljava/lang/String;

    .line 4
    iput-object p3, v0, Lcn/damai/commonbusiness/faceverify/request/IdentityInfoQueryRequest;->idCardType:Ljava/lang/String;

    .line 5
    iput-object p5, v0, Lcn/damai/commonbusiness/faceverify/request/IdentityInfoQueryRequest;->cryptographicInfo:Ljava/lang/String;

    .line 6
    invoke-static {}, Ltb/ty0;->s()Ljava/lang/String;

    move-result-object p2

    iput-object p2, v0, Lcn/damai/commonbusiness/faceverify/request/IdentityInfoQueryRequest;->loginKey:Ljava/lang/String;

    .line 7
    new-instance p2, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$1;

    const-class p3, Lcn/damai/commonbusiness/faceverify/bean/IdentityInfoQueryBean;

    invoke-direct {p2, p0, p3, p1, p6}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$1;-><init>(Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;Ljava/lang/Class;Landroid/content/Context;Ljava/lang/String;)V

    .line 8
    invoke-virtual {v0, p2}, Lcn/damai/common/net/mtop/netfit/DMBaseMtopRequest;->request(Lcom/taobao/tao/remotebusiness/IRemoteBaseListener;)Lcom/taobao/tao/remotebusiness/MtopBusiness;

    return-void
.end method

.method private s(Ljava/lang/String;Ljava/lang/String;)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "18"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1a
    iget-object v0, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->a:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyListener;

    if-eqz v0, :cond_30

    .line 2
    new-instance v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;

    invoke-direct {v0}, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;-><init>()V

    .line 3
    sget-object v1, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;->FAIL:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;

    iput-object v1, v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;->a:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;

    .line 4
    iput-object p1, v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;->b:Ljava/lang/String;

    .line 5
    iput-object p2, v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;->c:Ljava/lang/String;

    .line 6
    iget-object p1, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->a:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyListener;

    invoke-interface {p1, v0}, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyListener;->onAuditResult(Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;)V

    :cond_30
    return-void
.end method

.method private t()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "17"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->a:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyListener;

    if-eqz v0, :cond_1d

    .line 2
    iget-object v1, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->b:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;

    invoke-interface {v0, v1}, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyListener;->onAuditResult(Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;)V

    :cond_1d
    return-void
.end method

.method private y(Landroid/content/Context;Lcn/damai/commonbusiness/faceverify/bean/FaceVerifyTokenBean;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 15

    sget-object v0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "10"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_26

    const/4 v2, 0x7

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    aput-object p3, v2, p1

    const/4 p1, 0x4

    aput-object p4, v2, p1

    const/4 p1, 0x5

    aput-object p5, v2, p1

    const/4 p1, 0x6

    aput-object p6, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_26
    if-eqz p2, :cond_89

    .line 1
    invoke-virtual {p2}, Lcn/damai/commonbusiness/faceverify/bean/FaceVerifyTokenBean;->getVerifyToken()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_89

    .line 2
    :try_start_32
    invoke-static {}, Ltb/o52;->a()Landroid/app/Application;

    move-result-object v0
    :try_end_36
    .catch Ljava/lang/Exception; {:try_start_32 .. :try_end_36} :catch_85

    const-string v1, "faceService"

    const-string v2, "contentlabel"

    if-nez v0, :cond_50

    .line 3
    :try_start_3c
    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    const-string p2, "application \u4e3anull"

    .line 4
    invoke-virtual {p1, v2, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 5
    invoke-static {}, Lcn/damai/common/user/c;->d()Lcn/damai/common/user/c;

    move-result-object p2

    const-string p3, "RPSDK_Application"

    invoke-virtual {p2, p1, p3, v1}, Lcn/damai/common/user/c;->t(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 6
    :cond_50
    invoke-static {}, Ltb/o52;->a()Landroid/app/Application;

    move-result-object v0

    invoke-static {v0}, Ltb/zr4;->a(Landroid/content/Context;)V

    .line 7
    invoke-static {}, Lcom/alibaba/security/rp/RPSDK;->getContext()Landroid/content/Context;

    move-result-object v0

    if-nez v0, :cond_71

    .line 8
    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    const-string p2, "RPSDK Context \u4e3anull"

    .line 9
    invoke-virtual {p1, v2, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    invoke-static {}, Lcn/damai/common/user/c;->d()Lcn/damai/common/user/c;

    move-result-object p2

    const-string p3, "RPSDK_Context"

    invoke-virtual {p2, p1, p3, v1}, Lcn/damai/common/user/c;->t(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 11
    :cond_71
    invoke-virtual {p2}, Lcn/damai/commonbusiness/faceverify/bean/FaceVerifyTokenBean;->getVerifyToken()Ljava/lang/String;

    move-result-object p2

    new-instance v7, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$a;

    move-object v0, v7

    move-object v1, p0

    move-object v2, p1

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    move-object v6, p6

    invoke-direct/range {v0 .. v6}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$a;-><init>(Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {p2, p1, v7}, Lcom/alibaba/security/rp/RPSDK;->start(Ljava/lang/String;Landroid/content/Context;Lcom/alibaba/security/rp/RPSDK$RPCompletedListener;)V
    :try_end_84
    .catch Ljava/lang/Exception; {:try_start_3c .. :try_end_84} :catch_85

    goto :goto_89

    :catch_85
    move-exception p1

    .line 12
    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    :cond_89
    :goto_89
    return-void
.end method


# virtual methods
.method public r()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "19"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->a:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyListener;

    if-eqz v0, :cond_26

    .line 2
    new-instance v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;

    invoke-direct {v0}, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;-><init>()V

    .line 3
    sget-object v1, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;->EMPTY:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;

    iput-object v1, v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;->a:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult$State;

    .line 4
    iget-object v1, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->a:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyListener;

    invoke-interface {v1, v0}, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyListener;->onAuditResult(Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;)V

    :cond_26
    return-void
.end method

.method public u(Lcn/damai/commonbusiness/faceverify/bean/IdentityInfoQueryBean;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "16"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->b:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;

    if-nez v0, :cond_22

    .line 2
    new-instance v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;

    invoke-direct {v0}, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;-><init>()V

    iput-object v0, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->b:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;

    :cond_22
    if-eqz p1, :cond_4c

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->b:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;

    invoke-virtual {p1}, Lcn/damai/commonbusiness/faceverify/bean/IdentityInfoQueryBean;->getIdCard()Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;->d:Ljava/lang/String;

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->b:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;

    invoke-virtual {p1}, Lcn/damai/commonbusiness/faceverify/bean/IdentityInfoQueryBean;->getIdCardType()Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;->e:Ljava/lang/String;

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->b:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;

    invoke-virtual {p1}, Lcn/damai/commonbusiness/faceverify/bean/IdentityInfoQueryBean;->getName()Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;->f:Ljava/lang/String;

    .line 6
    iget-object v0, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->b:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;

    invoke-virtual {p1}, Lcn/damai/commonbusiness/faceverify/bean/IdentityInfoQueryBean;->getIdentityHash()Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;->g:Ljava/lang/String;

    .line 7
    iget-object v0, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->b:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;

    invoke-virtual {p1}, Lcn/damai/commonbusiness/faceverify/bean/IdentityInfoQueryBean;->isNeedFaceVerify()Z

    move-result p1

    iput-boolean p1, v0, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;->h:Z

    .line 8
    :cond_4c
    iget-object p1, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->a:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyListener;

    if-eqz p1, :cond_55

    .line 9
    iget-object v0, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->b:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;

    invoke-interface {p1, v0}, Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyListener;->onAuditResult(Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;)V

    :cond_55
    return-void
.end method

.method public v(Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->a:Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyListener;

    return-void
.end method

.method public w(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 16

    sget-object v0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_23

    const/4 v2, 0x6

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    aput-object p3, v2, p1

    const/4 p1, 0x4

    aput-object p4, v2, p1

    const/4 p1, 0x5

    aput-object p5, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_23
    const/4 v8, 0x0

    move-object v3, p0

    move-object v4, p1

    move-object v5, p2

    move-object v6, p3

    move-object v7, p4

    move-object v9, p5

    .line 1
    invoke-virtual/range {v3 .. v9}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->x(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public x(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 11

    sget-object v0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "7"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_26

    const/4 v2, 0x7

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    aput-object p3, v2, p1

    const/4 p1, 0x4

    aput-object p4, v2, p1

    const/4 p1, 0x5

    aput-object p5, v2, p1

    const/4 p1, 0x6

    aput-object p6, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_26
    sget-object v0, Ltb/nw2;->INSTANCE:Ltb/nw2;

    invoke-virtual {v0}, Ltb/nw2;->isLogin()Z

    move-result v1

    if-eqz v1, :cond_5e

    .line 2
    invoke-static {p5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_38

    .line 3
    invoke-direct/range {p0 .. p6}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->q(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_62

    .line 4
    :cond_38
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_4e

    invoke-static {p4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_4e

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_4e

    .line 5
    invoke-direct/range {p0 .. p6}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->q(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_62

    .line 6
    :cond_4e
    new-instance p2, Landroid/content/Intent;

    const-class p3, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;

    invoke-direct {p2, p1, p3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string p3, "scence"

    .line 7
    invoke-virtual {p2, p3, p6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 8
    invoke-virtual {p1, p2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto :goto_62

    :cond_5e
    const/4 p2, 0x0

    .line 9
    invoke-virtual {v0, p1, p2}, Ltb/nw2;->doLoginWithCustomPage(Ljava/lang/Object;Landroid/content/Intent;)V

    :goto_62
    return-void
.end method
