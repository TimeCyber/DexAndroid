.class public Lcn/damai/commonbusiness/home/bean/HomeMessage;
.super Ljava/lang/Object;
.source "Taobao"


# static fields
.field public static final CALENDAR_DATA:Ljava/lang/String; = "calendar_data"

.field public static final EVENT_SCROLL_DISTANCE:Ljava/lang/String; = "event_scroll_distance"

.field public static final EVENT_SCROLL_TO_TOP_OR_RECOMMEND:Ljava/lang/String; = "event_scroll_to_top_or_recommend"

.field public static final HEADER_BG:Ljava/lang/String; = "header_bg"

.field public static final REFRESH_GUESS_DATA:Ljava/lang/String; = "refresh_guess_data"

.field public static final REFRESH_HOME_DATA:Ljava/lang/String; = "refresh_home"

.field public static final SEARCH_WORD:Ljava/lang/String; = "search_word"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
