.class public Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$b;
.super Landroid/view/GestureDetector$SimpleOnGestureListener;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;-><init>(Landroid/widget/ImageView;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$b;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-direct {p0}, Landroid/view/GestureDetector$SimpleOnGestureListener;-><init>()V

    return-void
.end method


# virtual methods
.method public onFling(Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$b;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_2f

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    return p1

    .line 1
    :cond_2f
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$b;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->h(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Lcn/damai/commonbusiness/photoselect/photoview/OnSingleFlingListener;

    move-result-object v0

    if-eqz v0, :cond_66

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$b;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-virtual {v0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->N()F

    move-result v0

    invoke-static {}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->i()F

    move-result v1

    cmpl-float v0, v0, v1

    if-lez v0, :cond_46

    return v3

    .line 3
    :cond_46
    invoke-static {p1}, Landroidx/core/view/MotionEventCompat;->getPointerCount(Landroid/view/MotionEvent;)I

    move-result v0

    invoke-static {}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->j()I

    move-result v1

    if-gt v0, v1, :cond_66

    .line 4
    invoke-static {p2}, Landroidx/core/view/MotionEventCompat;->getPointerCount(Landroid/view/MotionEvent;)I

    move-result v0

    invoke-static {}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->j()I

    move-result v1

    if-le v0, v1, :cond_5b

    goto :goto_66

    .line 5
    :cond_5b
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$b;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->h(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Lcn/damai/commonbusiness/photoselect/photoview/OnSingleFlingListener;

    move-result-object v0

    invoke-interface {v0, p1, p2, p3, p4}, Lcn/damai/commonbusiness/photoselect/photoview/OnSingleFlingListener;->onFling(Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z

    move-result p1

    return p1

    :cond_66
    :goto_66
    return v3
.end method

.method public onLongPress(Landroid/view/MotionEvent;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$b;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$b;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-static {p1}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->g(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Landroid/view/View$OnLongClickListener;

    move-result-object p1

    if-eqz p1, :cond_2e

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$b;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-static {p1}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->g(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Landroid/view/View$OnLongClickListener;

    move-result-object p1

    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher$b;->a:Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;->t(Lcn/damai/commonbusiness/photoselect/photoview/PhotoViewAttacher;)Landroid/widget/ImageView;

    move-result-object v0

    invoke-interface {p1, v0}, Landroid/view/View$OnLongClickListener;->onLongClick(Landroid/view/View;)Z

    :cond_2e
    return-void
.end method
