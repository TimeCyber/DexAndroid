.class public Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask;
.super Landroid/os/AsyncTask;
.source "Taobao"


# annotations
.annotation build Landroid/annotation/SuppressLint;
    value = {
        "NewApi"
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask$Listener;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/String;",
        "Ljava/lang/Void;",
        "Landroid/graphics/Bitmap;",
        ">;"
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private a:Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask$Listener;

.field private b:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask$Listener;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    .line 2
    iput-object p2, p0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask;->a:Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask$Listener;

    .line 3
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask;->b:Landroid/content/Context;

    return-void
.end method

.method public static a(Landroid/content/Context;Landroid/net/Uri;Ljava/lang/String;)Ljava/lang/String;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1d

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 p0, 0x1

    aput-object p1, v2, p0

    const/4 p0, 0x2

    aput-object p2, v2, p0

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0

    .line 1
    :cond_1d
    :try_start_1d
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object p1

    .line 2
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Landroid/content/Context;->getExternalCacheDir()Ljava/io/File;

    move-result-object p0

    invoke-virtual {p0}, Ljava/io/File;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object p0, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    if-eqz p1, :cond_74

    if-eqz p0, :cond_74

    .line 3
    new-instance p2, Ljava/io/File;

    invoke-direct {p2, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 4
    new-instance v0, Ljava/io/FileOutputStream;

    invoke-direct {v0, p2}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 5
    new-instance p2, Ljava/io/BufferedInputStream;

    invoke-direct {p2, p1}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;)V

    .line 6
    new-instance p1, Ljava/io/BufferedOutputStream;

    invoke-direct {p1, v0}, Ljava/io/BufferedOutputStream;-><init>(Ljava/io/OutputStream;)V

    const/16 v1, 0x400

    new-array v1, v1, [B

    .line 7
    invoke-virtual {p2, v1}, Ljava/io/BufferedInputStream;->read([B)I

    move-result v2

    :goto_61
    if-lez v2, :cond_6e

    .line 8
    invoke-virtual {p1, v1, v3, v2}, Ljava/io/BufferedOutputStream;->write([BII)V

    .line 9
    invoke-virtual {p1}, Ljava/io/BufferedOutputStream;->flush()V

    .line 10
    invoke-virtual {p2, v1}, Ljava/io/BufferedInputStream;->read([B)I

    move-result v2

    goto :goto_61

    .line 11
    :cond_6e
    invoke-virtual {p1}, Ljava/io/BufferedOutputStream;->close()V

    .line 12
    invoke-virtual {v0}, Ljava/io/FileOutputStream;->close()V
    :try_end_74
    .catch Ljava/lang/Exception; {:try_start_1d .. :try_end_74} :catch_75

    :cond_74
    return-object p0

    :catch_75
    move-exception p0

    .line 13
    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method private static c(Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/graphics/Bitmap;

    return-object p0

    :cond_1a
    const/4 v0, 0x0

    .line 1
    :try_start_1b
    invoke-static {}, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->c()Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;

    move-result-object v1

    .line 2
    invoke-static {p0}, Ltb/g31;->b(Landroid/content/Context;)Landroid/util/DisplayMetrics;

    move-result-object v2

    invoke-static {v2}, Lcom/alibaba/wireless/security/aopsdk/replace/android/util/DisplayMetrics;->getwidthPixels(Landroid/util/DisplayMetrics;)I

    move-result v2

    sget v4, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->e:I

    div-int/2addr v2, v4

    invoke-static {p0}, Ltb/g31;->b(Landroid/content/Context;)Landroid/util/DisplayMetrics;

    move-result-object p0

    invoke-static {p0}, Lcom/alibaba/wireless/security/aopsdk/replace/android/util/DisplayMetrics;->getwidthPixels(Landroid/util/DisplayMetrics;)I

    move-result p0

    sget v4, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->e:I

    div-int/2addr p0, v4

    .line 3
    invoke-virtual {v1, p1, v3, v2, p0}, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->e(Ljava/lang/String;III)Landroid/graphics/Bitmap;

    move-result-object v0
    :try_end_39
    .catch Ljava/lang/Exception; {:try_start_1b .. :try_end_39} :catch_3a

    goto :goto_3e

    :catch_3a
    move-exception p0

    .line 4
    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    :goto_3e
    return-object v0
.end method


# virtual methods
.method protected varargs b([Ljava/lang/String;)Landroid/graphics/Bitmap;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/graphics/Bitmap;

    return-object p1

    .line 1
    :cond_1a
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask;->b:Landroid/content/Context;

    aget-object v1, p1, v3

    invoke-static {v0, v1}, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask;->c(Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    if-eqz v0, :cond_2c

    .line 2
    sget-object v1, Ltb/qs;->a:Landroid/util/LruCache;

    aget-object p1, p1, v3

    invoke-virtual {v1, p1, v0}, Landroid/util/LruCache;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-object v0

    .line 3
    :cond_2c
    new-instance v0, Landroid/util/Size;

    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask;->b:Landroid/content/Context;

    invoke-static {v1}, Ltb/g31;->b(Landroid/content/Context;)Landroid/util/DisplayMetrics;

    move-result-object v1

    invoke-static {v1}, Lcom/alibaba/wireless/security/aopsdk/replace/android/util/DisplayMetrics;->getwidthPixels(Landroid/util/DisplayMetrics;)I

    move-result v1

    sget v2, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->e:I

    div-int/2addr v1, v2

    iget-object v2, p0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask;->b:Landroid/content/Context;

    .line 4
    invoke-static {v2}, Ltb/g31;->b(Landroid/content/Context;)Landroid/util/DisplayMetrics;

    move-result-object v2

    invoke-static {v2}, Lcom/alibaba/wireless/security/aopsdk/replace/android/util/DisplayMetrics;->getwidthPixels(Landroid/util/DisplayMetrics;)I

    move-result v2

    sget v4, Lcn/damai/commonbusiness/photoselect/imageselected/utils/MediaUtils;->e:I

    div-int/2addr v2, v4

    invoke-direct {v0, v1, v2}, Landroid/util/Size;-><init>(II)V

    .line 5
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1d

    const/4 v4, 0x0

    if-lt v1, v2, :cond_67

    .line 6
    :try_start_52
    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask;->b:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    aget-object v2, p1, v3

    .line 7
    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v1, v2, v0, v4}, Landroid/content/ContentResolver;->loadThumbnail(Landroid/net/Uri;Landroid/util/Size;Landroid/os/CancellationSignal;)Landroid/graphics/Bitmap;

    move-result-object v4
    :try_end_62
    .catch Ljava/lang/Exception; {:try_start_52 .. :try_end_62} :catch_63

    goto :goto_67

    :catch_63
    move-exception v0

    .line 8
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :cond_67
    :goto_67
    if-eqz v4, :cond_70

    .line 9
    sget-object v0, Ltb/qs;->a:Landroid/util/LruCache;

    aget-object p1, p1, v3

    invoke-virtual {v0, p1, v4}, Landroid/util/LruCache;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_70
    return-object v4
.end method

.method protected d(Landroid/graphics/Bitmap;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask;->a:Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask$Listener;

    invoke-interface {v0, p1}, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask$Listener;->onSuccess(Landroid/graphics/Bitmap;)V

    return-void
.end method

.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 1
    check-cast p1, [Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask;->b([Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object p1

    return-object p1
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .registers 2

    .line 1
    check-cast p1, Landroid/graphics/Bitmap;

    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask;->d(Landroid/graphics/Bitmap;)V

    return-void
.end method
