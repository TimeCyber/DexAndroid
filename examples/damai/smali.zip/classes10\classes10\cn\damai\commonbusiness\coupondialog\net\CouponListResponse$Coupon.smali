.class public Lcn/damai/commonbusiness/coupondialog/net/CouponListResponse$Coupon;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/coupondialog/net/CouponListResponse;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Coupon"
.end annotation


# instance fields
.field public amount:Ljava/lang/String;

.field public condition:Ljava/lang/String;

.field public couponId:Ljava/lang/String;

.field public endTime:Ljava/lang/String;

.field public eventTrack:Ljava/lang/String;

.field public name:Ljava/lang/String;

.field public startShowTimeMillis:J

.field public startTime:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
