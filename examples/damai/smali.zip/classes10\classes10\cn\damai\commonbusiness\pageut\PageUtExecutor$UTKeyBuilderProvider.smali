.class public interface abstract Lcn/damai/commonbusiness/pageut/PageUtExecutor$UTKeyBuilderProvider;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/pageut/PageUtExecutor;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "UTKeyBuilderProvider"
.end annotation


# virtual methods
.method public abstract get(I)Lcn/damai/common/user/a$b;
.end method
