.class public Lcn/damai/commonbusiness/model/RealNameInfo;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public certificateNo:Ljava/lang/String;

.field public mobile:Ljava/lang/String;

.field public realNameStatus:Z

.field public userName:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
