.class public Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver$1;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->u(Landroid/content/Context;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic val$context:Landroid/content/Context;

.field final synthetic val$msg:Ljava/lang/String;


# direct methods
.method constructor <init>(Landroid/content/Context;Ljava/lang/String;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver$1;->val$context:Landroid/content/Context;

    iput-object p2, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver$1;->val$msg:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver$1;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    invoke-static {}, Lcn/damai/common/util/ToastUtil;->a()Lcn/damai/common/util/ToastUtil;

    move-result-object v0

    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver$1;->val$context:Landroid/content/Context;

    iget-object v2, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver$1;->val$msg:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lcn/damai/common/util/ToastUtil;->e(Landroid/content/Context;Ljava/lang/String;)V

    return-void
.end method
