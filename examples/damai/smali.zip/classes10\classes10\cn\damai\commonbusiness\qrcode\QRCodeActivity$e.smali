.class public Lcn/damai/commonbusiness/qrcode/QRCodeActivity$e;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/qrcode/QRCodeActivity;->renderArTab()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcom/alibaba/pictures/bricks/home/ARBean;

.field final synthetic b:Lcn/damai/commonbusiness/qrcode/QRCodeActivity;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/qrcode/QRCodeActivity;Lcom/alibaba/pictures/bricks/home/ARBean;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/qrcode/QRCodeActivity$e;->b:Lcn/damai/commonbusiness/qrcode/QRCodeActivity;

    iput-object p2, p0, Lcn/damai/commonbusiness/qrcode/QRCodeActivity$e;->a:Lcom/alibaba/pictures/bricks/home/ARBean;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/qrcode/QRCodeActivity$e;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    sget-object p1, Ltb/yd3;->INSTANCE:Ltb/yd3;

    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/QRCodeActivity$e;->b:Lcn/damai/commonbusiness/qrcode/QRCodeActivity;

    iget-object v1, p0, Lcn/damai/commonbusiness/qrcode/QRCodeActivity$e;->a:Lcom/alibaba/pictures/bricks/home/ARBean;

    iget-object v1, v1, Lcom/alibaba/pictures/bricks/home/ARBean;->actionUrl:Ljava/lang/String;

    invoke-virtual {p1, v0, v1}, Ltb/yd3;->handleUrl(Landroid/content/Context;Ljava/lang/String;)Z

    .line 2
    sget-object p1, Ltb/cb1;->INSTANCE:Ltb/cb1;

    invoke-virtual {p1}, Ltb/cb1;->f()Lcom/alibaba/pictures/ut/ClickCat;

    move-result-object p1

    const-string v0, "scan"

    .line 3
    invoke-virtual {p1, v0}, Lcom/alibaba/pictures/ut/ClickCat;->o(Ljava/lang/String;)Lcom/alibaba/pictures/ut/ClickCat;

    move-result-object p1

    const-string v0, "bottom"

    const-string v1, "arscan"

    .line 4
    invoke-virtual {p1, v0, v1}, Lcom/alibaba/pictures/ut/ClickCat;->v(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/pictures/ut/ClickCat;

    move-result-object p1

    .line 5
    invoke-virtual {p1, v3}, Lcom/alibaba/pictures/ut/ClickCat;->n(Z)Lcom/alibaba/pictures/ut/ClickCat;

    move-result-object p1

    .line 6
    invoke-virtual {p1}, Lcom/alibaba/pictures/ut/ClickCat;->j()V

    return-void
.end method
