.class public Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10$1;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;->onSuccess(Ljava/util/ArrayList;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic this$1:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10$1;->this$1:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10$1;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_14

    new-array v2, v3, [Ljava/lang/Object;

    aput-object p0, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10$1;->this$1:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;

    iget-object v0, v0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;->b:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;->access$300(Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;)Ljava/util/ArrayList;

    move-result-object v0

    if-eqz v0, :cond_f7

    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10$1;->this$1:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;

    iget-object v0, v0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;->b:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;->access$300(Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_f7

    .line 2
    new-instance v0, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;

    invoke-direct {v0}, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;-><init>()V

    const-string v1, "3"

    .line 3
    invoke-virtual {v0, v1}, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;->setType(Ljava/lang/String;)V

    const-string v1, "take_picture"

    .line 4
    invoke-virtual {v0, v1}, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;->setPath(Ljava/lang/String;)V

    .line 5
    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10$1;->this$1:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;

    iget-object v1, v1, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;->b:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;

    invoke-static {v1}, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;->access$300(Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;)Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltb/ww1;

    invoke-virtual {v1}, Ltb/ww1;->b()Ljava/util/ArrayList;

    move-result-object v1

    invoke-static {v1}, Ltb/mw5;->f(Ljava/util/List;)I

    move-result v1

    if-lez v1, :cond_69

    .line 6
    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10$1;->this$1:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;

    iget-object v1, v1, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;->b:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;

    invoke-static {v1}, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;->access$300(Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;)Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltb/ww1;

    invoke-virtual {v1}, Ltb/ww1;->b()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v4, v0}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    goto :goto_82

    .line 7
    :cond_69
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 8
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 9
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10$1;->this$1:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;

    iget-object v0, v0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;->b:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;->access$300(Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltb/ww1;

    invoke-virtual {v0, v1}, Ltb/ww1;->d(Ljava/util/ArrayList;)V

    .line 10
    :goto_82
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10$1;->this$1:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;

    iget-object v0, v0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;->b:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;->access$300(Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;)Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ltb/ww1;

    invoke-static {v0, v1}, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;->access$800(Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;Ltb/ww1;)V

    .line 11
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10$1;->this$1:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;

    iget-boolean v1, v0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;->a:Z

    if-eqz v1, :cond_f0

    .line 12
    iget-object v0, v0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;->b:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;->access$300(Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltb/ww1;

    invoke-virtual {v0}, Ltb/ww1;->b()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;

    .line 13
    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10$1;->this$1:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;

    iget-object v1, v1, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;->b:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;

    invoke-static {v1}, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;->access$000(Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;)Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;

    move-result-object v1

    invoke-virtual {v1}, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;->g()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/2addr v1, v3

    invoke-virtual {v0, v1}, Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;->setShowNum(I)V

    .line 14
    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10$1;->this$1:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;

    iget-object v1, v1, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;->b:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;

    invoke-static {v1}, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;->access$000(Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;)Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;

    move-result-object v1

    invoke-virtual {v1}, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;->g()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 15
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10$1;->this$1:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;

    iget-object v0, v0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;->b:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;->access$000(Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;)Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 16
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10$1;->this$1:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;

    iget-object v0, v0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;->b:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;->access$000(Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;)Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;

    move-result-object v1

    invoke-virtual {v1}, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImageAdapter;->g()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    invoke-static {v0, v1}, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;->access$400(Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;I)V

    .line 17
    :cond_f0
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10$1;->this$1:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;

    iget-object v0, v0, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity$10;->b:Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;->access$900(Lcn/damai/commonbusiness/photoselect/imageselected/ImageSelectorActivity;)V

    :cond_f7
    return-void
.end method
