.class public Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo$ProjectInfo;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/imagebrowse/bean/VideoInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "ProjectInfo"
.end annotation


# instance fields
.field public id:Ljava/lang/String;

.field public name:Ljava/lang/String;

.field public priceStr:Ljava/lang/String;

.field public showTime:Ljava/lang/String;

.field public subTitle:Ljava/lang/String;

.field public venueCity:Ljava/lang/String;

.field public venueName:Ljava/lang/String;

.field public verticalPic:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
