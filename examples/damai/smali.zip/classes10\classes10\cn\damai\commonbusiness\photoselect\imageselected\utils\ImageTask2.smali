.class public Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask2;
.super Landroid/os/AsyncTask;
.source "Taobao"


# annotations
.annotation build Landroid/annotation/SuppressLint;
    value = {
        "NewApi"
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask2$Listener;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/String;",
        "Ljava/lang/Void;",
        "Landroid/graphics/Bitmap;",
        ">;"
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private a:Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask2$Listener;

.field private b:Landroid/content/Context;

.field private c:Landroid/widget/ImageView;

.field private d:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;ZLandroid/widget/ImageView;Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask2$Listener;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    .line 2
    iput-object p4, p0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask2;->a:Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask2$Listener;

    .line 3
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask2;->b:Landroid/content/Context;

    .line 4
    iput-boolean p2, p0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask2;->d:Z

    .line 5
    iput-object p3, p0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask2;->c:Landroid/widget/ImageView;

    return-void
.end method

.method private static b(ZLjava/lang/String;)Landroid/graphics/Bitmap;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask2;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    aput-object p0, v2, v3

    const/4 p0, 0x1

    aput-object p1, v2, p0

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/graphics/Bitmap;

    return-object p0

    :cond_1e
    const/4 v0, 0x0

    if-eqz p0, :cond_28

    const/16 p0, 0x190

    .line 1
    :try_start_23
    invoke-static {p1, p0, p0}, Ltb/ii2;->d(Ljava/lang/String;II)Landroid/graphics/Bitmap;

    move-result-object p0

    goto :goto_30

    :cond_28
    const/16 p0, 0x320

    const/16 v1, 0x514

    .line 2
    invoke-static {p1, p0, v1}, Ltb/ii2;->d(Ljava/lang/String;II)Landroid/graphics/Bitmap;

    move-result-object p0
    :try_end_30
    .catch Ljava/lang/Exception; {:try_start_23 .. :try_end_30} :catch_32

    :goto_30
    move-object v0, p0

    goto :goto_36

    :catch_32
    move-exception p0

    .line 3
    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    :goto_36
    return-object v0
.end method


# virtual methods
.method protected varargs a([Ljava/lang/String;)Landroid/graphics/Bitmap;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask2;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/graphics/Bitmap;

    return-object p1

    .line 1
    :cond_1a
    iget-boolean v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask2;->d:Z

    aget-object v1, p1, v3

    invoke-static {v0, v1}, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask2;->b(ZLjava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    if-eqz v0, :cond_2b

    .line 2
    sget-object v1, Ltb/qs;->a:Landroid/util/LruCache;

    aget-object p1, p1, v3

    invoke-virtual {v1, p1, v0}, Landroid/util/LruCache;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2b
    return-object v0
.end method

.method protected c(Landroid/graphics/Bitmap;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask2;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-super {p0, p1}, Landroid/os/AsyncTask;->onPostExecute(Ljava/lang/Object;)V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask2;->a:Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask2$Listener;

    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask2;->c:Landroid/widget/ImageView;

    invoke-interface {v0, v1, p1}, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask2$Listener;->onSuccess(Landroid/widget/ImageView;Landroid/graphics/Bitmap;)V

    return-void
.end method

.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 1
    check-cast p1, [Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask2;->a([Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object p1

    return-object p1
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .registers 2

    .line 1
    check-cast p1, Landroid/graphics/Bitmap;

    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/photoselect/imageselected/utils/ImageTask2;->c(Landroid/graphics/Bitmap;)V

    return-void
.end method
