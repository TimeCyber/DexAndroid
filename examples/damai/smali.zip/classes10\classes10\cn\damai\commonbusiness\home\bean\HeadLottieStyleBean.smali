.class public Lcn/damai/commonbusiness/home/bean/HeadLottieStyleBean;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x1d484083b42216c7L


# instance fields
.field public color:Ljava/lang/String;

.field public index:I

.field public schemaLeft:Ljava/lang/String;

.field public schemaRight:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
