.class public Lcn/damai/commonbusiness/qrcode/QRCodeActivity$1$1;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/qrcode/QRCodeActivity$1;->onParametersSetted(J)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic this$1:Lcn/damai/commonbusiness/qrcode/QRCodeActivity$1;

.field final synthetic val$pcode:J


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/qrcode/QRCodeActivity$1;J)V
    .registers 4

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/qrcode/QRCodeActivity$1$1;->this$1:Lcn/damai/commonbusiness/qrcode/QRCodeActivity$1;

    iput-wide p2, p0, Lcn/damai/commonbusiness/qrcode/QRCodeActivity$1$1;->val$pcode:J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/qrcode/QRCodeActivity$1$1;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_14

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/QRCodeActivity$1$1;->this$1:Lcn/damai/commonbusiness/qrcode/QRCodeActivity$1;

    iget-object v0, v0, Lcn/damai/commonbusiness/qrcode/QRCodeActivity$1;->a:Lcn/damai/commonbusiness/qrcode/QRCodeActivity;

    iget-wide v1, p0, Lcn/damai/commonbusiness/qrcode/QRCodeActivity$1$1;->val$pcode:J

    invoke-static {v0, v1, v2}, Lcn/damai/commonbusiness/qrcode/QRCodeActivity;->access$002(Lcn/damai/commonbusiness/qrcode/QRCodeActivity;J)J

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/QRCodeActivity$1$1;->this$1:Lcn/damai/commonbusiness/qrcode/QRCodeActivity$1;

    iget-object v0, v0, Lcn/damai/commonbusiness/qrcode/QRCodeActivity$1;->a:Lcn/damai/commonbusiness/qrcode/QRCodeActivity;

    invoke-static {v0, v3}, Lcn/damai/commonbusiness/qrcode/QRCodeActivity;->access$102(Lcn/damai/commonbusiness/qrcode/QRCodeActivity;Z)Z

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/QRCodeActivity$1$1;->this$1:Lcn/damai/commonbusiness/qrcode/QRCodeActivity$1;

    iget-object v0, v0, Lcn/damai/commonbusiness/qrcode/QRCodeActivity$1;->a:Lcn/damai/commonbusiness/qrcode/QRCodeActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/qrcode/QRCodeActivity;->access$200(Lcn/damai/commonbusiness/qrcode/QRCodeActivity;)V

    return-void
.end method
