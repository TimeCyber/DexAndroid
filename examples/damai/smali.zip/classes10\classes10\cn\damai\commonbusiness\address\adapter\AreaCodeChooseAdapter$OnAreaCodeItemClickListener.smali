.class public interface abstract Lcn/damai/commonbusiness/address/adapter/AreaCodeChooseAdapter$OnAreaCodeItemClickListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/address/adapter/AreaCodeChooseAdapter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnAreaCodeItemClickListener"
.end annotation


# virtual methods
.method public abstract onItemClick(I)V
.end method
