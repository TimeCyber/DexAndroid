.class public Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$j;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;->showDoubleCheckDialog(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;

.field final synthetic c:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;Ljava/lang/String;Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;)V
    .registers 4

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$j;->c:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;

    iput-object p2, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$j;->a:Ljava/lang/String;

    iput-object p3, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$j;->b:Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .registers 8

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$j;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1e

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1e
    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    .line 2
    iget-object p2, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$j;->a:Ljava/lang/String;

    const-string v0, "certificate_type"

    invoke-interface {p1, v0, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 3
    sget-object p2, Ltb/cb1;->INSTANCE:Ltb/cb1;

    invoke-virtual {p2}, Ltb/cb1;->f()Lcom/alibaba/pictures/ut/ClickCat;

    move-result-object v0

    const-string v1, "page_addbuyperson"

    invoke-virtual {v0, v1}, Lcom/alibaba/pictures/ut/ClickCat;->o(Ljava/lang/String;)Lcom/alibaba/pictures/ut/ClickCat;

    move-result-object v0

    const-string v2, "pop"

    const-string v4, "popconfirmbtn"

    invoke-virtual {v0, v2, v4}, Lcom/alibaba/pictures/ut/ClickCat;->v(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/pictures/ut/ClickCat;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/alibaba/pictures/ut/ClickCat;->q(Ljava/util/Map;)Lcom/alibaba/pictures/ut/ClickCat;

    move-result-object v0

    invoke-virtual {v0, v3}, Lcom/alibaba/pictures/ut/ClickCat;->n(Z)Lcom/alibaba/pictures/ut/ClickCat;

    move-result-object v0

    invoke-virtual {v0}, Lcom/alibaba/pictures/ut/ClickCat;->j()V

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$j;->b:Lcn/damai/commonbusiness/contacts/ui/view/AddContactDoubleCheckView;

    invoke-virtual {p2, v0}, Ltb/cb1;->l(Landroid/view/View;)Lcom/alibaba/pictures/ut/ExposureDog;

    move-result-object p2

    invoke-virtual {p2}, Lcom/alibaba/pictures/ut/ExposureDog;->u()Lcom/alibaba/pictures/ut/ExposureDog;

    move-result-object p2

    invoke-virtual {p2, v1}, Lcom/alibaba/pictures/ut/ExposureDog;->w(Ljava/lang/String;)Lcom/alibaba/pictures/ut/ExposureDog;

    move-result-object p2

    .line 5
    invoke-virtual {p2, v2, v4}, Lcom/alibaba/pictures/ut/ExposureDog;->G(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/pictures/ut/ExposureDog;

    move-result-object p2

    invoke-virtual {p2, p1}, Lcom/alibaba/pictures/ut/ExposureDog;->y(Ljava/util/Map;)Lcom/alibaba/pictures/ut/ExposureDog;

    move-result-object p1

    invoke-virtual {p1}, Lcom/alibaba/pictures/ut/ExposureDog;->k()V

    .line 6
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$j;->c:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;

    iget-object p2, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$j;->a:Ljava/lang/String;

    invoke-static {p1, p2}, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;->access$400(Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;Ljava/lang/String;)V

    return-void
.end method
