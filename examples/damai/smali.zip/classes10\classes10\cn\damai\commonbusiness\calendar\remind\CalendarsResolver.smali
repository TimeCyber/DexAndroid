.class public Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation build Landroid/annotation/SuppressLint;
    value = {
        "Range"
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver$RemindMeListener;
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon; = null

.field public static final NULL_FLAG:Ljava/lang/String; = "NULL_FLAG"

.field private static c:Ljava/lang/String; = "DamaiMemberCalendar"

.field private static d:Ljava/lang/String; = "\u9879\u76ee\u63d0\u9192"

.field private static e:Ljava/lang/String; = "LOCAL"

.field private static f:Ljava/lang/String; = "\u4f18\u5148\u9009\u5ea7\u63d0\u9192"

.field private static g:Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;


# instance fields
.field private a:I

.field private b:Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver$RemindMeListener;


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x5

    .line 2
    iput v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->a:I

    return-void
.end method

.method private a(Landroid/content/Context;)J
    .registers 10

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "23"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    .line 1
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    if-eqz v2, :cond_22

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    aput-object p1, v2, v4

    .line 2
    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Long;

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    return-wide v0

    .line 3
    :cond_22
    invoke-static {}, Ljava/util/TimeZone;->getDefault()Ljava/util/TimeZone;

    move-result-object v0

    .line 4
    new-instance v1, Landroid/content/ContentValues;

    invoke-direct {v1}, Landroid/content/ContentValues;-><init>()V

    .line 5
    sget-object v2, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->c:Ljava/lang/String;

    const-string v4, "name"

    invoke-virtual {v1, v4, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 6
    sget-object v2, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->d:Ljava/lang/String;

    const-string v4, "account_name"

    invoke-virtual {v1, v4, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 7
    sget-object v2, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->e:Ljava/lang/String;

    const-string v6, "account_type"

    invoke-virtual {v1, v6, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 8
    sget-object v2, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->f:Ljava/lang/String;

    const-string v7, "calendar_displayName"

    invoke-virtual {v1, v7, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "visible"

    .line 9
    invoke-virtual {v1, v2, v5}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const v2, -0xffff01

    .line 10
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const-string v7, "calendar_color"

    invoke-virtual {v1, v7, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const/16 v2, 0x2bc

    .line 11
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const-string v7, "calendar_access_level"

    invoke-virtual {v1, v7, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const-string v2, "sync_events"

    .line 12
    invoke-virtual {v1, v2, v5}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 13
    invoke-virtual {v0}, Ljava/util/TimeZone;->getID()Ljava/lang/String;

    move-result-object v0

    const-string v2, "calendar_timezone"

    invoke-virtual {v1, v2, v0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 14
    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->d:Ljava/lang/String;

    const-string v2, "ownerAccount"

    invoke-virtual {v1, v2, v0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 15
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const-string v2, "canOrganizerRespond"

    invoke-virtual {v1, v2, v0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const-string v0, "content://com.android.calendar/calendars"

    .line 16
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    .line 17
    invoke-virtual {v0}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    move-result-object v0

    const-string v2, "caller_is_syncadapter"

    const-string v3, "true"

    .line 18
    invoke-virtual {v0, v2, v3}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    sget-object v2, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->d:Ljava/lang/String;

    .line 19
    invoke-virtual {v0, v4, v2}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    sget-object v2, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->e:Ljava/lang/String;

    .line 20
    invoke-virtual {v0, v6, v2}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    .line 21
    invoke-virtual {v0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v0

    const-wide/16 v2, -0x1

    .line 22
    :try_start_a5
    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p1

    invoke-virtual {p1, v0, v1}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;

    move-result-object p1

    if-nez p1, :cond_b1

    move-wide v0, v2

    goto :goto_b5

    .line 23
    :cond_b1
    invoke-static {p1}, Landroid/content/ContentUris;->parseId(Landroid/net/Uri;)J

    move-result-wide v0

    .line 24
    :goto_b5
    sget-object p1, Lcn/damai/commonbusiness/calendar/remind/a;->Companion:Lcn/damai/commonbusiness/calendar/remind/a$a;

    invoke-virtual {p1, v0, v1}, Lcn/damai/commonbusiness/calendar/remind/a$a;->c(J)V

    .line 25
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "addCalendarAccount: accountId = "

    invoke-virtual {p1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->s(Ljava/lang/String;)V
    :try_end_ce
    .catch Ljava/lang/Exception; {:try_start_a5 .. :try_end_ce} :catch_cf

    return-wide v0

    :catch_cf
    move-exception p1

    .line 26
    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return-wide v2
.end method

.method private i(Lcn/damai/commonbusiness/calendar/remind/CalendarAction;J)Landroid/content/ContentValues;
    .registers 12

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "14"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_21

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/content/ContentValues;

    return-object p1

    .line 1
    :cond_21
    invoke-virtual {p1}, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->getBeginTime()J

    move-result-wide v0

    .line 2
    invoke-virtual {p1}, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->getEndTime()J

    move-result-wide v4

    .line 3
    new-instance v2, Landroid/content/ContentValues;

    invoke-direct {v2}, Landroid/content/ContentValues;-><init>()V

    .line 4
    invoke-virtual {p1}, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->getRemindTitle()Ljava/lang/String;

    move-result-object v6

    const-string v7, "title"

    invoke-virtual {v2, v7, v6}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 5
    invoke-virtual {p1}, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->getDescription()Ljava/lang/String;

    move-result-object v6

    const-string v7, "description"

    invoke-virtual {v2, v7, v6}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 6
    iget-object v6, p1, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->frequency:Ljava/lang/String;

    invoke-static {v6}, Ltb/ht;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 7
    iget v7, p1, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->recurrenceTimes:I

    if-lez v7, :cond_66

    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_66

    .line 8
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v6, p1, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->recurrenceTimes:I

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const-string v7, "rrule"

    invoke-virtual {v2, v7, v6}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 9
    :cond_66
    invoke-virtual {p1}, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->getLocation()Ljava/lang/String;

    move-result-object v6

    const-string v7, "NULL_FLAG"

    .line 10
    invoke-virtual {v7, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_77

    const-string v7, "eventLocation"

    .line 11
    invoke-virtual {v2, v7, v6}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 12
    :cond_77
    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const-string p3, "calendar_id"

    invoke-virtual {v2, p3, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const-wide/16 p2, 0x0

    cmp-long v6, v4, p2

    if-nez v6, :cond_87

    move-wide v4, v0

    .line 13
    :cond_87
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const-string p3, "dtstart"

    invoke-virtual {v2, p3, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    .line 14
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const-string p3, "dtend"

    invoke-virtual {v2, p3, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    .line 15
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const-string p3, "hasAlarm"

    invoke-virtual {v2, p3, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 16
    iget-object p1, p1, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->timeZone:Ljava/lang/String;

    .line 17
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const-string p3, "Asia/Shanghai"

    if-nez p2, :cond_bc

    const-string p2, "GMT"

    .line 18
    invoke-virtual {p1, p2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p2

    if-eqz p2, :cond_b5

    goto :goto_bd

    .line 19
    :cond_b5
    invoke-static {p1}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->r(Ljava/lang/String;)Z

    move-result p2

    if-eqz p2, :cond_bc

    goto :goto_bd

    :cond_bc
    move-object p1, p3

    :goto_bd
    const-string p2, "eventTimezone"

    .line 20
    invoke-virtual {v2, p2, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    return-object v2
.end method

.method private j(Landroid/content/Context;)J
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "20"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Long;

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    return-wide v0

    .line 1
    :cond_1e
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->k(Landroid/content/Context;)J

    move-result-wide v0

    const-wide/16 v2, 0x0

    cmp-long v4, v0, v2

    if-ltz v4, :cond_29

    return-wide v0

    .line 2
    :cond_29
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->a(Landroid/content/Context;)J

    move-result-wide v0

    cmp-long p1, v0, v2

    if-ltz p1, :cond_32

    return-wide v0

    :cond_32
    const-wide/16 v0, -0x1

    return-wide v0
.end method

.method private k(Landroid/content/Context;)J
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "21"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Long;

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    return-wide v0

    .line 1
    :cond_1e
    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/a;->Companion:Lcn/damai/commonbusiness/calendar/remind/a$a;

    invoke-virtual {v0}, Lcn/damai/commonbusiness/calendar/remind/a$a;->a()J

    move-result-wide v0

    .line 2
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-direct {p0, p1, v2}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->v(Landroid/content/Context;Ljava/lang/Long;)Z

    move-result p1

    if-eqz p1, :cond_2f

    return-wide v0

    :cond_2f
    const-wide/16 v0, -0x1

    return-wide v0
.end method

.method public static n()Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;
    .registers 3

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;

    return-object v0

    .line 1
    :cond_14
    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->g:Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;

    if-nez v0, :cond_1f

    .line 2
    new-instance v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;

    invoke-direct {v0}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;-><init>()V

    sput-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->g:Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;

    .line 3
    :cond_1f
    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->g:Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;

    return-object v0
.end method

.method public static r(Ljava/lang/String;)Z
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "26"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0

    :cond_1b
    if-eqz p0, :cond_31

    .line 1
    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_24

    goto :goto_31

    .line 2
    :cond_24
    invoke-static {}, Ljava/util/TimeZone;->getAvailableIDs()[Ljava/lang/String;

    move-result-object v0

    .line 3
    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0, p0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result p0

    return p0

    :cond_31
    :goto_31
    return v3
.end method

.method public static s(Ljava/lang/String;)V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "24"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_14
    const-string v0, "CalendarTag"

    .line 1
    invoke-static {v0, p0}, Ltb/av2;->c(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public static u(Landroid/content/Context;Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "25"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 p0, 0x1

    aput-object p1, v2, p0

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_17
    if-nez p0, :cond_1a

    return-void

    .line 1
    :cond_1a
    new-instance v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver$1;

    invoke-direct {v0, p0, p1}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver$1;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 2
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p0

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object p1

    if-ne p0, p1, :cond_31

    .line 3
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    goto :goto_3d

    .line 4
    :cond_31
    new-instance p0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p1

    invoke-direct {p0, p1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    invoke-virtual {p0, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :goto_3d
    return-void
.end method

.method private v(Landroid/content/Context;Ljava/lang/Long;)Z
    .registers 13

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "22"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    .line 1
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    if-eqz v2, :cond_25

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    aput-object p1, v2, v4

    const/4 p1, 0x2

    aput-object p2, v2, p1

    .line 2
    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    return p1

    .line 3
    :cond_25
    invoke-static {}, Ljava/util/TimeZone;->getDefault()Ljava/util/TimeZone;

    move-result-object v0

    .line 4
    new-instance v1, Landroid/content/ContentValues;

    invoke-direct {v1}, Landroid/content/ContentValues;-><init>()V

    .line 5
    sget-object v2, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->c:Ljava/lang/String;

    const-string v6, "name"

    invoke-virtual {v1, v6, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 6
    sget-object v2, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->d:Ljava/lang/String;

    const-string v6, "account_name"

    invoke-virtual {v1, v6, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 7
    sget-object v2, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->e:Ljava/lang/String;

    const-string v7, "account_type"

    invoke-virtual {v1, v7, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 8
    sget-object v2, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->f:Ljava/lang/String;

    const-string v8, "calendar_displayName"

    invoke-virtual {v1, v8, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "visible"

    .line 9
    invoke-virtual {v1, v2, v5}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const v2, -0xffff01

    .line 10
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const-string v8, "calendar_color"

    invoke-virtual {v1, v8, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const/16 v2, 0x2bc

    .line 11
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const-string v8, "calendar_access_level"

    invoke-virtual {v1, v8, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const-string v2, "sync_events"

    .line 12
    invoke-virtual {v1, v2, v5}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 13
    invoke-virtual {v0}, Ljava/util/TimeZone;->getID()Ljava/lang/String;

    move-result-object v0

    const-string v2, "calendar_timezone"

    invoke-virtual {v1, v2, v0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 14
    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->d:Ljava/lang/String;

    const-string v2, "ownerAccount"

    invoke-virtual {v1, v2, v0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 15
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const-string v2, "canOrganizerRespond"

    invoke-virtual {v1, v2, v0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const-string v0, "content://com.android.calendar/calendars"

    .line 16
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    .line 17
    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    move-result-wide v8

    invoke-static {v0, v8, v9}, Landroid/content/ContentUris;->withAppendedId(Landroid/net/Uri;J)Landroid/net/Uri;

    move-result-object v0

    .line 18
    invoke-virtual {v0}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    move-result-object v0

    const-string v2, "caller_is_syncadapter"

    const-string v5, "true"

    .line 19
    invoke-virtual {v0, v2, v5}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    sget-object v2, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->d:Ljava/lang/String;

    .line 20
    invoke-virtual {v0, v6, v2}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    sget-object v2, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->e:Ljava/lang/String;

    .line 21
    invoke-virtual {v0, v7, v2}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    .line 22
    invoke-virtual {v0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v0

    .line 23
    :try_start_ae
    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p1

    const/4 v2, 0x0

    invoke-virtual {p1, v0, v1, v2, v2}, Landroid/content/ContentResolver;->update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    move-result p1

    .line 24
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "updateCalendarAccount: target accountId = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p2, " update rowNum = "

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {p2}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->s(Ljava/lang/String;)V
    :try_end_d3
    .catch Ljava/lang/Exception; {:try_start_ae .. :try_end_d3} :catch_d7

    if-lez p1, :cond_d6

    const/4 v3, 0x1

    :cond_d6
    return v3

    :catch_d7
    move-exception p1

    .line 25
    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return v3
.end method


# virtual methods
.method public b(Landroid/content/Context;Lcn/damai/commonbusiness/calendar/remind/CalendarAction;)J
    .registers 21

    move-object/from16 v8, p0

    move-object/from16 v9, p1

    move-object/from16 v10, p2

    const-string v11, "\u8bbe\u7f6e\u63d0\u9192\u5931\u8d25"

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "12"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v12, 0x1

    if-eqz v2, :cond_29

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object v8, v2, v3

    aput-object v9, v2, v12

    const/4 v3, 0x2

    aput-object v10, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    return-wide v0

    :cond_29
    const-wide/16 v13, -0x1

    .line 1
    :try_start_2b
    invoke-virtual/range {p2 .. p2}, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->getBeginTime()J

    move-result-wide v0

    const-wide/16 v2, 0x0

    cmp-long v4, v0, v2

    if-gtz v4, :cond_3b

    const-string v0, "\u4eb2\uff0c\u6dfb\u52a0\u65e5\u5386\u6570\u636e\u9519\u8bef\uff5e"

    .line 2
    invoke-static {v9, v0}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->u(Landroid/content/Context;Ljava/lang/String;)V

    return-wide v13

    .line 3
    :cond_3b
    invoke-direct/range {p0 .. p1}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->j(Landroid/content/Context;)J

    move-result-wide v6
    :try_end_3f
    .catch Ljava/lang/Exception; {:try_start_2b .. :try_end_3f} :catch_105

    const-string v15, "\u4eb2\uff0c\u65e0\u6cd5\u83b7\u53d6\u5230\u60a8\u7684\u624b\u673a\u65e5\u5386\u8bf7\u624b\u52a8\u8bbe\u7f6e\u63d0\u9192\uff5e"

    cmp-long v0, v6, v2

    if-gez v0, :cond_49

    .line 4
    :try_start_45
    invoke-static {v9, v15}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->u(Landroid/content/Context;Ljava/lang/String;)V

    return-wide v13

    .line 5
    :cond_49
    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/a;->Companion:Lcn/damai/commonbusiness/calendar/remind/a$a;

    invoke-virtual {v0, v10}, Lcn/damai/commonbusiness/calendar/remind/a$a;->b(Lcn/damai/commonbusiness/calendar/remind/CalendarAction;)J

    move-result-wide v16

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-wide v4, v6

    move-wide v12, v6

    move-wide/from16 v6, v16

    .line 6
    invoke-virtual/range {v1 .. v7}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->w(Landroid/content/Context;Lcn/damai/commonbusiness/calendar/remind/CalendarAction;JJ)Z

    move-result v0

    if-eqz v0, :cond_67

    .line 7
    iget-object v0, v8, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->b:Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver$RemindMeListener;

    if-eqz v0, :cond_66

    .line 8
    invoke-interface {v0}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver$RemindMeListener;->addRemindmeSuccess()V

    :cond_66
    return-wide v16

    .line 9
    :cond_67
    invoke-direct {v8, v10, v12, v13}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->i(Lcn/damai/commonbusiness/calendar/remind/CalendarAction;J)Landroid/content/ContentValues;

    move-result-object v0
    :try_end_6b
    .catch Ljava/lang/Exception; {:try_start_45 .. :try_end_6b} :catch_105

    const/4 v1, 0x0

    .line 10
    :try_start_6c
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    const-string v3, "content://com.android.calendar/events"

    invoke-static {v3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v2, v3, v0}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;

    move-result-object v0
    :try_end_7a
    .catch Ljava/lang/Exception; {:try_start_6c .. :try_end_7a} :catch_7b

    goto :goto_80

    :catch_7b
    move-exception v0

    .line 11
    :try_start_7c
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    move-object v0, v1

    :goto_80
    if-nez v0, :cond_88

    .line 12
    invoke-static {v9, v15}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->u(Landroid/content/Context;Ljava/lang/String;)V

    const-wide/16 v1, -0x1

    return-wide v1

    .line 13
    :cond_88
    new-instance v2, Landroid/content/ContentValues;

    invoke-direct {v2}, Landroid/content/ContentValues;-><init>()V

    .line 14
    invoke-static {v0}, Landroid/content/ContentUris;->parseId(Landroid/net/Uri;)J

    move-result-wide v3

    const-string v0, "event_id"

    .line 15
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    invoke-virtual {v2, v0, v5}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    .line 16
    invoke-virtual/range {p2 .. p2}, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->getOffset()I

    move-result v0
    :try_end_9e
    .catch Ljava/lang/Exception; {:try_start_7c .. :try_end_9e} :catch_105

    const-string v5, "minutes"

    if-gtz v0, :cond_ac

    .line 17
    :try_start_a2
    iget v0, v8, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->a:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v2, v5, v0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    goto :goto_b7

    .line 18
    :cond_ac
    invoke-virtual/range {p2 .. p2}, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->getOffset()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v2, v5, v0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    :goto_b7
    const-string v0, "method"

    const/4 v5, 0x1

    .line 19
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v2, v0, v5}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V
    :try_end_c1
    .catch Ljava/lang/Exception; {:try_start_a2 .. :try_end_c1} :catch_105

    .line 20
    :try_start_c1
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const-string v5, "content://com.android.calendar/reminders"

    invoke-static {v5}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v5

    invoke-virtual {v0, v5, v2}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;

    move-result-object v1
    :try_end_cf
    .catch Ljava/lang/Exception; {:try_start_c1 .. :try_end_cf} :catch_d0

    goto :goto_d4

    :catch_d0
    move-exception v0

    .line 21
    :try_start_d1
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :goto_d4
    if-nez v1, :cond_dc

    .line 22
    invoke-static {v9, v11}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->u(Landroid/content/Context;Ljava/lang/String;)V

    const-wide/16 v1, -0x1

    return-wide v1

    .line 23
    :cond_dc
    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/a;->Companion:Lcn/damai/commonbusiness/calendar/remind/a$a;

    invoke-virtual {v0, v10, v3, v4}, Lcn/damai/commonbusiness/calendar/remind/a$a;->d(Lcn/damai/commonbusiness/calendar/remind/CalendarAction;J)V

    .line 24
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "addCalendarEvent : accountId = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v12, v13}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, "; success new eventId ="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->s(Ljava/lang/String;)V

    .line 25
    iget-object v0, v8, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->b:Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver$RemindMeListener;

    if-eqz v0, :cond_104

    .line 26
    invoke-interface {v0}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver$RemindMeListener;->addRemindmeSuccess()V
    :try_end_104
    .catch Ljava/lang/Exception; {:try_start_d1 .. :try_end_104} :catch_105

    :cond_104
    return-wide v3

    :catch_105
    move-exception v0

    .line 27
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 28
    invoke-static {v9, v11}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->u(Landroid/content/Context;Ljava/lang/String;)V

    const-wide/16 v1, -0x1

    return-wide v1
.end method

.method public c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)J
    .registers 22

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_2e

    const/4 v2, 0x6

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 v3, 0x2

    aput-object p2, v2, v3

    const/4 v3, 0x3

    aput-object p3, v2, v3

    const/4 v3, 0x4

    invoke-static/range {p4 .. p5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    aput-object v4, v2, v3

    const/4 v3, 0x5

    aput-object p6, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    return-wide v0

    :cond_2e
    const-wide/16 v11, 0x0

    const/4 v13, 0x0

    const-string v7, "NULL_FLAG"

    move-object v4, p0

    move-object/from16 v5, p1

    move-object/from16 v6, p2

    move-object/from16 v8, p3

    move-wide/from16 v9, p4

    move-object/from16 v14, p6

    .line 1
    invoke-virtual/range {v4 .. v14}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->d(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJILjava/lang/String;)J

    move-result-wide v0

    return-wide v0
.end method

.method public d(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJILjava/lang/String;)J
    .registers 26

    move-object v0, p0

    move-object/from16 v1, p1

    sget-object v2, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v3, "11"

    invoke-static {v2, v3}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_44

    const/16 v4, 0x9

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v5, 0x0

    aput-object v0, v4, v5

    const/4 v5, 0x1

    aput-object v1, v4, v5

    const/4 v1, 0x2

    aput-object p2, v4, v1

    const/4 v1, 0x3

    aput-object p3, v4, v1

    const/4 v1, 0x4

    aput-object p4, v4, v1

    const/4 v1, 0x5

    invoke-static/range {p5 .. p6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    aput-object v5, v4, v1

    const/4 v1, 0x6

    invoke-static/range {p7 .. p8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    aput-object v5, v4, v1

    const/4 v1, 0x7

    invoke-static/range {p9 .. p9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v1

    const/16 v1, 0x8

    aput-object p10, v4, v1

    invoke-interface {v2, v3, v4}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    return-wide v1

    .line 1
    :cond_44
    new-instance v2, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;

    move-object v5, v2

    move-object/from16 v6, p2

    move-wide/from16 v7, p5

    move-object/from16 v9, p4

    move-object/from16 v10, p3

    move-wide/from16 v11, p7

    move/from16 v13, p9

    move-object/from16 v14, p10

    invoke-direct/range {v5 .. v14}, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;-><init>(Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;JILjava/lang/String;)V

    .line 2
    invoke-virtual {p0, v1, v2}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->b(Landroid/content/Context;Lcn/damai/commonbusiness/calendar/remind/CalendarAction;)J

    move-result-wide v1

    return-wide v1
.end method

.method public e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;J)V
    .registers 20

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_24

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 v3, 0x2

    aput-object p2, v2, v3

    const/4 v3, 0x3

    aput-object p3, v2, v3

    const/4 v3, 0x4

    invoke-static/range {p4 .. p5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_24
    const-wide/16 v11, 0x0

    const/4 v13, 0x0

    const-string v7, "NULL_FLAG"

    move-object v4, p0

    move-object v5, p1

    move-object/from16 v6, p2

    move-object/from16 v8, p3

    move-wide/from16 v9, p4

    .line 1
    invoke-virtual/range {v4 .. v13}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->g(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJI)V

    return-void
.end method

.method public f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;JJI)V
    .registers 23

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_32

    const/4 v2, 0x7

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 v3, 0x2

    aput-object p2, v2, v3

    const/4 v3, 0x3

    aput-object p3, v2, v3

    const/4 v3, 0x4

    invoke-static/range {p4 .. p5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    aput-object v4, v2, v3

    const/4 v3, 0x5

    invoke-static/range {p6 .. p7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    aput-object v4, v2, v3

    const/4 v3, 0x6

    invoke-static/range {p8 .. p8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_32
    const-string v7, "NULL_FLAG"

    move-object v4, p0

    move-object v5, p1

    move-object/from16 v6, p2

    move-object/from16 v8, p3

    move-wide/from16 v9, p4

    move-wide/from16 v11, p6

    move/from16 v13, p8

    .line 1
    invoke-virtual/range {v4 .. v13}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->g(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJI)V

    return-void
.end method

.method public g(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJI)V
    .registers 24

    move-object v0, p0

    move-object v1, p1

    sget-object v2, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v3, "10"

    invoke-static {v2, v3}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_38

    const/16 v4, 0x8

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v5, 0x0

    aput-object v0, v4, v5

    const/4 v5, 0x1

    aput-object v1, v4, v5

    const/4 v1, 0x2

    aput-object p2, v4, v1

    const/4 v1, 0x3

    aput-object p3, v4, v1

    const/4 v1, 0x4

    aput-object p4, v4, v1

    const/4 v1, 0x5

    invoke-static/range {p5 .. p6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    aput-object v5, v4, v1

    const/4 v1, 0x6

    invoke-static/range {p7 .. p8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    aput-object v5, v4, v1

    const/4 v1, 0x7

    invoke-static/range {p9 .. p9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v1

    invoke-interface {v2, v3, v4}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_38
    new-instance v2, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;

    move-object v5, v2

    move-object/from16 v6, p2

    move-wide/from16 v7, p5

    move-object/from16 v9, p4

    move-object/from16 v10, p3

    move-wide/from16 v11, p7

    move/from16 v13, p9

    invoke-direct/range {v5 .. v13}, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;-><init>(Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;JI)V

    .line 2
    invoke-virtual {p0, p1, v2}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->b(Landroid/content/Context;Lcn/damai/commonbusiness/calendar/remind/CalendarAction;)J

    return-void
.end method

.method public h(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)V
    .registers 23

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "9"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_2a

    const/4 v2, 0x7

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 v3, 0x2

    aput-object p2, v2, v3

    const/4 v3, 0x3

    aput-object p3, v2, v3

    const/4 v3, 0x4

    aput-object p4, v2, v3

    const/4 v3, 0x5

    invoke-static/range {p5 .. p6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    aput-object v4, v2, v3

    const/4 v3, 0x6

    aput-object p7, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_2a
    const-wide/16 v11, 0x0

    const/4 v13, 0x0

    move-object v4, p0

    move-object/from16 v5, p1

    move-object/from16 v6, p2

    move-object/from16 v7, p3

    move-object/from16 v8, p4

    move-wide/from16 v9, p5

    move-object/from16 v14, p7

    .line 1
    invoke-virtual/range {v4 .. v14}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->d(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJILjava/lang/String;)J

    return-void
.end method

.method public l(Landroid/content/Context;Lcn/damai/commonbusiness/calendar/remind/CalendarAction;)J
    .registers 11

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "16"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_21

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Long;

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide p1

    return-wide p1

    :cond_21
    const-wide/16 v0, -0x1

    .line 1
    :try_start_23
    sget-object v2, Lcn/damai/commonbusiness/calendar/remind/a;->Companion:Lcn/damai/commonbusiness/calendar/remind/a$a;

    invoke-virtual {v2, p2}, Lcn/damai/commonbusiness/calendar/remind/a$a;->b(Lcn/damai/commonbusiness/calendar/remind/CalendarAction;)J

    move-result-wide v3

    const-string v5, "content://com.android.calendar/events"

    .line 2
    invoke-static {v5}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v5

    invoke-static {v5, v3, v4}, Landroid/content/ContentUris;->withAppendedId(Landroid/net/Uri;J)Landroid/net/Uri;

    move-result-object v5

    .line 3
    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v6

    const/4 v7, 0x0

    invoke-virtual {v6, v5, v7, v7}, Landroid/content/ContentResolver;->delete(Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v5

    .line 4
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "deleteCalendarEvent : eventId = "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v3, " delete res = "

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->s(Ljava/lang/String;)V

    const/4 v3, -0x1

    if-ne v5, v3, :cond_61

    const-string p2, "\u53d6\u6d88\u5931\u8d25"

    .line 5
    invoke-static {p1, p2}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->u(Landroid/content/Context;Ljava/lang/String;)V

    return-wide v0

    .line 6
    :cond_61
    invoke-virtual {v2, p2}, Lcn/damai/commonbusiness/calendar/remind/a$a;->e(Lcn/damai/commonbusiness/calendar/remind/CalendarAction;)V

    .line 7
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->b:Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver$RemindMeListener;

    if-eqz p1, :cond_6b

    .line 8
    invoke-interface {p1}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver$RemindMeListener;->candelRemindmeSuccess()V
    :try_end_6b
    .catch Ljava/lang/Exception; {:try_start_23 .. :try_end_6b} :catch_6d

    :cond_6b
    int-to-long p1, v5

    return-wide p1

    :catch_6d
    move-exception p1

    .line 9
    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return-wide v0
.end method

.method public m(Landroid/content/Context;Ljava/lang/String;J)J
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "15"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_28

    const/4 v2, 0x4

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3, p4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Long;

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide p1

    return-wide p1

    .line 1
    :cond_28
    :try_start_28
    new-instance v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;

    invoke-direct {v0, p2, p3, p4}, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;-><init>(Ljava/lang/String;J)V

    .line 2
    invoke-virtual {p0, p1, v0}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->l(Landroid/content/Context;Lcn/damai/commonbusiness/calendar/remind/CalendarAction;)J

    move-result-wide p1
    :try_end_31
    .catch Ljava/lang/Exception; {:try_start_28 .. :try_end_31} :catch_32

    return-wide p1

    :catch_32
    move-exception p1

    .line 3
    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    const-wide/16 p1, -0x1

    return-wide p1
.end method

.method public o(Landroid/content/Context;Lcn/damai/commonbusiness/calendar/remind/CalendarAction;)Z
    .registers 16

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "19"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_21

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    return p1

    .line 1
    :cond_21
    :try_start_21
    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/a;->Companion:Lcn/damai/commonbusiness/calendar/remind/a$a;

    invoke-virtual {v0, p2}, Lcn/damai/commonbusiness/calendar/remind/a$a;->b(Lcn/damai/commonbusiness/calendar/remind/CalendarAction;)J

    move-result-wide v0

    .line 2
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->j(Landroid/content/Context;)J

    move-result-wide v11

    move-object v4, p0

    move-object v5, p1

    move-object v6, p2

    move-wide v7, v11

    move-wide v9, v0

    .line 3
    invoke-virtual/range {v4 .. v10}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->w(Landroid/content/Context;Lcn/damai/commonbusiness/calendar/remind/CalendarAction;JJ)Z

    move-result p1

    .line 4
    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "isRemindmeEventExist :accId ="

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v11, v12}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v2, " eventId = "

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v0, " exist = "

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {p2}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->s(Ljava/lang/String;)V
    :try_end_58
    .catch Ljava/lang/Exception; {:try_start_21 .. :try_end_58} :catch_59

    return p1

    :catch_59
    move-exception p1

    .line 5
    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return v3
.end method

.method public p(Landroid/content/Context;Ljava/lang/String;J)Z
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "17"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_28

    const/4 v2, 0x4

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3, p4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    return p1

    .line 1
    :cond_28
    new-instance v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;

    const-string v1, "Asia/Shanghai"

    invoke-direct {v0, p2, p3, p4, v1}, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;-><init>(Ljava/lang/String;JLjava/lang/String;)V

    .line 2
    invoke-virtual {p0, p1, v0}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->o(Landroid/content/Context;Lcn/damai/commonbusiness/calendar/remind/CalendarAction;)Z

    move-result p1

    return p1
.end method

.method public q(Landroid/content/Context;Ljava/lang/String;JLjava/lang/String;)Z
    .registers 10

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "18"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_2b

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3, p4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    aput-object p5, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    return p1

    .line 1
    :cond_2b
    new-instance v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;

    invoke-direct {v0, p2, p3, p4, p5}, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;-><init>(Ljava/lang/String;JLjava/lang/String;)V

    .line 2
    invoke-virtual {p0, p1, v0}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->o(Landroid/content/Context;Lcn/damai/commonbusiness/calendar/remind/CalendarAction;)Z

    move-result p1

    return p1
.end method

.method public t(Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver$RemindMeListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->b:Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver$RemindMeListener;

    return-void
.end method

.method public w(Landroid/content/Context;Lcn/damai/commonbusiness/calendar/remind/CalendarAction;JJ)Z
    .registers 12

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "13"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_2f

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3, p4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    invoke-static {p5, p6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    return p1

    :cond_2f
    if-eqz p1, :cond_6a

    const-wide/16 v0, 0x0

    cmp-long v2, p5, v0

    if-ltz v2, :cond_6a

    if-nez p2, :cond_3a

    goto :goto_6a

    .line 1
    :cond_3a
    :try_start_3a
    invoke-direct {p0, p2, p3, p4}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->i(Lcn/damai/commonbusiness/calendar/remind/CalendarAction;J)Landroid/content/ContentValues;

    move-result-object p2

    .line 2
    sget-object p3, Landroid/provider/CalendarContract$Events;->CONTENT_URI:Landroid/net/Uri;

    invoke-static {p3, p5, p6}, Landroid/content/ContentUris;->withAppendedId(Landroid/net/Uri;J)Landroid/net/Uri;

    move-result-object p3

    .line 3
    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p1

    const/4 p4, 0x0

    invoke-virtual {p1, p3, p2, p4, p4}, Landroid/content/ContentResolver;->update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    move-result p1

    .line 4
    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string p3, "updateCalendarEvent: "

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {p2}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->s(Ljava/lang/String;)V
    :try_end_61
    .catch Ljava/lang/Exception; {:try_start_3a .. :try_end_61} :catch_66

    if-lez p1, :cond_64

    goto :goto_65

    :cond_64
    const/4 v3, 0x0

    :goto_65
    return v3

    :catch_66
    move-exception p1

    .line 5
    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    :cond_6a
    :goto_6a
    return v4
.end method

.method public x(I)Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;

    return-object p1

    .line 1
    :cond_1e
    iput p1, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->a:I

    .line 2
    invoke-static {}, Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;->n()Lcn/damai/commonbusiness/calendar/remind/CalendarsResolver;

    move-result-object p1

    return-object p1
.end method
