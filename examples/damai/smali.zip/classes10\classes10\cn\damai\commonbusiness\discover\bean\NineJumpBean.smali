.class public Lcn/damai/commonbusiness/discover/bean/NineJumpBean;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon; = null

.field public static final STATUS_HAS_VIDEO:I = 0x14

.field public static final STATUS_NONE_VIDEO:I = 0x12

.field public static final STATUS_VIDEO_UNDER_REVIEW:I = 0x13


# instance fields
.field private final gridList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/discover/bean/GridBean;",
            ">;"
        }
    .end annotation
.end field

.field public final picInfoList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcn/damai/commonbusiness/imagebrowse/bean/PicInfo;",
            ">;"
        }
    .end annotation
.end field

.field public final videoInfoList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcn/damai/comment/bean/CommentVideoBean;",
            ">;"
        }
    .end annotation
.end field

.field public final videoStatus:I


# direct methods
.method public constructor <init>(Ljava/util/List;Lcn/damai/tetris/component/discover/bean/VideoInfo;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Lcn/damai/tetris/component/discover/bean/VideoInfo;",
            ")V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Ljava/util/ArrayList;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    iput-object v0, p0, Lcn/damai/commonbusiness/discover/bean/NineJumpBean;->videoInfoList:Ljava/util/ArrayList;

    .line 3
    new-instance v1, Ljava/util/ArrayList;

    const/16 v2, 0x9

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    iput-object v1, p0, Lcn/damai/commonbusiness/discover/bean/NineJumpBean;->picInfoList:Ljava/util/ArrayList;

    .line 4
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lcn/damai/commonbusiness/discover/bean/NineJumpBean;->gridList:Ljava/util/List;

    if-eqz p2, :cond_60

    .line 5
    invoke-virtual {p2}, Lcn/damai/tetris/component/discover/bean/VideoInfo;->isVideoUnderReviewStatus()Z

    move-result v1

    if-eqz v1, :cond_2a

    const/16 v0, 0x13

    .line 6
    invoke-static {p2}, Lcn/damai/commonbusiness/discover/bean/GridBean;->fromVideo2(Lcn/damai/tetris/component/discover/bean/VideoInfo;)Lcn/damai/commonbusiness/discover/bean/GridBean;

    move-result-object p2

    goto :goto_63

    .line 7
    :cond_2a
    iget-object v1, p2, Lcn/damai/tetris/component/discover/bean/VideoInfo;->coverUrl:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_60

    iget-object v1, p2, Lcn/damai/tetris/component/discover/bean/VideoInfo;->url:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_60

    const/16 v1, 0x14

    .line 8
    invoke-static {p2}, Lcn/damai/commonbusiness/discover/bean/GridBean;->fromVideo2(Lcn/damai/tetris/component/discover/bean/VideoInfo;)Lcn/damai/commonbusiness/discover/bean/GridBean;

    move-result-object v2

    .line 9
    new-instance v3, Lcn/damai/comment/bean/CommentVideoBean;

    invoke-direct {v3}, Lcn/damai/comment/bean/CommentVideoBean;-><init>()V

    .line 10
    iget-object v4, p2, Lcn/damai/tetris/component/discover/bean/VideoInfo;->coverUrl:Ljava/lang/String;

    invoke-virtual {v3, v4}, Lcn/damai/comment/bean/CommentVideoBean;->setPicUrl(Ljava/lang/String;)V

    .line 11
    iget-object v4, p2, Lcn/damai/tetris/component/discover/bean/VideoInfo;->url:Ljava/lang/String;

    invoke-virtual {v3, v4}, Lcn/damai/comment/bean/CommentVideoBean;->setVideoUrl(Ljava/lang/String;)V

    .line 12
    sget-object v4, Lcn/damai/comment/bean/CommentVideoBean$VideoType;->VIDEO_URL:Lcn/damai/comment/bean/CommentVideoBean$VideoType;

    invoke-virtual {v3, v4}, Lcn/damai/comment/bean/CommentVideoBean;->setType(Lcn/damai/comment/bean/CommentVideoBean$VideoType;)V

    .line 13
    iget-object p2, p2, Lcn/damai/tetris/component/discover/bean/VideoInfo;->sourceLabel:Ljava/lang/String;

    invoke-virtual {v3, p2}, Lcn/damai/comment/bean/CommentVideoBean;->setSourceLabel(Ljava/lang/String;)V

    .line 14
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-object p2, v2

    const/16 v0, 0x14

    goto :goto_63

    :cond_60
    const/16 v0, 0x12

    const/4 p2, 0x0

    .line 15
    :goto_63
    iput v0, p0, Lcn/damai/commonbusiness/discover/bean/NineJumpBean;->videoStatus:I

    .line 16
    invoke-static {p1}, Ltb/ck5;->d(Ljava/util/Collection;)Z

    move-result v0

    if-nez v0, :cond_89

    .line 17
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_6f
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_89

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 18
    new-instance v2, Lcn/damai/commonbusiness/imagebrowse/bean/PicInfo;

    invoke-direct {v2}, Lcn/damai/commonbusiness/imagebrowse/bean/PicInfo;-><init>()V

    .line 19
    invoke-virtual {v2, v1}, Lcn/damai/commonbusiness/imagebrowse/bean/PicInfo;->setPicUrl(Ljava/lang/String;)V

    .line 20
    iget-object v1, p0, Lcn/damai/commonbusiness/discover/bean/NineJumpBean;->picInfoList:Ljava/util/ArrayList;

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_6f

    .line 21
    :cond_89
    invoke-static {p1}, Lcn/damai/commonbusiness/discover/bean/GridBean;->formImgList(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    if-eqz p2, :cond_94

    .line 22
    iget-object v0, p0, Lcn/damai/commonbusiness/discover/bean/NineJumpBean;->gridList:Ljava/util/List;

    invoke-interface {v0, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 23
    :cond_94
    invoke-static {p1}, Ltb/ck5;->d(Ljava/util/Collection;)Z

    move-result p2

    if-nez p2, :cond_9f

    .line 24
    iget-object p2, p0, Lcn/damai/commonbusiness/discover/bean/NineJumpBean;->gridList:Ljava/util/List;

    invoke-interface {p2, p1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    :cond_9f
    return-void
.end method


# virtual methods
.method public computePosition2NextPage(I)I
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/discover/bean/NineJumpBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_22

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    return p1

    .line 1
    :cond_22
    iget v0, p0, Lcn/damai/commonbusiness/discover/bean/NineJumpBean;->videoStatus:I

    const/16 v1, 0x13

    if-eq v0, v1, :cond_29

    goto :goto_2b

    :cond_29
    add-int/lit8 p1, p1, -0x1

    :goto_2b
    return p1
.end method

.method public getGridList(Z)Ljava/util/List;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z)",
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/discover/bean/GridBean;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/discover/bean/NineJumpBean;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v4

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/List;

    return-object p1

    .line 1
    :cond_1e
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 2
    iget-object v1, p0, Lcn/damai/commonbusiness/discover/bean/NineJumpBean;->gridList:Ljava/util/List;

    invoke-static {v1}, Ltb/ck5;->d(Ljava/util/Collection;)Z

    move-result v1

    if-nez v1, :cond_53

    .line 3
    iget-object v1, p0, Lcn/damai/commonbusiness/discover/bean/NineJumpBean;->gridList:Ljava/util/List;

    invoke-interface {v0, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 4
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    if-eqz p1, :cond_50

    .line 5
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result p1

    const/4 v2, 0x3

    if-le p1, v2, :cond_50

    .line 6
    invoke-interface {v0, v4, v2}, Ljava/util/List;->subList(II)Ljava/util/List;

    move-result-object p1

    .line 7
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    sub-int/2addr v0, v3

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/discover/bean/GridBean;

    sub-int/2addr v1, v2

    iput v1, v0, Lcn/damai/commonbusiness/discover/bean/GridBean;->countRightBottomTag:I

    move-object v0, p1

    .line 8
    :cond_50
    invoke-static {v0}, Lcn/damai/commonbusiness/discover/bean/GridBean;->ensureItemCountMemberVar(Ljava/util/List;)V

    :cond_53
    return-object v0
.end method
