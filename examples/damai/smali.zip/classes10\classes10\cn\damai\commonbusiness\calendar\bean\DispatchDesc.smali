.class public Lcn/damai/commonbusiness/calendar/bean/DispatchDesc;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/calendar/bean/DispatchDesc$TYPE;
    }
.end annotation


# instance fields
.field public color:Ljava/lang/String;

.field public desc:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
