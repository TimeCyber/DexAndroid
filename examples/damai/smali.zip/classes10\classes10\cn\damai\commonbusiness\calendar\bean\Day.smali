.class public Lcn/damai/commonbusiness/calendar/bean/Day;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon; = null

.field public static final DAYTYPE_DEFAULT:I = 0x0

.field public static final DAYTYPE_HOLIDAY:I = 0x2

.field public static final DAYTYPE_WORKDAY:I = 0x1

.field public static final SELECTTYPE_DEFAULT:I = 0x0

.field public static final SELECTTYPE_END:I = 0x3

.field public static final SELECTTYPE_MIDDLE:I = 0x4

.field public static final SELECTTYPE_SINGLE:I = 0x1

.field public static final SELECTTYPE_START:I = 0x2

.field private static final serialVersionUID:J = -0x524174f600cdb88aL


# instance fields
.field public day:I

.field public dayType:I

.field public month:I

.field public project:Ljava/lang/String;

.field public projectId:Ljava/lang/String;

.field public projectName:Ljava/lang/String;

.field public selectType:I

.field public showType:I

.field public tag:Ljava/lang/String;

.field public tip:Ljava/lang/String;

.field public tipBg:Lcn/damai/commonbusiness/calendar/bean/DispatchDesc$TYPE;

.field public year:I


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lcn/damai/commonbusiness/calendar/bean/Day;->selectType:I

    .line 3
    iput v0, p0, Lcn/damai/commonbusiness/calendar/bean/Day;->showType:I

    return-void
.end method

.method public constructor <init>(III)V
    .registers 5

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 5
    iput v0, p0, Lcn/damai/commonbusiness/calendar/bean/Day;->selectType:I

    .line 6
    iput v0, p0, Lcn/damai/commonbusiness/calendar/bean/Day;->showType:I

    .line 7
    iput p1, p0, Lcn/damai/commonbusiness/calendar/bean/Day;->year:I

    .line 8
    iput p2, p0, Lcn/damai/commonbusiness/calendar/bean/Day;->month:I

    .line 9
    iput p3, p0, Lcn/damai/commonbusiness/calendar/bean/Day;->day:I

    return-void
.end method

.method private for2L(I)Ljava/lang/String;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/calendar/bean/Day;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "7"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    return-object p1

    .line 1
    :cond_1e
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ""

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-ne v0, v3, :cond_43

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "0"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    goto :goto_4e

    :cond_43
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_4e
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .registers 7
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    sget-object v0, Lcn/damai/commonbusiness/calendar/bean/Day;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    return p1

    .line 1
    :cond_1e
    instance-of v0, p1, Lcn/damai/commonbusiness/calendar/bean/Day;

    if-eqz v0, :cond_39

    .line 2
    check-cast p1, Lcn/damai/commonbusiness/calendar/bean/Day;

    .line 3
    iget v0, p0, Lcn/damai/commonbusiness/calendar/bean/Day;->year:I

    iget v1, p1, Lcn/damai/commonbusiness/calendar/bean/Day;->year:I

    if-ne v0, v1, :cond_37

    iget v0, p0, Lcn/damai/commonbusiness/calendar/bean/Day;->month:I

    iget v1, p1, Lcn/damai/commonbusiness/calendar/bean/Day;->month:I

    if-ne v0, v1, :cond_37

    iget v0, p0, Lcn/damai/commonbusiness/calendar/bean/Day;->day:I

    iget p1, p1, Lcn/damai/commonbusiness/calendar/bean/Day;->day:I

    if-ne v0, p1, :cond_37

    goto :goto_38

    :cond_37
    const/4 v3, 0x0

    :goto_38
    return v3

    .line 4
    :cond_39
    invoke-super {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public hashCode()I
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/bean/Day;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0

    .line 1
    :cond_1b
    invoke-super {p0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    return v0
.end method

.method public isAfterDay(Lcn/damai/commonbusiness/calendar/bean/Day;)Z
    .registers 8

    sget-object v0, Lcn/damai/commonbusiness/calendar/bean/Day;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    aput-object p1, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    return p1

    :cond_1e
    if-nez p1, :cond_21

    return v3

    .line 1
    :cond_21
    iget v0, p0, Lcn/damai/commonbusiness/calendar/bean/Day;->year:I

    iget v1, p1, Lcn/damai/commonbusiness/calendar/bean/Day;->year:I

    if-le v0, v1, :cond_28

    return v4

    :cond_28
    if-ne v0, v1, :cond_31

    .line 2
    iget v2, p0, Lcn/damai/commonbusiness/calendar/bean/Day;->month:I

    iget v5, p1, Lcn/damai/commonbusiness/calendar/bean/Day;->month:I

    if-le v2, v5, :cond_31

    return v4

    :cond_31
    if-ne v0, v1, :cond_40

    .line 3
    iget v0, p0, Lcn/damai/commonbusiness/calendar/bean/Day;->month:I

    iget v1, p1, Lcn/damai/commonbusiness/calendar/bean/Day;->month:I

    if-ne v0, v1, :cond_40

    iget v0, p0, Lcn/damai/commonbusiness/calendar/bean/Day;->day:I

    iget p1, p1, Lcn/damai/commonbusiness/calendar/bean/Day;->day:I

    if-le v0, p1, :cond_40

    return v4

    :cond_40
    return v3
.end method

.method public toShortDateString()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/bean/Day;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget v1, p0, Lcn/damai/commonbusiness/calendar/bean/Day;->month:I

    invoke-direct {p0, v1}, Lcn/damai/commonbusiness/calendar/bean/Day;->for2L(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lcn/damai/commonbusiness/calendar/bean/Day;->day:I

    invoke-direct {p0, v1}, Lcn/damai/commonbusiness/calendar/bean/Day;->for2L(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public toSimpleDate()Ljava/util/Date;
    .registers 5

    const-string v0, "-"

    sget-object v1, Lcn/damai/commonbusiness/calendar/bean/Day;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v2, "4"

    invoke-static {v1, v2}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_19

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v0, v3

    invoke-interface {v1, v2, v0}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Date;

    return-object v0

    .line 1
    :cond_19
    new-instance v1, Ljava/text/SimpleDateFormat;

    const-string v2, "yyyy-MM-dd"

    invoke-direct {v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    .line 2
    :try_start_20
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget v3, p0, Lcn/damai/commonbusiness/calendar/bean/Day;->year:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v3, p0, Lcn/damai/commonbusiness/calendar/bean/Day;->month:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v0, p0, Lcn/damai/commonbusiness/calendar/bean/Day;->day:I

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/text/SimpleDateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v0
    :try_end_42
    .catch Ljava/text/ParseException; {:try_start_20 .. :try_end_42} :catch_43

    return-object v0

    :catch_43
    move-exception v0

    .line 3
    invoke-virtual {v0}, Ljava/text/ParseException;->printStackTrace()V

    const/4 v0, 0x0

    return-object v0
.end method

.method public toSimpleDateString()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/bean/Day;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget v1, p0, Lcn/damai/commonbusiness/calendar/bean/Day;->year:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "-"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lcn/damai/commonbusiness/calendar/bean/Day;->month:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lcn/damai/commonbusiness/calendar/bean/Day;->day:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
