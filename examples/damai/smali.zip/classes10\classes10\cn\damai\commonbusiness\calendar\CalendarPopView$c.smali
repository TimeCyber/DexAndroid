.class public Lcn/damai/commonbusiness/calendar/CalendarPopView$c;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/calendar/CalendarPopView;->u()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/calendar/CalendarPopView;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/calendar/CalendarPopView;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$c;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/calendar/CalendarPopView$c;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$c;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    iput v3, p1, Lcn/damai/commonbusiness/calendar/CalendarPopView;->r:I

    .line 2
    invoke-static {p1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->d(Lcn/damai/commonbusiness/calendar/CalendarPopView;)V

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$c;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->k(Lcn/damai/commonbusiness/calendar/CalendarPopView;Lcn/damai/commonbusiness/calendar/bean/Day;)Lcn/damai/commonbusiness/calendar/bean/Day;

    move-result-object v0

    invoke-static {p1, v0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->h(Lcn/damai/commonbusiness/calendar/CalendarPopView;Lcn/damai/commonbusiness/calendar/bean/Day;)Lcn/damai/commonbusiness/calendar/bean/Day;

    .line 4
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$c;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-static {p1, v0}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->i(Lcn/damai/commonbusiness/calendar/CalendarPopView;Ljava/util/List;)V

    .line 5
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$c;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {p1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->c(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Ltb/sr1;

    move-result-object p1

    if-eqz p1, :cond_43

    .line 6
    iget-object p1, p0, Lcn/damai/commonbusiness/calendar/CalendarPopView$c;->a:Lcn/damai/commonbusiness/calendar/CalendarPopView;

    invoke-static {p1}, Lcn/damai/commonbusiness/calendar/CalendarPopView;->c(Lcn/damai/commonbusiness/calendar/CalendarPopView;)Ltb/sr1;

    move-result-object p1

    invoke-virtual {p1}, Ltb/sr1;->g()V

    :cond_43
    return-void
.end method
