.class public Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;
.super Landroid/view/View;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView$OnZoomOperatedListener;,
        Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView$OnFinderMoveListener;,
        Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView$OnFinderClickListener;
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon; = null

.field public static final KEY_SUPPORT_MANUAL:Ljava/lang/String; = "key_support_manual"

.field private static MSG_CLICK:I = 0x1

.field public static final TAG:Ljava/lang/String; = "ScaleFinderView"


# instance fields
.field private LINE_COLOR:I

.field private MOVE_PACE:I

.field private ZOOM_PACE:I

.field private angle_leftTop:Landroid/graphics/Bitmap;

.field private dLineWidth:I

.field private handler:Landroid/os/Handler;

.field private lastActionUp:J

.field private lastSingleFingerPositionY:F

.field private lastTwoFingerDistance:F

.field private mSupportManual:Z

.field private matrix:Landroid/graphics/Matrix;

.field private onFinderClickListener:Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView$OnFinderClickListener;

.field private onFinderMoveListener:Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView$OnFinderMoveListener;

.field private onZoomOperatedListener:Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView$OnZoomOperatedListener;

.field private paint:Landroid/graphics/Paint;

.field private shadowColor:I

.field private showScanRect:Z

.field private targetBottom:I

.field private targetLeft:I

.field private targetRight:I

.field private targetTop:I

.field private xFerPaint:Landroid/graphics/Paint;


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, p1, v0}, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 4

    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, p1, p2, v0}, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4

    .line 3
    invoke-direct {p0, p1, p2, p3}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 p2, 0x2

    .line 4
    iput p2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->dLineWidth:I

    const-string p2, "#5b03112b"

    .line 5
    invoke-static {p2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p2

    iput p2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->shadowColor:I

    const-string p2, "#108EE9"

    .line 6
    invoke-static {p2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p2

    iput p2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->LINE_COLOR:I

    const/16 p2, 0x1e

    .line 7
    iput p2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->ZOOM_PACE:I

    .line 8
    iput p2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->MOVE_PACE:I

    .line 9
    new-instance p2, Landroid/graphics/Matrix;

    invoke-direct {p2}, Landroid/graphics/Matrix;-><init>()V

    iput-object p2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->matrix:Landroid/graphics/Matrix;

    .line 10
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->initAngleBitmap(Landroid/content/Context;)V

    .line 11
    invoke-direct {p0}, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->initPaint()V

    .line 12
    invoke-direct {p0}, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->init()V

    const/4 p1, 0x1

    .line 13
    iput-boolean p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->showScanRect:Z

    return-void
.end method

.method static synthetic access$000()I
    .registers 1

    .line 1
    sget v0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->MSG_CLICK:I

    return v0
.end method

.method static synthetic access$100(Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;)J
    .registers 3

    .line 1
    iget-wide v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->lastActionUp:J

    return-wide v0
.end method

.method static synthetic access$200(Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;Landroid/os/Message;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->onFinderClickHappen(Landroid/os/Message;)V

    return-void
.end method

.method private drawAngle(Landroid/graphics/Canvas;)V
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "7"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eqz v2, :cond_17

    new-array v2, v4, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->paint:Landroid/graphics/Paint;

    const/16 v1, 0xff

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v0

    mul-int/lit8 v0, v0, 0xe

    div-int/lit8 v0, v0, 0x3c

    div-int/2addr v0, v4

    add-int/2addr v0, v3

    .line 3
    iget-object v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    iget v2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->targetLeft:I

    sub-int/2addr v2, v0

    int-to-float v2, v2

    iget v3, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->targetTop:I

    sub-int/2addr v3, v0

    int-to-float v3, v3

    iget-object v5, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v1, v2, v3, v5}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 4
    iget-object v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->matrix:Landroid/graphics/Matrix;

    invoke-virtual {v1}, Landroid/graphics/Matrix;->reset()V

    .line 5
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 6
    iget-object v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->matrix:Landroid/graphics/Matrix;

    const/high16 v2, 0x42b40000    # 90.0f

    iget-object v3, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    invoke-virtual {v3}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v3

    div-int/2addr v3, v4

    int-to-float v3, v3

    iget-object v5, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    .line 7
    invoke-virtual {v5}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v5

    div-int/2addr v5, v4

    int-to-float v5, v5

    .line 8
    invoke-virtual {v1, v2, v3, v5}, Landroid/graphics/Matrix;->setRotate(FFF)V

    .line 9
    iget v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->targetRight:I

    iget-object v2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v2

    sub-int/2addr v1, v2

    add-int/2addr v1, v0

    int-to-float v1, v1

    iget v2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->targetTop:I

    sub-int/2addr v2, v0

    int-to-float v2, v2

    invoke-virtual {p1, v1, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 10
    iget-object v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    iget-object v2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->matrix:Landroid/graphics/Matrix;

    iget-object v3, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v1, v2, v3}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Matrix;Landroid/graphics/Paint;)V

    .line 11
    iget v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->targetBottom:I

    iget v2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->targetTop:I

    sub-int/2addr v1, v2

    iget-object v2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v2

    sub-int/2addr v1, v2

    mul-int/lit8 v0, v0, 0x2

    add-int/2addr v1, v0

    int-to-float v1, v1

    const/4 v2, 0x0

    invoke-virtual {p1, v2, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 12
    iget-object v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->matrix:Landroid/graphics/Matrix;

    const/high16 v3, 0x43340000    # 180.0f

    iget-object v5, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    invoke-virtual {v5}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v5

    div-int/2addr v5, v4

    int-to-float v5, v5

    iget-object v6, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    .line 13
    invoke-virtual {v6}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v6

    div-int/2addr v6, v4

    int-to-float v6, v6

    .line 14
    invoke-virtual {v1, v3, v5, v6}, Landroid/graphics/Matrix;->setRotate(FFF)V

    .line 15
    iget-object v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    iget-object v3, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->matrix:Landroid/graphics/Matrix;

    iget-object v5, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v1, v3, v5}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Matrix;Landroid/graphics/Paint;)V

    .line 16
    iget v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->targetRight:I

    iget v3, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->targetLeft:I

    sub-int/2addr v1, v3

    iget-object v3, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    invoke-virtual {v3}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v3

    sub-int/2addr v1, v3

    add-int/2addr v1, v0

    neg-int v0, v1

    int-to-float v0, v0

    invoke-virtual {p1, v0, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 17
    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->matrix:Landroid/graphics/Matrix;

    const/high16 v1, 0x43870000    # 270.0f

    iget-object v2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v2

    div-int/2addr v2, v4

    int-to-float v2, v2

    iget-object v3, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    .line 18
    invoke-virtual {v3}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v3

    div-int/2addr v3, v4

    int-to-float v3, v3

    .line 19
    invoke-virtual {v0, v1, v2, v3}, Landroid/graphics/Matrix;->setRotate(FFF)V

    .line 20
    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    iget-object v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->matrix:Landroid/graphics/Matrix;

    iget-object v2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1, v2}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Matrix;Landroid/graphics/Paint;)V

    .line 21
    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    return-void
.end method

.method private drawRect(Landroid/graphics/Canvas;)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "8"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    new-instance v0, Landroid/graphics/Rect;

    iget v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->targetLeft:I

    iget v2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->targetTop:I

    iget v3, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->targetRight:I

    iget v4, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->targetBottom:I

    invoke-direct {v0, v1, v2, v3, v4}, Landroid/graphics/Rect;-><init>(IIII)V

    iget-object v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->xFerPaint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->drawRect(Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    return-void
.end method

.method private drawRectSide(Landroid/graphics/Canvas;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "9"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->paint:Landroid/graphics/Paint;

    iget v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->LINE_COLOR:I

    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->paint:Landroid/graphics/Paint;

    iget v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->dLineWidth:I

    int-to-float v0, v0

    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    return-void
.end method

.method private init()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_14
    const/4 v0, 0x2

    const/4 v1, 0x0

    .line 1
    invoke-virtual {p0, v0, v1}, Landroid/view/View;->setLayerType(ILandroid/graphics/Paint;)V

    .line 2
    invoke-virtual {p0, p0}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 3
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/alibaba/wireless/security/aopsdk/replace/android/os/Build;->getBRAND()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "/"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ltb/d41;->b()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "GiONEE/GN5001S"

    invoke-static {v0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_44

    const/16 v0, 0xa

    .line 4
    iput v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->ZOOM_PACE:I

    .line 5
    :cond_44
    new-instance v0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView$a;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, p0, v1}, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView$a;-><init>(Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;Landroid/os/Looper;)V

    iput-object v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->handler:Landroid/os/Handler;

    return-void
.end method

.method private initAngleBitmap(Landroid/content/Context;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    .line 2
    sget v0, Lcn/damai/commonbusiness/R$drawable;->qrcode_corner_left_top:I

    invoke-static {p1, v0}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object p1

    iput-object p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->angle_leftTop:Landroid/graphics/Bitmap;

    return-void
.end method

.method private initPaint()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_14

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->paint:Landroid/graphics/Paint;

    .line 2
    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 3
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->xFerPaint:Landroid/graphics/Paint;

    .line 4
    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->xFerPaint:Landroid/graphics/Paint;

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 6
    new-instance v0, Landroid/graphics/PorterDuffXfermode;

    sget-object v1, Landroid/graphics/PorterDuff$Mode;->DST_OUT:Landroid/graphics/PorterDuff$Mode;

    invoke-direct {v0, v1}, Landroid/graphics/PorterDuffXfermode;-><init>(Landroid/graphics/PorterDuff$Mode;)V

    .line 7
    iget-object v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->xFerPaint:Landroid/graphics/Paint;

    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    return-void
.end method

.method private onFinderClickHappen(Landroid/os/Message;)V
    .registers 8

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v2, :cond_17

    new-array v2, v3, [Ljava/lang/Object;

    aput-object p0, v2, v5

    aput-object p1, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_17
    const/4 v0, 0x4

    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "onClick(): x="

    aput-object v1, v0, v5

    .line 1
    iget v1, p1, Landroid/os/Message;->arg1:I

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v4

    const-string v1, ", y="

    aput-object v1, v0, v3

    const/4 v1, 0x3

    iget v2, p1, Landroid/os/Message;->arg2:I

    .line 2
    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    const-string v1, "ScaleFinderView"

    .line 3
    invoke-static {v1, v0}, Lcom/alipay/mobile/bqcscanservice/MPaasLogger;->d(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 4
    iget v0, p1, Landroid/os/Message;->arg1:I

    .line 5
    iget p1, p1, Landroid/os/Message;->arg2:I

    .line 6
    iget-object v1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->onFinderClickListener:Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView$OnFinderClickListener;

    if-eqz v1, :cond_53

    .line 7
    iget v2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->targetLeft:I

    if-le v0, v2, :cond_53

    iget v2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->targetTop:I

    if-le p1, v2, :cond_53

    iget v2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->targetRight:I

    if-ge v0, v2, :cond_53

    iget v2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->targetBottom:I

    if-ge v0, v2, :cond_53

    .line 8
    invoke-interface {v1, v0, p1}, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView$OnFinderClickListener;->onClick(II)V

    :cond_53
    return-void
.end method


# virtual methods
.method public onDraw(Landroid/graphics/Canvas;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-super {p0, p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    .line 2
    iget v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->shadowColor:I

    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->drawColor(I)V

    .line 3
    iget-boolean v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->showScanRect:Z

    if-eqz v0, :cond_2c

    .line 4
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->drawRect(Landroid/graphics/Canvas;)V

    .line 5
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->drawRectSide(Landroid/graphics/Canvas;)V

    .line 6
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->drawAngle(Landroid/graphics/Canvas;)V

    :cond_2c
    return-void
.end method

.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .registers 14

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "11"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-eqz v2, :cond_21

    new-array v2, v3, [Ljava/lang/Object;

    aput-object p0, v2, v5

    aput-object p1, v2, v6

    aput-object p2, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    return p1

    :cond_21
    new-array v0, v6, [Ljava/lang/Object;

    .line 1
    invoke-virtual {p2}, Landroid/view/MotionEvent;->toString()Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v5

    const-string v1, "ScaleFinderView"

    invoke-static {v1, v0}, Lcom/alipay/mobile/bqcscanservice/MPaasLogger;->d(Ljava/lang/String;[Ljava/lang/Object;)V

    if-eq p1, p0, :cond_31

    return v5

    .line 2
    :cond_31
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result p1

    const/4 v0, 0x0

    if-ne p1, v6, :cond_95

    .line 3
    iput v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->lastTwoFingerDistance:F

    .line 4
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    .line 5
    iget-wide v7, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->lastActionUp:J

    sub-long v7, v2, v7

    const-wide/16 v9, 0x12c

    cmp-long p1, v7, v9

    if-gez p1, :cond_5d

    new-array p1, v6, [Ljava/lang/Object;

    const-string p2, "double click"

    aput-object p2, p1, v5

    .line 6
    invoke-static {v1, p1}, Lcom/alipay/mobile/bqcscanservice/MPaasLogger;->d(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 7
    iget-object p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->onZoomOperatedListener:Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView$OnZoomOperatedListener;

    if-eqz p1, :cond_58

    .line 8
    invoke-interface {p1}, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView$OnZoomOperatedListener;->onZoomReverted()V

    :cond_58
    const-wide/16 p1, 0x0

    .line 9
    iput-wide p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->lastActionUp:J

    goto :goto_94

    .line 10
    :cond_5d
    iput-wide v2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->lastActionUp:J

    .line 11
    iget-boolean p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->mSupportManual:Z

    if-eqz p1, :cond_94

    new-array p1, v6, [Ljava/lang/Object;

    const-string v0, "click"

    aput-object v0, p1, v5

    .line 12
    invoke-static {v1, p1}, Lcom/alipay/mobile/bqcscanservice/MPaasLogger;->d(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 13
    iget-object p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->handler:Landroid/os/Handler;

    if-eqz p1, :cond_94

    .line 14
    invoke-static {}, Landroid/os/Message;->obtain()Landroid/os/Message;

    move-result-object p1

    .line 15
    sget v0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->MSG_CLICK:I

    iput v0, p1, Landroid/os/Message;->what:I

    .line 16
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    float-to-int v0, v0

    iput v0, p1, Landroid/os/Message;->arg1:I

    .line 17
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getY()F

    move-result p2

    float-to-int p2, p2

    iput p2, p1, Landroid/os/Message;->arg2:I

    .line 18
    new-instance p2, Ljava/lang/Long;

    iget-wide v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->lastActionUp:J

    invoke-direct {p2, v0, v1}, Ljava/lang/Long;-><init>(J)V

    iput-object p2, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 19
    iget-object p2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->handler:Landroid/os/Handler;

    invoke-virtual {p2, p1, v9, v10}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    :cond_94
    :goto_94
    return v6

    .line 20
    :cond_95
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result p1

    if-ne p1, v4, :cond_182

    .line 21
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getPointerCount()I

    move-result p1

    const/4 v0, 0x4

    const v2, 0x3dcccccd    # 0.1f

    if-ne p1, v4, :cond_125

    .line 22
    iget p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->lastTwoFingerDistance:F

    const-wide/high16 v7, 0x4000000000000000L    # 2.0

    cmpg-float p1, p1, v2

    if-gez p1, :cond_d2

    .line 23
    invoke-virtual {p2, v5}, Landroid/view/MotionEvent;->getX(I)F

    move-result p1

    .line 24
    invoke-virtual {p2, v5}, Landroid/view/MotionEvent;->getY(I)F

    move-result v0

    .line 25
    invoke-virtual {p2, v6}, Landroid/view/MotionEvent;->getX(I)F

    move-result v1

    .line 26
    invoke-virtual {p2, v6}, Landroid/view/MotionEvent;->getY(I)F

    move-result p2

    sub-float/2addr p1, v1

    float-to-double v1, p1

    .line 27
    invoke-static {v1, v2, v7, v8}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v1

    sub-float/2addr v0, p2

    float-to-double p1, v0

    .line 28
    invoke-static {p1, p2, v7, v8}, Ljava/lang/Math;->pow(DD)D

    move-result-wide p1

    add-double/2addr v1, p1

    .line 29
    invoke-static {v1, v2}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide p1

    double-to-float p1, p1

    iput p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->lastTwoFingerDistance:F

    goto :goto_124

    .line 30
    :cond_d2
    invoke-virtual {p2, v5}, Landroid/view/MotionEvent;->getX(I)F

    move-result p1

    .line 31
    invoke-virtual {p2, v5}, Landroid/view/MotionEvent;->getY(I)F

    move-result v2

    .line 32
    invoke-virtual {p2, v6}, Landroid/view/MotionEvent;->getX(I)F

    move-result v9

    .line 33
    invoke-virtual {p2, v6}, Landroid/view/MotionEvent;->getY(I)F

    move-result p2

    sub-float/2addr p1, v9

    float-to-double v9, p1

    .line 34
    invoke-static {v9, v10, v7, v8}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v9

    sub-float/2addr v2, p2

    float-to-double p1, v2

    .line 35
    invoke-static {p1, p2, v7, v8}, Ljava/lang/Math;->pow(DD)D

    move-result-wide p1

    add-double/2addr v9, p1

    .line 36
    invoke-static {v9, v10}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide p1

    double-to-float p1, p1

    new-array p2, v0, [Ljava/lang/Object;

    const-string v0, "lastTwoFingerDistance is "

    aput-object v0, p2, v5

    .line 37
    iget v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->lastTwoFingerDistance:F

    .line 38
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    aput-object v0, p2, v6

    const-string v0, ", distance is "

    aput-object v0, p2, v4

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    aput-object v0, p2, v3

    .line 39
    invoke-static {v1, p2}, Lcom/alipay/mobile/bqcscanservice/MPaasLogger;->d(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 40
    iget p2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->lastTwoFingerDistance:F

    sub-float/2addr p1, p2

    float-to-int p1, p1

    iget p2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->ZOOM_PACE:I

    div-int/2addr p1, p2

    .line 41
    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    move-result p2

    if-le p2, v6, :cond_124

    .line 42
    iget-object p2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->onZoomOperatedListener:Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView$OnZoomOperatedListener;

    if-eqz p2, :cond_124

    int-to-float p1, p1

    .line 43
    invoke-interface {p2, p1}, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView$OnZoomOperatedListener;->setZoom(F)V

    :cond_124
    :goto_124
    return v6

    .line 44
    :cond_125
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getPointerCount()I

    move-result p1

    if-ne p1, v6, :cond_181

    .line 45
    iget-boolean p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->mSupportManual:Z

    if-eqz p1, :cond_180

    .line 46
    iget p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->lastSingleFingerPositionY:F

    cmpg-float p1, p1, v2

    if-gtz p1, :cond_13c

    .line 47
    invoke-virtual {p2, v5}, Landroid/view/MotionEvent;->getY(I)F

    move-result p1

    iput p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->lastSingleFingerPositionY:F

    goto :goto_180

    .line 48
    :cond_13c
    invoke-virtual {p2, v5}, Landroid/view/MotionEvent;->getY(I)F

    move-result p1

    new-array p2, v0, [Ljava/lang/Object;

    const-string v0, "move: singleFingerPositionY is "

    aput-object v0, p2, v5

    .line 49
    iget v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->lastSingleFingerPositionY:F

    .line 50
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    aput-object v0, p2, v6

    const-string v0, ", curPositionY is "

    aput-object v0, p2, v4

    .line 51
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    aput-object v0, p2, v3

    .line 52
    invoke-static {v1, p2}, Lcom/alipay/mobile/bqcscanservice/MPaasLogger;->d(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 53
    iget p2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->lastSingleFingerPositionY:F

    sub-float/2addr p2, p1

    float-to-int p2, p2

    iget v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->MOVE_PACE:I

    div-int/2addr p2, v0

    new-array v0, v4, [Ljava/lang/Object;

    const-string v2, "move: rate = "

    aput-object v2, v0, v5

    .line 54
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v0, v6

    invoke-static {v1, v0}, Lcom/alipay/mobile/bqcscanservice/MPaasLogger;->d(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 55
    invoke-static {p2}, Ljava/lang/Math;->abs(I)I

    move-result v0

    if-le v0, v6, :cond_180

    .line 56
    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->onFinderMoveListener:Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView$OnFinderMoveListener;

    if-eqz v0, :cond_17e

    .line 57
    invoke-interface {v0, p2}, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView$OnFinderMoveListener;->onMove(I)V

    .line 58
    :cond_17e
    iput p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->lastSingleFingerPositionY:F

    :cond_180
    :goto_180
    return v6

    :cond_181
    return v5

    .line 59
    :cond_182
    iput v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->lastTwoFingerDistance:F

    .line 60
    iput v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->lastSingleFingerPositionY:F

    return v6
.end method

.method public setOnFinderClickListener(Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView$OnFinderClickListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "13"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->onFinderClickListener:Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView$OnFinderClickListener;

    return-void
.end method

.method public setOnFinderMoveListener(Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView$OnFinderMoveListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "14"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->onFinderMoveListener:Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView$OnFinderMoveListener;

    return-void
.end method

.method public setOnZoomOperatedListener(Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView$OnZoomOperatedListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "12"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->onZoomOperatedListener:Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView$OnZoomOperatedListener;

    return-void
.end method

.method public setShowScanRect(Z)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "10"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iput-boolean p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->showScanRect:Z

    return-void
.end method

.method public setSupportManual(Z)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "15"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iput-boolean p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->mSupportManual:Z

    return-void
.end method

.method public setTargetLocation(IIII)V
    .registers 14

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    if-eqz v2, :cond_30

    new-array v2, v3, [Ljava/lang/Object;

    aput-object p0, v2, v8

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v7

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v6

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v5

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_30
    const/16 v0, 0x8

    new-array v0, v0, [Ljava/lang/Object;

    const-string v1, "setTargetLocation: left="

    aput-object v1, v0, v8

    .line 1
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v0, v7

    const-string v1, ", top="

    aput-object v1, v0, v6

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v0, v5

    const-string v1, ", right="

    aput-object v1, v0, v4

    .line 2
    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v0, v3

    const/4 v1, 0x6

    const-string v2, ", bottom="

    aput-object v2, v0, v1

    const/4 v1, 0x7

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v0, v1

    const-string v1, "ScaleFinderView"

    .line 3
    invoke-static {v1, v0}, Lcom/alipay/mobile/bqcscanservice/MPaasLogger;->d(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 4
    iget v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->targetLeft:I

    if-ne p1, v0, :cond_74

    iget v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->targetRight:I

    if-ne v0, p3, :cond_74

    iget v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->targetTop:I

    if-ne v0, p2, :cond_74

    iget v0, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->targetBottom:I

    if-ne v0, p4, :cond_74

    return-void

    .line 5
    :cond_74
    iput p1, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->targetLeft:I

    .line 6
    iput p3, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->targetRight:I

    .line 7
    iput p2, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->targetTop:I

    .line 8
    iput p4, p0, Lcn/damai/commonbusiness/qrcode/widget/ScaleFinderView;->targetBottom:I

    return-void
.end method
