.class public Lcn/damai/commonbusiness/base/ResponseErrorPage;
.super Landroid/widget/LinearLayout;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/base/ResponseErrorPage$ErrorRefreshListener;
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private defaultErrorMsg:Ljava/lang/String;

.field private isOperation:Z

.field private isPioneer:Z

.field private mApiName:Ljava/lang/String;

.field private mBtnOther:Landroid/widget/TextView;

.field private mBtnRefresh:Landroid/widget/TextView;

.field private mBtnReport:Landroid/widget/TextView;

.field private mContext:Landroid/content/Context;

.field private mErrorCode:Ljava/lang/String;

.field private mErrorMsg:Ljava/lang/String;

.field private mErrorPageContainer:Landroid/widget/LinearLayout;

.field private mErrorPageLayout:Landroid/widget/LinearLayout;

.field private mErrorType:I

.field private mExtraBuilder:Ljava/lang/StringBuilder;

.field private mLayoutInflater:Landroid/view/LayoutInflater;

.field private mLeftBtn:Landroid/view/View;

.field private mRefreshListener:Lcn/damai/commonbusiness/base/ResponseErrorPage$ErrorRefreshListener;

.field private mRootView:Landroid/view/View;

.field public mTitleView:Landroid/view/View;

.field private mTvErrorContent:Landroid/widget/TextView;

.field private mTvErrorImage:Landroid/widget/ImageView;

.field private mTvErrorTitle:Landroid/widget/TextView;

.field private refreshContent:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/app/Activity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 15

    .line 13
    invoke-direct {p0, p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const-string v0, ""

    .line 14
    iput-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->defaultErrorMsg:Ljava/lang/String;

    const/4 v0, 0x0

    .line 15
    iput-boolean v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->isPioneer:Z

    const-string v0, "\u52aa\u529b\u5237\u65b0"

    .line 16
    iput-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->refreshContent:Ljava/lang/String;

    .line 17
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iput-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mExtraBuilder:Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    move-object v1, p0

    move-object v2, p1

    move-object v3, p1

    move v4, p2

    move-object v5, p3

    move-object v6, p4

    move-object v7, p5

    .line 18
    invoke-direct/range {v1 .. v8}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->init(Landroid/app/Activity;Landroid/content/Context;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)V

    return-void
.end method

.method public constructor <init>(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 14

    .line 1
    invoke-direct {p0, p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const-string v0, ""

    .line 2
    iput-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->defaultErrorMsg:Ljava/lang/String;

    const/4 v0, 0x0

    .line 3
    iput-boolean v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->isPioneer:Z

    const-string v0, "\u52aa\u529b\u5237\u65b0"

    .line 4
    iput-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->refreshContent:Ljava/lang/String;

    .line 5
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iput-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mExtraBuilder:Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v8, 0x0

    move-object v1, p0

    move-object v2, p1

    move-object v3, p1

    move-object v5, p2

    move-object v6, p3

    move-object v7, p4

    .line 6
    invoke-direct/range {v1 .. v8}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->init(Landroid/app/Activity;Landroid/content/Context;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)V
    .registers 15

    .line 7
    invoke-direct {p0, p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const-string v0, ""

    .line 8
    iput-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->defaultErrorMsg:Ljava/lang/String;

    const/4 v0, 0x0

    .line 9
    iput-boolean v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->isPioneer:Z

    const-string v0, "\u52aa\u529b\u5237\u65b0"

    .line 10
    iput-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->refreshContent:Ljava/lang/String;

    .line 11
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iput-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mExtraBuilder:Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v4, 0x1

    move-object v1, p0

    move-object v3, p1

    move-object v5, p2

    move-object v6, p3

    move-object v7, p4

    move-object v8, p5

    .line 12
    invoke-direct/range {v1 .. v8}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->init(Landroid/app/Activity;Landroid/content/Context;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)V

    return-void
.end method

.method private exitCurrentPage()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "26"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    if-nez v0, :cond_19

    return-void

    .line 2
    :cond_19
    instance-of v1, v0, Landroid/app/Activity;

    if-eqz v1, :cond_22

    .line 3
    check-cast v0, Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    :cond_22
    return-void
.end method

.method private getEmptyImage(Z)I
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "16"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_22

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    return p1

    :cond_22
    if-eqz p1, :cond_32

    .line 1
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    invoke-static {p1}, Ltb/sd4;->b(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_2f

    .line 2
    sget p1, Lcn/damai/commonbusiness/R$drawable;->pioneer_page_common_no_order:I

    goto :goto_31

    .line 3
    :cond_2f
    sget p1, Lcn/damai/commonbusiness/R$drawable;->pioneer_page_common_no_data:I

    :goto_31
    return p1

    .line 4
    :cond_32
    sget p1, Lcn/damai/commonbusiness/R$drawable;->common_error_ticket_empty:I

    return p1
.end method

.method private getExtraData(Ljava/lang/String;)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "18"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mExtraBuilder:Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v1

    invoke-virtual {v0, v4, v1}, Ljava/lang/StringBuilder;->delete(II)Ljava/lang/StringBuilder;

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mApiName:Ljava/lang/String;

    if-eqz v0, :cond_51

    .line 3
    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    const-string v1, "apiname"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_38

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mExtraBuilder:Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mApiName:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_50

    .line 5
    :cond_38
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mExtraBuilder:Ljava/lang/StringBuilder;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "apiName:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mApiName:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_50
    const/4 v4, 0x1

    .line 6
    :cond_51
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorCode:Ljava/lang/String;

    const-string v1, ","

    if-eqz v0, :cond_77

    if-eqz v4, :cond_5e

    .line 7
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mExtraBuilder:Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 8
    :cond_5e
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mExtraBuilder:Ljava/lang/StringBuilder;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "errorCode:"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorCode:Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_78

    :cond_77
    move v3, v4

    .line 9
    :goto_78
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorMsg:Ljava/lang/String;

    if-eqz v0, :cond_9b

    if-eqz v3, :cond_83

    .line 10
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mExtraBuilder:Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 11
    :cond_83
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mExtraBuilder:Ljava/lang/StringBuilder;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "errorMsg:"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorMsg:Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 12
    :cond_9b
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_ad

    if-eqz v3, :cond_a8

    .line 13
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mExtraBuilder:Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 14
    :cond_a8
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mExtraBuilder:Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_ad
    return-void
.end method

.method private getPageData(Landroid/app/Activity;)Ljava/lang/String;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "20"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    return-object p1

    :cond_1a
    const/4 v0, 0x0

    if-nez p1, :cond_1e

    return-object v0

    .line 15
    :cond_1e
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 16
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->length()I

    move-result v2

    invoke-virtual {v1, v3, v2}, Ljava/lang/StringBuilder;->delete(II)Ljava/lang/StringBuilder;

    .line 17
    invoke-virtual {p1}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v2

    if-eqz v2, :cond_38

    .line 18
    invoke-virtual {p1}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v0

    .line 19
    :cond_38
    invoke-direct {p0, v0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->getPageData(Landroid/os/Bundle;)Ljava/lang/String;

    .line 20
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method private getPageData(Landroid/os/Bundle;)Ljava/lang/String;
    .registers 8

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "19"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    aput-object p1, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    return-object p1

    .line 1
    :cond_1a
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 2
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v1

    invoke-virtual {v0, v3, v1}, Ljava/lang/StringBuilder;->delete(II)Ljava/lang/StringBuilder;

    if-eqz p1, :cond_7b

    .line 3
    invoke-virtual {p1}, Landroid/os/Bundle;->keySet()Ljava/util/Set;

    move-result-object v1

    if-eqz v1, :cond_7b

    .line 4
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const-string v2, "errorjson={"

    .line 5
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 6
    :cond_37
    :goto_37
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_64

    .line 7
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 8
    invoke-virtual {p1, v2}, Landroid/os/Bundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    if-eqz v3, :cond_37

    .line 9
    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    if-eqz v5, :cond_37

    .line 10
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ":"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ","

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_37

    .line 11
    :cond_64
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result p1

    if-le p1, v4, :cond_76

    .line 12
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result p1

    sub-int/2addr p1, v4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v1

    invoke-virtual {v0, p1, v1}, Ljava/lang/StringBuilder;->delete(II)Ljava/lang/StringBuilder;

    :cond_76
    const-string p1, "}"

    .line 13
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 14
    :cond_7b
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method private getScreenImage()Ljava/lang/String;
    .registers 13

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "25"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_17

    new-array v2, v4, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    const-string v1, ""

    if-nez v0, :cond_1e

    return-object v1

    :cond_1e
    const/4 v2, 0x0

    .line 2
    :try_start_1f
    check-cast v0, Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    .line 3
    invoke-virtual {v0, v4}, Landroid/view/View;->setDrawingCacheEnabled(Z)V

    .line 4
    invoke-virtual {v0}, Landroid/view/View;->buildDrawingCache()V

    .line 5
    invoke-virtual {v0}, Landroid/view/View;->getDrawingCache()Landroid/graphics/Bitmap;

    move-result-object v5

    .line 6
    new-instance v10, Landroid/graphics/Matrix;

    invoke-direct {v10}, Landroid/graphics/Matrix;-><init>()V

    const/high16 v0, 0x3f000000    # 0.5f

    .line 7
    invoke-virtual {v10, v0, v0}, Landroid/graphics/Matrix;->setScale(FF)V

    const/4 v6, 0x0

    const/4 v7, 0x0

    .line 8
    invoke-virtual {v5}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v8

    invoke-virtual {v5}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v9

    const/4 v11, 0x0

    invoke-static/range {v5 .. v11}, Landroid/graphics/Bitmap;->createBitmap(Landroid/graphics/Bitmap;IIIILandroid/graphics/Matrix;Z)Landroid/graphics/Bitmap;

    move-result-object v2

    if-eqz v2, :cond_93

    .line 9
    invoke-static {}, Ltb/mn1;->m()Ljava/lang/String;

    move-result-object v0

    .line 10
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_93

    .line 11
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, "/feedback"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v3}, Ltb/mn1;->t(Ljava/lang/String;Z)Z

    .line 12
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "/feedback/screen.jpg"

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 13
    invoke-static {v0}, Ltb/mn1;->d(Ljava/lang/String;)Ljava/io/File;

    .line 14
    new-instance v3, Ljava/io/FileOutputStream;

    invoke-direct {v3, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/lang/String;)V

    .line 15
    sget-object v4, Landroid/graphics/Bitmap$CompressFormat;->JPEG:Landroid/graphics/Bitmap$CompressFormat;

    const/16 v5, 0x64

    invoke-virtual {v2, v4, v5, v3}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    .line 16
    invoke-virtual {v3}, Ljava/io/FileOutputStream;->flush()V

    .line 17
    invoke-virtual {v3}, Ljava/io/FileOutputStream;->close()V
    :try_end_92
    .catch Ljava/lang/Exception; {:try_start_1f .. :try_end_92} :catch_a0
    .catchall {:try_start_1f .. :try_end_92} :catchall_99

    move-object v1, v0

    :cond_93
    if-eqz v2, :cond_a3

    .line 18
    :goto_95
    invoke-virtual {v2}, Landroid/graphics/Bitmap;->recycle()V

    goto :goto_a3

    :catchall_99
    move-exception v0

    if-eqz v2, :cond_9f

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->recycle()V

    .line 19
    :cond_9f
    throw v0

    :catch_a0
    if-eqz v2, :cond_a3

    goto :goto_95

    :cond_a3
    :goto_a3
    return-object v1
.end method

.method private hideRefreshBtn()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "14"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnRefresh:Landroid/widget/TextView;

    if-eqz v0, :cond_1d

    const/16 v1, 0x8

    .line 2
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    :cond_1d
    return-void
.end method

.method private init(Landroid/app/Activity;Landroid/content/Context;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)V
    .registers 13

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_2e

    const/16 v2, 0x8

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    aput-object p4, v2, p1

    const/4 p1, 0x5

    aput-object p5, v2, p1

    const/4 p1, 0x6

    aput-object p6, v2, p1

    const/4 p1, 0x7

    aput-object p7, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_2e
    iput-object p2, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    .line 2
    iput-object p6, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mApiName:Ljava/lang/String;

    .line 3
    iput-object p4, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorCode:Ljava/lang/String;

    .line 4
    iput-object p5, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorMsg:Ljava/lang/String;

    .line 5
    iput p3, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorType:I

    const-string p6, "layout_inflater"

    .line 6
    invoke-virtual {p2, p6}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroid/view/LayoutInflater;

    iput-object p2, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mLayoutInflater:Landroid/view/LayoutInflater;

    .line 7
    sget-object p2, Ltb/oa;->INSTANCE:Ltb/oa;

    .line 8
    invoke-virtual {p2}, Ltb/oa;->getAppConfigProvider()Lcom/alibaba/pictures/cornerstone/common/IAppConfigProvider;

    move-result-object p6

    if-eqz p6, :cond_55

    invoke-virtual {p2}, Ltb/oa;->getAppConfigProvider()Lcom/alibaba/pictures/cornerstone/common/IAppConfigProvider;

    move-result-object p2

    invoke-interface {p2}, Lcom/alibaba/pictures/cornerstone/common/IAppConfigProvider;->getIsPioneerOpen()Z

    move-result p2

    if-eqz p2, :cond_55

    goto :goto_56

    :cond_55
    const/4 v3, 0x0

    :goto_56
    iput-boolean v3, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->isPioneer:Z

    if-eqz p7, :cond_62

    .line 9
    invoke-direct {p0, p7}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->getPageData(Landroid/os/Bundle;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->getExtraData(Ljava/lang/String;)V

    goto :goto_6b

    :cond_62
    if-eqz p1, :cond_6b

    .line 10
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->getPageData(Landroid/app/Activity;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->getExtraData(Ljava/lang/String;)V

    .line 11
    :cond_6b
    :goto_6b
    invoke-direct {p0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->initView()V

    .line 12
    invoke-direct {p0, p4, p3}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->initButtonView(Ljava/lang/String;I)V

    .line 13
    invoke-virtual {p0, p4, p5}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->loadErrorMsg(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method private initButtonView()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "7"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mRootView:Landroid/view/View;

    if-nez v0, :cond_19

    return-void

    .line 2
    :cond_19
    sget-object v0, Ltb/oa;->INSTANCE:Ltb/oa;

    .line 3
    invoke-virtual {v0}, Ltb/oa;->getAppConfigProvider()Lcom/alibaba/pictures/cornerstone/common/IAppConfigProvider;

    move-result-object v0

    invoke-interface {v0}, Lcom/alibaba/pictures/cornerstone/common/IAppConfigProvider;->getIsPioneerOpen()Z

    move-result v0

    .line 4
    iget-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mRootView:Landroid/view/View;

    sget v2, Lcn/damai/commonbusiness/R$id;->btn_refresh:I

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnRefresh:Landroid/widget/TextView;

    .line 5
    iget-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mRootView:Landroid/view/View;

    sget v2, Lcn/damai/commonbusiness/R$id;->tv_report:I

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnReport:Landroid/widget/TextView;

    .line 6
    iget-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mRootView:Landroid/view/View;

    sget v2, Lcn/damai/commonbusiness/R$id;->btn_other:I

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnOther:Landroid/widget/TextView;

    const/16 v2, 0x8

    .line 7
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setVisibility(I)V

    .line 8
    iget-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnRefresh:Landroid/widget/TextView;

    invoke-virtual {v1, p0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    if-eqz v0, :cond_75

    .line 9
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    iget-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorContent:Landroid/widget/TextView;

    invoke-static {v0, v1}, Ltb/sd4;->g(Landroid/content/Context;Landroid/widget/TextView;)V

    .line 10
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorPageLayout:Landroid/widget/LinearLayout;

    iget-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    const/high16 v2, 0x41f00000    # 30.0f

    invoke-static {v1, v2}, Ltb/d31;->a(Landroid/content/Context;F)I

    move-result v1

    invoke-virtual {v0, v3, v3, v3, v1}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 11
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    iget-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnRefresh:Landroid/widget/TextView;

    invoke-static {v0, v1}, Ltb/sd4;->c(Landroid/content/Context;Landroid/widget/TextView;)V

    .line 12
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnRefresh:Landroid/widget/TextView;

    sget v1, Lcn/damai/commonbusiness/R$drawable;->bg_error_page_button_pioneer:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 13
    :cond_75
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnOther:Landroid/widget/TextView;

    invoke-virtual {v0, p0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method private initButtonView(Ljava/lang/String;I)V
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "15"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_1e

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    aput-object p1, v2, v4

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 14
    :cond_1e
    sget-object v0, Ltb/oa;->INSTANCE:Ltb/oa;

    .line 15
    invoke-virtual {v0}, Ltb/oa;->getAppConfigProvider()Lcom/alibaba/pictures/cornerstone/common/IAppConfigProvider;

    move-result-object v0

    invoke-interface {v0}, Lcom/alibaba/pictures/cornerstone/common/IAppConfigProvider;->getIsPioneerOpen()Z

    move-result v0

    .line 16
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_51

    const-string v1, "DM_SECONDARY_ORDER_ERROR_02"

    .line 17
    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_51

    .line 18
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->refreshContent:Ljava/lang/String;

    invoke-virtual {p0, v4, p1}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->updateBtnState(ZLjava/lang/String;)V

    const-string p1, "\u6b63\u5728\u6392\u961f\uff0c\u8bf7\u7a0d\u540e\u54e6"

    .line 19
    iput-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->defaultErrorMsg:Ljava/lang/String;

    if-eqz v0, :cond_49

    .line 20
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorImage:Landroid/widget/ImageView;

    sget p2, Lcn/damai/commonbusiness/R$drawable;->pioneer_page_common_error:I

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setImageResource(I)V

    goto :goto_50

    .line 21
    :cond_49
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorImage:Landroid/widget/ImageView;

    sget p2, Lcn/damai/commonbusiness/R$drawable;->dm_common_neterror_waiting:I

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setImageResource(I)V

    :goto_50
    return-void

    :cond_51
    const-string v1, "\u91cd\u65b0\u9009\u62e9"

    const-string v2, "\u62a2\u7968\u4eba\u6570\u592a\u591a\u5566\uff0c\u7ee7\u7eed\u5c1d\u8bd5\u522b\u653e\u5f03"

    const-string v5, ""

    packed-switch p2, :pswitch_data_198

    .line 22
    :pswitch_5a
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->refreshContent:Ljava/lang/String;

    invoke-virtual {p0, v4, p1}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->updateBtnState(ZLjava/lang/String;)V

    .line 23
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    sget p2, Lcn/damai/commonbusiness/R$string;->common_net_error_tip:I

    invoke-virtual {p1, p2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->defaultErrorMsg:Ljava/lang/String;

    if-eqz v0, :cond_18f

    .line 24
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorImage:Landroid/widget/ImageView;

    sget p2, Lcn/damai/commonbusiness/R$drawable;->pioneer_page_common_error:I

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setImageResource(I)V

    goto/16 :goto_196

    .line 25
    :pswitch_78
    invoke-virtual {p0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->hideReportBtn()V

    .line 26
    invoke-direct {p0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->hideRefreshBtn()V

    .line 27
    invoke-virtual {p0, v4, v5}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->updateOtherBtnState(ZLjava/lang/String;)V

    const-string p1, "\u8fd9\u91cc\u7a7a\u7a7a\u5982\u4e5f"

    .line 28
    iput-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->defaultErrorMsg:Ljava/lang/String;

    .line 29
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorImage:Landroid/widget/ImageView;

    invoke-direct {p0, v0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->getEmptyImage(Z)I

    move-result p2

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setImageResource(I)V

    goto/16 :goto_196

    .line 30
    :pswitch_90
    invoke-virtual {p0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->hideReportBtn()V

    const-string p1, "\u767b\u5f55"

    .line 31
    invoke-virtual {p0, v4, p1}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->updateBtnState(ZLjava/lang/String;)V

    const-string p1, "\u4f60\u8fd8\u6ca1\u6709\u767b\u5f55\u54e6(-.-)"

    .line 32
    iput-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->defaultErrorMsg:Ljava/lang/String;

    if-eqz v0, :cond_a7

    .line 33
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorImage:Landroid/widget/ImageView;

    sget p2, Lcn/damai/commonbusiness/R$drawable;->pioneer_page_common_error:I

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setImageResource(I)V

    goto/16 :goto_196

    .line 34
    :cond_a7
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorImage:Landroid/widget/ImageView;

    sget p2, Lcn/damai/commonbusiness/R$drawable;->common_error_ticket_login:I

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setImageResource(I)V

    goto/16 :goto_196

    .line 35
    :pswitch_b0
    invoke-virtual {p0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->hideReportBtn()V

    .line 36
    invoke-virtual {p0, v4, v1}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->updateBtnState(ZLjava/lang/String;)V

    const-string p1, "\u60a8\u9009\u8d2d\u7684\u5546\u54c1\u4fe1\u606f\u5df2\u8fc7\u671f\uff0c\u8bf7\u91cd\u65b0\u67e5\u8be2"

    .line 37
    iput-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->defaultErrorMsg:Ljava/lang/String;

    if-eqz v0, :cond_c5

    .line 38
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorImage:Landroid/widget/ImageView;

    sget p2, Lcn/damai/commonbusiness/R$drawable;->pioneer_page_common_error:I

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setImageResource(I)V

    goto/16 :goto_196

    .line 39
    :cond_c5
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorImage:Landroid/widget/ImageView;

    sget p2, Lcn/damai/commonbusiness/R$drawable;->common_error_ticket_empty:I

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setImageResource(I)V

    goto/16 :goto_196

    .line 40
    :pswitch_ce
    invoke-virtual {p0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->hideReportBtn()V

    .line 41
    invoke-virtual {p0, v4, v1}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->updateBtnState(ZLjava/lang/String;)V

    .line 42
    iput-object v2, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->defaultErrorMsg:Ljava/lang/String;

    if-eqz v0, :cond_e1

    .line 43
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorImage:Landroid/widget/ImageView;

    sget p2, Lcn/damai/commonbusiness/R$drawable;->pioneer_page_common_error:I

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setImageResource(I)V

    goto/16 :goto_196

    .line 44
    :cond_e1
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorImage:Landroid/widget/ImageView;

    sget p2, Lcn/damai/commonbusiness/R$drawable;->common_error_ticket_limit:I

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setImageResource(I)V

    goto/16 :goto_196

    .line 45
    :pswitch_ea
    invoke-virtual {p0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->hideReportBtn()V

    .line 46
    invoke-virtual {p0, v3, v5}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->updateBtnState(ZLjava/lang/String;)V

    .line 47
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    sget p2, Lcn/damai/commonbusiness/R$string;->common_project_no_exist_tip:I

    invoke-virtual {p1, p2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->defaultErrorMsg:Ljava/lang/String;

    .line 48
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorImage:Landroid/widget/ImageView;

    invoke-direct {p0, v0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->getEmptyImage(Z)I

    move-result p2

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setImageResource(I)V

    goto/16 :goto_196

    .line 49
    :pswitch_109
    invoke-virtual {p0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->hideReportBtn()V

    .line 50
    invoke-virtual {p0, v3, v5}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->updateBtnState(ZLjava/lang/String;)V

    .line 51
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    sget p2, Lcn/damai/commonbusiness/R$string;->common_ticket_empty_tip:I

    invoke-virtual {p1, p2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->defaultErrorMsg:Ljava/lang/String;

    .line 52
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorImage:Landroid/widget/ImageView;

    invoke-direct {p0, v0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->getEmptyImage(Z)I

    move-result p2

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setImageResource(I)V

    goto :goto_196

    .line 53
    :pswitch_127
    invoke-virtual {p0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->hideReportBtn()V

    .line 54
    invoke-virtual {p0, v4, v5}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->updateBtnState(ZLjava/lang/String;)V

    .line 55
    iput-object v2, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->defaultErrorMsg:Ljava/lang/String;

    if-eqz v0, :cond_139

    .line 56
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorImage:Landroid/widget/ImageView;

    sget p2, Lcn/damai/commonbusiness/R$drawable;->pioneer_page_common_error:I

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setImageResource(I)V

    goto :goto_196

    .line 57
    :cond_139
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorImage:Landroid/widget/ImageView;

    sget p2, Lcn/damai/commonbusiness/R$drawable;->common_error_ticket_limit:I

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setImageResource(I)V

    goto :goto_196

    .line 58
    :pswitch_141
    iget-object p2, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->refreshContent:Ljava/lang/String;

    invoke-virtual {p0, v4, p2}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->updateBtnState(ZLjava/lang/String;)V

    .line 59
    iget-object p2, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    invoke-virtual {p2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p2

    sget v1, Lcn/damai/commonbusiness/R$string;->common_net_error_tip:I

    invoke-virtual {p2, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p2

    iput-object p2, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->defaultErrorMsg:Ljava/lang/String;

    const-string p2, "ANDROID_SYS_NO_NETWORK"

    .line 60
    invoke-static {p1, p2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const-string v2, "1002"

    if-nez v1, :cond_164

    .line 61
    invoke-static {p1, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_168

    :cond_164
    const-string v1, "\u62b1\u6b49\uff0c\u7f51\u7edc\u4e0d\u592a\u987a\u7545\u54e6\uff0c\u8bf7\u7a0d\u540e\u518d\u8bd5\u5427"

    .line 62
    iput-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->defaultErrorMsg:Ljava/lang/String;

    :cond_168
    if-eqz v0, :cond_187

    .line 63
    invoke-static {p1, p2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p2

    if-nez p2, :cond_17f

    .line 64
    invoke-static {p1, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_177

    goto :goto_17f

    .line 65
    :cond_177
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorImage:Landroid/widget/ImageView;

    sget p2, Lcn/damai/commonbusiness/R$drawable;->pioneer_page_common_error:I

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setImageResource(I)V

    goto :goto_196

    .line 66
    :cond_17f
    :goto_17f
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorImage:Landroid/widget/ImageView;

    sget p2, Lcn/damai/commonbusiness/R$drawable;->common_no_net_with_pioneer:I

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setImageResource(I)V

    goto :goto_196

    .line 67
    :cond_187
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorImage:Landroid/widget/ImageView;

    sget p2, Lcn/damai/commonbusiness/R$drawable;->common_error_net:I

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setImageResource(I)V

    goto :goto_196

    .line 68
    :cond_18f
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorImage:Landroid/widget/ImageView;

    sget p2, Lcn/damai/commonbusiness/R$drawable;->common_error_net:I

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setImageResource(I)V

    :goto_196
    return-void

    nop

    :pswitch_data_198
    .packed-switch 0x1
        :pswitch_141
        :pswitch_127
        :pswitch_109
        :pswitch_ea
        :pswitch_ce
        :pswitch_b0
        :pswitch_90
        :pswitch_5a
        :pswitch_5a
        :pswitch_78
        :pswitch_127
    .end packed-switch
.end method

.method private initView()V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mLayoutInflater:Landroid/view/LayoutInflater;

    sget v1, Lcn/damai/commonbusiness/R$layout;->layout_error_page:I

    invoke-virtual {v0, v1, p0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mRootView:Landroid/view/View;

    .line 2
    sget v1, Lcn/damai/commonbusiness/R$id;->ll_error_container:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorPageContainer:Landroid/widget/LinearLayout;

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mRootView:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->ll_error:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorPageLayout:Landroid/widget/LinearLayout;

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mRootView:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->base_header_title:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorTitle:Landroid/widget/TextView;

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mRootView:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->base_header_left:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mLeftBtn:Landroid/view/View;

    .line 6
    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 7
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mRootView:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->iv_error_tip:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorImage:Landroid/widget/ImageView;

    .line 8
    iget-boolean v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->isPioneer:Z

    const-string v2, "GrabActivity"

    if-eqz v1, :cond_c2

    .line 9
    iget-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    invoke-static {v1, v0}, Ltb/sd4;->d(Landroid/content/Context;Landroid/widget/ImageView;)V

    .line 10
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "TickletListActivity"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_83

    .line 11
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    sget v4, Lcn/damai/commonbusiness/R$color;->bricks_F0F3F7:I

    invoke-virtual {v0, v4}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    invoke-virtual {p0, v0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->setContainerBackground(I)V

    .line 12
    :cond_83
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const-string v4, "TicketMyCommentActivity"

    .line 13
    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 14
    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v1, "DMH5Activity"

    .line 15
    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 16
    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 17
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_9c
    :goto_9c
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_f4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 18
    iget-object v2, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_9c

    .line 19
    iget-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    iget-object v2, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorImage:Landroid/widget/ImageView;

    const/16 v4, -0x6e

    invoke-static {v1, v2, v4}, Ltb/sd4;->e(Landroid/content/Context;Landroid/widget/ImageView;I)V

    goto :goto_9c

    .line 20
    :cond_c2
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 21
    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 22
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_ce
    :goto_ce
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_f4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 23
    iget-object v2, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_ce

    .line 24
    iget-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    iget-object v2, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorImage:Landroid/widget/ImageView;

    const/16 v4, -0x32

    invoke-static {v1, v2, v4}, Ltb/sd4;->e(Landroid/content/Context;Landroid/widget/ImageView;I)V

    goto :goto_ce

    .line 25
    :cond_f4
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mRootView:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->tv_error_tip:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorContent:Landroid/widget/TextView;

    .line 26
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mRootView:Landroid/view/View;

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 27
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mRootView:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->layout_header_view:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTitleView:Landroid/view/View;

    .line 28
    invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V

    .line 29
    invoke-direct {p0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->initButtonView()V

    return-void
.end method

.method private isOperation(Ljava/lang/String;Ljava/lang/String;)Z
    .registers 8

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "27"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_21

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    return p1

    .line 1
    :cond_21
    iget v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorType:I

    if-eq v0, v3, :cond_26

    return v4

    .line 2
    :cond_26
    :try_start_26
    invoke-static {p2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p2
    :try_end_2a
    .catch Ljava/lang/Exception; {:try_start_26 .. :try_end_2a} :catch_2b

    goto :goto_30

    :catch_2b
    move-exception p2

    .line 3
    invoke-virtual {p2}, Ljava/lang/Exception;->printStackTrace()V

    const/4 p2, 0x0

    :goto_30
    if-nez p2, :cond_33

    return v4

    :cond_33
    packed-switch p2, :pswitch_data_48

    .line 4
    invoke-static {p1}, Ltb/mw5;->j(Ljava/lang/String;)Z

    move-result p2

    if-nez p2, :cond_45

    const-string p2, "\u8054\u7cfb\u5ba2\u670d"

    invoke-virtual {p1, p2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_45

    goto :goto_46

    :cond_45
    const/4 v3, 0x0

    :goto_46
    :pswitch_46
    return v3

    nop

    :pswitch_data_48
    .packed-switch 0x226
        :pswitch_46
        :pswitch_46
        :pswitch_46
    .end packed-switch
.end method

.method private refreshListener()V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "24"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_14

    new-array v2, v3, [Ljava/lang/Object;

    aput-object p0, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorType:I

    if-eq v0, v3, :cond_4c

    const/4 v1, 0x2

    if-eq v0, v1, :cond_44

    const/4 v1, 0x5

    if-eq v0, v1, :cond_38

    const/4 v1, 0x6

    if-eq v0, v1, :cond_34

    const/4 v1, 0x7

    if-eq v0, v1, :cond_2c

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mRefreshListener:Lcn/damai/commonbusiness/base/ResponseErrorPage$ErrorRefreshListener;

    if-eqz v0, :cond_7a

    .line 3
    invoke-interface {v0, v4}, Lcn/damai/commonbusiness/base/ResponseErrorPage$ErrorRefreshListener;->handleError(I)V

    goto :goto_7a

    .line 4
    :cond_2c
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mRefreshListener:Lcn/damai/commonbusiness/base/ResponseErrorPage$ErrorRefreshListener;

    if-eqz v0, :cond_7a

    .line 5
    invoke-interface {v0, v4}, Lcn/damai/commonbusiness/base/ResponseErrorPage$ErrorRefreshListener;->handleError(I)V

    goto :goto_7a

    .line 6
    :cond_34
    invoke-direct {p0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->exitCurrentPage()V

    goto :goto_7a

    .line 7
    :cond_38
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mRefreshListener:Lcn/damai/commonbusiness/base/ResponseErrorPage$ErrorRefreshListener;

    if-eqz v0, :cond_40

    .line 8
    invoke-interface {v0, v4}, Lcn/damai/commonbusiness/base/ResponseErrorPage$ErrorRefreshListener;->handleError(I)V

    goto :goto_7a

    .line 9
    :cond_40
    invoke-direct {p0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->exitCurrentPage()V

    goto :goto_7a

    .line 10
    :cond_44
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mRefreshListener:Lcn/damai/commonbusiness/base/ResponseErrorPage$ErrorRefreshListener;

    if-eqz v0, :cond_7a

    .line 11
    invoke-interface {v0, v4}, Lcn/damai/commonbusiness/base/ResponseErrorPage$ErrorRefreshListener;->handleError(I)V

    goto :goto_7a

    .line 12
    :cond_4c
    iget-boolean v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->isOperation:Z

    if-eqz v0, :cond_73

    .line 13
    :try_start_50
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.DIAL"

    const-string v2, "tel:10103721"

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 14
    iget-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    invoke-virtual {v1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_62
    .catch Ljava/lang/Exception; {:try_start_50 .. :try_end_62} :catch_63

    goto :goto_7a

    :catch_63
    move-exception v0

    .line 15
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 16
    invoke-static {}, Lcn/damai/common/util/ToastUtil;->a()Lcn/damai/common/util/ToastUtil;

    move-result-object v0

    iget-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    const-string v2, "\u65e0\u6cd5\u62e8\u53f7\uff0c\u8bf7\u624b\u52a8\u62e8\u625310103721"

    invoke-virtual {v0, v1, v2}, Lcn/damai/common/util/ToastUtil;->j(Landroid/content/Context;Ljava/lang/String;)V

    goto :goto_7a

    .line 17
    :cond_73
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mRefreshListener:Lcn/damai/commonbusiness/base/ResponseErrorPage$ErrorRefreshListener;

    if-eqz v0, :cond_7a

    .line 18
    invoke-interface {v0, v4}, Lcn/damai/commonbusiness/base/ResponseErrorPage$ErrorRefreshListener;->handleError(I)V

    :cond_7a
    :goto_7a
    return-void
.end method

.method private reportListener(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "23"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x2

    if-eqz v2, :cond_17

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const-string v1, "name"

    const-string v2, "90"

    .line 2
    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 3
    iget-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorMsg:Ljava/lang/String;

    if-eqz v1, :cond_2c

    const-string v2, "descInfo"

    .line 4
    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 5
    :cond_2c
    iget-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mExtraBuilder:Ljava/lang/StringBuilder;

    if-eqz v1, :cond_35

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_37

    :cond_35
    const-string v1, ""

    .line 6
    :goto_37
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_42

    const-string v2, "extra"

    .line 7
    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 8
    :cond_42
    iget-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    if-eqz v1, :cond_70

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    iget-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    .line 10
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_70

    const-string v2, "fromPage"

    .line 11
    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "\\."

    .line 12
    invoke-virtual {v1, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_70

    .line 13
    array-length v2, v1

    if-le v2, v3, :cond_70

    .line 14
    aget-object v1, v1, v3

    const-string v2, "module"

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_70
    const-string v1, "screenView"

    .line 15
    invoke-virtual {v0, v1, p1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 16
    invoke-static {}, Lcn/damai/common/user/c;->d()Lcn/damai/common/user/c;

    move-result-object p1

    invoke-static {}, Ltb/a50;->i()Ltb/a50;

    move-result-object v1

    .line 17
    invoke-static {}, Ltb/ty0;->E()Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorMsg:Ljava/lang/String;

    .line 18
    invoke-virtual {v1, v2, v3}, Ltb/a50;->o(Ljava/lang/String;Ljava/lang/String;)Lcn/damai/common/user/a$b;

    move-result-object v1

    invoke-virtual {p1, v1}, Lcn/damai/common/user/c;->r(Lcn/damai/common/user/a$b;)V

    .line 19
    sget-object p1, Ltb/yd3;->INSTANCE:Ltb/yd3;

    iget-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    const-string v2, "feed_back_report"

    invoke-static {v2}, Lcom/alibaba/pictures/picturesbiz/NavUri;->c(Ljava/lang/String;)Lcom/alibaba/pictures/picturesbiz/NavUri;

    move-result-object v2

    invoke-virtual {v2}, Lcom/alibaba/pictures/picturesbiz/NavUri;->a()Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {p1, v1, v2, v0}, Ltb/yd3;->handleUri(Landroid/content/Context;Landroid/net/Uri;Landroid/os/Bundle;)Z

    return-void
.end method


# virtual methods
.method public askPermission()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "22"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    :try_start_14
    sget-object v0, Ltb/b74;->STORAGE:[Ljava/lang/String;

    invoke-static {v0}, Ltb/w64;->k([Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_24

    .line 2
    invoke-direct {p0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->getScreenImage()Ljava/lang/String;

    move-result-object v0

    .line 3
    invoke-direct {p0, v0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->reportListener(Ljava/lang/String;)V

    goto :goto_2e

    :cond_24
    const-string v0, ""

    .line 4
    invoke-direct {p0, v0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->reportListener(Ljava/lang/String;)V
    :try_end_29
    .catch Ljava/lang/Exception; {:try_start_14 .. :try_end_29} :catch_2a

    goto :goto_2e

    :catch_2a
    move-exception v0

    .line 5
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :goto_2e
    return-void
.end method

.method public getRefreshBtn()Landroid/view/View;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnRefresh:Landroid/widget/TextView;

    return-object v0
.end method

.method public getReportBtn()Landroid/view/View;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnReport:Landroid/widget/TextView;

    return-object v0
.end method

.method public hideReportBtn()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "8"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnReport:Landroid/widget/TextView;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    return-void
.end method

.method public hideTitle()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "29"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mRootView:Landroid/view/View;

    sget v1, Lcn/damai/commonbusiness/R$id;->layout_header_view:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/16 v1, 0x8

    .line 2
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method

.method public loadErrorMsg(Ljava/lang/String;Ljava/lang/String;)V
    .registers 8

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "17"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz v2, :cond_1a

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v4

    const/4 v4, 0x1

    aput-object p1, v2, v4

    aput-object p2, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1a
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorContent:Landroid/widget/TextView;

    if-eqz v0, :cond_76

    .line 2
    iget v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorType:I

    if-ne v1, v3, :cond_28

    .line 3
    iget-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->defaultErrorMsg:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_76

    :cond_28
    const/4 v0, 0x5

    if-ne v1, v0, :cond_3f

    .line 4
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_39

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorContent:Landroid/widget/TextView;

    iget-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->defaultErrorMsg:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_76

    .line 6
    :cond_39
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorContent:Landroid/widget/TextView;

    invoke-virtual {v0, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_76

    .line 7
    :cond_3f
    invoke-static {p2}, Ltb/mw5;->j(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_6f

    const-string v0, "ANDROID_SYS_NO_NETWORK"

    .line 8
    invoke-static {p1, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_55

    const-string v0, "1002"

    .line 9
    invoke-static {p1, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_57

    :cond_55
    const-string p2, "\u62b1\u6b49\uff0c\u7f51\u7edc\u4e0d\u592a\u987a\u7545\u54e6\uff0c\u8bf7\u7a0d\u540e\u518d\u8bd5\u5427"

    .line 10
    :cond_57
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v0

    const/16 v1, 0x64

    if-gt v0, v1, :cond_65

    .line 11
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorContent:Landroid/widget/TextView;

    invoke-virtual {v0, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_76

    .line 12
    :cond_65
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorContent:Landroid/widget/TextView;

    invoke-virtual {p2, v4, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_76

    .line 13
    :cond_6f
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorContent:Landroid/widget/TextView;

    iget-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->defaultErrorMsg:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 14
    :cond_76
    :goto_76
    invoke-direct {p0, p1, p2}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->isOperation(Ljava/lang/String;Ljava/lang/String;)Z

    move-result p1

    iput-boolean p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->isOperation:Z

    return-void
.end method

.method public onClick(Landroid/view/View;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "21"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result p1

    .line 2
    sget v0, Lcn/damai/commonbusiness/R$id;->base_header_left:I

    if-ne p1, v0, :cond_23

    .line 3
    invoke-direct {p0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->exitCurrentPage()V

    goto :goto_57

    .line 4
    :cond_23
    sget v0, Lcn/damai/commonbusiness/R$id;->tv_report:I

    if-ne p1, v0, :cond_42

    .line 5
    sget-object p1, Ltb/nw2;->INSTANCE:Ltb/nw2;

    invoke-virtual {p1}, Ltb/nw2;->isLogin()Z

    move-result v0

    if-nez v0, :cond_36

    .line 6
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Ltb/nw2;->doLoginWithCustomPage(Ljava/lang/Object;Landroid/content/Intent;)V

    return-void

    .line 7
    :cond_36
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    if-eqz p1, :cond_57

    instance-of p1, p1, Landroid/app/Activity;

    if-eqz p1, :cond_57

    .line 8
    invoke-virtual {p0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->askPermission()V

    goto :goto_57

    .line 9
    :cond_42
    sget v0, Lcn/damai/commonbusiness/R$id;->btn_refresh:I

    if-ne p1, v0, :cond_4a

    .line 10
    invoke-direct {p0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->refreshListener()V

    goto :goto_57

    .line 11
    :cond_4a
    sget v0, Lcn/damai/commonbusiness/R$id;->btn_other:I

    if-ne p1, v0, :cond_57

    .line 12
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mRefreshListener:Lcn/damai/commonbusiness/base/ResponseErrorPage$ErrorRefreshListener;

    if-eqz p1, :cond_57

    const/16 v0, 0xa

    .line 13
    invoke-interface {p1, v0}, Lcn/damai/commonbusiness/base/ResponseErrorPage$ErrorRefreshListener;->handleError(I)V

    :cond_57
    :goto_57
    return-void
.end method

.method public setContainerBackground(I)V
    .registers 6
    .param p1    # I
        .annotation build Landroidx/annotation/ColorInt;
        .end annotation
    .end param

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorPageContainer:Landroid/widget/LinearLayout;

    if-eqz v0, :cond_22

    .line 2
    invoke-virtual {v0, p1}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    :cond_22
    return-void
.end method

.method public setErrorImageSize(II)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "12"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_22

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_22
    iget-boolean v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->isPioneer:Z

    if-eqz v0, :cond_2e

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mContext:Landroid/content/Context;

    iget-object p2, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorImage:Landroid/widget/ImageView;

    invoke-static {p1, p2}, Ltb/sd4;->d(Landroid/content/Context;Landroid/widget/ImageView;)V

    return-void

    .line 3
    :cond_2e
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorImage:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout$LayoutParams;

    .line 4
    iput p1, v0, Landroid/widget/LinearLayout$LayoutParams;->width:I

    .line 5
    iput p2, v0, Landroid/widget/LinearLayout$LayoutParams;->height:I

    .line 6
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorImage:Landroid/widget/ImageView;

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public setLeftBtnVisibility(I)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mLeftBtn:Landroid/view/View;

    invoke-virtual {v0, p1}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method

.method public setRefreshListener(Lcn/damai/commonbusiness/base/ResponseErrorPage$ErrorRefreshListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "28"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mRefreshListener:Lcn/damai/commonbusiness/base/ResponseErrorPage$ErrorRefreshListener;

    return-void
.end method

.method public setRootViewBackground(I)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "34"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mRootView:Landroid/view/View;

    if-eqz v0, :cond_30

    sget v1, Lcn/damai/commonbusiness/R$id;->ll_error:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_30

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mRootView:Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/view/View;->setBackgroundColor(I)V

    :cond_30
    return-void
.end method

.method public setTitleContent(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "30"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_22

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mTvErrorTitle:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_22
    return-void
.end method

.method public updateBtnState(ZLjava/lang/String;)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "9"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1e

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnRefresh:Landroid/widget/TextView;

    if-eqz v0, :cond_38

    if-eqz p1, :cond_35

    .line 2
    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 3
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_2f

    .line 4
    iget-object p2, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->refreshContent:Ljava/lang/String;

    .line 5
    :cond_2f
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnRefresh:Landroid/widget/TextView;

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_38

    .line 6
    :cond_35
    invoke-direct {p0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->hideRefreshBtn()V

    :cond_38
    :goto_38
    return-void
.end method

.method public updateErrorPageGravity(II)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "31"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_22

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_22
    const/16 v0, 0x30

    if-ne p1, v0, :cond_35

    if-eqz p2, :cond_35

    .line 1
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorPageLayout:Landroid/widget/LinearLayout;

    const/16 v0, 0x31

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorPageLayout:Landroid/widget/LinearLayout;

    invoke-virtual {p1, v3, p2, v3, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    goto :goto_41

    .line 3
    :cond_35
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorPageLayout:Landroid/widget/LinearLayout;

    const/16 p2, 0x11

    invoke-virtual {p1, p2}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 4
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorPageLayout:Landroid/widget/LinearLayout;

    invoke-virtual {p1, v3, v3, v3, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    :goto_41
    return-void
.end method

.method public updateOtherBtnState(ZLjava/lang/String;)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "10"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1e

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnOther:Landroid/widget/TextView;

    if-eqz v0, :cond_3a

    if-eqz p1, :cond_35

    .line 2
    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 3
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_2f

    const-string p2, "\u8bb0\u5f55\u6211\u7684\u7cbe\u5f69\u73b0\u573a"

    .line 4
    :cond_2f
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnOther:Landroid/widget/TextView;

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_3a

    :cond_35
    const/16 p1, 0x8

    .line 5
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setVisibility(I)V

    :cond_3a
    :goto_3a
    return-void
.end method

.method public updateOtherBtnState(ZLjava/lang/String;Landroid/view/View$OnClickListener;IIZ)V
    .registers 11

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "11"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_36

    const/4 v2, 0x7

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    aput-object p3, v2, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x5

    invoke-static {p5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x6

    invoke-static {p6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 6
    :cond_36
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnOther:Landroid/widget/TextView;

    if-eqz v0, :cond_6d

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_6d

    const/16 v0, 0x8

    if-eqz p1, :cond_68

    .line 7
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnOther:Landroid/widget/TextView;

    invoke-virtual {p1, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 8
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnOther:Landroid/widget/TextView;

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 9
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnOther:Landroid/widget/TextView;

    invoke-virtual {p1, p3}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 10
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnOther:Landroid/widget/TextView;

    invoke-virtual {p1, p5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 11
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnOther:Landroid/widget/TextView;

    invoke-virtual {p1, p4}, Landroid/widget/TextView;->setBackgroundResource(I)V

    if-eqz p6, :cond_6d

    .line 12
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnRefresh:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setVisibility(I)V

    .line 13
    invoke-virtual {p0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->hideReportBtn()V

    goto :goto_6d

    .line 14
    :cond_68
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnOther:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setVisibility(I)V

    :cond_6d
    :goto_6d
    return-void
.end method

.method public updatePageGravity(II)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "32"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_22

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_22
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorPageLayout:Landroid/widget/LinearLayout;

    if-nez v0, :cond_27

    return-void

    .line 2
    :cond_27
    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x2

    .line 3
    iput v1, v0, Landroid/widget/LinearLayout$LayoutParams;->height:I

    .line 4
    iget-object v1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorPageLayout:Landroid/widget/LinearLayout;

    invoke-virtual {v1, v0}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v0, 0x30

    if-ne p1, v0, :cond_48

    if-eqz p2, :cond_48

    .line 5
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorPageLayout:Landroid/widget/LinearLayout;

    const/16 v0, 0x31

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 6
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorPageLayout:Landroid/widget/LinearLayout;

    invoke-virtual {p1, v3, p2, v3, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    goto :goto_54

    .line 7
    :cond_48
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorPageLayout:Landroid/widget/LinearLayout;

    const/16 p2, 0x11

    invoke-virtual {p1, p2}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 8
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorPageLayout:Landroid/widget/LinearLayout;

    invoke-virtual {p1, v3, v3, v3, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    :goto_54
    return-void
.end method

.method public updateRefreshBtn(ZLjava/lang/String;)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "13"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1e

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1e
    iget v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mErrorType:I

    const/4 v1, 0x5

    if-eq v0, v1, :cond_24

    return-void

    .line 2
    :cond_24
    iget-object v0, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnRefresh:Landroid/widget/TextView;

    if-eqz v0, :cond_3e

    if-eqz p1, :cond_3b

    .line 3
    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setVisibility(I)V

    .line 4
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_35

    .line 5
    iget-object p2, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->refreshContent:Ljava/lang/String;

    .line 6
    :cond_35
    iget-object p1, p0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->mBtnRefresh:Landroid/widget/TextView;

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_3e

    .line 7
    :cond_3b
    invoke-direct {p0}, Lcn/damai/commonbusiness/base/ResponseErrorPage;->hideRefreshBtn()V

    :cond_3e
    :goto_3e
    return-void
.end method

.method public updateReportBtn(ZLjava/lang/String;)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/base/ResponseErrorPage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "33"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1d

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1d
    return-void
.end method
