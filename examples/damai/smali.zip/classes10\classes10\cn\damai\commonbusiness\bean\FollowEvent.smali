.class public Lcn/damai/commonbusiness/bean/FollowEvent;
.super Ljava/lang/Object;
.source "Taobao"


# static fields
.field public static final LIVE_FOLLOW_EVENT:Ljava/lang/String; = "live_follow_event"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
