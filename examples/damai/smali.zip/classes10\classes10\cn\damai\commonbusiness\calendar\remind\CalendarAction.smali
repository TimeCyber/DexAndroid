.class public Lcn/damai/commonbusiness/calendar/remind/CalendarAction;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field public beginTime:J

.field public description:Ljava/lang/String;

.field public endTime:J

.field public frequency:Ljava/lang/String;

.field public link:Ljava/lang/String;

.field public location:Ljava/lang/String;

.field public offset:I

.field public recurrenceTimes:I

.field public remind:I

.field public remindTitle:Ljava/lang/String;

.field public timeZone:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    .line 2
    iput v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->recurrenceTimes:I

    const-string v0, ""

    .line 3
    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->description:Ljava/lang/String;

    const-string v0, "NULL_FLAG"

    .line 4
    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->location:Ljava/lang/String;

    const-wide/16 v0, 0x0

    .line 5
    iput-wide v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->endTime:J

    const/4 v0, 0x0

    .line 6
    iput v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->offset:I

    const-string v0, "Asia/Shanghai"

    .line 7
    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->timeZone:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;J)V
    .registers 6

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    .line 9
    iput v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->recurrenceTimes:I

    const-string v0, ""

    .line 10
    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->description:Ljava/lang/String;

    const-string v0, "NULL_FLAG"

    .line 11
    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->location:Ljava/lang/String;

    const-wide/16 v0, 0x0

    .line 12
    iput-wide v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->endTime:J

    const/4 v0, 0x0

    .line 13
    iput v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->offset:I

    const-string v0, "Asia/Shanghai"

    .line 14
    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->timeZone:Ljava/lang/String;

    .line 15
    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->remindTitle:Ljava/lang/String;

    .line 16
    iput-wide p2, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->beginTime:J

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;JLjava/lang/String;)V
    .registers 7

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    .line 18
    iput v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->recurrenceTimes:I

    const-string v0, ""

    .line 19
    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->description:Ljava/lang/String;

    const-string v0, "NULL_FLAG"

    .line 20
    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->location:Ljava/lang/String;

    const-wide/16 v0, 0x0

    .line 21
    iput-wide v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->endTime:J

    const/4 v0, 0x0

    .line 22
    iput v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->offset:I

    const-string v0, "Asia/Shanghai"

    .line 23
    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->timeZone:Ljava/lang/String;

    .line 24
    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->remindTitle:Ljava/lang/String;

    .line 25
    iput-wide p2, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->beginTime:J

    .line 26
    iput-object p4, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->timeZone:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;JI)V
    .registers 11

    .line 27
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    .line 28
    iput v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->recurrenceTimes:I

    const-string v0, ""

    .line 29
    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->description:Ljava/lang/String;

    const-string v0, "NULL_FLAG"

    .line 30
    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->location:Ljava/lang/String;

    const-wide/16 v0, 0x0

    .line 31
    iput-wide v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->endTime:J

    const/4 v0, 0x0

    .line 32
    iput v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->offset:I

    const-string v0, "Asia/Shanghai"

    .line 33
    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->timeZone:Ljava/lang/String;

    .line 34
    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->remindTitle:Ljava/lang/String;

    .line 35
    iput-wide p2, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->beginTime:J

    .line 36
    iput-object p4, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->description:Ljava/lang/String;

    .line 37
    iput-object p5, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->location:Ljava/lang/String;

    .line 38
    iput-wide p6, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->endTime:J

    .line 39
    iput p8, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->offset:I

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;JILjava/lang/String;)V
    .registers 12

    .line 40
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    .line 41
    iput v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->recurrenceTimes:I

    const-string v0, ""

    .line 42
    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->description:Ljava/lang/String;

    const-string v0, "NULL_FLAG"

    .line 43
    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->location:Ljava/lang/String;

    const-wide/16 v0, 0x0

    .line 44
    iput-wide v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->endTime:J

    const/4 v0, 0x0

    .line 45
    iput v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->offset:I

    const-string v0, "Asia/Shanghai"

    .line 46
    iput-object v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->timeZone:Ljava/lang/String;

    .line 47
    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->remindTitle:Ljava/lang/String;

    .line 48
    iput-wide p2, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->beginTime:J

    .line 49
    iput-object p4, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->description:Ljava/lang/String;

    .line 50
    iput-object p5, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->location:Ljava/lang/String;

    .line 51
    iput-wide p6, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->endTime:J

    .line 52
    iput p8, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->offset:I

    .line 53
    iput-object p9, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->timeZone:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public genUniKey()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "23"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->remindTitle:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v1, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->beginTime:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 2
    invoke-static {v0}, Ltb/a13;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 3
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Calendar_"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getBeginTime()J
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    return-wide v0

    .line 1
    :cond_1b
    iget-wide v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->beginTime:J

    return-wide v0
.end method

.method public getDescription()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->description:Ljava/lang/String;

    return-object v0
.end method

.method public getEndTime()J
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "9"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    return-wide v0

    .line 1
    :cond_1b
    iget-wide v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->endTime:J

    return-wide v0
.end method

.method public getFrequency()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "19"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->frequency:Ljava/lang/String;

    return-object v0
.end method

.method public getLink()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "15"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->link:Ljava/lang/String;

    return-object v0
.end method

.method public getLocation()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "7"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->location:Ljava/lang/String;

    return-object v0
.end method

.method public getOffset()I
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "11"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->offset:I

    return v0
.end method

.method public getRecurrenceTimes()I
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "17"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->recurrenceTimes:I

    return v0
.end method

.method public getRemind()I
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "21"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->remind:I

    return v0
.end method

.method public getRemindTitle()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->remindTitle:Ljava/lang/String;

    return-object v0
.end method

.method public getTimeZone()Ljava/lang/String;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "13"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->timeZone:Ljava/lang/String;

    return-object v0
.end method

.method public setBeginTime(J)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iput-wide p1, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->beginTime:J

    return-void
.end method

.method public setDescription(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->description:Ljava/lang/String;

    return-void
.end method

.method public setEndTime(J)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "10"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iput-wide p1, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->endTime:J

    return-void
.end method

.method public setFrequency(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "20"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->frequency:Ljava/lang/String;

    return-void
.end method

.method public setLink(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "16"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->link:Ljava/lang/String;

    return-void
.end method

.method public setLocation(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "8"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->location:Ljava/lang/String;

    return-void
.end method

.method public setOffset(I)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "12"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iput p1, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->offset:I

    return-void
.end method

.method public setRecurrenceTimes(I)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "18"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iput p1, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->recurrenceTimes:I

    return-void
.end method

.method public setRemind(I)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "22"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iput p1, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->remind:I

    return-void
.end method

.method public setRemindTitle(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->remindTitle:Ljava/lang/String;

    return-void
.end method

.method public setTimeZone(Ljava/lang/String;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "14"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/calendar/remind/CalendarAction;->timeZone:Ljava/lang/String;

    return-void
.end method
