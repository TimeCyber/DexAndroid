.class public interface abstract Lcn/damai/commonbusiness/photoselect/photoview/OnViewTapListener;
.super Ljava/lang/Object;
.source "Taobao"


# virtual methods
.method public abstract onViewTap(Landroid/view/View;FF)V
.end method
