.class public Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
.super Landroid/widget/LinearLayout;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownEndListener;,
        Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$a;,
        Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon; = null

.field private static final UPDATE_UI_CODE:I = 0x65


# instance fields
.field private colon:Ljava/lang/String;

.field private context:Landroid/content/Context;

.field private countDownEndListener:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownEndListener;

.field private hourColonTv:Landroid/widget/TextView;

.field private hourTv:Landroid/widget/TextView;

.field private isContinue:Z

.field lastTime:J

.field private mExecutorService:Ljava/util/concurrent/ExecutorService;

.field private minuteColonTv:Landroid/widget/TextView;

.field private minuteTv:Landroid/widget/TextView;

.field private myHandler:Landroid/os/Handler;

.field private originalTime:J

.field private secondTv:Landroid/widget/TextView;

.field timeEnd:J

.field private volatile timeStamp:J


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, p1, v0}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 4
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, p1, p2, v0}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .line 3
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 p2, 0x0

    .line 4
    iput-boolean p2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->isContinue:Z

    const-string p2, ":"

    .line 5
    iput-object p2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->colon:Ljava/lang/String;

    .line 6
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object p2

    iput-object p2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->mExecutorService:Ljava/util/concurrent/ExecutorService;

    .line 7
    new-instance p2, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$a;

    invoke-direct {p2, p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$a;-><init>(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;)V

    iput-object p2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->myHandler:Landroid/os/Handler;

    const-wide/16 p2, 0x0

    .line 8
    iput-wide p2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->lastTime:J

    .line 9
    iput-wide p2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->timeEnd:J

    .line 10
    iput-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->context:Landroid/content/Context;

    .line 11
    invoke-direct {p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->init()V

    return-void
.end method

.method static synthetic access$000(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;)Z
    .registers 1

    .line 1
    iget-boolean p0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->isContinue:Z

    return p0
.end method

.method static synthetic access$002(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;Z)Z
    .registers 2

    .line 1
    iput-boolean p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->isContinue:Z

    return p1
.end method

.method static synthetic access$100(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;)J
    .registers 3

    .line 1
    iget-wide v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->timeStamp:J

    return-wide v0
.end method

.method static synthetic access$110(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;)J
    .registers 5

    .line 1
    iget-wide v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->timeStamp:J

    const-wide/16 v2, 0x1

    sub-long v2, v0, v2

    iput-wide v2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->timeStamp:J

    return-wide v0
.end method

.method static synthetic access$200(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;)Landroid/os/Handler;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->myHandler:Landroid/os/Handler;

    return-object p0
.end method

.method static synthetic access$300(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;)Landroid/widget/TextView;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$400(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;Ljava/lang/String;Landroid/widget/TextView;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->updateTvText(Ljava/lang/String;Landroid/widget/TextView;)V

    return-void
.end method

.method static synthetic access$500(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;)Landroid/widget/TextView;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$600(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;)Landroid/widget/TextView;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$700(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownEndListener;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->countDownEndListener:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownEndListener;

    return-object p0
.end method

.method private countDown()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "97"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$1;

    invoke-direct {v1, p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$1;-><init>(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 2
    iget-object v1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->mExecutorService:Ljava/util/concurrent/ExecutorService;

    if-eqz v1, :cond_28

    invoke-interface {v1}, Ljava/util/concurrent/ExecutorService;->isShutdown()Z

    move-result v1

    if-eqz v1, :cond_2e

    .line 3
    :cond_28
    invoke-static {}, Ljava/util/concurrent/Executors;->newCachedThreadPool()Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    iput-object v1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->mExecutorService:Ljava/util/concurrent/ExecutorService;

    .line 4
    :cond_2e
    iget-object v1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->mExecutorService:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v1, v0}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method private init()V
    .registers 8

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_14

    new-array v2, v4, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    invoke-virtual {p0, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v0, 0x10

    .line 2
    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 3
    new-instance v0, Landroid/widget/TextView;

    iget-object v1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->context:Landroid/content/Context;

    invoke-direct {v0, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    const-string v1, "#000000"

    .line 4
    invoke-direct {p0, v1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    const-string v2, "#DEDEDE"

    invoke-direct {p0, v2}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setBackgroundColor(I)V

    .line 6
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    const/high16 v3, 0x41400000    # 12.0f

    invoke-virtual {v0, v4, v3}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 7
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    const/16 v5, 0x11

    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setGravity(I)V

    .line 8
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 9
    new-instance v0, Landroid/widget/TextView;

    iget-object v6, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->context:Landroid/content/Context;

    invoke-direct {v0, v6}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourColonTv:Landroid/widget/TextView;

    .line 10
    invoke-direct {p0, v1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v0, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 11
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, v4, v3}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 12
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourColonTv:Landroid/widget/TextView;

    iget-object v6, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->colon:Ljava/lang/String;

    invoke-virtual {v0, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 13
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setGravity(I)V

    .line 14
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourColonTv:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 15
    new-instance v0, Landroid/widget/TextView;

    iget-object v6, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->context:Landroid/content/Context;

    invoke-direct {v0, v6}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    .line 16
    invoke-direct {p0, v1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v0, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 17
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-direct {p0, v2}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v0, v6}, Landroid/widget/TextView;->setBackgroundColor(I)V

    .line 18
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {v0, v4, v3}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 19
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setGravity(I)V

    .line 20
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 21
    new-instance v0, Landroid/widget/TextView;

    iget-object v6, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->context:Landroid/content/Context;

    invoke-direct {v0, v6}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteColonTv:Landroid/widget/TextView;

    .line 22
    invoke-direct {p0, v1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v0, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 23
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, v4, v3}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 24
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteColonTv:Landroid/widget/TextView;

    iget-object v6, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->colon:Ljava/lang/String;

    invoke-virtual {v0, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 25
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setGravity(I)V

    .line 26
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteColonTv:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 27
    new-instance v0, Landroid/widget/TextView;

    iget-object v6, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->context:Landroid/content/Context;

    invoke-direct {v0, v6}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    .line 28
    invoke-direct {p0, v1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 29
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-direct {p0, v2}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setBackgroundColor(I)V

    .line 30
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {v0, v4, v3}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 31
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setGravity(I)V

    .line 32
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void
.end method

.method private parseColor(Ljava/lang/String;)I
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "86"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    return p1

    .line 1
    :cond_1e
    :try_start_1e
    invoke-static {p1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3
    :try_end_22
    .catch Ljava/lang/Exception; {:try_start_1e .. :try_end_22} :catch_23

    goto :goto_2d

    :catch_23
    move-exception p1

    .line 2
    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    const-string v0, "DMDXCountDownView"

    invoke-static {v0, p1}, Ltb/av2;->b(Ljava/lang/String;Ljava/lang/String;)V

    :goto_2d
    return v3
.end method

.method private updateTvText(Ljava/lang/String;Landroid/widget/TextView;)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "98"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_1a
    if-nez p2, :cond_1d

    return-void

    .line 1
    :cond_1d
    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method


# virtual methods
.method public destoryCountDownView()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "96"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->mExecutorService:Ljava/util/concurrent/ExecutorService;

    if-eqz v0, :cond_1b

    .line 2
    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;

    .line 3
    :cond_1b
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->myHandler:Landroid/os/Handler;

    if-eqz v0, :cond_25

    const/4 v1, 0x0

    .line 4
    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 5
    iput-object v1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->myHandler:Landroid/os/Handler;

    :cond_25
    return-void
.end method

.method protected dispatchVisibilityChanged(Landroid/view/View;I)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "100"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1e
    invoke-super {p0, p1, p2}, Landroid/widget/LinearLayout;->dispatchVisibilityChanged(Landroid/view/View;I)V

    const/4 p1, 0x4

    const-string v0, "DMDXCountDownView"

    if-ne p2, p1, :cond_39

    .line 2
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide p1

    iput-wide p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->lastTime:J

    .line 3
    iget-wide p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->timeStamp:J

    iput-wide p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->timeEnd:J

    const-string p1, "onVisibilityChanged INVISIBLE"

    .line 4
    invoke-static {v0, p1}, Ltb/av2;->c(Ljava/lang/String;Ljava/lang/String;)V

    .line 5
    invoke-virtual {p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->pauseCountDown()Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    goto :goto_5f

    .line 6
    :cond_39
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide p1

    iget-wide v1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->lastTime:J

    sub-long/2addr p1, v1

    .line 7
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "onVisibilityChanged VISIBLE"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-wide/16 v2, 0x3e8

    div-long/2addr p1, v2

    invoke-virtual {v1, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Ltb/av2;->c(Ljava/lang/String;Ljava/lang/String;)V

    .line 8
    iget-wide v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->timeEnd:J

    sub-long/2addr v0, p1

    iput-wide v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->timeStamp:J

    .line 9
    invoke-virtual {p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->startCountDown()Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    :goto_5f
    return-void
.end method

.method public getCountTime()J
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "92"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    return-wide v0

    .line 1
    :cond_1b
    iget-wide v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->originalTime:J

    return-wide v0
.end method

.method public pauseCountDown()Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "94"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object v0

    .line 1
    :cond_17
    iput-boolean v3, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->isContinue:Z

    return-object p0
.end method

.method public setColonTvBackground(Landroid/graphics/drawable/Drawable;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "20"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    :cond_1a
    if-eqz p1, :cond_2c

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x10

    if-lt v0, v1, :cond_2c

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_2c
    return-object p0
.end method

.method public setColonTvBackgroundColorHex(Ljava/lang/String;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "18"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1a
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result p1

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundColor(I)V

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundColor(I)V

    return-object p0
.end method

.method public setColonTvBackgroundRes(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "19"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundResource(I)V

    return-object p0
.end method

.method public setColonTvGravity(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "21"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1a
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_BOTTOM:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    const/16 v1, 0x11

    if-ne p1, v0, :cond_23

    const/16 v1, 0x50

    goto :goto_3e

    .line 2
    :cond_23
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_CENTER:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_28

    goto :goto_3e

    .line 3
    :cond_28
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_LEFT:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_30

    const v1, 0x800003

    goto :goto_3e

    .line 4
    :cond_30
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_RIGHT:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_38

    const v1, 0x800005

    goto :goto_3e

    .line 5
    :cond_38
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_TOP:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_3e

    const/16 v1, 0x30

    .line 6
    :cond_3e
    :goto_3e
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourColonTv:Landroid/widget/TextView;

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setGravity(I)V

    .line 7
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteColonTv:Landroid/widget/TextView;

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setGravity(I)V

    return-object p0
.end method

.method public setColonTvSize(F)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "16"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, v3, p1}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, v3, p1}, Landroid/widget/TextView;->setTextSize(IF)V

    return-object p0
.end method

.method public setColonTvTextColorHex(Ljava/lang/String;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "17"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1a
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result p1

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    return-object p0
.end method

.method public setColonTvWH(II)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "15"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_25

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_25
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v0, p1, p2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourColonTv:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteColonTv:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-object p0
.end method

.method public setCountDownEndListener(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownEndListener;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "99"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->countDownEndListener:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownEndListener;

    return-void
.end method

.method public setCountTime(J)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "91"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1e
    iput-wide p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->timeStamp:J

    .line 2
    iput-wide p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->originalTime:J

    return-object p0
.end method

.method public setHourColonTvBackground(Landroid/graphics/drawable/Drawable;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "66"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    :cond_1a
    if-eqz p1, :cond_27

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x10

    if-lt v0, v1, :cond_27

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_27
    return-object p0
.end method

.method public setHourColonTvBackgroundColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "68"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 3
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundColor(I)V

    return-object p0
.end method

.method public setHourColonTvBackgroundColor(Ljava/lang/String;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "67"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1a
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result p1

    .line 2
    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->setHourColonTvBackgroundColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    move-result-object p1

    return-object p1
.end method

.method public setHourColonTvBackgroundRes(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "65"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundResource(I)V

    return-object p0
.end method

.method public setHourColonTvBold(Z)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "76"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourColonTv:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/text/TextPaint;->setFakeBoldText(Z)V

    return-object p0
.end method

.method public setHourColonTvGravity(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "73"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1a
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_BOTTOM:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    const/16 v1, 0x11

    if-ne p1, v0, :cond_23

    const/16 v1, 0x50

    goto :goto_3e

    .line 2
    :cond_23
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_CENTER:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_28

    goto :goto_3e

    .line 3
    :cond_28
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_LEFT:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_30

    const v1, 0x800003

    goto :goto_3e

    .line 4
    :cond_30
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_RIGHT:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_38

    const v1, 0x800005

    goto :goto_3e

    .line 5
    :cond_38
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_TOP:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_3e

    const/16 v1, 0x30

    .line 6
    :cond_3e
    :goto_3e
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourColonTv:Landroid/widget/TextView;

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setGravity(I)V

    return-object p0
.end method

.method public setHourColonTvMargins(IIII)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "75"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_33

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_33
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x2

    invoke-direct {v0, v1, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 2
    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourColonTv:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-object p0
.end method

.method public setHourColonTvPadding(IIII)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "74"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_33

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_33
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/widget/TextView;->setPadding(IIII)V

    return-object p0
.end method

.method public setHourColonTvSize(II)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "64"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_25

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_25
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourColonTv:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    if-eqz v0, :cond_3a

    if-lez p1, :cond_31

    .line 2
    iput p1, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    :cond_31
    if-lez p2, :cond_35

    .line 3
    iput p2, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 4
    :cond_35
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourColonTv:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_3a
    return-object p0
.end method

.method public setHourColonTvText(Ljava/lang/String;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "69"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1a
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-object p0
.end method

.method public setHourColonTvTextColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "72"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 3
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    return-object p0
.end method

.method public setHourColonTvTextColor(Ljava/lang/String;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "71"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1a
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result p1

    .line 2
    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->setHourColonTvTextColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    move-result-object p1

    return-object p1
.end method

.method public setHourColonTvTextSize(F)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "70"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, v3, p1}, Landroid/widget/TextView;->setTextSize(IF)V

    return-object p0
.end method

.method public setHourTvBackground(Landroid/graphics/drawable/Drawable;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "24"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    :cond_1a
    if-eqz p1, :cond_2d

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x10

    if-lt v0, v1, :cond_28

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_2d

    .line 3
    :cond_28
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_2d
    :goto_2d
    return-object p0
.end method

.method public setHourTvBackgroundColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "26"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 3
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundColor(I)V

    return-object p0
.end method

.method public setHourTvBackgroundColor(Ljava/lang/String;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "25"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1a
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result p1

    .line 2
    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->setHourTvBackgroundColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    move-result-object p1

    return-object p1
.end method

.method public setHourTvBackgroundColorWithRadius(II)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "28"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_25

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    :cond_25
    if-nez p2, :cond_2c

    .line 3
    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->setHourTvBackgroundColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    move-result-object p1

    return-object p1

    .line 4
    :cond_2c
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    int-to-float p2, p2

    .line 5
    invoke-virtual {v0, p2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 6
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 7
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 p2, 0x10

    if-lt p1, p2, :cond_44

    .line 8
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_49

    .line 9
    :cond_44
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    :goto_49
    return-object p0
.end method

.method public setHourTvBackgroundColorWithRadius(Ljava/lang/String;I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "27"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_21

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_21
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result p1

    .line 2
    invoke-virtual {p0, p1, p2}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->setHourTvBackgroundColorWithRadius(II)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    move-result-object p1

    return-object p1
.end method

.method public setHourTvBackgroundRes(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "23"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundResource(I)V

    return-object p0
.end method

.method public setHourTvBold(Z)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "35"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/text/TextPaint;->setFakeBoldText(Z)V

    return-object p0
.end method

.method public setHourTvGravity(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "32"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1a
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_BOTTOM:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    const/16 v1, 0x11

    if-ne p1, v0, :cond_23

    const/16 v1, 0x50

    goto :goto_3e

    .line 2
    :cond_23
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_CENTER:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_28

    goto :goto_3e

    .line 3
    :cond_28
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_LEFT:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_30

    const v1, 0x800003

    goto :goto_3e

    .line 4
    :cond_30
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_RIGHT:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_38

    const v1, 0x800005

    goto :goto_3e

    .line 5
    :cond_38
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_TOP:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_3e

    const/16 v1, 0x30

    .line 6
    :cond_3e
    :goto_3e
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setGravity(I)V

    return-object p0
.end method

.method public setHourTvMargins(IIII)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "34"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_33

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_33
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x2

    invoke-direct {v0, v1, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 2
    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-object p0
.end method

.method public setHourTvPadding(IIII)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "33"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_33

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_33
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/widget/TextView;->setPadding(IIII)V

    return-object p0
.end method

.method public setHourTvSize(II)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "22"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_25

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_25
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    if-eqz v0, :cond_3a

    if-lez p1, :cond_31

    .line 2
    iput p1, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    :cond_31
    if-lez p2, :cond_35

    .line 3
    iput p2, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 4
    :cond_35
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_3a
    return-object p0
.end method

.method public setHourTvTextColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "31"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 3
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    return-object p0
.end method

.method public setHourTvTextColor(Ljava/lang/String;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "30"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1a
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result p1

    .line 2
    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->setHourTvTextColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    move-result-object p1

    return-object p1
.end method

.method public setHourTvTextSize(F)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "29"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-virtual {v0, v3, p1}, Landroid/widget/TextView;->setTextSize(IF)V

    return-object p0
.end method

.method public setMinuteColonTvBackground(Landroid/graphics/drawable/Drawable;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "79"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    :cond_1a
    if-eqz p1, :cond_27

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x10

    if-lt v0, v1, :cond_27

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_27
    return-object p0
.end method

.method public setMinuteColonTvBackgroundColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "81"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 3
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundColor(I)V

    return-object p0
.end method

.method public setMinuteColonTvBackgroundColor(Ljava/lang/String;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "80"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1a
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result p1

    .line 2
    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->setMinuteColonTvBackgroundColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    move-result-object p1

    return-object p1
.end method

.method public setMinuteColonTvBackgroundRes(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "78"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundResource(I)V

    return-object p0
.end method

.method public setMinuteColonTvBold(Z)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "90"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteColonTv:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/text/TextPaint;->setFakeBoldText(Z)V

    return-object p0
.end method

.method public setMinuteColonTvGravity(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "87"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1a
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_BOTTOM:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    const/16 v1, 0x11

    if-ne p1, v0, :cond_23

    const/16 v1, 0x50

    goto :goto_3e

    .line 2
    :cond_23
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_CENTER:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_28

    goto :goto_3e

    .line 3
    :cond_28
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_LEFT:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_30

    const v1, 0x800003

    goto :goto_3e

    .line 4
    :cond_30
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_RIGHT:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_38

    const v1, 0x800005

    goto :goto_3e

    .line 5
    :cond_38
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_TOP:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_3e

    const/16 v1, 0x30

    .line 6
    :cond_3e
    :goto_3e
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteColonTv:Landroid/widget/TextView;

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setGravity(I)V

    return-object p0
.end method

.method public setMinuteColonTvMargins(IIII)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "89"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_33

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_33
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x2

    invoke-direct {v0, v1, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 2
    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteColonTv:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-object p0
.end method

.method public setMinuteColonTvPadding(IIII)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "88"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_33

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_33
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/widget/TextView;->setPadding(IIII)V

    return-object p0
.end method

.method public setMinuteColonTvSize(II)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "77"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_25

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_25
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteColonTv:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    if-eqz v0, :cond_3a

    if-lez p1, :cond_31

    .line 2
    iput p1, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    :cond_31
    if-lez p2, :cond_35

    .line 3
    iput p2, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 4
    :cond_35
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteColonTv:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_3a
    return-object p0
.end method

.method public setMinuteColonTvText(Ljava/lang/String;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "82"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1a
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-object p0
.end method

.method public setMinuteColonTvTextColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "85"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 3
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    return-object p0
.end method

.method public setMinuteColonTvTextColor(Ljava/lang/String;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "84"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1a
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result p1

    .line 2
    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->setMinuteColonTvTextColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    move-result-object p1

    return-object p1
.end method

.method public setMinuteColonTvTextSize(F)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "83"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteColonTv:Landroid/widget/TextView;

    invoke-virtual {v0, v3, p1}, Landroid/widget/TextView;->setTextSize(IF)V

    return-object p0
.end method

.method public setMinuteTvBackground(Landroid/graphics/drawable/Drawable;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "38"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    :cond_1a
    if-eqz p1, :cond_27

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x10

    if-lt v0, v1, :cond_27

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_27
    return-object p0
.end method

.method public setMinuteTvBackgroundColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "40"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 3
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundColor(I)V

    return-object p0
.end method

.method public setMinuteTvBackgroundColor(Ljava/lang/String;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "39"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1a
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result p1

    .line 2
    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->setMinuteTvBackgroundColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    move-result-object p1

    return-object p1
.end method

.method public setMinuteTvBackgroundColorWidthRadius(II)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "42"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_25

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    :cond_25
    if-nez p2, :cond_2c

    .line 4
    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->setMinuteTvBackgroundColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    move-result-object p1

    return-object p1

    .line 5
    :cond_2c
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    int-to-float p2, p2

    .line 6
    invoke-virtual {v0, p2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 7
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 8
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 p2, 0x10

    if-lt p1, p2, :cond_44

    .line 9
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_49

    .line 10
    :cond_44
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    :goto_49
    return-object p0
.end method

.method public setMinuteTvBackgroundColorWidthRadius(Ljava/lang/String;I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "41"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_21

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    :cond_21
    if-nez p2, :cond_28

    .line 1
    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->setMinuteTvBackgroundColor(Ljava/lang/String;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    move-result-object p1

    return-object p1

    .line 2
    :cond_28
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result p1

    .line 3
    invoke-virtual {p0, p1, p2}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->setMinuteTvBackgroundColorWidthRadius(II)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    move-result-object p1

    return-object p1
.end method

.method public setMinuteTvBackgroundRes(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "37"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundResource(I)V

    return-object p0
.end method

.method public setMinuteTvBold(Z)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "49"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/text/TextPaint;->setFakeBoldText(Z)V

    return-object p0
.end method

.method public setMinuteTvGravity(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "46"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1a
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_BOTTOM:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    const/16 v1, 0x11

    if-ne p1, v0, :cond_23

    const/16 v1, 0x50

    goto :goto_3e

    .line 2
    :cond_23
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_CENTER:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_28

    goto :goto_3e

    .line 3
    :cond_28
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_LEFT:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_30

    const v1, 0x800003

    goto :goto_3e

    .line 4
    :cond_30
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_RIGHT:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_38

    const v1, 0x800005

    goto :goto_3e

    .line 5
    :cond_38
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_TOP:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_3e

    const/16 v1, 0x30

    .line 6
    :cond_3e
    :goto_3e
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setGravity(I)V

    return-object p0
.end method

.method public setMinuteTvMargins(IIII)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "48"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_33

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_33
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x2

    invoke-direct {v0, v1, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 2
    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-object p0
.end method

.method public setMinuteTvPadding(IIII)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "47"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_33

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_33
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/widget/TextView;->setPadding(IIII)V

    return-object p0
.end method

.method public setMinuteTvSize(II)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "36"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_25

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_25
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    if-eqz v0, :cond_3a

    if-lez p1, :cond_31

    .line 2
    iput p1, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    :cond_31
    if-lez p2, :cond_35

    .line 3
    iput p2, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 4
    :cond_35
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_3a
    return-object p0
.end method

.method public setMinuteTvTextColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "45"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 3
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    return-object p0
.end method

.method public setMinuteTvTextColor(Ljava/lang/String;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "44"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1a
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result p1

    .line 2
    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->setMinuteTvTextColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    move-result-object p1

    return-object p1
.end method

.method public setMinuteTvTextSize(F)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "43"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {v0, v3, p1}, Landroid/widget/TextView;->setTextSize(IF)V

    return-object p0
.end method

.method public setSecondTvBackground(Landroid/graphics/drawable/Drawable;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "52"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    :cond_1a
    if-eqz p1, :cond_27

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x10

    if-lt v0, v1, :cond_27

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_27
    return-object p0
.end method

.method public setSecondTvBackgroundColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "54"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 3
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundColor(I)V

    return-object p0
.end method

.method public setSecondTvBackgroundColor(Ljava/lang/String;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "53"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1a
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result p1

    .line 2
    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->setSecondTvBackgroundColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    move-result-object p1

    return-object p1
.end method

.method public setSecondTvBackgroundColorWidthRadius(II)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "56"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_25

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    :cond_25
    if-nez p2, :cond_2c

    .line 3
    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->setSecondTvBackgroundColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    move-result-object p1

    return-object p1

    .line 4
    :cond_2c
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    int-to-float p2, p2

    .line 5
    invoke-virtual {v0, p2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 6
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 7
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 p2, 0x10

    if-lt p1, p2, :cond_44

    .line 8
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_49

    .line 9
    :cond_44
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    :goto_49
    return-object p0
.end method

.method public setSecondTvBackgroundColorWidthRadius(Ljava/lang/String;I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "55"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_21

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_21
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result p1

    .line 2
    invoke-virtual {p0, p1, p2}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->setSecondTvBackgroundColorWidthRadius(II)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    move-result-object p1

    return-object p1
.end method

.method public setSecondTvBackgroundRes(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "51"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundResource(I)V

    return-object p0
.end method

.method public setSecondTvBold(Z)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "63"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/text/TextPaint;->setFakeBoldText(Z)V

    return-object p0
.end method

.method public setSecondTvGravity(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "60"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1a
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_BOTTOM:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    const/16 v1, 0x11

    if-ne p1, v0, :cond_23

    const/16 v1, 0x50

    goto :goto_3e

    .line 2
    :cond_23
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_CENTER:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_28

    goto :goto_3e

    .line 3
    :cond_28
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_LEFT:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_30

    const v1, 0x800003

    goto :goto_3e

    .line 4
    :cond_30
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_RIGHT:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_38

    const v1, 0x800005

    goto :goto_3e

    .line 5
    :cond_38
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_TOP:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_3e

    const/16 v1, 0x30

    .line 6
    :cond_3e
    :goto_3e
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setGravity(I)V

    return-object p0
.end method

.method public setSecondTvMargins(IIII)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "62"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_33

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_33
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x2

    invoke-direct {v0, v1, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 2
    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-object p0
.end method

.method public setSecondTvPadding(IIII)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "61"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_33

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_33
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/widget/TextView;->setPadding(IIII)V

    return-object p0
.end method

.method public setSecondTvSize(II)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "50"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_25

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_25
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    if-eqz v0, :cond_3a

    if-lez p1, :cond_31

    .line 2
    iput p1, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    :cond_31
    if-lez p2, :cond_35

    .line 3
    iput p2, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 4
    :cond_35
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_3a
    return-object p0
.end method

.method public setSecondTvTextColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "59"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 3
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    return-object p0
.end method

.method public setSecondTvTextColor(Ljava/lang/String;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "58"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1a
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result p1

    .line 2
    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->setSecondTvTextColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    move-result-object p1

    return-object p1
.end method

.method public setSecondTvTextSize(F)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "57"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {v0, v3, p1}, Landroid/widget/TextView;->setTextSize(IF)V

    return-object p0
.end method

.method public setTimeTvBackground(Landroid/graphics/drawable/Drawable;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "13"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    :cond_1a
    if-eqz p1, :cond_41

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x10

    if-lt v0, v1, :cond_32

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_41

    .line 5
    :cond_32
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 6
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 7
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_41
    :goto_41
    return-object p0
.end method

.method public setTimeTvBackgroundColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "10"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 3
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundColor(I)V

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundColor(I)V

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundColor(I)V

    return-object p0
.end method

.method public setTimeTvBackgroundColor(Ljava/lang/String;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "8"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1a
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result p1

    .line 2
    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->setTimeTvBackgroundColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    move-result-object p1

    return-object p1
.end method

.method public setTimeTvBackgroundColorWidthRadius(II)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "11"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_25

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    :cond_25
    if-nez p2, :cond_2c

    .line 3
    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->setTimeTvBackgroundColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    move-result-object p1

    return-object p1

    .line 4
    :cond_2c
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    int-to-float p2, p2

    .line 5
    invoke-virtual {v0, p2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 6
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 7
    invoke-virtual {p0, v0}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->setTimeTvBackground(Landroid/graphics/drawable/Drawable;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    move-result-object p1

    return-object p1
.end method

.method public setTimeTvBackgroundColorWidthRadius(Ljava/lang/String;I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "9"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_21

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_21
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result p1

    .line 2
    invoke-virtual {p0, p1, p2}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->setTimeTvBackgroundColorWidthRadius(II)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    move-result-object p1

    return-object p1
.end method

.method public setTimeTvBackgroundRes(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "12"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackgroundResource(I)V

    return-object p0
.end method

.method public setTimeTvFontName(Ljava/lang/String;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1a
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_53

    const-string v0, "Alibaba-PuHuiTi-Heavy.otf"

    .line 2
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_44

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-virtual {p1}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    move-result-object p1

    invoke-virtual {p1, v3}, Landroid/text/TextPaint;->setFakeBoldText(Z)V

    .line 4
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {p1}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    move-result-object p1

    invoke-virtual {p1, v3}, Landroid/text/TextPaint;->setFakeBoldText(Z)V

    .line 5
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {p1}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    move-result-object p1

    invoke-virtual {p1, v3}, Landroid/text/TextPaint;->setFakeBoldText(Z)V

    goto :goto_53

    .line 6
    :cond_44
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-static {v0, p1}, Ltb/jx1;->b(Landroid/widget/TextView;Ljava/lang/String;)V

    .line 7
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-static {v0, p1}, Ltb/jx1;->b(Landroid/widget/TextView;Ljava/lang/String;)V

    .line 8
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-static {v0, p1}, Ltb/jx1;->b(Landroid/widget/TextView;Ljava/lang/String;)V

    :cond_53
    :goto_53
    return-object p0
.end method

.method public setTimeTvGravity(Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "14"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1a
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_BOTTOM:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    const/16 v1, 0x11

    if-ne p1, v0, :cond_23

    const/16 v1, 0x50

    goto :goto_3e

    .line 2
    :cond_23
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_CENTER:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_28

    goto :goto_3e

    .line 3
    :cond_28
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_LEFT:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_30

    const v1, 0x800003

    goto :goto_3e

    .line 4
    :cond_30
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_RIGHT:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_38

    const v1, 0x800005

    goto :goto_3e

    .line 5
    :cond_38
    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;->GRAVITY_TOP:Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView$CountDownViewGravity;

    if-ne p1, v0, :cond_3e

    const/16 v1, 0x30

    .line 6
    :cond_3e
    :goto_3e
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setGravity(I)V

    .line 7
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setGravity(I)V

    .line 8
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setGravity(I)V

    return-object p0
.end method

.method public setTimeTvPadding(IIII)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_33

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_33
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/widget/TextView;->setPadding(IIII)V

    return-object p0
.end method

.method public setTimeTvSize(F)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-virtual {v0, v3, p1}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {v0, v3, p1}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {v0, v3, p1}, Landroid/widget/TextView;->setTextSize(IF)V

    return-object p0
.end method

.method public setTimeTvTextColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "7"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 3
    :cond_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 4
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    return-object p0
.end method

.method public setTimeTvTextColor(Ljava/lang/String;)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    .line 1
    :cond_1a
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->parseColor(Ljava/lang/String;)I

    move-result p1

    .line 2
    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->setTimeTvTextColor(I)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    move-result-object p1

    return-object p1
.end method

.method public setTimeTvWH(II)Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_25

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object p1

    :cond_25
    if-lez p1, :cond_3d

    if-lez p2, :cond_3d

    .line 1
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v0, p1, p2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->hourTv:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->minuteTv:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 4
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->secondTv:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_3d
    return-object p0
.end method

.method public startCountDown()Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "93"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_17

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object v0

    .line 1
    :cond_17
    iput-boolean v3, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->isContinue:Z

    .line 2
    invoke-direct {p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->countDown()V

    return-object p0
.end method

.method public stopCountDown()Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "95"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;

    return-object v0

    :cond_17
    const-wide/16 v0, 0x0

    .line 1
    iput-wide v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/temp/DMDXCountDownView;->timeStamp:J

    return-object p0
.end method
