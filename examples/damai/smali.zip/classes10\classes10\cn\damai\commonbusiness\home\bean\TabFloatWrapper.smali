.class public Lcn/damai/commonbusiness/home/bean/TabFloatWrapper;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/home/bean/TabFloatWrapper$TabTag;
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private final tabFloat:Lcn/damai/commonbusiness/home/bean/ITabFloat;

.field private tabTag:I


# direct methods
.method public constructor <init>(Lcn/damai/commonbusiness/home/bean/ITabFloat;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lcn/damai/commonbusiness/home/bean/TabFloatWrapper;->tabTag:I

    .line 3
    iput-object p1, p0, Lcn/damai/commonbusiness/home/bean/TabFloatWrapper;->tabFloat:Lcn/damai/commonbusiness/home/bean/ITabFloat;

    return-void
.end method

.method public constructor <init>(Lcn/damai/commonbusiness/home/bean/ITabFloat;I)V
    .registers 4
    .param p2    # I
        .annotation build Lcn/damai/commonbusiness/home/bean/TabFloatWrapper$TabTag;
        .end annotation
    .end param

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 5
    iput v0, p0, Lcn/damai/commonbusiness/home/bean/TabFloatWrapper;->tabTag:I

    .line 6
    iput-object p1, p0, Lcn/damai/commonbusiness/home/bean/TabFloatWrapper;->tabFloat:Lcn/damai/commonbusiness/home/bean/ITabFloat;

    .line 7
    iput p2, p0, Lcn/damai/commonbusiness/home/bean/TabFloatWrapper;->tabTag:I

    return-void
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .registers 7
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    sget-object v0, Lcn/damai/commonbusiness/home/bean/TabFloatWrapper;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    return p1

    :cond_1e
    if-ne p0, p1, :cond_21

    return v3

    :cond_21
    if-eqz p1, :cond_4f

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    if-eq v0, v1, :cond_2e

    goto :goto_4f

    .line 2
    :cond_2e
    check-cast p1, Lcn/damai/commonbusiness/home/bean/TabFloatWrapper;

    .line 3
    iget-object v0, p1, Lcn/damai/commonbusiness/home/bean/TabFloatWrapper;->tabFloat:Lcn/damai/commonbusiness/home/bean/ITabFloat;

    iget-object v1, p0, Lcn/damai/commonbusiness/home/bean/TabFloatWrapper;->tabFloat:Lcn/damai/commonbusiness/home/bean/ITabFloat;

    invoke-static {v0, v1}, Ltb/lk3;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4d

    iget p1, p1, Lcn/damai/commonbusiness/home/bean/TabFloatWrapper;->tabTag:I

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iget v0, p0, Lcn/damai/commonbusiness/home/bean/TabFloatWrapper;->tabTag:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {p1, v0}, Ltb/lk3;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_4d

    goto :goto_4e

    :cond_4d
    const/4 v3, 0x0

    :goto_4e
    return v3

    :cond_4f
    :goto_4f
    return v4
.end method

.method public getTabFloat()Lcn/damai/commonbusiness/home/bean/ITabFloat;
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/home/bean/TabFloatWrapper;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/damai/commonbusiness/home/bean/ITabFloat;

    return-object v0

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/home/bean/TabFloatWrapper;->tabFloat:Lcn/damai/commonbusiness/home/bean/ITabFloat;

    return-object v0
.end method

.method public getTabTag()I
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/home/bean/TabFloatWrapper;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget v0, p0, Lcn/damai/commonbusiness/home/bean/TabFloatWrapper;->tabTag:I

    return v0
.end method

.method public hashCode()I
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/home/bean/TabFloatWrapper;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_1b

    new-array v2, v3, [Ljava/lang/Object;

    aput-object p0, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0

    :cond_1b
    const/4 v0, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    .line 1
    iget-object v1, p0, Lcn/damai/commonbusiness/home/bean/TabFloatWrapper;->tabFloat:Lcn/damai/commonbusiness/home/bean/ITabFloat;

    aput-object v1, v0, v4

    iget v1, p0, Lcn/damai/commonbusiness/home/bean/TabFloatWrapper;->tabTag:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v0, v3

    invoke-static {v0}, Ltb/lk3;->b([Ljava/lang/Object;)I

    move-result v0

    return v0
.end method
