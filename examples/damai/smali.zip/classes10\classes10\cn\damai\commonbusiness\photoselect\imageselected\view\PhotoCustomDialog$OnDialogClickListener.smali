.class public interface abstract Lcn/damai/commonbusiness/photoselect/imageselected/view/PhotoCustomDialog$OnDialogClickListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/photoselect/imageselected/view/PhotoCustomDialog;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnDialogClickListener"
.end annotation


# virtual methods
.method public abstract onCancle()V
.end method

.method public abstract onDelete()V
.end method
