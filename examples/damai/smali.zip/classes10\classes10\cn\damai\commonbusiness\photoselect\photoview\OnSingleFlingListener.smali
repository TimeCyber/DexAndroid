.class public interface abstract Lcn/damai/commonbusiness/photoselect/photoview/OnSingleFlingListener;
.super Ljava/lang/Object;
.source "Taobao"


# virtual methods
.method public abstract onFling(Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
.end method
