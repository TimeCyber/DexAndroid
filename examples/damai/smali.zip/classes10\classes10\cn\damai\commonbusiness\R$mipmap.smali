.class public final Lcn/damai/commonbusiness/R$mipmap;
.super Ljava/lang/Object;
.source "Taobao"


# static fields
.field public static final ic_launcher:I = 0x7f0f0000


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
