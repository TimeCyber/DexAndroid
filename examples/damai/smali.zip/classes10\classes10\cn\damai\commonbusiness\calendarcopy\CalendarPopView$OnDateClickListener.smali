.class public interface abstract Lcn/damai/commonbusiness/calendarcopy/CalendarPopView$OnDateClickListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/calendarcopy/CalendarPopView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnDateClickListener"
.end annotation


# virtual methods
.method public abstract onClose()V
.end method

.method public abstract onDateClick(ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;)V
.end method
