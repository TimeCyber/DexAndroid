.class public Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$d;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;->showPhotoCustomDialog()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$d;->a:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .registers 8

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$d;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_1e

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1e
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$d;->a:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;->access$800(Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "2"

    invoke-virtual {p2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_32

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$d;->a:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;->access$900(Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;)V

    goto :goto_96

    .line 3
    :cond_32
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$d;->a:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;->access$1000(Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;)Lcn/damai/commonbusiness/photoselect/imageselected/view/MyViewPager;

    move-result-object p1

    invoke-virtual {p1}, Landroidx/viewpager/widget/ViewPager;->getCurrentItem()I

    move-result p1

    .line 4
    iget-object p2, p0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$d;->a:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;

    invoke-static {p2}, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;->access$1100(Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;)V

    .line 5
    iget-object p2, p0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$d;->a:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;

    invoke-static {p2}, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;->access$400(Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;)Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 6
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$d;->a:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;->access$1200(Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;)Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter;

    move-result-object p1

    invoke-virtual {p1}, Landroidx/viewpager/widget/PagerAdapter;->notifyDataSetChanged()V

    .line 7
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$d;->a:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;->access$500(Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;)Landroid/widget/TextView;

    move-result-object p1

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$d;->a:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;->access$1000(Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;)Lcn/damai/commonbusiness/photoselect/imageselected/view/MyViewPager;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getCurrentItem()I

    move-result v0

    add-int/2addr v0, v3

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, "/"

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$d;->a:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;->access$400(Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 8
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$d;->a:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;->access$400(Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;)Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-nez p1, :cond_96

    .line 9
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity$d;->a:Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;

    invoke-virtual {p1}, Lcn/damai/commonbusiness/photoselect/imageselected/PreviewDeleteActivity;->finish()V

    :cond_96
    :goto_96
    return-void
.end method
