.class public Lcn/damai/commonbusiness/fission/bean/FissionInfoBean;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;,
        Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$ActivityInfo;
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x1L


# instance fields
.field public shareInfo:Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$ActivityInfo;

.field public userInfo:Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
