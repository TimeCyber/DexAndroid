.class public Lcn/damai/commonbusiness/fission/bean/FissionViewPagerBean;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field public static final MAIDAN_DETAIL:Ljava/lang/String; = "2"

.field public static final ORDER_DETAIL:Ljava/lang/String; = "3"

.field public static final PROJECT_DETAIL:Ljava/lang/String; = "1"

.field private static final serialVersionUID:J = 0x1L


# instance fields
.field public bgColor:I

.field public bitmap:Landroid/graphics/Bitmap;

.field public channel:Ljava/lang/String;

.field public chickenSoup:Ljava/lang/String;

.field public imageUrl:Ljava/lang/String;

.field public mainMessage:Ljava/lang/String;

.field public subMessage:Ljava/lang/String;

.field public userInfo:Lcn/damai/commonbusiness/fission/bean/FissionInfoBean$UserInfo;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
