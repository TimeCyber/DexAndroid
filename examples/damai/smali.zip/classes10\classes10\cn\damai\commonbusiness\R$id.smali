.class public final Lcn/damai/commonbusiness/R$id;
.super Ljava/lang/Object;
.source "Taobao"


# static fields
.field public static final ALT:I = 0x7f0a0000

.field public static final BL_TR:I = 0x7f0a0009

.field public static final BOTTOM_END:I = 0x7f0a000a

.field public static final BOTTOM_START:I = 0x7f0a000b

.field public static final BOTTOM_TOP:I = 0x7f0a000c

.field public static final BR_TL:I = 0x7f0a000d

.field public static final CTRL:I = 0x7f0a000e

.field public static final DINBold:I = 0x7f0a000f

.field public static final Default:I = 0x7f0a0010

.field public static final DmDigit:I = 0x7f0a0011

.field public static final DmDigitHeavy:I = 0x7f0a0012

.field public static final FUNCTION:I = 0x7f0a0014

.field public static final FakeBold:I = 0x7f0a0015

.field public static final FixedBehind:I = 0x7f0a0016

.field public static final FixedFront:I = 0x7f0a0017

.field public static final LEFT_RIGHT:I = 0x7f0a0018

.field public static final META:I = 0x7f0a0019

.field public static final MatchLayout:I = 0x7f0a001a

.field public static final NO_DEBUG:I = 0x7f0a001b

.field public static final PuHui:I = 0x7f0a001c

.field public static final PuHuiNum:I = 0x7f0a001d

.field public static final RIGHT_LEFT:I = 0x7f0a001e

.field public static final SHIFT:I = 0x7f0a001f

.field public static final SHOW_ALL:I = 0x7f0a0020

.field public static final SHOW_PATH:I = 0x7f0a0021

.field public static final SHOW_PROGRESS:I = 0x7f0a0022

.field public static final SYM:I = 0x7f0a0024

.field public static final Scale:I = 0x7f0a0025

.field public static final TL_BR:I = 0x7f0a0028

.field public static final TOP_BOTTOM:I = 0x7f0a0029

.field public static final TOP_END:I = 0x7f0a002a

.field public static final TOP_START:I = 0x7f0a002b

.field public static final TR_BL:I = 0x7f0a002c

.field public static final Translate:I = 0x7f0a002d

.field public static final UC_WEB_VIEW_CLIENT_DELEGATE:I = 0x7f0a002e

.field public static final WEB_VIEW_CLIENT_DELEGATE:I = 0x7f0a002f

.field public static final _byte:I = 0x7f0a0030

.field public static final _double:I = 0x7f0a0031

.field public static final _float:I = 0x7f0a0032

.field public static final _integer:I = 0x7f0a0033

.field public static final _long:I = 0x7f0a0034

.field public static final _short:I = 0x7f0a0035

.field public static final abfl_detect_layout:I = 0x7f0a0038

.field public static final abfl_dialog_content_text:I = 0x7f0a0039

.field public static final abfl_dialog_negative_btn:I = 0x7f0a003a

.field public static final abfl_dialog_positive_btn:I = 0x7f0a003b

.field public static final abfl_waiting_tip:I = 0x7f0a003c

.field public static final abfl_widget_camera:I = 0x7f0a003d

.field public static final abfl_widget_camera_surface:I = 0x7f0a003e

.field public static final abfl_widget_da_actionGuidance_anim_image:I = 0x7f0a003f

.field public static final abfl_widget_da_mainPrompt:I = 0x7f0a0040

.field public static final abfl_widget_da_maskview:I = 0x7f0a0041

.field public static final abfl_widget_da_maskview_blurview:I = 0x7f0a0042

.field public static final abfl_widget_dar_btn:I = 0x7f0a0043

.field public static final abfl_widget_dar_content:I = 0x7f0a0044

.field public static final abfl_widget_dar_ctid_btn:I = 0x7f0a0045

.field public static final abfl_widget_dar_icon:I = 0x7f0a0046

.field public static final abfl_widget_dar_other_btn:I = 0x7f0a0047

.field public static final abfl_widget_dar_title:I = 0x7f0a0048

.field public static final abfl_widget_detectaction:I = 0x7f0a0049

.field public static final abfl_widget_detectactionresult:I = 0x7f0a004a

.field public static final abfl_widget_guide:I = 0x7f0a004b

.field public static final abfl_widget_guide_btn:I = 0x7f0a004c

.field public static final abfl_widget_guide_copyright:I = 0x7f0a004d

.field public static final abfl_widget_guide_icon:I = 0x7f0a004e

.field public static final abfl_widget_guide_subtext_center:I = 0x7f0a004f

.field public static final abfl_widget_guide_subtext_left:I = 0x7f0a0050

.field public static final abfl_widget_guide_subtext_parent:I = 0x7f0a0051

.field public static final abfl_widget_guide_subtext_right:I = 0x7f0a0052

.field public static final abfl_widget_guide_text:I = 0x7f0a0053

.field public static final abfl_widget_tb_close:I = 0x7f0a0054

.field public static final abfl_widget_tb_close_parent:I = 0x7f0a0055

.field public static final abfl_widget_titlebar:I = 0x7f0a0056

.field public static final accelerate:I = 0x7f0a0058

.field public static final accessibility_action_clickable_span:I = 0x7f0a0059

.field public static final accessibility_custom_action_0:I = 0x7f0a005a

.field public static final accessibility_custom_action_1:I = 0x7f0a005b

.field public static final accessibility_custom_action_10:I = 0x7f0a005c

.field public static final accessibility_custom_action_11:I = 0x7f0a005d

.field public static final accessibility_custom_action_12:I = 0x7f0a005e

.field public static final accessibility_custom_action_13:I = 0x7f0a005f

.field public static final accessibility_custom_action_14:I = 0x7f0a0060

.field public static final accessibility_custom_action_15:I = 0x7f0a0061

.field public static final accessibility_custom_action_16:I = 0x7f0a0062

.field public static final accessibility_custom_action_17:I = 0x7f0a0063

.field public static final accessibility_custom_action_18:I = 0x7f0a0064

.field public static final accessibility_custom_action_19:I = 0x7f0a0065

.field public static final accessibility_custom_action_2:I = 0x7f0a0066

.field public static final accessibility_custom_action_20:I = 0x7f0a0067

.field public static final accessibility_custom_action_21:I = 0x7f0a0068

.field public static final accessibility_custom_action_22:I = 0x7f0a0069

.field public static final accessibility_custom_action_23:I = 0x7f0a006a

.field public static final accessibility_custom_action_24:I = 0x7f0a006b

.field public static final accessibility_custom_action_25:I = 0x7f0a006c

.field public static final accessibility_custom_action_26:I = 0x7f0a006d

.field public static final accessibility_custom_action_27:I = 0x7f0a006e

.field public static final accessibility_custom_action_28:I = 0x7f0a006f

.field public static final accessibility_custom_action_29:I = 0x7f0a0070

.field public static final accessibility_custom_action_3:I = 0x7f0a0071

.field public static final accessibility_custom_action_30:I = 0x7f0a0072

.field public static final accessibility_custom_action_31:I = 0x7f0a0073

.field public static final accessibility_custom_action_4:I = 0x7f0a0074

.field public static final accessibility_custom_action_5:I = 0x7f0a0075

.field public static final accessibility_custom_action_6:I = 0x7f0a0076

.field public static final accessibility_custom_action_7:I = 0x7f0a0077

.field public static final accessibility_custom_action_8:I = 0x7f0a0078

.field public static final accessibility_custom_action_9:I = 0x7f0a0079

.field public static final account_album_item_area:I = 0x7f0a007a

.field public static final account_album_item_bg:I = 0x7f0a007b

.field public static final account_album_item_desc:I = 0x7f0a007c

.field public static final account_album_item_name:I = 0x7f0a007d

.field public static final account_album_item_pic:I = 0x7f0a007e

.field public static final action:I = 0x7f0a007f

.field public static final action0:I = 0x7f0a0080

.field public static final actionDown:I = 0x7f0a0081

.field public static final actionDownUp:I = 0x7f0a0082

.field public static final actionUp:I = 0x7f0a0083

.field public static final action_bar:I = 0x7f0a0084

.field public static final action_bar_activity_content:I = 0x7f0a0085

.field public static final action_bar_container:I = 0x7f0a0086

.field public static final action_bar_root:I = 0x7f0a0087

.field public static final action_bar_spinner:I = 0x7f0a0088

.field public static final action_bar_subtitle:I = 0x7f0a0089

.field public static final action_bar_title:I = 0x7f0a008a

.field public static final action_channel_container:I = 0x7f0a008b

.field public static final action_close:I = 0x7f0a008c

.field public static final action_container:I = 0x7f0a008d

.field public static final action_context_bar:I = 0x7f0a008e

.field public static final action_divider:I = 0x7f0a008f

.field public static final action_image:I = 0x7f0a0090

.field public static final action_layout:I = 0x7f0a0091

.field public static final action_menu_divider:I = 0x7f0a0092

.field public static final action_menu_presenter:I = 0x7f0a0093

.field public static final action_mode_bar:I = 0x7f0a0094

.field public static final action_mode_bar_stub:I = 0x7f0a0095

.field public static final action_mode_close_button:I = 0x7f0a0096

.field public static final action_one:I = 0x7f0a0097

.field public static final action_pager_indicator:I = 0x7f0a0098

.field public static final action_pager_text:I = 0x7f0a0099

.field public static final action_sheet_cancel_item:I = 0x7f0a009a

.field public static final action_sheet_container:I = 0x7f0a009b

.field public static final action_sheet_item:I = 0x7f0a009c

.field public static final action_text:I = 0x7f0a009d

.field public static final action_two:I = 0x7f0a009e

.field public static final actions:I = 0x7f0a009f

.field public static final activity_arrow:I = 0x7f0a00a0

.field public static final activity_chooser_view_content:I = 0x7f0a00a1

.field public static final activity_configuration_height_dp:I = 0x7f0a00a2

.field public static final activity_configuration_width_dp:I = 0x7f0a00a3

.field public static final activity_content:I = 0x7f0a00a4

.field public static final activity_count:I = 0x7f0a00a5

.field public static final activity_des:I = 0x7f0a00a6

.field public static final activity_desc:I = 0x7f0a00a7

.field public static final activity_flag:I = 0x7f0a00a9

.field public static final activity_image:I = 0x7f0a00aa

.field public static final activity_ll:I = 0x7f0a00ab

.field public static final activity_orientation:I = 0x7f0a00ad

.field public static final activity_price_list:I = 0x7f0a00ae

.field public static final activity_tag:I = 0x7f0a00af

.field public static final activity_tag_joined:I = 0x7f0a00b0

.field public static final activity_title:I = 0x7f0a00b1

.field public static final actor_album_desc:I = 0x7f0a00b2

.field public static final actor_album_item_area:I = 0x7f0a00b3

.field public static final actor_album_item_name:I = 0x7f0a00b4

.field public static final actor_album_item_pic:I = 0x7f0a00b5

.field public static final actor_image:I = 0x7f0a00b6

.field public static final actor_image_bg:I = 0x7f0a00b7

.field public static final actor_layout:I = 0x7f0a00b8

.field public static final actor_single_layout:I = 0x7f0a00b9

.field public static final actor_text:I = 0x7f0a00ba

.field public static final add:I = 0x7f0a00bf

.field public static final add_address_root_lv:I = 0x7f0a00c0

.field public static final add_arrow:I = 0x7f0a00c1

.field public static final add_btn:I = 0x7f0a00c2

.field public static final add_contacts_back_icon:I = 0x7f0a00c5

.field public static final add_contacts_cancel_btn:I = 0x7f0a00c6

.field public static final add_contacts_clear_idcard_number_iv:I = 0x7f0a00c7

.field public static final add_contacts_clear_name_iv:I = 0x7f0a00c8

.field public static final add_contacts_confirm_btn:I = 0x7f0a00c9

.field public static final add_contacts_container:I = 0x7f0a00ca

.field public static final add_contacts_id_nationality_btn:I = 0x7f0a00cb

.field public static final add_contacts_id_nationality_more_btn:I = 0x7f0a00cc

.field public static final add_contacts_id_nationality_title:I = 0x7f0a00cd

.field public static final add_contacts_id_type_btn:I = 0x7f0a00ce

.field public static final add_contacts_id_type_more_btn:I = 0x7f0a00cf

.field public static final add_contacts_idcard_line:I = 0x7f0a00d0

.field public static final add_contacts_idcard_number:I = 0x7f0a00d1

.field public static final add_contacts_idcard_number_text_tv:I = 0x7f0a00d2

.field public static final add_contacts_idtype_list:I = 0x7f0a00d3

.field public static final add_contacts_info_layout:I = 0x7f0a00d4

.field public static final add_contacts_name:I = 0x7f0a00d5

.field public static final add_contacts_name_text_tv:I = 0x7f0a00d6

.field public static final add_contacts_notice:I = 0x7f0a00d7

.field public static final add_contacts_save_btn:I = 0x7f0a00d8

.field public static final add_contacts_tip:I = 0x7f0a00d9

.field public static final add_contacts_title:I = 0x7f0a00da

.field public static final add_contacts_title_layout:I = 0x7f0a00db

.field public static final add_contacts_title_line:I = 0x7f0a00dc

.field public static final add_contacts_title_line2:I = 0x7f0a00dd

.field public static final add_contatcs_cancel_btn:I = 0x7f0a00de

.field public static final add_contatcs_error_tip_text:I = 0x7f0a00df

.field public static final add_customer_btn:I = 0x7f0a00e0

.field public static final add_image:I = 0x7f0a00e3

.field public static final add_nationality_div:I = 0x7f0a00e5

.field public static final add_nationality_line:I = 0x7f0a00e6

.field public static final add_photo_layout:I = 0x7f0a00e7

.field public static final add_time:I = 0x7f0a00f0

.field public static final additional_container:I = 0x7f0a00f4

.field public static final address:I = 0x7f0a00f7

.field public static final address_protocol_checkbox:I = 0x7f0a00fe

.field public static final address_protocol_layout:I = 0x7f0a00ff

.field public static final advert_flag:I = 0x7f0a0103

.field public static final ai_search:I = 0x7f0a010d

.field public static final alertTitle:I = 0x7f0a0113

.field public static final ali_ucc_bind_title:I = 0x7f0a0114

.field public static final ali_ucc_close:I = 0x7f0a0115

.field public static final ali_ucc_login_frame:I = 0x7f0a0116

.field public static final ali_ucc_new_login_content:I = 0x7f0a0117

.field public static final ali_user_guide_account_login_btn:I = 0x7f0a0118

.field public static final ali_user_guide_alipay_login_btn:I = 0x7f0a0119

.field public static final ali_user_guide_app_name:I = 0x7f0a011a

.field public static final ali_user_guide_close:I = 0x7f0a011b

.field public static final ali_user_guide_close_layout:I = 0x7f0a011c

.field public static final ali_user_guide_tb_login_btn:I = 0x7f0a011d

.field public static final ali_user_guide_title:I = 0x7f0a011e

.field public static final ali_user_login_alipay_login_tv:I = 0x7f0a011f

.field public static final ali_user_sso_guide_activity:I = 0x7f0a0120

.field public static final ali_user_webview_container:I = 0x7f0a0121

.field public static final ali_user_webview_toolbar:I = 0x7f0a0122

.field public static final ali_userbg:I = 0x7f0a0123

.field public static final aligned:I = 0x7f0a0124

.field public static final aliuser_account_additem_avatar:I = 0x7f0a0125

.field public static final aliuser_account_item_avatar:I = 0x7f0a0126

.field public static final aliuser_account_item_delete_btn:I = 0x7f0a0127

.field public static final aliuser_account_item_selected:I = 0x7f0a0128

.field public static final aliuser_account_item_userinput:I = 0x7f0a0129

.field public static final aliuser_alipay_area:I = 0x7f0a012a

.field public static final aliuser_alipay_protocal:I = 0x7f0a012b

.field public static final aliuser_auth_title_back_tv:I = 0x7f0a012c

.field public static final aliuser_bottom_menu_title_divider:I = 0x7f0a012d

.field public static final aliuser_bottom_menu_title_tv:I = 0x7f0a012e

.field public static final aliuser_cancel_tv:I = 0x7f0a012f

.field public static final aliuser_change_login:I = 0x7f0a0130

.field public static final aliuser_check_rl:I = 0x7f0a0131

.field public static final aliuser_containers_sv:I = 0x7f0a0132

.field public static final aliuser_content:I = 0x7f0a0133

.field public static final aliuser_content_frame:I = 0x7f0a0134

.field public static final aliuser_damai_ll:I = 0x7f0a0135

.field public static final aliuser_dialog_cancel:I = 0x7f0a0136

.field public static final aliuser_dialog_confirm:I = 0x7f0a0137

.field public static final aliuser_dialog_logo:I = 0x7f0a0138

.field public static final aliuser_dialog_message:I = 0x7f0a0139

.field public static final aliuser_dialog_split:I = 0x7f0a013a

.field public static final aliuser_dialog_title:I = 0x7f0a013b

.field public static final aliuser_dm_region_tip:I = 0x7f0a013c

.field public static final aliuser_go_pwd:I = 0x7f0a013d

.field public static final aliuser_go_taobao_pwd:I = 0x7f0a013e

.field public static final aliuser_id_webview:I = 0x7f0a013f

.field public static final aliuser_login_account_clear_iv:I = 0x7f0a0140

.field public static final aliuser_login_account_et:I = 0x7f0a0141

.field public static final aliuser_login_account_rl:I = 0x7f0a0142

.field public static final aliuser_login_account_tv:I = 0x7f0a0143

.field public static final aliuser_login_alipay_login_divider:I = 0x7f0a0144

.field public static final aliuser_login_avatar:I = 0x7f0a0145

.field public static final aliuser_login_btn:I = 0x7f0a0146

.field public static final aliuser_login_dm_logo:I = 0x7f0a0147

.field public static final aliuser_login_forgot_password_tv:I = 0x7f0a0148

.field public static final aliuser_login_history_ll:I = 0x7f0a0149

.field public static final aliuser_login_login_btn:I = 0x7f0a014a

.field public static final aliuser_login_login_btn_ll:I = 0x7f0a014b

.field public static final aliuser_login_mobile_clear_iv:I = 0x7f0a014c

.field public static final aliuser_login_mobile_et:I = 0x7f0a014d

.field public static final aliuser_login_mobile_tv:I = 0x7f0a014e

.field public static final aliuser_login_normal_ll:I = 0x7f0a014f

.field public static final aliuser_login_password_clear_iv:I = 0x7f0a0150

.field public static final aliuser_login_password_et:I = 0x7f0a0151

.field public static final aliuser_login_qr_code:I = 0x7f0a0152

.field public static final aliuser_login_send_smscode_btn:I = 0x7f0a0153

.field public static final aliuser_login_send_voicecode_tv:I = 0x7f0a0154

.field public static final aliuser_login_show_password_btn:I = 0x7f0a0155

.field public static final aliuser_login_sms_code_secondary_title_tv:I = 0x7f0a0156

.field public static final aliuser_login_sms_code_view:I = 0x7f0a0157

.field public static final aliuser_login_switch_face_login:I = 0x7f0a0158

.field public static final aliuser_login_switch_more_login:I = 0x7f0a0159

.field public static final aliuser_login_switch_pwdlogin:I = 0x7f0a015a

.field public static final aliuser_login_switch_smslogin:I = 0x7f0a015b

.field public static final aliuser_login_voice_code_tv:I = 0x7f0a015c

.field public static final aliuser_login_voice_rr:I = 0x7f0a015d

.field public static final aliuser_main_content:I = 0x7f0a015e

.field public static final aliuser_menu_item:I = 0x7f0a015f

.field public static final aliuser_menu_item_help:I = 0x7f0a0160

.field public static final aliuser_menu_item_more:I = 0x7f0a0161

.field public static final aliuser_menu_lv:I = 0x7f0a0162

.field public static final aliuser_multi_account_add_btn:I = 0x7f0a0163

.field public static final aliuser_multi_account_delete_manager_btn:I = 0x7f0a0164

.field public static final aliuser_multi_account_lv:I = 0x7f0a0165

.field public static final aliuser_multi_account_title:I = 0x7f0a0166

.field public static final aliuser_multi_account_title_ll:I = 0x7f0a0167

.field public static final aliuser_multi_account_title_secondary:I = 0x7f0a0168

.field public static final aliuser_multi_logout_btn:I = 0x7f0a0169

.field public static final aliuser_onekey_login_account_tv:I = 0x7f0a016a

.field public static final aliuser_onekey_login_bottom_area:I = 0x7f0a016b

.field public static final aliuser_onekey_login_btn:I = 0x7f0a016c

.field public static final aliuser_onekey_login_menu:I = 0x7f0a016d

.field public static final aliuser_onekey_reg_account_tv:I = 0x7f0a016e

.field public static final aliuser_onekey_reg_avatar:I = 0x7f0a016f

.field public static final aliuser_onekey_reg_btn:I = 0x7f0a0170

.field public static final aliuser_onekey_reg_ll:I = 0x7f0a0171

.field public static final aliuser_operation_agree:I = 0x7f0a0172

.field public static final aliuser_operation_disagree:I = 0x7f0a0173

.field public static final aliuser_operation_sencondary_tip:I = 0x7f0a0174

.field public static final aliuser_operation_tip:I = 0x7f0a0175

.field public static final aliuser_policy_protocal:I = 0x7f0a0176

.field public static final aliuser_protocal_inset_ll:I = 0x7f0a0177

.field public static final aliuser_protocal_tip:I = 0x7f0a0178

.field public static final aliuser_protocol_cancel:I = 0x7f0a0179

.field public static final aliuser_protocol_inset:I = 0x7f0a017a

.field public static final aliuser_protocol_tv:I = 0x7f0a017b

.field public static final aliuser_qr_container:I = 0x7f0a017c

.field public static final aliuser_qr_refresh:I = 0x7f0a017d

.field public static final aliuser_qrlogin_divider:I = 0x7f0a017e

.field public static final aliuser_qrlogin_tv:I = 0x7f0a017f

.field public static final aliuser_recommend_login_account_et:I = 0x7f0a0180

.field public static final aliuser_recommend_login_account_rl:I = 0x7f0a0181

.field public static final aliuser_recommend_login_bottom_area:I = 0x7f0a0182

.field public static final aliuser_recommend_login_left_func_tv:I = 0x7f0a0183

.field public static final aliuser_recommend_login_menu:I = 0x7f0a0184

.field public static final aliuser_recommend_login_next_btn:I = 0x7f0a0185

.field public static final aliuser_recommend_login_password_clear_iv:I = 0x7f0a0186

.field public static final aliuser_recommend_login_password_et:I = 0x7f0a0187

.field public static final aliuser_recommend_login_password_rl:I = 0x7f0a0188

.field public static final aliuser_recommend_login_reg_tip_tv:I = 0x7f0a0189

.field public static final aliuser_recommend_login_reg_tv:I = 0x7f0a018a

.field public static final aliuser_recommend_login_region_tv:I = 0x7f0a018b

.field public static final aliuser_recommend_login_right_func_tv:I = 0x7f0a018c

.field public static final aliuser_recommend_login_show_password_btn:I = 0x7f0a018d

.field public static final aliuser_recommend_login_tip_tv:I = 0x7f0a018e

.field public static final aliuser_reg_checkbox:I = 0x7f0a018f

.field public static final aliuser_reg_func_menu:I = 0x7f0a0190

.field public static final aliuser_reg_operational_location_tv:I = 0x7f0a0191

.field public static final aliuser_reg_scroll:I = 0x7f0a0192

.field public static final aliuser_reg_tip:I = 0x7f0a0193

.field public static final aliuser_reg_tv:I = 0x7f0a0194

.field public static final aliuser_region_list_title:I = 0x7f0a0195

.field public static final aliuser_region_listview:I = 0x7f0a0196

.field public static final aliuser_region_rl:I = 0x7f0a0197

.field public static final aliuser_region_tv:I = 0x7f0a0198

.field public static final aliuser_register_cancel:I = 0x7f0a0199

.field public static final aliuser_register_email_clear_iv:I = 0x7f0a019a

.field public static final aliuser_register_email_code_et:I = 0x7f0a019b

.field public static final aliuser_register_email_et:I = 0x7f0a019c

.field public static final aliuser_register_enterprise:I = 0x7f0a019d

.field public static final aliuser_register_mobile_et:I = 0x7f0a019e

.field public static final aliuser_register_password_et:I = 0x7f0a019f

.field public static final aliuser_register_password_tip:I = 0x7f0a01a0

.field public static final aliuser_register_person:I = 0x7f0a01a1

.field public static final aliuser_register_reg_btn:I = 0x7f0a01a2

.field public static final aliuser_register_reg_btn_ll:I = 0x7f0a01a3

.field public static final aliuser_register_send_emailcode_btn:I = 0x7f0a01a4

.field public static final aliuser_register_send_smscode_btn:I = 0x7f0a01a5

.field public static final aliuser_register_send_voicecode_tv:I = 0x7f0a01a6

.field public static final aliuser_register_sms_code_et:I = 0x7f0a01a7

.field public static final aliuser_register_sms_code_secondary_title_tv:I = 0x7f0a01a8

.field public static final aliuser_register_sms_code_view:I = 0x7f0a01a9

.field public static final aliuser_register_tips_tv:I = 0x7f0a01aa

.field public static final aliuser_root_ll:I = 0x7f0a01ab

.field public static final aliuser_scan_bg_imageview:I = 0x7f0a01ac

.field public static final aliuser_scan_cancelButton:I = 0x7f0a01ad

.field public static final aliuser_scan_confirmButton:I = 0x7f0a01ae

.field public static final aliuser_scan_confirmTextView:I = 0x7f0a01af

.field public static final aliuser_scan_login_account_tv:I = 0x7f0a01b0

.field public static final aliuser_scan_login_btn:I = 0x7f0a01b1

.field public static final aliuser_scan_subTitleTextView:I = 0x7f0a01b2

.field public static final aliuser_scan_switch_pwd:I = 0x7f0a01b3

.field public static final aliuser_scan_switch_sms:I = 0x7f0a01b4

.field public static final aliuser_scan_textview:I = 0x7f0a01b5

.field public static final aliuser_send_sms_success_tip:I = 0x7f0a01b6

.field public static final aliuser_success_icon:I = 0x7f0a01b7

.field public static final aliuser_switch_mobile_reg:I = 0x7f0a01b8

.field public static final aliuser_switch_recommend_login:I = 0x7f0a01b9

.field public static final aliuser_tb_protocal:I = 0x7f0a01ba

.field public static final aliuser_toast_body:I = 0x7f0a01bb

.field public static final aliuser_toast_message:I = 0x7f0a01bc

.field public static final aliuser_toolbar:I = 0x7f0a01bd

.field public static final aliuser_user_login_ll:I = 0x7f0a01be

.field public static final aliuser_web_progress_bar:I = 0x7f0a01bf

.field public static final aliuser_web_rl:I = 0x7f0a01c0

.field public static final all:I = 0x7f0a01c1

.field public static final allStates:I = 0x7f0a01c2

.field public static final all_card_layout:I = 0x7f0a01c3

.field public static final all_photo:I = 0x7f0a01c4

.field public static final all_value_container:I = 0x7f0a01c5

.field public static final already_int_check_img:I = 0x7f0a01c6

.field public static final already_int_dis_check_img:I = 0x7f0a01c7

.field public static final already_int_dis_uncheck_img:I = 0x7f0a01c8

.field public static final already_int_uncheck_img:I = 0x7f0a01c9

.field public static final alum_tab_jump:I = 0x7f0a01ca

.field public static final always:I = 0x7f0a01cb

.field public static final alwaysHide:I = 0x7f0a01cc

.field public static final alwaysShow:I = 0x7f0a01cd

.field public static final alwaysShowAfterTouch:I = 0x7f0a01ce

.field public static final amap_map3d_city_header:I = 0x7f0a01cf

.field public static final amap_map3d_city_header_image:I = 0x7f0a01d0

.field public static final amap_map3d_city_listview:I = 0x7f0a01d1

.field public static final amap_map3d_dialog_cancle:I = 0x7f0a01d2

.field public static final amap_map3d_dialog_delete:I = 0x7f0a01d3

.field public static final amap_map3d_dialog_status:I = 0x7f0a01d4

.field public static final amap_map3d_dialog_title:I = 0x7f0a01d5

.field public static final amap_map3d_divider1:I = 0x7f0a01d6

.field public static final amap_map3d_download_header:I = 0x7f0a01d7

.field public static final amap_map3d_download_header_image:I = 0x7f0a01d8

.field public static final amap_map3d_download_header_text:I = 0x7f0a01d9

.field public static final amap_map3d_download_listview:I = 0x7f0a01da

.field public static final amap_map3d_download_progress_status:I = 0x7f0a01db

.field public static final amap_map3d_download_status_image:I = 0x7f0a01dc

.field public static final amap_map3d_download_status_layout:I = 0x7f0a01dd

.field public static final amap_map3d_download_title_back:I = 0x7f0a01de

.field public static final amap_map3d_download_title_layout:I = 0x7f0a01df

.field public static final amap_map3d_download_title_text:I = 0x7f0a01e0

.field public static final amap_map3d_footer:I = 0x7f0a01e1

.field public static final amap_map3d_group_image:I = 0x7f0a01e2

.field public static final amap_map3d_group_text:I = 0x7f0a01e3

.field public static final amap_map3d_header:I = 0x7f0a01e4

.field public static final amap_map3d_name:I = 0x7f0a01e5

.field public static final amap_map3d_name_size:I = 0x7f0a01e6

.field public static final amap_map3d_progress:I = 0x7f0a01e7

.field public static final amap_map3d_search_input:I = 0x7f0a01e8

.field public static final amap_map3d_search_input_clean:I = 0x7f0a01e9

.field public static final amap_map3d_search_input_searchimg:I = 0x7f0a01ea

.field public static final amap_map3d_search_listview:I = 0x7f0a01eb

.field public static final anchor_horizontal_group:I = 0x7f0a01ed

.field public static final anchor_name_tv:I = 0x7f0a01ee

.field public static final androidx_compose_ui_view_composition_context:I = 0x7f0a01ef

.field public static final anim_view:I = 0x7f0a01f1

.field public static final animateToEnd:I = 0x7f0a01f2

.field public static final animateToStart:I = 0x7f0a01f3

.field public static final animation_view_id_after_publish:I = 0x7f0a01f4

.field public static final ant_see_bottombar_tip_bg_img:I = 0x7f0a01f5

.field public static final antiClockwise:I = 0x7f0a01f6

.field public static final anticipate:I = 0x7f0a01f7

.field public static final apm_page_root_view:I = 0x7f0a01f8

.field public static final apm_view_token:I = 0x7f0a01f9

.field public static final appbar:I = 0x7f0a01fa

.field public static final appbar_layout:I = 0x7f0a01fb

.field public static final arc:I = 0x7f0a01fc

.field public static final area_code_choose_close_tv:I = 0x7f0a01fd

.field public static final area_code_choose_container_fv:I = 0x7f0a01fe

.field public static final area_code_choose_layer_lv:I = 0x7f0a01ff

.field public static final area_code_choose_title_tv:I = 0x7f0a0200

.field public static final area_code_item_line:I = 0x7f0a0201

.field public static final area_code_rlv:I = 0x7f0a0202

.field public static final area_code_select_ck:I = 0x7f0a0203

.field public static final area_code_text_name_tv:I = 0x7f0a0204

.field public static final area_code_top_status_bar_space:I = 0x7f0a0205

.field public static final area_container:I = 0x7f0a0206

.field public static final areas:I = 0x7f0a0207

.field public static final areas_close:I = 0x7f0a0208

.field public static final areas_content:I = 0x7f0a0209

.field public static final aritst_content_layout:I = 0x7f0a020a

.field public static final aritst_content_poster:I = 0x7f0a020b

.field public static final aritst_content_title:I = 0x7f0a020c

.field public static final aritst_image_layout:I = 0x7f0a020d

.field public static final around:I = 0x7f0a020e

.field public static final arrow:I = 0x7f0a020f

.field public static final arrow_down_up:I = 0x7f0a0210

.field public static final arrow_icon_font:I = 0x7f0a0211

.field public static final arrow_right:I = 0x7f0a0213

.field public static final article_add_comment:I = 0x7f0a0219

.field public static final article_add_favor:I = 0x7f0a021a

.field public static final article_comment_container:I = 0x7f0a021b

.field public static final article_comment_count:I = 0x7f0a021c

.field public static final article_container:I = 0x7f0a021d

.field public static final article_content:I = 0x7f0a021e

.field public static final article_detail_share:I = 0x7f0a021f

.field public static final article_favor_count:I = 0x7f0a0220

.field public static final article_head:I = 0x7f0a0221

.field public static final article_image:I = 0x7f0a0222

.field public static final article_image_container:I = 0x7f0a0223

.field public static final article_image_cover:I = 0x7f0a0224

.field public static final article_image_tag:I = 0x7f0a0225

.field public static final article_jump_film_detail:I = 0x7f0a0226

.field public static final article_magic_comment_header:I = 0x7f0a0227

.field public static final article_media:I = 0x7f0a0228

.field public static final article_menu:I = 0x7f0a0229

.field public static final article_menu_fill_view:I = 0x7f0a022a

.field public static final article_share_menu:I = 0x7f0a022b

.field public static final article_summary:I = 0x7f0a022c

.field public static final article_theme_media_duration:I = 0x7f0a022d

.field public static final article_theme_media_play_icon:I = 0x7f0a022e

.field public static final article_title:I = 0x7f0a022f

.field public static final article_topic:I = 0x7f0a0230

.field public static final article_topic_cover:I = 0x7f0a0231

.field public static final article_topic_cover_radius:I = 0x7f0a0232

.field public static final article_video_indicate:I = 0x7f0a0233

.field public static final article_video_indicate_bg:I = 0x7f0a0234

.field public static final artist_avatar:I = 0x7f0a0238

.field public static final artist_avatar_lay:I = 0x7f0a0239

.field public static final artist_avatar_lay_child:I = 0x7f0a023a

.field public static final artist_avatar_pioneer:I = 0x7f0a023b

.field public static final artist_banner_child_btn:I = 0x7f0a023c

.field public static final artist_banner_child_subtitle:I = 0x7f0a023d

.field public static final artist_banner_child_title:I = 0x7f0a023e

.field public static final artist_benefit_multiple_container:I = 0x7f0a023f

.field public static final artist_benefit_single_container:I = 0x7f0a0240

.field public static final artist_card_layout:I = 0x7f0a0241

.field public static final artist_club_item_date:I = 0x7f0a0243

.field public static final artist_future_city_add:I = 0x7f0a0246

.field public static final artist_future_city_container:I = 0x7f0a0247

.field public static final artist_future_city_rl:I = 0x7f0a0248

.field public static final artist_future_padding_bottom:I = 0x7f0a0249

.field public static final artist_future_padding_recycle:I = 0x7f0a024a

.field public static final artist_future_padding_top:I = 0x7f0a024b

.field public static final artist_future_title:I = 0x7f0a024c

.field public static final artist_future_title_tag:I = 0x7f0a024d

.field public static final artist_future_want_count_desc_icon:I = 0x7f0a024e

.field public static final artist_future_want_count_desc_tv:I = 0x7f0a024f

.field public static final artist_future_want_count_tv:I = 0x7f0a0250

.field public static final artist_future_want_rich_tv:I = 0x7f0a0251

.field public static final artist_future_want_tag:I = 0x7f0a0252

.field public static final artist_icon_mute:I = 0x7f0a0253

.field public static final artist_image:I = 0x7f0a0254

.field public static final artist_inner_layout:I = 0x7f0a0255

.field public static final artist_item_poster:I = 0x7f0a0256

.field public static final artist_item_price_above:I = 0x7f0a0257

.field public static final artist_item_price_flag:I = 0x7f0a0258

.field public static final artist_item_price_layout:I = 0x7f0a0259

.field public static final artist_item_price_tv:I = 0x7f0a025a

.field public static final artist_item_title:I = 0x7f0a025b

.field public static final artist_masterpiece:I = 0x7f0a025d

.field public static final artist_merch_layout:I = 0x7f0a025e

.field public static final artist_more_text:I = 0x7f0a0260

.field public static final artist_name:I = 0x7f0a0261

.field public static final artist_name_first_icon:I = 0x7f0a0262

.field public static final artist_name_txt:I = 0x7f0a0263

.field public static final artist_now_big_title_tv:I = 0x7f0a0264

.field public static final artist_now_subtitle_tv:I = 0x7f0a0265

.field public static final artist_pic:I = 0x7f0a0268

.field public static final artist_poster_iv:I = 0x7f0a026a

.field public static final artist_poster_iv_border:I = 0x7f0a026b

.field public static final artist_profession:I = 0x7f0a026d

.field public static final artist_select_list:I = 0x7f0a026e

.field public static final artist_select_list_stick_title_block:I = 0x7f0a026f

.field public static final artist_show_sub_title_tv:I = 0x7f0a0270

.field public static final artist_show_title_tv:I = 0x7f0a0271

.field public static final artist_show_want_tv:I = 0x7f0a0272

.field public static final artist_tag_image:I = 0x7f0a0273

.field public static final artist_tag_text:I = 0x7f0a0274

.field public static final artist_tour_city_view:I = 0x7f0a0275

.field public static final asConfigured:I = 0x7f0a0279

.field public static final aspectRatio:I = 0x7f0a027a

.field public static final async:I = 0x7f0a027c

.field public static final async_pool_view_tag:I = 0x7f0a027d

.field public static final attent_view_brand:I = 0x7f0a0281

.field public static final attent_view_ipbrand:I = 0x7f0a0283

.field public static final attent_view_star:I = 0x7f0a0284

.field public static final audience_description:I = 0x7f0a0286

.field public static final audience_layout:I = 0x7f0a0287

.field public static final audience_reminder:I = 0x7f0a0288

.field public static final audience_title:I = 0x7f0a0289

.field public static final augmented:I = 0x7f0a028a

.field public static final auth_third_header:I = 0x7f0a028b

.field public static final author_tag:I = 0x7f0a028d

.field public static final auto:I = 0x7f0a028e

.field public static final autoComplete:I = 0x7f0a028f

.field public static final autoCompleteToEnd:I = 0x7f0a0290

.field public static final autoCompleteToStart:I = 0x7f0a0291

.field public static final auto_fit:I = 0x7f0a0292

.field public static final auto_focus:I = 0x7f0a0293

.field public static final auto_rotation_operator:I = 0x7f0a0294

.field public static final automatic:I = 0x7f0a0295

.field public static final avatar:I = 0x7f0a0296

.field public static final avatar_img:I = 0x7f0a0297

.field public static final avatar_inner_border:I = 0x7f0a0298

.field public static final avatar_inner_layout:I = 0x7f0a0299

.field public static final avatar_lay:I = 0x7f0a029a

.field public static final avatar_out_border:I = 0x7f0a029c

.field public static final avatar_place_holder:I = 0x7f0a029d

.field public static final avatar_right_bottom_v_tag:I = 0x7f0a029e

.field public static final avatar_right_bottom_yy_member_tag:I = 0x7f0a029f

.field public static final avatar_round_img:I = 0x7f0a02a0

.field public static final back:I = 0x7f0a02b1

.field public static final back_btn:I = 0x7f0a02b2

.field public static final back_btn_right_container:I = 0x7f0a02b3

.field public static final backgroundView:I = 0x7f0a02b5

.field public static final background_image:I = 0x7f0a02b6

.field public static final background_view:I = 0x7f0a02b7

.field public static final badge_info:I = 0x7f0a02b8

.field public static final badge_item:I = 0x7f0a02b9

.field public static final badge_menu1:I = 0x7f0a02ba

.field public static final badge_menu2:I = 0x7f0a02bb

.field public static final ball_tab_indicator:I = 0x7f0a02bc

.field public static final bank_icon:I = 0x7f0a02be

.field public static final bank_selector_item_check:I = 0x7f0a02bf

.field public static final bank_selector_item_reason:I = 0x7f0a02c0

.field public static final bank_selector_item_reason_icon:I = 0x7f0a02c1

.field public static final bank_selector_item_sub_desc:I = 0x7f0a02c2

.field public static final bank_selector_item_time:I = 0x7f0a02c3

.field public static final bank_selector_item_title:I = 0x7f0a02c4

.field public static final banner:I = 0x7f0a02c5

.field public static final bannerContainer:I = 0x7f0a02c6

.field public static final bannerTitle:I = 0x7f0a02c7

.field public static final bannerViewPager:I = 0x7f0a02c8

.field public static final banner_container:I = 0x7f0a02c9

.field public static final banner_image:I = 0x7f0a02cb

.field public static final banner_image_view:I = 0x7f0a02cc

.field public static final banner_img:I = 0x7f0a02cd

.field public static final banner_indicator:I = 0x7f0a02ce

.field public static final banner_pic:I = 0x7f0a02cf

.field public static final banner_view_pager:I = 0x7f0a02d3

.field public static final bannervideo:I = 0x7f0a02d4

.field public static final bannerview:I = 0x7f0a02d5

.field public static final bar_code:I = 0x7f0a02d7

.field public static final bar_code_content:I = 0x7f0a02d8

.field public static final bar_code_num:I = 0x7f0a02d9

.field public static final barrier:I = 0x7f0a02dd

.field public static final base_content_llyt:I = 0x7f0a02de

.field public static final base_header_left:I = 0x7f0a02df

.field public static final base_header_right:I = 0x7f0a02e0

.field public static final base_header_title:I = 0x7f0a02e1

.field public static final base_left_icon:I = 0x7f0a02e2

.field public static final base_left_text:I = 0x7f0a02e3

.field public static final base_padding_left:I = 0x7f0a02e4

.field public static final base_padding_right:I = 0x7f0a02e5

.field public static final base_right_icon:I = 0x7f0a02e6

.field public static final base_right_text:I = 0x7f0a02e7

.field public static final baseline:I = 0x7f0a02e8

.field public static final battle_agree_tag:I = 0x7f0a02e9

.field public static final battle_disagree_tag:I = 0x7f0a02ea

.field public static final begin_time:I = 0x7f0a02ee

.field public static final beginning:I = 0x7f0a02ef

.field public static final benefit_button_title:I = 0x7f0a02f1

.field public static final benefit_desc:I = 0x7f0a02f2

.field public static final benefit_icon:I = 0x7f0a02f3

.field public static final benefit_img:I = 0x7f0a02f4

.field public static final benefit_main_title:I = 0x7f0a02f5

.field public static final benefit_sub_title:I = 0x7f0a02f6

.field public static final benefit_title:I = 0x7f0a02f7

.field public static final bese_content_view:I = 0x7f0a02f8

.field public static final bese_head_view:I = 0x7f0a02f9

.field public static final bestChoice:I = 0x7f0a02fa

.field public static final best_schedule_item_tag:I = 0x7f0a02fb

.field public static final bezier:I = 0x7f0a02fc

.field public static final bg:I = 0x7f0a02fd

.field public static final bgView:I = 0x7f0a02ff

.field public static final bg_image:I = 0x7f0a0301

.field public static final bg_layout:I = 0x7f0a0302

.field public static final bg_recommend_new_header:I = 0x7f0a0308

.field public static final big_lottie_animation:I = 0x7f0a030a

.field public static final big_poster:I = 0x7f0a030b

.field public static final black_diamond_spot:I = 0x7f0a0311

.field public static final blank:I = 0x7f0a0312

.field public static final blank_black:I = 0x7f0a0313

.field public static final blank_view:I = 0x7f0a0314

.field public static final blank_white:I = 0x7f0a0315

.field public static final blank_white_container:I = 0x7f0a0316

.field public static final block_bank_select_amount:I = 0x7f0a0317

.field public static final block_bank_select_area:I = 0x7f0a0318

.field public static final block_bank_select_arrow:I = 0x7f0a0319

.field public static final block_bank_select_name:I = 0x7f0a031a

.field public static final block_bogo_select_area:I = 0x7f0a031b

.field public static final block_bogo_select_arrow:I = 0x7f0a031c

.field public static final block_bogo_select_name:I = 0x7f0a031d

.field public static final block_citypass_open_switch:I = 0x7f0a031e

.field public static final block_coupon_select_amount:I = 0x7f0a031f

.field public static final block_coupon_select_area:I = 0x7f0a0320

.field public static final block_coupon_select_arrow:I = 0x7f0a0321

.field public static final block_coupon_select_name:I = 0x7f0a0322

.field public static final block_endorse_fee_arrow:I = 0x7f0a0323

.field public static final block_notice_desc_container:I = 0x7f0a0324

.field public static final block_notice_item_desc:I = 0x7f0a0325

.field public static final block_notice_item_order:I = 0x7f0a0326

.field public static final block_notice_item_title:I = 0x7f0a0327

.field public static final block_notice_title:I = 0x7f0a0328

.field public static final block_oriprice_select_area:I = 0x7f0a0329

.field public static final block_oriprice_select_area_amount:I = 0x7f0a032a

.field public static final block_presalecode_select_area:I = 0x7f0a032b

.field public static final block_presalecode_select_area_amount:I = 0x7f0a032c

.field public static final block_presalecode_select_area_arrow:I = 0x7f0a032d

.field public static final block_presalecode_select_area_price:I = 0x7f0a032e

.field public static final block_reduce_select_area:I = 0x7f0a032f

.field public static final block_sale_select_area:I = 0x7f0a0330

.field public static final block_sale_select_area_used:I = 0x7f0a0331

.field public static final block_special_price_select_area:I = 0x7f0a0332

.field public static final block_total_amount:I = 0x7f0a0333

.field public static final block_total_desc:I = 0x7f0a0334

.field public static final block_total_mcard_amount:I = 0x7f0a0335

.field public static final block_total_title:I = 0x7f0a0336

.field public static final block_unioncard_name:I = 0x7f0a0337

.field public static final block_unioncard_question:I = 0x7f0a0338

.field public static final block_unioncard_select_arrow:I = 0x7f0a0339

.field public static final block_unioncard_select_tips:I = 0x7f0a033a

.field public static final block_unioncard_select_tips_red:I = 0x7f0a033b

.field public static final block_wanna_2_see_icon:I = 0x7f0a033c

.field public static final block_want_see:I = 0x7f0a033d

.field public static final blocking:I = 0x7f0a033f

.field public static final blur_bg:I = 0x7f0a0340

.field public static final blur_bg_static:I = 0x7f0a0341

.field public static final body:I = 0x7f0a0346

.field public static final bogo_desc:I = 0x7f0a0347

.field public static final bolang_view:I = 0x7f0a0348

.field public static final bold:I = 0x7f0a0349

.field public static final border_brand_venue:I = 0x7f0a034c

.field public static final both:I = 0x7f0a034d

.field public static final bottom:I = 0x7f0a034e

.field public static final bottom_bar:I = 0x7f0a0351

.field public static final bottom_bg_layout:I = 0x7f0a0353

.field public static final bottom_btn_container_fl:I = 0x7f0a0354

.field public static final bottom_button:I = 0x7f0a0355

.field public static final bottom_button_line:I = 0x7f0a0356

.field public static final bottom_end_layout:I = 0x7f0a0359

.field public static final bottom_extra_button:I = 0x7f0a035a

.field public static final bottom_first_view:I = 0x7f0a035b

.field public static final bottom_layout:I = 0x7f0a035d

.field public static final bottom_line:I = 0x7f0a035e

.field public static final bottom_of_viewfinder:I = 0x7f0a0360

.field public static final bottom_padding:I = 0x7f0a0361

.field public static final bottom_panel:I = 0x7f0a0362

.field public static final bottom_price_detail_desc:I = 0x7f0a0363

.field public static final bottom_price_down_arrow:I = 0x7f0a0364

.field public static final bottom_purchase:I = 0x7f0a0365

.field public static final bottom_second_view:I = 0x7f0a0366

.field public static final bottom_sheet_menu:I = 0x7f0a0368

.field public static final bottom_sheet_title:I = 0x7f0a0369

.field public static final bottom_space:I = 0x7f0a036a

.field public static final bottom_submit_order:I = 0x7f0a036c

.field public static final bottom_tag:I = 0x7f0a0370

.field public static final bottom_tag_container:I = 0x7f0a0371

.field public static final bottom_third_view:I = 0x7f0a0372

.field public static final bottom_top_shader:I = 0x7f0a0373

.field public static final bottom_total_price:I = 0x7f0a0374

.field public static final bottom_view:I = 0x7f0a0376

.field public static final bottom_zone:I = 0x7f0a0377

.field public static final bounce:I = 0x7f0a0378

.field public static final boxing_office_forecast:I = 0x7f0a037c

.field public static final boxing_office_rank:I = 0x7f0a037d

.field public static final boxing_office_title:I = 0x7f0a037e

.field public static final boxing_office_update_time:I = 0x7f0a037f

.field public static final brand_ablum_pcount:I = 0x7f0a0380

.field public static final brand_ablum_photo:I = 0x7f0a0381

.field public static final brand_ablum_tip:I = 0x7f0a0382

.field public static final brand_and_venue_content_ll:I = 0x7f0a038a

.field public static final brand_and_venue_content_poste_tag:I = 0x7f0a038b

.field public static final brand_and_venue_content_poste_video_tag:I = 0x7f0a038c

.field public static final brand_and_venue_content_poster:I = 0x7f0a038d

.field public static final brand_and_venue_content_title:I = 0x7f0a038e

.field public static final brand_and_venue_fl:I = 0x7f0a038f

.field public static final brand_and_venue_fl_miv:I = 0x7f0a0390

.field public static final brand_and_venue_info:I = 0x7f0a0391

.field public static final brand_and_venue_info_Ll:I = 0x7f0a0392

.field public static final brand_and_venue_info_btn:I = 0x7f0a0393

.field public static final brand_and_venue_info_coupon_container:I = 0x7f0a0394

.field public static final brand_and_venue_info_coupon_desc:I = 0x7f0a0395

.field public static final brand_and_venue_info_coupon_num:I = 0x7f0a0396

.field public static final brand_and_venue_info_coupon_num_pre:I = 0x7f0a0397

.field public static final brand_and_venue_info_coupon_title:I = 0x7f0a0398

.field public static final brand_and_venue_info_logo:I = 0x7f0a0399

.field public static final brand_and_venue_info_title:I = 0x7f0a039a

.field public static final brand_and_venue_item_banner:I = 0x7f0a039b

.field public static final brand_and_venue_project_and_comment_ll:I = 0x7f0a039c

.field public static final brand_and_venue_project_ll:I = 0x7f0a039d

.field public static final brand_and_venue_project_poster:I = 0x7f0a039e

.field public static final brand_and_venue_project_price:I = 0x7f0a039f

.field public static final brand_and_venue_project_price_ll:I = 0x7f0a03a0

.field public static final brand_and_venue_project_price_pre:I = 0x7f0a03a1

.field public static final brand_and_venue_project_title:I = 0x7f0a03a2

.field public static final brand_back:I = 0x7f0a03ad

.field public static final brand_banner:I = 0x7f0a03ae

.field public static final brand_header_back:I = 0x7f0a03b5

.field public static final brand_header_bg:I = 0x7f0a03b6

.field public static final brand_header_bg_1:I = 0x7f0a03b7

.field public static final brand_header_bg_2:I = 0x7f0a03b8

.field public static final brand_header_bg_cover:I = 0x7f0a03b9

.field public static final brand_header_bottombg:I = 0x7f0a03ba

.field public static final brand_header_cardview:I = 0x7f0a03bb

.field public static final brand_header_couponview:I = 0x7f0a03bc

.field public static final brand_header_desc_tag:I = 0x7f0a03be

.field public static final brand_header_img:I = 0x7f0a03c0

.field public static final brand_header_img_shadow:I = 0x7f0a03c1

.field public static final brand_header_indicator:I = 0x7f0a03c2

.field public static final brand_header_player:I = 0x7f0a03c3

.field public static final brand_header_share:I = 0x7f0a03c4

.field public static final brand_header_tv_desc2:I = 0x7f0a03c5

.field public static final brand_header_tv_fans:I = 0x7f0a03c6

.field public static final brand_header_tv_name:I = 0x7f0a03c7

.field public static final brand_header_videotitle:I = 0x7f0a03c8

.field public static final brand_header_videotitle_arrow:I = 0x7f0a03c9

.field public static final brand_header_viewpager:I = 0x7f0a03ca

.field public static final brand_index_headerbg:I = 0x7f0a03cc

.field public static final brand_index_headerbg_shadow:I = 0x7f0a03cd

.field public static final brand_ll_quickreport_more:I = 0x7f0a03d0

.field public static final brand_quickreport_ipuv:I = 0x7f0a03d4

.field public static final brand_quickreport_ipuv_icon:I = 0x7f0a03d5

.field public static final brand_quickreport_item_layout:I = 0x7f0a03d6

.field public static final brand_quickreport_item_layout_fr_shadow:I = 0x7f0a03d7

.field public static final brand_quickreport_layout:I = 0x7f0a03d8

.field public static final brand_quickreport_normal_img:I = 0x7f0a03d9

.field public static final brand_quickreport_normal_item:I = 0x7f0a03da

.field public static final brand_quickreport_special:I = 0x7f0a03db

.field public static final brand_quickreport_special_icon:I = 0x7f0a03dc

.field public static final brand_quickreport_special_img:I = 0x7f0a03dd

.field public static final brand_quickreport_time:I = 0x7f0a03de

.field public static final brand_quickreport_title:I = 0x7f0a03df

.field public static final brand_quickreport_title_layout:I = 0x7f0a03e0

.field public static final brand_quickreport_tv_normal_ipuv:I = 0x7f0a03e1

.field public static final brand_quickreport_tv_normal_title:I = 0x7f0a03e2

.field public static final brand_quickreport_tv_special_ipuv:I = 0x7f0a03e3

.field public static final brand_quickreport_tv_special_title:I = 0x7f0a03e4

.field public static final brand_quickreport_update_time:I = 0x7f0a03e5

.field public static final brand_quickreport_update_time_point:I = 0x7f0a03e6

.field public static final brand_rv:I = 0x7f0a03e7

.field public static final brand_you_proj_memo:I = 0x7f0a03f6

.field public static final brand_you_proj_title:I = 0x7f0a03f7

.field public static final brandip_grade_score:I = 0x7f0a03f8

.field public static final brandip_grade_star:I = 0x7f0a03f9

.field public static final brandip_top_imgbg:I = 0x7f0a03fa

.field public static final brandip_top_imgbg_4:I = 0x7f0a03fb

.field public static final brandip_top_imgbg_bottomshadow:I = 0x7f0a03fc

.field public static final brandip_top_imgbg_cover:I = 0x7f0a03fd

.field public static final brandip_top_imgbg_cover_4:I = 0x7f0a03fe

.field public static final brandip_top_item_desc:I = 0x7f0a03ff

.field public static final brandip_top_item_image:I = 0x7f0a0400

.field public static final brandip_top_item_image1:I = 0x7f0a0401

.field public static final brandip_top_item_image2:I = 0x7f0a0402

.field public static final brandip_top_item_parent:I = 0x7f0a0403

.field public static final brandip_top_item_title:I = 0x7f0a0404

.field public static final bread:I = 0x7f0a0405

.field public static final bricks_artist_shadow:I = 0x7f0a0407

.field public static final bricks_atmosphere_banner_block:I = 0x7f0a0408

.field public static final bricks_atmosphere_banner_block_bottom:I = 0x7f0a0409

.field public static final bricks_atmosphere_banner_block_header:I = 0x7f0a040a

.field public static final bricks_atmosphere_banner_container:I = 0x7f0a040b

.field public static final bricks_ball_flipper:I = 0x7f0a040c

.field public static final bricks_ball_icon:I = 0x7f0a040d

.field public static final bricks_ball_label:I = 0x7f0a040e

.field public static final bricks_ball_label_layout:I = 0x7f0a040f

.field public static final bricks_ball_name:I = 0x7f0a0410

.field public static final bricks_ball_rl_label:I = 0x7f0a0411

.field public static final bricks_ball_text:I = 0x7f0a0412

.field public static final bricks_base_header_left:I = 0x7f0a0413

.field public static final bricks_base_header_title:I = 0x7f0a0414

.field public static final bricks_base_left_icon:I = 0x7f0a0415

.field public static final bricks_btn_go:I = 0x7f0a0416

.field public static final bricks_channel_brand_fans_num:I = 0x7f0a0417

.field public static final bricks_channel_brand_name:I = 0x7f0a0418

.field public static final bricks_channel_brand_project_first:I = 0x7f0a0419

.field public static final bricks_channel_brand_project_poster:I = 0x7f0a041a

.field public static final bricks_channel_brand_project_price:I = 0x7f0a041b

.field public static final bricks_channel_brand_project_second:I = 0x7f0a041c

.field public static final bricks_channel_brand_project_title:I = 0x7f0a041d

.field public static final bricks_channel_brand_right_arrow:I = 0x7f0a041e

.field public static final bricks_channel_brand_tag_img:I = 0x7f0a041f

.field public static final bricks_channel_brand_top_block:I = 0x7f0a0420

.field public static final bricks_channel_grabhot_project_card_view:I = 0x7f0a0421

.field public static final bricks_channel_grabhot_project_switch_container:I = 0x7f0a0422

.field public static final bricks_channel_page_top_block:I = 0x7f0a0423

.field public static final bricks_component_project_nearby_title:I = 0x7f0a0424

.field public static final bricks_component_project_tips:I = 0x7f0a0425

.field public static final bricks_dialog_bottom_action_cancel:I = 0x7f0a0426

.field public static final bricks_dialog_bottom_action_container:I = 0x7f0a0427

.field public static final bricks_dialog_bottom_action_lv:I = 0x7f0a0428

.field public static final bricks_dialog_bottom_action_tel_icon:I = 0x7f0a0429

.field public static final bricks_dialog_bottom_action_tv:I = 0x7f0a042a

.field public static final bricks_dm_common_price_block:I = 0x7f0a042b

.field public static final bricks_dm_common_price_des:I = 0x7f0a042c

.field public static final bricks_dm_common_price_prefix:I = 0x7f0a042d

.field public static final bricks_dm_common_price_suffix:I = 0x7f0a042e

.field public static final bricks_dm_common_price_unknown:I = 0x7f0a042f

.field public static final bricks_fold_text:I = 0x7f0a0430

.field public static final bricks_grab_hot_image:I = 0x7f0a0431

.field public static final bricks_grab_hot_image_artist:I = 0x7f0a0432

.field public static final bricks_grab_hot_image_artistpic:I = 0x7f0a0433

.field public static final bricks_grab_hot_image_artistpic_shell:I = 0x7f0a0434

.field public static final bricks_grab_hot_image_cover:I = 0x7f0a0435

.field public static final bricks_grab_hot_image_name:I = 0x7f0a0436

.field public static final bricks_grab_hot_price_layout:I = 0x7f0a0437

.field public static final bricks_grab_hot_right:I = 0x7f0a0438

.field public static final bricks_grab_hot_subtitle:I = 0x7f0a0439

.field public static final bricks_grab_hot_title:I = 0x7f0a043a

.field public static final bricks_grab_hot_title_grab_tv:I = 0x7f0a043b

.field public static final bricks_grab_hot_title_grab_view:I = 0x7f0a043c

.field public static final bricks_grab_hot_title_item_price:I = 0x7f0a043d

.field public static final bricks_grab_hot_title_price_flag:I = 0x7f0a043e

.field public static final bricks_grab_hot_title_price_label:I = 0x7f0a043f

.field public static final bricks_grab_hot_title_subtitle:I = 0x7f0a0440

.field public static final bricks_grab_hot_title_tags:I = 0x7f0a0441

.field public static final bricks_head_atmosphere_click_area:I = 0x7f0a0442

.field public static final bricks_head_atmosphere_click_area_big:I = 0x7f0a0443

.field public static final bricks_head_atmosphere_click_area_one:I = 0x7f0a0444

.field public static final bricks_head_atmosphere_click_area_two:I = 0x7f0a0445

.field public static final bricks_head_atmosphere_lottie:I = 0x7f0a0446

.field public static final bricks_head_atmosphere_lottie_click:I = 0x7f0a0447

.field public static final bricks_head_atmosphere_pic:I = 0x7f0a0448

.field public static final bricks_head_atmosphere_pic_click:I = 0x7f0a0449

.field public static final bricks_head_layout:I = 0x7f0a044a

.field public static final bricks_horizontal_layout:I = 0x7f0a044b

.field public static final bricks_horizontal_layout_bg:I = 0x7f0a044c

.field public static final bricks_horizontal_layout_more:I = 0x7f0a044d

.field public static final bricks_horizontal_layout_moreimg:I = 0x7f0a044e

.field public static final bricks_horizontal_layout_title:I = 0x7f0a044f

.field public static final bricks_horizontal_layout_top:I = 0x7f0a0450

.field public static final bricks_horizontalraw_layout:I = 0x7f0a0451

.field public static final bricks_hotrecommend_layout:I = 0x7f0a0452

.field public static final bricks_hotrecommend_lottie_layout:I = 0x7f0a0453

.field public static final bricks_hotrecommend_title:I = 0x7f0a0455

.field public static final bricks_hotrecommend_title_flash:I = 0x7f0a0456

.field public static final bricks_icon_holder:I = 0x7f0a0458

.field public static final bricks_id_product_price:I = 0x7f0a0459

.field public static final bricks_id_product_price_bg:I = 0x7f0a045a

.field public static final bricks_id_product_price_end:I = 0x7f0a045b

.field public static final bricks_id_product_price_pic:I = 0x7f0a045d

.field public static final bricks_id_product_price_pre:I = 0x7f0a045e

.field public static final bricks_id_product_price_tag:I = 0x7f0a045f

.field public static final bricks_id_tetris_project_filter_container:I = 0x7f0a0460

.field public static final bricks_id_welfare_bg:I = 0x7f0a0461

.field public static final bricks_id_welfare_desc:I = 0x7f0a0462

.field public static final bricks_id_welfare_img:I = 0x7f0a0463

.field public static final bricks_id_welfare_img_content:I = 0x7f0a0464

.field public static final bricks_id_welfare_img_title:I = 0x7f0a0465

.field public static final bricks_image_item2:I = 0x7f0a0466

.field public static final bricks_item_title_indicator:I = 0x7f0a0467

.field public static final bricks_item_title_indicator_filter:I = 0x7f0a0468

.field public static final bricks_mo_banner_image_view:I = 0x7f0a0469

.field public static final bricks_mo_banner_tag:I = 0x7f0a046a

.field public static final bricks_pioneer_ball_label:I = 0x7f0a046b

.field public static final bricks_pioneer_ball_label_layout:I = 0x7f0a046c

.field public static final bricks_pioneer_ball_rl_label:I = 0x7f0a046d

.field public static final bricks_poster:I = 0x7f0a046e

.field public static final bricks_refresh_layout_footer:I = 0x7f0a046f

.field public static final bricks_refresh_layout_header:I = 0x7f0a0470

.field public static final bricks_richtext_click_more:I = 0x7f0a0471

.field public static final bricks_richtext_recycleview:I = 0x7f0a0472

.field public static final bricks_richtext_title:I = 0x7f0a0473

.field public static final bricks_snapup_title:I = 0x7f0a0474

.field public static final bricks_tile_ranking_text:I = 0x7f0a0475

.field public static final bricks_tv_project_num:I = 0x7f0a0476

.field public static final bricks_tv_see_people_num:I = 0x7f0a0477

.field public static final bricks_tv_subtitle:I = 0x7f0a0478

.field public static final bricks_tv_title:I = 0x7f0a0479

.field public static final bricks_welfare_layout:I = 0x7f0a047a

.field public static final bricks_welfare_title:I = 0x7f0a047b

.field public static final bricks_wish_container_rect:I = 0x7f0a047c

.field public static final bricks_wish_item_view_container:I = 0x7f0a047d

.field public static final bricks_wish_shadow_offset:I = 0x7f0a047e

.field public static final bricks_wish_shadow_view:I = 0x7f0a047f

.field public static final broadcast_block_want_see_iv:I = 0x7f0a0480

.field public static final broadcast_container:I = 0x7f0a0481

.field public static final broadcast_container_card:I = 0x7f0a0482

.field public static final browser_fragment_layout:I = 0x7f0a0483

.field public static final btnAgree:I = 0x7f0a0484

.field public static final btnCancel:I = 0x7f0a0485

.field public static final btnConfirm:I = 0x7f0a0486

.field public static final btnShare:I = 0x7f0a0487

.field public static final btn_action:I = 0x7f0a0488

.field public static final btn_address_submit:I = 0x7f0a048a

.field public static final btn_album:I = 0x7f0a048b

.field public static final btn_back:I = 0x7f0a048c

.field public static final btn_buy:I = 0x7f0a048d

.field public static final btn_buy_bottom_div:I = 0x7f0a048e

.field public static final btn_buy_bottom_div_line:I = 0x7f0a048f

.field public static final btn_buy_upcoming:I = 0x7f0a0490

.field public static final btn_buy_view:I = 0x7f0a0491

.field public static final btn_buy_waiting:I = 0x7f0a0492

.field public static final btn_buy_waiting_tip:I = 0x7f0a0493

.field public static final btn_call:I = 0x7f0a0494

.field public static final btn_cancel:I = 0x7f0a0495

.field public static final btn_cancel_reservation:I = 0x7f0a0496

.field public static final btn_cancle:I = 0x7f0a0497

.field public static final btn_close:I = 0x7f0a0499

.field public static final btn_confirm:I = 0x7f0a049a

.field public static final btn_exchange:I = 0x7f0a049c

.field public static final btn_exchange_ext:I = 0x7f0a049d

.field public static final btn_exchange_ext_with_reminder:I = 0x7f0a049e

.field public static final btn_exchange_reminder_cancel_submit:I = 0x7f0a049f

.field public static final btn_exchange_reminder_submit:I = 0x7f0a04a0

.field public static final btn_exchange_with_reminder:I = 0x7f0a04a1

.field public static final btn_folder:I = 0x7f0a04a2

.field public static final btn_go:I = 0x7f0a04a4

.field public static final btn_go_my_calendar:I = 0x7f0a04a6

.field public static final btn_go_v2:I = 0x7f0a04a7

.field public static final btn_icon:I = 0x7f0a04a9

.field public static final btn_icon_container:I = 0x7f0a04aa

.field public static final btn_iknow:I = 0x7f0a04ab

.field public static final btn_integral_convert:I = 0x7f0a04ac

.field public static final btn_integral_des:I = 0x7f0a04ad

.field public static final btn_integral_value:I = 0x7f0a04ae

.field public static final btn_left:I = 0x7f0a04b1

.field public static final btn_mute:I = 0x7f0a04b2

.field public static final btn_open_date:I = 0x7f0a04b3

.field public static final btn_operation:I = 0x7f0a04b4

.field public static final btn_other:I = 0x7f0a04b6

.field public static final btn_pay:I = 0x7f0a04b7

.field public static final btn_play:I = 0x7f0a04ba

.field public static final btn_preview:I = 0x7f0a04bb

.field public static final btn_refresh:I = 0x7f0a04bc

.field public static final btn_right:I = 0x7f0a04bd

.field public static final btn_share_icon:I = 0x7f0a04c3

.field public static final btn_spring_open_card_refresh:I = 0x7f0a04c5

.field public static final btn_submit:I = 0x7f0a04c6

.field public static final btn_txt:I = 0x7f0a04c7

.field public static final btn_waiting_left1:I = 0x7f0a04c9

.field public static final btn_waiting_left2:I = 0x7f0a04ca

.field public static final btn_waiting_right1:I = 0x7f0a04cb

.field public static final btn_waiting_right2:I = 0x7f0a04cc

.field public static final btn_zone:I = 0x7f0a04ce

.field public static final btnbolck_waiting_left:I = 0x7f0a04cf

.field public static final btnbolck_waiting_right:I = 0x7f0a04d0

.field public static final bubble:I = 0x7f0a04d1

.field public static final buttomButtonView:I = 0x7f0a04d3

.field public static final buttom_margin:I = 0x7f0a04d4

.field public static final buttom_view:I = 0x7f0a04d5

.field public static final buttonPanel:I = 0x7f0a04d6

.field public static final button_container:I = 0x7f0a04d7

.field public static final button_divider:I = 0x7f0a04d8

.field public static final button_line:I = 0x7f0a04d9

.field public static final button_split_line:I = 0x7f0a04da

.field public static final buy:I = 0x7f0a04db

.field public static final buy_btn:I = 0x7f0a04dc

.field public static final buy_card_edit_phone:I = 0x7f0a04dd

.field public static final buy_card_phone:I = 0x7f0a04de

.field public static final buy_ticket_action_title:I = 0x7f0a04df

.field public static final buy_ticket_text:I = 0x7f0a04e0

.field public static final buy_zone:I = 0x7f0a04e1

.field public static final buynow_add:I = 0x7f0a04e2

.field public static final buynow_close:I = 0x7f0a04e3

.field public static final buynow_num:I = 0x7f0a04e4

.field public static final buynow_plus:I = 0x7f0a04e5

.field public static final buynow_sub:I = 0x7f0a04e6

.field public static final bv_special_tag:I = 0x7f0a04e7

.field public static final ca_fragment_container:I = 0x7f0a04e8

.field public static final calendarView:I = 0x7f0a04ea

.field public static final calendar_clickview:I = 0x7f0a04eb

.field public static final calendar_day_tip:I = 0x7f0a04ed

.field public static final calendar_day_tip_arrow:I = 0x7f0a04ee

.field public static final calendar_day_tip_rl:I = 0x7f0a04ef

.field public static final calendar_out_container:I = 0x7f0a04f0

.field public static final calendar_top_padding:I = 0x7f0a04f1

.field public static final calendar_view:I = 0x7f0a04f2

.field public static final callMeasure:I = 0x7f0a04f3

.field public static final can_buy_txt:I = 0x7f0a04f7

.field public static final cancel:I = 0x7f0a04f8

.field public static final cancelBtn:I = 0x7f0a04f9

.field public static final cancel_action:I = 0x7f0a04fa

.field public static final cancel_btn:I = 0x7f0a04fb

.field public static final cancel_button:I = 0x7f0a04fc

.field public static final cancel_reason_list_layout:I = 0x7f0a04fd

.field public static final cancel_text:I = 0x7f0a04fe

.field public static final cancel_vote:I = 0x7f0a04ff

.field public static final cancle:I = 0x7f0a0500

.field public static final cancle_btn:I = 0x7f0a0501

.field public static final capture_flashlight:I = 0x7f0a0502

.field public static final card_benefits:I = 0x7f0a0504

.field public static final card_bg:I = 0x7f0a0505

.field public static final card_box:I = 0x7f0a0506

.field public static final card_brand_normal_item_black_holder:I = 0x7f0a0507

.field public static final card_brand_normal_item_one:I = 0x7f0a0508

.field public static final card_brand_normal_item_two:I = 0x7f0a0509

.field public static final card_container:I = 0x7f0a050a

.field public static final card_icon:I = 0x7f0a050c

.field public static final card_item:I = 0x7f0a050d

.field public static final card_list_container:I = 0x7f0a050e

.field public static final card_list_container_noscroll:I = 0x7f0a050f

.field public static final card_list_wrap:I = 0x7f0a0510

.field public static final card_period:I = 0x7f0a0511

.field public static final card_price_dash_line:I = 0x7f0a0512

.field public static final card_show_all_arrow:I = 0x7f0a0514

.field public static final card_show_all_subtitle:I = 0x7f0a0515

.field public static final card_show_all_ui:I = 0x7f0a0516

.field public static final card_text:I = 0x7f0a0517

.field public static final card_title:I = 0x7f0a0518

.field public static final card_title_latestnews:I = 0x7f0a0519

.field public static final card_title_layout:I = 0x7f0a051a

.field public static final card_use_guide:I = 0x7f0a051d

.field public static final card_use_tips:I = 0x7f0a051e

.field public static final card_use_tips_container:I = 0x7f0a051f

.field public static final card_view:I = 0x7f0a0520

.field public static final cardview_movie_layout:I = 0x7f0a0521

.field public static final carryVelocity:I = 0x7f0a0522

.field public static final cash_back_amount:I = 0x7f0a0523

.field public static final cash_back_amount_container:I = 0x7f0a0524

.field public static final cash_back_animation_view:I = 0x7f0a0525

.field public static final cash_back_summary:I = 0x7f0a0526

.field public static final cash_back_unit:I = 0x7f0a0527

.field public static final cate_text_div:I = 0x7f0a0528

.field public static final cate_text_tv:I = 0x7f0a0529

.field public static final category_ball_container:I = 0x7f0a052a

.field public static final category_ball_container_label:I = 0x7f0a052b

.field public static final category_ball_container_rl_label:I = 0x7f0a052c

.field public static final category_icon_line:I = 0x7f0a0530

.field public static final category_icon_pic:I = 0x7f0a0531

.field public static final category_icon_title_bottom:I = 0x7f0a0532

.field public static final category_icon_title_bottom_pioneer:I = 0x7f0a0533

.field public static final category_icon_title_left:I = 0x7f0a0534

.field public static final category_item_label:I = 0x7f0a0536

.field public static final cb_fission_scrollview:I = 0x7f0a053a

.field public static final cb_ll_member_auth:I = 0x7f0a053b

.field public static final cb_main_message:I = 0x7f0a053c

.field public static final cb_my_invite_content:I = 0x7f0a053e

.field public static final cb_placeholer_bg:I = 0x7f0a0540

.field public static final cb_sub_message:I = 0x7f0a0541

.field public static final cb_title_bar_space_view:I = 0x7f0a0542

.field public static final cb_title_left_icon:I = 0x7f0a0543

.field public static final cb_title_text_url:I = 0x7f0a0544

.field public static final cb_user_icon:I = 0x7f0a0545

.field public static final cb_user_layout:I = 0x7f0a0546

.field public static final cb_user_name:I = 0x7f0a0547

.field public static final cd_fission_viewpager:I = 0x7f0a0548

.field public static final center:I = 0x7f0a0549

.field public static final centerBottom:I = 0x7f0a054a

.field public static final centerCrop:I = 0x7f0a054b

.field public static final centerInside:I = 0x7f0a054c

.field public static final centerTop:I = 0x7f0a054d

.field public static final center_crop:I = 0x7f0a054e

.field public static final center_horizontal:I = 0x7f0a054f

.field public static final center_inside:I = 0x7f0a0550

.field public static final center_vertical:I = 0x7f0a0551

.field public static final centre:I = 0x7f0a0552

.field public static final cert_info_tag_layout:I = 0x7f0a0554

.field public static final certificate_typename:I = 0x7f0a0555

.field public static final chain:I = 0x7f0a0556

.field public static final chain2:I = 0x7f0a0557

.field public static final chains:I = 0x7f0a0558

.field public static final change_hint_first:I = 0x7f0a0559

.field public static final change_hint_second:I = 0x7f0a055a

.field public static final change_privileged_audience_btn:I = 0x7f0a055c

.field public static final change_with_attribute:I = 0x7f0a055d

.field public static final channel_artist_active_task_count_down:I = 0x7f0a055f

.field public static final channel_artist_active_task_count_down_block:I = 0x7f0a0560

.field public static final channel_artist_active_task_count_down_pre:I = 0x7f0a0561

.field public static final channel_artist_active_task_des:I = 0x7f0a0562

.field public static final channel_artist_active_task_image:I = 0x7f0a0563

.field public static final channel_artist_active_task_info_block:I = 0x7f0a0564

.field public static final channel_artist_active_task_info_block_left:I = 0x7f0a0565

.field public static final channel_artist_active_task_item_divider:I = 0x7f0a0566

.field public static final channel_artist_active_task_item_first:I = 0x7f0a0567

.field public static final channel_artist_active_task_item_second:I = 0x7f0a0568

.field public static final channel_artist_active_task_status_des:I = 0x7f0a0569

.field public static final channel_artist_active_task_title:I = 0x7f0a056a

.field public static final channel_artist_task_item_btn:I = 0x7f0a056b

.field public static final channel_artist_task_item_btn_block:I = 0x7f0a056c

.field public static final channel_artist_task_item_btn_loading:I = 0x7f0a056d

.field public static final channel_artist_task_item_progress:I = 0x7f0a056e

.field public static final channel_artist_task_item_subtitle:I = 0x7f0a056f

.field public static final channel_artist_task_item_title:I = 0x7f0a0570

.field public static final channel_brand_and_venue_card_title:I = 0x7f0a0571

.field public static final channel_fragment_container:I = 0x7f0a0578

.field public static final channel_grab_content_text:I = 0x7f0a0579

.field public static final channel_grab_fl:I = 0x7f0a057a

.field public static final channel_grab_highlight_content_text:I = 0x7f0a057b

.field public static final channel_grab_hot_image:I = 0x7f0a057c

.field public static final channel_grab_hot_image_artist:I = 0x7f0a057d

.field public static final channel_grab_hot_image_artistpic:I = 0x7f0a057e

.field public static final channel_grab_hot_image_artistpic_shell:I = 0x7f0a057f

.field public static final channel_grab_hot_image_name:I = 0x7f0a0580

.field public static final channel_grab_lottie_layout:I = 0x7f0a0581

.field public static final channel_grab_main_info:I = 0x7f0a0582

.field public static final channel_grab_name:I = 0x7f0a0583

.field public static final channel_grab_price:I = 0x7f0a0584

.field public static final channel_grab_price_custom:I = 0x7f0a0585

.field public static final channel_grab_price_fl:I = 0x7f0a0586

.field public static final channel_grab_price_miss:I = 0x7f0a0587

.field public static final channel_grab_subtitle_content:I = 0x7f0a0588

.field public static final channel_grab_want_watch_num:I = 0x7f0a0589

.field public static final channel_grab_want_watch_num_suffix:I = 0x7f0a058a

.field public static final channel_header_back:I = 0x7f0a058b

.field public static final channel_header_bar:I = 0x7f0a058c

.field public static final channel_header_container:I = 0x7f0a058d

.field public static final channel_header_search:I = 0x7f0a058e

.field public static final channel_header_search_btn:I = 0x7f0a058f

.field public static final channel_header_search_layout:I = 0x7f0a0590

.field public static final channel_id_stl:I = 0x7f0a0591

.field public static final channel_item_tag_view:I = 0x7f0a0592

.field public static final channel_search_text:I = 0x7f0a0593

.field public static final channel_venue_bg_poster:I = 0x7f0a0594

.field public static final channel_venue_card_cover_block:I = 0x7f0a0595

.field public static final channel_venue_card_cover_bottom:I = 0x7f0a0596

.field public static final channel_venue_card_cover_top:I = 0x7f0a0597

.field public static final channel_venue_coupon_info_block:I = 0x7f0a0598

.field public static final channel_venue_coupon_price:I = 0x7f0a0599

.field public static final channel_venue_coupon_price_block:I = 0x7f0a059a

.field public static final channel_venue_coupon_price_prefix:I = 0x7f0a059b

.field public static final channel_venue_coupon_sub_title:I = 0x7f0a059c

.field public static final channel_venue_detail_info_block:I = 0x7f0a059d

.field public static final channel_venue_info_block:I = 0x7f0a059e

.field public static final channel_venue_info_divider:I = 0x7f0a059f

.field public static final channel_venue_info_fans_num:I = 0x7f0a05a0

.field public static final channel_venue_info_fans_num_suffix:I = 0x7f0a05a1

.field public static final channel_venue_info_showing_num:I = 0x7f0a05a2

.field public static final channel_venue_info_showing_num_suffix:I = 0x7f0a05a3

.field public static final channel_venue_name:I = 0x7f0a05a4

.field public static final channel_venue_showing_posters:I = 0x7f0a05a5

.field public static final charge_price:I = 0x7f0a05a6

.field public static final chargecard_item:I = 0x7f0a05a7

.field public static final chargecard_open_switch:I = 0x7f0a05a8

.field public static final chargecard_zone:I = 0x7f0a05a9

.field public static final check:I = 0x7f0a05aa

.field public static final check_film_wanted:I = 0x7f0a05ab

.field public static final check_login_loading:I = 0x7f0a05ac

.field public static final check_youku_wanted:I = 0x7f0a05ad

.field public static final checkbox:I = 0x7f0a05ae

.field public static final checkbox_bg:I = 0x7f0a05af

.field public static final checked:I = 0x7f0a05b0

.field public static final chip:I = 0x7f0a05b9

.field public static final chip1:I = 0x7f0a05ba

.field public static final chip2:I = 0x7f0a05bb

.field public static final chip3:I = 0x7f0a05bc

.field public static final chip_group:I = 0x7f0a05bd

.field public static final choose_from_first:I = 0x7f0a05bf

.field public static final choose_from_second:I = 0x7f0a05c0

.field public static final chronometer:I = 0x7f0a05c6

.field public static final cinemaFeatureContainer:I = 0x7f0a05c7

.field public static final cinema_activity_action:I = 0x7f0a05c8

.field public static final cinema_activity_action_desc:I = 0x7f0a05c9

.field public static final cinema_activity_content:I = 0x7f0a05ca

.field public static final cinema_activity_tag_container:I = 0x7f0a05cb

.field public static final cinema_activity_tip:I = 0x7f0a05cc

.field public static final cinema_activity_tip_text:I = 0x7f0a05cd

.field public static final cinema_activity_title:I = 0x7f0a05ce

.field public static final cinema_arrow:I = 0x7f0a05cf

.field public static final cinema_background_image:I = 0x7f0a05d0

.field public static final cinema_background_image_cover:I = 0x7f0a05d1

.field public static final cinema_card_view:I = 0x7f0a05d2

.field public static final cinema_card_view_space_holder:I = 0x7f0a05d3

.field public static final cinema_distance_mall_metro_des:I = 0x7f0a05d4

.field public static final cinema_distance_mall_metro_des_container:I = 0x7f0a05d5

.field public static final cinema_distance_mall_metro_des_icon:I = 0x7f0a05d6

.field public static final cinema_element_name:I = 0x7f0a05d7

.field public static final cinema_filter:I = 0x7f0a05d8

.field public static final cinema_filter_item:I = 0x7f0a05d9

.field public static final cinema_function_tag_container:I = 0x7f0a05da

.field public static final cinema_info_block:I = 0x7f0a05db

.field public static final cinema_item_favorite_cover:I = 0x7f0a05dc

.field public static final cinema_item_favorite_view:I = 0x7f0a05dd

.field public static final cinema_language_recycle:I = 0x7f0a05de

.field public static final cinema_language_txt:I = 0x7f0a05df

.field public static final cinema_list_item_buyone_giveone_decorate:I = 0x7f0a05e0

.field public static final cinema_list_item_buyone_giveone_tag:I = 0x7f0a05e1

.field public static final cinema_list_item_buyone_giveone_tip:I = 0x7f0a05e2

.field public static final cinema_list_item_decoration_root:I = 0x7f0a05e3

.field public static final cinema_more_txt:I = 0x7f0a05e4

.field public static final cinema_name:I = 0x7f0a05e5

.field public static final cinema_offline_status:I = 0x7f0a05e6

.field public static final cinema_root_view:I = 0x7f0a05e7

.field public static final cinema_service_arrow:I = 0x7f0a05e8

.field public static final cinema_service_more_txt:I = 0x7f0a05e9

.field public static final cinema_service_recycle:I = 0x7f0a05ea

.field public static final cinema_service_txt:I = 0x7f0a05eb

.field public static final cinema_tip_intro_content:I = 0x7f0a05ec

.field public static final cinema_type_recycle:I = 0x7f0a05ed

.field public static final cinema_type_txt:I = 0x7f0a05ee

.field public static final cinemas_state_layout:I = 0x7f0a05fc

.field public static final circle:I = 0x7f0a05fd

.field public static final circleBig:I = 0x7f0a05fe

.field public static final circleIndicator:I = 0x7f0a05ff

.field public static final circleRect:I = 0x7f0a0600

.field public static final circle_avatar_holder:I = 0x7f0a0601

.field public static final circle_avatar_list_layout:I = 0x7f0a0602

.field public static final circle_card_img_item_img:I = 0x7f0a0603

.field public static final circle_card_layout:I = 0x7f0a0604

.field public static final circle_center:I = 0x7f0a0605

.field public static final circle_content_list:I = 0x7f0a0606

.field public static final circle_hor_list:I = 0x7f0a0607

.field public static final circle_page_indicator:I = 0x7f0a0609

.field public static final circle_pic_img:I = 0x7f0a060a

.field public static final circle_pic_video_icon:I = 0x7f0a060b

.field public static final circle_user_head_icon:I = 0x7f0a060c

.field public static final circle_user_head_layout:I = 0x7f0a060d

.field public static final circular_bubble:I = 0x7f0a060e

.field public static final city_base_view:I = 0x7f0a060f

.field public static final city_card_action_btn:I = 0x7f0a0610

.field public static final city_card_center:I = 0x7f0a0611

.field public static final city_card_city_add_tv:I = 0x7f0a0612

.field public static final city_card_city_distance_tv:I = 0x7f0a0613

.field public static final city_card_city_name_tv:I = 0x7f0a0614

.field public static final city_card_lottie:I = 0x7f0a0615

.field public static final city_card_rl:I = 0x7f0a0616

.field public static final city_card_time_line_desc:I = 0x7f0a0617

.field public static final city_card_top_tag:I = 0x7f0a0618

.field public static final city_cluster_select_list:I = 0x7f0a0619

.field public static final city_cluster_select_list_stick_title_block:I = 0x7f0a061a

.field public static final city_lay:I = 0x7f0a061b

.field public static final city_list_close:I = 0x7f0a061c

.field public static final city_list_title:I = 0x7f0a061d

.field public static final city_list_view:I = 0x7f0a061e

.field public static final city_name:I = 0x7f0a061f

.field public static final city_pass_activity:I = 0x7f0a0620

.field public static final city_pass_close:I = 0x7f0a0621

.field public static final city_pass_continue:I = 0x7f0a0622

.field public static final city_pass_desc:I = 0x7f0a0623

.field public static final city_pass_desc1:I = 0x7f0a0624

.field public static final city_pass_desc2:I = 0x7f0a0625

.field public static final city_pass_desc3:I = 0x7f0a0626

.field public static final city_pass_header:I = 0x7f0a0627

.field public static final city_pass_icon:I = 0x7f0a0628

.field public static final city_pass_line:I = 0x7f0a0629

.field public static final city_pass_title:I = 0x7f0a062a

.field public static final city_pass_view:I = 0x7f0a062b

.field public static final city_search_list:I = 0x7f0a062e

.field public static final city_search_result_ll:I = 0x7f0a062f

.field public static final city_select_cancel:I = 0x7f0a0630

.field public static final city_select_list:I = 0x7f0a0631

.field public static final city_select_navtitle:I = 0x7f0a0632

.field public static final city_select_sort_letter:I = 0x7f0a0633

.field public static final city_select_title:I = 0x7f0a0634

.field public static final clSeatView:I = 0x7f0a0636

.field public static final cl_exchange:I = 0x7f0a0637

.field public static final cl_exchange_with_reminder:I = 0x7f0a0638

.field public static final cl_layout:I = 0x7f0a063b

.field public static final cl_open_card_loading_contain:I = 0x7f0a063c

.field public static final cl_pay_card:I = 0x7f0a063d

.field public static final cl_recommend_sale:I = 0x7f0a063e

.field public static final cl_root:I = 0x7f0a063f

.field public static final cl_ticket_remind_content:I = 0x7f0a0641

.field public static final classics_arrow:I = 0x7f0a0642

.field public static final clear_btn:I = 0x7f0a0643

.field public static final clear_search_history:I = 0x7f0a0644

.field public static final clear_text:I = 0x7f0a0645

.field public static final clear_tv:I = 0x7f0a0646

.field public static final click_area:I = 0x7f0a0647

.field public static final clip:I = 0x7f0a0648

.field public static final clip_horizontal:I = 0x7f0a0649

.field public static final clip_vertical:I = 0x7f0a064a

.field public static final clockwise:I = 0x7f0a064c

.field public static final close:I = 0x7f0a064d

.field public static final close_arrow:I = 0x7f0a064e

.field public static final close_btn:I = 0x7f0a064f

.field public static final close_button:I = 0x7f0a0650

.field public static final close_order_cancel:I = 0x7f0a0652

.field public static final close_order_message:I = 0x7f0a0653

.field public static final close_order_ok:I = 0x7f0a0654

.field public static final close_tv:I = 0x7f0a0655

.field public static final close_view:I = 0x7f0a0656

.field public static final close_window:I = 0x7f0a0657

.field public static final closest:I = 0x7f0a0658

.field public static final code:I = 0x7f0a0659

.field public static final code_et:I = 0x7f0a065a

.field public static final code_layout:I = 0x7f0a065b

.field public static final collapseActionView:I = 0x7f0a065c

.field public static final color_title:I = 0x7f0a0660

.field public static final color_white:I = 0x7f0a0661

.field public static final color_yellow:I = 0x7f0a0662

.field public static final column:I = 0x7f0a0664

.field public static final column_reverse:I = 0x7f0a0666

.field public static final combolist:I = 0x7f0a0667

.field public static final combolist_recyclerview:I = 0x7f0a0668

.field public static final comment:I = 0x7f0a0669

.field public static final comment_1_ui:I = 0x7f0a066a

.field public static final comment_2_ui:I = 0x7f0a066b

.field public static final comment_3_ui:I = 0x7f0a066c

.field public static final comment_banner_left_img:I = 0x7f0a066e

.field public static final comment_banner_right_img:I = 0x7f0a066f

.field public static final comment_banner_subtitle:I = 0x7f0a0670

.field public static final comment_banner_title:I = 0x7f0a0671

.field public static final comment_bottom_layout:I = 0x7f0a0672

.field public static final comment_content:I = 0x7f0a0676

.field public static final comment_content_wrapper:I = 0x7f0a0677

.field public static final comment_date_city:I = 0x7f0a067a

.field public static final comment_date_indetail:I = 0x7f0a067b

.field public static final comment_detail_comment_delete:I = 0x7f0a067c

.field public static final comment_detail_maincomment_more:I = 0x7f0a067e

.field public static final comment_empty_bg:I = 0x7f0a0681

.field public static final comment_empty_text:I = 0x7f0a0682

.field public static final comment_exception_text:I = 0x7f0a0683

.field public static final comment_film_actor:I = 0x7f0a0684

.field public static final comment_film_container:I = 0x7f0a0685

.field public static final comment_film_image:I = 0x7f0a0686

.field public static final comment_film_name:I = 0x7f0a0687

.field public static final comment_film_viewstub:I = 0x7f0a0688

.field public static final comment_has_played_icon:I = 0x7f0a068b

.field public static final comment_help_container:I = 0x7f0a068d

.field public static final comment_hl_avatar:I = 0x7f0a068e

.field public static final comment_hl_avatar_anim:I = 0x7f0a068f

.field public static final comment_hl_content:I = 0x7f0a0690

.field public static final comment_hl_content_flipper1:I = 0x7f0a0691

.field public static final comment_hl_content_flipper2:I = 0x7f0a0692

.field public static final comment_hl_content_pics:I = 0x7f0a0693

.field public static final comment_hl_content_pics_v2:I = 0x7f0a0694

.field public static final comment_hl_myavatar:I = 0x7f0a0695

.field public static final comment_hl_praise_layout:I = 0x7f0a0696

.field public static final comment_hl_themetitle:I = 0x7f0a0697

.field public static final comment_hl_title:I = 0x7f0a0698

.field public static final comment_hl_username:I = 0x7f0a0699

.field public static final comment_item:I = 0x7f0a069a

.field public static final comment_keyword_block:I = 0x7f0a069d

.field public static final comment_layout:I = 0x7f0a069e

.field public static final comment_like_layout:I = 0x7f0a069f

.field public static final comment_like_num:I = 0x7f0a06a0

.field public static final comment_like_numicon:I = 0x7f0a06a1

.field public static final comment_list_title:I = 0x7f0a06a4

.field public static final comment_magic_tag_viewstub:I = 0x7f0a06a5

.field public static final comment_num:I = 0x7f0a06a6

.field public static final comment_num_reply:I = 0x7f0a06a7

.field public static final comment_praise_layout:I = 0x7f0a06a8

.field public static final comment_reply_content_et:I = 0x7f0a06af

.field public static final comment_reply_contentll:I = 0x7f0a06b0

.field public static final comment_reply_layout:I = 0x7f0a06b3

.field public static final comment_reply_txt:I = 0x7f0a06b5

.field public static final comment_score:I = 0x7f0a06b6

.field public static final comment_share_content_layout:I = 0x7f0a06b7

.field public static final comment_share_white_bg:I = 0x7f0a06b8

.field public static final comment_tag_container:I = 0x7f0a06ba

.field public static final comment_tag_image:I = 0x7f0a06bb

.field public static final comment_tag_sub_text:I = 0x7f0a06bc

.field public static final comment_tag_text:I = 0x7f0a06bd

.field public static final comment_title:I = 0x7f0a06be

.field public static final comment_user_name:I = 0x7f0a06c0

.field public static final comment_userinfo_layout:I = 0x7f0a06c1

.field public static final comment_userinfo_view:I = 0x7f0a06c2

.field public static final comment_vip_icon:I = 0x7f0a06c4

.field public static final common_account_list:I = 0x7f0a06c5

.field public static final common_account_title:I = 0x7f0a06c6

.field public static final common_banner_view_bg:I = 0x7f0a06c7

.field public static final common_banner_view_play:I = 0x7f0a06c8

.field public static final common_business_add_address_title_left_tv:I = 0x7f0a06c9

.field public static final common_business_add_address_title_lv:I = 0x7f0a06ca

.field public static final common_business_add_address_title_main_tv:I = 0x7f0a06cb

.field public static final common_business_add_address_title_right_tv:I = 0x7f0a06cc

.field public static final common_business_area_code_container_lv:I = 0x7f0a06cd

.field public static final common_business_area_code_indicator_tv:I = 0x7f0a06ce

.field public static final common_business_area_code_tv:I = 0x7f0a06cf

.field public static final common_business_choose_consignee_tv:I = 0x7f0a06d0

.field public static final common_business_city_wheel_view:I = 0x7f0a06d1

.field public static final common_business_clear_consignee_detail_address_iv:I = 0x7f0a06d2

.field public static final common_business_clear_consignee_name_iv:I = 0x7f0a06d3

.field public static final common_business_clear_consignee_phone_iv:I = 0x7f0a06d4

.field public static final common_business_consignee_detail_address_et:I = 0x7f0a06d5

.field public static final common_business_consignee_name_et:I = 0x7f0a06d6

.field public static final common_business_consignee_name_text:I = 0x7f0a06d7

.field public static final common_business_consignee_phone_et:I = 0x7f0a06d8

.field public static final common_business_consignee_phone_text:I = 0x7f0a06d9

.field public static final common_business_consignee_region_indicator:I = 0x7f0a06da

.field public static final common_business_consignee_region_text:I = 0x7f0a06db

.field public static final common_business_consignee_region_tv:I = 0x7f0a06dc

.field public static final common_business_consignee_street_indicator:I = 0x7f0a06dd

.field public static final common_business_consignee_street_text:I = 0x7f0a06de

.field public static final common_business_consignee_street_tv:I = 0x7f0a06df

.field public static final common_business_county_wheel_view:I = 0x7f0a06e0

.field public static final common_business_detail_address_text:I = 0x7f0a06e1

.field public static final common_business_division_select_cancel_tv:I = 0x7f0a06e2

.field public static final common_business_division_select_completed_tv:I = 0x7f0a06e3

.field public static final common_business_province_wheel_view:I = 0x7f0a06e4

.field public static final common_business_street_select_cancel_tv:I = 0x7f0a06e5

.field public static final common_business_street_select_completed_tv:I = 0x7f0a06e6

.field public static final common_business_street_wheel_view:I = 0x7f0a06e7

.field public static final common_card_bottom_text:I = 0x7f0a06e8

.field public static final common_card_desc_info:I = 0x7f0a06e9

.field public static final common_card_desc_info2:I = 0x7f0a06ea

.field public static final common_card_top_flag:I = 0x7f0a06eb

.field public static final common_card_top_info:I = 0x7f0a06ec

.field public static final common_card_top_value:I = 0x7f0a06ed

.field public static final common_card_top_vv:I = 0x7f0a06ee

.field public static final common_comment_block:I = 0x7f0a06ef

.field public static final common_comment_content:I = 0x7f0a06f0

.field public static final common_comment_content_img_center:I = 0x7f0a06f1

.field public static final common_comment_content_img_count:I = 0x7f0a06f2

.field public static final common_comment_content_img_left:I = 0x7f0a06f3

.field public static final common_comment_content_img_right:I = 0x7f0a06f4

.field public static final common_comment_content_imglist_viewstub:I = 0x7f0a06f5

.field public static final common_comment_favor_btn:I = 0x7f0a06f6

.field public static final common_comment_favor_count:I = 0x7f0a06f7

.field public static final common_comment_item:I = 0x7f0a06f8

.field public static final common_comment_location:I = 0x7f0a06f9

.field public static final common_comment_new_favor_btn:I = 0x7f0a06fa

.field public static final common_comment_reply_btn:I = 0x7f0a06fb

.field public static final common_comment_reply_count:I = 0x7f0a06fc

.field public static final common_comment_time:I = 0x7f0a06fd

.field public static final common_comment_user:I = 0x7f0a06fe

.field public static final common_exptext_btn:I = 0x7f0a06ff

.field public static final common_exptext_content:I = 0x7f0a0700

.field public static final common_exptext_cover:I = 0x7f0a0701

.field public static final common_exptext_title:I = 0x7f0a0702

.field public static final common_header_info:I = 0x7f0a0703

.field public static final common_img_count_info:I = 0x7f0a0704

.field public static final common_img_count_info_title:I = 0x7f0a0705

.field public static final common_module_title_container:I = 0x7f0a0706

.field public static final common_navbar_back:I = 0x7f0a0707

.field public static final common_navbar_info_desc:I = 0x7f0a0708

.field public static final common_navbar_info_flipper:I = 0x7f0a0709

.field public static final common_navbar_info_title:I = 0x7f0a070a

.field public static final common_navbar_infoll:I = 0x7f0a070b

.field public static final common_reply_content:I = 0x7f0a070c

.field public static final common_reply_nickname:I = 0x7f0a070d

.field public static final common_search_edit_text:I = 0x7f0a070e

.field public static final common_search_edit_text_clear:I = 0x7f0a070f

.field public static final common_search_func_btn:I = 0x7f0a0710

.field public static final common_sub_title:I = 0x7f0a0711

.field public static final common_title:I = 0x7f0a0712

.field public static final common_title_morell:I = 0x7f0a0713

.field public static final common_title_morell_tv:I = 0x7f0a0714

.field public static final common_toast_image:I = 0x7f0a0715

.field public static final common_toast_text:I = 0x7f0a0716

.field public static final common_toast_text_dialog:I = 0x7f0a0717

.field public static final common_top_banner_bottombg:I = 0x7f0a0718

.field public static final common_top_banner_container:I = 0x7f0a0719

.field public static final common_top_space:I = 0x7f0a071a

.field public static final compat_elevation:I = 0x7f0a0752

.field public static final compilation_btn:I = 0x7f0a0753

.field public static final complete:I = 0x7f0a0754

.field public static final component_common_gaiax_layout:I = 0x7f0a0755

.field public static final component_sticky_tab_layout:I = 0x7f0a0756

.field public static final component_tab_layout:I = 0x7f0a0757

.field public static final compose_view_saveable_id_tag:I = 0x7f0a0759

.field public static final compress:I = 0x7f0a075a

.field public static final conditional_rule_current_tag:I = 0x7f0a0762

.field public static final conditional_rule_des:I = 0x7f0a0763

.field public static final conditional_rule_single_des:I = 0x7f0a0764

.field public static final conditional_rule_time:I = 0x7f0a0765

.field public static final conditional_rule_time_container:I = 0x7f0a0766

.field public static final conditional_tab_item:I = 0x7f0a0767

.field public static final conditional_time_excel:I = 0x7f0a0768

.field public static final configset:I = 0x7f0a0769

.field public static final configset_switch:I = 0x7f0a076a

.field public static final confirm:I = 0x7f0a076b

.field public static final confirmBtn:I = 0x7f0a076c

.field public static final confirm_btn:I = 0x7f0a076d

.field public static final confirm_button:I = 0x7f0a076e

.field public static final console_tv:I = 0x7f0a076f

.field public static final constraint:I = 0x7f0a0770

.field public static final constraintLayout:I = 0x7f0a0771

.field public static final constraint_layout:I = 0x7f0a0772

.field public static final consume_window_insets_tag:I = 0x7f0a0779

.field public static final contact_item_head:I = 0x7f0a077a

.field public static final contact_item_header_text:I = 0x7f0a077b

.field public static final contact_list_item_head:I = 0x7f0a077c

.field public static final contacts_letters_list:I = 0x7f0a077d

.field public static final contacts_toast_message:I = 0x7f0a077e

.field public static final container:I = 0x7f0a077f

.field public static final container_bg:I = 0x7f0a0780

.field public static final container_common_price:I = 0x7f0a0781

.field public static final container_ll:I = 0x7f0a0782

.field public static final container_ui:I = 0x7f0a0783

.field public static final contanier:I = 0x7f0a0784

.field public static final content:I = 0x7f0a0785

.field public static final contentLayout:I = 0x7f0a0786

.field public static final contentPanel:I = 0x7f0a0787

.field public static final contentView:I = 0x7f0a0788

.field public static final content_bg:I = 0x7f0a0789

.field public static final content_container:I = 0x7f0a078a

.field public static final content_detail_publisher_btn:I = 0x7f0a07a3

.field public static final content_detail_user_info:I = 0x7f0a07ab

.field public static final content_free_list:I = 0x7f0a07af

.field public static final content_free_more_title:I = 0x7f0a07b0

.field public static final content_free_praise_icon:I = 0x7f0a07b1

.field public static final content_free_zan_container:I = 0x7f0a07b2

.field public static final content_item_divide_line:I = 0x7f0a07b3

.field public static final content_item_ninelayout:I = 0x7f0a07b4

.field public static final content_item_poster_container:I = 0x7f0a07b5

.field public static final content_item_poster_video_play_icon:I = 0x7f0a07b6

.field public static final content_item_text_main:I = 0x7f0a07b7

.field public static final content_item_text_quanwen:I = 0x7f0a07b8

.field public static final content_item_title:I = 0x7f0a07b9

.field public static final content_item_video_time:I = 0x7f0a07ba

.field public static final content_main_list:I = 0x7f0a07be

.field public static final content_main_list_show_more:I = 0x7f0a07bf

.field public static final content_page_container:I = 0x7f0a07c0

.field public static final content_style_title_container:I = 0x7f0a07c1

.field public static final content_vip_divide_line_layout:I = 0x7f0a07c6

.field public static final content_vip_header_layout:I = 0x7f0a07c7

.field public static final content_vip_join_button_layout:I = 0x7f0a07c8

.field public static final content_vip_join_button_text:I = 0x7f0a07c9

.field public static final content_wrapper:I = 0x7f0a07ca

.field public static final content_zone:I = 0x7f0a07cb

.field public static final contentzone:I = 0x7f0a07cc

.field public static final contiguous:I = 0x7f0a07cd

.field public static final continuousVelocity:I = 0x7f0a07ce

.field public static final contrast_price_container:I = 0x7f0a07cf

.field public static final control_layout:I = 0x7f0a07d0

.field public static final coordinator:I = 0x7f0a07d1

.field public static final copy_url:I = 0x7f0a07d3

.field public static final core_view:I = 0x7f0a07d4

.field public static final cornAction:I = 0x7f0a07d5

.field public static final cornContent:I = 0x7f0a07d6

.field public static final cornIcon:I = 0x7f0a07d7

.field public static final cornTitle:I = 0x7f0a07d8

.field public static final corner:I = 0x7f0a07d9

.field public static final cos:I = 0x7f0a07db

.field public static final costMsg:I = 0x7f0a07dc

.field public static final cost_price:I = 0x7f0a07dd

.field public static final cost_price_num:I = 0x7f0a07de

.field public static final cost_price_pre:I = 0x7f0a07df

.field public static final cost_price_suf:I = 0x7f0a07e0

.field public static final count:I = 0x7f0a07e1

.field public static final count_data_desc:I = 0x7f0a07e2

.field public static final count_down_timer:I = 0x7f0a07e6

.field public static final count_down_timer_view_container:I = 0x7f0a07e7

.field public static final count_errorcode_tip:I = 0x7f0a07ea

.field public static final count_tip:I = 0x7f0a07eb

.field public static final counterclockwise:I = 0x7f0a07ec

.field public static final country:I = 0x7f0a07ed

.field public static final coupon_action_button:I = 0x7f0a07ef

.field public static final coupon_action_loading:I = 0x7f0a07f0

.field public static final coupon_banner_view_bg:I = 0x7f0a07f1

.field public static final coupon_bottom_buy_btn_tv:I = 0x7f0a07f2

.field public static final coupon_bottom_service_btn_fl:I = 0x7f0a07f3

.field public static final coupon_container:I = 0x7f0a07f6

.field public static final coupon_img_count_info:I = 0x7f0a0801

.field public static final coupon_img_count_info_title:I = 0x7f0a0802

.field public static final coupon_item_limit_tagview_coupontype:I = 0x7f0a0803

.field public static final coupon_item_limit_tagview_overlay:I = 0x7f0a0804

.field public static final coupon_item_limit_tagview_target:I = 0x7f0a0805

.field public static final coupon_limit_amount:I = 0x7f0a0809

.field public static final coupon_limit_tagview_container:I = 0x7f0a080a

.field public static final coupon_limit_ticketsnum:I = 0x7f0a080b

.field public static final coupon_member_tag_des:I = 0x7f0a080c

.field public static final coupon_package_bottom_item:I = 0x7f0a080f

.field public static final coupon_price_container:I = 0x7f0a0811

.field public static final coupon_receive:I = 0x7f0a0813

.field public static final coupon_reduce_select_area:I = 0x7f0a0814

.field public static final coupon_reduce_select_arrow:I = 0x7f0a0815

.field public static final coupon_status:I = 0x7f0a0817

.field public static final coupon_subtitle:I = 0x7f0a0819

.field public static final coupon_title:I = 0x7f0a081a

.field public static final coupon_top_banner_bottombg:I = 0x7f0a081f

.field public static final coupon_top_banner_container:I = 0x7f0a0820

.field public static final coupon_type_icon:I = 0x7f0a0821

.field public static final coupon_view_order_sale:I = 0x7f0a0824

.field public static final coupons_container:I = 0x7f0a0825

.field public static final cover:I = 0x7f0a0826

.field public static final cover_bottom_divline:I = 0x7f0a0828

.field public static final cover_half_bottom:I = 0x7f0a0829

.field public static final cover_half_top:I = 0x7f0a082a

.field public static final cover_tip:I = 0x7f0a082b

.field public static final ctrl_name:I = 0x7f0a0839

.field public static final ctrlbar_back:I = 0x7f0a083a

.field public static final ctrlbar_forward:I = 0x7f0a083b

.field public static final ctrlbar_refresh:I = 0x7f0a083c

.field public static final cumulative_box_office:I = 0x7f0a083d

.field public static final currentState:I = 0x7f0a083f

.field public static final current_city_container:I = 0x7f0a0840

.field public static final current_city_exchange:I = 0x7f0a0841

.field public static final current_city_exchange_iconf:I = 0x7f0a0842

.field public static final current_city_ll:I = 0x7f0a0843

.field public static final current_city_logo:I = 0x7f0a0844

.field public static final current_city_name:I = 0x7f0a0845

.field public static final current_city_tag:I = 0x7f0a0846

.field public static final current_poplayer:I = 0x7f0a0847

.field public static final custom:I = 0x7f0a0848

.field public static final customPanel:I = 0x7f0a0849

.field public static final custom_content:I = 0x7f0a084a

.field public static final custom_delete:I = 0x7f0a084b

.field public static final custom_edit:I = 0x7f0a084c

.field public static final custom_frame_layout:I = 0x7f0a084d

.field public static final customer_irecyclerview:I = 0x7f0a084f

.field public static final customer_item_bottom_line:I = 0x7f0a0850

.field public static final cut:I = 0x7f0a0853

.field public static final cv_channel_brand_venue_container:I = 0x7f0a0854

.field public static final cw_0:I = 0x7f0a0856

.field public static final cw_180:I = 0x7f0a0857

.field public static final cw_270:I = 0x7f0a0858

.field public static final cw_90:I = 0x7f0a0859

.field public static final damai_dialog_bottom_space:I = 0x7f0a085a

.field public static final damai_dialog_btn_line:I = 0x7f0a085b

.field public static final damai_dialog_btn_top_line:I = 0x7f0a085c

.field public static final damai_dialog_cancel_btn:I = 0x7f0a085d

.field public static final damai_dialog_close_btn:I = 0x7f0a085e

.field public static final damai_dialog_confirm_btn:I = 0x7f0a085f

.field public static final damai_dialog_content:I = 0x7f0a0860

.field public static final damai_dialog_layout:I = 0x7f0a0861

.field public static final damai_dialog_tip_content:I = 0x7f0a0862

.field public static final damai_dialog_title:I = 0x7f0a0863

.field public static final damai_protocol_dialog_layout:I = 0x7f0a0864

.field public static final damai_root_layout:I = 0x7f0a0865

.field public static final damai_theme_dialog:I = 0x7f0a0866

.field public static final damai_theme_dialog_bottom_action_block:I = 0x7f0a0867

.field public static final damai_theme_dialog_bottom_space:I = 0x7f0a0868

.field public static final damai_theme_dialog_cancel_btn:I = 0x7f0a0869

.field public static final damai_theme_dialog_close_btn:I = 0x7f0a086a

.field public static final damai_theme_dialog_close_layout:I = 0x7f0a086b

.field public static final damai_theme_dialog_confirm_btn:I = 0x7f0a086c

.field public static final damai_theme_dialog_container:I = 0x7f0a086d

.field public static final damai_theme_dialog_content_container:I = 0x7f0a086e

.field public static final damai_theme_dialog_content_layout:I = 0x7f0a086f

.field public static final damai_theme_dialog_content_scroll:I = 0x7f0a0870

.field public static final damai_theme_dialog_gift_price:I = 0x7f0a0871

.field public static final damai_theme_dialog_layout:I = 0x7f0a0873

.field public static final damai_theme_dialog_subtitle:I = 0x7f0a0874

.field public static final damai_theme_dialog_tip_content:I = 0x7f0a0875

.field public static final damai_theme_dialog_tip_desc:I = 0x7f0a0876

.field public static final damai_theme_dialog_title:I = 0x7f0a0877

.field public static final damai_theme_dialog_top_image:I = 0x7f0a0878

.field public static final damai_theme_dialog_top_image_bg:I = 0x7f0a0879

.field public static final damai_theme_dialog_top_image_lottie:I = 0x7f0a087a

.field public static final damai_theme_dialog_top_layout_bottom:I = 0x7f0a087b

.field public static final damai_theme_dialog_top_layout_top:I = 0x7f0a087c

.field public static final danmaku_avatar_1:I = 0x7f0a087d

.field public static final danmaku_avatar_1_bg:I = 0x7f0a087e

.field public static final danmaku_avatar_2:I = 0x7f0a087f

.field public static final danmaku_avatar_2_bg:I = 0x7f0a0880

.field public static final danmaku_common:I = 0x7f0a0881

.field public static final danmaku_content:I = 0x7f0a0882

.field public static final danmaku_creator:I = 0x7f0a0883

.field public static final danmaku_mine:I = 0x7f0a0884

.field public static final danmaku_mine_dominate:I = 0x7f0a0885

.field public static final danmaku_notice:I = 0x7f0a0886

.field public static final danmaku_view_watch_together:I = 0x7f0a0887

.field public static final danmaku_vip_flag_1:I = 0x7f0a0888

.field public static final danmaku_vip_flag_2:I = 0x7f0a0889

.field public static final daojishi_layout:I = 0x7f0a088a

.field public static final dark:I = 0x7f0a088b

.field public static final dash:I = 0x7f0a088c

.field public static final dash_line:I = 0x7f0a088e

.field public static final date:I = 0x7f0a0890

.field public static final date_count_container:I = 0x7f0a0891

.field public static final date_picker_actions:I = 0x7f0a0893

.field public static final date_sub:I = 0x7f0a0894

.field public static final day:I = 0x7f0a0895

.field public static final day_view:I = 0x7f0a0897

.field public static final dbm_drama_recycler:I = 0x7f0a0898

.field public static final dbm_tab_recycler:I = 0x7f0a0899

.field public static final dc_project_addr:I = 0x7f0a089a

.field public static final dc_project_date:I = 0x7f0a089b

.field public static final dc_project_ipuv:I = 0x7f0a089c

.field public static final dc_project_partition:I = 0x7f0a089d

.field public static final dc_project_poster:I = 0x7f0a089e

.field public static final dc_project_poster_tv:I = 0x7f0a089f

.field public static final dc_project_price:I = 0x7f0a08a0

.field public static final dc_project_score_num:I = 0x7f0a08a1

.field public static final dc_project_score_num_suffix:I = 0x7f0a08a2

.field public static final dc_project_title:I = 0x7f0a08a3

.field public static final dc_project_title_container:I = 0x7f0a08a4

.field public static final dc_root:I = 0x7f0a08a5

.field public static final decelerate:I = 0x7f0a08a7

.field public static final decelerateAndComplete:I = 0x7f0a08a8

.field public static final decision_slice:I = 0x7f0a08a9

.field public static final decode:I = 0x7f0a08aa

.field public static final decode_failed:I = 0x7f0a08ab

.field public static final decode_succeeded:I = 0x7f0a08ac

.field public static final decor_content_parent:I = 0x7f0a08ad

.field public static final decorate:I = 0x7f0a08ae

.field public static final decorate_view:I = 0x7f0a08af

.field public static final decorated_disabled:I = 0x7f0a08b0

.field public static final deduction_price:I = 0x7f0a08b1

.field public static final deep_further_focus_click_block:I = 0x7f0a08b2

.field public static final deep_further_focused:I = 0x7f0a08b3

.field public static final deep_further_role:I = 0x7f0a08b4

.field public static final deep_further_unfocused:I = 0x7f0a08b5

.field public static final default_activity_button:I = 0x7f0a08b6

.field public static final default_frame:I = 0x7f0a08b7

.field public static final default_mode:I = 0x7f0a08b8

.field public static final defaults:I = 0x7f0a08b9

.field public static final degrade_happy_coin:I = 0x7f0a08ba

.field public static final degrade_happy_coin_container:I = 0x7f0a08bb

.field public static final delete:I = 0x7f0a08bc

.field public static final delete_customer_cancle:I = 0x7f0a08bd

.field public static final delete_customer_confirm:I = 0x7f0a08be

.field public static final deliver_left:I = 0x7f0a08c3

.field public static final deliver_right:I = 0x7f0a08c7

.field public static final deltaRelative:I = 0x7f0a08cb

.field public static final derivation:I = 0x7f0a08cd

.field public static final derivation_friend_icon:I = 0x7f0a08ce

.field public static final derivation_friend_icon_ext:I = 0x7f0a08cf

.field public static final derivation_friend_icon_title:I = 0x7f0a08d0

.field public static final derivation_icon:I = 0x7f0a08d1

.field public static final derivation_icon_title:I = 0x7f0a08d3

.field public static final des:I = 0x7f0a08d4

.field public static final desc:I = 0x7f0a08d5

.field public static final desc_close:I = 0x7f0a08d6

.field public static final desc_non:I = 0x7f0a08d8

.field public static final desc_tv:I = 0x7f0a08d9

.field public static final description:I = 0x7f0a08da

.field public static final design_bottom_sheet:I = 0x7f0a08db

.field public static final design_menu_item_action_area:I = 0x7f0a08dc

.field public static final design_menu_item_action_area_stub:I = 0x7f0a08dd

.field public static final design_menu_item_text:I = 0x7f0a08de

.field public static final design_navigation_view:I = 0x7f0a08df

.field public static final detail_dummy_panel:I = 0x7f0a08e0

.field public static final detail_enter_pay_done:I = 0x7f0a08e1

.field public static final detail_parent:I = 0x7f0a08e2

.field public static final detail_servicefee:I = 0x7f0a08e9

.field public static final detail_title:I = 0x7f0a08ea

.field public static final detial_zone:I = 0x7f0a08ed

.field public static final dfp_date:I = 0x7f0a08ee

.field public static final dfp_poster:I = 0x7f0a08ef

.field public static final dfp_price:I = 0x7f0a08f0

.field public static final dfp_price_custom:I = 0x7f0a08f1

.field public static final dfp_price_pending:I = 0x7f0a08f2

.field public static final dfp_price_postfix:I = 0x7f0a08f3

.field public static final dfp_price_prefix:I = 0x7f0a08f4

.field public static final dfp_rank_tag:I = 0x7f0a08f5

.field public static final dfp_rank_tag_icon:I = 0x7f0a08f6

.field public static final dfp_rank_tag_ll:I = 0x7f0a08f7

.field public static final dfp_title:I = 0x7f0a08f8

.field public static final dfp_wanna_see_tag:I = 0x7f0a08f9

.field public static final dialog_bg:I = 0x7f0a08fd

.field public static final dialog_bottom_action_container:I = 0x7f0a08fe

.field public static final dialog_bottom_action_lv:I = 0x7f0a08ff

.field public static final dialog_close:I = 0x7f0a0902

.field public static final dialog_content:I = 0x7f0a0904

.field public static final dialog_content_container:I = 0x7f0a0905

.field public static final dialog_content_container2:I = 0x7f0a0906

.field public static final dialog_content_layout:I = 0x7f0a0907

.field public static final dialog_expand_content_container:I = 0x7f0a0908

.field public static final dialog_expand_content_container3:I = 0x7f0a0909

.field public static final dialog_expand_content_container4:I = 0x7f0a090a

.field public static final dialog_footer:I = 0x7f0a090b

.field public static final dialog_item_action_icon_f:I = 0x7f0a090c

.field public static final dialog_item_action_img:I = 0x7f0a090d

.field public static final dialog_item_action_tv:I = 0x7f0a090e

.field public static final dialog_myfavor_mediaaccount_guide_closebtn:I = 0x7f0a0919

.field public static final dialog_myfavor_mediaaccount_guide_confirmbtn:I = 0x7f0a091a

.field public static final dialog_myfavor_mediaaccount_guide_image:I = 0x7f0a091b

.field public static final dialog_scratch_bg:I = 0x7f0a0925

.field public static final dialog_title:I = 0x7f0a0927

.field public static final dialog_view:I = 0x7f0a0928

.field public static final dialog_zone:I = 0x7f0a0929

.field public static final dianying_zone:I = 0x7f0a092a

.field public static final diff_container:I = 0x7f0a092c

.field public static final dimensions:I = 0x7f0a092e

.field public static final dinamicBindDataList:I = 0x7f0a092f

.field public static final dinamicCurrentImageName:I = 0x7f0a0930

.field public static final dinamicImageName:I = 0x7f0a0931

.field public static final dinamicKeyBoardListener:I = 0x7f0a0932

.field public static final dinamicLayoutRadii:I = 0x7f0a0933

.field public static final dinamicPropertyTag:I = 0x7f0a0934

.field public static final dinamicSubData:I = 0x7f0a0935

.field public static final dinamicTextWatcher:I = 0x7f0a0936

.field public static final dinamicViewParams:I = 0x7f0a0937

.field public static final dinamicViewResult:I = 0x7f0a0938

.field public static final dinamicViewType:I = 0x7f0a0939

.field public static final dinamicXWidgetNodeTag:I = 0x7f0a093a

.field public static final dinamic_preview_back:I = 0x7f0a093b

.field public static final direct:I = 0x7f0a093d

.field public static final directo_leading_role_container:I = 0x7f0a093e

.field public static final director:I = 0x7f0a093f

.field public static final dis_like_icon:I = 0x7f0a0940

.field public static final disableHome:I = 0x7f0a0941

.field public static final disabled:I = 0x7f0a0945

.field public static final discount_barrier:I = 0x7f0a094d

.field public static final discount_bg_view:I = 0x7f0a094e

.field public static final discount_info_icon:I = 0x7f0a0951

.field public static final discount_info_tv:I = 0x7f0a0952

.field public static final discount_ll_right:I = 0x7f0a0953

.field public static final discount_logo_gone_view:I = 0x7f0a0954

.field public static final discount_logo_iv:I = 0x7f0a0955

.field public static final discount_price:I = 0x7f0a0956

.field public static final discount_price_desc:I = 0x7f0a0957

.field public static final discount_tags_container:I = 0x7f0a0958

.field public static final discount_ticket_title_layout:I = 0x7f0a095b

.field public static final discount_to_use:I = 0x7f0a095c

.field public static final discount_view:I = 0x7f0a0962

.field public static final discuss_title:I = 0x7f0a0979

.field public static final disjoint:I = 0x7f0a097c

.field public static final dislike:I = 0x7f0a097d

.field public static final dislike_divider:I = 0x7f0a097e

.field public static final disount_label_container:I = 0x7f0a097f

.field public static final display_price:I = 0x7f0a0980

.field public static final divide_line:I = 0x7f0a0981

.field public static final divider:I = 0x7f0a0983

.field public static final divider2:I = 0x7f0a0984

.field public static final divider3:I = 0x7f0a0985

.field public static final divider_bottom:I = 0x7f0a0986

.field public static final divider_d:I = 0x7f0a0987

.field public static final divider_extra:I = 0x7f0a0988

.field public static final divider_line:I = 0x7f0a098b

.field public static final divider_line_1:I = 0x7f0a098c

.field public static final divider_line_2:I = 0x7f0a098d

.field public static final division_name_tv:I = 0x7f0a098e

.field public static final dm_aliuser_root_region:I = 0x7f0a098f

.field public static final dm_cb_login_pro:I = 0x7f0a0990

.field public static final dm_cb_register_pro:I = 0x7f0a0991

.field public static final dm_discount_balel:I = 0x7f0a0992

.field public static final dm_info:I = 0x7f0a0995

.field public static final dm_line_5:I = 0x7f0a0996

.field public static final dm_ll_login_pro:I = 0x7f0a0997

.field public static final dm_project_activity_item:I = 0x7f0a09a3

.field public static final dm_project_broadcast_coming_title:I = 0x7f0a09a4

.field public static final dm_project_broadcast_coming_title_arrow:I = 0x7f0a09a5

.field public static final dm_project_broadcast_coming_title_block:I = 0x7f0a09a6

.field public static final dm_project_broadcast_coming_title_right_block:I = 0x7f0a09a7

.field public static final dm_project_broadcast_coming_title_right_des:I = 0x7f0a09a8

.field public static final dm_project_timer_view:I = 0x7f0a09a9

.field public static final dm_ptr_scroll_view:I = 0x7f0a09aa

.field public static final dm_tv_login_pro_desc:I = 0x7f0a09ad

.field public static final dm_tv_login_tip_desc:I = 0x7f0a09ae

.field public static final dma_agree_btn:I = 0x7f0a09af

.field public static final dma_content_ui:I = 0x7f0a09b0

.field public static final dma_protocol_check_btn:I = 0x7f0a09b1

.field public static final dma_protocol_check_click_btn:I = 0x7f0a09b2

.field public static final dma_protocol_name:I = 0x7f0a09b3

.field public static final dma_protocol_prefix:I = 0x7f0a09b4

.field public static final dma_reject_btn:I = 0x7f0a09b5

.field public static final dma_rule_container:I = 0x7f0a09b6

.field public static final dma_sub_title:I = 0x7f0a09b7

.field public static final dma_title:I = 0x7f0a09b8

.field public static final dmg_close:I = 0x7f0a09b9

.field public static final dmg_header_ui:I = 0x7f0a09ba

.field public static final dmg_img:I = 0x7f0a09bb

.field public static final dmg_img_gif:I = 0x7f0a09bc

.field public static final dmg_img_ui:I = 0x7f0a09bd

.field public static final dmg_user_name:I = 0x7f0a09be

.field public static final dmp_close:I = 0x7f0a09bf

.field public static final dmp_img:I = 0x7f0a09c0

.field public static final dontremind:I = 0x7f0a09c2

.field public static final dot:I = 0x7f0a09c3

.field public static final downloadBar:I = 0x7f0a09c4

.field public static final downloadImage:I = 0x7f0a09c5

.field public static final downloadText:I = 0x7f0a09c6

.field public static final download_image_tv:I = 0x7f0a09c7

.field public static final dp:I = 0x7f0a09c8

.field public static final dragAnticlockwise:I = 0x7f0a09c9

.field public static final dragClockwise:I = 0x7f0a09ca

.field public static final dragDown:I = 0x7f0a09cb

.field public static final dragEnd:I = 0x7f0a09cc

.field public static final dragLeft:I = 0x7f0a09cd

.field public static final dragRight:I = 0x7f0a09ce

.field public static final dragStart:I = 0x7f0a09cf

.field public static final dragUp:I = 0x7f0a09d0

.field public static final drama_activity_root:I = 0x7f0a09d1

.field public static final drama_citys:I = 0x7f0a09d2

.field public static final drama_focus_state_tv:I = 0x7f0a09d4

.field public static final drama_focus_state_ui:I = 0x7f0a09d5

.field public static final drama_image:I = 0x7f0a09d6

.field public static final drama_image_layout:I = 0x7f0a09d7

.field public static final drama_inner_layout:I = 0x7f0a09d8

.field public static final drama_inner_layout2:I = 0x7f0a09d9

.field public static final drama_ipuv:I = 0x7f0a09da

.field public static final drama_list_container:I = 0x7f0a09db

.field public static final drama_no_more:I = 0x7f0a09dc

.field public static final drama_poster:I = 0x7f0a09de

.field public static final drama_poster_ui:I = 0x7f0a09df

.field public static final drama_recycler:I = 0x7f0a09e0

.field public static final drama_show_more:I = 0x7f0a09e3

.field public static final drama_star_score:I = 0x7f0a09e4

.field public static final drama_tag:I = 0x7f0a09e5

.field public static final drama_title:I = 0x7f0a09e6

.field public static final drama_worth_recycler:I = 0x7f0a09e7

.field public static final draw_desc:I = 0x7f0a09e8

.field public static final draw_title_pic:I = 0x7f0a09e9

.field public static final draw_title_text:I = 0x7f0a09ea

.field public static final drawn_btn:I = 0x7f0a09eb

.field public static final drawn_container:I = 0x7f0a09ec

.field public static final dropdown_menu:I = 0x7f0a09ee

.field public static final duration:I = 0x7f0a09f5

.field public static final dvd:I = 0x7f0a09f6

.field public static final dvd_margin:I = 0x7f0a09f7

.field public static final dvd_nomargin:I = 0x7f0a09f8

.field public static final dx_date_picker_view_tag:I = 0x7f0a09f9

.field public static final dx_imageview_createview_timestamp_key:I = 0x7f0a09fa

.field public static final dx_imageview_renderview_timestamp_key:I = 0x7f0a09fb

.field public static final dx_multi_line_input:I = 0x7f0a09fc

.field public static final dx_recycler_expose_stay_time:I = 0x7f0a09fd

.field public static final dx_recycler_layout_view_tag:I = 0x7f0a09fe

.field public static final dx_recycler_sticky_holder:I = 0x7f0a09ff

.field public static final dx_recycler_sticky_key:I = 0x7f0a0a00

.field public static final dx_recycler_view_has_scroll_listener:I = 0x7f0a0a01

.field public static final dx_switch_background_off_color:I = 0x7f0a0a02

.field public static final dx_switch_background_on_color:I = 0x7f0a0a03

.field public static final dx_switch_set_background_on_view:I = 0x7f0a0a04

.field public static final dx_tag_animation_expanded_widget_on_view:I = 0x7f0a0a05

.field public static final dx_tag_expanded_widget_on_view:I = 0x7f0a0a06

.field public static final dx_tag_flatten_widget_on_view:I = 0x7f0a0a07

.field public static final dx_textview_font_tag:I = 0x7f0a0a08

.field public static final dynamic_btn:I = 0x7f0a0a09

.field public static final easeIn:I = 0x7f0a0a0f

.field public static final easeInOut:I = 0x7f0a0a10

.field public static final easeOut:I = 0x7f0a0a11

.field public static final east:I = 0x7f0a0a12

.field public static final edit_comment_arrow:I = 0x7f0a0a14

.field public static final edit_line:I = 0x7f0a0a1c

.field public static final edit_phone_num:I = 0x7f0a0a20

.field public static final edit_query:I = 0x7f0a0a21

.field public static final editor:I = 0x7f0a0a22

.field public static final edittext:I = 0x7f0a0a23

.field public static final elastic:I = 0x7f0a0a26

.field public static final electronic_line:I = 0x7f0a0a27

.field public static final electronic_right_arrow:I = 0x7f0a0a28

.field public static final element_root:I = 0x7f0a0a29

.field public static final ellipse:I = 0x7f0a0a2a

.field public static final empty:I = 0x7f0a0a2f

.field public static final empty_container:I = 0x7f0a0a30

.field public static final empty_data:I = 0x7f0a0a31

.field public static final empty_ic:I = 0x7f0a0a32

.field public static final empty_view:I = 0x7f0a0a37

.field public static final emptydata_container:I = 0x7f0a0a38

.field public static final enable_service_text:I = 0x7f0a0a39

.field public static final encode_failed:I = 0x7f0a0a3a

.field public static final encode_succeeded:I = 0x7f0a0a3b

.field public static final end:I = 0x7f0a0a3c

.field public static final endToStart:I = 0x7f0a0a3d

.field public static final end_padder:I = 0x7f0a0a3e

.field public static final end_time:I = 0x7f0a0a3f

.field public static final end_time_txt:I = 0x7f0a0a40

.field public static final endorse_arrow:I = 0x7f0a0a41

.field public static final endorse_check:I = 0x7f0a0a42

.field public static final endorse_desc:I = 0x7f0a0a43

.field public static final endorse_desc_container:I = 0x7f0a0a44

.field public static final endorse_icon:I = 0x7f0a0a45

.field public static final endorse_label:I = 0x7f0a0a46

.field public static final endorse_text:I = 0x7f0a0a47

.field public static final endorse_zone:I = 0x7f0a0a48

.field public static final enterAlways:I = 0x7f0a0a49

.field public static final enterAlwaysCollapsed:I = 0x7f0a0a4a

.field public static final equity_card_container:I = 0x7f0a0a4b

.field public static final equity_deduction_layout:I = 0x7f0a0a4c

.field public static final equity_deduction_txt:I = 0x7f0a0a4d

.field public static final equity_icon:I = 0x7f0a0a4e

.field public static final equity_pop_item:I = 0x7f0a0a4f

.field public static final errorView:I = 0x7f0a0a51

.field public static final error_container:I = 0x7f0a0a53

.field public static final et_count:I = 0x7f0a0a57

.field public static final et_errorcode:I = 0x7f0a0a58

.field public static final et_input:I = 0x7f0a0a59

.field public static final et_keyword:I = 0x7f0a0a5d

.field public static final et_phone:I = 0x7f0a0a5e

.field public static final evaluate_back_to_top:I = 0x7f0a0a5f

.field public static final evaluate_bottom_line:I = 0x7f0a0a60

.field public static final evaluate_container:I = 0x7f0a0a61

.field public static final evaluate_detail_action:I = 0x7f0a0a62

.field public static final evaluate_dm_info_tag_view:I = 0x7f0a0a66

.field public static final evaluate_grade_block:I = 0x7f0a0a67

.field public static final evaluate_grade_desc:I = 0x7f0a0a68

.field public static final evaluate_grade_view:I = 0x7f0a0a69

.field public static final evaluate_grade_weight:I = 0x7f0a0a6a

.field public static final evaluate_icon_arrow:I = 0x7f0a0a6c

.field public static final evaluate_item_layout:I = 0x7f0a0a6d

.field public static final evaluate_label_horizontal:I = 0x7f0a0a6e

.field public static final evaluate_label_layout:I = 0x7f0a0a6f

.field public static final evaluate_label_list:I = 0x7f0a0a70

.field public static final evaluate_lay:I = 0x7f0a0a71

.field public static final evaluate_list_title:I = 0x7f0a0a72

.field public static final evaluate_list_title_left_icon:I = 0x7f0a0a73

.field public static final evaluate_list_want_see_guide:I = 0x7f0a0a74

.field public static final evaluate_my_action:I = 0x7f0a0a75

.field public static final evaluate_my_line:I = 0x7f0a0a76

.field public static final evaluate_praise_num:I = 0x7f0a0a77

.field public static final evaluate_praise_view:I = 0x7f0a0a78

.field public static final evaluate_project:I = 0x7f0a0a79

.field public static final evaluate_project_desc:I = 0x7f0a0a7a

.field public static final evaluate_project_image:I = 0x7f0a0a7b

.field public static final evaluate_project_info:I = 0x7f0a0a7c

.field public static final evaluate_project_name:I = 0x7f0a0a7d

.field public static final evaluate_recyclerview:I = 0x7f0a0a7e

.field public static final evaluate_share_top_bg:I = 0x7f0a0a80

.field public static final evaluate_spoiler_view:I = 0x7f0a0a81

.field public static final excel_head_end:I = 0x7f0a0a83

.field public static final excel_head_first:I = 0x7f0a0a84

.field public static final exchange_state_txt:I = 0x7f0a0a85

.field public static final exchange_zone:I = 0x7f0a0a86

.field public static final exit:I = 0x7f0a0a87

.field public static final exitUntilCollapsed:I = 0x7f0a0a88

.field public static final expand_activities_button:I = 0x7f0a0a89

.field public static final expand_collapse:I = 0x7f0a0a8a

.field public static final expand_collapse_bg:I = 0x7f0a0a8b

.field public static final expand_tag_container:I = 0x7f0a0a8c

.field public static final expandable_iconf:I = 0x7f0a0a8d

.field public static final expandable_text:I = 0x7f0a0a8e

.field public static final expandable_view:I = 0x7f0a0a8f

.field public static final expanded_mask:I = 0x7f0a0a90

.field public static final expanded_menu:I = 0x7f0a0a91

.field public static final extend:I = 0x7f0a0a95

.field public static final extra_button:I = 0x7f0a0a98

.field public static final eye_icon:I = 0x7f0a0a9a

.field public static final fade:I = 0x7f0a0a9e

.field public static final fake_schedule_and_food_tab:I = 0x7f0a0a9f

.field public static final fake_schedule_and_food_tab_layout:I = 0x7f0a0aa0

.field public static final fake_sticky_view:I = 0x7f0a0aa1

.field public static final fans:I = 0x7f0a0aa2

.field public static final fans_and_sell_tv:I = 0x7f0a0aa3

.field public static final fans_banner:I = 0x7f0a0aa5

.field public static final fans_count:I = 0x7f0a0aa6

.field public static final fans_layout:I = 0x7f0a0aa7

.field public static final fans_tv:I = 0x7f0a0aa8

.field public static final fast_button:I = 0x7f0a0aac

.field public static final fast_filter_item_text:I = 0x7f0a0aad

.field public static final fast_filter_tv:I = 0x7f0a0aae

.field public static final fast_filter_tv_lottie:I = 0x7f0a0aaf

.field public static final fast_preview_layout:I = 0x7f0a0ab0

.field public static final fast_seat:I = 0x7f0a0ab1

.field public static final fast_seat_view:I = 0x7f0a0ab2

.field public static final favorite:I = 0x7f0a0ab9

.field public static final favorite_with_gift:I = 0x7f0a0aba

.field public static final favorite_with_gift_pioneer:I = 0x7f0a0abb

.field public static final favourite_label:I = 0x7f0a0abc

.field public static final favourite_live:I = 0x7f0a0abd

.field public static final favourite_poster:I = 0x7f0a0abe

.field public static final favourite_score_icon:I = 0x7f0a0abf

.field public static final favourite_score_layout:I = 0x7f0a0ac0

.field public static final favourite_score_text:I = 0x7f0a0ac1

.field public static final favourite_tag:I = 0x7f0a0ac2

.field public static final feature_container:I = 0x7f0a0ac3

.field public static final feed_article_add_favor:I = 0x7f0a0ac4

.field public static final feed_article_favor_count:I = 0x7f0a0ac5

.field public static final feed_card_container:I = 0x7f0a0ac6

.field public static final feed_card_img:I = 0x7f0a0ac7

.field public static final feed_error_status_container:I = 0x7f0a0ac8

.field public static final feed_head_icon_layout:I = 0x7f0a0ac9

.field public static final feed_media_icon:I = 0x7f0a0acb

.field public static final feed_media_name:I = 0x7f0a0acc

.field public static final feed_media_praise:I = 0x7f0a0acd

.field public static final feed_media_verify:I = 0x7f0a0ace

.field public static final feed_play_icon:I = 0x7f0a0ad5

.field public static final feed_play_icon_pioneer:I = 0x7f0a0ad6

.field public static final feed_project_hw_layout:I = 0x7f0a0ad7

.field public static final feed_project_poster:I = 0x7f0a0ad8

.field public static final feed_project_price_pending_ui:I = 0x7f0a0ad9

.field public static final feed_project_tag:I = 0x7f0a0ada

.field public static final feed_project_time:I = 0x7f0a0adb

.field public static final feed_project_title:I = 0x7f0a0adc

.field public static final feed_project_wantsee:I = 0x7f0a0add

.field public static final feed_project_with_price_tv:I = 0x7f0a0ade

.field public static final feed_project_with_price_ui:I = 0x7f0a0adf

.field public static final feed_relative_arrow:I = 0x7f0a0ae0

.field public static final feed_relative_layout:I = 0x7f0a0ae1

.field public static final feed_tab:I = 0x7f0a0ae2

.field public static final feed_tab_layout:I = 0x7f0a0ae4

.field public static final feedback:I = 0x7f0a0ae7

.field public static final feedback_close:I = 0x7f0a0ae8

.field public static final fg_notice_recycler:I = 0x7f0a0af8

.field public static final fg_promotion_recycler:I = 0x7f0a0af9

.field public static final fg_promotion_title:I = 0x7f0a0afa

.field public static final fill:I = 0x7f0a0afb

.field public static final fillScreen:I = 0x7f0a0afc

.field public static final fill_bg_layout:I = 0x7f0a0afd

.field public static final fill_horizontal:I = 0x7f0a0afe

.field public static final fill_vertical:I = 0x7f0a0aff

.field public static final filled:I = 0x7f0a0b00

.field public static final film_bg:I = 0x7f0a0b05

.field public static final film_comment_content:I = 0x7f0a0b07

.field public static final film_count:I = 0x7f0a0b0b

.field public static final film_detail:I = 0x7f0a0b0c

.field public static final film_detail_block_left_text:I = 0x7f0a0b0f

.field public static final film_detail_block_right_text:I = 0x7f0a0b10

.field public static final film_detail_bottom_atmosphere:I = 0x7f0a0b11

.field public static final film_detail_bottom_atmosphere_icon:I = 0x7f0a0b12

.field public static final film_detail_bottom_atmosphere_layter_top:I = 0x7f0a0b13

.field public static final film_detail_bottom_container:I = 0x7f0a0b14

.field public static final film_detail_bottom_flash_avatar:I = 0x7f0a0b15

.field public static final film_detail_bottom_left_container:I = 0x7f0a0b16

.field public static final film_detail_bottom_left_maindes:I = 0x7f0a0b17

.field public static final film_detail_bottom_left_subdes:I = 0x7f0a0b18

.field public static final film_detail_bottom_right_container:I = 0x7f0a0b1b

.field public static final film_detail_bottom_right_container_bg:I = 0x7f0a0b1c

.field public static final film_detail_bottom_right_discount:I = 0x7f0a0b1d

.field public static final film_detail_bottom_right_icon:I = 0x7f0a0b1e

.field public static final film_detail_bottom_right_maindes:I = 0x7f0a0b1f

.field public static final film_detail_bottom_right_subdes:I = 0x7f0a0b20

.field public static final film_detail_comment_count:I = 0x7f0a0b22

.field public static final film_detail_comment_head:I = 0x7f0a0b23

.field public static final film_detail_comment_tip:I = 0x7f0a0b26

.field public static final film_detail_container:I = 0x7f0a0b27

.field public static final film_detail_enter:I = 0x7f0a0b29

.field public static final film_detail_group_booking_arrow:I = 0x7f0a0b2c

.field public static final film_detail_group_booking_avatar:I = 0x7f0a0b2d

.field public static final film_detail_group_booking_more:I = 0x7f0a0b2e

.field public static final film_detail_group_booking_subtitle:I = 0x7f0a0b2f

.field public static final film_detail_group_booking_timer:I = 0x7f0a0b30

.field public static final film_detail_group_booking_timer_block:I = 0x7f0a0b31

.field public static final film_detail_group_booking_timer_pre:I = 0x7f0a0b32

.field public static final film_detail_group_booking_title:I = 0x7f0a0b33

.field public static final film_detail_intro_content:I = 0x7f0a0b34

.field public static final film_detail_intro_egg_content:I = 0x7f0a0b35

.field public static final film_detail_intro_title:I = 0x7f0a0b36

.field public static final film_detail_intro_watching_tip:I = 0x7f0a0b37

.field public static final film_detail_item:I = 0x7f0a0b38

.field public static final film_detail_market_icon:I = 0x7f0a0b39

.field public static final film_detail_market_subtitle:I = 0x7f0a0b3a

.field public static final film_detail_market_subtitle_icon:I = 0x7f0a0b3b

.field public static final film_detail_market_title:I = 0x7f0a0b3c

.field public static final film_detail_page_top_indicate:I = 0x7f0a0b44

.field public static final film_detail_souvenir_icon:I = 0x7f0a0b48

.field public static final film_detail_souvenir_item_arrow:I = 0x7f0a0b49

.field public static final film_detail_souvenir_title:I = 0x7f0a0b4a

.field public static final film_detail_surrounding_layout:I = 0x7f0a0b4b

.field public static final film_detail_video_dynamic_content:I = 0x7f0a0b61

.field public static final film_detail_video_dynamic_title:I = 0x7f0a0b62

.field public static final film_image:I = 0x7f0a0b65

.field public static final film_info:I = 0x7f0a0b66

.field public static final film_is_showing:I = 0x7f0a0b67

.field public static final film_name:I = 0x7f0a0b68

.field public static final film_name_en_txt:I = 0x7f0a0b69

.field public static final film_name_txt:I = 0x7f0a0b6a

.field public static final film_no_comment_img:I = 0x7f0a0b6b

.field public static final film_play_time:I = 0x7f0a0b6d

.field public static final film_poster:I = 0x7f0a0b70

.field public static final film_poster_bg:I = 0x7f0a0b71

.field public static final film_remark_tag:I = 0x7f0a0b77

.field public static final film_role:I = 0x7f0a0b81

.field public static final film_show_mark:I = 0x7f0a0b84

.field public static final film_showing_hot:I = 0x7f0a0b85

.field public static final film_surrounding_action:I = 0x7f0a0b89

.field public static final film_surrounding_cd:I = 0x7f0a0b8a

.field public static final film_surrounding_image:I = 0x7f0a0b8b

.field public static final film_surrounding_sub_title:I = 0x7f0a0b8c

.field public static final film_surrounding_title:I = 0x7f0a0b8d

.field public static final film_surrounding_title_layout:I = 0x7f0a0b8e

.field public static final film_surrounding_title_tag:I = 0x7f0a0b8f

.field public static final film_tag_view:I = 0x7f0a0b90

.field public static final film_ticket_num:I = 0x7f0a0b91

.field public static final film_time:I = 0x7f0a0b92

.field public static final film_title:I = 0x7f0a0b93

.field public static final film_version_recycle:I = 0x7f0a0b95

.field public static final film_version_txt:I = 0x7f0a0b96

.field public static final film_want_comment:I = 0x7f0a0b98

.field public static final film_year:I = 0x7f0a0b99

.field public static final filter_List:I = 0x7f0a0b9a

.field public static final filter_all:I = 0x7f0a0b9b

.field public static final filter_arrow:I = 0x7f0a0b9c

.field public static final filter_brand:I = 0x7f0a0b9d

.field public static final filter_btn_arrow:I = 0x7f0a0b9e

.field public static final filter_btn_container:I = 0x7f0a0b9f

.field public static final filter_btn_container2:I = 0x7f0a0ba0

.field public static final filter_btn_fl:I = 0x7f0a0ba1

.field public static final filter_btn_name:I = 0x7f0a0ba2

.field public static final filter_city:I = 0x7f0a0ba3

.field public static final filter_content:I = 0x7f0a0ba4

.field public static final filter_fast_filter_list:I = 0x7f0a0ba5

.field public static final filter_horizontal_base_filter_block:I = 0x7f0a0ba6

.field public static final filter_horizontal_calendar:I = 0x7f0a0ba7

.field public static final filter_horizontal_calendar_btn_layout:I = 0x7f0a0ba8

.field public static final filter_horizontal_calendar_layout:I = 0x7f0a0ba9

.field public static final filter_horizontal_main_block:I = 0x7f0a0baa

.field public static final filter_list:I = 0x7f0a0bab

.field public static final filter_main_tab_layout:I = 0x7f0a0bac

.field public static final filter_main_text:I = 0x7f0a0bad

.field public static final filter_mall_subway:I = 0x7f0a0bae

.field public static final filter_order:I = 0x7f0a0baf

.field public static final filter_panel:I = 0x7f0a0bb0

.field public static final filter_sub_container:I = 0x7f0a0bb1

.field public static final filter_sub_horizontal_scroll_view:I = 0x7f0a0bb2

.field public static final filter_tag_name:I = 0x7f0a0bb3

.field public static final filter_time_ui:I = 0x7f0a0bb4

.field public static final filter_timer:I = 0x7f0a0bb5

.field public static final filter_timer_arrow:I = 0x7f0a0bb6

.field public static final filter_tips:I = 0x7f0a0bb7

.field public static final filter_title:I = 0x7f0a0bb8

.field public static final filter_value:I = 0x7f0a0bb9

.field public static final filter_value_num:I = 0x7f0a0bba

.field public static final filter_view_content_root_container:I = 0x7f0a0bbb

.field public static final filter_view_title:I = 0x7f0a0bbc

.field public static final filter_view_title_bottom_divider:I = 0x7f0a0bbd

.field public static final filter_view_title_layout_container:I = 0x7f0a0bbe

.field public static final filter_view_title_layout_style1:I = 0x7f0a0bbf

.field public static final filter_view_title_layout_style2:I = 0x7f0a0bc0

.field public static final filter_view_title_top_divider:I = 0x7f0a0bc1

.field public static final find_tabbar_container:I = 0x7f0a0bc2

.field public static final first_day_of_month:I = 0x7f0a0bc3

.field public static final first_line:I = 0x7f0a0bc4

.field public static final fission_content_bg:I = 0x7f0a0bc5

.field public static final fission_content_down_bg:I = 0x7f0a0bc6

.field public static final fission_content_up_bg:I = 0x7f0a0bc7

.field public static final fission_image:I = 0x7f0a0bc8

.field public static final fission_image_bg:I = 0x7f0a0bc9

.field public static final fission_image_layout:I = 0x7f0a0bca

.field public static final fission_mask_layout:I = 0x7f0a0bcb

.field public static final fission_placeholer_circle:I = 0x7f0a0bcc

.field public static final fission_upgrade_chickensoup:I = 0x7f0a0bcd

.field public static final fission_upgrade_close:I = 0x7f0a0bce

.field public static final fission_upgrade_content_info:I = 0x7f0a0bcf

.field public static final fission_upgrade_entry_des:I = 0x7f0a0bd0

.field public static final fission_upgrade_gen_view:I = 0x7f0a0bd1

.field public static final fission_upgrade_holder:I = 0x7f0a0bd2

.field public static final fission_upgrade_image:I = 0x7f0a0bd3

.field public static final fission_upgrade_main_title:I = 0x7f0a0bd4

.field public static final fission_upgrade_name:I = 0x7f0a0bd5

.field public static final fission_upgrade_qrcode:I = 0x7f0a0bd6

.field public static final fission_upgrade_seat:I = 0x7f0a0bd7

.field public static final fission_upgrade_seat_des:I = 0x7f0a0bd8

.field public static final fission_upgrade_sep_line:I = 0x7f0a0bd9

.field public static final fission_upgrade_share_kinds:I = 0x7f0a0bda

.field public static final fission_upgrade_time:I = 0x7f0a0bdb

.field public static final fission_upgrade_time_des:I = 0x7f0a0bdc

.field public static final fission_upgrade_tip:I = 0x7f0a0bdd

.field public static final fission_upgrade_user_image:I = 0x7f0a0bde

.field public static final fission_upgrade_user_name:I = 0x7f0a0bdf

.field public static final fission_upgrade_venue:I = 0x7f0a0be0

.field public static final fission_upgrade_venue_des:I = 0x7f0a0be1

.field public static final fission_upgrade_view:I = 0x7f0a0be2

.field public static final fitBottomStart:I = 0x7f0a0be3

.field public static final fitCenter:I = 0x7f0a0be4

.field public static final fitEnd:I = 0x7f0a0be5

.field public static final fitHeight:I = 0x7f0a0be6

.field public static final fitStart:I = 0x7f0a0be7

.field public static final fitWidth:I = 0x7f0a0be9

.field public static final fitXY:I = 0x7f0a0bea

.field public static final fit_center:I = 0x7f0a0beb

.field public static final fit_end:I = 0x7f0a0bec

.field public static final fit_start:I = 0x7f0a0bed

.field public static final fit_xy:I = 0x7f0a0bee

.field public static final fixed:I = 0x7f0a0bef

.field public static final fixed_1_ui:I = 0x7f0a0bf0

.field public static final fixed_2_ui:I = 0x7f0a0bf1

.field public static final fixed_3_ui:I = 0x7f0a0bf2

.field public static final fixed_bg_img:I = 0x7f0a0bf3

.field public static final fixed_sub2_title:I = 0x7f0a0bf4

.field public static final fixed_sub_img:I = 0x7f0a0bf5

.field public static final fixed_sub_title:I = 0x7f0a0bf6

.field public static final flAddress:I = 0x7f0a0bf7

.field public static final fl_banner_image:I = 0x7f0a0bfb

.field public static final fl_bogo:I = 0x7f0a0bfc

.field public static final fl_cancel_btn:I = 0x7f0a0bfd

.field public static final fl_channel_brand_venue_container_rect:I = 0x7f0a0bfe

.field public static final fl_channel_brand_venue_item:I = 0x7f0a0bff

.field public static final fl_cinema_and_arrow:I = 0x7f0a0c00

.field public static final fl_comment_follow:I = 0x7f0a0c01

.field public static final fl_container_layout:I = 0x7f0a0c03

.field public static final fl_content_item_poster_container:I = 0x7f0a0c04

.field public static final fl_dm_img_container:I = 0x7f0a0c07

.field public static final fl_draw_btn:I = 0x7f0a0c09

.field public static final fl_electronic_view:I = 0x7f0a0c0b

.field public static final fl_film_detail_intro_egg:I = 0x7f0a0c0c

.field public static final fl_film_detail_intro_watching_tip:I = 0x7f0a0c0d

.field public static final fl_finish:I = 0x7f0a0c0e

.field public static final fl_ge_parent:I = 0x7f0a0c12

.field public static final fl_head_modify:I = 0x7f0a0c14

.field public static final fl_hotsearch:I = 0x7f0a0c16

.field public static final fl_inner:I = 0x7f0a0c19

.field public static final fl_login_platform_damai:I = 0x7f0a0c1e

.field public static final fl_main_content:I = 0x7f0a0c1f

.field public static final fl_ok_btn:I = 0x7f0a0c28

.field public static final fl_progress_loading:I = 0x7f0a0c2d

.field public static final fl_recomment_tag:I = 0x7f0a0c2f

.field public static final fl_refund_endorse:I = 0x7f0a0c30

.field public static final fl_sales:I = 0x7f0a0c33

.field public static final fl_sales2:I = 0x7f0a0c34

.field public static final fl_schedule_and_food_tab:I = 0x7f0a0c35

.field public static final fl_schedule_tag:I = 0x7f0a0c36

.field public static final fl_seat_spring_banner:I = 0x7f0a0c38

.field public static final fl_seekbar:I = 0x7f0a0c3b

.field public static final fl_shedule_info:I = 0x7f0a0c3c

.field public static final fl_spring_open_card_contain:I = 0x7f0a0c3f

.field public static final fl_surprise_red_closed_button:I = 0x7f0a0c43

.field public static final fl_tabindicator:I = 0x7f0a0c45

.field public static final fl_tag:I = 0x7f0a0c46

.field public static final fl_top:I = 0x7f0a0c4a

.field public static final fl_video_container:I = 0x7f0a0c4d

.field public static final fl_want_see_tips_container:I = 0x7f0a0c4e

.field public static final fl_wanted_normal_atmosphere:I = 0x7f0a0c4f

.field public static final fl_win:I = 0x7f0a0c50

.field public static final flash_red_packet:I = 0x7f0a0c51

.field public static final flash_red_packet_discount:I = 0x7f0a0c52

.field public static final flash_red_packet_discount_text_num:I = 0x7f0a0c53

.field public static final flash_red_packet_img:I = 0x7f0a0c54

.field public static final flash_red_packet_item_bg:I = 0x7f0a0c55

.field public static final flash_red_packet_item_btn:I = 0x7f0a0c56

.field public static final flash_red_packet_item_des:I = 0x7f0a0c57

.field public static final flash_red_packet_item_flash_tag:I = 0x7f0a0c58

.field public static final flash_red_packet_item_portrait:I = 0x7f0a0c59

.field public static final flash_red_packet_item_subtitle:I = 0x7f0a0c5a

.field public static final flash_red_packet_item_timer:I = 0x7f0a0c5b

.field public static final flash_red_packet_item_tip:I = 0x7f0a0c5c

.field public static final flash_red_packet_item_title:I = 0x7f0a0c5d

.field public static final flash_red_packet_text:I = 0x7f0a0c5e

.field public static final flash_view:I = 0x7f0a0c5f

.field public static final flex_bg_layout:I = 0x7f0a0c60

.field public static final flex_city:I = 0x7f0a0c61

.field public static final flex_end:I = 0x7f0a0c62

.field public static final flex_start:I = 0x7f0a0c64

.field public static final flex_tab:I = 0x7f0a0c65

.field public static final flexbox_layout_album:I = 0x7f0a0c66

.field public static final flexboxlayout:I = 0x7f0a0c67

.field public static final flip:I = 0x7f0a0c68

.field public static final flipper_tag_zone:I = 0x7f0a0c69

.field public static final float_category_list:I = 0x7f0a0c6a

.field public static final float_category_list_main_lv:I = 0x7f0a0c6b

.field public static final float_category_list_sub_lv:I = 0x7f0a0c6c

.field public static final floating:I = 0x7f0a0c6d

.field public static final floorChooser:I = 0x7f0a0c6e

.field public static final flow_layout:I = 0x7f0a0c70

.field public static final focusCrop:I = 0x7f0a0c71

.field public static final follow_btn:I = 0x7f0a0c73

.field public static final follow_tv:I = 0x7f0a0c78

.field public static final fontSize_select:I = 0x7f0a0c7b

.field public static final food_empty_view:I = 0x7f0a0c7c

.field public static final foot:I = 0x7f0a0c7e

.field public static final foot_icon:I = 0x7f0a0c7f

.field public static final foot_tv:I = 0x7f0a0c80

.field public static final footer:I = 0x7f0a0c81

.field public static final footer_classics_progress:I = 0x7f0a0c82

.field public static final footer_container:I = 0x7f0a0c83

.field public static final footer_content:I = 0x7f0a0c84

.field public static final footer_line:I = 0x7f0a0c85

.field public static final foregroundView:I = 0x7f0a0c86

.field public static final forever:I = 0x7f0a0c87

.field public static final forth_line:I = 0x7f0a0c88

.field public static final fragment:I = 0x7f0a0c91

.field public static final fragment_container:I = 0x7f0a0c92

.field public static final fragment_container_view_tag:I = 0x7f0a0c93

.field public static final fragment_discount:I = 0x7f0a0c94

.field public static final fragment_price_detail:I = 0x7f0a0c95

.field public static final fragment_root:I = 0x7f0a0c96

.field public static final fragment_view:I = 0x7f0a0c97

.field public static final frameContent:I = 0x7f0a0c98

.field public static final framework_slice:I = 0x7f0a0c99

.field public static final friday:I = 0x7f0a0c9a

.field public static final friend_tag:I = 0x7f0a0c9b

.field public static final friend_tag_click_block:I = 0x7f0a0c9c

.field public static final friend_tag_focused:I = 0x7f0a0c9d

.field public static final friend_tag_unfocused:I = 0x7f0a0c9e

.field public static final frost:I = 0x7f0a0c9f

.field public static final full_screen_btn:I = 0x7f0a0ca0

.field public static final gaiax_render_root_parent:I = 0x7f0a0ca4

.field public static final gaiax_rv_touch:I = 0x7f0a0ca5

.field public static final gallery:I = 0x7f0a0ca6

.field public static final gap_view1:I = 0x7f0a0ca7

.field public static final ge_view_wish:I = 0x7f0a0cab

.field public static final ghost_view:I = 0x7f0a0cac

.field public static final ghost_view_holder:I = 0x7f0a0cad

.field public static final glass_message:I = 0x7f0a0cae

.field public static final gone:I = 0x7f0a0cb2

.field public static final goods_activity_container:I = 0x7f0a0cb3

.field public static final goods_desc:I = 0x7f0a0cb4

.field public static final goto_detail:I = 0x7f0a0cb6

.field public static final goto_home:I = 0x7f0a0cb7

.field public static final goto_single:I = 0x7f0a0cc0

.field public static final grab_container:I = 0x7f0a0cc5

.field public static final grab_container_bg_level_2:I = 0x7f0a0cc6

.field public static final grab_countdown_view:I = 0x7f0a0cc7

.field public static final grab_film_container:I = 0x7f0a0cc8

.field public static final grab_price_view:I = 0x7f0a0cc9

.field public static final grab_price_view_container:I = 0x7f0a0cca

.field public static final grab_right:I = 0x7f0a0ccb

.field public static final grab_time_img:I = 0x7f0a0ccc

.field public static final grab_time_rl:I = 0x7f0a0ccd

.field public static final grab_time_rl_root:I = 0x7f0a0cce

.field public static final grab_time_tv:I = 0x7f0a0ccf

.field public static final grab_time_tv_suffix:I = 0x7f0a0cd0

.field public static final gradient:I = 0x7f0a0cd3

.field public static final grid:I = 0x7f0a0ce1

.field public static final grid_container:I = 0x7f0a0ce2

.field public static final gridview:I = 0x7f0a0ce3

.field public static final group_artist_list:I = 0x7f0a0ce4

.field public static final group_artist_list_content_block:I = 0x7f0a0ce5

.field public static final group_artist_list_end_cover:I = 0x7f0a0ce6

.field public static final group_artist_list_icon:I = 0x7f0a0ce7

.field public static final group_artist_list_tips:I = 0x7f0a0ce8

.field public static final group_artist_list_title:I = 0x7f0a0ce9

.field public static final group_artist_list_title_block:I = 0x7f0a0cea

.field public static final group_booking_block_Add_btn:I = 0x7f0a0ceb

.field public static final group_booking_block_member_container:I = 0x7f0a0cec

.field public static final group_booking_block_member_container_cover:I = 0x7f0a0ced

.field public static final group_booking_invite_btn:I = 0x7f0a0cee

.field public static final group_booking_invite_btn_block:I = 0x7f0a0cef

.field public static final group_booking_invite_btn_tip:I = 0x7f0a0cf0

.field public static final group_booking_status_block:I = 0x7f0a0cf1

.field public static final group_booking_status_subtitle:I = 0x7f0a0cf2

.field public static final group_booking_status_title:I = 0x7f0a0cf3

.field public static final group_buy_layout:I = 0x7f0a0cf4

.field public static final group_buy_sale_tag:I = 0x7f0a0cf5

.field public static final group_buy_title:I = 0x7f0a0cf6

.field public static final group_city_cluster_list_content_block:I = 0x7f0a0cf7

.field public static final group_city_cluster_list_end_cover:I = 0x7f0a0cf8

.field public static final group_city_list:I = 0x7f0a0cf9

.field public static final group_divider:I = 0x7f0a0cfa

.field public static final group_filter:I = 0x7f0a0cfb

.field public static final group_float_select_list_icon:I = 0x7f0a0cfc

.field public static final group_float_select_list_tips:I = 0x7f0a0cfd

.field public static final group_float_select_list_title:I = 0x7f0a0cfe

.field public static final group_items_container:I = 0x7f0a0cff

.field public static final group_list:I = 0x7f0a0d00

.field public static final group_name:I = 0x7f0a0d01

.field public static final group_select_float_list:I = 0x7f0a0d02

.field public static final group_select_float_list_title_block:I = 0x7f0a0d03

.field public static final group_title:I = 0x7f0a0d04

.field public static final groupbuy_toast:I = 0x7f0a0d05

.field public static final groups:I = 0x7f0a0d07

.field public static final guess_you_like_root:I = 0x7f0a0d08

.field public static final guid_dialog_title_close_btn:I = 0x7f0a0d09

.field public static final guid_dialog_title_des_tv:I = 0x7f0a0d0a

.field public static final guide:I = 0x7f0a0d0b

.field public static final guide_bottom:I = 0x7f0a0d0c

.field public static final guide_desc:I = 0x7f0a0d0d

.field public static final guide_zone:I = 0x7f0a0d10

.field public static final guideline:I = 0x7f0a0d11

.field public static final h5_share_menu:I = 0x7f0a0d12

.field public static final h_project_card_layout:I = 0x7f0a0d13

.field public static final h_ratio_max_80_auto_fill:I = 0x7f0a0d14

.field public static final h_ratio_min_50_max_80_auto_fill:I = 0x7f0a0d15

.field public static final half_solid_tag_left:I = 0x7f0a0d17

.field public static final half_solid_tag_right:I = 0x7f0a0d18

.field public static final hall:I = 0x7f0a0d19

.field public static final hall_num:I = 0x7f0a0d1a

.field public static final halo_left:I = 0x7f0a0d1b

.field public static final halo_right:I = 0x7f0a0d1c

.field public static final happy_coin_bg:I = 0x7f0a0d1d

.field public static final happy_coin_container:I = 0x7f0a0d1e

.field public static final happy_coin_dialog_contain:I = 0x7f0a0d1f

.field public static final happy_coin_dialog_double:I = 0x7f0a0d20

.field public static final happy_coin_dialog_double_button:I = 0x7f0a0d21

.field public static final happy_coin_dialog_double_success:I = 0x7f0a0d22

.field public static final happy_coin_dialog_double_success_msg:I = 0x7f0a0d23

.field public static final happy_coin_double_count:I = 0x7f0a0d24

.field public static final happy_coin_double_icon:I = 0x7f0a0d25

.field public static final happy_coin_icon:I = 0x7f0a0d26

.field public static final happy_coin_right:I = 0x7f0a0d27

.field public static final happy_coin_text:I = 0x7f0a0d28

.field public static final happy_coin_top_View:I = 0x7f0a0d29

.field public static final hardware:I = 0x7f0a0d2a

.field public static final has_boxing_office_rank:I = 0x7f0a0d2b

.field public static final has_prize:I = 0x7f0a0d2e

.field public static final head:I = 0x7f0a0d32

.field public static final head_bar:I = 0x7f0a0d35

.field public static final head_icon:I = 0x7f0a0d36

.field public static final head_layout:I = 0x7f0a0d38

.field public static final header:I = 0x7f0a0d39

.field public static final header_content:I = 0x7f0a0d3f

.field public static final header_image:I = 0x7f0a0d40

.field public static final header_image_platform_icon:I = 0x7f0a0d41

.field public static final header_layout:I = 0x7f0a0d42

.field public static final header_left_back:I = 0x7f0a0d43

.field public static final header_search_v2_cancel:I = 0x7f0a0d51

.field public static final header_search_v2_input:I = 0x7f0a0d52

.field public static final header_search_v2_input_bg:I = 0x7f0a0d53

.field public static final header_search_v2_input_delete:I = 0x7f0a0d54

.field public static final header_search_v2_space:I = 0x7f0a0d55

.field public static final header_search_v2_ui:I = 0x7f0a0d56

.field public static final header_title:I = 0x7f0a0d5a

.field public static final header_view:I = 0x7f0a0d5d

.field public static final height:I = 0x7f0a0d5f

.field public static final help_emoji_image:I = 0x7f0a0d60

.field public static final help_text:I = 0x7f0a0d61

.field public static final hide_in_inspector_tag:I = 0x7f0a0d62

.field public static final historyList:I = 0x7f0a0d65

.field public static final history_text:I = 0x7f0a0d68

.field public static final history_text_ift:I = 0x7f0a0d69

.field public static final holder:I = 0x7f0a0d6a

.field public static final holder_id:I = 0x7f0a0d6b

.field public static final holecardView:I = 0x7f0a0d6d

.field public static final holiday_tag_text:I = 0x7f0a0d6e

.field public static final holiday_tips:I = 0x7f0a0d6f

.field public static final home:I = 0x7f0a0d70

.field public static final homeAsUp:I = 0x7f0a0d71

.field public static final home_bg_pull:I = 0x7f0a0d72

.field public static final home_calendar_bg:I = 0x7f0a0d73

.field public static final home_calendar_bg_lottie_v2:I = 0x7f0a0d74

.field public static final home_calendar_bg_pic_v2:I = 0x7f0a0d75

.field public static final home_calendar_container:I = 0x7f0a0d76

.field public static final home_calendar_container_v2:I = 0x7f0a0d77

.field public static final home_calendar_content:I = 0x7f0a0d78

.field public static final home_calendar_right_icon_v2:I = 0x7f0a0d79

.field public static final home_calendar_subTitle_v2:I = 0x7f0a0d7a

.field public static final home_calendar_title:I = 0x7f0a0d7b

.field public static final home_calendar_title_v2:I = 0x7f0a0d7c

.field public static final home_calender_content_arrow:I = 0x7f0a0d7d

.field public static final home_calender_content_text:I = 0x7f0a0d7e

.field public static final home_grab_content_text:I = 0x7f0a0d8f

.field public static final home_head_default_bg:I = 0x7f0a0d90

.field public static final home_head_second_floor_background:I = 0x7f0a0d91

.field public static final home_head_second_floor_pic:I = 0x7f0a0d95

.field public static final home_notice_arrow:I = 0x7f0a0d97

.field public static final home_notice_content:I = 0x7f0a0d98

.field public static final home_page_guide:I = 0x7f0a0d99

.field public static final home_pull_refresh_bg:I = 0x7f0a0d9f

.field public static final home_tile_calendar_iv_shadow:I = 0x7f0a0da0

.field public static final home_tile_calendar_iv_shadow_bottom:I = 0x7f0a0da1

.field public static final home_tile_calendar_iv_shadow_poster1:I = 0x7f0a0da2

.field public static final home_tile_ranking_iv_shadow:I = 0x7f0a0da3

.field public static final home_tile_ranking_iv_shadow_bottom:I = 0x7f0a0da4

.field public static final home_tile_ranking_iv_shadow_poster1:I = 0x7f0a0da5

.field public static final home_tile_ranking_iv_shadow_poster2:I = 0x7f0a0da6

.field public static final home_tile_ranking_iv_shadowleft:I = 0x7f0a0da7

.field public static final home_tile_ranking_iv_shadowright:I = 0x7f0a0da8

.field public static final home_video_mask_root:I = 0x7f0a0da9

.field public static final homepage_announcement_arrow:I = 0x7f0a0daf

.field public static final homepage_announcement_content:I = 0x7f0a0db0

.field public static final homepage_announcement_layout:I = 0x7f0a0db1

.field public static final homepage_banner:I = 0x7f0a0db2

.field public static final homepage_eva_cancel:I = 0x7f0a0db3

.field public static final homepage_eva_desc:I = 0x7f0a0db4

.field public static final homepage_eva_full_star_lottie:I = 0x7f0a0db5

.field public static final homepage_eva_grade_desc:I = 0x7f0a0db6

.field public static final homepage_eva_grade_view:I = 0x7f0a0db7

.field public static final homepage_eva_layout:I = 0x7f0a0db8

.field public static final homepage_eva_project_image:I = 0x7f0a0db9

.field public static final homepage_eva_project_name:I = 0x7f0a0dba

.field public static final homepage_evaluate_holder:I = 0x7f0a0dbb

.field public static final homepage_evaluate_layout:I = 0x7f0a0dbc

.field public static final homepage_grab_ticket_cntainer:I = 0x7f0a0dbe

.field public static final homepage_grab_ticket_item_heightlight_text:I = 0x7f0a0dbf

.field public static final homepage_grab_ticket_item_text:I = 0x7f0a0dc0

.field public static final homepage_grab_ticket_label:I = 0x7f0a0dc1

.field public static final homepage_header_bar:I = 0x7f0a0dc2

.field public static final homepage_header_cert_info:I = 0x7f0a0dc3

.field public static final homepage_header_container:I = 0x7f0a0dc4

.field public static final homepage_header_search:I = 0x7f0a0dcb

.field public static final homepage_header_search_btn:I = 0x7f0a0dcc

.field public static final homepage_header_search_layout:I = 0x7f0a0dcd

.field public static final homepage_item_bottom_left:I = 0x7f0a0dd4

.field public static final homepage_item_buy_tickets_btn:I = 0x7f0a0dd5

.field public static final homepage_item_discountDesc:I = 0x7f0a0dd6

.field public static final homepage_item_dm_common_price_view:I = 0x7f0a0dd7

.field public static final homepage_item_dm_common_price_view_custom:I = 0x7f0a0dd8

.field public static final homepage_item_image_border:I = 0x7f0a0dd9

.field public static final homepage_item_image_normal:I = 0x7f0a0dda

.field public static final homepage_item_image_normal_cover:I = 0x7f0a0ddb

.field public static final homepage_item_image_tag:I = 0x7f0a0ddc

.field public static final homepage_item_poster_block:I = 0x7f0a0ddd

.field public static final homepage_item_price:I = 0x7f0a0dde

.field public static final homepage_item_price_flag:I = 0x7f0a0ddf

.field public static final homepage_item_price_layout:I = 0x7f0a0de0

.field public static final homepage_item_price_line:I = 0x7f0a0de1

.field public static final homepage_item_price_preferential:I = 0x7f0a0de2

.field public static final homepage_item_price_preferential_flag:I = 0x7f0a0de3

.field public static final homepage_item_price_preferential_lottie_big:I = 0x7f0a0de4

.field public static final homepage_item_price_preferential_lottie_little:I = 0x7f0a0de5

.field public static final homepage_item_show_time:I = 0x7f0a0de6

.field public static final homepage_item_subinfo:I = 0x7f0a0de7

.field public static final homepage_item_tag_view:I = 0x7f0a0de8

.field public static final homepage_module_title_label:I = 0x7f0a0dea

.field public static final homepage_module_title_more_arrow:I = 0x7f0a0deb

.field public static final homepage_module_title_more_layout:I = 0x7f0a0dec

.field public static final homepage_module_title_more_text:I = 0x7f0a0ded

.field public static final homepage_popup_window_close_btn:I = 0x7f0a0df0

.field public static final homepage_popup_window_dna:I = 0x7f0a0df1

.field public static final homepage_popup_window_image:I = 0x7f0a0df2

.field public static final homepage_project_item_title:I = 0x7f0a0df3

.field public static final homepage_project_item_title_endcover:I = 0x7f0a0df4

.field public static final homepage_project_item_title_holder:I = 0x7f0a0df5

.field public static final homepage_project_item_title_wide:I = 0x7f0a0df6

.field public static final homepage_rank_item_image_normal:I = 0x7f0a0df7

.field public static final homepage_rank_item_image_tag:I = 0x7f0a0df8

.field public static final homepage_rank_item_live_room:I = 0x7f0a0df9

.field public static final homepage_rank_item_price:I = 0x7f0a0dfa

.field public static final homepage_rank_item_price_flag:I = 0x7f0a0dfb

.field public static final homepage_rank_item_price_label:I = 0x7f0a0dfc

.field public static final homepage_rank_item_price_layout:I = 0x7f0a0dfd

.field public static final homepage_rank_item_price_unknown:I = 0x7f0a0dfe

.field public static final homepage_rank_item_rank:I = 0x7f0a0dff

.field public static final homepage_rank_item_tag_view:I = 0x7f0a0e00

.field public static final homepage_rank_item_time:I = 0x7f0a0e01

.field public static final homepage_rank_item_title:I = 0x7f0a0e02

.field public static final homepage_rank_line_divider:I = 0x7f0a0e03

.field public static final homepage_rank_recyclerview:I = 0x7f0a0e04

.field public static final homepage_rank_top_item_image:I = 0x7f0a0e05

.field public static final homepage_rank_top_item_subtitle:I = 0x7f0a0e06

.field public static final homepage_rank_top_item_title:I = 0x7f0a0e07

.field public static final homepage_rank_top_more_layout:I = 0x7f0a0e08

.field public static final homepage_rank_top_more_text:I = 0x7f0a0e09

.field public static final homepage_rank_top_recyclerview:I = 0x7f0a0e0a

.field public static final homepage_rank_top_tablayout:I = 0x7f0a0e0b

.field public static final homepage_rank_top_viewpager:I = 0x7f0a0e0c

.field public static final homepage_recent_more_layout:I = 0x7f0a0e0d

.field public static final homepage_recent_more_text:I = 0x7f0a0e0e

.field public static final homepage_recent_page_divider:I = 0x7f0a0e0f

.field public static final homepage_recent_recyclerview:I = 0x7f0a0e10

.field public static final homepage_recent_tablayout:I = 0x7f0a0e11

.field public static final homepage_recent_viewpager:I = 0x7f0a0e12

.field public static final homepage_star_tour_arrow:I = 0x7f0a0e14

.field public static final homepage_star_tour_card:I = 0x7f0a0e15

.field public static final homepage_star_tour_city_count:I = 0x7f0a0e16

.field public static final homepage_star_tour_city_list:I = 0x7f0a0e17

.field public static final homepage_star_tour_city_name:I = 0x7f0a0e18

.field public static final homepage_star_tour_count:I = 0x7f0a0e19

.field public static final homepage_star_tour_project_city:I = 0x7f0a0e1a

.field public static final homepage_star_tour_project_city_venue:I = 0x7f0a0e1b

.field public static final homepage_star_tour_project_image:I = 0x7f0a0e1c

.field public static final homepage_star_tour_project_layout:I = 0x7f0a0e1d

.field public static final homepage_star_tour_project_line:I = 0x7f0a0e1e

.field public static final homepage_star_tour_project_price:I = 0x7f0a0e1f

.field public static final homepage_star_tour_project_price_layout:I = 0x7f0a0e20

.field public static final homepage_star_tour_project_price_unknown:I = 0x7f0a0e21

.field public static final homepage_star_tour_project_time:I = 0x7f0a0e22

.field public static final homepage_star_tour_project_title:I = 0x7f0a0e23

.field public static final homepage_star_tour_project_venue:I = 0x7f0a0e24

.field public static final homepage_star_tour_star:I = 0x7f0a0e25

.field public static final homepage_star_tour_star_avatar:I = 0x7f0a0e26

.field public static final homepage_star_tour_star_name:I = 0x7f0a0e27

.field public static final homepage_star_tour_tab:I = 0x7f0a0e28

.field public static final homepage_star_tour_tab_name:I = 0x7f0a0e29

.field public static final homepage_star_tour_v_tag:I = 0x7f0a0e2a

.field public static final homepage_tv_title_cert_info:I = 0x7f0a0e39

.field public static final homepage_video_cover:I = 0x7f0a0e3a

.field public static final homepage_video_cover_v2:I = 0x7f0a0e3b

.field public static final homepage_video_item_btn_single:I = 0x7f0a0e3c

.field public static final homepage_video_item_buy_btn:I = 0x7f0a0e3d

.field public static final homepage_video_item_buy_btnarrow:I = 0x7f0a0e3e

.field public static final homepage_video_item_desc:I = 0x7f0a0e3f

.field public static final homepage_video_item_image:I = 0x7f0a0e40

.field public static final homepage_video_item_image_layout:I = 0x7f0a0e41

.field public static final homepage_video_item_price:I = 0x7f0a0e42

.field public static final homepage_video_item_price_flag:I = 0x7f0a0e43

.field public static final homepage_video_item_price_layout:I = 0x7f0a0e44

.field public static final homepage_video_item_tag:I = 0x7f0a0e45

.field public static final homepage_video_item_title:I = 0x7f0a0e46

.field public static final homepage_video_play_border:I = 0x7f0a0e47

.field public static final homepage_video_play_cover:I = 0x7f0a0e48

.field public static final homepage_video_player:I = 0x7f0a0e49

.field public static final homepage_video_player_v2:I = 0x7f0a0e4a

.field public static final homepage_video_poster_mask:I = 0x7f0a0e4b

.field public static final homepage_video_project_list:I = 0x7f0a0e4c

.field public static final homepage_video_project_list_v2:I = 0x7f0a0e4d

.field public static final homepage_want_see_tablayout:I = 0x7f0a0e4e

.field public static final homepage_want_see_viewpager:I = 0x7f0a0e4f

.field public static final homepage_water_flow_rank_gradient:I = 0x7f0a0e50

.field public static final homepage_waterflow_circle_avatar_view:I = 0x7f0a0e5b

.field public static final homepage_waterflow_circle_imgview:I = 0x7f0a0e5c

.field public static final homepage_waterflow_circle_ll:I = 0x7f0a0e5d

.field public static final homepage_waterflow_circle_tag:I = 0x7f0a0e5e

.field public static final homepage_waterflow_circle_title:I = 0x7f0a0e5f

.field public static final homepage_waterflow_circle_title_fansnum:I = 0x7f0a0e60

.field public static final homepage_waterflow_circle_title_subtitle:I = 0x7f0a0e61

.field public static final homepage_waterflow_coupon_get_btn:I = 0x7f0a0e62

.field public static final homepage_waterflow_coupon_image:I = 0x7f0a0e63

.field public static final homepage_waterflow_coupon_layout:I = 0x7f0a0e64

.field public static final homepage_waterflow_coupon_money:I = 0x7f0a0e65

.field public static final homepage_waterflow_coupon_rmb_symbol:I = 0x7f0a0e67

.field public static final homepage_waterflow_coupon_subtitle:I = 0x7f0a0e68

.field public static final homepage_waterflow_coupon_title:I = 0x7f0a0e69

.field public static final homepage_waterflow_img_rc:I = 0x7f0a0e79

.field public static final homepage_waterflow_markting_price:I = 0x7f0a0e7b

.field public static final homepage_waterflow_rank_image:I = 0x7f0a0e7c

.field public static final homepage_waterflow_rank_image_layout:I = 0x7f0a0e7d

.field public static final homepage_waterflow_rank_subtitle:I = 0x7f0a0e7e

.field public static final homepage_waterflow_rank_title:I = 0x7f0a0e7f

.field public static final homepage_waterflow_rank_type:I = 0x7f0a0e80

.field public static final homepage_waterflow_ranklist_bg:I = 0x7f0a0e81

.field public static final homepage_waterflow_recommend_ranklist_tag_img:I = 0x7f0a0e83

.field public static final homepage_waterflow_venues_desc:I = 0x7f0a0e85

.field public static final homepage_waterflow_venues_desc_bottom_dash:I = 0x7f0a0e86

.field public static final homepage_waterflow_venues_desc_top_dash:I = 0x7f0a0e87

.field public static final homepage_waterflow_venues_entrance_btn:I = 0x7f0a0e88

.field public static final homepage_waterflow_venues_entrance_btn_text:I = 0x7f0a0e89

.field public static final homepage_waterflow_venues_header_icon:I = 0x7f0a0e8a

.field public static final homepage_waterflow_venues_header_icon_layout:I = 0x7f0a0e8b

.field public static final homepage_waterflow_venues_header_v_icon:I = 0x7f0a0e8c

.field public static final homepage_waterflow_venues_image:I = 0x7f0a0e8d

.field public static final homepage_waterflow_venues_name:I = 0x7f0a0e8e

.field public static final homepage_waterflow_venues_shade:I = 0x7f0a0e8f

.field public static final homepage_waterflow_venues_tag:I = 0x7f0a0e90

.field public static final hometab_scrollView:I = 0x7f0a0e95

.field public static final honorRequest:I = 0x7f0a0e96

.field public static final horScrollView:I = 0x7f0a0e97

.field public static final horizontal:I = 0x7f0a0e98

.field public static final horizontal_container:I = 0x7f0a0e99

.field public static final horizontal_left:I = 0x7f0a0e9b

.field public static final horizontal_only:I = 0x7f0a0e9c

.field public static final horizontal_progress:I = 0x7f0a0e9d

.field public static final horizontal_right:I = 0x7f0a0e9e

.field public static final hot_city_list:I = 0x7f0a0e9f

.field public static final hotrecommend_subtitle:I = 0x7f0a0ec2

.field public static final hotrecommend_subtitle_content:I = 0x7f0a0ec3

.field public static final href:I = 0x7f0a0ec8

.field public static final hrv_canlendar:I = 0x7f0a0ec9

.field public static final hrv_galley:I = 0x7f0a0ecb

.field public static final hrv_view:I = 0x7f0a0ece

.field public static final hv_container:I = 0x7f0a0ed2

.field public static final ib_gress:I = 0x7f0a0ed3

.field public static final ib_search:I = 0x7f0a0ed4

.field public static final ic_sku_state_view_charm:I = 0x7f0a0eda

.field public static final ic_sku_state_view_top_skeleton_charm:I = 0x7f0a0edb

.field public static final icb_check:I = 0x7f0a0edd

.field public static final icb_check_container:I = 0x7f0a0ede

.field public static final icb_protocol_text:I = 0x7f0a0edf

.field public static final icon:I = 0x7f0a0ee0

.field public static final icon1:I = 0x7f0a0ee1

.field public static final icon2:I = 0x7f0a0ee2

.field public static final icon3:I = 0x7f0a0ee3

.field public static final icon4:I = 0x7f0a0ee4

.field public static final icon5:I = 0x7f0a0ee5

.field public static final icon_activity_right_arrow:I = 0x7f0a0ee6

.field public static final icon_arrow:I = 0x7f0a0ee7

.field public static final icon_back:I = 0x7f0a0ee8

.field public static final icon_check:I = 0x7f0a0eec

.field public static final icon_close:I = 0x7f0a0eed

.field public static final icon_copy:I = 0x7f0a0eee

.field public static final icon_fans:I = 0x7f0a0ef0

.field public static final icon_friend:I = 0x7f0a0ef1

.field public static final icon_generate_image:I = 0x7f0a0ef3

.field public static final icon_glass:I = 0x7f0a0ef4

.field public static final icon_group:I = 0x7f0a0ef5

.field public static final icon_phone:I = 0x7f0a0f06

.field public static final icon_play:I = 0x7f0a0f07

.field public static final icon_play_mini_tv:I = 0x7f0a0f08

.field public static final icon_pull_double_arrow:I = 0x7f0a0f0a

.field public static final icon_right_arrow:I = 0x7f0a0f0d

.field public static final icon_save:I = 0x7f0a0f0e

.field public static final icon_search_info_item_video:I = 0x7f0a0f0f

.field public static final icon_sousuo:I = 0x7f0a0f10

.field public static final icon_star_five:I = 0x7f0a0f11

.field public static final icon_star_four:I = 0x7f0a0f12

.field public static final icon_star_header:I = 0x7f0a0f13

.field public static final icon_star_one:I = 0x7f0a0f14

.field public static final icon_star_three:I = 0x7f0a0f15

.field public static final icon_star_two:I = 0x7f0a0f16

.field public static final icon_star_vip:I = 0x7f0a0f17

.field public static final icon_weibo:I = 0x7f0a0f1a

.field public static final icon_wx:I = 0x7f0a0f1b

.field public static final iconf_coupon_package:I = 0x7f0a0f1c

.field public static final iconf_current_city:I = 0x7f0a0f1d

.field public static final iconfont_xf_jiantoubig_you:I = 0x7f0a0f1f

.field public static final idCard:I = 0x7f0a0f20

.field public static final idTypeName:I = 0x7f0a0f21

.field public static final id_artist_card_address_or_actor:I = 0x7f0a0f22

.field public static final id_artist_card_head_pic_blur:I = 0x7f0a0f23

.field public static final id_artist_card_status_tv:I = 0x7f0a0f24

.field public static final id_artist_card_time_or_director_tv:I = 0x7f0a0f25

.field public static final id_artist_card_title:I = 0x7f0a0f26

.field public static final id_artist_card_video_pic:I = 0x7f0a0f27

.field public static final id_artist_card_video_pic_blur:I = 0x7f0a0f28

.field public static final id_artist_card_video_pic_layout:I = 0x7f0a0f29

.field public static final id_artist_card_video_play_icon:I = 0x7f0a0f2a

.field public static final id_artist_card_vip_desc:I = 0x7f0a0f2b

.field public static final id_artist_card_vip_icon:I = 0x7f0a0f2c

.field public static final id_artist_card_vip_layout:I = 0x7f0a0f2d

.field public static final id_artist_history_ip_fans_layout:I = 0x7f0a0f2e

.field public static final id_artist_history_ip_img:I = 0x7f0a0f2f

.field public static final id_artist_history_ip_name:I = 0x7f0a0f30

.field public static final id_artist_history_ip_sell_layout:I = 0x7f0a0f31

.field public static final id_artist_history_ip_year:I = 0x7f0a0f32

.field public static final id_artist_project_poster:I = 0x7f0a0f33

.field public static final id_artist_project_poster_tag_view:I = 0x7f0a0f34

.field public static final id_artist_project_score_want_layout:I = 0x7f0a0f35

.field public static final id_artist_project_vip_btn:I = 0x7f0a0f36

.field public static final id_artist_project_vip_btn_arrow:I = 0x7f0a0f37

.field public static final id_artist_project_vip_btn_tv:I = 0x7f0a0f38

.field public static final id_bind_view_holder:I = 0x7f0a0f39

.field public static final id_bottom_action_ui:I = 0x7f0a0f3e

.field public static final id_bricks_artist_avatar:I = 0x7f0a0f41

.field public static final id_bricks_artist_bottom_layout:I = 0x7f0a0f42

.field public static final id_bricks_artist_descarrow:I = 0x7f0a0f43

.field public static final id_bricks_artist_descll:I = 0x7f0a0f44

.field public static final id_bricks_artist_desctv:I = 0x7f0a0f45

.field public static final id_bricks_artist_divider:I = 0x7f0a0f46

.field public static final id_bricks_artist_fans_layout:I = 0x7f0a0f47

.field public static final id_bricks_artist_fans_layout_container:I = 0x7f0a0f48

.field public static final id_bricks_artist_fans_tips:I = 0x7f0a0f49

.field public static final id_bricks_artist_follow:I = 0x7f0a0f4a

.field public static final id_bricks_artist_guide_img:I = 0x7f0a0f4b

.field public static final id_bricks_artist_guide_layout:I = 0x7f0a0f4c

.field public static final id_bricks_artist_guide_text:I = 0x7f0a0f4d

.field public static final id_bricks_artist_head_bg1:I = 0x7f0a0f4e

.field public static final id_bricks_artist_head_img:I = 0x7f0a0f4f

.field public static final id_bricks_artist_head_layout:I = 0x7f0a0f50

.field public static final id_bricks_artist_head_layout_container:I = 0x7f0a0f51

.field public static final id_bricks_artist_head_mask:I = 0x7f0a0f52

.field public static final id_bricks_artist_head_shining:I = 0x7f0a0f53

.field public static final id_bricks_artist_head_video:I = 0x7f0a0f54

.field public static final id_bricks_artist_info_container:I = 0x7f0a0f55

.field public static final id_bricks_artist_info_divider:I = 0x7f0a0f56

.field public static final id_bricks_artist_infoview:I = 0x7f0a0f57

.field public static final id_bricks_artist_name:I = 0x7f0a0f58

.field public static final id_bricks_artist_name_container:I = 0x7f0a0f59

.field public static final id_bricks_artist_name_tv:I = 0x7f0a0f5a

.field public static final id_bricks_artist_sell_layout:I = 0x7f0a0f5b

.field public static final id_bricks_artist_tour_dark_layer:I = 0x7f0a0f5c

.field public static final id_bricks_artist_tour_dark_layer_bg:I = 0x7f0a0f5d

.field public static final id_bricks_artist_tour_layout:I = 0x7f0a0f5e

.field public static final id_bricks_artist_vip_tag:I = 0x7f0a0f5f

.field public static final id_bricks_banner_container:I = 0x7f0a0f60

.field public static final id_bricks_banner_indicator_view:I = 0x7f0a0f61

.field public static final id_bricks_banner_normal_img_bg:I = 0x7f0a0f62

.field public static final id_bricks_banner_sub_img_container:I = 0x7f0a0f63

.field public static final id_bricks_banner_super_color_bg:I = 0x7f0a0f64

.field public static final id_bricks_banner_super_gradient_bg:I = 0x7f0a0f65

.field public static final id_bricks_banner_super_img1:I = 0x7f0a0f66

.field public static final id_bricks_banner_super_img2:I = 0x7f0a0f67

.field public static final id_bricks_banner_super_img3:I = 0x7f0a0f68

.field public static final id_bricks_banner_super_img_bg:I = 0x7f0a0f69

.field public static final id_bricks_banner_super_text1:I = 0x7f0a0f6a

.field public static final id_bricks_banner_super_text2:I = 0x7f0a0f6b

.field public static final id_bricks_banner_super_text3:I = 0x7f0a0f6c

.field public static final id_bricks_calendar_day_flip:I = 0x7f0a0f6e

.field public static final id_bricks_calendar_desc:I = 0x7f0a0f6f

.field public static final id_bricks_calendar_month_flip:I = 0x7f0a0f70

.field public static final id_bricks_calendar_week:I = 0x7f0a0f71

.field public static final id_bricks_calendar_week_first:I = 0x7f0a0f72

.field public static final id_bricks_ci_copy:I = 0x7f0a0f73

.field public static final id_bricks_ci_info:I = 0x7f0a0f74

.field public static final id_bricks_coq_tv:I = 0x7f0a0f75

.field public static final id_bricks_cor_rule_img:I = 0x7f0a0f76

.field public static final id_bricks_cor_rule_tv:I = 0x7f0a0f77

.field public static final id_bricks_cq_all_btn:I = 0x7f0a0f78

.field public static final id_bricks_cq_questions_flex:I = 0x7f0a0f79

.field public static final id_bricks_csr_rule_flex:I = 0x7f0a0f7a

.field public static final id_bricks_datid_bricks_calendar_week_second:I = 0x7f0a0f7b

.field public static final id_bricks_day_num_first:I = 0x7f0a0f7c

.field public static final id_bricks_day_num_second:I = 0x7f0a0f7d

.field public static final id_bricks_horizontal_head_linear:I = 0x7f0a0f7e

.field public static final id_bricks_horizontal_head_scroll:I = 0x7f0a0f7f

.field public static final id_bricks_horizontal_head_title:I = 0x7f0a0f80

.field public static final id_bricks_horizontal_head_top_title:I = 0x7f0a0f81

.field public static final id_bricks_ip_city_container:I = 0x7f0a0f82

.field public static final id_bricks_ip_city_left_img:I = 0x7f0a0f83

.field public static final id_bricks_ip_city_list:I = 0x7f0a0f84

.field public static final id_bricks_ip_main_recycler:I = 0x7f0a0f85

.field public static final id_bricks_ip_wish_city_name:I = 0x7f0a0f86

.field public static final id_bricks_ip_wish_city_right_arrow:I = 0x7f0a0f87

.field public static final id_bricks_ip_wish_city_status:I = 0x7f0a0f88

.field public static final id_bricks_ip_wish_city_want_status:I = 0x7f0a0f89

.field public static final id_bricks_ip_wish_city_wish_status:I = 0x7f0a0f8a

.field public static final id_bricks_ip_wish_success_lottie:I = 0x7f0a0f8b

.field public static final id_bricks_item_tag_desc_tv:I = 0x7f0a0f8c

.field public static final id_bricks_item_tag_name_tv:I = 0x7f0a0f8d

.field public static final id_bricks_month_num_first:I = 0x7f0a0f8e

.field public static final id_bricks_month_num_second:I = 0x7f0a0f8f

.field public static final id_bricks_more_city_tv:I = 0x7f0a0f90

.field public static final id_bricks_nested_banner_view:I = 0x7f0a0f91

.field public static final id_bricks_one_shop_tag:I = 0x7f0a0f92

.field public static final id_bricks_reservation_artist_img:I = 0x7f0a0f93

.field public static final id_bricks_reservation_artist_layout:I = 0x7f0a0f94

.field public static final id_bricks_reservation_artist_name:I = 0x7f0a0f95

.field public static final id_bricks_reservation_content_layout:I = 0x7f0a0f96

.field public static final id_bricks_reservation_count:I = 0x7f0a0f97

.field public static final id_bricks_reservation_count_postfix:I = 0x7f0a0f98

.field public static final id_bricks_reservation_price_postfix:I = 0x7f0a0f99

.field public static final id_bricks_reservation_project_name:I = 0x7f0a0f9a

.field public static final id_bricks_reservation_project_post_layout:I = 0x7f0a0f9b

.field public static final id_bricks_reservation_project_post_view:I = 0x7f0a0f9c

.field public static final id_bricks_reservation_project_tag:I = 0x7f0a0f9d

.field public static final id_bricks_reservation_rmb_price:I = 0x7f0a0f9e

.field public static final id_bricks_reservation_rmb_tag:I = 0x7f0a0f9f

.field public static final id_bricks_reservation_tag:I = 0x7f0a0fa0

.field public static final id_bricks_reservation_x:I = 0x7f0a0fa3

.field public static final id_bricks_time_day:I = 0x7f0a0fb5

.field public static final id_bricks_time_day_mark:I = 0x7f0a0fb6

.field public static final id_bricks_time_hour:I = 0x7f0a0fb7

.field public static final id_bricks_time_hour_label:I = 0x7f0a0fb8

.field public static final id_bricks_time_layout:I = 0x7f0a0fb9

.field public static final id_bricks_time_min:I = 0x7f0a0fba

.field public static final id_bricks_time_min_label:I = 0x7f0a0fbb

.field public static final id_bricks_time_pre_icon:I = 0x7f0a0fbc

.field public static final id_bricks_time_sec:I = 0x7f0a0fbd

.field public static final id_bricks_time_start_sale:I = 0x7f0a0fbe

.field public static final id_bricks_venue_count_container:I = 0x7f0a0fc1

.field public static final id_bricks_venue_distance_image:I = 0x7f0a0fc2

.field public static final id_bricks_venue_distance_tag:I = 0x7f0a0fc3

.field public static final id_bricks_venue_fans_count:I = 0x7f0a0fc4

.field public static final id_bricks_venue_fans_count_unit:I = 0x7f0a0fc5

.field public static final id_bricks_venue_follow:I = 0x7f0a0fc6

.field public static final id_bricks_venue_gap:I = 0x7f0a0fc7

.field public static final id_bricks_venue_items_count:I = 0x7f0a0fc8

.field public static final id_bricks_venue_items_count_unit:I = 0x7f0a0fc9

.field public static final id_bricks_venue_location:I = 0x7f0a0fca

.field public static final id_bricks_venue_location_container:I = 0x7f0a0fcb

.field public static final id_bricks_venue_location_distance:I = 0x7f0a0fcc

.field public static final id_bricks_venue_name:I = 0x7f0a0fcd

.field public static final id_bricks_venue_name_container:I = 0x7f0a0fce

.field public static final id_bricks_venue_service_container:I = 0x7f0a0fcf

.field public static final id_bricks_venue_vip_tag:I = 0x7f0a0fd0

.field public static final id_bricks_wish_full_container:I = 0x7f0a0fd1

.field public static final id_bricks_wish_head_img:I = 0x7f0a0fd2

.field public static final id_bricks_wish_head_mask:I = 0x7f0a0fd3

.field public static final id_bricks_wish_head_shining:I = 0x7f0a0fd4

.field public static final id_bricks_wish_name_tv:I = 0x7f0a0fd5

.field public static final id_bricks_wish_right_action:I = 0x7f0a0fd6

.field public static final id_bricks_wish_right_tv:I = 0x7f0a0fd7

.field public static final id_bricks_wish_top_right_tag:I = 0x7f0a0fd8

.field public static final id_bricks_wish_top_title:I = 0x7f0a0fd9

.field public static final id_btr_city_icon:I = 0x7f0a0fda

.field public static final id_btr_city_name:I = 0x7f0a0fdb

.field public static final id_common_sheet_dialog_h_ratio_layout:I = 0x7f0a0fdc

.field public static final id_common_sheet_h_ratio_layout:I = 0x7f0a0fdd

.field public static final id_common_sheet_top_empty:I = 0x7f0a0fde

.field public static final id_container_order_detail:I = 0x7f0a0fdf

.field public static final id_day_top_date:I = 0x7f0a0fe0

.field public static final id_day_top_tip:I = 0x7f0a0fe1

.field public static final id_demo_add_1:I = 0x7f0a0fe6

.field public static final id_demo_add_5:I = 0x7f0a0fe7

.field public static final id_demo_content_recycler:I = 0x7f0a0fe8

.field public static final id_demo_remove_1:I = 0x7f0a0fe9

.field public static final id_demo_remove_all:I = 0x7f0a0fea

.field public static final id_demo_sheet_coordinator:I = 0x7f0a0feb

.field public static final id_dialog_taobao_bind_auth_agree:I = 0x7f0a0fec

.field public static final id_dialog_taobao_bind_auth_cancel:I = 0x7f0a0fed

.field public static final id_dialog_taobao_bind_auth_check_tv:I = 0x7f0a0fee

.field public static final id_dialog_taobao_bind_auth_confirm:I = 0x7f0a0fef

.field public static final id_dialog_taobao_bind_auth_layout:I = 0x7f0a0ff0

.field public static final id_dialog_taobao_bind_auth_protocol:I = 0x7f0a0ff1

.field public static final id_dialog_want_btn_subtitle:I = 0x7f0a0ff2

.field public static final id_dialog_want_btn_title:I = 0x7f0a0ff3

.field public static final id_dialog_want_btn_tv:I = 0x7f0a0ff4

.field public static final id_dialog_want_close_btn:I = 0x7f0a0ff5

.field public static final id_dialog_want_lottie:I = 0x7f0a0ff6

.field public static final id_dialog_want_lottie_top:I = 0x7f0a0ff7

.field public static final id_discount_tags_container:I = 0x7f0a0ff8

.field public static final id_film_actor_tv:I = 0x7f0a1008

.field public static final id_film_card_actor_layout:I = 0x7f0a1009

.field public static final id_film_card_high_light_desc:I = 0x7f0a100a

.field public static final id_film_card_high_light_layout:I = 0x7f0a100b

.field public static final id_film_card_poster:I = 0x7f0a100c

.field public static final id_film_card_poster_tag_flex:I = 0x7f0a100d

.field public static final id_film_card_video_pic:I = 0x7f0a100e

.field public static final id_film_card_video_pic_blur:I = 0x7f0a100f

.field public static final id_film_card_video_pic_layout:I = 0x7f0a1010

.field public static final id_film_card_vip_desc:I = 0x7f0a1011

.field public static final id_film_card_vip_icon:I = 0x7f0a1012

.field public static final id_film_card_vip_layout:I = 0x7f0a1013

.field public static final id_film_director_tv:I = 0x7f0a1015

.field public static final id_film_divider_line:I = 0x7f0a1016

.field public static final id_film_poster:I = 0x7f0a1017

.field public static final id_film_project_vip_btn:I = 0x7f0a1018

.field public static final id_film_project_vip_btn_arrow:I = 0x7f0a1019

.field public static final id_film_project_vip_btn_tv:I = 0x7f0a101a

.field public static final id_film_score_count_tv:I = 0x7f0a101b

.field public static final id_film_score_post_tv:I = 0x7f0a101c

.field public static final id_film_score_tv:I = 0x7f0a101d

.field public static final id_film_score_want_count_post_tv:I = 0x7f0a101e

.field public static final id_film_score_want_count_tv:I = 0x7f0a101f

.field public static final id_film_score_want_layout:I = 0x7f0a1020

.field public static final id_film_time_to_show:I = 0x7f0a1021

.field public static final id_film_title_tm:I = 0x7f0a1022

.field public static final id_filter_category_main:I = 0x7f0a1023

.field public static final id_filter_category_sub:I = 0x7f0a1024

.field public static final id_filter_category_sub_tag:I = 0x7f0a1025

.field public static final id_filter_category_tag:I = 0x7f0a1026

.field public static final id_follow_layout:I = 0x7f0a1027

.field public static final id_follow_layout_add_tag:I = 0x7f0a1028

.field public static final id_follow_layout_text:I = 0x7f0a1029

.field public static final id_foot_normal:I = 0x7f0a102a

.field public static final id_foot_rank_define_layout:I = 0x7f0a102b

.field public static final id_h_project_action_tip:I = 0x7f0a102c

.field public static final id_h_project_address:I = 0x7f0a102d

.field public static final id_h_project_block_want_see_tip:I = 0x7f0a102e

.field public static final id_h_project_date:I = 0x7f0a102f

.field public static final id_h_project_line1:I = 0x7f0a1030

.field public static final id_h_project_pending_price:I = 0x7f0a1031

.field public static final id_h_project_poster:I = 0x7f0a1032

.field public static final id_h_project_price:I = 0x7f0a1033

.field public static final id_h_project_price_layout:I = 0x7f0a1034

.field public static final id_h_project_price_prefix:I = 0x7f0a1035

.field public static final id_h_project_promotion_tag:I = 0x7f0a1036

.field public static final id_h_project_rec_ai:I = 0x7f0a1037

.field public static final id_h_project_rec_count_down_day:I = 0x7f0a1038

.field public static final id_h_project_rec_count_down_hour_m_s:I = 0x7f0a1039

.field public static final id_h_project_rec_count_down_layout:I = 0x7f0a103a

.field public static final id_h_project_rec_div:I = 0x7f0a103b

.field public static final id_h_project_rec_layout:I = 0x7f0a103c

.field public static final id_h_project_rec_postfix_tv:I = 0x7f0a103d

.field public static final id_h_project_rec_prefix_tv:I = 0x7f0a103e

.field public static final id_h_project_score:I = 0x7f0a103f

.field public static final id_h_project_score_layout:I = 0x7f0a1040

.field public static final id_h_project_title:I = 0x7f0a1041

.field public static final id_h_project_want_see_rec_layout:I = 0x7f0a1042

.field public static final id_head_atmo_v2_atmo_image:I = 0x7f0a1043

.field public static final id_head_atmo_v2_atmo_lottie:I = 0x7f0a1044

.field public static final id_head_atmo_v2_bg_image_view:I = 0x7f0a1045

.field public static final id_head_atmo_v2_bg_layout:I = 0x7f0a1046

.field public static final id_head_atmo_v2_bottom_view:I = 0x7f0a1047

.field public static final id_head_atmo_v2_click_area_layout:I = 0x7f0a1048

.field public static final id_head_atmo_v2_hw_ratio_view:I = 0x7f0a1049

.field public static final id_head_atmo_v2_top_view:I = 0x7f0a104a

.field public static final id_head_first_img:I = 0x7f0a104b

.field public static final id_head_second_tv:I = 0x7f0a104c

.field public static final id_id_notice_top_view:I = 0x7f0a104e

.field public static final id_ignore_view:I = 0x7f0a104f

.field public static final id_image_tag_right_extend:I = 0x7f0a1050

.field public static final id_img_loader_tag:I = 0x7f0a1051

.field public static final id_item_data:I = 0x7f0a1052

.field public static final id_join_splice_top_title:I = 0x7f0a1053

.field public static final id_lazy_tag:I = 0x7f0a1054

.field public static final id_list_empty_img:I = 0x7f0a1059

.field public static final id_list_empty_text:I = 0x7f0a105a

.field public static final id_list_empty_text_hint:I = 0x7f0a105b

.field public static final id_list_empty_view:I = 0x7f0a105c

.field public static final id_list_recycler:I = 0x7f0a105d

.field public static final id_list_title_layout:I = 0x7f0a105e

.field public static final id_mixed_favorite_btn:I = 0x7f0a1063

.field public static final id_mixed_favorite_btn_pioneer:I = 0x7f0a1064

.field public static final id_mixed_favorite_with_gift:I = 0x7f0a1065

.field public static final id_mixed_favorite_with_gift_pioneer:I = 0x7f0a1066

.field public static final id_mixed_film_card_actor_tv:I = 0x7f0a1067

.field public static final id_mixed_film_card_buy_btn:I = 0x7f0a1068

.field public static final id_mixed_film_card_director_tv:I = 0x7f0a1069

.field public static final id_mixed_film_card_favorite_normal_layout:I = 0x7f0a106a

.field public static final id_mixed_film_card_favorite_pioneer_layout:I = 0x7f0a106b

.field public static final id_mixed_film_card_name:I = 0x7f0a106c

.field public static final id_mixed_film_none_score_tv:I = 0x7f0a106d

.field public static final id_mixed_film_score_count_divider:I = 0x7f0a106e

.field public static final id_mixed_film_score_count_tv:I = 0x7f0a106f

.field public static final id_mixed_film_score_layout:I = 0x7f0a1070

.field public static final id_mixed_film_score_ph_tv:I = 0x7f0a1071

.field public static final id_mixed_film_score_tv:I = 0x7f0a1072

.field public static final id_mixed_film_score_want_layout:I = 0x7f0a1073

.field public static final id_mixed_film_time_2_show_tv:I = 0x7f0a1074

.field public static final id_mixed_film_want_count_divider:I = 0x7f0a1075

.field public static final id_mixed_film_want_count_ph_tv:I = 0x7f0a1076

.field public static final id_mixed_film_want_count_post_tv:I = 0x7f0a1077

.field public static final id_mixed_film_want_count_tv:I = 0x7f0a1078

.field public static final id_mixed_film_want_layout:I = 0x7f0a1079

.field public static final id_mixed_score_count_divider:I = 0x7f0a107a

.field public static final id_module_data:I = 0x7f0a107b

.field public static final id_nine_grid_child_tag:I = 0x7f0a10ac

.field public static final id_note_lb_tag:I = 0x7f0a10af

.field public static final id_notice_close_btn:I = 0x7f0a10b0

.field public static final id_notice_list:I = 0x7f0a10b1

.field public static final id_notice_title:I = 0x7f0a10b2

.field public static final id_pcd_activity_action:I = 0x7f0a10b3

.field public static final id_pcd_activity_action2:I = 0x7f0a10b4

.field public static final id_pcd_activity_close:I = 0x7f0a10b5

.field public static final id_pcd_activity_img:I = 0x7f0a10b6

.field public static final id_pcd_activity_text:I = 0x7f0a10b7

.field public static final id_pcd_activity_user_head:I = 0x7f0a10b8

.field public static final id_pcd_activity_user_name:I = 0x7f0a10b9

.field public static final id_pcd_dialog_body:I = 0x7f0a10ba

.field public static final id_pcd_user_layout:I = 0x7f0a10bb

.field public static final id_price_extend_left_layout:I = 0x7f0a10f4

.field public static final id_project_poster_container:I = 0x7f0a1104

.field public static final id_project_price_layout:I = 0x7f0a1106

.field public static final id_project_status_tv:I = 0x7f0a1107

.field public static final id_project_status_tv_layout:I = 0x7f0a1108

.field public static final id_rank_city_tip:I = 0x7f0a110a

.field public static final id_rank_f_main_btn_tab:I = 0x7f0a110b

.field public static final id_rank_f_sub_btn_lv:I = 0x7f0a110c

.field public static final id_rank_f_tip:I = 0x7f0a110d

.field public static final id_rank_one_sub_left_icon:I = 0x7f0a110e

.field public static final id_rank_one_sub_right_icon:I = 0x7f0a110f

.field public static final id_rank_one_sub_text:I = 0x7f0a1110

.field public static final id_rank_square_container:I = 0x7f0a1111

.field public static final id_rank_square_stl:I = 0x7f0a1112

.field public static final id_right_btn_Layout:I = 0x7f0a1114

.field public static final id_script_shop:I = 0x7f0a1128

.field public static final id_script_shop_address_tv:I = 0x7f0a1129

.field public static final id_script_shop_distance_tv:I = 0x7f0a112a

.field public static final id_script_shop_line:I = 0x7f0a112b

.field public static final id_script_shop_pic:I = 0x7f0a112c

.field public static final id_script_shop_score_tv:I = 0x7f0a112d

.field public static final id_script_shop_score_view:I = 0x7f0a112e

.field public static final id_script_shop_tag:I = 0x7f0a112f

.field public static final id_script_shop_title_tv:I = 0x7f0a1130

.field public static final id_script_shop_tuan_auth_icon:I = 0x7f0a1131

.field public static final id_script_shop_tuan_count_tv:I = 0x7f0a1132

.field public static final id_script_shop_tuan_desc_tv:I = 0x7f0a1133

.field public static final id_script_shop_tuan_layout:I = 0x7f0a1134

.field public static final id_script_shop_tuan_price_tag:I = 0x7f0a1135

.field public static final id_script_shop_tuan_price_tv:I = 0x7f0a1136

.field public static final id_sku_bottom_bar_action_content:I = 0x7f0a1137

.field public static final id_sku_bottom_bar_container:I = 0x7f0a1138

.field public static final id_sku_main_content_layout:I = 0x7f0a1139

.field public static final id_sku_splice_bottom_buy_layout:I = 0x7f0a113a

.field public static final id_sku_splice_bottom_go_buy_layout:I = 0x7f0a113b

.field public static final id_sku_splice_bottom_go_buy_tip:I = 0x7f0a113c

.field public static final id_sku_splice_bottom_go_buy_tv:I = 0x7f0a113d

.field public static final id_sku_splice_bottom_layout:I = 0x7f0a113e

.field public static final id_sku_splice_bottom_left_action_layout:I = 0x7f0a113f

.field public static final id_sku_splice_bottom_left_action_tv:I = 0x7f0a1140

.field public static final id_sku_splice_bottom_left_tip_tv:I = 0x7f0a1141

.field public static final id_sku_splice_bottom_right_action_layout:I = 0x7f0a1142

.field public static final id_sku_splice_bottom_right_action_tv:I = 0x7f0a1143

.field public static final id_sku_splice_bottom_right_tip_tv:I = 0x7f0a1144

.field public static final id_sku_splice_bottom_tip_color_chip:I = 0x7f0a1145

.field public static final id_sku_splice_bottom_tip_layout:I = 0x7f0a1146

.field public static final id_sku_splice_bottom_tip_tv:I = 0x7f0a1147

.field public static final id_sku_splice_buy_now_content_view:I = 0x7f0a1148

.field public static final id_sku_splice_cut_line_price_tv:I = 0x7f0a1149

.field public static final id_sku_splice_join_fast_tip_tv:I = 0x7f0a114a

.field public static final id_sku_splice_join_shortcut_bg_img:I = 0x7f0a114b

.field public static final id_sku_splice_join_shortcut_layout:I = 0x7f0a114c

.field public static final id_sku_splice_join_team_flipper:I = 0x7f0a114d

.field public static final id_sku_splice_join_ticket_count:I = 0x7f0a114e

.field public static final id_sku_splice_join_ticket_count_pre:I = 0x7f0a114f

.field public static final id_sku_splice_join_ticket_count_suffix:I = 0x7f0a1150

.field public static final id_sku_splice_join_top_hot_area:I = 0x7f0a1151

.field public static final id_sku_splice_need_join_count_block:I = 0x7f0a1152

.field public static final id_sku_splice_open_join_list:I = 0x7f0a1153

.field public static final id_sku_splice_pop_close:I = 0x7f0a1154

.field public static final id_sku_splice_pop_layer_close:I = 0x7f0a1155

.field public static final id_sku_splice_pop_teams_recyclerview:I = 0x7f0a1156

.field public static final id_sku_splice_pop_title:I = 0x7f0a1157

.field public static final id_sku_splice_pop_top_flipper_view:I = 0x7f0a1158

.field public static final id_sku_splice_pop_top_layout:I = 0x7f0a1159

.field public static final id_sku_splice_pop_top_star_img:I = 0x7f0a115a

.field public static final id_sku_splice_price_tv:I = 0x7f0a115b

.field public static final id_sku_splice_team_action_btn:I = 0x7f0a115c

.field public static final id_sku_splice_team_head_v:I = 0x7f0a115d

.field public static final id_sku_splice_team_timer_down:I = 0x7f0a115e

.field public static final id_sku_start_splice_content_view:I = 0x7f0a115f

.field public static final id_sku_start_splice_state_view:I = 0x7f0a1160

.field public static final id_sm_score_ext_ui:I = 0x7f0a1171

.field public static final id_sm_shop_addr:I = 0x7f0a1172

.field public static final id_sm_shop_auth:I = 0x7f0a1173

.field public static final id_sm_shop_call_ui:I = 0x7f0a1174

.field public static final id_sm_shop_entrance_arrow:I = 0x7f0a1175

.field public static final id_sm_shop_ext_info:I = 0x7f0a1176

.field public static final id_sm_shop_ext_status:I = 0x7f0a1177

.field public static final id_sm_shop_info_entrance:I = 0x7f0a1178

.field public static final id_sm_shop_loc_distance:I = 0x7f0a1179

.field public static final id_sm_shop_loc_ui:I = 0x7f0a117a

.field public static final id_sm_shop_name:I = 0x7f0a117b

.field public static final id_sm_shop_open_evaluate_btn:I = 0x7f0a117c

.field public static final id_sm_shop_price_and_count:I = 0x7f0a117d

.field public static final id_sm_shop_score_star_ui:I = 0x7f0a117e

.field public static final id_sm_shop_score_tv:I = 0x7f0a117f

.field public static final id_sm_shop_star_view:I = 0x7f0a1180

.field public static final id_sm_shop_tag_flex2:I = 0x7f0a1181

.field public static final id_sm_venue_fans_show_count:I = 0x7f0a1182

.field public static final id_sm_venue_loc_address:I = 0x7f0a1183

.field public static final id_sm_venue_loc_distance:I = 0x7f0a1184

.field public static final id_sm_venue_loc_ui:I = 0x7f0a1185

.field public static final id_sm_venue_name:I = 0x7f0a1186

.field public static final id_splice_bottom_bar_layout:I = 0x7f0a118a

.field public static final id_splice_bottom_buy_container:I = 0x7f0a118b

.field public static final id_splice_bottom_pop_layer_style_container:I = 0x7f0a118c

.field public static final id_splice_bottom_price_tv:I = 0x7f0a118d

.field public static final id_splice_bottom_price_tv_pioneer:I = 0x7f0a118e

.field public static final id_splice_fragment_container:I = 0x7f0a118f

.field public static final id_splice_layout_price_detail:I = 0x7f0a1190

.field public static final id_splice_new_enable_join_open_state_layout:I = 0x7f0a1191

.field public static final id_splice_new_enable_join_tip_tv:I = 0x7f0a1192

.field public static final id_splice_new_enable_join_title:I = 0x7f0a1193

.field public static final id_splice_new_enable_join_tv:I = 0x7f0a1194

.field public static final id_splice_price_cut_line:I = 0x7f0a1195

.field public static final id_splice_price_detail_arrow:I = 0x7f0a1196

.field public static final id_splice_price_detail_promotion_tip:I = 0x7f0a1197

.field public static final id_splice_price_discount_tag:I = 0x7f0a1198

.field public static final id_splice_price_left_layout:I = 0x7f0a1199

.field public static final id_splice_price_prefix:I = 0x7f0a119a

.field public static final id_splice_price_prefix_pioneer:I = 0x7f0a119b

.field public static final id_splice_price_sell_out_tv:I = 0x7f0a119c

.field public static final id_splice_price_ticket_count:I = 0x7f0a119d

.field public static final id_splice_price_tv:I = 0x7f0a119e

.field public static final id_splice_ticket_limit_tip:I = 0x7f0a119f

.field public static final id_splice_ticket_limit_title:I = 0x7f0a11a0

.field public static final id_splice_ticket_select_num_jia:I = 0x7f0a11a1

.field public static final id_splice_ticket_select_num_jian:I = 0x7f0a11a2

.field public static final id_splice_ticket_select_num_layout:I = 0x7f0a11a3

.field public static final id_splice_ticket_select_num_tv:I = 0x7f0a11a4

.field public static final id_start_splice_price_flex:I = 0x7f0a11a5

.field public static final id_start_splice_top_title:I = 0x7f0a11a6

.field public static final id_stl:I = 0x7f0a11a7

.field public static final id_tetris_project_filter_container:I = 0x7f0a11ac

.field public static final id_tetris_rank_change_city:I = 0x7f0a11ad

.field public static final id_tetris_rank_empty_layout:I = 0x7f0a11ae

.field public static final id_tetris_rank_layout:I = 0x7f0a11af

.field public static final id_tetris_rank_top_round_bg:I = 0x7f0a11b0

.field public static final id_this_is_one_guide_point:I = 0x7f0a11b1

.field public static final id_time_line_layout:I = 0x7f0a11b3

.field public static final id_tv_project_rank:I = 0x7f0a11cd

.field public static final id_tv_project_rank_mark:I = 0x7f0a11ce

.field public static final id_tv_project_score_postfix:I = 0x7f0a11cf

.field public static final id_tv_project_score_tv:I = 0x7f0a11d0

.field public static final id_tv_project_want_postfix:I = 0x7f0a11d1

.field public static final id_tv_project_want_tv:I = 0x7f0a11d2

.field public static final id_tv_reasondiv:I = 0x7f0a11d3

.field public static final id_tv_reasonicon:I = 0x7f0a11d4

.field public static final id_tv_reasonstr:I = 0x7f0a11d5

.field public static final id_user_extra_tabs:I = 0x7f0a11d7

.field public static final id_user_extra_title_bar:I = 0x7f0a11d8

.field public static final id_user_extra_view_pager:I = 0x7f0a11d9

.field public static final id_user_publish_btn:I = 0x7f0a11db

.field public static final id_user_publish_name:I = 0x7f0a11dc

.field public static final id_video_decor:I = 0x7f0a11de

.field public static final idcard_clear_btn:I = 0x7f0a11df

.field public static final ifRoom:I = 0x7f0a11e3

.field public static final if_already_choose:I = 0x7f0a11e4

.field public static final if_already_choose2:I = 0x7f0a11e5

.field public static final if_notice:I = 0x7f0a11e6

.field public static final ift_home_remind_machine_tip:I = 0x7f0a11e7

.field public static final ift_home_remind_ticket_tip:I = 0x7f0a11e8

.field public static final ift_union_check:I = 0x7f0a11e9

.field public static final ignore:I = 0x7f0a11eb

.field public static final ignoreRequest:I = 0x7f0a11ec

.field public static final im_calender_place_holder:I = 0x7f0a11ee

.field public static final im_calender_sub_title:I = 0x7f0a11ef

.field public static final im_group_avatar_bottom_container:I = 0x7f0a11f0

.field public static final image:I = 0x7f0a11f1

.field public static final imageView:I = 0x7f0a11f2

.field public static final imageView2:I = 0x7f0a11f3

.field public static final imageView3:I = 0x7f0a11f4

.field public static final image_back:I = 0x7f0a11fa

.field public static final image_banner:I = 0x7f0a11fb

.field public static final image_bg:I = 0x7f0a11fc

.field public static final image_browse_back_tv:I = 0x7f0a11fd

.field public static final image_browse_position_tv:I = 0x7f0a11fe

.field public static final image_browse_title_tv:I = 0x7f0a11ff

.field public static final image_browse_viewer:I = 0x7f0a1200

.field public static final image_button:I = 0x7f0a1201

.field public static final image_buy_user:I = 0x7f0a1202

.field public static final image_choice:I = 0x7f0a1203

.field public static final image_container:I = 0x7f0a1204

.field public static final image_content_item_poster:I = 0x7f0a1205

.field public static final image_count:I = 0x7f0a1206

.field public static final image_count_label_icon:I = 0x7f0a1207

.field public static final image_count_lay:I = 0x7f0a1208

.field public static final image_download_tv:I = 0x7f0a1209

.field public static final image_gallery_list:I = 0x7f0a120b

.field public static final image_gotop:I = 0x7f0a120c

.field public static final image_icon_arrow:I = 0x7f0a1211

.field public static final image_indicator:I = 0x7f0a1212

.field public static final image_intro_tv:I = 0x7f0a1213

.field public static final image_item:I = 0x7f0a1214

.field public static final image_item2:I = 0x7f0a1216

.field public static final image_item2_v2:I = 0x7f0a1217

.field public static final image_item3:I = 0x7f0a1218

.field public static final image_item3_v2:I = 0x7f0a1219

.field public static final image_item_bg:I = 0x7f0a121a

.field public static final image_lay:I = 0x7f0a121e

.field public static final image_layout_juebuchongfu:I = 0x7f0a121f

.field public static final image_line:I = 0x7f0a1220

.field public static final image_logo:I = 0x7f0a1221

.field public static final image_project:I = 0x7f0a1226

.field public static final image_quan:I = 0x7f0a1227

.field public static final image_share:I = 0x7f0a1228

.field public static final image_tag:I = 0x7f0a122a

.field public static final image_tag_view:I = 0x7f0a122b

.field public static final image_top:I = 0x7f0a122c

.field public static final image_view:I = 0x7f0a122e

.field public static final image_xin:I = 0x7f0a122f

.field public static final imageview:I = 0x7f0a1233

.field public static final img:I = 0x7f0a1234

.field public static final img_arrow:I = 0x7f0a1235

.field public static final img_bg:I = 0x7f0a1236

.field public static final img_bg_atmosphere:I = 0x7f0a1237

.field public static final img_black_diamond:I = 0x7f0a1238

.field public static final img_btn_invite:I = 0x7f0a1239

.field public static final img_coin:I = 0x7f0a123a

.field public static final img_cover:I = 0x7f0a123c

.field public static final img_guide_bubble:I = 0x7f0a123f

.field public static final img_header_bg:I = 0x7f0a1240

.field public static final img_header_bg_gradient:I = 0x7f0a1241

.field public static final img_icon:I = 0x7f0a1243

.field public static final img_icon2:I = 0x7f0a1244

.field public static final img_iv:I = 0x7f0a1246

.field public static final img_jia:I = 0x7f0a1247

.field public static final img_jian:I = 0x7f0a1248

.field public static final img_loading:I = 0x7f0a1249

.field public static final img_photo:I = 0x7f0a124b

.field public static final img_pioneer_project_layout:I = 0x7f0a124c

.field public static final img_post:I = 0x7f0a124d

.field public static final img_project:I = 0x7f0a124e

.field public static final img_project_layout:I = 0x7f0a124f

.field public static final img_project_right_icon:I = 0x7f0a1250

.field public static final img_project_tip:I = 0x7f0a1251

.field public static final img_refund_notice:I = 0x7f0a1252

.field public static final img_sale_status:I = 0x7f0a1253

.field public static final img_share_bg:I = 0x7f0a1254

.field public static final img_share_title:I = 0x7f0a1255

.field public static final img_ticket_remind_ballon:I = 0x7f0a1256

.field public static final img_title:I = 0x7f0a1257

.field public static final img_user_level:I = 0x7f0a1259

.field public static final img_video:I = 0x7f0a125a

.field public static final img_vip:I = 0x7f0a125b

.field public static final img_vip_rule:I = 0x7f0a125c

.field public static final img_want_light:I = 0x7f0a125d

.field public static final img_want_title:I = 0x7f0a125e

.field public static final immediateStop:I = 0x7f0a125f

.field public static final included:I = 0x7f0a1260

.field public static final indicator:I = 0x7f0a1261

.field public static final indicatorContainer:I = 0x7f0a1262

.field public static final indicatorInside:I = 0x7f0a1263

.field public static final indicator_brand_venue_triangle:I = 0x7f0a1265

.field public static final indicator_container:I = 0x7f0a1266

.field public static final indicator_img:I = 0x7f0a1267

.field public static final indicator_img2:I = 0x7f0a1268

.field public static final indicator_layout:I = 0x7f0a1269

.field public static final indicator_scrollview:I = 0x7f0a126a

.field public static final indicator_txt:I = 0x7f0a126b

.field public static final indicator_txt_prefix:I = 0x7f0a126c

.field public static final info:I = 0x7f0a126d

.field public static final inline:I = 0x7f0a1270

.field public static final innear_bg_ll:I = 0x7f0a1271

.field public static final innear_bg_parent:I = 0x7f0a1272

.field public static final inner_icon:I = 0x7f0a1273

.field public static final inner_project_gap:I = 0x7f0a1274

.field public static final inner_project_layout:I = 0x7f0a1275

.field public static final inner_project_wrapper:I = 0x7f0a1276

.field public static final inner_text:I = 0x7f0a1277

.field public static final inputContent:I = 0x7f0a1278

.field public static final inside:I = 0x7f0a1279

.field public static final inspection_slot_table_set:I = 0x7f0a127b

.field public static final integral_zone:I = 0x7f0a1286

.field public static final introduce_txt:I = 0x7f0a1288

.field public static final invisible:I = 0x7f0a1289

.field public static final inward:I = 0x7f0a1296

.field public static final ip_actoralbum_list:I = 0x7f0a1297

.field public static final ip_album_item_pic:I = 0x7f0a1298

.field public static final ip_album_item_pic_cover:I = 0x7f0a1299

.field public static final ip_bottombar_buy:I = 0x7f0a129a

.field public static final ip_bottombar_text:I = 0x7f0a129b

.field public static final ip_bottombar_tip_bg:I = 0x7f0a129c

.field public static final ip_bottombar_tip_textbelow:I = 0x7f0a129d

.field public static final ip_bottombar_tip_texttop:I = 0x7f0a129e

.field public static final ip_brand_artist:I = 0x7f0a129f

.field public static final ip_brand_artist_avatar:I = 0x7f0a12a0

.field public static final ip_brand_artist_fancount:I = 0x7f0a12a1

.field public static final ip_brand_artist_layout:I = 0x7f0a12a2

.field public static final ip_brand_artist_name:I = 0x7f0a12a3

.field public static final ip_brand_card_desc:I = 0x7f0a12a4

.field public static final ip_brand_card_dynnews:I = 0x7f0a12a5

.field public static final ip_brand_card_dynnews_card:I = 0x7f0a12a6

.field public static final ip_brand_card_dynnews_flipper:I = 0x7f0a12a7

.field public static final ip_brand_card_dynnews_flipper_item:I = 0x7f0a12a8

.field public static final ip_brand_card_dynnews_flipper_itemtv:I = 0x7f0a12a9

.field public static final ip_brand_card_img:I = 0x7f0a12aa

.field public static final ip_brand_card_item1:I = 0x7f0a12ab

.field public static final ip_brand_card_item2:I = 0x7f0a12ac

.field public static final ip_brand_card_line1:I = 0x7f0a12ad

.field public static final ip_brand_card_line2:I = 0x7f0a12ae

.field public static final ip_brand_card_line3:I = 0x7f0a12af

.field public static final ip_brand_card_name:I = 0x7f0a12b0

.field public static final ip_brand_card_name_v:I = 0x7f0a12b1

.field public static final ip_brand_center_layout:I = 0x7f0a12b2

.field public static final ip_brand_container:I = 0x7f0a12b3

.field public static final ip_brand_fans_and_show:I = 0x7f0a12b4

.field public static final ip_brand_icon:I = 0x7f0a12b5

.field public static final ip_brand_left_layout:I = 0x7f0a12b6

.field public static final ip_brand_name:I = 0x7f0a12b7

.field public static final ip_brand_quickreport:I = 0x7f0a12b8

.field public static final ip_brand_quickreport_img:I = 0x7f0a12b9

.field public static final ip_brand_quickreport_title:I = 0x7f0a12ba

.field public static final ip_brand_right_layout_page:I = 0x7f0a12bb

.field public static final ip_brand_right_layout_score:I = 0x7f0a12bc

.field public static final ip_brand_root:I = 0x7f0a12bd

.field public static final ip_brand_score:I = 0x7f0a12be

.field public static final ip_brand_score_star_view:I = 0x7f0a12bf

.field public static final ip_brand_score_tv:I = 0x7f0a12c0

.field public static final ip_brand_title:I = 0x7f0a12c1

.field public static final ip_brand_top_layout:I = 0x7f0a12c2

.field public static final ip_brand_video_time:I = 0x7f0a12c3

.field public static final ip_btn:I = 0x7f0a12c4

.field public static final ip_container_ll:I = 0x7f0a12c5

.field public static final ip_future_city_rl:I = 0x7f0a12c7

.field public static final ip_item_tag:I = 0x7f0a12c8

.field public static final ip_item_tag_img:I = 0x7f0a12c9

.field public static final ip_item_tag_tv:I = 0x7f0a12ca

.field public static final ip_music_avatar_avatar:I = 0x7f0a12cb

.field public static final ip_music_avatar_avatar_pioneer:I = 0x7f0a12cc

.field public static final ip_music_brand_avatar_layout:I = 0x7f0a12cd

.field public static final ip_music_brand_avatar_layout_child:I = 0x7f0a12ce

.field public static final ip_poster:I = 0x7f0a12cf

.field public static final ip_tags_bottombar:I = 0x7f0a12d0

.field public static final ip_tags_buy:I = 0x7f0a12d1

.field public static final ip_tags_scroll:I = 0x7f0a12d2

.field public static final ip_tags_scroll_content:I = 0x7f0a12d3

.field public static final ip_tags_tag_bg:I = 0x7f0a12d4

.field public static final ip_tags_tag_count:I = 0x7f0a12d5

.field public static final ip_tags_tag_title:I = 0x7f0a12d6

.field public static final ip_tags_tag_zan:I = 0x7f0a12d7

.field public static final ip_tags_top:I = 0x7f0a12d8

.field public static final ip_tags_top_close:I = 0x7f0a12d9

.field public static final ip_tags_top_title:I = 0x7f0a12da

.field public static final ip_tour_item_btn:I = 0x7f0a12db

.field public static final ip_tour_item_buy:I = 0x7f0a12dc

.field public static final ip_tour_item_buy_area:I = 0x7f0a12dd

.field public static final ip_tour_item_buy_desc:I = 0x7f0a12de

.field public static final ip_tour_item_buy_midtext:I = 0x7f0a12df

.field public static final ip_tour_item_city:I = 0x7f0a12e0

.field public static final ip_tour_item_city_nearest:I = 0x7f0a12e1

.field public static final ip_tour_item_date:I = 0x7f0a12e2

.field public static final ip_tour_item_divline_bottom:I = 0x7f0a12e3

.field public static final ip_tour_item_divline_dot:I = 0x7f0a12e4

.field public static final ip_tour_item_divline_top:I = 0x7f0a12e5

.field public static final ip_tour_item_month:I = 0x7f0a12e6

.field public static final ip_tour_item_place:I = 0x7f0a12e7

.field public static final ip_tour_item_time:I = 0x7f0a12e8

.field public static final ip_tour_scroll:I = 0x7f0a12e9

.field public static final ip_tour_scroll_content:I = 0x7f0a12ea

.field public static final ip_tour_top:I = 0x7f0a12eb

.field public static final ip_tour_top_close:I = 0x7f0a12ec

.field public static final ip_tour_top_title:I = 0x7f0a12ed

.field public static final ip_tv_subtitle:I = 0x7f0a12ee

.field public static final ip_tv_title:I = 0x7f0a12ef

.field public static final ip_video_album_desc:I = 0x7f0a12f0

.field public static final ip_video_album_item_comment:I = 0x7f0a12f1

.field public static final ip_video_album_item_header:I = 0x7f0a12f2

.field public static final ip_video_album_item_name:I = 0x7f0a12f3

.field public static final ip_video_album_play:I = 0x7f0a12f4

.field public static final ip_video_album_usericon:I = 0x7f0a12f5

.field public static final ip_video_pic_tip:I = 0x7f0a12f6

.field public static final ip_video_pic_tiptv:I = 0x7f0a12f7

.field public static final ip_videoalbum_list:I = 0x7f0a12f8

.field public static final ip_videoalbum_title:I = 0x7f0a12f9

.field public static final ipinfo_content:I = 0x7f0a12fc

.field public static final ipinfo_descinfo:I = 0x7f0a12fd

.field public static final ipinfo_ranklist:I = 0x7f0a12fe

.field public static final ipinfo_ranklist_divline:I = 0x7f0a12ff

.field public static final ipinfo_score:I = 0x7f0a1300

.field public static final ipinfo_score_arrow:I = 0x7f0a1301

.field public static final ipinfo_score_desc:I = 0x7f0a1302

.field public static final ipinfo_score_divline:I = 0x7f0a1303

.field public static final ipinfo_score_rank:I = 0x7f0a1304

.field public static final ipinfo_score_ratingbar:I = 0x7f0a1305

.field public static final ipinfo_score_title_icon:I = 0x7f0a1306

.field public static final ipinfo_score_titleimg:I = 0x7f0a1307

.field public static final ipinfo_score_userimg:I = 0x7f0a1308

.field public static final ipinfo_score_usertext:I = 0x7f0a1309

.field public static final ipinfo_score_value:I = 0x7f0a130a

.field public static final ipinfo_score_value_root:I = 0x7f0a130b

.field public static final ipinfo_showinfo:I = 0x7f0a130c

.field public static final ipinfo_showinfo_add_city:I = 0x7f0a130d

.field public static final ipinfo_showinfo_add_city_icon:I = 0x7f0a130e

.field public static final ipinfo_showinfo_add_city_text:I = 0x7f0a130f

.field public static final ipinfo_showinfo_favnum:I = 0x7f0a1310

.field public static final ipinfo_showinfo_img:I = 0x7f0a1311

.field public static final ipinfo_showinfo_left:I = 0x7f0a1312

.field public static final ipinfo_showinfo_title:I = 0x7f0a1313

.field public static final ipinfo_showinfo_type:I = 0x7f0a1314

.field public static final ipinfo_showinfo_wannasee:I = 0x7f0a1315

.field public static final ipinfo_showinfo_wannasee_icon:I = 0x7f0a1316

.field public static final ipinfo_showinfo_wannasee_text:I = 0x7f0a1317

.field public static final irc:I = 0x7f0a1319

.field public static final it_block_card_select_arrow:I = 0x7f0a1342

.field public static final italic:I = 0x7f0a1343

.field public static final item:I = 0x7f0a1344

.field public static final item1:I = 0x7f0a1345

.field public static final item2:I = 0x7f0a1346

.field public static final item3:I = 0x7f0a1347

.field public static final item4:I = 0x7f0a1348

.field public static final item_1_layout:I = 0x7f0a1349

.field public static final item_2_layout:I = 0x7f0a134a

.field public static final item_3_layout:I = 0x7f0a134b

.field public static final item_4_layout:I = 0x7f0a134c

.field public static final item_5_layout:I = 0x7f0a134d

.field public static final item_6_layout:I = 0x7f0a134e

.field public static final item_bottom_line:I = 0x7f0a134f

.field public static final item_category_ball_icon_container:I = 0x7f0a1352

.field public static final item_category_ball_icon_half_container:I = 0x7f0a1353

.field public static final item_category_ball_icon_multiple_container:I = 0x7f0a1354

.field public static final item_category_ball_icon_quarter_container:I = 0x7f0a1355

.field public static final item_category_ball_icon_third_container:I = 0x7f0a1356

.field public static final item_category_one_name:I = 0x7f0a1357

.field public static final item_category_one_tag:I = 0x7f0a1358

.field public static final item_city_music_p_time:I = 0x7f0a1359

.field public static final item_container:I = 0x7f0a135a

.field public static final item_count_tip_layout:I = 0x7f0a135c

.field public static final item_desc:I = 0x7f0a135d

.field public static final item_desc_icon:I = 0x7f0a135e

.field public static final item_discover_big_note_head_1:I = 0x7f0a135f

.field public static final item_discover_big_note_head_2:I = 0x7f0a1360

.field public static final item_empty_btn:I = 0x7f0a1361

.field public static final item_empty_hint:I = 0x7f0a1362

.field public static final item_expand_desc:I = 0x7f0a1364

.field public static final item_feed_title:I = 0x7f0a1365

.field public static final item_feed_vote_top_img:I = 0x7f0a1366

.field public static final item_feed_vote_ui:I = 0x7f0a1367

.field public static final item_filter_confirm:I = 0x7f0a1368

.field public static final item_filter_container:I = 0x7f0a1369

.field public static final item_filter_flex:I = 0x7f0a136a

.field public static final item_filter_flex_title:I = 0x7f0a136b

.field public static final item_filter_one_item_id:I = 0x7f0a136c

.field public static final item_filter_reset:I = 0x7f0a136d

.field public static final item_filter_text:I = 0x7f0a136e

.field public static final item_flowlayout:I = 0x7f0a1370

.field public static final item_grab_empty_click:I = 0x7f0a1372

.field public static final item_grab_hot_image:I = 0x7f0a1373

.field public static final item_grab_hot_image_artist:I = 0x7f0a1374

.field public static final item_grab_hot_image_artistpic:I = 0x7f0a1375

.field public static final item_grab_hot_image_artistpic_shell:I = 0x7f0a1376

.field public static final item_grab_hot_image_fl:I = 0x7f0a1377

.field public static final item_grab_hot_image_name:I = 0x7f0a1378

.field public static final item_grab_main_info:I = 0x7f0a1379

.field public static final item_grab_name:I = 0x7f0a137a

.field public static final item_grab_time:I = 0x7f0a137c

.field public static final item_grab_time_rl:I = 0x7f0a137d

.field public static final item_header_coupon_got:I = 0x7f0a137e

.field public static final item_header_coupon_want:I = 0x7f0a137f

.field public static final item_header_coupon_wantparent:I = 0x7f0a1380

.field public static final item_icon_arrow:I = 0x7f0a1381

.field public static final item_label:I = 0x7f0a1383

.field public static final item_name:I = 0x7f0a138a

.field public static final item_nine_one_img:I = 0x7f0a138b

.field public static final item_nine_one_pic_num:I = 0x7f0a138c

.field public static final item_nine_one_play_top_right:I = 0x7f0a138d

.field public static final item_nine_one_video_status:I = 0x7f0a138e

.field public static final item_nine_video_time:I = 0x7f0a138f

.field public static final item_now_tv:I = 0x7f0a1390

.field public static final item_parent:I = 0x7f0a1391

.field public static final item_poster:I = 0x7f0a1393

.field public static final item_price:I = 0x7f0a1394

.field public static final item_price_above:I = 0x7f0a1395

.field public static final item_price_desc:I = 0x7f0a1396

.field public static final item_price_flag:I = 0x7f0a1397

.field public static final item_price_layout:I = 0x7f0a1398

.field public static final item_price_tv:I = 0x7f0a1399

.field public static final item_promotion_content:I = 0x7f0a139e

.field public static final item_promotion_excel_title:I = 0x7f0a13a1

.field public static final item_promotion_tag:I = 0x7f0a13a4

.field public static final item_promotion_title:I = 0x7f0a13a5

.field public static final item_promotion_tv:I = 0x7f0a13a6

.field public static final item_seat_promotion_tag:I = 0x7f0a13b1

.field public static final item_single_vote_count:I = 0x7f0a13b8

.field public static final item_single_vote_progress:I = 0x7f0a13b9

.field public static final item_single_vote_text:I = 0x7f0a13ba

.field public static final item_text:I = 0x7f0a13bb

.field public static final item_title:I = 0x7f0a13bc

.field public static final item_title_tip:I = 0x7f0a13bf

.field public static final item_total_tv:I = 0x7f0a13c1

.field public static final item_touch_helper_previous_elevation:I = 0x7f0a13c2

.field public static final item_user_center_empty_iv:I = 0x7f0a13c3

.field public static final item_user_center_empty_title_tv:I = 0x7f0a13c4

.field public static final item_user_center_empty_tv:I = 0x7f0a13c5

.field public static final item_user_center_empty_view:I = 0x7f0a13c6

.field public static final item_vote_fr_layout:I = 0x7f0a13c9

.field public static final item_vote_layout_id:I = 0x7f0a13ca

.field public static final item_vote_tag:I = 0x7f0a13cb

.field public static final item_vote_tag_img:I = 0x7f0a13cc

.field public static final iv:I = 0x7f0a13cd

.field public static final ivLogoView:I = 0x7f0a13cf

.field public static final ivSearchTag:I = 0x7f0a13d1

.field public static final ivSeatGuide:I = 0x7f0a13d2

.field public static final iv_account_image:I = 0x7f0a13d7

.field public static final iv_action_des_icon:I = 0x7f0a13d8

.field public static final iv_action_icon:I = 0x7f0a13d9

.field public static final iv_arrow_down:I = 0x7f0a13da

.field public static final iv_arrow_up:I = 0x7f0a13db

.field public static final iv_auth_third_authorized:I = 0x7f0a13e3

.field public static final iv_auth_third_authorizer:I = 0x7f0a13e4

.field public static final iv_back:I = 0x7f0a13e5

.field public static final iv_background:I = 0x7f0a13e6

.field public static final iv_big_vip:I = 0x7f0a13e9

.field public static final iv_bottom_icon:I = 0x7f0a13ea

.field public static final iv_brand_tagimg:I = 0x7f0a13ef

.field public static final iv_card_tag:I = 0x7f0a13f3

.field public static final iv_card_tag_barrier:I = 0x7f0a13f4

.field public static final iv_card_union_icon:I = 0x7f0a13f5

.field public static final iv_channel_brand_venue_shining:I = 0x7f0a13f6

.field public static final iv_channel_brand_venue_tab:I = 0x7f0a13f7

.field public static final iv_child_1:I = 0x7f0a13f8

.field public static final iv_child_2:I = 0x7f0a13f9

.field public static final iv_child_3:I = 0x7f0a13fa

.field public static final iv_child_4:I = 0x7f0a13fb

.field public static final iv_choose_seat:I = 0x7f0a13fc

.field public static final iv_circle_action_icon:I = 0x7f0a13fd

.field public static final iv_circle_head:I = 0x7f0a13ff

.field public static final iv_circle_pic:I = 0x7f0a1401

.field public static final iv_close:I = 0x7f0a1403

.field public static final iv_close_btn:I = 0x7f0a1404

.field public static final iv_comment_action:I = 0x7f0a1405

.field public static final iv_comment_icon:I = 0x7f0a1406

.field public static final iv_comment_luxury:I = 0x7f0a1407

.field public static final iv_comment_title:I = 0x7f0a1408

.field public static final iv_comment_title2:I = 0x7f0a1409

.field public static final iv_comment_title_left_icon:I = 0x7f0a140a

.field public static final iv_comment_title_right_icon:I = 0x7f0a140b

.field public static final iv_comment_top:I = 0x7f0a140c

.field public static final iv_convert_status:I = 0x7f0a140d

.field public static final iv_coupon_luck_bg:I = 0x7f0a140e

.field public static final iv_coupon_tip_tag:I = 0x7f0a1410

.field public static final iv_cover:I = 0x7f0a1411

.field public static final iv_delete:I = 0x7f0a1412

.field public static final iv_discount:I = 0x7f0a1414

.field public static final iv_divider:I = 0x7f0a1415

.field public static final iv_dna_pic:I = 0x7f0a1417

.field public static final iv_easter_egg:I = 0x7f0a1418

.field public static final iv_error_tip:I = 0x7f0a141c

.field public static final iv_exchange_reminder_icon:I = 0x7f0a141e

.field public static final iv_icon:I = 0x7f0a1424

.field public static final iv_icon_coupon_package:I = 0x7f0a1425

.field public static final iv_identify:I = 0x7f0a1426

.field public static final iv_image:I = 0x7f0a1427

.field public static final iv_img:I = 0x7f0a1429

.field public static final iv_jiantou:I = 0x7f0a1432

.field public static final iv_left:I = 0x7f0a1435

.field public static final iv_line:I = 0x7f0a1437

.field public static final iv_lock:I = 0x7f0a1439

.field public static final iv_logo:I = 0x7f0a143a

.field public static final iv_lottery_close_btn:I = 0x7f0a143b

.field public static final iv_lottie_coupon_package:I = 0x7f0a143c

.field public static final iv_luck_film_poster:I = 0x7f0a143d

.field public static final iv_magic_comment_cover:I = 0x7f0a143e

.field public static final iv_masking:I = 0x7f0a1441

.field public static final iv_media_vod:I = 0x7f0a1442

.field public static final iv_member_bg:I = 0x7f0a1443

.field public static final iv_member_bg_gif:I = 0x7f0a1444

.field public static final iv_member_container:I = 0x7f0a1445

.field public static final iv_mine_evaluated_badge:I = 0x7f0a144e

.field public static final iv_more_images:I = 0x7f0a1457

.field public static final iv_movie_image:I = 0x7f0a1458

.field public static final iv_movie_image_first:I = 0x7f0a1459

.field public static final iv_movie_image_first_fl:I = 0x7f0a145a

.field public static final iv_movie_image_second:I = 0x7f0a145b

.field public static final iv_movie_image_second_fl:I = 0x7f0a145c

.field public static final iv_movie_image_third:I = 0x7f0a145d

.field public static final iv_movie_image_third_fl:I = 0x7f0a145e

.field public static final iv_movie_trailer_list:I = 0x7f0a145f

.field public static final iv_nft_back_rim:I = 0x7f0a1461

.field public static final iv_no_sale_tip:I = 0x7f0a1464

.field public static final iv_pay_icon:I = 0x7f0a146f

.field public static final iv_pic:I = 0x7f0a1473

.field public static final iv_pioneer_icon:I = 0x7f0a1474

.field public static final iv_poster:I = 0x7f0a1475

.field public static final iv_price:I = 0x7f0a147a

.field public static final iv_profile_header:I = 0x7f0a147b

.field public static final iv_project_bg:I = 0x7f0a147d

.field public static final iv_project_image:I = 0x7f0a147e

.field public static final iv_project_img:I = 0x7f0a1481

.field public static final iv_project_status:I = 0x7f0a1485

.field public static final iv_qrcode_img:I = 0x7f0a1487

.field public static final iv_recommend_1:I = 0x7f0a1489

.field public static final iv_recommend_1_container:I = 0x7f0a148a

.field public static final iv_recommend_2:I = 0x7f0a148b

.field public static final iv_recommend_2_container:I = 0x7f0a148c

.field public static final iv_recommend_3:I = 0x7f0a148d

.field public static final iv_recommend_3_container:I = 0x7f0a148e

.field public static final iv_recommend_4:I = 0x7f0a148f

.field public static final iv_recommend_4_container:I = 0x7f0a1490

.field public static final iv_reward:I = 0x7f0a1493

.field public static final iv_ribbons:I = 0x7f0a1494

.field public static final iv_right:I = 0x7f0a1495

.field public static final iv_schedule_lucky_tag:I = 0x7f0a1498

.field public static final iv_schedule_tag_icon:I = 0x7f0a1499

.field public static final iv_select:I = 0x7f0a149c

.field public static final iv_selected:I = 0x7f0a149d

.field public static final iv_selected_2:I = 0x7f0a149e

.field public static final iv_selection:I = 0x7f0a149f

.field public static final iv_spring_dialog_content:I = 0x7f0a14a9

.field public static final iv_spring_dialog_content_error:I = 0x7f0a14aa

.field public static final iv_state:I = 0x7f0a14ab

.field public static final iv_tabindicator:I = 0x7f0a14ae

.field public static final iv_tag_name_prefix:I = 0x7f0a14af

.field public static final iv_text:I = 0x7f0a14b0

.field public static final iv_tip:I = 0x7f0a14b4

.field public static final iv_tips_icon:I = 0x7f0a14b5

.field public static final iv_vip:I = 0x7f0a14b8

.field public static final iv_wanted_normal_atmosphere:I = 0x7f0a14c0

.field public static final iv_watching_tip:I = 0x7f0a14c4

.field public static final join_layout:I = 0x7f0a14c8

.field public static final join_tv:I = 0x7f0a14ca

.field public static final join_vip_button:I = 0x7f0a14cb

.field public static final jubao_desc:I = 0x7f0a14cc

.field public static final jumpToEnd:I = 0x7f0a14cd

.field public static final jumpToStart:I = 0x7f0a14ce

.field public static final key:I = 0x7f0a14cf

.field public static final kv_star_tour_info:I = 0x7f0a14d0

.field public static final kv_star_tour_info_desc:I = 0x7f0a14d1

.field public static final kv_star_tour_info_img:I = 0x7f0a14d2

.field public static final kv_star_tour_info_name:I = 0x7f0a14d3

.field public static final kv_star_tour_info_price:I = 0x7f0a14d4

.field public static final kv_star_tour_info_pricevalue:I = 0x7f0a14d5

.field public static final kv_star_tour_info_tags:I = 0x7f0a14d6

.field public static final kv_star_tour_info_tags_parent:I = 0x7f0a14d7

.field public static final kv_star_tour_info_video_ui:I = 0x7f0a14d8

.field public static final kv_star_tour_info_video_v2:I = 0x7f0a14d9

.field public static final l1s1:I = 0x7f0a14da

.field public static final l1s2:I = 0x7f0a14db

.field public static final l1s3:I = 0x7f0a14dc

.field public static final l1s4:I = 0x7f0a14dd

.field public static final l1s5:I = 0x7f0a14de

.field public static final l1s6:I = 0x7f0a14df

.field public static final l2s1:I = 0x7f0a14e0

.field public static final l2s2:I = 0x7f0a14e1

.field public static final l2s3:I = 0x7f0a14e2

.field public static final l2s4:I = 0x7f0a14e3

.field public static final l2s5:I = 0x7f0a14e4

.field public static final l3s1:I = 0x7f0a14e5

.field public static final l4s1:I = 0x7f0a14e6

.field public static final label:I = 0x7f0a14e7

.field public static final label_icon:I = 0x7f0a14e8

.field public static final label_item:I = 0x7f0a14e9

.field public static final label_view:I = 0x7f0a14ea

.field public static final label_zone:I = 0x7f0a14eb

.field public static final labeled:I = 0x7f0a14ec

.field public static final language_arrow:I = 0x7f0a14ee

.field public static final language_more_txt:I = 0x7f0a14ef

.field public static final last_padding:I = 0x7f0a14f0

.field public static final last_select_day:I = 0x7f0a14f1

.field public static final last_select_day_ignore_current:I = 0x7f0a14f2

.field public static final last_update:I = 0x7f0a14f3

.field public static final last_visited_icon:I = 0x7f0a14f4

.field public static final launch_product_query:I = 0x7f0a14f5

.field public static final lay_city:I = 0x7f0a14f7

.field public static final lay_sex_sel:I = 0x7f0a14f8

.field public static final lay_title:I = 0x7f0a14f9

.field public static final layer_close:I = 0x7f0a14fa

.field public static final layer_subtitle:I = 0x7f0a14fb

.field public static final layer_subtitle_fake:I = 0x7f0a14fc

.field public static final layer_title:I = 0x7f0a14fd

.field public static final layermanager_canvas_innerview_id:I = 0x7f0a14fe

.field public static final layermanager_penetrate_webview_container_id:I = 0x7f0a14ff

.field public static final layermanager_viewmodel_page_id:I = 0x7f0a1500

.field public static final layermanager_viewmodel_view_id:I = 0x7f0a1501

.field public static final layout:I = 0x7f0a1502

.field public static final layout1:I = 0x7f0a1503

.field public static final layout2:I = 0x7f0a1504

.field public static final layout_action:I = 0x7f0a1505

.field public static final layout_address_content:I = 0x7f0a1506

.field public static final layout_address_main:I = 0x7f0a1507

.field public static final layout_all:I = 0x7f0a1509

.field public static final layout_all_click_toall:I = 0x7f0a150a

.field public static final layout_amount:I = 0x7f0a150b

.field public static final layout_base:I = 0x7f0a150d

.field public static final layout_bottom:I = 0x7f0a150f

.field public static final layout_bottom_buy_tip:I = 0x7f0a1511

.field public static final layout_bottom_channel_icon:I = 0x7f0a1512

.field public static final layout_bottom_discount_tip:I = 0x7f0a1513

.field public static final layout_bottom_discount_tip_container:I = 0x7f0a1514

.field public static final layout_bottom_num:I = 0x7f0a1515

.field public static final layout_bottom_qrcode_area_img:I = 0x7f0a1516

.field public static final layout_bottom_qrcode_area_ll:I = 0x7f0a1517

.field public static final layout_bottom_qrcode_area_text:I = 0x7f0a1518

.field public static final layout_calendar:I = 0x7f0a151b

.field public static final layout_channel:I = 0x7f0a151f

.field public static final layout_cinema_price:I = 0x7f0a1520

.field public static final layout_cinema_price_container:I = 0x7f0a1521

.field public static final layout_comment_container:I = 0x7f0a1525

.field public static final layout_comment_film_associate:I = 0x7f0a1526

.field public static final layout_consignee_info:I = 0x7f0a1529

.field public static final layout_container:I = 0x7f0a152a

.field public static final layout_content:I = 0x7f0a152b

.field public static final layout_copy_link:I = 0x7f0a152c

.field public static final layout_date:I = 0x7f0a152e

.field public static final layout_date_title:I = 0x7f0a1530

.field public static final layout_day:I = 0x7f0a1531

.field public static final layout_desc:I = 0x7f0a1532

.field public static final layout_dialog:I = 0x7f0a1533

.field public static final layout_discount:I = 0x7f0a1534

.field public static final layout_extra:I = 0x7f0a1536

.field public static final layout_fourdate:I = 0x7f0a1537

.field public static final layout_fragment_container:I = 0x7f0a1538

.field public static final layout_galley:I = 0x7f0a153a

.field public static final layout_generate_image:I = 0x7f0a153b

.field public static final layout_guding:I = 0x7f0a153d

.field public static final layout_hall_tip:I = 0x7f0a153f

.field public static final layout_header:I = 0x7f0a1540

.field public static final layout_header_view:I = 0x7f0a1541

.field public static final layout_heat_icon:I = 0x7f0a1542

.field public static final layout_heat_list:I = 0x7f0a1543

.field public static final layout_image:I = 0x7f0a1546

.field public static final layout_info:I = 0x7f0a1547

.field public static final layout_ipvuv:I = 0x7f0a154f

.field public static final layout_irc:I = 0x7f0a1550

.field public static final layout_left:I = 0x7f0a1552

.field public static final layout_movie_want_remark:I = 0x7f0a1556

.field public static final layout_null:I = 0x7f0a1559

.field public static final layout_num:I = 0x7f0a155a

.field public static final layout_num_top:I = 0x7f0a155b

.field public static final layout_order_delivery_info:I = 0x7f0a155c

.field public static final layout_pay_freight:I = 0x7f0a155e

.field public static final layout_perform:I = 0x7f0a155f

.field public static final layout_perform_des:I = 0x7f0a1560

.field public static final layout_perform_time_detailstr:I = 0x7f0a1561

.field public static final layout_perform_view:I = 0x7f0a1562

.field public static final layout_poster:I = 0x7f0a1565

.field public static final layout_price:I = 0x7f0a1566

.field public static final layout_price_detail:I = 0x7f0a1567

.field public static final layout_project:I = 0x7f0a1568

.field public static final layout_project_tag:I = 0x7f0a1569

.field public static final layout_quehuo:I = 0x7f0a156b

.field public static final layout_rating:I = 0x7f0a156d

.field public static final layout_refresh:I = 0x7f0a156e

.field public static final layout_register:I = 0x7f0a156f

.field public static final layout_right:I = 0x7f0a1570

.field public static final layout_row2:I = 0x7f0a1571

.field public static final layout_score:I = 0x7f0a1572

.field public static final layout_score_postfix:I = 0x7f0a1574

.field public static final layout_score_preifx:I = 0x7f0a1575

.field public static final layout_score_tip:I = 0x7f0a1576

.field public static final layout_scroll:I = 0x7f0a1577

.field public static final layout_search_input:I = 0x7f0a1578

.field public static final layout_seat:I = 0x7f0a1579

.field public static final layout_seat_img:I = 0x7f0a157a

.field public static final layout_seat_parent:I = 0x7f0a157c

.field public static final layout_see_heat:I = 0x7f0a1580

.field public static final layout_shouhu_detail:I = 0x7f0a1584

.field public static final layout_simple_date:I = 0x7f0a1586

.field public static final layout_simple_day:I = 0x7f0a1587

.field public static final layout_sku:I = 0x7f0a1588

.field public static final layout_sku_num_ll:I = 0x7f0a1589

.field public static final layout_star:I = 0x7f0a158b

.field public static final layout_start_bg:I = 0x7f0a158c

.field public static final layout_step:I = 0x7f0a158d

.field public static final layout_step_detail:I = 0x7f0a158e

.field public static final layout_sticky:I = 0x7f0a158f

.field public static final layout_subtitle:I = 0x7f0a1591

.field public static final layout_tag:I = 0x7f0a1592

.field public static final layout_tag_container:I = 0x7f0a1593

.field public static final layout_tag_img:I = 0x7f0a1594

.field public static final layout_tag_promotion:I = 0x7f0a1595

.field public static final layout_tag_righttop:I = 0x7f0a1596

.field public static final layout_tag_shape_combine_layout:I = 0x7f0a1597

.field public static final layout_tag_shape_post_v:I = 0x7f0a1598

.field public static final layout_tag_shape_prefix_v:I = 0x7f0a1599

.field public static final layout_tag_text:I = 0x7f0a159a

.field public static final layout_tag_vip:I = 0x7f0a159b

.field public static final layout_tag_vip_des:I = 0x7f0a159c

.field public static final layout_text_input:I = 0x7f0a159d

.field public static final layout_ticket_area:I = 0x7f0a159e

.field public static final layout_title:I = 0x7f0a159f

.field public static final layout_toast_title:I = 0x7f0a15a0

.field public static final layout_top:I = 0x7f0a15a2

.field public static final layout_top_normal:I = 0x7f0a15a3

.field public static final layout_top_see:I = 0x7f0a15a4

.field public static final layout_two_row:I = 0x7f0a15a5

.field public static final layout_webview:I = 0x7f0a15aa

.field public static final layout_xin:I = 0x7f0a15ab

.field public static final layout_yushou:I = 0x7f0a15ac

.field public static final leading_role:I = 0x7f0a15ae

.field public static final left:I = 0x7f0a15af

.field public static final leftBottom:I = 0x7f0a15b0

.field public static final leftCenter:I = 0x7f0a15b1

.field public static final leftToRight:I = 0x7f0a15b2

.field public static final leftTop:I = 0x7f0a15b3

.field public static final left_area:I = 0x7f0a15b4

.field public static final left_back:I = 0x7f0a15b5

.field public static final left_bottom_img_tag:I = 0x7f0a15b6

.field public static final left_circle:I = 0x7f0a15b7

.field public static final left_icon:I = 0x7f0a15b8

.field public static final left_text_container:I = 0x7f0a15b9

.field public static final left_top_image:I = 0x7f0a15bb

.field public static final left_top_layout:I = 0x7f0a15bc

.field public static final left_top_text:I = 0x7f0a15bd

.field public static final left_view:I = 0x7f0a15be

.field public static final letterText:I = 0x7f0a15c0

.field public static final light:I = 0x7f0a15c1

.field public static final like:I = 0x7f0a15c2

.field public static final like_icon:I = 0x7f0a15c3

.field public static final like_lay:I = 0x7f0a15c4

.field public static final like_lottie:I = 0x7f0a15c5

.field public static final lin_refresh_layout:I = 0x7f0a15c6

.field public static final lin_simple_date:I = 0x7f0a15c7

.field public static final line:I = 0x7f0a15c8

.field public static final line1:I = 0x7f0a15c9

.field public static final line1_container:I = 0x7f0a15ca

.field public static final line2_container:I = 0x7f0a15cb

.field public static final line2_text:I = 0x7f0a15cc

.field public static final line3:I = 0x7f0a15cd

.field public static final line3_text:I = 0x7f0a15ce

.field public static final line3_text_unit:I = 0x7f0a15cf

.field public static final line_page_indicator:I = 0x7f0a15d5

.field public static final line_title:I = 0x7f0a15da

.field public static final line_view:I = 0x7f0a15dd

.field public static final line_waitting_inner:I = 0x7f0a15de

.field public static final linear:I = 0x7f0a15df

.field public static final linearLayout:I = 0x7f0a15e0

.field public static final linearLayout2:I = 0x7f0a15e1

.field public static final linearLayout3:I = 0x7f0a15e2

.field public static final linearLayout4:I = 0x7f0a15e3

.field public static final linearLayout5:I = 0x7f0a15e4

.field public static final list:I = 0x7f0a15e5

.field public static final listMode:I = 0x7f0a15e6

.field public static final list_bg:I = 0x7f0a15e7

.field public static final list_conent:I = 0x7f0a15e8

.field public static final list_conent_cover:I = 0x7f0a15e9

.field public static final list_conent_parent:I = 0x7f0a15ea

.field public static final list_item:I = 0x7f0a15ed

.field public static final list_move_top:I = 0x7f0a15ee

.field public static final list_view:I = 0x7f0a15f1

.field public static final listview:I = 0x7f0a15f2

.field public static final listview_refresh:I = 0x7f0a15f3

.field public static final live_brand_bg_pic:I = 0x7f0a15f5

.field public static final live_brand_container:I = 0x7f0a15f6

.field public static final live_brand_info:I = 0x7f0a15f7

.field public static final live_brand_info_container:I = 0x7f0a15f8

.field public static final live_brand_name:I = 0x7f0a15f9

.field public static final live_brand_performanceCount:I = 0x7f0a15fa

.field public static final live_brand_pic:I = 0x7f0a15fb

.field public static final live_brand_price:I = 0x7f0a15fc

.field public static final live_brand_price_container:I = 0x7f0a15fd

.field public static final live_card_all:I = 0x7f0a15fe

.field public static final live_card_all_icon:I = 0x7f0a15ff

.field public static final live_card_bg_pic:I = 0x7f0a1600

.field public static final live_card_flag:I = 0x7f0a1601

.field public static final live_card_go_to_all:I = 0x7f0a1602

.field public static final live_card_info:I = 0x7f0a1603

.field public static final live_card_name:I = 0x7f0a1604

.field public static final live_icon:I = 0x7f0a1632

.field public static final live_notice:I = 0x7f0a1637

.field public static final live_remind_avatar_img:I = 0x7f0a1649

.field public static final live_remind_title_tv:I = 0x7f0a164a

.field public static final live_remind_vertical_flipper:I = 0x7f0a164b

.field public static final live_share_artist_container:I = 0x7f0a164c

.field public static final live_share_artist_left:I = 0x7f0a164d

.field public static final live_share_artist_right:I = 0x7f0a164e

.field public static final live_venue_bg_pic:I = 0x7f0a1650

.field public static final live_venue_container:I = 0x7f0a1651

.field public static final live_venue_info:I = 0x7f0a1652

.field public static final live_venue_info_container:I = 0x7f0a1653

.field public static final live_venue_name:I = 0x7f0a1654

.field public static final live_venue_performanceCount:I = 0x7f0a1655

.field public static final live_venue_pic:I = 0x7f0a1656

.field public static final live_venue_price:I = 0x7f0a1657

.field public static final live_venue_price_container:I = 0x7f0a1658

.field public static final livehouse_artist_content_recycler:I = 0x7f0a165b

.field public static final livehouse_artist_recycler:I = 0x7f0a165c

.field public static final liwu_view:I = 0x7f0a165d

.field public static final ll:I = 0x7f0a165e

.field public static final llContent:I = 0x7f0a1660

.field public static final llSearchTag:I = 0x7f0a1661

.field public static final ll_2_part_container:I = 0x7f0a1664

.field public static final ll_add:I = 0x7f0a1666

.field public static final ll_add_city:I = 0x7f0a1667

.field public static final ll_add_city_container:I = 0x7f0a1668

.field public static final ll_address_and_distance:I = 0x7f0a166e

.field public static final ll_amount:I = 0x7f0a1670

.field public static final ll_auth_third_detail:I = 0x7f0a1671

.field public static final ll_banners:I = 0x7f0a1673

.field public static final ll_block_card_select_area:I = 0x7f0a1674

.field public static final ll_block_card_select_icons:I = 0x7f0a1675

.field public static final ll_bottom:I = 0x7f0a1676

.field public static final ll_bottom_button:I = 0x7f0a1677

.field public static final ll_bottom_discount_tip_container:I = 0x7f0a167a

.field public static final ll_boxing_office_rank:I = 0x7f0a167c

.field public static final ll_button_container:I = 0x7f0a167f

.field public static final ll_call_phone:I = 0x7f0a1680

.field public static final ll_card_note_proj:I = 0x7f0a1681

.field public static final ll_card_note_proj_img:I = 0x7f0a1682

.field public static final ll_card_note_proj_name:I = 0x7f0a1683

.field public static final ll_card_note_proj_score:I = 0x7f0a1684

.field public static final ll_card_num:I = 0x7f0a1685

.field public static final ll_card_type:I = 0x7f0a1686

.field public static final ll_center:I = 0x7f0a1687

.field public static final ll_center_content:I = 0x7f0a1688

.field public static final ll_child_price:I = 0x7f0a168a

.field public static final ll_city_tour:I = 0x7f0a168c

.field public static final ll_comment:I = 0x7f0a168e

.field public static final ll_comment_banner:I = 0x7f0a168f

.field public static final ll_console_windowbar:I = 0x7f0a1694

.field public static final ll_container:I = 0x7f0a1697

.field public static final ll_content:I = 0x7f0a1698

.field public static final ll_cost:I = 0x7f0a1699

.field public static final ll_coupon_detail:I = 0x7f0a169a

.field public static final ll_coupon_item:I = 0x7f0a169b

.field public static final ll_coupon_parent:I = 0x7f0a169f

.field public static final ll_coupon_price:I = 0x7f0a16a0

.field public static final ll_coupon_rule:I = 0x7f0a16a1

.field public static final ll_coupons:I = 0x7f0a16a4

.field public static final ll_deep_article:I = 0x7f0a16a6

.field public static final ll_delete:I = 0x7f0a16a7

.field public static final ll_discount_integral:I = 0x7f0a16b6

.field public static final ll_discount_stock:I = 0x7f0a16b7

.field public static final ll_dna:I = 0x7f0a16ba

.field public static final ll_draw_btn:I = 0x7f0a16bc

.field public static final ll_edit_comment:I = 0x7f0a16be

.field public static final ll_empty_root:I = 0x7f0a16c1

.field public static final ll_error:I = 0x7f0a16c3

.field public static final ll_error_container:I = 0x7f0a16c4

.field public static final ll_exchange_reminder:I = 0x7f0a16c6

.field public static final ll_fans_ranking_item:I = 0x7f0a16cb

.field public static final ll_fans_ranking_item_name:I = 0x7f0a16cc

.field public static final ll_fans_ranking_item_number:I = 0x7f0a16cd

.field public static final ll_fans_ranking_item_pic:I = 0x7f0a16ce

.field public static final ll_fans_ranking_item_value:I = 0x7f0a16cf

.field public static final ll_fans_ranking_parent:I = 0x7f0a16d0

.field public static final ll_feed_praise_layout:I = 0x7f0a16d1

.field public static final ll_feedback:I = 0x7f0a16d3

.field public static final ll_film_detail_comment_count:I = 0x7f0a16d4

.field public static final ll_film_profile_item:I = 0x7f0a16d5

.field public static final ll_follow:I = 0x7f0a16d6

.field public static final ll_homepage_item_bottom_left_artist:I = 0x7f0a16de

.field public static final ll_images:I = 0x7f0a16e2

.field public static final ll_initial:I = 0x7f0a16e3

.field public static final ll_integral:I = 0x7f0a16e4

.field public static final ll_integral_convert:I = 0x7f0a16e5

.field public static final ll_integral_value:I = 0x7f0a16e6

.field public static final ll_lose:I = 0x7f0a16f6

.field public static final ll_lose_logo:I = 0x7f0a16f7

.field public static final ll_member_auth_layout:I = 0x7f0a16f8

.field public static final ll_member_auth_protocol:I = 0x7f0a16f9

.field public static final ll_member_auth_protocol_instruction:I = 0x7f0a16fa

.field public static final ll_member_auth_title:I = 0x7f0a16fb

.field public static final ll_more:I = 0x7f0a1715

.field public static final ll_more_tour:I = 0x7f0a1716

.field public static final ll_more_tour_line:I = 0x7f0a1717

.field public static final ll_name:I = 0x7f0a1719

.field public static final ll_not_use_coupon_container:I = 0x7f0a171a

.field public static final ll_not_use_expand:I = 0x7f0a171b

.field public static final ll_notice:I = 0x7f0a171c

.field public static final ll_open_card_parent:I = 0x7f0a1720

.field public static final ll_order_address:I = 0x7f0a1721

.field public static final ll_page:I = 0x7f0a172c

.field public static final ll_parent:I = 0x7f0a172d

.field public static final ll_parent_title:I = 0x7f0a172e

.field public static final ll_perform_item:I = 0x7f0a173a

.field public static final ll_phone_zone:I = 0x7f0a173c

.field public static final ll_price:I = 0x7f0a1741

.field public static final ll_project_extra_benefit_layout:I = 0x7f0a174a

.field public static final ll_project_right:I = 0x7f0a174d

.field public static final ll_promotion_excel_layout:I = 0x7f0a1751

.field public static final ll_rank_mid_layout:I = 0x7f0a1755

.field public static final ll_red_packet:I = 0x7f0a1757

.field public static final ll_renewal_number:I = 0x7f0a175a

.field public static final ll_root:I = 0x7f0a175e

.field public static final ll_sale:I = 0x7f0a1760

.field public static final ll_sales:I = 0x7f0a1761

.field public static final ll_score:I = 0x7f0a1762

.field public static final ll_score_follow:I = 0x7f0a1763

.field public static final ll_search_bottom_div:I = 0x7f0a1765

.field public static final ll_search_item:I = 0x7f0a1766

.field public static final ll_senior_vip_integral:I = 0x7f0a1768

.field public static final ll_share_channel:I = 0x7f0a176a

.field public static final ll_spring_dialog_button:I = 0x7f0a176e

.field public static final ll_spring_open_card_content:I = 0x7f0a176f

.field public static final ll_spring_open_card_dialog_tip:I = 0x7f0a1770

.field public static final ll_star:I = 0x7f0a1776

.field public static final ll_step1:I = 0x7f0a1777

.field public static final ll_step2:I = 0x7f0a1778

.field public static final ll_step3:I = 0x7f0a1779

.field public static final ll_tabs:I = 0x7f0a177c

.field public static final ll_text_content:I = 0x7f0a177d

.field public static final ll_tiaopiaopiao_tip:I = 0x7f0a1781

.field public static final ll_ticket_info:I = 0x7f0a1783

.field public static final ll_timer:I = 0x7f0a1787

.field public static final ll_tips_container:I = 0x7f0a178a

.field public static final ll_title:I = 0x7f0a178b

.field public static final ll_title_bar:I = 0x7f0a178c

.field public static final ll_titlebar_login:I = 0x7f0a1790

.field public static final ll_tm_right_profit_layout:I = 0x7f0a1791

.field public static final ll_top:I = 0x7f0a1792

.field public static final ll_top_container:I = 0x7f0a1795

.field public static final ll_transpant:I = 0x7f0a1799

.field public static final ll_tv_container:I = 0x7f0a179a

.field public static final ll_user_dna:I = 0x7f0a179e

.field public static final ll_video:I = 0x7f0a17a4

.field public static final ll_video_tag:I = 0x7f0a17a5

.field public static final ll_view_container:I = 0x7f0a17a6

.field public static final ll_view_root:I = 0x7f0a17a7

.field public static final ll_vip_item:I = 0x7f0a17a8

.field public static final ll_voice:I = 0x7f0a17a9

.field public static final ll_week:I = 0x7f0a17ab

.field public static final load_more_layout:I = 0x7f0a17ad

.field public static final loadingLayout_status_bar_space:I = 0x7f0a17af

.field public static final loadingView:I = 0x7f0a17b0

.field public static final loading_des:I = 0x7f0a17b1

.field public static final loading_item:I = 0x7f0a17b3

.field public static final loading_view:I = 0x7f0a17b6

.field public static final location:I = 0x7f0a17b8

.field public static final location_container:I = 0x7f0a17b9

.field public static final location_tip_pop_action_btn:I = 0x7f0a17ba

.field public static final location_tip_pop_action_close:I = 0x7f0a17bb

.field public static final location_tip_pop_content:I = 0x7f0a17bc

.field public static final location_tip_pop_content_block:I = 0x7f0a17bd

.field public static final location_tip_pop_content_des:I = 0x7f0a17be

.field public static final location_tip_pop_content_title:I = 0x7f0a17bf

.field public static final location_tip_pop_img_arrow:I = 0x7f0a17c0

.field public static final log:I = 0x7f0a17c1

.field public static final loginContainer:I = 0x7f0a17c2

.field public static final login_btn:I = 0x7f0a17c3

.field public static final login_doc:I = 0x7f0a17c4

.field public static final login_more_title:I = 0x7f0a17c5

.field public static final login_platform_damai_logo:I = 0x7f0a17c6

.field public static final login_platform_wechat_btn:I = 0x7f0a17c7

.field public static final login_third_account_btn:I = 0x7f0a17c8

.field public static final login_third_more_btn:I = 0x7f0a17c9

.field public static final login_third_platform_qq_btn:I = 0x7f0a17ca

.field public static final login_third_platform_weibo_btn:I = 0x7f0a17cb

.field public static final login_third_taobao_btn:I = 0x7f0a17cc

.field public static final login_third_tb_btn:I = 0x7f0a17cd

.field public static final login_third_zhifubao_btn:I = 0x7f0a17ce

.field public static final login_view:I = 0x7f0a17cf

.field public static final logo:I = 0x7f0a17d0

.field public static final loop_banner:I = 0x7f0a17d2

.field public static final loop_indicator:I = 0x7f0a17d3

.field public static final lottery_pic:I = 0x7f0a17d4

.field public static final lottie_animation:I = 0x7f0a17d5

.field public static final lottie_focus:I = 0x7f0a17d7

.field public static final lottie_focus_layout:I = 0x7f0a17d8

.field public static final lottie_icon:I = 0x7f0a17d9

.field public static final lottie_layer_name:I = 0x7f0a17da

.field public static final lottie_view:I = 0x7f0a17dc

.field public static final lottie_voice:I = 0x7f0a17dd

.field public static final lottie_want_see:I = 0x7f0a17de

.field public static final lottie_want_see_fl:I = 0x7f0a17df

.field public static final lottie_want_thumb:I = 0x7f0a17e0

.field public static final lottie_wanted_normal_atmosphere:I = 0x7f0a17e1

.field public static final love_value:I = 0x7f0a17e2

.field public static final love_value_container:I = 0x7f0a17e3

.field public static final love_value_label:I = 0x7f0a17e4

.field public static final ltr:I = 0x7f0a17e7

.field public static final luck_draw_result_bg:I = 0x7f0a17e8

.field public static final luck_draw_result_empty_bg:I = 0x7f0a17e9

.field public static final lv_container:I = 0x7f0a17ea

.field public static final lv_profile:I = 0x7f0a17ed

.field public static final lz_tag:I = 0x7f0a17ee

.field public static final mWebView:I = 0x7f0a17ef

.field public static final main:I = 0x7f0a17f1

.field public static final main_desc:I = 0x7f0a17f4

.field public static final main_hot_item_llyt:I = 0x7f0a17f5

.field public static final main_hot_recommand_item_iv:I = 0x7f0a17f6

.field public static final main_hot_recommand_item_name_tv:I = 0x7f0a17f7

.field public static final main_hot_recommand_item_time_tv:I = 0x7f0a17f8

.field public static final main_image:I = 0x7f0a17f9

.field public static final main_tab_recycler:I = 0x7f0a17ff

.field public static final main_title:I = 0x7f0a1800

.field public static final main_view:I = 0x7f0a1801

.field public static final manualOnly:I = 0x7f0a1802

.field public static final mark_bottom_spacing:I = 0x7f0a1805

.field public static final mark_s1_city_name:I = 0x7f0a1806

.field public static final mark_s1_city_name_shining:I = 0x7f0a1807

.field public static final mark_s1_img_1:I = 0x7f0a1808

.field public static final mark_s1_img_1_ui:I = 0x7f0a1809

.field public static final mark_s1_img_2:I = 0x7f0a180a

.field public static final mark_s1_img_2_ui:I = 0x7f0a180b

.field public static final mark_s1_img_3:I = 0x7f0a180c

.field public static final mark_s1_img_3_ui:I = 0x7f0a180d

.field public static final mark_s1_layout_normal:I = 0x7f0a180e

.field public static final mark_s2_city_name:I = 0x7f0a180f

.field public static final mark_s2_close:I = 0x7f0a1810

.field public static final mark_s2_layout_highlight:I = 0x7f0a1811

.field public static final mark_s2_show_layout_1:I = 0x7f0a1812

.field public static final mark_s2_show_layout_2:I = 0x7f0a1813

.field public static final mark_s2_show_layout_3:I = 0x7f0a1814

.field public static final mark_s3_layout_point:I = 0x7f0a1815

.field public static final mark_s4_filter_icon:I = 0x7f0a1816

.field public static final mark_s4_filter_title:I = 0x7f0a1817

.field public static final market_tag_container:I = 0x7f0a1819

.field public static final marqueeTextView:I = 0x7f0a181f

.field public static final mask_bottom:I = 0x7f0a1820

.field public static final mask_grab_time:I = 0x7f0a1821

.field public static final mask_image:I = 0x7f0a1822

.field public static final mask_invalid:I = 0x7f0a1823

.field public static final mask_layer:I = 0x7f0a1824

.field public static final mask_top:I = 0x7f0a1825

.field public static final masked:I = 0x7f0a182b

.field public static final master_tag:I = 0x7f0a182c

.field public static final match_constraint:I = 0x7f0a182d

.field public static final match_header:I = 0x7f0a182e

.field public static final match_parent:I = 0x7f0a182f

.field public static final material_clock_display:I = 0x7f0a1830

.field public static final material_clock_face:I = 0x7f0a1831

.field public static final material_clock_hand:I = 0x7f0a1832

.field public static final material_clock_period_am_button:I = 0x7f0a1833

.field public static final material_clock_period_pm_button:I = 0x7f0a1834

.field public static final material_clock_period_toggle:I = 0x7f0a1835

.field public static final material_hour_text_input:I = 0x7f0a1836

.field public static final material_hour_tv:I = 0x7f0a1837

.field public static final material_label:I = 0x7f0a1838

.field public static final material_minute_text_input:I = 0x7f0a1839

.field public static final material_minute_tv:I = 0x7f0a183a

.field public static final material_textinput_timepicker:I = 0x7f0a183b

.field public static final material_timepicker_cancel_button:I = 0x7f0a183c

.field public static final material_timepicker_container:I = 0x7f0a183d

.field public static final material_timepicker_edit_text:I = 0x7f0a183e

.field public static final material_timepicker_mode_button:I = 0x7f0a183f

.field public static final material_timepicker_ok_button:I = 0x7f0a1840

.field public static final material_timepicker_view:I = 0x7f0a1841

.field public static final material_value_index:I = 0x7f0a1842

.field public static final matrix:I = 0x7f0a1843

.field public static final max_window:I = 0x7f0a1844

.field public static final mcard_container:I = 0x7f0a1845

.field public static final mcard_header_icon:I = 0x7f0a1846

.field public static final mcard_header_title:I = 0x7f0a1847

.field public static final mcard_save_bogo_number:I = 0x7f0a1848

.field public static final mcard_save_number:I = 0x7f0a1849

.field public static final mcard_top_divider:I = 0x7f0a184a

.field public static final mcard_top_divider_use_tips:I = 0x7f0a184b

.field public static final mcard_vip_benefit_container:I = 0x7f0a184c

.field public static final mcard_vip_tag:I = 0x7f0a184d

.field public static final mcard_vip_title:I = 0x7f0a184e

.field public static final mcv_pager:I = 0x7f0a184f

.field public static final media_actions:I = 0x7f0a1850

.field public static final media_image:I = 0x7f0a1853

.field public static final media_name:I = 0x7f0a1854

.field public static final media_next:I = 0x7f0a1855

.field public static final media_pause:I = 0x7f0a1859

.field public static final media_time:I = 0x7f0a185a

.field public static final media_vod_container:I = 0x7f0a185b

.field public static final media_want_container:I = 0x7f0a185c

.field public static final member_auth_right_close:I = 0x7f0a185d

.field public static final member_auth_tip:I = 0x7f0a185e

.field public static final member_damai_auth:I = 0x7f0a185f

.field public static final member_level_bg:I = 0x7f0a1862

.field public static final member_level_img:I = 0x7f0a1863

.field public static final member_taopiaopiao_auth:I = 0x7f0a1869

.field public static final menu_action1:I = 0x7f0a1873

.field public static final menu_action2:I = 0x7f0a1874

.field public static final menu_action2_container:I = 0x7f0a1875

.field public static final menu_action2_text:I = 0x7f0a1876

.field public static final message:I = 0x7f0a1877

.field public static final message_scrollView:I = 0x7f0a1886

.field public static final message_text:I = 0x7f0a1887

.field public static final mfh_text:I = 0x7f0a188e

.field public static final mfh_text_layout:I = 0x7f0a188f

.field public static final middle:I = 0x7f0a1890

.field public static final min_window:I = 0x7f0a1893

.field public static final mine_add_address_title_left_icon:I = 0x7f0a1896

.field public static final mine_address_invalid_close_prompt_tv:I = 0x7f0a1897

.field public static final mine_address_invalid_prompt_content_tv:I = 0x7f0a1898

.field public static final mine_address_invalid_prompt_rv:I = 0x7f0a1899

.field public static final mine_address_item_default_indicator_tv:I = 0x7f0a189a

.field public static final mine_address_item_default_text_tv:I = 0x7f0a189b

.field public static final mine_address_item_detail_address_tv:I = 0x7f0a189c

.field public static final mine_address_item_invalid_indicator_tv:I = 0x7f0a189d

.field public static final mine_address_item_receiver_basic_ll:I = 0x7f0a189e

.field public static final mine_address_item_right_indicator_tv:I = 0x7f0a189f

.field public static final mine_address_item_set_default_ll:I = 0x7f0a18a0

.field public static final mine_address_list_header:I = 0x7f0a18a1

.field public static final mine_address_list_recycler_view:I = 0x7f0a18a2

.field public static final mine_base_header_left:I = 0x7f0a18a9

.field public static final mine_base_header_title:I = 0x7f0a18aa

.field public static final mine_brand_project_1:I = 0x7f0a18af

.field public static final mine_brand_project_2:I = 0x7f0a18b0

.field public static final mine_brand_project_3:I = 0x7f0a18b1

.field public static final mine_brand_project_div1:I = 0x7f0a18b2

.field public static final mine_brand_project_div2:I = 0x7f0a18b3

.field public static final mine_title_left_icon_font_tv:I = 0x7f0a18ff

.field public static final mine_title_right_tv:I = 0x7f0a1900

.field public static final mine_title_tv:I = 0x7f0a1901

.field public static final mini:I = 0x7f0a1914

.field public static final mirror:I = 0x7f0a1926

.field public static final mix_appbar_layout:I = 0x7f0a1927

.field public static final mo_alertdialog_body_bottom_divider:I = 0x7f0a1928

.field public static final mo_alertdialog_bottom:I = 0x7f0a1929

.field public static final mo_alertdialog_bottom_close_btn:I = 0x7f0a192a

.field public static final mo_alertdialog_content:I = 0x7f0a192b

.field public static final mo_alertdialog_content_body:I = 0x7f0a192c

.field public static final mo_alertdialog_head_wrapper:I = 0x7f0a192d

.field public static final mo_alertdialog_rootview:I = 0x7f0a192e

.field public static final mo_alertdialog_top_body_divider:I = 0x7f0a192f

.field public static final mo_itemview_desimg_layout_des:I = 0x7f0a1930

.field public static final mo_itemview_desimg_layout_img:I = 0x7f0a1931

.field public static final mo_itemview_icondes_layout_des:I = 0x7f0a1932

.field public static final mo_itemview_icondes_layout_icon:I = 0x7f0a1933

.field public static final mo_itemview_normal_text:I = 0x7f0a1934

.field public static final mo_recyclerview_fragment_content:I = 0x7f0a1935

.field public static final mo_tip_pop_content:I = 0x7f0a1936

.field public static final mo_tip_pop_content_block:I = 0x7f0a1937

.field public static final mo_tip_pop_content_close_btn:I = 0x7f0a1938

.field public static final mo_tip_pop_img_arrow:I = 0x7f0a1939

.field public static final mo_tip_pop_img_down:I = 0x7f0a193a

.field public static final mock_irc:I = 0x7f0a193b

.field public static final mode_all:I = 0x7f0a193c

.field public static final mode_fix:I = 0x7f0a193d

.field public static final mode_only_current:I = 0x7f0a193e

.field public static final modify_tv:I = 0x7f0a1945

.field public static final module_title_label_x:I = 0x7f0a1947

.field public static final module_title_layout:I = 0x7f0a1948

.field public static final module_title_more_layout_1:I = 0x7f0a1949

.field public static final module_title_more_layout_2:I = 0x7f0a194a

.field public static final module_title_more_text_1:I = 0x7f0a194b

.field public static final module_title_more_text_2:I = 0x7f0a194c

.field public static final moimage_target_uri:I = 0x7f0a194d

.field public static final mon:I = 0x7f0a194e

.field public static final monday:I = 0x7f0a194f

.field public static final monospace:I = 0x7f0a1950

.field public static final month:I = 0x7f0a1951

.field public static final month_grid:I = 0x7f0a1952

.field public static final month_navigation_bar:I = 0x7f0a1953

.field public static final month_navigation_fragment_toggle:I = 0x7f0a1954

.field public static final month_navigation_next:I = 0x7f0a1955

.field public static final month_navigation_previous:I = 0x7f0a1956

.field public static final month_tab_tv:I = 0x7f0a1957

.field public static final month_title:I = 0x7f0a1958

.field public static final more:I = 0x7f0a1959

.field public static final more_arrow:I = 0x7f0a195b

.field public static final more_text:I = 0x7f0a195e

.field public static final more_txt:I = 0x7f0a1961

.field public static final motion_base:I = 0x7f0a1962

.field public static final moveableTexture:I = 0x7f0a1963

.field public static final movie_btn:I = 0x7f0a1964

.field public static final movie_container:I = 0x7f0a1965

.field public static final movie_detail_container:I = 0x7f0a1966

.field public static final movie_name:I = 0x7f0a1967

.field public static final movie_no_remark:I = 0x7f0a1968

.field public static final movie_remark:I = 0x7f0a196a

.field public static final movie_show_mark:I = 0x7f0a196b

.field public static final movie_spm_page_apm_b:I = 0x7f0a196c

.field public static final movie_spm_value:I = 0x7f0a196d

.field public static final movie_time__comment_content_imglist_viewstub:I = 0x7f0a196e

.field public static final msgText:I = 0x7f0a196f

.field public static final msg_text:I = 0x7f0a1970

.field public static final mtrl_anchor_parent:I = 0x7f0a1971

.field public static final mtrl_calendar_day_selector_frame:I = 0x7f0a1972

.field public static final mtrl_calendar_days_of_week:I = 0x7f0a1973

.field public static final mtrl_calendar_frame:I = 0x7f0a1974

.field public static final mtrl_calendar_main_pane:I = 0x7f0a1975

.field public static final mtrl_calendar_months:I = 0x7f0a1976

.field public static final mtrl_calendar_selection_frame:I = 0x7f0a1977

.field public static final mtrl_calendar_text_input_frame:I = 0x7f0a1978

.field public static final mtrl_calendar_year_selector_frame:I = 0x7f0a1979

.field public static final mtrl_card_checked_layer_id:I = 0x7f0a197a

.field public static final mtrl_child_content_container:I = 0x7f0a197b

.field public static final mtrl_internal_children_alpha_tag:I = 0x7f0a197c

.field public static final mtrl_motion_snapshot_view:I = 0x7f0a197d

.field public static final mtrl_picker_fullscreen:I = 0x7f0a197e

.field public static final mtrl_picker_header:I = 0x7f0a197f

.field public static final mtrl_picker_header_selection_text:I = 0x7f0a1980

.field public static final mtrl_picker_header_title_and_selection:I = 0x7f0a1981

.field public static final mtrl_picker_header_toggle:I = 0x7f0a1982

.field public static final mtrl_picker_text_input_date:I = 0x7f0a1983

.field public static final mtrl_picker_text_input_range_end:I = 0x7f0a1984

.field public static final mtrl_picker_text_input_range_start:I = 0x7f0a1985

.field public static final mtrl_picker_title_text:I = 0x7f0a1986

.field public static final mtrl_view_tag_bottom_padding:I = 0x7f0a1987

.field public static final multi_image_container:I = 0x7f0a1988

.field public static final multi_image_one:I = 0x7f0a1989

.field public static final multi_image_three:I = 0x7f0a198a

.field public static final multi_image_two:I = 0x7f0a198b

.field public static final multi_list:I = 0x7f0a198c

.field public static final multi_mode:I = 0x7f0a198d

.field public static final multi_user_layout:I = 0x7f0a198e

.field public static final multiply:I = 0x7f0a198f

.field public static final music_festival_hot_vf_ui:I = 0x7f0a1990

.field public static final music_festival_map_layout:I = 0x7f0a1991

.field public static final music_festival_map_tab_list:I = 0x7f0a1992

.field public static final music_festival_map_tip:I = 0x7f0a1993

.field public static final music_festival_map_view:I = 0x7f0a1994

.field public static final music_festival_vf:I = 0x7f0a1995

.field public static final music_icon_vf:I = 0x7f0a1996

.field public static final music_page_share_id:I = 0x7f0a1997

.field public static final music_tab_border:I = 0x7f0a1998

.field public static final music_tab_icon:I = 0x7f0a1999

.field public static final music_tab_name:I = 0x7f0a199a

.field public static final myWebView:I = 0x7f0a199b

.field public static final my_benefit_youku_actionbtn:I = 0x7f0a199c

.field public static final my_benefit_youku_bg:I = 0x7f0a199d

.field public static final my_benefit_youku_des:I = 0x7f0a199e

.field public static final my_benefit_youku_timer:I = 0x7f0a199f

.field public static final my_benefit_youku_title:I = 0x7f0a19a0

.field public static final my_happy_coin_txt:I = 0x7f0a19a1

.field public static final my_surfaceView:I = 0x7f0a19a2

.field public static final nIndicator:I = 0x7f0a19a6

.field public static final name:I = 0x7f0a19a7

.field public static final name_and_balance:I = 0x7f0a19a8

.field public static final name_container:I = 0x7f0a19a9

.field public static final name_layout:I = 0x7f0a19aa

.field public static final name_mark1:I = 0x7f0a19ab

.field public static final name_mark2:I = 0x7f0a19ac

.field public static final name_mark3:I = 0x7f0a19ad

.field public static final name_title:I = 0x7f0a19ae

.field public static final name_tv:I = 0x7f0a19af

.field public static final nav_bar:I = 0x7f0a19b0

.field public static final nav_bar_immersive:I = 0x7f0a19b1

.field public static final navbar_back:I = 0x7f0a19b2

.field public static final navbar_back_bg:I = 0x7f0a19b3

.field public static final navbar_back_icon:I = 0x7f0a19b4

.field public static final navbar_back_layout:I = 0x7f0a19b5

.field public static final navbar_follow:I = 0x7f0a19b6

.field public static final navbar_img:I = 0x7f0a19b7

.field public static final navbar_share_bg:I = 0x7f0a19b8

.field public static final navbar_share_icon:I = 0x7f0a19b9

.field public static final navbar_share_layout:I = 0x7f0a19ba

.field public static final navbar_title:I = 0x7f0a19bb

.field public static final navbar_title_layout:I = 0x7f0a19bc

.field public static final navigate_tab:I = 0x7f0a19bd

.field public static final navigation:I = 0x7f0a19be

.field public static final navigation_bar_item_active_indicator_view:I = 0x7f0a19bf

.field public static final navigation_bar_item_icon_container:I = 0x7f0a19c0

.field public static final navigation_bar_item_icon_view:I = 0x7f0a19c1

.field public static final navigation_bar_item_labels_group:I = 0x7f0a19c2

.field public static final navigation_bar_item_large_label_view:I = 0x7f0a19c3

.field public static final navigation_bar_item_small_label_view:I = 0x7f0a19c4

.field public static final navigation_header_container:I = 0x7f0a19c5

.field public static final need_int_check_img:I = 0x7f0a19cd

.field public static final need_int_dis_check_img:I = 0x7f0a19ce

.field public static final need_int_dis_uncheck_img:I = 0x7f0a19cf

.field public static final need_int_uncheck_img:I = 0x7f0a19d0

.field public static final need_integral:I = 0x7f0a19d1

.field public static final never:I = 0x7f0a19d2

.field public static final neverCompleteToEnd:I = 0x7f0a19d3

.field public static final neverCompleteToStart:I = 0x7f0a19d4

.field public static final new_common_text:I = 0x7f0a19d5

.field public static final new_person_gift_view:I = 0x7f0a19dc

.field public static final new_person_gift_view_stub:I = 0x7f0a19dd

.field public static final next_button:I = 0x7f0a19e3

.field public static final next_video:I = 0x7f0a19e4

.field public static final nick_name:I = 0x7f0a19e6

.field public static final nickname_line:I = 0x7f0a19e9

.field public static final nine_image_layout:I = 0x7f0a19ea

.field public static final nkv_star_tour_info:I = 0x7f0a19ee

.field public static final noState:I = 0x7f0a19f0

.field public static final no_code:I = 0x7f0a19f1

.field public static final no_name:I = 0x7f0a19f2

.field public static final no_prize:I = 0x7f0a19f3

.field public static final no_score_zone:I = 0x7f0a19f5

.field public static final none:I = 0x7f0a19f8

.field public static final normal:I = 0x7f0a19f9

.field public static final normal_tag_zone:I = 0x7f0a19fd

.field public static final north:I = 0x7f0a19fe

.field public static final not_cancel_vote:I = 0x7f0a19ff

.field public static final note_card_bottom_desc:I = 0x7f0a1a00

.field public static final note_card_bottom_icon:I = 0x7f0a1a01

.field public static final note_card_bottom_ll:I = 0x7f0a1a02

.field public static final note_container:I = 0x7f0a1a03

.field public static final note_location_text:I = 0x7f0a1a04

.field public static final note_more_action:I = 0x7f0a1a05

.field public static final note_relate_icon:I = 0x7f0a1a06

.field public static final note_relate_tv:I = 0x7f0a1a07

.field public static final note_relate_ui:I = 0x7f0a1a08

.field public static final note_s1_hw_layout:I = 0x7f0a1a09

.field public static final note_s1_img:I = 0x7f0a1a0a

.field public static final note_s1_title:I = 0x7f0a1a0b

.field public static final note_s1_title_2:I = 0x7f0a1a0c

.field public static final note_s2_text:I = 0x7f0a1a0d

.field public static final note_s2_ui:I = 0x7f0a1a0e

.field public static final note_si_feature:I = 0x7f0a1a0f

.field public static final note_si_top:I = 0x7f0a1a10

.field public static final note_stroke_layout:I = 0x7f0a1a11

.field public static final note_tag_lb_category:I = 0x7f0a1a12

.field public static final note_tag_lb_category_avatar:I = 0x7f0a1a13

.field public static final note_tag_lb_category_blurbg:I = 0x7f0a1a14

.field public static final note_tag_lb_category_pro:I = 0x7f0a1a15

.field public static final note_text:I = 0x7f0a1a16

.field public static final note_view_pager:I = 0x7f0a1a17

.field public static final notice_card_container:I = 0x7f0a1a18

.field public static final notice_list_content:I = 0x7f0a1a1b

.field public static final notice_list_divline:I = 0x7f0a1a1c

.field public static final notice_list_imgcontent:I = 0x7f0a1a1d

.field public static final notice_list_time:I = 0x7f0a1a1e

.field public static final notice_list_title:I = 0x7f0a1a1f

.field public static final notification_background:I = 0x7f0a1a20

.field public static final notification_main_column:I = 0x7f0a1a21

.field public static final notification_main_column_container:I = 0x7f0a1a22

.field public static final nowplaying_btn_zone:I = 0x7f0a1a25

.field public static final nowrap:I = 0x7f0a1a26

.field public static final numIndicator:I = 0x7f0a1a2a

.field public static final numIndicatorInside:I = 0x7f0a1a2b

.field public static final number:I = 0x7f0a1a2d

.field public static final number_et:I = 0x7f0a1a2e

.field public static final number_layout:I = 0x7f0a1a2f

.field public static final number_text:I = 0x7f0a1a30

.field public static final off:I = 0x7f0a1a31

.field public static final offical_content_item_content_id:I = 0x7f0a1a32

.field public static final offical_content_item_index_id:I = 0x7f0a1a33

.field public static final offical_goods_list:I = 0x7f0a1a34

.field public static final ok:I = 0x7f0a1a35

.field public static final ok_btn:I = 0x7f0a1a36

.field public static final on:I = 0x7f0a1a38

.field public static final one_arch_footer:I = 0x7f0a1a3a

.field public static final one_arch_header:I = 0x7f0a1a3b

.field public static final one_arch_recyclerView:I = 0x7f0a1a3c

.field public static final one_arch_recyclerView_container:I = 0x7f0a1a3d

.field public static final one_arch_refresh_layout:I = 0x7f0a1a3e

.field public static final onearch_lazy_load_fragment:I = 0x7f0a1a40

.field public static final online_card_title:I = 0x7f0a1a41

.field public static final online_card_title_layout:I = 0x7f0a1a42

.field public static final online_prolist_recycler:I = 0x7f0a1a43

.field public static final online_tag_layout:I = 0x7f0a1a44

.field public static final online_tag_view_name:I = 0x7f0a1a45

.field public static final online_title:I = 0x7f0a1a46

.field public static final online_title_layout:I = 0x7f0a1a47

.field public static final onlive_date:I = 0x7f0a1a48

.field public static final onlive_date_layout:I = 0x7f0a1a49

.field public static final open_card:I = 0x7f0a1a4b

.field public static final open_card_container:I = 0x7f0a1a4c

.field public static final open_mcard_desc:I = 0x7f0a1a4d

.field public static final open_mcard_title:I = 0x7f0a1a4e

.field public static final openday:I = 0x7f0a1a4f

.field public static final order_address_indicator_iv:I = 0x7f0a1a52

.field public static final order_bottom_panel:I = 0x7f0a1a56

.field public static final order_bottom_panel_btn_sub:I = 0x7f0a1a57

.field public static final order_bottom_panel_btn_title:I = 0x7f0a1a58

.field public static final order_bottom_panel_detail_info_zone:I = 0x7f0a1a59

.field public static final order_bottom_panel_left:I = 0x7f0a1a5a

.field public static final order_bottom_panel_left_arrow:I = 0x7f0a1a5b

.field public static final order_bottom_panel_left_price:I = 0x7f0a1a5c

.field public static final order_bottom_panel_left_price_yuan:I = 0x7f0a1a5d

.field public static final order_bottom_panel_left_subtitle:I = 0x7f0a1a5e

.field public static final order_bottom_panel_left_title:I = 0x7f0a1a5f

.field public static final order_bottom_panel_price_tip:I = 0x7f0a1a60

.field public static final order_bottom_panel_right:I = 0x7f0a1a61

.field public static final order_bottom_panel_up_title:I = 0x7f0a1a62

.field public static final order_buy_amount_counter:I = 0x7f0a1a63

.field public static final order_buy_amount_counter_minus:I = 0x7f0a1a64

.field public static final order_buy_amount_counter_plus:I = 0x7f0a1a65

.field public static final order_buy_amount_counter_text:I = 0x7f0a1a66

.field public static final order_buy_amount_limit_desc:I = 0x7f0a1a67

.field public static final order_buy_amount_price_block:I = 0x7f0a1a68

.field public static final order_buy_amount_title:I = 0x7f0a1a69

.field public static final order_buy_amount_total_price:I = 0x7f0a1a6a

.field public static final order_citypass_open_desc:I = 0x7f0a1a75

.field public static final order_citypass_open_price_desc:I = 0x7f0a1a76

.field public static final order_citypass_open_price_tip:I = 0x7f0a1a77

.field public static final order_citypass_open_title:I = 0x7f0a1a78

.field public static final order_coupon_detail:I = 0x7f0a1a79

.field public static final order_coupon_view:I = 0x7f0a1a7a

.field public static final order_create_contact_list_last_view_margin:I = 0x7f0a1a7b

.field public static final order_create_contacts_name:I = 0x7f0a1a7c

.field public static final order_create_contacts_name_layout:I = 0x7f0a1a7d

.field public static final order_create_contacts_name_select_image:I = 0x7f0a1a7e

.field public static final order_detail_address_tv:I = 0x7f0a1a7f

.field public static final order_detail_bottom:I = 0x7f0a1a80

.field public static final order_detail_pop:I = 0x7f0a1a81

.field public static final order_film_festival:I = 0x7f0a1a8a

.field public static final order_header_bottom_container:I = 0x7f0a1a8e

.field public static final order_header_container:I = 0x7f0a1a8f

.field public static final order_header_down_container:I = 0x7f0a1a93

.field public static final order_header_info1:I = 0x7f0a1a94

.field public static final order_header_info2:I = 0x7f0a1a95

.field public static final order_header_info3:I = 0x7f0a1a96

.field public static final order_header_info_address:I = 0x7f0a1a97

.field public static final order_header_info_container:I = 0x7f0a1a98

.field public static final order_header_info_hall:I = 0x7f0a1a99

.field public static final order_header_info_seat:I = 0x7f0a1a9a

.field public static final order_header_info_time:I = 0x7f0a1a9b

.field public static final order_header_name:I = 0x7f0a1a9d

.field public static final order_header_piao:I = 0x7f0a1a9e

.field public static final order_header_special:I = 0x7f0a1aa2

.field public static final order_header_time_count:I = 0x7f0a1aa6

.field public static final order_header_up_container:I = 0x7f0a1aa8

.field public static final order_mcard_open_desc:I = 0x7f0a1aab

.field public static final order_mcard_open_origin_price_tip:I = 0x7f0a1aac

.field public static final order_mcard_open_price_tip:I = 0x7f0a1aad

.field public static final order_mcard_open_switch_zone:I = 0x7f0a1aae

.field public static final order_mcard_open_title:I = 0x7f0a1aaf

.field public static final order_movie_festival:I = 0x7f0a1ab0

.field public static final order_name_tv:I = 0x7f0a1ab1

.field public static final order_ordering_common_sale_amount:I = 0x7f0a1ab7

.field public static final order_ordering_common_sale_btn:I = 0x7f0a1ab8

.field public static final order_phone_tv:I = 0x7f0a1ab9

.field public static final order_refund_tag_new:I = 0x7f0a1abb

.field public static final order_render_bottom:I = 0x7f0a1abc

.field public static final order_result_dialog_top_msg:I = 0x7f0a1abe

.field public static final order_result_festival_item_btn:I = 0x7f0a1abf

.field public static final order_result_festival_item_poster:I = 0x7f0a1ac0

.field public static final order_result_festival_item_subtitle:I = 0x7f0a1ac1

.field public static final order_result_festival_item_title:I = 0x7f0a1ac2

.field public static final order_result_happy_coin_contain:I = 0x7f0a1ac3

.field public static final order_result_happy_coin_contain_desc:I = 0x7f0a1ac4

.field public static final order_result_happy_coin_contain_subtitle:I = 0x7f0a1ac5

.field public static final order_result_happy_coin_contain_title:I = 0x7f0a1ac6

.field public static final order_result_happy_coin_contain_unit:I = 0x7f0a1ac7

.field public static final order_result_happy_coin_wheel_contain:I = 0x7f0a1ac8

.field public static final order_result_popwindow_down_arrow:I = 0x7f0a1ac9

.field public static final order_result_popwindow_msg:I = 0x7f0a1aca

.field public static final order_result_popwindow_up_arrow:I = 0x7f0a1acb

.field public static final order_result_received_happy_coin_tip:I = 0x7f0a1acc

.field public static final order_result_tip_container:I = 0x7f0a1acd

.field public static final order_sale_item_bought:I = 0x7f0a1ace

.field public static final order_sale_item_detail:I = 0x7f0a1acf

.field public static final order_sale_item_gift_container:I = 0x7f0a1ad0

.field public static final order_sale_item_gift_value:I = 0x7f0a1ad1

.field public static final order_sale_item_image:I = 0x7f0a1ad2

.field public static final order_sale_item_image_buy:I = 0x7f0a1ad3

.field public static final order_sale_item_image_container:I = 0x7f0a1ad4

.field public static final order_sale_item_image_hot:I = 0x7f0a1ad5

.field public static final order_sale_item_image_new:I = 0x7f0a1ad6

.field public static final order_sale_item_mcard_price:I = 0x7f0a1ad7

.field public static final order_sale_item_person_tag:I = 0x7f0a1ad8

.field public static final order_sale_item_price:I = 0x7f0a1ad9

.field public static final order_sale_item_price_desc:I = 0x7f0a1ada

.field public static final order_sale_item_price_old:I = 0x7f0a1adb

.field public static final order_sale_item_select_view:I = 0x7f0a1adc

.field public static final order_sale_price:I = 0x7f0a1add

.field public static final order_state_layout:I = 0x7f0a1ade

.field public static final order_success_benefit_btn:I = 0x7f0a1adf

.field public static final order_success_benefit_btn_arrow:I = 0x7f0a1ae0

.field public static final order_success_benefit_subtitle:I = 0x7f0a1ae1

.field public static final order_success_benefit_title:I = 0x7f0a1ae2

.field public static final order_success_vip_benefit_container:I = 0x7f0a1ae3

.field public static final order_success_vip_benefit_item_btn:I = 0x7f0a1ae4

.field public static final order_success_vip_benefit_item_container:I = 0x7f0a1ae5

.field public static final order_success_vip_benefit_item_pic:I = 0x7f0a1ae6

.field public static final order_success_vip_benefit_item_title:I = 0x7f0a1ae7

.field public static final order_success_vip_benefit_title_container:I = 0x7f0a1ae8

.field public static final order_success_vip_bg:I = 0x7f0a1ae9

.field public static final order_success_vip_bg_title:I = 0x7f0a1aea

.field public static final order_success_vip_coin_btn:I = 0x7f0a1aeb

.field public static final order_success_vip_coin_icon:I = 0x7f0a1aec

.field public static final order_success_vip_coin_num:I = 0x7f0a1aed

.field public static final order_success_vip_divider:I = 0x7f0a1aee

.field public static final order_success_vip_subtitle:I = 0x7f0a1aef

.field public static final order_success_vip_title:I = 0x7f0a1af0

.field public static final order_time_icon:I = 0x7f0a1af1

.field public static final order_time_text_view:I = 0x7f0a1af2

.field public static final order_time_text_view2:I = 0x7f0a1af3

.field public static final order_title_container:I = 0x7f0a1af4

.field public static final ordering_coupon_reduce_countdown_timer:I = 0x7f0a1af5

.field public static final ordering_early_brid_item_view:I = 0x7f0a1af6

.field public static final ordering_item_header_cancel:I = 0x7f0a1af7

.field public static final ordering_item_header_confirm:I = 0x7f0a1af8

.field public static final ordering_item_header_desc:I = 0x7f0a1af9

.field public static final ordering_item_header_title:I = 0x7f0a1afa

.field public static final ordering_more_good_tip:I = 0x7f0a1afb

.field public static final ordering_new_notice_btn_arrow:I = 0x7f0a1afc

.field public static final ordering_phone:I = 0x7f0a1afd

.field public static final ordering_phone_desc:I = 0x7f0a1afe

.field public static final ordering_pop_member_reduce_item_check:I = 0x7f0a1aff

.field public static final ordering_pop_member_reduce_item_des_container:I = 0x7f0a1b00

.field public static final ordering_pop_member_reduce_item_icon:I = 0x7f0a1b01

.field public static final ordering_pop_member_reduce_item_title:I = 0x7f0a1b02

.field public static final ordering_popupwindow_header:I = 0x7f0a1b03

.field public static final ordering_sale_title_all:I = 0x7f0a1b04

.field public static final ordering_sale_title_all_arrow:I = 0x7f0a1b05

.field public static final ordering_selector_block_oriprice_title:I = 0x7f0a1b06

.field public static final ordering_selector_block_presalecode_title:I = 0x7f0a1b07

.field public static final ordering_selector_item_check:I = 0x7f0a1b08

.field public static final ordering_selector_item_desc:I = 0x7f0a1b09

.field public static final ordering_selector_item_dummy:I = 0x7f0a1b0a

.field public static final ordering_selector_item_limitdesc:I = 0x7f0a1b0b

.field public static final ordering_selector_item_sub_desc:I = 0x7f0a1b0c

.field public static final ordering_selector_item_sub_desc_disable:I = 0x7f0a1b0d

.field public static final ordering_selector_item_title:I = 0x7f0a1b0e

.field public static final ordering_selector_recyclerview:I = 0x7f0a1b0f

.field public static final ordering_vip_bogo_item_view:I = 0x7f0a1b10

.field public static final ordering_vip_coupon_amount:I = 0x7f0a1b11

.field public static final ordering_vip_coupon_countdown_timer:I = 0x7f0a1b12

.field public static final ordering_vip_coupon_title:I = 0x7f0a1b13

.field public static final ordering_vip_price_item_view:I = 0x7f0a1b14

.field public static final ordering_vip_reduce_des:I = 0x7f0a1b15

.field public static final ordering_vip_reduce_title:I = 0x7f0a1b16

.field public static final ordering_vip_subtitle:I = 0x7f0a1b17

.field public static final origin:I = 0x7f0a1b19

.field public static final origin_price:I = 0x7f0a1b1a

.field public static final original_integral:I = 0x7f0a1b1b

.field public static final oscar_cinema_detail_item_evaluate_allpeoplenum:I = 0x7f0a1b1c

.field public static final oscar_cinema_detail_item_evaluate_body:I = 0x7f0a1b1d

.field public static final oscar_cinema_detail_item_evaluate_body_left:I = 0x7f0a1b1e

.field public static final oscar_cinema_detail_item_evaluate_no_score_msg:I = 0x7f0a1b1f

.field public static final oscar_cinema_detail_item_evaluate_no_score_title:I = 0x7f0a1b20

.field public static final oscar_cinema_detail_item_evaluate_overallratio:I = 0x7f0a1b21

.field public static final oscar_cinema_detail_item_evaluate_overallratio_percet:I = 0x7f0a1b22

.field public static final oscar_cinema_detail_item_evaluate_right:I = 0x7f0a1b23

.field public static final oscar_cinema_detail_item_evaluate_right_inneritem_progress:I = 0x7f0a1b24

.field public static final oscar_cinema_detail_item_evaluate_right_inneritem_ratio:I = 0x7f0a1b25

.field public static final oscar_cinema_detail_item_evaluate_right_inneritem_title:I = 0x7f0a1b26

.field public static final oscar_cinema_list_map:I = 0x7f0a1b27

.field public static final oscar_cinema_list_map_control:I = 0x7f0a1b28

.field public static final oscar_cinema_list_map_info:I = 0x7f0a1b29

.field public static final oscar_cinema_list_map_large:I = 0x7f0a1b2a

.field public static final oscar_cinema_list_map_locate:I = 0x7f0a1b2b

.field public static final oscar_cinema_list_map_small:I = 0x7f0a1b2c

.field public static final oscar_cinema_list_marker_address:I = 0x7f0a1b2d

.field public static final oscar_cinema_list_marker_name:I = 0x7f0a1b2e

.field public static final oscar_cinema_list_marker_navigation:I = 0x7f0a1b2f

.field public static final oscar_cinema_search_background:I = 0x7f0a1b30

.field public static final oscar_cinema_search_key_check:I = 0x7f0a1b31

.field public static final oscar_cinema_search_key_item:I = 0x7f0a1b32

.field public static final oscar_cinema_search_key_num:I = 0x7f0a1b33

.field public static final oscar_cinema_search_no_result:I = 0x7f0a1b34

.field public static final oscar_cinema_search_result_list:I = 0x7f0a1b35

.field public static final oscar_cinemalist_child_root_view:I = 0x7f0a1b36

.field public static final oscar_cinemalist_cinema_action:I = 0x7f0a1b37

.field public static final oscar_cinemalist_cinema_address:I = 0x7f0a1b38

.field public static final oscar_cinemalist_cinema_distance:I = 0x7f0a1b39

.field public static final oscar_cinemalist_cinema_name:I = 0x7f0a1b3a

.field public static final oscar_cinemalist_cinema_schedules:I = 0x7f0a1b3b

.field public static final oscar_cinemalist_cinema_schedules_container:I = 0x7f0a1b3c

.field public static final oscar_cinemalist_cinema_schedules_intro:I = 0x7f0a1b3d

.field public static final oscar_cinemalist_cinema_status:I = 0x7f0a1b3e

.field public static final oscar_cinemalist_content_card_view:I = 0x7f0a1b3f

.field public static final oscar_cinemas_address_tag_divider:I = 0x7f0a1b40

.field public static final oscar_cinemas_score_tag_divider:I = 0x7f0a1b41

.field public static final oscar_cinemas_score_tag_prefix:I = 0x7f0a1b42

.field public static final oscar_cinemas_score_tag_score:I = 0x7f0a1b43

.field public static final oscar_cinenalist_cinema_mem_card_buy:I = 0x7f0a1b44

.field public static final oscar_cinenalist_cinema_mem_card_group:I = 0x7f0a1b45

.field public static final oscar_cinenalist_cinema_newcomer:I = 0x7f0a1b46

.field public static final oscar_cinenalist_cinema_no_score:I = 0x7f0a1b47

.field public static final oscar_cinenalist_cinema_oriprice:I = 0x7f0a1b48

.field public static final oscar_cinenalist_cinema_price:I = 0x7f0a1b49

.field public static final oscar_cinenalist_cinema_price_stuff:I = 0x7f0a1b4a

.field public static final oscar_cinenalist_cinema_price_yuan:I = 0x7f0a1b4b

.field public static final oscar_cinenalist_cinema_tag_block:I = 0x7f0a1b4c

.field public static final oscar_cinenalist_cinema_vip_price:I = 0x7f0a1b4d

.field public static final oscar_common_comment_container:I = 0x7f0a1b4e

.field public static final oscar_common_comment_content:I = 0x7f0a1b4f

.field public static final oscar_edit_phone:I = 0x7f0a1b50

.field public static final oscar_edit_phone_done:I = 0x7f0a1b51

.field public static final oscar_edit_phone_open_contract:I = 0x7f0a1b52

.field public static final oscar_schedule_list_promotion_cash:I = 0x7f0a1b53

.field public static final oscar_schedule_list_special_card:I = 0x7f0a1b54

.field public static final oscar_schedule_list_zero_schedule:I = 0x7f0a1b55

.field public static final oscar_schedule_sale_btn:I = 0x7f0a1b56

.field public static final oscar_schedule_sale_divider:I = 0x7f0a1b57

.field public static final oscar_schedule_sale_start_date:I = 0x7f0a1b58

.field public static final oscar_schedule_sale_start_time:I = 0x7f0a1b59

.field public static final oscar_schedule_start_container:I = 0x7f0a1b5a

.field public static final other:I = 0x7f0a1b5b

.field public static final other_btn:I = 0x7f0a1b5c

.field public static final other_months:I = 0x7f0a1b5d

.field public static final out_of_range:I = 0x7f0a1b5e

.field public static final outline:I = 0x7f0a1b5f

.field public static final outside:I = 0x7f0a1b60

.field public static final outward:I = 0x7f0a1b61

.field public static final oval:I = 0x7f0a1b62

.field public static final overlay_home_movie_trailer_first_item:I = 0x7f0a1b65

.field public static final overlay_home_movie_trailer_item:I = 0x7f0a1b66

.field public static final overlay_home_movie_trailer_second_item:I = 0x7f0a1b67

.field public static final overlay_home_movie_trailer_third_item:I = 0x7f0a1b68

.field public static final oversea_bind_btn:I = 0x7f0a1b6c

.field public static final oversea_change_account_login_btn:I = 0x7f0a1b6d

.field public static final overshoot:I = 0x7f0a1b6e

.field public static final packed:I = 0x7f0a1b71

.field public static final padding_View:I = 0x7f0a1b72

.field public static final page:I = 0x7f0a1b73

.field public static final page_container:I = 0x7f0a1b74

.field public static final pager_header:I = 0x7f0a1b7a

.field public static final pager_preview_videos:I = 0x7f0a1b7b

.field public static final pager_schedule:I = 0x7f0a1b7c

.field public static final parallax:I = 0x7f0a1b7f

.field public static final parent:I = 0x7f0a1b80

.field public static final parentPanel:I = 0x7f0a1b81

.field public static final parentRelative:I = 0x7f0a1b82

.field public static final parent_matrix:I = 0x7f0a1b83

.field public static final passkey_des:I = 0x7f0a1b84

.field public static final passkey_header_img:I = 0x7f0a1b85

.field public static final passkey_header_ll:I = 0x7f0a1b86

.field public static final passkey_header_mobile:I = 0x7f0a1b87

.field public static final passport_button_area:I = 0x7f0a1b8a

.field public static final passport_button_cancel:I = 0x7f0a1b8b

.field public static final passport_button_ok:I = 0x7f0a1b8c

.field public static final passport_button_split_line:I = 0x7f0a1b8d

.field public static final passport_dialog_divider:I = 0x7f0a1b8e

.field public static final passport_dialog_icon:I = 0x7f0a1b8f

.field public static final passport_dialog_message:I = 0x7f0a1b90

.field public static final passport_ott_mask:I = 0x7f0a1b91

.field public static final passport_ott_op_icon:I = 0x7f0a1b92

.field public static final passport_ott_op_text:I = 0x7f0a1b93

.field public static final passport_ott_qr_code:I = 0x7f0a1b94

.field public static final password_toggle:I = 0x7f0a1b95

.field public static final path:I = 0x7f0a1b96

.field public static final pathRelative:I = 0x7f0a1b97

.field public static final pay_done_icon:I = 0x7f0a1b9a

.field public static final pay_option_list_panel:I = 0x7f0a1b9b

.field public static final pay_status_desc:I = 0x7f0a1bb7

.field public static final pay_tag:I = 0x7f0a1bb8

.field public static final pay_zone:I = 0x7f0a1bb9

.field public static final pb1:I = 0x7f0a1bbd

.field public static final pb_loading_item:I = 0x7f0a1bbe

.field public static final pb_progress:I = 0x7f0a1bc0

.field public static final percent:I = 0x7f0a1bc2

.field public static final perform_bottom_button:I = 0x7f0a1bc4

.field public static final perform_bottom_firstbutton:I = 0x7f0a1bc5

.field public static final perform_bottom_secondbutton:I = 0x7f0a1bc6

.field public static final perform_btn:I = 0x7f0a1bc7

.field public static final perform_date_calendar:I = 0x7f0a1bc8

.field public static final perform_des:I = 0x7f0a1bc9

.field public static final perform_seat_tip_tv:I = 0x7f0a1bcb

.field public static final perform_textView:I = 0x7f0a1bcc

.field public static final perform_textView_layout:I = 0x7f0a1bcd

.field public static final performance:I = 0x7f0a1bd0

.field public static final performance_content:I = 0x7f0a1bd1

.field public static final performance_count:I = 0x7f0a1bd2

.field public static final permission_container:I = 0x7f0a1bdd

.field public static final permission_top_layout:I = 0x7f0a1bde

.field public static final pha_fragment_host:I = 0x7f0a1be1

.field public static final phone_container:I = 0x7f0a1be2

.field public static final phone_hint:I = 0x7f0a1be3

.field public static final pic:I = 0x7f0a1be6

.field public static final pic1:I = 0x7f0a1be7

.field public static final pic2:I = 0x7f0a1be8

.field public static final pic3:I = 0x7f0a1be9

.field public static final pic_kit_dialog_bottom_action_block:I = 0x7f0a1bea

.field public static final pic_kit_dialog_btn_divider:I = 0x7f0a1beb

.field public static final pic_kit_dialog_btn_first:I = 0x7f0a1bec

.field public static final pic_kit_dialog_btn_second:I = 0x7f0a1bed

.field public static final pic_kit_dialog_container:I = 0x7f0a1bee

.field public static final pic_kit_dialog_content_body_block:I = 0x7f0a1bef

.field public static final pic_kit_dialog_content_layout:I = 0x7f0a1bf0

.field public static final pic_kit_dialog_content_tips:I = 0x7f0a1bf1

.field public static final pic_kit_dialog_root_layout:I = 0x7f0a1bf2

.field public static final pic_kit_dialog_subtitle:I = 0x7f0a1bf3

.field public static final pic_kit_dialog_title:I = 0x7f0a1bf4

.field public static final pic_kit_top_img:I = 0x7f0a1bf5

.field public static final pic_kit_top_img_bg:I = 0x7f0a1bf6

.field public static final pic_kit_top_img_container:I = 0x7f0a1bf7

.field public static final pic_layout_root:I = 0x7f0a1bf8

.field public static final pic_poster:I = 0x7f0a1bf9

.field public static final pic_promotion_discount_excel_desc:I = 0x7f0a1bfa

.field public static final pic_promotion_discount_excel_desc_action:I = 0x7f0a1bfb

.field public static final pic_promotion_discount_excel_desc_action_arrow:I = 0x7f0a1bfc

.field public static final pic_promotion_discount_excel_desc_block:I = 0x7f0a1bfd

.field public static final pic_promotion_discount_excel_desc_sub:I = 0x7f0a1bfe

.field public static final pic_promotion_discount_excel_item_layout:I = 0x7f0a1bff

.field public static final pic_promotion_discount_excel_tag:I = 0x7f0a1c00

.field public static final pic_promotion_discount_info_mark:I = 0x7f0a1c01

.field public static final pic_promotion_discount_info_mark_block:I = 0x7f0a1c02

.field public static final pic_promotion_discount_info_mark_icon:I = 0x7f0a1c03

.field public static final pick_photo_text:I = 0x7f0a1c05

.field public static final piclist_view:I = 0x7f0a1c08

.field public static final picture:I = 0x7f0a1c09

.field public static final pictureviewpage_rightbottom_des:I = 0x7f0a1c0c

.field public static final pin:I = 0x7f0a1c0d

.field public static final pioneer_feed_bottom_layout:I = 0x7f0a1c12

.field public static final pioneer_feed_card_price_delete:I = 0x7f0a1c15

.field public static final pioneer_feed_card_price_layout:I = 0x7f0a1c17

.field public static final pioneer_feed_card_price_num:I = 0x7f0a1c18

.field public static final pioneer_feed_card_price_symbol:I = 0x7f0a1c19

.field public static final pioneer_feed_card_price_unit:I = 0x7f0a1c1a

.field public static final pioneer_feed_card_s1_title:I = 0x7f0a1c1d

.field public static final pioneer_feed_card_sellcount:I = 0x7f0a1c1e

.field public static final pioneer_feed_img:I = 0x7f0a1c24

.field public static final pioneer_feed_ipstore_entrance_img:I = 0x7f0a1c25

.field public static final pioneer_feed_ipstore_entrance_tv:I = 0x7f0a1c26

.field public static final pioneer_home_grab_block_mix_block:I = 0x7f0a1c50

.field public static final pioneer_home_grab_block_subtitle:I = 0x7f0a1c51

.field public static final pioneer_home_grab_block_subtitle_divider:I = 0x7f0a1c52

.field public static final pioneer_home_grab_block_subtitle_want_score:I = 0x7f0a1c53

.field public static final pioneer_home_grab_block_title:I = 0x7f0a1c54

.field public static final pioneer_homepage_grab_countdown_view:I = 0x7f0a1c5c

.field public static final pioneer_homepage_grab_hot_title_grab_img:I = 0x7f0a1c5d

.field public static final pioneer_homepage_grab_hot_title_grab_img_degree:I = 0x7f0a1c5e

.field public static final pioneer_homepage_project_item_mask:I = 0x7f0a1c6b

.field public static final pioneer_item_tag_view_container:I = 0x7f0a1c74

.field public static final pioneer_iv_more_images:I = 0x7f0a1c78

.field public static final pioneer_live_ipstore_item_card:I = 0x7f0a1c8b

.field public static final pioneer_loading_item:I = 0x7f0a1c8d

.field public static final pioneer_mask_image:I = 0x7f0a1c8f

.field public static final pioneer_search_icon:I = 0x7f0a1cb1

.field public static final pioneer_search_icon_container:I = 0x7f0a1cb2

.field public static final pioneer_search_icon_text:I = 0x7f0a1cb3

.field public static final pioneer_search_tab_select_indicator:I = 0x7f0a1cb4

.field public static final pioneer_search_tab_text:I = 0x7f0a1cb5

.field public static final pioneer_search_v2_history_clear:I = 0x7f0a1cb6

.field public static final pioneer_tag:I = 0x7f0a1cc3

.field public static final pioneer_tag_tpp:I = 0x7f0a1cc4

.field public static final pioneer_tv_homepage_show_more_title:I = 0x7f0a1ccd

.field public static final placeholder_layout:I = 0x7f0a1cd9

.field public static final play:I = 0x7f0a1cda

.field public static final play_arrow:I = 0x7f0a1cdb

.field public static final play_date:I = 0x7f0a1cdc

.field public static final play_date_time_version:I = 0x7f0a1cdd

.field public static final play_tag:I = 0x7f0a1cde

.field public static final play_time:I = 0x7f0a1cdf

.field public static final player:I = 0x7f0a1ce0

.field public static final player_video_btn:I = 0x7f0a1ce2

.field public static final player_view_transition_play:I = 0x7f0a1ce3

.field public static final plus_state_txt:I = 0x7f0a1ce4

.field public static final pop_irc:I = 0x7f0a1ce7

.field public static final pop_irc_parent:I = 0x7f0a1ce8

.field public static final pop_mgr:I = 0x7f0a1ce9

.field public static final pop_tv:I = 0x7f0a1cea

.field public static final poplayer_augmentedview_record_tag_id:I = 0x7f0a1ceb

.field public static final poplayer_console_register_background_tag_id:I = 0x7f0a1cec

.field public static final poplayer_console_selector_touch_interceptor_id:I = 0x7f0a1ced

.field public static final poplayer_trigger_tracking_service_id:I = 0x7f0a1cee

.field public static final poplayer_view:I = 0x7f0a1cef

.field public static final poplayer_view_frame:I = 0x7f0a1cf0

.field public static final popu_star_pro_list:I = 0x7f0a1cf7

.field public static final popup_content_view_wrap:I = 0x7f0a1cf8

.field public static final popup_layout:I = 0x7f0a1cfa

.field public static final port_view:I = 0x7f0a1cfb

.field public static final position:I = 0x7f0a1cfc

.field public static final postLayout:I = 0x7f0a1cfd

.field public static final post_lay:I = 0x7f0a1cfe

.field public static final poster:I = 0x7f0a1cff

.field public static final poster_card_container:I = 0x7f0a1d00

.field public static final poster_container:I = 0x7f0a1d01

.field public static final poster_rank:I = 0x7f0a1d04

.field public static final poster_v2:I = 0x7f0a1d06

.field public static final poster_zone:I = 0x7f0a1d08

.field public static final praise_item_anim:I = 0x7f0a1d09

.field public static final praise_item_iconimg:I = 0x7f0a1d0a

.field public static final praise_item_text:I = 0x7f0a1d0b

.field public static final pre_schedule_tag_view:I = 0x7f0a1d0c

.field public static final preform_scrollview:I = 0x7f0a1d0d

.field public static final presale_activity_tag:I = 0x7f0a1d0e

.field public static final presale_tips:I = 0x7f0a1d0f

.field public static final preschedule:I = 0x7f0a1d10

.field public static final preschedule_or_buyer:I = 0x7f0a1d11

.field public static final preschedule_outofdate:I = 0x7f0a1d12

.field public static final preview:I = 0x7f0a1d14

.field public static final price:I = 0x7f0a1d15

.field public static final price_after:I = 0x7f0a1d16

.field public static final price_bg:I = 0x7f0a1d17

.field public static final price_container:I = 0x7f0a1d18

.field public static final price_container_view:I = 0x7f0a1d19

.field public static final price_icon:I = 0x7f0a1d1a

.field public static final price_lay:I = 0x7f0a1d1c

.field public static final price_layout:I = 0x7f0a1d1d

.field public static final price_pending:I = 0x7f0a1d20

.field public static final price_prefix:I = 0x7f0a1d21

.field public static final price_suffix:I = 0x7f0a1d24

.field public static final price_txt:I = 0x7f0a1d29

.field public static final price_ui:I = 0x7f0a1d2a

.field public static final price_unit:I = 0x7f0a1d2b

.field public static final price_view:I = 0x7f0a1d2c

.field public static final price_zone:I = 0x7f0a1d2d

.field public static final privileged_audience_already_set_layout:I = 0x7f0a1d30

.field public static final privileged_audience_not_set_layout:I = 0x7f0a1d31

.field public static final privileged_audience_selected_name:I = 0x7f0a1d32

.field public static final privileged_audience_selected_total_number:I = 0x7f0a1d33

.field public static final privileges_arrow:I = 0x7f0a1d34

.field public static final privileges_line:I = 0x7f0a1d35

.field public static final privileges_more_txt:I = 0x7f0a1d36

.field public static final privileges_recycle:I = 0x7f0a1d37

.field public static final privileges_txt:I = 0x7f0a1d38

.field public static final prize_action:I = 0x7f0a1d39

.field public static final prize_name:I = 0x7f0a1d3a

.field public static final prize_num:I = 0x7f0a1d3b

.field public static final prize_num_zone:I = 0x7f0a1d3c

.field public static final prize_unit:I = 0x7f0a1d3d

.field public static final pro_inner_layout:I = 0x7f0a1d3f

.field public static final problem_name_tv:I = 0x7f0a1d40

.field public static final process_img:I = 0x7f0a1d41

.field public static final produce_cell_img:I = 0x7f0a1d42

.field public static final produce_cell_name:I = 0x7f0a1d43

.field public static final produce_cell_title:I = 0x7f0a1d44

.field public static final product_name:I = 0x7f0a1d45

.field public static final product_price:I = 0x7f0a1d46

.field public static final product_tag:I = 0x7f0a1d47

.field public static final profile_header_icon:I = 0x7f0a1d48

.field public static final profile_item_right_arrow:I = 0x7f0a1d49

.field public static final profile_title:I = 0x7f0a1d4a

.field public static final progress:I = 0x7f0a1d4b

.field public static final progress1:I = 0x7f0a1d4c

.field public static final progress2:I = 0x7f0a1d4d

.field public static final progress3:I = 0x7f0a1d4e

.field public static final progress4:I = 0x7f0a1d4f

.field public static final progress5:I = 0x7f0a1d50

.field public static final progressBar:I = 0x7f0a1d51

.field public static final progress_bar:I = 0x7f0a1d52

.field public static final progress_circular:I = 0x7f0a1d53

.field public static final progress_dialog_layout_root:I = 0x7f0a1d54

.field public static final progress_horizontal:I = 0x7f0a1d55

.field public static final progress_large:I = 0x7f0a1d56

.field public static final progress_loading:I = 0x7f0a1d58

.field public static final progress_loading_view:I = 0x7f0a1d59

.field public static final progress_page:I = 0x7f0a1d5a

.field public static final progress_view:I = 0x7f0a1d5b

.field public static final progressbar:I = 0x7f0a1d5c

.field public static final project_activity_hor_des:I = 0x7f0a1d5e

.field public static final project_activity_hor_tag:I = 0x7f0a1d5f

.field public static final project_activity_item:I = 0x7f0a1d60

.field public static final project_bottom_customer_follow_container_lv:I = 0x7f0a1d84

.field public static final project_bottom_lay:I = 0x7f0a1d86

.field public static final project_broadcast_recycler:I = 0x7f0a1d9a

.field public static final project_buynow_price:I = 0x7f0a1d9c

.field public static final project_calendar_view:I = 0x7f0a1d9d

.field public static final project_container:I = 0x7f0a1d9f

.field public static final project_detail_perform_date_layout:I = 0x7f0a1dae

.field public static final project_detail_perform_flowlayout:I = 0x7f0a1db0

.field public static final project_detail_perform_price_flowlayout:I = 0x7f0a1db1

.field public static final project_detail_perform_price_layout:I = 0x7f0a1db2

.field public static final project_detail_perform_price_text:I = 0x7f0a1db3

.field public static final project_detail_perform_ticket_layout:I = 0x7f0a1db4

.field public static final project_detail_perform_time_flowlayout:I = 0x7f0a1db5

.field public static final project_detail_perform_time_layout:I = 0x7f0a1db6

.field public static final project_detail_title_bar_divider:I = 0x7f0a1dbd

.field public static final project_flash_sale_icon:I = 0x7f0a1dcd

.field public static final project_image:I = 0x7f0a1dd4

.field public static final project_image_container:I = 0x7f0a1dd5

.field public static final project_index_id:I = 0x7f0a1dd6

.field public static final project_info:I = 0x7f0a1dd7

.field public static final project_item_image_browse_title_bar:I = 0x7f0a1df3

.field public static final project_item_image_info_rv:I = 0x7f0a1df4

.field public static final project_item_pop_notice_matter_irc:I = 0x7f0a1dfe

.field public static final project_perform_calendar_left_img:I = 0x7f0a1e1d

.field public static final project_perform_calendar_left_layout:I = 0x7f0a1e1e

.field public static final project_perform_calendar_right_img:I = 0x7f0a1e1f

.field public static final project_perform_calendar_right_layout:I = 0x7f0a1e20

.field public static final project_perform_calendar_topbar_text:I = 0x7f0a1e21

.field public static final project_service_conditional_refund:I = 0x7f0a1e3b

.field public static final project_service_item_tag_action:I = 0x7f0a1e3d

.field public static final project_service_item_tag_desc_other_tv:I = 0x7f0a1e3e

.field public static final project_service_item_tag_desc_tv:I = 0x7f0a1e3f

.field public static final project_service_item_tag_img:I = 0x7f0a1e40

.field public static final project_service_item_tag_ll:I = 0x7f0a1e41

.field public static final project_service_item_tag_name_tv:I = 0x7f0a1e42

.field public static final project_service_tag_lv:I = 0x7f0a1e43

.field public static final project_state_buy:I = 0x7f0a1e45

.field public static final project_state_count_down:I = 0x7f0a1e46

.field public static final project_state_count_down_day:I = 0x7f0a1e47

.field public static final project_state_count_down_day_tag:I = 0x7f0a1e48

.field public static final project_state_count_down_hour:I = 0x7f0a1e49

.field public static final project_state_count_down_minute:I = 0x7f0a1e4a

.field public static final project_state_count_down_second:I = 0x7f0a1e4b

.field public static final project_state_none_ticket:I = 0x7f0a1e4c

.field public static final project_support_service_irc:I = 0x7f0a1e50

.field public static final project_support_service_item_action_desc:I = 0x7f0a1e51

.field public static final project_title:I = 0x7f0a1e5c

.field public static final project_top_lay:I = 0x7f0a1e63

.field public static final project_view:I = 0x7f0a1e65

.field public static final project_with_price_custom_ui:I = 0x7f0a1e6d

.field public static final project_with_price_pending:I = 0x7f0a1e6e

.field public static final project_with_price_promotion:I = 0x7f0a1e6f

.field public static final project_with_price_ui:I = 0x7f0a1e70

.field public static final promotion_activity:I = 0x7f0a1e74

.field public static final promotion_layout:I = 0x7f0a1e77

.field public static final protocol_content:I = 0x7f0a1e85

.field public static final protocol_text:I = 0x7f0a1e86

.field public static final protocol_title:I = 0x7f0a1e87

.field public static final protocol_zone:I = 0x7f0a1e88

.field public static final ptr_classic_header_rotate_view:I = 0x7f0a1e89

.field public static final ptr_classic_header_rotate_view_header_last_update:I = 0x7f0a1e8a

.field public static final ptr_classic_header_rotate_view_header_text:I = 0x7f0a1e8b

.field public static final ptr_classic_header_rotate_view_header_title:I = 0x7f0a1e8c

.field public static final ptr_classic_header_rotate_view_progressbar:I = 0x7f0a1e8d

.field public static final ptr_content:I = 0x7f0a1e8e

.field public static final ptr_progress:I = 0x7f0a1e8f

.field public static final ptr_text:I = 0x7f0a1e90

.field public static final pull:I = 0x7f0a1ea7

.field public static final pullDownFromTop:I = 0x7f0a1ea8

.field public static final pullFromEnd:I = 0x7f0a1ea9

.field public static final pullFromStart:I = 0x7f0a1eaa

.field public static final pullUpFromBottom:I = 0x7f0a1eab

.field public static final pull_animation:I = 0x7f0a1eac

.field public static final pull_bg:I = 0x7f0a1ead

.field public static final pull_down_headerview:I = 0x7f0a1eae

.field public static final pull_down_listview:I = 0x7f0a1eaf

.field public static final pull_down_view:I = 0x7f0a1eb0

.field public static final pull_recyclerview:I = 0x7f0a1eb1

.field public static final pull_refresh_layout:I = 0x7f0a1eb2

.field public static final pull_refresh_mask:I = 0x7f0a1eb3

.field public static final pull_to_refresh_anim_view:I = 0x7f0a1eb4

.field public static final pull_to_refresh_arrow_icon:I = 0x7f0a1eb5

.field public static final pull_to_refresh_arrow_loading_progress:I = 0x7f0a1eb6

.field public static final pull_to_refresh_default_view:I = 0x7f0a1eb7

.field public static final pull_to_refresh_image:I = 0x7f0a1eb8

.field public static final pull_to_refresh_progress:I = 0x7f0a1eb9

.field public static final pull_to_refresh_status_text:I = 0x7f0a1eba

.field public static final pull_to_refresh_sub_text:I = 0x7f0a1ebb

.field public static final pull_to_refresh_text:I = 0x7f0a1ebc

.field public static final pull_to_refresh_time:I = 0x7f0a1ebd

.field public static final pull_to_refresh_tips:I = 0x7f0a1ebe

.field public static final pull_to_refresh_view_layout:I = 0x7f0a1ebf

.field public static final pull_to_refresh_view_layout_with_tips:I = 0x7f0a1ec0

.field public static final pullrefresh_prompt:I = 0x7f0a1ec1

.field public static final push_bar_text:I = 0x7f0a1ec5

.field public static final push_bar_title:I = 0x7f0a1ec6

.field public static final push_big_bigtext_defaultView:I = 0x7f0a1ec7

.field public static final push_big_bigview_defaultView:I = 0x7f0a1ec8

.field public static final push_big_defaultView:I = 0x7f0a1ec9

.field public static final push_big_notification:I = 0x7f0a1eca

.field public static final push_big_notification_content:I = 0x7f0a1ecb

.field public static final push_big_notification_date:I = 0x7f0a1ecc

.field public static final push_big_notification_icon:I = 0x7f0a1ecd

.field public static final push_big_notification_icon2:I = 0x7f0a1ece

.field public static final push_big_notification_title:I = 0x7f0a1ecf

.field public static final push_big_pic_default_Content:I = 0x7f0a1ed0

.field public static final push_big_text_notification_area:I = 0x7f0a1ed1

.field public static final push_pure_bigview_banner:I = 0x7f0a1ed2

.field public static final push_pure_bigview_expanded:I = 0x7f0a1ed3

.field public static final push_pure_close:I = 0x7f0a1ed4

.field public static final px:I = 0x7f0a1ed5

.field public static final qr_bottom_bg:I = 0x7f0a1ed6

.field public static final qr_code:I = 0x7f0a1ed7

.field public static final qr_code_org:I = 0x7f0a1ed8

.field public static final qrcode_img:I = 0x7f0a1ed9

.field public static final qrcode_scan_frame_layout:I = 0x7f0a1eda

.field public static final qrcode_title:I = 0x7f0a1edb

.field public static final qrcode_title_bar:I = 0x7f0a1edc

.field public static final query_tip_card_container:I = 0x7f0a1edd

.field public static final query_tip_special_title:I = 0x7f0a1ede

.field public static final query_tip_title:I = 0x7f0a1edf

.field public static final quit:I = 0x7f0a1ee3

.field public static final quotation_icon:I = 0x7f0a1ee4

.field public static final radial:I = 0x7f0a1ee5

.field public static final radio:I = 0x7f0a1ee6

.field public static final radius_cover:I = 0x7f0a1ee7

.field public static final radius_fg:I = 0x7f0a1ee8

.field public static final range:I = 0x7f0a1ee9

.field public static final range_mode:I = 0x7f0a1eea

.field public static final rank_bar_rating:I = 0x7f0a1eeb

.field public static final rank_bg_img:I = 0x7f0a1eec

.field public static final rank_empty_des:I = 0x7f0a1ef0

.field public static final rank_icon:I = 0x7f0a1ef1

.field public static final rank_item_score:I = 0x7f0a1ef2

.field public static final rank_label:I = 0x7f0a1ef3

.field public static final rank_list_layout:I = 0x7f0a1ef6

.field public static final rank_select_recycler:I = 0x7f0a1ef9

.field public static final rank_tv:I = 0x7f0a1efa

.field public static final rank_user_extra:I = 0x7f0a1efb

.field public static final rank_user_icon:I = 0x7f0a1efc

.field public static final rank_user_mask:I = 0x7f0a1efd

.field public static final rank_user_me_tag:I = 0x7f0a1efe

.field public static final rank_user_name:I = 0x7f0a1eff

.field public static final rank_user_num:I = 0x7f0a1f00

.field public static final rank_value:I = 0x7f0a1f01

.field public static final rank_word_item_city:I = 0x7f0a1f02

.field public static final rank_word_item_city_layout:I = 0x7f0a1f03

.field public static final rank_word_item_container:I = 0x7f0a1f04

.field public static final rank_word_item_root_view:I = 0x7f0a1f05

.field public static final rank_word_item_title:I = 0x7f0a1f06

.field public static final rating_bar:I = 0x7f0a1f07

.field public static final rating_bar_anim:I = 0x7f0a1f08

.field public static final rating_container:I = 0x7f0a1f09

.field public static final ray_verify_code:I = 0x7f0a1f12

.field public static final rc:I = 0x7f0a1f13

.field public static final read_count:I = 0x7f0a1f15

.field public static final real_time_box_office:I = 0x7f0a1f18

.field public static final real_value:I = 0x7f0a1f19

.field public static final real_value_container:I = 0x7f0a1f1a

.field public static final realname_auth_back:I = 0x7f0a1f1b

.field public static final realname_auth_btn:I = 0x7f0a1f1c

.field public static final realname_auth_tips:I = 0x7f0a1f24

.field public static final realname_autherror_layout:I = 0x7f0a1f27

.field public static final realname_center_certnum_layout:I = 0x7f0a1f29

.field public static final realname_center_certype_layout:I = 0x7f0a1f2a

.field public static final realname_center_certype_line:I = 0x7f0a1f2b

.field public static final realname_center_real_layout:I = 0x7f0a1f2c

.field public static final realname_center_real_line:I = 0x7f0a1f2d

.field public static final realname_cernum:I = 0x7f0a1f2f

.field public static final realname_cernum_text:I = 0x7f0a1f30

.field public static final realname_certype:I = 0x7f0a1f31

.field public static final realname_choose_auther_layout:I = 0x7f0a1f33

.field public static final realname_clear_btn:I = 0x7f0a1f34

.field public static final realname_edit:I = 0x7f0a1f35

.field public static final realname_error_btn_lly:I = 0x7f0a1f36

.field public static final realname_error_img:I = 0x7f0a1f37

.field public static final realname_error_left_btn:I = 0x7f0a1f38

.field public static final realname_error_line:I = 0x7f0a1f39

.field public static final realname_error_msg:I = 0x7f0a1f3a

.field public static final realname_error_reason_content:I = 0x7f0a1f3b

.field public static final realname_error_reason_detail_btn:I = 0x7f0a1f3c

.field public static final realname_error_reason_lly:I = 0x7f0a1f3d

.field public static final realname_error_reason_title:I = 0x7f0a1f3e

.field public static final realname_error_right_btn:I = 0x7f0a1f3f

.field public static final realname_error_status:I = 0x7f0a1f40

.field public static final realname_right_icon:I = 0x7f0a1f43

.field public static final realname_tag:I = 0x7f0a1f46

.field public static final realname_title:I = 0x7f0a1f47

.field public static final realname_title_back:I = 0x7f0a1f48

.field public static final receive_88vip:I = 0x7f0a1f4c

.field public static final receive_88vip_loading:I = 0x7f0a1f4d

.field public static final receive_88vip_view:I = 0x7f0a1f4e

.field public static final recharge_btn:I = 0x7f0a1f4f

.field public static final recharge_btn_desc:I = 0x7f0a1f50

.field public static final recharge_ori_price:I = 0x7f0a1f51

.field public static final recharge_price:I = 0x7f0a1f52

.field public static final recharge_time:I = 0x7f0a1f53

.field public static final recharge_title:I = 0x7f0a1f54

.field public static final recommend_block:I = 0x7f0a1f56

.field public static final recommend_block_bg:I = 0x7f0a1f57

.field public static final recommend_block_cinema_address:I = 0x7f0a1f58

.field public static final recommend_block_cinema_distance:I = 0x7f0a1f59

.field public static final recommend_block_cinema_name:I = 0x7f0a1f5a

.field public static final recommend_block_cinema_price:I = 0x7f0a1f5b

.field public static final recommend_block_cinema_schedule_desc:I = 0x7f0a1f5c

.field public static final recommend_block_cinema_schedule_desc_icon:I = 0x7f0a1f5d

.field public static final recommend_block_cinema_schedules:I = 0x7f0a1f5e

.field public static final recommend_block_cinema_tag:I = 0x7f0a1f5f

.field public static final recommend_block_schedule_divider_line:I = 0x7f0a1f60

.field public static final recommend_block_title:I = 0x7f0a1f61

.field public static final recommend_container:I = 0x7f0a1f62

.field public static final recommend_container_view:I = 0x7f0a1f63

.field public static final recommend_desc:I = 0x7f0a1f64

.field public static final recommend_list_container:I = 0x7f0a1f6e

.field public static final recommend_num:I = 0x7f0a1f6f

.field public static final recommend_reason:I = 0x7f0a1f70

.field public static final recommend_reason_divider:I = 0x7f0a1f71

.field public static final recommend_reason_lay:I = 0x7f0a1f72

.field public static final recommend_refresh:I = 0x7f0a1f73

.field public static final recommend_spec_tag:I = 0x7f0a1f75

.field public static final recommend_success_view:I = 0x7f0a1f76

.field public static final recommend_title:I = 0x7f0a1f79

.field public static final recomment_tag:I = 0x7f0a1f7b

.field public static final recomment_tag_container:I = 0x7f0a1f7c

.field public static final record_btn:I = 0x7f0a1f7d

.field public static final rect:I = 0x7f0a1f7e

.field public static final rectangle:I = 0x7f0a1f7f

.field public static final rectangles:I = 0x7f0a1f80

.field public static final recyclerView:I = 0x7f0a1f83

.field public static final recyclerView_album:I = 0x7f0a1f84

.field public static final recycler_content:I = 0x7f0a1f85

.field public static final recycler_view:I = 0x7f0a1f87

.field public static final recyclerview:I = 0x7f0a1f88

.field public static final redPoint:I = 0x7f0a1f89

.field public static final redeem_help:I = 0x7f0a1f8a

.field public static final reduce_check:I = 0x7f0a1f8b

.field public static final reduce_contaier:I = 0x7f0a1f8c

.field public static final reduce_container:I = 0x7f0a1f8d

.field public static final reduce_desc:I = 0x7f0a1f8e

.field public static final reduce_dvd:I = 0x7f0a1f8f

.field public static final reduce_item_check:I = 0x7f0a1f90

.field public static final reduce_title:I = 0x7f0a1f91

.field public static final refound_info:I = 0x7f0a1f92

.field public static final refreshLayout:I = 0x7f0a1f93

.field public static final refresh_animation:I = 0x7f0a1f94

.field public static final refresh_area:I = 0x7f0a1f95

.field public static final refresh_button:I = 0x7f0a1f96

.field public static final refresh_layout:I = 0x7f0a1f98

.field public static final refresh_overView:I = 0x7f0a1f99

.field public static final refresh_placeholder:I = 0x7f0a1f9a

.field public static final refresh_progress:I = 0x7f0a1f9b

.field public static final refresh_start_animation:I = 0x7f0a1f9c

.field public static final refund_arrow:I = 0x7f0a1f9d

.field public static final refund_desc:I = 0x7f0a1f9f

.field public static final refund_desc_1:I = 0x7f0a1fa0

.field public static final refund_desc_2:I = 0x7f0a1fa1

.field public static final refund_desc_container:I = 0x7f0a1fa2

.field public static final refund_dvd:I = 0x7f0a1fa3

.field public static final refund_endorse_upgrade_close:I = 0x7f0a1fa4

.field public static final refund_group:I = 0x7f0a1fa5

.field public static final refund_icon:I = 0x7f0a1fa6

.field public static final refund_item:I = 0x7f0a1fa8

.field public static final refund_label:I = 0x7f0a1fa9

.field public static final refund_label_1:I = 0x7f0a1faa

.field public static final refund_label_2:I = 0x7f0a1fab

.field public static final refund_text:I = 0x7f0a1fae

.field public static final refund_title:I = 0x7f0a1faf

.field public static final refund_zone:I = 0x7f0a1fb1

.field public static final regesiter_short_goods_layout:I = 0x7f0a1fb2

.field public static final reget_button:I = 0x7f0a1fb3

.field public static final region_name:I = 0x7f0a1fb6

.field public static final region_number:I = 0x7f0a1fb7

.field public static final region_select:I = 0x7f0a1fb8

.field public static final register_list:I = 0x7f0a1fba

.field public static final remark:I = 0x7f0a1fc6

.field public static final remark_container:I = 0x7f0a1fc7

.field public static final remark_desc:I = 0x7f0a1fc8

.field public static final remark_divider:I = 0x7f0a1fc9

.field public static final remote_activity_tag:I = 0x7f0a1fca

.field public static final remote_union_icon:I = 0x7f0a1fcb

.field public static final replace_view:I = 0x7f0a1fcd

.field public static final replay:I = 0x7f0a1fce

.field public static final reply_content_viewstub:I = 0x7f0a1fd0

.field public static final reply_icon:I = 0x7f0a1fd1

.field public static final report:I = 0x7f0a1fd4

.field public static final report_header:I = 0x7f0a1fd5

.field public static final report_item_check:I = 0x7f0a1fd6

.field public static final report_item_tv:I = 0x7f0a1fd7

.field public static final report_memo:I = 0x7f0a1fd8

.field public static final report_reason_length:I = 0x7f0a1fd9

.field public static final report_reason_list:I = 0x7f0a1fda

.field public static final report_reason_memo:I = 0x7f0a1fdb

.field public static final report_reason_memotitle:I = 0x7f0a1fdc

.field public static final report_root:I = 0x7f0a1fdd

.field public static final reset:I = 0x7f0a1fe2

.field public static final restart:I = 0x7f0a1fe5

.field public static final restart_preview:I = 0x7f0a1fe6

.field public static final restrict_text:I = 0x7f0a1fe7

.field public static final result_icon:I = 0x7f0a1feb

.field public static final result_view:I = 0x7f0a1fec

.field public static final return_scan_result:I = 0x7f0a1fed

.field public static final reverse:I = 0x7f0a1fee

.field public static final reverseSawtooth:I = 0x7f0a1fef

.field public static final reward_detail_container:I = 0x7f0a1ff0

.field public static final reward_detail_icon_right_arrow:I = 0x7f0a1ff1

.field public static final rich_bubble:I = 0x7f0a1ff2

.field public static final right:I = 0x7f0a1ffe

.field public static final rightBottom:I = 0x7f0a1fff

.field public static final rightCenter:I = 0x7f0a2000

.field public static final rightToLeft:I = 0x7f0a2001

.field public static final rightTop:I = 0x7f0a2002

.field public static final right_action:I = 0x7f0a2003

.field public static final right_action_layout:I = 0x7f0a2004

.field public static final right_area:I = 0x7f0a2005

.field public static final right_arrow:I = 0x7f0a2006

.field public static final right_bottom_view:I = 0x7f0a2007

.field public static final right_button:I = 0x7f0a2008

.field public static final right_circle:I = 0x7f0a2009

.field public static final right_guideline_id:I = 0x7f0a200a

.field public static final right_icon:I = 0x7f0a200b

.field public static final right_icon_v2:I = 0x7f0a200c

.field public static final right_image:I = 0x7f0a200d

.field public static final right_image_shadow:I = 0x7f0a200e

.field public static final right_image_shadow2:I = 0x7f0a200f

.field public static final right_side:I = 0x7f0a2012

.field public static final right_text:I = 0x7f0a2013

.field public static final right_top_category_tag:I = 0x7f0a2014

.field public static final right_top_view:I = 0x7f0a2015

.field public static final right_view:I = 0x7f0a2016

.field public static final right_zone:I = 0x7f0a2017

.field public static final ring:I = 0x7f0a2018

.field public static final risk_alert_item_icon:I = 0x7f0a2019

.field public static final risk_alert_item_label_first:I = 0x7f0a201a

.field public static final risk_alert_item_label_sec:I = 0x7f0a201b

.field public static final risk_alert_item_title:I = 0x7f0a201c

.field public static final risk_cinema_info_block:I = 0x7f0a201d

.field public static final risk_info_timer:I = 0x7f0a201e

.field public static final risk_refund_info_block:I = 0x7f0a201f

.field public static final risk_time_info_block:I = 0x7f0a2020

.field public static final riv_dm_img:I = 0x7f0a2021

.field public static final riv_item_theme_project:I = 0x7f0a2022

.field public static final rl_block_total_amount:I = 0x7f0a2028

.field public static final rl_bottom:I = 0x7f0a2029

.field public static final rl_bottom_bar:I = 0x7f0a202a

.field public static final rl_close:I = 0x7f0a202d

.field public static final rl_container:I = 0x7f0a202f

.field public static final rl_content:I = 0x7f0a2030

.field public static final rl_cost:I = 0x7f0a2032

.field public static final rl_coupon:I = 0x7f0a2033

.field public static final rl_coupons:I = 0x7f0a2034

.field public static final rl_discount_price:I = 0x7f0a2037

.field public static final rl_discount_price2:I = 0x7f0a2038

.field public static final rl_film_media_wanted:I = 0x7f0a203b

.field public static final rl_finish:I = 0x7f0a203c

.field public static final rl_goto_detail:I = 0x7f0a203d

.field public static final rl_image_view:I = 0x7f0a2044

.field public static final rl_left_item:I = 0x7f0a2048

.field public static final rl_lock:I = 0x7f0a204a

.field public static final rl_lottery_result:I = 0x7f0a204b

.field public static final rl_luck_top:I = 0x7f0a204c

.field public static final rl_panel_top:I = 0x7f0a204f

.field public static final rl_parent:I = 0x7f0a2050

.field public static final rl_performance_more_item:I = 0x7f0a2053

.field public static final rl_project_extra_benefit_layout:I = 0x7f0a205b

.field public static final rl_protocol_dialog_container:I = 0x7f0a205e

.field public static final rl_rank_head_layout:I = 0x7f0a205f

.field public static final rl_refund_endorse:I = 0x7f0a2064

.field public static final rl_right_item:I = 0x7f0a2066

.field public static final rl_root:I = 0x7f0a2067

.field public static final rl_shedule_item_time:I = 0x7f0a2069

.field public static final rl_show_more_item:I = 0x7f0a206a

.field public static final rl_tips:I = 0x7f0a206f

.field public static final rl_title:I = 0x7f0a2070

.field public static final rl_tm_right_profit_layout:I = 0x7f0a2072

.field public static final rl_top_bar:I = 0x7f0a2074

.field public static final rl_top_title:I = 0x7f0a2076

.field public static final rl_top_title2:I = 0x7f0a2077

.field public static final rl_unity_container:I = 0x7f0a2078

.field public static final rl_vip_exchange:I = 0x7f0a207a

.field public static final rl_vip_item:I = 0x7f0a207b

.field public static final rl_youku_wanted:I = 0x7f0a2080

.field public static final role_name_tv:I = 0x7f0a2086

.field public static final roll_tip_item:I = 0x7f0a2087

.field public static final roll_tip_item_title:I = 0x7f0a2088

.field public static final root:I = 0x7f0a2089

.field public static final rootView:I = 0x7f0a208a

.field public static final root_constraint:I = 0x7f0a208c

.field public static final root_container:I = 0x7f0a208d

.field public static final root_layout:I = 0x7f0a208f

.field public static final root_rl:I = 0x7f0a2091

.field public static final root_view:I = 0x7f0a2092

.field public static final rootview:I = 0x7f0a2094

.field public static final rotate:I = 0x7f0a2095

.field public static final round:I = 0x7f0a2096

.field public static final roundRectShape:I = 0x7f0a2097

.field public static final roundShape:I = 0x7f0a2099

.field public static final rounded:I = 0x7f0a209a

.field public static final rounded_rectangle:I = 0x7f0a209b

.field public static final row:I = 0x7f0a209c

.field public static final row_index_key:I = 0x7f0a209d

.field public static final row_reverse:I = 0x7f0a209e

.field public static final rp_camera_switch_iv:I = 0x7f0a209f

.field public static final rp_dialog_close_btn:I = 0x7f0a20a0

.field public static final rp_dialog_content:I = 0x7f0a20a1

.field public static final rp_dialog_content_text:I = 0x7f0a20a2

.field public static final rp_dialog_negative_btn:I = 0x7f0a20a3

.field public static final rp_dialog_positive_btn:I = 0x7f0a20a4

.field public static final rp_dialog_subtitle_text:I = 0x7f0a20a5

.field public static final rp_dialog_title_text:I = 0x7f0a20a6

.field public static final rp_loading_close_iv:I = 0x7f0a20a7

.field public static final rp_loading_failed_content:I = 0x7f0a20a8

.field public static final rp_loading_failed_ic:I = 0x7f0a20a9

.field public static final rp_loading_failed_ll:I = 0x7f0a20aa

.field public static final rp_loading_failed_retry:I = 0x7f0a20ab

.field public static final rp_loading_failed_title:I = 0x7f0a20ac

.field public static final rp_loading_iv:I = 0x7f0a20ad

.field public static final rp_loading_pb:I = 0x7f0a20ae

.field public static final rp_preview_layout:I = 0x7f0a20af

.field public static final rp_remote_loading_hint_1:I = 0x7f0a20b0

.field public static final rp_remote_loading_hint_2:I = 0x7f0a20b1

.field public static final rp_take_photo_layout:I = 0x7f0a20b2

.field public static final rtl:I = 0x7f0a20b3

.field public static final rule_tv:I = 0x7f0a20b4

.field public static final runnable:I = 0x7f0a20b5

.field public static final rv_brand_venue:I = 0x7f0a20b8

.field public static final rv_brand_venue_img:I = 0x7f0a20b9

.field public static final rv_brand_venue_title:I = 0x7f0a20ba

.field public static final rv_city_list:I = 0x7f0a20bb

.field public static final rv_coupons:I = 0x7f0a20be

.field public static final rv_fast_filter:I = 0x7f0a20c0

.field public static final rv_folder:I = 0x7f0a20c3

.field public static final rv_image:I = 0x7f0a20c4

.field public static final rv_main_container:I = 0x7f0a20c6

.field public static final rv_pay_option_list:I = 0x7f0a20ce

.field public static final rv_price:I = 0x7f0a20cf

.field public static final rv_touch:I = 0x7f0a20d1

.field public static final saleGoodsTip:I = 0x7f0a20d5

.field public static final sale_activity_view:I = 0x7f0a20d6

.field public static final sale_bottom_confirm:I = 0x7f0a20d7

.field public static final sale_bottom_confirm_btn:I = 0x7f0a20d8

.field public static final sale_bottom_name:I = 0x7f0a20d9

.field public static final sale_bottom_price:I = 0x7f0a20da

.field public static final sale_bottom_upper:I = 0x7f0a20db

.field public static final sale_bottom_value:I = 0x7f0a20dc

.field public static final sale_count:I = 0x7f0a20dd

.field public static final sale_item_label:I = 0x7f0a20de

.field public static final sale_select_switch:I = 0x7f0a20df

.field public static final sales_corner_tag_lab:I = 0x7f0a20e0

.field public static final sales_header_title:I = 0x7f0a20e1

.field public static final sales_header_title_goods_coupon_des:I = 0x7f0a20e2

.field public static final sales_order_expire_time:I = 0x7f0a20e3

.field public static final sales_order_valid_date:I = 0x7f0a20e4

.field public static final salse_tag:I = 0x7f0a20e5

.field public static final sando_container:I = 0x7f0a20e6

.field public static final sans:I = 0x7f0a20e7

.field public static final sat:I = 0x7f0a20e8

.field public static final saturday:I = 0x7f0a20e9

.field public static final save_local_storage:I = 0x7f0a20ea

.field public static final save_non_transition_alpha:I = 0x7f0a20eb

.field public static final save_overlay_view:I = 0x7f0a20ec

.field public static final sawtooth:I = 0x7f0a20ed

.field public static final scale:I = 0x7f0a20ee

.field public static final scaleToFit:I = 0x7f0a20ef

.field public static final scallop:I = 0x7f0a20f0

.field public static final scan_album_image:I = 0x7f0a20f1

.field public static final scan_finder_view:I = 0x7f0a20f2

.field public static final scan_gesture_view:I = 0x7f0a20f3

.field public static final scan_label:I = 0x7f0a20f4

.field public static final scan_ray_container:I = 0x7f0a20f6

.field public static final scan_ray_view:I = 0x7f0a20f7

.field public static final scan_tip:I = 0x7f0a20f8

.field public static final scenic:I = 0x7f0a20f9

.field public static final schedule_activity_tag:I = 0x7f0a20fb

.field public static final schedule_activity_view:I = 0x7f0a20fc

.field public static final schedule_and_food_tab:I = 0x7f0a20fd

.field public static final schedule_buyone_getone_tag:I = 0x7f0a20fe

.field public static final schedule_card_desc:I = 0x7f0a20ff

.field public static final schedule_card_img:I = 0x7f0a2100

.field public static final schedule_card_profit:I = 0x7f0a2101

.field public static final schedule_card_title:I = 0x7f0a2102

.field public static final schedule_cinema_address:I = 0x7f0a2103

.field public static final schedule_cinema_address_location:I = 0x7f0a2104

.field public static final schedule_cinema_address_location_icon:I = 0x7f0a2105

.field public static final schedule_cinema_features:I = 0x7f0a2106

.field public static final schedule_cinema_info:I = 0x7f0a2107

.field public static final schedule_cinema_info_container:I = 0x7f0a2108

.field public static final schedule_cinema_phone:I = 0x7f0a2109

.field public static final schedule_cinema_phone_icon:I = 0x7f0a210a

.field public static final schedule_coupon_bg:I = 0x7f0a210b

.field public static final schedule_coupon_cinemaname:I = 0x7f0a210c

.field public static final schedule_coupon_click:I = 0x7f0a210d

.field public static final schedule_coupon_coupontitle:I = 0x7f0a210e

.field public static final schedule_coupon_desc:I = 0x7f0a210f

.field public static final schedule_coupon_outdate:I = 0x7f0a2110

.field public static final schedule_coupon_price:I = 0x7f0a2111

.field public static final schedule_coupon_yuan:I = 0x7f0a2112

.field public static final schedule_equity_card:I = 0x7f0a2113

.field public static final schedule_err_desc:I = 0x7f0a2114

.field public static final schedule_film_festival:I = 0x7f0a2115

.field public static final schedule_film_poster:I = 0x7f0a2116

.field public static final schedule_group_buy_container:I = 0x7f0a2117

.field public static final schedule_member_banner_info:I = 0x7f0a2118

.field public static final schedule_member_banner_item:I = 0x7f0a2119

.field public static final schedule_member_card_action:I = 0x7f0a211a

.field public static final schedule_member_card_desc:I = 0x7f0a211b

.field public static final schedule_member_card_price:I = 0x7f0a211c

.field public static final schedule_member_card_price_suffix:I = 0x7f0a211d

.field public static final schedule_memcard_space:I = 0x7f0a211e

.field public static final schedule_promotion_des:I = 0x7f0a211f

.field public static final schedule_promotion_tag:I = 0x7f0a2120

.field public static final schedule_promotion_title:I = 0x7f0a2121

.field public static final schedule_red_packet_tag:I = 0x7f0a2122

.field public static final schedule_sale_title:I = 0x7f0a2123

.field public static final schedule_sale_title_goods_coupon_des:I = 0x7f0a2124

.field public static final schedule_show_info:I = 0x7f0a2125

.field public static final schedule_star_tag:I = 0x7f0a2126

.field public static final schedule_tag:I = 0x7f0a2127

.field public static final schedule_tag_container:I = 0x7f0a2128

.field public static final schedule_ticket_tags_container:I = 0x7f0a2129

.field public static final schedule_upper:I = 0x7f0a212a

.field public static final schedule_vip_discount:I = 0x7f0a212b

.field public static final scoll_content:I = 0x7f0a212d

.field public static final score:I = 0x7f0a212e

.field public static final scoreStar_view:I = 0x7f0a212f

.field public static final score_cate:I = 0x7f0a2133

.field public static final score_favor_right_hint:I = 0x7f0a2135

.field public static final score_icon:I = 0x7f0a2136

.field public static final score_info_view:I = 0x7f0a2137

.field public static final score_lay:I = 0x7f0a2139

.field public static final score_ll:I = 0x7f0a213a

.field public static final score_star:I = 0x7f0a213b

.field public static final score_text:I = 0x7f0a213c

.field public static final score_text_suffix:I = 0x7f0a213d

.field public static final score_text_title:I = 0x7f0a213e

.field public static final score_zone:I = 0x7f0a2140

.field public static final scratch_view:I = 0x7f0a2141

.field public static final screen:I = 0x7f0a2142

.field public static final script_btn:I = 0x7f0a2151

.field public static final script_coupon_coupon_name:I = 0x7f0a2152

.field public static final script_coupon_desc:I = 0x7f0a2153

.field public static final script_coupon_limit_desc:I = 0x7f0a2154

.field public static final script_coupon_limit_title:I = 0x7f0a2155

.field public static final script_coupon_name:I = 0x7f0a2156

.field public static final script_coupon_poster:I = 0x7f0a2157

.field public static final script_coupon_price:I = 0x7f0a2158

.field public static final script_coupon_price_icon:I = 0x7f0a2159

.field public static final script_coupon_sell_num:I = 0x7f0a215a

.field public static final script_coupon_service_clickll:I = 0x7f0a215b

.field public static final script_coupon_service_layout:I = 0x7f0a215c

.field public static final script_coupon_service_more:I = 0x7f0a215d

.field public static final script_coupon_service_title:I = 0x7f0a215e

.field public static final script_coupon_store_icon:I = 0x7f0a215f

.field public static final script_coupon_store_name:I = 0x7f0a2160

.field public static final script_desc:I = 0x7f0a2161

.field public static final script_detail_top_follow_layout:I = 0x7f0a2162

.field public static final script_detail_top_place_h:I = 0x7f0a2163

.field public static final script_detail_top_play_icon:I = 0x7f0a2164

.field public static final script_detail_top_play_layout:I = 0x7f0a2165

.field public static final script_detail_top_play_tv:I = 0x7f0a2166

.field public static final script_detail_top_wanna_2_see_icon:I = 0x7f0a2167

.field public static final script_detail_top_wanna_2_see_text:I = 0x7f0a2168

.field public static final script_img:I = 0x7f0a2169

.field public static final script_info_header_img:I = 0x7f0a216a

.field public static final script_info_header_limit_tag:I = 0x7f0a216b

.field public static final script_info_header_name:I = 0x7f0a216c

.field public static final script_murder_header_info:I = 0x7f0a216d

.field public static final script_murder_shop:I = 0x7f0a216e

.field public static final script_name:I = 0x7f0a216f

.field public static final script_poster:I = 0x7f0a2171

.field public static final script_price_tag:I = 0x7f0a2172

.field public static final script_score:I = 0x7f0a2173

.field public static final script_share_page_poster:I = 0x7f0a2174

.field public static final script_share_page_subtitle:I = 0x7f0a2175

.field public static final script_share_page_title:I = 0x7f0a2176

.field public static final script_shop_score:I = 0x7f0a2177

.field public static final script_tag:I = 0x7f0a2178

.field public static final script_tags:I = 0x7f0a2179

.field public static final scriptkill_top_gaussimg:I = 0x7f0a217b

.field public static final scriptkill_top_gaussimg_cover:I = 0x7f0a217c

.field public static final scroll:I = 0x7f0a217d

.field public static final scrollIndicatorDown:I = 0x7f0a217e

.field public static final scrollIndicatorUp:I = 0x7f0a217f

.field public static final scrollView:I = 0x7f0a2180

.field public static final scroll_content:I = 0x7f0a2181

.field public static final scroll_root:I = 0x7f0a2184

.field public static final scroll_simple_date:I = 0x7f0a2185

.field public static final scroll_view:I = 0x7f0a2187

.field public static final scrollable:I = 0x7f0a2188

.field public static final scrollable_loadmore_progressbar:I = 0x7f0a2189

.field public static final scrollable_loadmore_tv:I = 0x7f0a218a

.field public static final scrollview:I = 0x7f0a218b

.field public static final scv_ticket_info:I = 0x7f0a218c

.field public static final sdv_sale_item_image:I = 0x7f0a218d

.field public static final search:I = 0x7f0a218e

.field public static final search_ai_btn_lottie:I = 0x7f0a218f

.field public static final search_ai_entry:I = 0x7f0a2190

.field public static final search_badge:I = 0x7f0a2191

.field public static final search_bar:I = 0x7f0a2192

.field public static final search_book_contents_failed:I = 0x7f0a2193

.field public static final search_book_contents_succeeded:I = 0x7f0a2194

.field public static final search_btn:I = 0x7f0a2196

.field public static final search_button:I = 0x7f0a2197

.field public static final search_clear_btn:I = 0x7f0a2198

.field public static final search_close_btn:I = 0x7f0a2199

.field public static final search_container:I = 0x7f0a219a

.field public static final search_content:I = 0x7f0a219b

.field public static final search_edit_frame:I = 0x7f0a219c

.field public static final search_edit_text:I = 0x7f0a219d

.field public static final search_egg_list:I = 0x7f0a219e

.field public static final search_go_btn:I = 0x7f0a21a0

.field public static final search_history:I = 0x7f0a21a1

.field public static final search_history_container:I = 0x7f0a21a2

.field public static final search_hot_list_recycler_view:I = 0x7f0a21a3

.field public static final search_hot_list_root_view:I = 0x7f0a21a4

.field public static final search_information_item_layout:I = 0x7f0a21a5

.field public static final search_list_view:I = 0x7f0a21a6

.field public static final search_list_view_flipper:I = 0x7f0a21a7

.field public static final search_list_view_icon:I = 0x7f0a21a8

.field public static final search_mag_icon:I = 0x7f0a21a9

.field public static final search_no_result:I = 0x7f0a21aa

.field public static final search_no_result_img:I = 0x7f0a21ab

.field public static final search_plate:I = 0x7f0a21ac

.field public static final search_result_dispatch_tab_lottie:I = 0x7f0a21ad

.field public static final search_result_dispatch_tab_pic:I = 0x7f0a21ae

.field public static final search_result_favorite:I = 0x7f0a21af

.field public static final search_result_favorite_Ll:I = 0x7f0a21b0

.field public static final search_result_favorite_fl:I = 0x7f0a21b1

.field public static final search_result_favorite_fl_pioneer:I = 0x7f0a21b2

.field public static final search_result_favorite_pioneer:I = 0x7f0a21b3

.field public static final search_result_film_banner_card_play_btn:I = 0x7f0a21b4

.field public static final search_result_film_banner_card_play_btn_pioneer:I = 0x7f0a21b5

.field public static final search_result_film_banner_card_poster:I = 0x7f0a21b6

.field public static final search_result_film_card_banner:I = 0x7f0a21b7

.field public static final search_result_film_card_buy_btn:I = 0x7f0a21b8

.field public static final search_result_film_card_name:I = 0x7f0a21b9

.field public static final search_result_film_card_no_banner:I = 0x7f0a21ba

.field public static final search_result_film_card_normal_header:I = 0x7f0a21bb

.field public static final search_result_film_card_notice:I = 0x7f0a21bc

.field public static final search_result_film_card_notice_content:I = 0x7f0a21bd

.field public static final search_result_film_card_notice_divider:I = 0x7f0a21be

.field public static final search_result_film_card_notice_title:I = 0x7f0a21bf

.field public static final search_result_film_card_other_info:I = 0x7f0a21c0

.field public static final search_result_film_card_poster:I = 0x7f0a21c1

.field public static final search_result_film_card_score_favor:I = 0x7f0a21c2

.field public static final search_result_film_card_score_favor_left:I = 0x7f0a21c3

.field public static final search_result_film_card_score_favor_right:I = 0x7f0a21c4

.field public static final search_result_tab_layout:I = 0x7f0a21c5

.field public static final search_src_text:I = 0x7f0a21c6

.field public static final search_title_close:I = 0x7f0a21c8

.field public static final search_title_container:I = 0x7f0a21c9

.field public static final search_title_content:I = 0x7f0a21ca

.field public static final search_title_layout:I = 0x7f0a21cb

.field public static final search_v2_container:I = 0x7f0a21cc

.field public static final search_v2_egg_layout:I = 0x7f0a21cd

.field public static final search_v2_history_clear:I = 0x7f0a21ce

.field public static final search_v2_history_layout:I = 0x7f0a21cf

.field public static final search_v2_history_layout_container:I = 0x7f0a21d0

.field public static final search_v2_history_word_title:I = 0x7f0a21d1

.field public static final search_v2_history_word_title_bg:I = 0x7f0a21d2

.field public static final search_v2_history_word_ui:I = 0x7f0a21d3

.field public static final search_v2_hot_word_container:I = 0x7f0a21d4

.field public static final search_v2_hot_word_sub_title:I = 0x7f0a21d5

.field public static final search_v2_hot_word_title:I = 0x7f0a21d6

.field public static final search_v2_hot_word_ui:I = 0x7f0a21d7

.field public static final search_v2_iconList:I = 0x7f0a21d8

.field public static final search_v2_rank_number:I = 0x7f0a21d9

.field public static final search_v2_rank_tag:I = 0x7f0a21da

.field public static final search_v2_rank_tag_local:I = 0x7f0a21db

.field public static final search_v2_rank_text:I = 0x7f0a21dc

.field public static final search_v2_rank_trend:I = 0x7f0a21dd

.field public static final search_v2_rank_word_ui:I = 0x7f0a21de

.field public static final search_v2_search_history_layout:I = 0x7f0a21df

.field public static final search_v2_search_result:I = 0x7f0a21e0

.field public static final search_v2_suggest_recycler:I = 0x7f0a21e1

.field public static final search_v2_top_bg:I = 0x7f0a21e2

.field public static final search_v2_word_suggest_layout:I = 0x7f0a21e3

.field public static final search_v2_word_tab_ui:I = 0x7f0a21e4

.field public static final search_view:I = 0x7f0a21e5

.field public static final search_view_container:I = 0x7f0a21e6

.field public static final search_view_hint:I = 0x7f0a21e7

.field public static final search_view_icon:I = 0x7f0a21e8

.field public static final search_view_img:I = 0x7f0a21e9

.field public static final search_view_txt:I = 0x7f0a21ea

.field public static final search_voice_btn:I = 0x7f0a21eb

.field public static final seat:I = 0x7f0a21ed

.field public static final seat_bottom_panel:I = 0x7f0a21f4

.field public static final seat_container:I = 0x7f0a21f6

.field public static final seat_effect_layer:I = 0x7f0a21f7

.field public static final seat_group:I = 0x7f0a21f9

.field public static final seat_name:I = 0x7f0a2203

.field public static final seat_number:I = 0x7f0a2204

.field public static final seat_number_layout:I = 0x7f0a2205

.field public static final seat_overlay_bottom:I = 0x7f0a2206

.field public static final seat_price:I = 0x7f0a2208

.field public static final seat_price_icon:I = 0x7f0a220a

.field public static final seat_warn_tv:I = 0x7f0a2216

.field public static final seattable:I = 0x7f0a2217

.field public static final second_line:I = 0x7f0a2218

.field public static final second_line_layout:I = 0x7f0a2219

.field public static final second_line_view:I = 0x7f0a221a

.field public static final see_more_default:I = 0x7f0a221c

.field public static final seek_bar:I = 0x7f0a221e

.field public static final seekbar:I = 0x7f0a221f

.field public static final seekbar_bg:I = 0x7f0a2220

.field public static final seekbar_want:I = 0x7f0a2221

.field public static final selectClickBg:I = 0x7f0a2223

.field public static final select_add:I = 0x7f0a2227

.field public static final select_amount:I = 0x7f0a2228

.field public static final select_artist_list_item:I = 0x7f0a2229

.field public static final select_bottom:I = 0x7f0a222a

.field public static final select_city_hot_list_item:I = 0x7f0a222b

.field public static final select_city_list_item:I = 0x7f0a222c

.field public static final select_city_list_item_divider:I = 0x7f0a222d

.field public static final select_city_list_item_divider_bottom:I = 0x7f0a222e

.field public static final select_dialog_listview:I = 0x7f0a222f

.field public static final select_float_list_item:I = 0x7f0a2231

.field public static final select_hint_first:I = 0x7f0a2232

.field public static final select_hint_second:I = 0x7f0a2233

.field public static final select_minus:I = 0x7f0a2234

.field public static final select_privileged_audience_btn:I = 0x7f0a2236

.field public static final select_seat_area_tip_message:I = 0x7f0a2237

.field public static final select_seat_info_deliver:I = 0x7f0a2238

.field public static final select_zone:I = 0x7f0a2239

.field public static final selected:I = 0x7f0a223a

.field public static final selection_type:I = 0x7f0a223c

.field public static final selector_item_check:I = 0x7f0a223d

.field public static final senior_tv_stock:I = 0x7f0a223f

.field public static final senior_tv_stock_top:I = 0x7f0a2240

.field public static final seperate_line:I = 0x7f0a2241

.field public static final serif:I = 0x7f0a2244

.field public static final service_notice_container:I = 0x7f0a2246

.field public static final service_support:I = 0x7f0a2247

.field public static final service_support_icon:I = 0x7f0a2248

.field public static final session_time:I = 0x7f0a224f

.field public static final session_time_tab:I = 0x7f0a2250

.field public static final sex_desc:I = 0x7f0a2253

.field public static final sex_icon:I = 0x7f0a2254

.field public static final sex_line:I = 0x7f0a2256

.field public static final shadow_left_danmaku:I = 0x7f0a2260

.field public static final shadow_right_danmaku:I = 0x7f0a2261

.field public static final shape_bacground:I = 0x7f0a2262

.field public static final share:I = 0x7f0a2263

.field public static final share_activity_layout:I = 0x7f0a2265

.field public static final share_ads_banner:I = 0x7f0a2266

.field public static final share_ads_banner_subtitle:I = 0x7f0a2267

.field public static final share_ads_banner_title:I = 0x7f0a2268

.field public static final share_ads_icon:I = 0x7f0a2269

.field public static final share_artist_avatar:I = 0x7f0a226a

.field public static final share_artist_desc:I = 0x7f0a226b

.field public static final share_artist_name:I = 0x7f0a226c

.field public static final share_board:I = 0x7f0a226d

.field public static final share_btn:I = 0x7f0a226e

.field public static final share_btn_v2:I = 0x7f0a226f

.field public static final share_cancel_area:I = 0x7f0a2270

.field public static final share_cancel_btn:I = 0x7f0a2271

.field public static final share_card_bg:I = 0x7f0a2272

.field public static final share_card_location:I = 0x7f0a2273

.field public static final share_card_time:I = 0x7f0a2274

.field public static final share_card_title:I = 0x7f0a2275

.field public static final share_card_type:I = 0x7f0a2276

.field public static final share_card_type_ll:I = 0x7f0a2277

.field public static final share_channel_container:I = 0x7f0a2278

.field public static final share_channel_icon:I = 0x7f0a2279

.field public static final share_channel_name:I = 0x7f0a227a

.field public static final share_container:I = 0x7f0a227b

.field public static final share_container_divider:I = 0x7f0a227c

.field public static final share_content_head:I = 0x7f0a227d

.field public static final share_content_layout:I = 0x7f0a227e

.field public static final share_content_user_content:I = 0x7f0a227f

.field public static final share_content_user_img:I = 0x7f0a2280

.field public static final share_content_user_info_visible_icon:I = 0x7f0a2281

.field public static final share_content_user_member_icon:I = 0x7f0a2282

.field public static final share_content_user_name:I = 0x7f0a2283

.field public static final share_dingding_circle_btn:I = 0x7f0a2284

.field public static final share_fans:I = 0x7f0a2285

.field public static final share_icon:I = 0x7f0a2288

.field public static final share_icon_desc:I = 0x7f0a2289

.field public static final share_img:I = 0x7f0a228a

.field public static final share_item_bg:I = 0x7f0a228b

.field public static final share_item_iconfont:I = 0x7f0a228c

.field public static final share_item_image:I = 0x7f0a228d

.field public static final share_item_text:I = 0x7f0a228e

.field public static final share_layout:I = 0x7f0a228f

.field public static final share_left_tx:I = 0x7f0a2290

.field public static final share_lottie_view:I = 0x7f0a2292

.field public static final share_menu_title:I = 0x7f0a2293

.field public static final share_mid_tx:I = 0x7f0a2294

.field public static final share_page:I = 0x7f0a2295

.field public static final share_page_bg:I = 0x7f0a2296

.field public static final share_page_bg_layout:I = 0x7f0a2297

.field public static final share_page_bottom:I = 0x7f0a2298

.field public static final share_page_comment_content:I = 0x7f0a2299

.field public static final share_page_comment_create_time:I = 0x7f0a229a

.field public static final share_page_comment_user_icon:I = 0x7f0a229b

.field public static final share_page_comment_user_nick:I = 0x7f0a229c

.field public static final share_page_damai_logo:I = 0x7f0a229d

.field public static final share_page_dm_tag:I = 0x7f0a229e

.field public static final share_page_footer:I = 0x7f0a229f

.field public static final share_page_perform_city:I = 0x7f0a22a0

.field public static final share_page_perform_time:I = 0x7f0a22a1

.field public static final share_page_poster:I = 0x7f0a22a2

.field public static final share_page_poster_layout:I = 0x7f0a22a3

.field public static final share_page_projectbg:I = 0x7f0a22a4

.field public static final share_page_qrcode_img:I = 0x7f0a22a5

.field public static final share_page_qrcode_tip:I = 0x7f0a22a6

.field public static final share_page_remark:I = 0x7f0a22a7

.field public static final share_page_remark_value:I = 0x7f0a22a8

.field public static final share_page_reward_tip:I = 0x7f0a22a9

.field public static final share_page_subtitle:I = 0x7f0a22aa

.field public static final share_page_title:I = 0x7f0a22ac

.field public static final share_page_user_evaluate_content:I = 0x7f0a22ad

.field public static final share_page_user_evaluate_divider:I = 0x7f0a22ae

.field public static final share_page_user_evaluate_pics:I = 0x7f0a22af

.field public static final share_page_user_evaluate_time:I = 0x7f0a22b0

.field public static final share_page_user_grade:I = 0x7f0a22b1

.field public static final share_page_user_grade_layout:I = 0x7f0a22b2

.field public static final share_page_user_grade_view:I = 0x7f0a22b3

.field public static final share_page_user_header_icon:I = 0x7f0a22b4

.field public static final share_page_user_nick:I = 0x7f0a22b5

.field public static final share_page_user_nick_layout:I = 0x7f0a22b6

.field public static final share_qq_btn:I = 0x7f0a22b7

.field public static final share_qrcode:I = 0x7f0a22b8

.field public static final share_root:I = 0x7f0a22b9

.field public static final share_save_btn:I = 0x7f0a22ba

.field public static final share_scrollview:I = 0x7f0a22bb

.field public static final share_sina_btn:I = 0x7f0a22bc

.field public static final share_title_layout:I = 0x7f0a22bd

.field public static final share_top_view:I = 0x7f0a22be

.field public static final share_wechat_btn:I = 0x7f0a22bf

.field public static final share_wechat_circle_btn:I = 0x7f0a22c0

.field public static final share_wx_img_msg:I = 0x7f0a22c1

.field public static final share_wx_img_originalprice:I = 0x7f0a22c2

.field public static final share_wx_img_price:I = 0x7f0a22c3

.field public static final share_wx_img_showtime:I = 0x7f0a22c4

.field public static final share_wx_img_userbar:I = 0x7f0a22c5

.field public static final share_wx_img_userimg:I = 0x7f0a22c6

.field public static final share_wx_img_usermsg:I = 0x7f0a22c7

.field public static final share_yymember_integrate:I = 0x7f0a22c8

.field public static final share_yymember_integrate_action:I = 0x7f0a22c9

.field public static final share_yymember_integrate_icon:I = 0x7f0a22ca

.field public static final share_yymember_integrate_text:I = 0x7f0a22cb

.field public static final sharedValueSet:I = 0x7f0a22cc

.field public static final sharedValueUnset:I = 0x7f0a22cd

.field public static final sheet_container:I = 0x7f0a22ce

.field public static final sheet_content:I = 0x7f0a22cf

.field public static final sheet_title:I = 0x7f0a22d1

.field public static final shengyu_layout:I = 0x7f0a22d2

.field public static final shimmer:I = 0x7f0a22d3

.field public static final shop_address:I = 0x7f0a22d4

.field public static final shop_img:I = 0x7f0a22d5

.field public static final shop_name:I = 0x7f0a22d6

.field public static final shortcut:I = 0x7f0a22d7

.field public static final showCustom:I = 0x7f0a22d8

.field public static final showHome:I = 0x7f0a22d9

.field public static final showTitle:I = 0x7f0a22da

.field public static final showWhenTouch:I = 0x7f0a22db

.field public static final show_bogo:I = 0x7f0a22dc

.field public static final show_btn:I = 0x7f0a22dd

.field public static final show_city:I = 0x7f0a22de

.field public static final show_count_icon:I = 0x7f0a22df

.field public static final show_icon:I = 0x7f0a22e5

.field public static final show_location:I = 0x7f0a22e6

.field public static final show_name:I = 0x7f0a22e8

.field public static final show_poster:I = 0x7f0a22e9

.field public static final show_poster_mask:I = 0x7f0a22ea

.field public static final show_qrcode:I = 0x7f0a22ec

.field public static final show_time:I = 0x7f0a22ee

.field public static final show_tip:I = 0x7f0a22f1

.field public static final show_tomorrow:I = 0x7f0a22f2

.field public static final simplified_business_container:I = 0x7f0a22f4

.field public static final simplified_business_root_view:I = 0x7f0a22f5

.field public static final simplified_business_top_view:I = 0x7f0a22f6

.field public static final sin:I = 0x7f0a22f7

.field public static final single:I = 0x7f0a22f8

.field public static final single_image:I = 0x7f0a22f9

.field public static final single_mode:I = 0x7f0a22fa

.field public static final single_user_layout:I = 0x7f0a22fc

.field public static final size_100x100:I = 0x7f0a22fe

.field public static final size_30x30:I = 0x7f0a2300

.field public static final size_40x40:I = 0x7f0a2301

.field public static final size_50x50:I = 0x7f0a2302

.field public static final size_60x60:I = 0x7f0a2305

.field public static final size_63x63:I = 0x7f0a2306

.field public static final size_70x70:I = 0x7f0a2308

.field public static final size_80x80:I = 0x7f0a2309

.field public static final skipped:I = 0x7f0a230b

.field public static final sku_contanier:I = 0x7f0a230c

.field public static final sku_dollar_tv:I = 0x7f0a230d

.field public static final sku_ellipsis_tv:I = 0x7f0a230e

.field public static final sku_price_tv:I = 0x7f0a230f

.field public static final sky_view:I = 0x7f0a2312

.field public static final slide:I = 0x7f0a2313

.field public static final slideIndicator:I = 0x7f0a2314

.field public static final sliding_image:I = 0x7f0a2319

.field public static final sliding_image_bottom_bar:I = 0x7f0a231a

.field public static final sliding_image_gradient:I = 0x7f0a231b

.field public static final sliding_item:I = 0x7f0a231c

.field public static final sliding_item_default:I = 0x7f0a231d

.field public static final sliding_tag:I = 0x7f0a231e

.field public static final sll_content_item_main_container:I = 0x7f0a231f

.field public static final snackbar_action:I = 0x7f0a2321

.field public static final snackbar_text:I = 0x7f0a2322

.field public static final snap:I = 0x7f0a2323

.field public static final snapMargins:I = 0x7f0a2324

.field public static final snap_horizontal_list:I = 0x7f0a2325

.field public static final sns_share:I = 0x7f0a2326

.field public static final so_install_layout:I = 0x7f0a2327

.field public static final software:I = 0x7f0a2328

.field public static final solid:I = 0x7f0a2329

.field public static final sort_filter_check:I = 0x7f0a2331

.field public static final sort_filter_item:I = 0x7f0a2332

.field public static final sort_type:I = 0x7f0a2334

.field public static final sound_test_success:I = 0x7f0a2335

.field public static final sourcelabel_txt:I = 0x7f0a2336

.field public static final south:I = 0x7f0a2337

.field public static final sp_line2:I = 0x7f0a2338

.field public static final space:I = 0x7f0a2339

.field public static final space_around:I = 0x7f0a233a

.field public static final space_between:I = 0x7f0a233b

.field public static final space_bottom:I = 0x7f0a233c

.field public static final space_evenly:I = 0x7f0a233d

.field public static final space_horizontal:I = 0x7f0a233e

.field public static final space_line:I = 0x7f0a233f

.field public static final space_to_note_container:I = 0x7f0a2340

.field public static final space_vertical:I = 0x7f0a2341

.field public static final spacer:I = 0x7f0a2342

.field public static final spb_interpolator_accelerate:I = 0x7f0a2343

.field public static final spb_interpolator_acceleratedecelerate:I = 0x7f0a2344

.field public static final spb_interpolator_decelerate:I = 0x7f0a2345

.field public static final spb_interpolator_linear:I = 0x7f0a2346

.field public static final special_effects_controller_view_tag:I = 0x7f0a2347

.field public static final special_schedule_tag:I = 0x7f0a2348

.field public static final special_schedule_tag_view:I = 0x7f0a2349

.field public static final special_tag_view:I = 0x7f0a234a

.field public static final spinner_item:I = 0x7f0a234b

.field public static final splash_image:I = 0x7f0a234e

.field public static final splice_order_activity_level_subtitle:I = 0x7f0a2352

.field public static final splice_order_activity_level_title:I = 0x7f0a2353

.field public static final splice_order_launch_one:I = 0x7f0a2354

.field public static final splice_order_launch_one_arrow:I = 0x7f0a2355

.field public static final splice_order_launch_one_pre:I = 0x7f0a2356

.field public static final splice_order_level_btn_container:I = 0x7f0a2357

.field public static final splice_order_notice_avatar:I = 0x7f0a2358

.field public static final splice_order_notice_des:I = 0x7f0a2359

.field public static final splice_order_pop_content_container:I = 0x7f0a235a

.field public static final splice_order_pop_content_core_state:I = 0x7f0a235b

.field public static final spline:I = 0x7f0a235c

.field public static final split_action_bar:I = 0x7f0a2366

.field public static final spm_block:I = 0x7f0a2367

.field public static final spmd:I = 0x7f0a2368

.field public static final spread:I = 0x7f0a236b

.field public static final spread_inside:I = 0x7f0a236c

.field public static final spring:I = 0x7f0a236d

.field public static final square:I = 0x7f0a236e

.field public static final src_atop:I = 0x7f0a237a

.field public static final src_in:I = 0x7f0a237b

.field public static final src_over:I = 0x7f0a237c

.field public static final srl_classics_arrow:I = 0x7f0a237d

.field public static final srl_classics_center:I = 0x7f0a237e

.field public static final srl_classics_progress:I = 0x7f0a237f

.field public static final srl_classics_title:I = 0x7f0a2380

.field public static final srl_classics_update:I = 0x7f0a2381

.field public static final staff_img:I = 0x7f0a2382

.field public static final staff_name_tv:I = 0x7f0a2383

.field public static final staff_role_img:I = 0x7f0a2384

.field public static final staggered_grid:I = 0x7f0a2385

.field public static final standard:I = 0x7f0a2386

.field public static final star_header_img:I = 0x7f0a2387

.field public static final star_header_img_artist:I = 0x7f0a2388

.field public static final star_header_img_brand:I = 0x7f0a2389

.field public static final star_header_ll_share:I = 0x7f0a238a

.field public static final star_index_headerbg:I = 0x7f0a238b

.field public static final star_label_view:I = 0x7f0a238c

.field public static final star_name_view:I = 0x7f0a238d

.field public static final star_tag_view:I = 0x7f0a2393

.field public static final star_tour_info_cities:I = 0x7f0a2394

.field public static final star_tour_info_cities_parent:I = 0x7f0a2395

.field public static final star_tour_info_citydate:I = 0x7f0a2396

.field public static final star_tour_info_citydesc:I = 0x7f0a2397

.field public static final star_tour_info_cityimg:I = 0x7f0a2398

.field public static final star_tour_info_cityname:I = 0x7f0a2399

.field public static final star_user_tv_name:I = 0x7f0a239a

.field public static final start:I = 0x7f0a239e

.field public static final startHorizontal:I = 0x7f0a239f

.field public static final startToEnd:I = 0x7f0a23a0

.field public static final startVertical:I = 0x7f0a23a1

.field public static final start_note_txt:I = 0x7f0a23a2

.field public static final start_time_txt:I = 0x7f0a23a3

.field public static final startindex_morepro_title:I = 0x7f0a23a4

.field public static final state_layout:I = 0x7f0a23a7

.field public static final state_view:I = 0x7f0a23a9

.field public static final state_view_base_info_vf:I = 0x7f0a23aa

.field public static final state_view_container:I = 0x7f0a23ad

.field public static final state_view_content:I = 0x7f0a23ae

.field public static final state_view_content_card:I = 0x7f0a23af

.field public static final state_view_loading_anim:I = 0x7f0a23b0

.field public static final state_view_msg:I = 0x7f0a23b1

.field public static final state_view_page_loading:I = 0x7f0a23b2

.field public static final state_view_refresh_btn:I = 0x7f0a23b3

.field public static final state_view_report_btn:I = 0x7f0a23b4

.field public static final state_view_retry_btn:I = 0x7f0a23b5

.field public static final state_view_status_bar_space:I = 0x7f0a23b6

.field public static final state_view_tip:I = 0x7f0a23b7

.field public static final state_view_title_bar:I = 0x7f0a23b8

.field public static final state_view_title_bar_back:I = 0x7f0a23b9

.field public static final state_view_title_bar_back_container:I = 0x7f0a23ba

.field public static final state_view_title_bar_tv:I = 0x7f0a23bb

.field public static final state_view_top_skeleton:I = 0x7f0a23bc

.field public static final state_view_top_skeleton_row_one:I = 0x7f0a23bd

.field public static final state_view_top_skeleton_row_two:I = 0x7f0a23be

.field public static final state_view_want_see_header_bg:I = 0x7f0a23bf

.field public static final statemanager_button:I = 0x7f0a23c0

.field public static final statemanager_hint:I = 0x7f0a23c1

.field public static final statemanager_img:I = 0x7f0a23c2

.field public static final statemanager_img_pioneer:I = 0x7f0a23c3

.field public static final statemanager_loading:I = 0x7f0a23c4

.field public static final statemanager_loading_dm_normal:I = 0x7f0a23c5

.field public static final statemanager_loading_webp:I = 0x7f0a23c6

.field public static final statemanager_right_button:I = 0x7f0a23c7

.field public static final statemanager_subhint:I = 0x7f0a23c8

.field public static final statemanager_top_holder:I = 0x7f0a23c9

.field public static final staticLayout:I = 0x7f0a23ca

.field public static final staticPostLayout:I = 0x7f0a23cb

.field public static final status:I = 0x7f0a23cc

.field public static final statusText:I = 0x7f0a23cd

.field public static final status_bar:I = 0x7f0a23ce

.field public static final status_bar_bg_immersive:I = 0x7f0a23cf

.field public static final status_bar_gap:I = 0x7f0a23d0

.field public static final status_bar_latest_event_content:I = 0x7f0a23d2

.field public static final status_bar_space:I = 0x7f0a23d3

.field public static final status_desc:I = 0x7f0a23d4

.field public static final status_icon:I = 0x7f0a23d5

.field public static final status_img:I = 0x7f0a23d6

.field public static final status_info:I = 0x7f0a23d7

.field public static final status_space:I = 0x7f0a23da

.field public static final step1_tv:I = 0x7f0a23dd

.field public static final step2_tv:I = 0x7f0a23de

.field public static final step3_tv:I = 0x7f0a23df

.field public static final step_content_layout:I = 0x7f0a23e0

.field public static final step_layout:I = 0x7f0a23e1

.field public static final sticky:I = 0x7f0a23e2

.field public static final sticky_feed_tab:I = 0x7f0a23e3

.field public static final sticky_header:I = 0x7f0a23e4

.field public static final sticky_header_new:I = 0x7f0a23e5

.field public static final stop:I = 0x7f0a23e9

.field public static final stretch:I = 0x7f0a23ec

.field public static final stroke:I = 0x7f0a23ed

.field public static final stub_filter_brand_pop_container:I = 0x7f0a23ee

.field public static final stub_filter_brand_pop_container_pioneer:I = 0x7f0a23ef

.field public static final stvAddress:I = 0x7f0a23f1

.field public static final subTitle:I = 0x7f0a23f2

.field public static final subTitle_v2:I = 0x7f0a23f3

.field public static final sub_content:I = 0x7f0a23f4

.field public static final sub_desc:I = 0x7f0a23f5

.field public static final sub_reply_content:I = 0x7f0a23f7

.field public static final sub_reply_line:I = 0x7f0a23f8

.field public static final sub_title:I = 0x7f0a23fa

.field public static final sub_title_txt:I = 0x7f0a23ff

.field public static final submenuarrow:I = 0x7f0a2402

.field public static final submit:I = 0x7f0a2403

.field public static final submit_area:I = 0x7f0a2404

.field public static final submit_btn:I = 0x7f0a2405

.field public static final submit_loading:I = 0x7f0a2408

.field public static final submit_report:I = 0x7f0a2409

.field public static final submit_tx:I = 0x7f0a240a

.field public static final subreply_layout:I = 0x7f0a240b

.field public static final subtitle:I = 0x7f0a240c

.field public static final success_container:I = 0x7f0a240d

.field public static final success_container_bg:I = 0x7f0a240e

.field public static final success_desc_tv:I = 0x7f0a240f

.field public static final success_image_desc:I = 0x7f0a2410

.field public static final summary_ai:I = 0x7f0a2411

.field public static final sun:I = 0x7f0a2412

.field public static final sunday:I = 0x7f0a2413

.field public static final surface:I = 0x7f0a241d

.field public static final surfaceView:I = 0x7f0a241e

.field public static final surprise_red_cost_context:I = 0x7f0a241f

.field public static final surprise_red_cost_price:I = 0x7f0a2420

.field public static final surprise_red_cost_price_tag:I = 0x7f0a2421

.field public static final surprise_red_coupon_bubble:I = 0x7f0a2422

.field public static final surprise_red_coupon_bubble_identity:I = 0x7f0a2423

.field public static final surprise_red_coupon_container:I = 0x7f0a2424

.field public static final surprise_red_coupon_img:I = 0x7f0a2425

.field public static final surprise_red_coupon_limit_amount:I = 0x7f0a2426

.field public static final surprise_red_coupon_price_container:I = 0x7f0a2427

.field public static final surprise_red_coupon_price_ll:I = 0x7f0a2428

.field public static final surprise_red_coupon_right_top_corner:I = 0x7f0a2429

.field public static final surprise_red_coupon_title:I = 0x7f0a242a

.field public static final surprise_red_exchange_btn:I = 0x7f0a242b

.field public static final surprise_red_exchange_cost:I = 0x7f0a242c

.field public static final surprise_red_exchange_iconf:I = 0x7f0a242d

.field public static final surprise_red_exchange_ll:I = 0x7f0a242e

.field public static final surprise_red_packet:I = 0x7f0a242f

.field public static final surprise_red_packet_cinemas:I = 0x7f0a2430

.field public static final surprise_red_packet_now_playing:I = 0x7f0a2432

.field public static final surprise_red_packet_schedule:I = 0x7f0a2433

.field public static final surprise_red_receive_btn:I = 0x7f0a2434

.field public static final surprise_red_receive_ll:I = 0x7f0a2435

.field public static final surprise_red_receive_lottie:I = 0x7f0a2436

.field public static final surprise_red_status:I = 0x7f0a2437

.field public static final surprise_red_title:I = 0x7f0a2438

.field public static final surprise_red_valid_date:I = 0x7f0a2439

.field public static final surprise_timer_play:I = 0x7f0a243a

.field public static final swipe_refresh:I = 0x7f0a243e

.field public static final switch_btn:I = 0x7f0a243f

.field public static final switch_next_day:I = 0x7f0a2442

.field public static final switch_schedule:I = 0x7f0a2447

.field public static final t_banner_img:I = 0x7f0a2449

.field public static final t_banner_join_count:I = 0x7f0a244a

.field public static final t_banner_tag:I = 0x7f0a244b

.field public static final t_banner_title:I = 0x7f0a244c

.field public static final t_banner_title_prefix:I = 0x7f0a244d

.field public static final tabMode:I = 0x7f0a244f

.field public static final tabName:I = 0x7f0a2450

.field public static final tab_ar:I = 0x7f0a2451

.field public static final tab_badge:I = 0x7f0a2452

.field public static final tab_bg_shadow:I = 0x7f0a2453

.field public static final tab_bg_subview:I = 0x7f0a2454

.field public static final tab_click_view:I = 0x7f0a2455

.field public static final tab_container:I = 0x7f0a2456

.field public static final tab_content:I = 0x7f0a2457

.field public static final tab_divider:I = 0x7f0a2458

.field public static final tab_group:I = 0x7f0a2459

.field public static final tab_group_scroll_view:I = 0x7f0a245a

.field public static final tab_home_text:I = 0x7f0a245b

.field public static final tab_icon:I = 0x7f0a245c

.field public static final tab_icon_lottie:I = 0x7f0a245d

.field public static final tab_image:I = 0x7f0a245e

.field public static final tab_indicator:I = 0x7f0a245f

.field public static final tab_indicator_lottie:I = 0x7f0a2460

.field public static final tab_layout:I = 0x7f0a2462

.field public static final tab_line:I = 0x7f0a2464

.field public static final tab_name:I = 0x7f0a2466

.field public static final tab_official:I = 0x7f0a2467

.field public static final tab_real:I = 0x7f0a2468

.field public static final tab_scan:I = 0x7f0a2469

.field public static final tab_tag_img:I = 0x7f0a246a

.field public static final tab_tag_lottie:I = 0x7f0a246b

.field public static final tab_temp_cover_img:I = 0x7f0a246c

.field public static final tab_temp_cover_img_ui:I = 0x7f0a246d

.field public static final tab_text:I = 0x7f0a246e

.field public static final tab_user:I = 0x7f0a2473

.field public static final tabbar_reselected_img:I = 0x7f0a2475

.field public static final tabbar_selected_img:I = 0x7f0a2476

.field public static final table_left_sub_text:I = 0x7f0a2477

.field public static final table_left_text:I = 0x7f0a2478

.field public static final table_right_text:I = 0x7f0a2479

.field public static final tag:I = 0x7f0a247a

.field public static final tag_accessibility_actions:I = 0x7f0a247b

.field public static final tag_accessibility_clickable_spans:I = 0x7f0a247c

.field public static final tag_accessibility_heading:I = 0x7f0a247d

.field public static final tag_accessibility_pane_title:I = 0x7f0a247e

.field public static final tag_base_line:I = 0x7f0a247f

.field public static final tag_container:I = 0x7f0a2480

.field public static final tag_iconfont:I = 0x7f0a2481

.field public static final tag_lay:I = 0x7f0a2482

.field public static final tag_layout_helper_bg:I = 0x7f0a2484

.field public static final tag_name:I = 0x7f0a2485

.field public static final tag_nested_target_view:I = 0x7f0a2486

.field public static final tag_on_apply_window_listener:I = 0x7f0a2487

.field public static final tag_on_receive_content_listener:I = 0x7f0a2488

.field public static final tag_on_receive_content_mime_types:I = 0x7f0a2489

.field public static final tag_pic_data:I = 0x7f0a248b

.field public static final tag_position:I = 0x7f0a248c

.field public static final tag_saved_child_recycler_view:I = 0x7f0a248d

.field public static final tag_screen_reader_focusable:I = 0x7f0a248e

.field public static final tag_sku_seat_image_title:I = 0x7f0a248f

.field public static final tag_sku_seat_image_uri:I = 0x7f0a2490

.field public static final tag_state_description:I = 0x7f0a2491

.field public static final tag_text_view:I = 0x7f0a2492

.field public static final tag_title_right_enable:I = 0x7f0a2493

.field public static final tag_transition_group:I = 0x7f0a2494

.field public static final tag_txt:I = 0x7f0a2496

.field public static final tag_unhandled_key_event_manager:I = 0x7f0a2497

.field public static final tag_unhandled_key_listeners:I = 0x7f0a2498

.field public static final tag_video_palyer_ui_eable:I = 0x7f0a2499

.field public static final tag_view:I = 0x7f0a249a

.field public static final tag_view_bg:I = 0x7f0a249b

.field public static final tag_view_name:I = 0x7f0a249c

.field public static final tag_window_insets_animation_callback:I = 0x7f0a249d

.field public static final tags:I = 0x7f0a249e

.field public static final take_model_parent:I = 0x7f0a249f

.field public static final take_photo:I = 0x7f0a24a0

.field public static final take_photo_background_img:I = 0x7f0a24a1

.field public static final take_photo_portrait_img:I = 0x7f0a24a2

.field public static final task1_container:I = 0x7f0a24a8

.field public static final task1_desc:I = 0x7f0a24a9

.field public static final task1_name:I = 0x7f0a24aa

.field public static final task2_container:I = 0x7f0a24ab

.field public static final task2_desc:I = 0x7f0a24ac

.field public static final task2_name:I = 0x7f0a24ad

.field public static final task3_container:I = 0x7f0a24ae

.field public static final task3_desc:I = 0x7f0a24af

.field public static final task3_name:I = 0x7f0a24b0

.field public static final tb_fragment_host:I = 0x7f0a24b7

.field public static final teris_page_bottombar:I = 0x7f0a24be

.field public static final teris_page_empty_img:I = 0x7f0a24bf

.field public static final teris_page_empty_tv:I = 0x7f0a24c0

.field public static final teris_page_empty_view:I = 0x7f0a24c1

.field public static final teris_page_irecyclerview:I = 0x7f0a24c2

.field public static final test_btn:I = 0x7f0a24c5

.field public static final test_calendar:I = 0x7f0a24c6

.field public static final test_checkbox_android_button_tint:I = 0x7f0a24c7

.field public static final test_checkbox_app_button_tint:I = 0x7f0a24c8

.field public static final test_radiobutton_android_button_tint:I = 0x7f0a24c9

.field public static final test_radiobutton_app_button_tint:I = 0x7f0a24ca

.field public static final tetris_bannerdefault_title:I = 0x7f0a24cb

.field public static final tetris_layer_default_pager:I = 0x7f0a24cc

.field public static final tetris_layer_gap_bg:I = 0x7f0a24cd

.field public static final tetris_layer_gap_radius:I = 0x7f0a24ce

.field public static final tetris_layer_wrapper_title:I = 0x7f0a24cf

.field public static final tetris_recycler_container:I = 0x7f0a24d0

.field public static final tetris_root_container:I = 0x7f0a24d1

.field public static final text:I = 0x7f0a24d2

.field public static final text2:I = 0x7f0a24d3

.field public static final text2_with_icon:I = 0x7f0a24d4

.field public static final textSpacerNoButtons:I = 0x7f0a24d6

.field public static final textSpacerNoTitle:I = 0x7f0a24d7

.field public static final textStart:I = 0x7f0a24d8

.field public static final textView:I = 0x7f0a24db

.field public static final textView4:I = 0x7f0a24dc

.field public static final textView5:I = 0x7f0a24dd

.field public static final textView_obtain_more:I = 0x7f0a24de

.field public static final text_button:I = 0x7f0a24e0

.field public static final text_colored_text:I = 0x7f0a24e1

.field public static final text_content:I = 0x7f0a24e2

.field public static final text_huaju:I = 0x7f0a24e4

.field public static final text_icon:I = 0x7f0a24e5

.field public static final text_input_end_icon:I = 0x7f0a24e6

.field public static final text_input_error_icon:I = 0x7f0a24e7

.field public static final text_input_start_icon:I = 0x7f0a24e8

.field public static final text_lay:I = 0x7f0a24e9

.field public static final text_line1:I = 0x7f0a24eb

.field public static final text_line2:I = 0x7f0a24ec

.field public static final text_name:I = 0x7f0a24ed

.field public static final text_share:I = 0x7f0a24f3

.field public static final text_subTitle:I = 0x7f0a24f4

.field public static final text_title:I = 0x7f0a24f6

.field public static final text_title_pic:I = 0x7f0a24f7

.field public static final textinput_counter:I = 0x7f0a24f8

.field public static final textinput_error:I = 0x7f0a24f9

.field public static final textinput_helper_text:I = 0x7f0a24fa

.field public static final textinput_placeholder:I = 0x7f0a24fb

.field public static final textinput_prefix_text:I = 0x7f0a24fc

.field public static final textinput_suffix_text:I = 0x7f0a24fd

.field public static final texture:I = 0x7f0a24fe

.field public static final textureView:I = 0x7f0a24ff

.field public static final theEndView:I = 0x7f0a2500

.field public static final theme_article_text:I = 0x7f0a2502

.field public static final theme_banner:I = 0x7f0a2503

.field public static final theme_banner_img:I = 0x7f0a2504

.field public static final theme_circle_bg_image:I = 0x7f0a2507

.field public static final theme_circle_desc_v2:I = 0x7f0a2508

.field public static final theme_circle_join:I = 0x7f0a250a

.field public static final theme_circle_join_icon:I = 0x7f0a250b

.field public static final theme_circle_name:I = 0x7f0a250c

.field public static final theme_circle_person_info:I = 0x7f0a250d

.field public static final theme_circle_title_cms_bar:I = 0x7f0a250f

.field public static final theme_circle_vote_bg:I = 0x7f0a2510

.field public static final theme_circle_vote_img:I = 0x7f0a2511

.field public static final theme_circle_vote_layout:I = 0x7f0a2512

.field public static final theme_circle_vote_tag:I = 0x7f0a2513

.field public static final theme_content_num:I = 0x7f0a2514

.field public static final theme_content_tip:I = 0x7f0a2515

.field public static final theme_des:I = 0x7f0a2516

.field public static final theme_discuss_view:I = 0x7f0a2518

.field public static final theme_image_container:I = 0x7f0a251b

.field public static final theme_image_ui:I = 0x7f0a251c

.field public static final theme_img:I = 0x7f0a251d

.field public static final theme_img_hw_ratio_layout:I = 0x7f0a251e

.field public static final theme_img_hw_stroke_layout:I = 0x7f0a251f

.field public static final theme_img_layout:I = 0x7f0a2520

.field public static final theme_indicator:I = 0x7f0a2521

.field public static final theme_ipvuv_num:I = 0x7f0a2522

.field public static final theme_ipvuv_tip:I = 0x7f0a2523

.field public static final theme_media_container:I = 0x7f0a2524

.field public static final theme_mutiple_image_layout:I = 0x7f0a2525

.field public static final theme_price_tag:I = 0x7f0a252e

.field public static final theme_project_btn:I = 0x7f0a252f

.field public static final theme_project_rec:I = 0x7f0a2530

.field public static final theme_project_ui:I = 0x7f0a2531

.field public static final theme_rank_count_down_ui:I = 0x7f0a2533

.field public static final theme_rank_day_num:I = 0x7f0a2534

.field public static final theme_rank_day_text:I = 0x7f0a2535

.field public static final theme_rank_end:I = 0x7f0a2536

.field public static final theme_rank_hour_num:I = 0x7f0a2537

.field public static final theme_rank_hour_text:I = 0x7f0a2538

.field public static final theme_rank_lv:I = 0x7f0a2539

.field public static final theme_rank_minute_num:I = 0x7f0a253a

.field public static final theme_rank_minute_text:I = 0x7f0a253b

.field public static final theme_rank_second_num:I = 0x7f0a253c

.field public static final theme_rank_second_text:I = 0x7f0a253d

.field public static final theme_rank_view_stub:I = 0x7f0a253e

.field public static final theme_text:I = 0x7f0a253f

.field public static final theme_title:I = 0x7f0a2540

.field public static final theme_title_bar:I = 0x7f0a2541

.field public static final theme_watch_info:I = 0x7f0a2542

.field public static final third_line:I = 0x7f0a2544

.field public static final third_party:I = 0x7f0a2545

.field public static final thumbnails_iv:I = 0x7f0a2547

.field public static final thursday:I = 0x7f0a2548

.field public static final ticket_area_card_title_bar_view:I = 0x7f0a254c

.field public static final ticket_area_card_view:I = 0x7f0a254d

.field public static final ticket_area_top_background_img:I = 0x7f0a254e

.field public static final ticket_btn:I = 0x7f0a2550

.field public static final ticket_btn_hint:I = 0x7f0a2551

.field public static final ticket_card_performImageUrl:I = 0x7f0a2553

.field public static final ticket_card_projectName:I = 0x7f0a2554

.field public static final ticket_card_showTimeStr:I = 0x7f0a2555

.field public static final ticket_card_skuInfo_package:I = 0x7f0a2556

.field public static final ticket_card_venueName:I = 0x7f0a2557

.field public static final ticket_code:I = 0x7f0a2558

.field public static final ticket_gb_qrcode_container:I = 0x7f0a255f

.field public static final ticket_gb_qrcode_des:I = 0x7f0a2560

.field public static final ticket_gb_qrcode_error_block:I = 0x7f0a2561

.field public static final ticket_gb_qrcode_error_block_btn:I = 0x7f0a2562

.field public static final ticket_gb_qrcode_error_block_des:I = 0x7f0a2563

.field public static final ticket_gb_qrcode_error_block_icon:I = 0x7f0a2564

.field public static final ticket_gb_qrcode_info_code:I = 0x7f0a2565

.field public static final ticket_gb_qrcode_info_status:I = 0x7f0a2566

.field public static final ticket_gb_qrcode_leftarrow:I = 0x7f0a2567

.field public static final ticket_gb_qrcode_rightarrow:I = 0x7f0a2568

.field public static final ticket_gb_qrcode_tip:I = 0x7f0a2569

.field public static final ticket_icon:I = 0x7f0a256c

.field public static final ticket_remind_qr_code_container:I = 0x7f0a2575

.field public static final ticket_remind_qr_code_gb_block:I = 0x7f0a2576

.field public static final ticket_remind_qr_code_indicator:I = 0x7f0a2577

.field public static final ticket_remind_qr_code_indicator_gbcode:I = 0x7f0a2578

.field public static final ticket_remind_qr_code_indicator_ticket:I = 0x7f0a2579

.field public static final ticket_resultContent:I = 0x7f0a257a

.field public static final ticket_result_description:I = 0x7f0a257b

.field public static final ticket_result_description_layout:I = 0x7f0a257c

.field public static final ticket_success_lottie_view:I = 0x7f0a2592

.field public static final ticklet_alert_bottom_layout:I = 0x7f0a259e

.field public static final ticklet_alert_layout:I = 0x7f0a259f

.field public static final ticklet_alert_text:I = 0x7f0a25a0

.field public static final ticklet_alert_top_icon_bg:I = 0x7f0a25a1

.field public static final ticklet_header_notice_icon:I = 0x7f0a25f7

.field public static final ticklet_perform_name:I = 0x7f0a2658

.field public static final ticklet_perform_popwindow_bottom_layout:I = 0x7f0a265a

.field public static final ticklet_perform_popwindow_layout:I = 0x7f0a265b

.field public static final ticklet_perform_popwindow_top_layout:I = 0x7f0a265c

.field public static final ticklet_perform_showtime:I = 0x7f0a265e

.field public static final ticklet_perform_type_card_layout:I = 0x7f0a2661

.field public static final ticklet_perform_type_qrcode_layout:I = 0x7f0a2662

.field public static final ticklet_project_color_mask_bg:I = 0x7f0a2663

.field public static final ticklet_project_divide_view:I = 0x7f0a2664

.field public static final ticklet_project_goto_detail:I = 0x7f0a2665

.field public static final ticklet_project_item_card:I = 0x7f0a2666

.field public static final ticklet_project_item_card_bg:I = 0x7f0a2667

.field public static final ticklet_project_name:I = 0x7f0a2668

.field public static final ticklet_project_project_image:I = 0x7f0a2669

.field public static final ticklet_project_project_image_bottom_bg1:I = 0x7f0a266a

.field public static final ticklet_project_project_image_bottom_bg2:I = 0x7f0a266b

.field public static final ticklet_project_time:I = 0x7f0a266c

.field public static final ticklet_project_top_layout:I = 0x7f0a266d

.field public static final ticklet_project_venue_name:I = 0x7f0a266e

.field public static final ticklet_ticket_right_arrow:I = 0x7f0a2694

.field public static final time:I = 0x7f0a26fc

.field public static final time_area:I = 0x7f0a26fd

.field public static final time_contain:I = 0x7f0a2700

.field public static final time_container:I = 0x7f0a2701

.field public static final time_current:I = 0x7f0a2702

.field public static final time_filter:I = 0x7f0a2703

.field public static final time_line_bottom:I = 0x7f0a2705

.field public static final time_line_middle:I = 0x7f0a2706

.field public static final time_line_title:I = 0x7f0a2707

.field public static final time_line_top:I = 0x7f0a2708

.field public static final time_line_top_tag:I = 0x7f0a2709

.field public static final time_seekbar:I = 0x7f0a270a

.field public static final time_type_container:I = 0x7f0a270b

.field public static final timer:I = 0x7f0a270d

.field public static final timerTV:I = 0x7f0a270e

.field public static final timerTV2:I = 0x7f0a270f

.field public static final timer_text_view:I = 0x7f0a2710

.field public static final tip:I = 0x7f0a2712

.field public static final tipTextView:I = 0x7f0a2713

.field public static final tip_content:I = 0x7f0a2714

.field public static final tip_grade:I = 0x7f0a2715

.field public static final tip_icon:I = 0x7f0a2716

.field public static final tip_iv:I = 0x7f0a2717

.field public static final tip_message_container:I = 0x7f0a2719

.field public static final tip_message_container_ll:I = 0x7f0a271a

.field public static final tip_message_num_tv:I = 0x7f0a271b

.field public static final tip_right_arrow:I = 0x7f0a271d

.field public static final tip_right_button:I = 0x7f0a271e

.field public static final tip_tv:I = 0x7f0a2721

.field public static final tip_view:I = 0x7f0a2722

.field public static final tip_wheel_container:I = 0x7f0a2723

.field public static final tip_zone:I = 0x7f0a2724

.field public static final tips:I = 0x7f0a2725

.field public static final tips1:I = 0x7f0a2726

.field public static final tips2:I = 0x7f0a2727

.field public static final tips3:I = 0x7f0a2728

.field public static final tips4:I = 0x7f0a2729

.field public static final tips_container:I = 0x7f0a272a

.field public static final tips_right_btn:I = 0x7f0a272b

.field public static final tips_sub:I = 0x7f0a272c

.field public static final tips_text:I = 0x7f0a272d

.field public static final title:I = 0x7f0a272e

.field public static final titleDividerNoCustom:I = 0x7f0a272f

.field public static final titlePreIcon:I = 0x7f0a2730

.field public static final titleTxt:I = 0x7f0a2731

.field public static final titleView:I = 0x7f0a2732

.field public static final title_back_btn:I = 0x7f0a2733

.field public static final title_background:I = 0x7f0a2734

.field public static final title_bar:I = 0x7f0a2735

.field public static final title_bar_city:I = 0x7f0a2736

.field public static final title_bar_city_arrow:I = 0x7f0a2737

.field public static final title_bar_city_block:I = 0x7f0a2738

.field public static final title_bar_city_divider:I = 0x7f0a2739

.field public static final title_bar_space:I = 0x7f0a273c

.field public static final title_bar_space_view:I = 0x7f0a273d

.field public static final title_bg:I = 0x7f0a273f

.field public static final title_bg_layout:I = 0x7f0a2740

.field public static final title_container:I = 0x7f0a2741

.field public static final title_content:I = 0x7f0a2742

.field public static final title_filter:I = 0x7f0a2743

.field public static final title_icon:I = 0x7f0a2744

.field public static final title_image:I = 0x7f0a2745

.field public static final title_lay:I = 0x7f0a2746

.field public static final title_layout:I = 0x7f0a2748

.field public static final title_left_icon:I = 0x7f0a2749

.field public static final title_line:I = 0x7f0a274a

.field public static final title_mask_view:I = 0x7f0a274b

.field public static final title_more_rank_btn:I = 0x7f0a274c

.field public static final title_navbar_attention:I = 0x7f0a274e

.field public static final title_navbar_report:I = 0x7f0a274f

.field public static final title_navbar_share:I = 0x7f0a2750

.field public static final title_navbar_title:I = 0x7f0a2751

.field public static final title_right_image:I = 0x7f0a2754

.field public static final title_share_btn:I = 0x7f0a2758

.field public static final title_template:I = 0x7f0a275a

.field public static final title_text:I = 0x7f0a275b

.field public static final title_tv:I = 0x7f0a275d

.field public static final title_tv_block:I = 0x7f0a275e

.field public static final title_tv_block_filter:I = 0x7f0a275f

.field public static final title_txt:I = 0x7f0a2760

.field public static final title_v2:I = 0x7f0a2761

.field public static final title_wannasee_btn:I = 0x7f0a2762

.field public static final title_zone:I = 0x7f0a2763

.field public static final titlebar:I = 0x7f0a2764

.field public static final titlebar_button:I = 0x7f0a2765

.field public static final titlebar_button_inner:I = 0x7f0a2766

.field public static final titlebar_image:I = 0x7f0a2767

.field public static final titlebar_left_btn:I = 0x7f0a2768

.field public static final titlebar_left_btn2:I = 0x7f0a2769

.field public static final titlebar_left_container:I = 0x7f0a276a

.field public static final titlebar_right_btn:I = 0x7f0a276b

.field public static final titlebar_right_btn2:I = 0x7f0a276c

.field public static final titlebar_right_btn3:I = 0x7f0a276d

.field public static final titlebar_title:I = 0x7f0a276e

.field public static final titlebar_title_container:I = 0x7f0a276f

.field public static final titlr_container:I = 0x7f0a2770

.field public static final tm_view_id_fast_click:I = 0x7f0a277a

.field public static final tm_vip_top_layout:I = 0x7f0a277b

.field public static final toast_custom_iv:I = 0x7f0a278a

.field public static final toast_custom_tv:I = 0x7f0a278b

.field public static final toast_lottie_view:I = 0x7f0a278c

.field public static final toast_lottie_view_v2:I = 0x7f0a278d

.field public static final toast_message:I = 0x7f0a278e

.field public static final toast_sub_title_v2:I = 0x7f0a278f

.field public static final toast_title:I = 0x7f0a2790

.field public static final toast_title_v2:I = 0x7f0a2791

.field public static final toolbar:I = 0x7f0a2794

.field public static final toolbar_layout:I = 0x7f0a2795

.field public static final top:I = 0x7f0a2796

.field public static final topBar:I = 0x7f0a2797

.field public static final topPanel:I = 0x7f0a2799

.field public static final top_area:I = 0x7f0a279b

.field public static final top_bar_wantsee_tip_close:I = 0x7f0a279c

.field public static final top_bg_image:I = 0x7f0a279e

.field public static final top_divider:I = 0x7f0a27a3

.field public static final top_layout:I = 0x7f0a27a4

.field public static final top_line:I = 0x7f0a27a5

.field public static final top_msg_txt:I = 0x7f0a27a7

.field public static final top_of_viewfinder:I = 0x7f0a27a8

.field public static final top_score_layout:I = 0x7f0a27a9

.field public static final top_score_layout_div:I = 0x7f0a27aa

.field public static final top_score_layout_left:I = 0x7f0a27ab

.field public static final top_score_layoutdiv:I = 0x7f0a27ac

.field public static final top_space:I = 0x7f0a27ad

.field public static final top_status_bar_space:I = 0x7f0a27ae

.field public static final top_tag:I = 0x7f0a27af

.field public static final top_view:I = 0x7f0a27b1

.field public static final topbar_line:I = 0x7f0a27b2

.field public static final topic_icon:I = 0x7f0a27b4

.field public static final topic_image:I = 0x7f0a27b5

.field public static final torch_image_view:I = 0x7f0a27bb

.field public static final torch_tips_view:I = 0x7f0a27bc

.field public static final total_price:I = 0x7f0a27bd

.field public static final touchLayout:I = 0x7f0a27bf

.field public static final touch_auto_view:I = 0x7f0a27c0

.field public static final touch_outside:I = 0x7f0a27c1

.field public static final tour_city_bottom_container:I = 0x7f0a27c2

.field public static final tour_city_center_container:I = 0x7f0a27c3

.field public static final tour_city_top_container:I = 0x7f0a27c9

.field public static final tour_city_view_bg_center:I = 0x7f0a27ca

.field public static final tour_filter_pager:I = 0x7f0a27cc

.field public static final tour_filter_tab:I = 0x7f0a27cd

.field public static final tour_more_arrow:I = 0x7f0a27cf

.field public static final tour_more_info:I = 0x7f0a27d0

.field public static final tour_more_line:I = 0x7f0a27d1

.field public static final tour_more_title:I = 0x7f0a27d2

.field public static final tour_project_container:I = 0x7f0a27d8

.field public static final tour_recyclerView:I = 0x7f0a27d9

.field public static final tour_space:I = 0x7f0a27da

.field public static final tourism_btn_name:I = 0x7f0a27dc

.field public static final tourism_line_address_name:I = 0x7f0a27dd

.field public static final tourism_line_distance:I = 0x7f0a27e0

.field public static final tourism_line_distance_layout:I = 0x7f0a27e1

.field public static final tourism_line_distance_line:I = 0x7f0a27e2

.field public static final tourism_line_gap:I = 0x7f0a27e3

.field public static final tourism_line_name:I = 0x7f0a27e4

.field public static final tourism_line_performance_layout:I = 0x7f0a27e6

.field public static final tourism_line_performance_name:I = 0x7f0a27e7

.field public static final tourism_line_performance_price_default:I = 0x7f0a27e8

.field public static final tourism_line_performance_price_view:I = 0x7f0a27e9

.field public static final tourism_line_performance_tag:I = 0x7f0a27ea

.field public static final tourism_line_performance_type:I = 0x7f0a27eb

.field public static final tourism_line_pic:I = 0x7f0a27ec

.field public static final tourism_line_price_default:I = 0x7f0a27ed

.field public static final tourism_line_price_label_ticket:I = 0x7f0a27ee

.field public static final tourism_line_price_layout:I = 0x7f0a27ef

.field public static final tourism_line_price_view:I = 0x7f0a27f0

.field public static final tourism_line_promotion_tag1:I = 0x7f0a27f1

.field public static final tourism_line_promotion_tag1_divider:I = 0x7f0a27f2

.field public static final tourism_line_promotion_tag2:I = 0x7f0a27f3

.field public static final tourism_line_promotion_tag2_divider:I = 0x7f0a27f4

.field public static final tourism_line_promotion_tag3:I = 0x7f0a27f5

.field public static final tourism_line_show_tag:I = 0x7f0a27f6

.field public static final tourism_line_show_tag_card:I = 0x7f0a27f7

.field public static final tourism_line_tag:I = 0x7f0a27f8

.field public static final tourism_line_type:I = 0x7f0a27f9

.field public static final tourism_line_type_pioneer:I = 0x7f0a27fa

.field public static final tourism_ranking_tab_container:I = 0x7f0a27fb

.field public static final tourism_ranking_tab_list:I = 0x7f0a27fc

.field public static final tourism_ranking_tab_title:I = 0x7f0a27fd

.field public static final tourism_ranking_tab_title_container:I = 0x7f0a27fe

.field public static final tourism_ranking_tab_title_huabian:I = 0x7f0a27ff

.field public static final tourism_ranking_tab_title_huabianfan:I = 0x7f0a2800

.field public static final tourism_ranking_vacation_package_container:I = 0x7f0a2801

.field public static final tourism_ranking_vacation_package_list:I = 0x7f0a2802

.field public static final tourism_ranking_vacation_package_title:I = 0x7f0a2803

.field public static final tourism_ranking_vacation_package_title_container:I = 0x7f0a2804

.field public static final tourism_spots_icon:I = 0x7f0a2805

.field public static final tourism_spots_layout:I = 0x7f0a2806

.field public static final tourism_spots_name:I = 0x7f0a2807

.field public static final tourism_spots_price_promotion:I = 0x7f0a2808

.field public static final tourism_spots_price_root_layout:I = 0x7f0a2809

.field public static final tourism_spots_price_view:I = 0x7f0a280a

.field public static final tourism_spots_tab_background:I = 0x7f0a280b

.field public static final tourism_spots_tag:I = 0x7f0a280c

.field public static final tourism_tab_jiantou:I = 0x7f0a280d

.field public static final tourism_tab_name_pic:I = 0x7f0a280e

.field public static final tourism_tab_name_text:I = 0x7f0a280f

.field public static final tpp_remark:I = 0x7f0a2810

.field public static final tpp_remark_divider:I = 0x7f0a2811

.field public static final tpp_third_party:I = 0x7f0a2812

.field public static final track_pick_btn:I = 0x7f0a2813

.field public static final track_result:I = 0x7f0a2814

.field public static final tracker_frameLayout:I = 0x7f0a2815

.field public static final tracker_frameLayout2:I = 0x7f0a2816

.field public static final trade_add_address_title_main_tv:I = 0x7f0a2817

.field public static final transition_current_scene:I = 0x7f0a2840

.field public static final transition_layout_save:I = 0x7f0a2843

.field public static final transition_position:I = 0x7f0a2844

.field public static final transition_scene_layoutid_cache:I = 0x7f0a2846

.field public static final transition_transform:I = 0x7f0a284a

.field public static final triangle:I = 0x7f0a2850

.field public static final trip_desc_float_arrow:I = 0x7f0a2851

.field public static final trip_desc_float_title:I = 0x7f0a2852

.field public static final trip_desc_float_view:I = 0x7f0a2853

.field public static final trip_desc_float_viewtv:I = 0x7f0a2854

.field public static final tuesday:I = 0x7f0a2855

.field public static final tv:I = 0x7f0a2856

.field public static final tvSearchTag:I = 0x7f0a2860

.field public static final tvSeatSubView:I = 0x7f0a2861

.field public static final tvSeatView:I = 0x7f0a2862

.field public static final tvSeatViewNewTip:I = 0x7f0a2863

.field public static final tvTextShadowLeft:I = 0x7f0a2864

.field public static final tvTextShadowRight:I = 0x7f0a2865

.field public static final tvTitle:I = 0x7f0a2866

.field public static final tvUpdatePercent:I = 0x7f0a2868

.field public static final tv_88Vip:I = 0x7f0a2869

.field public static final tv_action:I = 0x7f0a286c

.field public static final tv_action_btn:I = 0x7f0a286d

.field public static final tv_add_city_desc:I = 0x7f0a2872

.field public static final tv_add_main:I = 0x7f0a2874

.field public static final tv_address:I = 0x7f0a2875

.field public static final tv_address_des:I = 0x7f0a2876

.field public static final tv_address_freight_title:I = 0x7f0a2877

.field public static final tv_address_title:I = 0x7f0a2879

.field public static final tv_agree_mcard_protocol:I = 0x7f0a287a

.field public static final tv_album_common_footer:I = 0x7f0a287c

.field public static final tv_all:I = 0x7f0a287d

.field public static final tv_all_click_toall:I = 0x7f0a287e

.field public static final tv_amount:I = 0x7f0a287f

.field public static final tv_arrow:I = 0x7f0a2882

.field public static final tv_article_magic_comment_nickname:I = 0x7f0a2883

.field public static final tv_article_magic_comment_remark:I = 0x7f0a2884

.field public static final tv_article_magic_comment_remark_title:I = 0x7f0a2885

.field public static final tv_article_magic_date_title:I = 0x7f0a2886

.field public static final tv_article_magic_mark_title:I = 0x7f0a2887

.field public static final tv_article_more_magic_tip:I = 0x7f0a2888

.field public static final tv_article_video_duration:I = 0x7f0a2889

.field public static final tv_artistName:I = 0x7f0a288a

.field public static final tv_artist_desc:I = 0x7f0a288b

.field public static final tv_artist_name:I = 0x7f0a288c

.field public static final tv_auth_third_agreement:I = 0x7f0a2890

.field public static final tv_auth_third_btn:I = 0x7f0a2891

.field public static final tv_auth_third_detail:I = 0x7f0a2892

.field public static final tv_auth_third_title:I = 0x7f0a2893

.field public static final tv_author:I = 0x7f0a2894

.field public static final tv_begin_time:I = 0x7f0a2897

.field public static final tv_best_price_info:I = 0x7f0a289a

.field public static final tv_block_card_select_name:I = 0x7f0a289b

.field public static final tv_bottom_buy_tip:I = 0x7f0a289c

.field public static final tv_bottom_discount_item_action:I = 0x7f0a289d

.field public static final tv_bottom_discount_item_action_arrow:I = 0x7f0a289e

.field public static final tv_bottom_discount_item_action_text:I = 0x7f0a289f

.field public static final tv_bottom_discount_item_tip:I = 0x7f0a28a0

.field public static final tv_bottom_discount_item_tip_tag:I = 0x7f0a28a1

.field public static final tv_bottom_discount_item_tip_taggray:I = 0x7f0a28a2

.field public static final tv_broadcast:I = 0x7f0a28a5

.field public static final tv_bubble_hint:I = 0x7f0a28a7

.field public static final tv_buy:I = 0x7f0a28aa

.field public static final tv_calendar_month:I = 0x7f0a28ae

.field public static final tv_cancel:I = 0x7f0a28af

.field public static final tv_cancel_action:I = 0x7f0a28b0

.field public static final tv_cancle:I = 0x7f0a28b2

.field public static final tv_card_desc:I = 0x7f0a28b5

.field public static final tv_card_num_data:I = 0x7f0a28b9

.field public static final tv_card_num_tips:I = 0x7f0a28ba

.field public static final tv_card_tips:I = 0x7f0a28bb

.field public static final tv_card_type_data:I = 0x7f0a28bc

.field public static final tv_card_type_tip:I = 0x7f0a28bd

.field public static final tv_channel_brand_venue_name:I = 0x7f0a28c1

.field public static final tv_check:I = 0x7f0a28c2

.field public static final tv_cinema_name:I = 0x7f0a28c4

.field public static final tv_circle_hor_title:I = 0x7f0a28c6

.field public static final tv_circle_sub:I = 0x7f0a28c7

.field public static final tv_circle_title:I = 0x7f0a28c9

.field public static final tv_city:I = 0x7f0a28ca

.field public static final tv_city_name:I = 0x7f0a28cb

.field public static final tv_city_num:I = 0x7f0a28cc

.field public static final tv_close:I = 0x7f0a28cd

.field public static final tv_close_examples:I = 0x7f0a28ce

.field public static final tv_collapsedIcon:I = 0x7f0a28d1

.field public static final tv_colon1:I = 0x7f0a28d3

.field public static final tv_colon2:I = 0x7f0a28d4

.field public static final tv_colon3:I = 0x7f0a28d5

.field public static final tv_comment_action:I = 0x7f0a28d9

.field public static final tv_comment_des:I = 0x7f0a28db

.field public static final tv_comment_sub_title:I = 0x7f0a28dc

.field public static final tv_comment_title:I = 0x7f0a28df

.field public static final tv_confirm:I = 0x7f0a28eb

.field public static final tv_confirm_num:I = 0x7f0a28ec

.field public static final tv_content:I = 0x7f0a28ef

.field public static final tv_content_free_item_praise_num:I = 0x7f0a28f0

.field public static final tv_content_tag:I = 0x7f0a28f2

.field public static final tv_corner_desc:I = 0x7f0a28f3

.field public static final tv_cost:I = 0x7f0a28f7

.field public static final tv_cost2:I = 0x7f0a28f8

.field public static final tv_cost_coin:I = 0x7f0a28f9

.field public static final tv_cost_coin_img:I = 0x7f0a28fa

.field public static final tv_cost_coin_text:I = 0x7f0a28fb

.field public static final tv_count:I = 0x7f0a28fc

.field public static final tv_coupon_desc:I = 0x7f0a2909

.field public static final tv_coupon_detail:I = 0x7f0a290a

.field public static final tv_coupon_expired:I = 0x7f0a290b

.field public static final tv_coupon_list_block:I = 0x7f0a290c

.field public static final tv_coupon_member_lucky_des:I = 0x7f0a2913

.field public static final tv_coupon_name:I = 0x7f0a2914

.field public static final tv_coupon_name_sec:I = 0x7f0a2915

.field public static final tv_coupon_name_third:I = 0x7f0a2916

.field public static final tv_coupon_origin_price:I = 0x7f0a2919

.field public static final tv_coupon_reduce_name:I = 0x7f0a291c

.field public static final tv_coupon_select:I = 0x7f0a291d

.field public static final tv_coupon_status:I = 0x7f0a291e

.field public static final tv_coupon_sum:I = 0x7f0a291f

.field public static final tv_coupon_tip_arrow:I = 0x7f0a2922

.field public static final tv_coupon_tip_des:I = 0x7f0a2923

.field public static final tv_coupon_tips:I = 0x7f0a2924

.field public static final tv_cur_month:I = 0x7f0a292a

.field public static final tv_date:I = 0x7f0a292b

.field public static final tv_date_tip:I = 0x7f0a292c

.field public static final tv_date_title:I = 0x7f0a292d

.field public static final tv_day:I = 0x7f0a292f

.field public static final tv_day_tag:I = 0x7f0a2930

.field public static final tv_day_tag_holiday:I = 0x7f0a2931

.field public static final tv_day_tip:I = 0x7f0a2932

.field public static final tv_day_view_label:I = 0x7f0a2933

.field public static final tv_delete:I = 0x7f0a2935

.field public static final tv_des:I = 0x7f0a293e

.field public static final tv_desc:I = 0x7f0a293f

.field public static final tv_desc1:I = 0x7f0a2940

.field public static final tv_desc2:I = 0x7f0a2941

.field public static final tv_desc_line2:I = 0x7f0a2942

.field public static final tv_desc_num:I = 0x7f0a2943

.field public static final tv_desc_suffix:I = 0x7f0a2944

.field public static final tv_describe:I = 0x7f0a2945

.field public static final tv_detail_price:I = 0x7f0a2948

.field public static final tv_detail_title:I = 0x7f0a294c

.field public static final tv_dianying:I = 0x7f0a2951

.field public static final tv_discount:I = 0x7f0a2953

.field public static final tv_discount_base_score:I = 0x7f0a2954

.field public static final tv_discount_des:I = 0x7f0a2955

.field public static final tv_discount_hint_label:I = 0x7f0a2956

.field public static final tv_discount_num:I = 0x7f0a2957

.field public static final tv_discount_score:I = 0x7f0a2958

.field public static final tv_discount_seat_desc:I = 0x7f0a2959

.field public static final tv_discount_stock:I = 0x7f0a295a

.field public static final tv_discount_user_integral:I = 0x7f0a295c

.field public static final tv_distance:I = 0x7f0a295e

.field public static final tv_dm_name:I = 0x7f0a295f

.field public static final tv_dm_tag_1:I = 0x7f0a2960

.field public static final tv_dm_tag_2:I = 0x7f0a2961

.field public static final tv_dna_similarity:I = 0x7f0a2964

.field public static final tv_draw:I = 0x7f0a2965

.field public static final tv_draw_btn:I = 0x7f0a2966

.field public static final tv_draw_hint:I = 0x7f0a2967

.field public static final tv_duration:I = 0x7f0a2968

.field public static final tv_electronic_des:I = 0x7f0a296c

.field public static final tv_electronic_right:I = 0x7f0a296d

.field public static final tv_electronic_title:I = 0x7f0a296e

.field public static final tv_electronic_view:I = 0x7f0a296f

.field public static final tv_empty_content:I = 0x7f0a2971

.field public static final tv_end_time:I = 0x7f0a2973

.field public static final tv_equity_subtitle:I = 0x7f0a2974

.field public static final tv_equity_title:I = 0x7f0a2975

.field public static final tv_error_code:I = 0x7f0a2976

.field public static final tv_error_info:I = 0x7f0a2977

.field public static final tv_error_tip:I = 0x7f0a2978

.field public static final tv_exchange_btn:I = 0x7f0a297a

.field public static final tv_explain:I = 0x7f0a297c

.field public static final tv_ext_btn:I = 0x7f0a297f

.field public static final tv_fans_count:I = 0x7f0a2983

.field public static final tv_fans_icon_tip:I = 0x7f0a2984

.field public static final tv_feed_card_tag:I = 0x7f0a2986

.field public static final tv_feed_title:I = 0x7f0a2989

.field public static final tv_festival_price:I = 0x7f0a298a

.field public static final tv_film_msg:I = 0x7f0a2994

.field public static final tv_film_name:I = 0x7f0a2995

.field public static final tv_film_profile_item_image:I = 0x7f0a2997

.field public static final tv_film_profile_item_main_title:I = 0x7f0a2998

.field public static final tv_film_profile_item_sub_icon:I = 0x7f0a2999

.field public static final tv_film_profile_item_sub_title:I = 0x7f0a299a

.field public static final tv_finish:I = 0x7f0a299c

.field public static final tv_finish_exchange:I = 0x7f0a299d

.field public static final tv_finish_small:I = 0x7f0a299e

.field public static final tv_first:I = 0x7f0a299f

.field public static final tv_float_right_bottom_view:I = 0x7f0a29a0

.field public static final tv_folder_name:I = 0x7f0a29a3

.field public static final tv_folder_size:I = 0x7f0a29a4

.field public static final tv_follow:I = 0x7f0a29a5

.field public static final tv_follow_icon:I = 0x7f0a29a6

.field public static final tv_freight:I = 0x7f0a29a9

.field public static final tv_freight_label:I = 0x7f0a29aa

.field public static final tv_fresh_location:I = 0x7f0a29ab

.field public static final tv_fuhao:I = 0x7f0a29ac

.field public static final tv_gray_circle:I = 0x7f0a29b2

.field public static final tv_gridView_item_name:I = 0x7f0a29b3

.field public static final tv_happy_coin_num:I = 0x7f0a29b6

.field public static final tv_has_watched:I = 0x7f0a29b8

.field public static final tv_head_modify:I = 0x7f0a29b9

.field public static final tv_head_tips:I = 0x7f0a29ba

.field public static final tv_header_v:I = 0x7f0a29bc

.field public static final tv_hint:I = 0x7f0a29bd

.field public static final tv_home_remind_egg:I = 0x7f0a29c0

.field public static final tv_home_remind_egg_label:I = 0x7f0a29c1

.field public static final tv_home_remind_machine_tip:I = 0x7f0a29c2

.field public static final tv_home_remind_sale:I = 0x7f0a29c3

.field public static final tv_home_remind_sale_label:I = 0x7f0a29c4

.field public static final tv_home_remind_ticket:I = 0x7f0a29c5

.field public static final tv_home_remind_ticket_label:I = 0x7f0a29c6

.field public static final tv_home_remind_ticket_tip:I = 0x7f0a29c7

.field public static final tv_homepage_performance_more_title:I = 0x7f0a29c9

.field public static final tv_homepage_show_mark:I = 0x7f0a29cd

.field public static final tv_homepage_show_more_count:I = 0x7f0a29ce

.field public static final tv_homepage_show_more_divider:I = 0x7f0a29cf

.field public static final tv_homepage_show_more_title:I = 0x7f0a29d0

.field public static final tv_homepage_tab_top_right:I = 0x7f0a29d3

.field public static final tv_hour:I = 0x7f0a29d6

.field public static final tv_hour_suffix:I = 0x7f0a29d7

.field public static final tv_hours:I = 0x7f0a29d8

.field public static final tv_hui:I = 0x7f0a29d9

.field public static final tv_icon_arrow:I = 0x7f0a29db

.field public static final tv_index_info:I = 0x7f0a29e0

.field public static final tv_indicator:I = 0x7f0a29e1

.field public static final tv_info:I = 0x7f0a29e2

.field public static final tv_integral:I = 0x7f0a29e4

.field public static final tv_integral_discount:I = 0x7f0a29e5

.field public static final tv_integral_number:I = 0x7f0a29e6

.field public static final tv_ipinfo_tagbg:I = 0x7f0a2a0c

.field public static final tv_ipinfo_tagleft:I = 0x7f0a2a0d

.field public static final tv_ipinfo_tagright:I = 0x7f0a2a0e

.field public static final tv_ipvuv:I = 0x7f0a2a0f

.field public static final tv_item_choose:I = 0x7f0a2a12

.field public static final tv_item_subtitle:I = 0x7f0a2a13

.field public static final tv_item_title:I = 0x7f0a2a14

.field public static final tv_item_unit:I = 0x7f0a2a15

.field public static final tv_kssj_tip:I = 0x7f0a2a1b

.field public static final tv_license:I = 0x7f0a2a27

.field public static final tv_limit_num:I = 0x7f0a2a28

.field public static final tv_limit_num_title:I = 0x7f0a2a29

.field public static final tv_line1:I = 0x7f0a2a2b

.field public static final tv_line2:I = 0x7f0a2a2c

.field public static final tv_ll_member_pro_agree:I = 0x7f0a2a2e

.field public static final tv_ll_member_pro_cancel:I = 0x7f0a2a2f

.field public static final tv_ll_member_pro_content:I = 0x7f0a2a30

.field public static final tv_loading_des:I = 0x7f0a2a31

.field public static final tv_lottery:I = 0x7f0a2a35

.field public static final tv_magic_comment_content:I = 0x7f0a2a36

.field public static final tv_magic_comment_show_name:I = 0x7f0a2a37

.field public static final tv_magic_comment_shut_flag:I = 0x7f0a2a38

.field public static final tv_main_image_tag:I = 0x7f0a2a39

.field public static final tv_main_image_title:I = 0x7f0a2a3a

.field public static final tv_main_title:I = 0x7f0a2a3b

.field public static final tv_mark:I = 0x7f0a2a3c

.field public static final tv_mark_class:I = 0x7f0a2a3d

.field public static final tv_mark_holiday:I = 0x7f0a2a3e

.field public static final tv_mark_project:I = 0x7f0a2a3f

.field public static final tv_maxnum:I = 0x7f0a2a46

.field public static final tv_member_auth_checkbox_tip:I = 0x7f0a2a47

.field public static final tv_member_auth_protocol_desc:I = 0x7f0a2a48

.field public static final tv_member_auth_title:I = 0x7f0a2a49

.field public static final tv_milli:I = 0x7f0a2a4f

.field public static final tv_min_price:I = 0x7f0a2a52

.field public static final tv_min_price_bv:I = 0x7f0a2a53

.field public static final tv_min_price_fake:I = 0x7f0a2a54

.field public static final tv_min_price_fake_bv:I = 0x7f0a2a55

.field public static final tv_minute:I = 0x7f0a2a7c

.field public static final tv_minute_suffix:I = 0x7f0a2a7f

.field public static final tv_minutes:I = 0x7f0a2a80

.field public static final tv_modify:I = 0x7f0a2a82

.field public static final tv_money:I = 0x7f0a2a83

.field public static final tv_money_desc:I = 0x7f0a2a84

.field public static final tv_money_ll:I = 0x7f0a2a85

.field public static final tv_money_prefix:I = 0x7f0a2a88

.field public static final tv_more:I = 0x7f0a2a89

.field public static final tv_more_arrow:I = 0x7f0a2a8a

.field public static final tv_more_title:I = 0x7f0a2a8c

.field public static final tv_movie_name:I = 0x7f0a2a8d

.field public static final tv_movie_want_remark_left:I = 0x7f0a2a8e

.field public static final tv_movie_want_remark_right:I = 0x7f0a2a8f

.field public static final tv_msg:I = 0x7f0a2a90

.field public static final tv_multiple_hint:I = 0x7f0a2a94

.field public static final tv_multiple_times:I = 0x7f0a2a95

.field public static final tv_name:I = 0x7f0a2a97

.field public static final tv_name_data:I = 0x7f0a2a98

.field public static final tv_name_des:I = 0x7f0a2a99

.field public static final tv_name_tip:I = 0x7f0a2a9b

.field public static final tv_near_tip:I = 0x7f0a2a9d

.field public static final tv_nearby_low_price:I = 0x7f0a2a9e

.field public static final tv_nickname:I = 0x7f0a2aa3

.field public static final tv_not_enough:I = 0x7f0a2aa7

.field public static final tv_not_use_sum:I = 0x7f0a2aa8

.field public static final tv_notice:I = 0x7f0a2aa9

.field public static final tv_num:I = 0x7f0a2aaf

.field public static final tv_num_detail:I = 0x7f0a2ab0

.field public static final tv_num_tip:I = 0x7f0a2ab1

.field public static final tv_number:I = 0x7f0a2ab2

.field public static final tv_ok:I = 0x7f0a2ab3

.field public static final tv_open_location:I = 0x7f0a2ab5

.field public static final tv_open_notification:I = 0x7f0a2ab6

.field public static final tv_order:I = 0x7f0a2ab7

.field public static final tv_order_address_arrow:I = 0x7f0a2ab8

.field public static final tv_order_num:I = 0x7f0a2abe

.field public static final tv_order_state_des:I = 0x7f0a2aca

.field public static final tv_original_price:I = 0x7f0a2acd

.field public static final tv_over_amount:I = 0x7f0a2ace

.field public static final tv_package_ticket:I = 0x7f0a2acf

.field public static final tv_part:I = 0x7f0a2ad1

.field public static final tv_pay:I = 0x7f0a2ad4

.field public static final tv_pay_action:I = 0x7f0a2ad5

.field public static final tv_pay_amount:I = 0x7f0a2adb

.field public static final tv_pay_desc:I = 0x7f0a2adc

.field public static final tv_pay_option_select:I = 0x7f0a2adf

.field public static final tv_pay_status:I = 0x7f0a2ae3

.field public static final tv_pay_symbol:I = 0x7f0a2ae4

.field public static final tv_pay_title:I = 0x7f0a2ae6

.field public static final tv_people_comment:I = 0x7f0a2ae8

.field public static final tv_people_tip:I = 0x7f0a2ae9

.field public static final tv_perform_changetip:I = 0x7f0a2aec

.field public static final tv_perform_changetip_icon:I = 0x7f0a2aed

.field public static final tv_perform_des:I = 0x7f0a2aee

.field public static final tv_perform_name:I = 0x7f0a2aef

.field public static final tv_perform_time:I = 0x7f0a2af1

.field public static final tv_perform_time_detailstr:I = 0x7f0a2af2

.field public static final tv_perform_time_icon:I = 0x7f0a2af3

.field public static final tv_perform_tip:I = 0x7f0a2af4

.field public static final tv_phone:I = 0x7f0a2af6

.field public static final tv_phone_des:I = 0x7f0a2af7

.field public static final tv_phone_number:I = 0x7f0a2af8

.field public static final tv_positive_tag:I = 0x7f0a2b00

.field public static final tv_poster_show_mark:I = 0x7f0a2b01

.field public static final tv_poster_show_mark_img:I = 0x7f0a2b02

.field public static final tv_preferential:I = 0x7f0a2b03

.field public static final tv_preferential_tip:I = 0x7f0a2b04

.field public static final tv_preschedule_mark:I = 0x7f0a2b05

.field public static final tv_preview:I = 0x7f0a2b06

.field public static final tv_price:I = 0x7f0a2b07

.field public static final tv_price_coupon_package:I = 0x7f0a2b08

.field public static final tv_price_custom:I = 0x7f0a2b09

.field public static final tv_price_limit:I = 0x7f0a2b0a

.field public static final tv_price_name:I = 0x7f0a2b0b

.field public static final tv_price_normal:I = 0x7f0a2b0c

.field public static final tv_price_normal2:I = 0x7f0a2b0d

.field public static final tv_price_num:I = 0x7f0a2b0e

.field public static final tv_price_original_extend:I = 0x7f0a2b0f

.field public static final tv_price_pre:I = 0x7f0a2b10

.field public static final tv_price_preferential_extend:I = 0x7f0a2b11

.field public static final tv_price_prefix:I = 0x7f0a2b12

.field public static final tv_price_qi:I = 0x7f0a2b13

.field public static final tv_price_save:I = 0x7f0a2b14

.field public static final tv_price_save2:I = 0x7f0a2b15

.field public static final tv_price_suf:I = 0x7f0a2b16

.field public static final tv_price_suffix:I = 0x7f0a2b17

.field public static final tv_price_tag:I = 0x7f0a2b18

.field public static final tv_price_tip:I = 0x7f0a2b19

.field public static final tv_profit_desc:I = 0x7f0a2b1f

.field public static final tv_progress_dialog_label:I = 0x7f0a2b20

.field public static final tv_project:I = 0x7f0a2b21

.field public static final tv_project_address_info_block:I = 0x7f0a2b22

.field public static final tv_project_artist_mark:I = 0x7f0a2b23

.field public static final tv_project_city:I = 0x7f0a2b24

.field public static final tv_project_comment:I = 0x7f0a2b26

.field public static final tv_project_dis:I = 0x7f0a2b29

.field public static final tv_project_dis_divider:I = 0x7f0a2b2a

.field public static final tv_project_dis_pioneer:I = 0x7f0a2b2b

.field public static final tv_project_extra_benefit_action:I = 0x7f0a2b2d

.field public static final tv_project_extra_benefit_desc:I = 0x7f0a2b2e

.field public static final tv_project_extra_benefit_icon:I = 0x7f0a2b2f

.field public static final tv_project_follow_desc:I = 0x7f0a2b30

.field public static final tv_project_follow_desc_divider:I = 0x7f0a2b31

.field public static final tv_project_ipuv_suffix:I = 0x7f0a2b33

.field public static final tv_project_name:I = 0x7f0a2b35

.field public static final tv_project_num:I = 0x7f0a2b36

.field public static final tv_project_num_v2:I = 0x7f0a2b37

.field public static final tv_project_price:I = 0x7f0a2b38

.field public static final tv_project_price_confirm:I = 0x7f0a2b39

.field public static final tv_project_price_label:I = 0x7f0a2b3c

.field public static final tv_project_price_view:I = 0x7f0a2b40

.field public static final tv_project_rank:I = 0x7f0a2b41

.field public static final tv_project_rank_mark:I = 0x7f0a2b42

.field public static final tv_project_site:I = 0x7f0a2b45

.field public static final tv_project_status:I = 0x7f0a2b46

.field public static final tv_project_time:I = 0x7f0a2b47

.field public static final tv_project_tip:I = 0x7f0a2b49

.field public static final tv_project_title:I = 0x7f0a2b4a

.field public static final tv_project_tourDesc:I = 0x7f0a2b4b

.field public static final tv_project_tourName:I = 0x7f0a2b4c

.field public static final tv_project_venueName:I = 0x7f0a2b4d

.field public static final tv_promotion_tag:I = 0x7f0a2b4e

.field public static final tv_promotion_text:I = 0x7f0a2b4f

.field public static final tv_promotion_text_line:I = 0x7f0a2b50

.field public static final tv_qi:I = 0x7f0a2b52

.field public static final tv_qq:I = 0x7f0a2b53

.field public static final tv_quehuo:I = 0x7f0a2b56

.field public static final tv_quehuo_sanjiao:I = 0x7f0a2b57

.field public static final tv_rank_list_title:I = 0x7f0a2b5b

.field public static final tv_rank_title:I = 0x7f0a2b5e

.field public static final tv_rating_num_desc:I = 0x7f0a2b5f

.field public static final tv_reader_number:I = 0x7f0a2b60

.field public static final tv_reduce_score:I = 0x7f0a2b65

.field public static final tv_reduce_tag:I = 0x7f0a2b66

.field public static final tv_refund_change_content:I = 0x7f0a2b68

.field public static final tv_refund_change_title:I = 0x7f0a2b69

.field public static final tv_refund_endorse_tips:I = 0x7f0a2b6a

.field public static final tv_register_tip:I = 0x7f0a2b6c

.field public static final tv_remark:I = 0x7f0a2b6d

.field public static final tv_remark_people:I = 0x7f0a2b6e

.field public static final tv_remark_title:I = 0x7f0a2b6f

.field public static final tv_remark_title_lite:I = 0x7f0a2b70

.field public static final tv_renewal:I = 0x7f0a2b71

.field public static final tv_renewal_number_data:I = 0x7f0a2b72

.field public static final tv_renewal_number_tips:I = 0x7f0a2b73

.field public static final tv_reopen_mark:I = 0x7f0a2b74

.field public static final tv_report:I = 0x7f0a2b79

.field public static final tv_reward:I = 0x7f0a2b86

.field public static final tv_reward_detail:I = 0x7f0a2b87

.field public static final tv_right:I = 0x7f0a2b88

.field public static final tv_rule_detail:I = 0x7f0a2b89

.field public static final tv_rule_item:I = 0x7f0a2b8a

.field public static final tv_rule_title:I = 0x7f0a2b8b

.field public static final tv_sale_hint:I = 0x7f0a2b8d

.field public static final tv_sale_name:I = 0x7f0a2b8f

.field public static final tv_sale_price:I = 0x7f0a2b90

.field public static final tv_sale_remind:I = 0x7f0a2b91

.field public static final tv_sale_status:I = 0x7f0a2b92

.field public static final tv_sale_tag:I = 0x7f0a2b93

.field public static final tv_sales_status:I = 0x7f0a2b94

.field public static final tv_saving_schedule:I = 0x7f0a2b95

.field public static final tv_schedule_coupon_luck_get:I = 0x7f0a2b97

.field public static final tv_schedule_coupon_luck_name:I = 0x7f0a2b98

.field public static final tv_schedule_coupon_luck_tag:I = 0x7f0a2b99

.field public static final tv_score:I = 0x7f0a2b9a

.field public static final tv_score_icon_tip:I = 0x7f0a2b9d

.field public static final tv_score_want_ext_tv:I = 0x7f0a2ba2

.field public static final tv_script_coupon_price:I = 0x7f0a2ba4

.field public static final tv_script_score:I = 0x7f0a2ba6

.field public static final tv_seat_img:I = 0x7f0a2ba8

.field public static final tv_seat_text:I = 0x7f0a2bab

.field public static final tv_second:I = 0x7f0a2bad

.field public static final tv_seconds:I = 0x7f0a2bb2

.field public static final tv_see_people_num:I = 0x7f0a2bb5

.field public static final tv_see_people_num_v2:I = 0x7f0a2bb6

.field public static final tv_select:I = 0x7f0a2bb8

.field public static final tv_select_num:I = 0x7f0a2bb9

.field public static final tv_select_perform_tip:I = 0x7f0a2bba

.field public static final tv_select_price_detail:I = 0x7f0a2bbb

.field public static final tv_select_seat_bogo_dialog_title:I = 0x7f0a2bbc

.field public static final tv_select_seat_bogo_new_button:I = 0x7f0a2bbd

.field public static final tv_select_seat_bogo_new_contain:I = 0x7f0a2bbe

.field public static final tv_select_seat_bogo_new_tip:I = 0x7f0a2bbf

.field public static final tv_select_seat_bogo_new_title:I = 0x7f0a2bc0

.field public static final tv_select_seat_contain_item_msg:I = 0x7f0a2bc1

.field public static final tv_select_tip:I = 0x7f0a2bc4

.field public static final tv_senior_vip_integral:I = 0x7f0a2bd4

.field public static final tv_senior_vip_integral_base:I = 0x7f0a2bd5

.field public static final tv_senior_vip_integral_number:I = 0x7f0a2bd6

.field public static final tv_share:I = 0x7f0a2bd9

.field public static final tv_share_icon:I = 0x7f0a2bda

.field public static final tv_shengyu_fen:I = 0x7f0a2bdd

.field public static final tv_shengyu_fen_tip:I = 0x7f0a2bde

.field public static final tv_shengyu_hour_tip:I = 0x7f0a2bdf

.field public static final tv_shengyu_xiaoshi:I = 0x7f0a2be0

.field public static final tv_shenhua:I = 0x7f0a2be1

.field public static final tv_show_all:I = 0x7f0a2be3

.field public static final tv_show_open_time:I = 0x7f0a2be9

.field public static final tv_size:I = 0x7f0a2bef

.field public static final tv_sku_price_prefix:I = 0x7f0a2bf0

.field public static final tv_sku_state_view_base_info_des:I = 0x7f0a2bf1

.field public static final tv_sku_state_view_base_info_title:I = 0x7f0a2bf2

.field public static final tv_socre_desc:I = 0x7f0a2bf5

.field public static final tv_special_buyer_tag:I = 0x7f0a2bf6

.field public static final tv_special_tag:I = 0x7f0a2bf7

.field public static final tv_spring_dialog_button_bottom_desc:I = 0x7f0a2bfb

.field public static final tv_spring_dialog_button_desc:I = 0x7f0a2bfc

.field public static final tv_spring_dialog_button_origin_price:I = 0x7f0a2bfd

.field public static final tv_spring_dialog_subtitle:I = 0x7f0a2bfe

.field public static final tv_spring_open_card_cancel:I = 0x7f0a2bff

.field public static final tv_spring_open_card_dialog_tag:I = 0x7f0a2c00

.field public static final tv_spring_open_card_dialog_tip:I = 0x7f0a2c01

.field public static final tv_spring_open_card_title:I = 0x7f0a2c02

.field public static final tv_status:I = 0x7f0a2c0a

.field public static final tv_stock:I = 0x7f0a2c0b

.field public static final tv_strong_guide:I = 0x7f0a2c0d

.field public static final tv_sub_arrow:I = 0x7f0a2c10

.field public static final tv_sub_title:I = 0x7f0a2c15

.field public static final tv_subhint:I = 0x7f0a2c16

.field public static final tv_subtitle:I = 0x7f0a2c17

.field public static final tv_subtitle_v2:I = 0x7f0a2c18

.field public static final tv_switch_gesture:I = 0x7f0a2c1c

.field public static final tv_tab:I = 0x7f0a2c1d

.field public static final tv_tag:I = 0x7f0a2c20

.field public static final tv_tag_name:I = 0x7f0a2c21

.field public static final tv_tag_name_prefix:I = 0x7f0a2c22

.field public static final tv_tag_new:I = 0x7f0a2c24

.field public static final tv_take_photo_hint:I = 0x7f0a2c25

.field public static final tv_text:I = 0x7f0a2c27

.field public static final tv_ticket_des:I = 0x7f0a2c2e

.field public static final tv_ticket_info:I = 0x7f0a2c32

.field public static final tv_ticket_price:I = 0x7f0a2c37

.field public static final tv_ticket_sub_des:I = 0x7f0a2c3a

.field public static final tv_time:I = 0x7f0a2c3f

.field public static final tv_time1:I = 0x7f0a2c40

.field public static final tv_time2:I = 0x7f0a2c42

.field public static final tv_time3:I = 0x7f0a2c44

.field public static final tv_time4:I = 0x7f0a2c46

.field public static final tv_time_start:I = 0x7f0a2c49

.field public static final tv_time_suffix:I = 0x7f0a2c4a

.field public static final tv_time_tip:I = 0x7f0a2c4c

.field public static final tv_timer_day:I = 0x7f0a2c4d

.field public static final tv_timer_day_mark:I = 0x7f0a2c4e

.field public static final tv_timer_hour:I = 0x7f0a2c4f

.field public static final tv_timer_hour_label:I = 0x7f0a2c50

.field public static final tv_timer_min:I = 0x7f0a2c51

.field public static final tv_timer_min_label:I = 0x7f0a2c52

.field public static final tv_timer_sec:I = 0x7f0a2c53

.field public static final tv_timer_sec_label:I = 0x7f0a2c54

.field public static final tv_timer_suffix:I = 0x7f0a2c55

.field public static final tv_tip:I = 0x7f0a2c56

.field public static final tv_tip_container:I = 0x7f0a2c57

.field public static final tv_tips:I = 0x7f0a2c59

.field public static final tv_tips_content:I = 0x7f0a2c5a

.field public static final tv_tips_title:I = 0x7f0a2c5b

.field public static final tv_title:I = 0x7f0a2c5c

.field public static final tv_title_coupon_package:I = 0x7f0a2c5e

.field public static final tv_title_date:I = 0x7f0a2c5f

.field public static final tv_title_name:I = 0x7f0a2c62

.field public static final tv_title_pioneer:I = 0x7f0a2c64

.field public static final tv_title_v2:I = 0x7f0a2c69

.field public static final tv_title_video:I = 0x7f0a2c6a

.field public static final tv_tm_right_profit_action:I = 0x7f0a2c6b

.field public static final tv_tm_right_profit_desc:I = 0x7f0a2c6c

.field public static final tv_tm_right_profit_icon:I = 0x7f0a2c6d

.field public static final tv_top_notice:I = 0x7f0a2c76

.field public static final tv_top_notice2:I = 0x7f0a2c77

.field public static final tv_top_tag:I = 0x7f0a2c79

.field public static final tv_top_tips:I = 0x7f0a2c7a

.field public static final tv_total:I = 0x7f0a2c7b

.field public static final tv_total_coin:I = 0x7f0a2c7c

.field public static final tv_union_desc:I = 0x7f0a2c88

.field public static final tv_union_receive:I = 0x7f0a2c89

.field public static final tv_union_title:I = 0x7f0a2c8a

.field public static final tv_union_use_tip:I = 0x7f0a2c8b

.field public static final tv_unit:I = 0x7f0a2c8c

.field public static final tv_unit2:I = 0x7f0a2c8d

.field public static final tv_use_action:I = 0x7f0a2c8f

.field public static final tv_use_integral:I = 0x7f0a2c90

.field public static final tv_user_date:I = 0x7f0a2c92

.field public static final tv_user_dna_value:I = 0x7f0a2c93

.field public static final tv_user_name:I = 0x7f0a2c96

.field public static final tv_user_title:I = 0x7f0a2c98

.field public static final tv_valid_timer:I = 0x7f0a2c99

.field public static final tv_venue:I = 0x7f0a2c9a

.field public static final tv_venue_dis:I = 0x7f0a2c9b

.field public static final tv_verify_code:I = 0x7f0a2c9c

.field public static final tv_video_remind_text:I = 0x7f0a2c9e

.field public static final tv_video_select:I = 0x7f0a2c9f

.field public static final tv_video_showing_hot:I = 0x7f0a2ca0

.field public static final tv_vip_desc:I = 0x7f0a2ca5

.field public static final tv_vip_tag:I = 0x7f0a2ca7

.field public static final tv_voice_duration:I = 0x7f0a2ca8

.field public static final tv_want_count:I = 0x7f0a2cab

.field public static final tv_want_count_index:I = 0x7f0a2cad

.field public static final tv_want_count_title:I = 0x7f0a2cae

.field public static final tv_want_see_btn:I = 0x7f0a2cb1

.field public static final tv_weak_guide:I = 0x7f0a2cb8

.field public static final tv_week:I = 0x7f0a2cb9

.field public static final tv_weibo:I = 0x7f0a2cba

.field public static final tv_weixin:I = 0x7f0a2cbb

.field public static final tv_weizhifu_tip:I = 0x7f0a2cbc

.field public static final tv_word:I = 0x7f0a2cbe

.field public static final tv_word_count:I = 0x7f0a2cbf

.field public static final tv_word_total:I = 0x7f0a2cc0

.field public static final tv_xuxian3:I = 0x7f0a2cc1

.field public static final tv_yc_code:I = 0x7f0a2cc3

.field public static final tv_yc_code_title:I = 0x7f0a2cc4

.field public static final tv_yixiajia:I = 0x7f0a2cc5

.field public static final tv_youku_right:I = 0x7f0a2cca

.field public static final tv_youku_right2:I = 0x7f0a2ccb

.field public static final tv_yushou:I = 0x7f0a2ccd

.field public static final tv_yushou_sanjiao:I = 0x7f0a2cce

.field public static final tx_feed_error_msg:I = 0x7f0a2cd1

.field public static final txt:I = 0x7f0a2cd2

.field public static final txt_hall_tip:I = 0x7f0a2cd3

.field public static final txt_icon:I = 0x7f0a2cd4

.field public static final txt_info:I = 0x7f0a2cd5

.field public static final txt_sub:I = 0x7f0a2cd6

.field public static final type:I = 0x7f0a2cd7

.field public static final type_container:I = 0x7f0a2cd8

.field public static final type_divider:I = 0x7f0a2cd9

.field public static final uik_load_more_footer_progress:I = 0x7f0a2cdf

.field public static final uik_load_more_footer_text:I = 0x7f0a2ce0

.field public static final uik_refresh_header:I = 0x7f0a2ce1

.field public static final uik_refresh_header_fl:I = 0x7f0a2ce2

.field public static final uik_refresh_header_progress1:I = 0x7f0a2ce3

.field public static final uik_refresh_header_progress2:I = 0x7f0a2ce4

.field public static final uik_refresh_header_progress3:I = 0x7f0a2ce5

.field public static final uik_refresh_header_second_floor:I = 0x7f0a2ce6

.field public static final uik_refresh_header_view:I = 0x7f0a2ce7

.field public static final uikit_damai_avatar:I = 0x7f0a2ce8

.field public static final uikit_damai_avatar_border:I = 0x7f0a2ce9

.field public static final uikit_damai_avatar_crown:I = 0x7f0a2cea

.field public static final uikit_damai_avatar_image:I = 0x7f0a2ceb

.field public static final uikit_damai_avatar_inner_border:I = 0x7f0a2cec

.field public static final uikit_damai_avatar_layout:I = 0x7f0a2ced

.field public static final uikit_damai_avatar_placeholder:I = 0x7f0a2cee

.field public static final uikit_damai_avatar_v_tag:I = 0x7f0a2cef

.field public static final uikit_damai_avatar_yymember_tag:I = 0x7f0a2cf0

.field public static final uikit_first:I = 0x7f0a2cf1

.field public static final uikit_hori_project_img:I = 0x7f0a2cf2

.field public static final uikit_hori_project_info:I = 0x7f0a2cf3

.field public static final uikit_hori_project_price:I = 0x7f0a2cf4

.field public static final uikit_hori_project_title:I = 0x7f0a2cf5

.field public static final uikit_live_icon:I = 0x7f0a2cf6

.field public static final uikit_load_more_loading_icon:I = 0x7f0a2cf7

.field public static final uikit_load_more_loading_tip:I = 0x7f0a2cf8

.field public static final uikit_loading_icon:I = 0x7f0a2cf9

.field public static final uikit_tag_view_name:I = 0x7f0a2cfa

.field public static final unchecked:I = 0x7f0a2d00

.field public static final underline:I = 0x7f0a2d01

.field public static final uniform:I = 0x7f0a2d02

.field public static final union_card_item:I = 0x7f0a2d03

.field public static final union_check:I = 0x7f0a2d04

.field public static final union_desc:I = 0x7f0a2d05

.field public static final union_dvd:I = 0x7f0a2d06

.field public static final union_tip:I = 0x7f0a2d07

.field public static final union_title:I = 0x7f0a2d08

.field public static final unit:I = 0x7f0a2d09

.field public static final unit_text:I = 0x7f0a2d0a

.field public static final unlabeled:I = 0x7f0a2d0b

.field public static final unlogin_name:I = 0x7f0a2d0c

.field public static final up:I = 0x7f0a2d0e

.field public static final upcoming_btn_zone:I = 0x7f0a2d0f

.field public static final update_button_accept:I = 0x7f0a2d10

.field public static final update_button_cancel:I = 0x7f0a2d11

.field public static final update_contentDialog:I = 0x7f0a2d12

.field public static final update_dialog_content:I = 0x7f0a2d13

.field public static final update_dialog_rootView:I = 0x7f0a2d14

.field public static final update_message:I = 0x7f0a2d15

.field public static final update_rootDialog:I = 0x7f0a2d16

.field public static final update_title:I = 0x7f0a2d17

.field public static final upload:I = 0x7f0a2d18

.field public static final useLogo:I = 0x7f0a2d1a

.field public static final use_citypass_desc:I = 0x7f0a2d1b

.field public static final use_citypass_title:I = 0x7f0a2d1c

.field public static final use_guide_desc:I = 0x7f0a2d1d

.field public static final used_phone:I = 0x7f0a2d1e

.field public static final user_add_comment_location:I = 0x7f0a2d1f

.field public static final user_add_comment_time:I = 0x7f0a2d20

.field public static final user_center_empty_publish_btn:I = 0x7f0a2d27

.field public static final user_center_empty_publish_btn_pioneer:I = 0x7f0a2d28

.field public static final user_desc:I = 0x7f0a2d40

.field public static final user_feature:I = 0x7f0a2d44

.field public static final user_head:I = 0x7f0a2d4e

.field public static final user_head_1:I = 0x7f0a2d4f

.field public static final user_head_1_layout:I = 0x7f0a2d50

.field public static final user_head_2:I = 0x7f0a2d51

.field public static final user_head_2_layout:I = 0x7f0a2d52

.field public static final user_head_3:I = 0x7f0a2d53

.field public static final user_head_3_layout:I = 0x7f0a2d54

.field public static final user_head_pic:I = 0x7f0a2d55

.field public static final user_head_single:I = 0x7f0a2d56

.field public static final user_head_single_name:I = 0x7f0a2d57

.field public static final user_head_tag:I = 0x7f0a2d58

.field public static final user_header_back:I = 0x7f0a2d59

.field public static final user_icon:I = 0x7f0a2d5b

.field public static final user_icon_container:I = 0x7f0a2d5c

.field public static final user_icon_dmavatar:I = 0x7f0a2d5d

.field public static final user_icon_right_margin:I = 0x7f0a2d60

.field public static final user_iv_header:I = 0x7f0a2d64

.field public static final user_level:I = 0x7f0a2d65

.field public static final user_name:I = 0x7f0a2d67

.field public static final user_name_bottom_margin:I = 0x7f0a2d68

.field public static final user_nick:I = 0x7f0a2d69

.field public static final user_nick_layout:I = 0x7f0a2d6a

.field public static final user_nick_line:I = 0x7f0a2d6b

.field public static final user_nickname:I = 0x7f0a2d6c

.field public static final user_old_vip_tag_view:I = 0x7f0a2d6d

.field public static final user_prefix1:I = 0x7f0a2d6f

.field public static final user_prefix2:I = 0x7f0a2d70

.field public static final user_project_list:I = 0x7f0a2d72

.field public static final user_ratingbar:I = 0x7f0a2d78

.field public static final user_role:I = 0x7f0a2d79

.field public static final user_score:I = 0x7f0a2d7a

.field public static final user_star_b_headerbg:I = 0x7f0a2d7d

.field public static final user_star_b_headerbg_cover:I = 0x7f0a2d7e

.field public static final user_student_tag:I = 0x7f0a2d7f

.field public static final user_tag_view:I = 0x7f0a2d81

.field public static final user_title:I = 0x7f0a2d93

.field public static final user_title_sub:I = 0x7f0a2d94

.field public static final user_tv_fanscout:I = 0x7f0a2d97

.field public static final user_tv_fansdesc:I = 0x7f0a2d98

.field public static final user_tv_name:I = 0x7f0a2d9a

.field public static final user_tv_showcout:I = 0x7f0a2d9d

.field public static final user_tv_showdesc:I = 0x7f0a2d9e

.field public static final user_tv_showdesc_div:I = 0x7f0a2d9f

.field public static final ut_feature_id:I = 0x7f0a2da3

.field public static final vPager:I = 0x7f0a2da4

.field public static final v_badge:I = 0x7f0a2da5

.field public static final v_dm_tag_line:I = 0x7f0a2da7

.field public static final v_home_remind_no_code_deliver:I = 0x7f0a2da8

.field public static final v_left_location:I = 0x7f0a2daa

.field public static final v_line:I = 0x7f0a2dac

.field public static final v_luck_poster_top_pic:I = 0x7f0a2dae

.field public static final v_outside:I = 0x7f0a2db0

.field public static final v_schedule_tip_line:I = 0x7f0a2db3

.field public static final v_select_seat_contain_item_icon:I = 0x7f0a2db4

.field public static final v_spring_open_card_dialog_tip_bottom:I = 0x7f0a2db6

.field public static final v_ticket_remind_birthday:I = 0x7f0a2db7

.field public static final v_ticket_remind_birthday_ballon:I = 0x7f0a2db8

.field public static final valid_date:I = 0x7f0a2db9

.field public static final valid_date_tag:I = 0x7f0a2dba

.field public static final valid_show_btn:I = 0x7f0a2dbb

.field public static final vd_bottom_line:I = 0x7f0a2dbc

.field public static final vd_top_line:I = 0x7f0a2dbd

.field public static final venue:I = 0x7f0a2dbe

.field public static final venue_basic_info_gradient_downline:I = 0x7f0a2dc1

.field public static final venue_basic_info_gradient_upline:I = 0x7f0a2dc2

.field public static final venue_cell_address:I = 0x7f0a2dc3

.field public static final venue_cell_address_div:I = 0x7f0a2dc4

.field public static final venue_cell_avatar_avatar:I = 0x7f0a2dc5

.field public static final venue_cell_avatar_layout_child:I = 0x7f0a2dc6

.field public static final venue_cell_center_layout:I = 0x7f0a2dca

.field public static final venue_cell_coupon_item:I = 0x7f0a2dcb

.field public static final venue_cell_dis:I = 0x7f0a2dcc

.field public static final venue_cell_empty_tv:I = 0x7f0a2dcd

.field public static final venue_cell_fans_and_show:I = 0x7f0a2dce

.field public static final venue_cell_icon:I = 0x7f0a2dcf

.field public static final venue_cell_list:I = 0x7f0a2dd0

.field public static final venue_cell_name:I = 0x7f0a2dd1

.field public static final venue_cell_right_attention:I = 0x7f0a2dd2

.field public static final venue_cell_right_attention_tv:I = 0x7f0a2dd3

.field public static final venue_cell_right_attentionll:I = 0x7f0a2dd4

.field public static final venue_cell_sellitem:I = 0x7f0a2dd5

.field public static final venue_cell_top_layout:I = 0x7f0a2dd6

.field public static final venue_cell_top_layout_ll:I = 0x7f0a2dd7

.field public static final venue_distance:I = 0x7f0a2dd9

.field public static final venue_distance_icon:I = 0x7f0a2dda

.field public static final venue_follow_tips_image:I = 0x7f0a2ddc

.field public static final venue_info_block:I = 0x7f0a2dde

.field public static final venue_info_block_lay:I = 0x7f0a2ddf

.field public static final venue_ka_card_banner:I = 0x7f0a2de0

.field public static final venue_ka_card_banner_layout:I = 0x7f0a2de1

.field public static final venue_ka_card_type_tag:I = 0x7f0a2de2

.field public static final venue_ka_count_info_lay:I = 0x7f0a2de3

.field public static final venue_ka_divider:I = 0x7f0a2de4

.field public static final venue_ka_fans:I = 0x7f0a2de5

.field public static final venue_ka_fans_count:I = 0x7f0a2de6

.field public static final venue_ka_go_to_home:I = 0x7f0a2de7

.field public static final venue_ka_performance:I = 0x7f0a2de8

.field public static final venue_ka_performance_count:I = 0x7f0a2de9

.field public static final venue_ka_promotion_desc:I = 0x7f0a2dea

.field public static final venue_ka_promotion_float_icon:I = 0x7f0a2deb

.field public static final venue_ka_promotion_lay:I = 0x7f0a2dec

.field public static final venue_ka_vip_tag:I = 0x7f0a2ded

.field public static final venue_location:I = 0x7f0a2def

.field public static final venue_name:I = 0x7f0a2df2

.field public static final venue_tag_base_info_bg:I = 0x7f0a2df5

.field public static final venue_tag_image:I = 0x7f0a2df6

.field public static final verify_send_code:I = 0x7f0a2e08

.field public static final version_arrow:I = 0x7f0a2e0a

.field public static final version_line:I = 0x7f0a2e0b

.field public static final version_more_txt:I = 0x7f0a2e0c

.field public static final vertical:I = 0x7f0a2e0d

.field public static final vertical_down:I = 0x7f0a2e0e

.field public static final vertical_only:I = 0x7f0a2e10

.field public static final vertical_up:I = 0x7f0a2e11

.field public static final vid_edittext:I = 0x7f0a2e14

.field public static final video_container:I = 0x7f0a2e1a

.field public static final video_cover:I = 0x7f0a2e1b

.field public static final video_duration:I = 0x7f0a2e1d

.field public static final video_duration_lay:I = 0x7f0a2e1e

.field public static final video_error_refresh:I = 0x7f0a2e1f

.field public static final video_error_tips:I = 0x7f0a2e20

.field public static final video_error_ui:I = 0x7f0a2e21

.field public static final video_go:I = 0x7f0a2e22

.field public static final video_hw_3_4:I = 0x7f0a2e23

.field public static final video_hw_9_16:I = 0x7f0a2e24

.field public static final video_icon:I = 0x7f0a2e25

.field public static final video_icon_old:I = 0x7f0a2e26

.field public static final video_image:I = 0x7f0a2e27

.field public static final video_image_browse_back_tv:I = 0x7f0a2e28

.field public static final video_image_browse_position_tv:I = 0x7f0a2e29

.field public static final video_image_browse_title_bar:I = 0x7f0a2e2a

.field public static final video_image_browse_viewer:I = 0x7f0a2e2b

.field public static final video_image_info_rv:I = 0x7f0a2e2c

.field public static final video_image_intro_tv:I = 0x7f0a2e2d

.field public static final video_irc:I = 0x7f0a2e2e

.field public static final video_loading:I = 0x7f0a2e2f

.field public static final video_play:I = 0x7f0a2e30

.field public static final video_player:I = 0x7f0a2e31

.field public static final video_project:I = 0x7f0a2e32

.field public static final video_project_address:I = 0x7f0a2e33

.field public static final video_project_img:I = 0x7f0a2e34

.field public static final video_project_name:I = 0x7f0a2e35

.field public static final video_project_see_project:I = 0x7f0a2e36

.field public static final video_project_time:I = 0x7f0a2e37

.field public static final video_tag:I = 0x7f0a2e38

.field public static final video_tag_bg:I = 0x7f0a2e39

.field public static final video_tag_view:I = 0x7f0a2e3a

.field public static final video_title:I = 0x7f0a2e3b

.field public static final video_view:I = 0x7f0a2e3c

.field public static final video_voice_btn:I = 0x7f0a2e3d

.field public static final view:I = 0x7f0a2e3e

.field public static final view3:I = 0x7f0a2e3f

.field public static final view_bg:I = 0x7f0a2e40

.field public static final view_bottom:I = 0x7f0a2e43

.field public static final view_bottom_down:I = 0x7f0a2e44

.field public static final view_bottom_line1:I = 0x7f0a2e45

.field public static final view_bottom_up:I = 0x7f0a2e46

.field public static final view_btn1:I = 0x7f0a2e47

.field public static final view_btn2:I = 0x7f0a2e48

.field public static final view_calendar:I = 0x7f0a2e49

.field public static final view_calendar_pager:I = 0x7f0a2e4a

.field public static final view_cover:I = 0x7f0a2e4d

.field public static final view_id_fast_click:I = 0x7f0a2e50

.field public static final view_jiantou:I = 0x7f0a2e51

.field public static final view_line:I = 0x7f0a2e53

.field public static final view_line2:I = 0x7f0a2e54

.field public static final view_long_select:I = 0x7f0a2e56

.field public static final view_long_select_inner:I = 0x7f0a2e57

.field public static final view_manual_calculate:I = 0x7f0a2e58

.field public static final view_mask:I = 0x7f0a2e59

.field public static final view_null:I = 0x7f0a2e5c

.field public static final view_offset_helper:I = 0x7f0a2e5d

.field public static final view_order_bg:I = 0x7f0a2e5e

.field public static final view_pager:I = 0x7f0a2e5f

.field public static final view_pager2_album:I = 0x7f0a2e60

.field public static final view_pager_indicator:I = 0x7f0a2e61

.field public static final view_part:I = 0x7f0a2e62

.field public static final view_profile_stroke:I = 0x7f0a2e63

.field public static final view_scroll_location:I = 0x7f0a2e65

.field public static final view_shedule_item_time:I = 0x7f0a2e66

.field public static final view_stub_time_filter:I = 0x7f0a2e68

.field public static final view_tag_num:I = 0x7f0a2e69

.field public static final view_title_line:I = 0x7f0a2e6a

.field public static final view_top:I = 0x7f0a2e6b

.field public static final view_transition:I = 0x7f0a2e6d

.field public static final view_translucent:I = 0x7f0a2e6e

.field public static final view_tree_lifecycle_owner:I = 0x7f0a2e6f

.field public static final view_tree_on_back_pressed_dispatcher_owner:I = 0x7f0a2e70

.field public static final view_tree_saved_state_registry_owner:I = 0x7f0a2e71

.field public static final view_tree_view_model_store_owner:I = 0x7f0a2e72

.field public static final viewpager:I = 0x7f0a2e76

.field public static final vip_card_bottom_text:I = 0x7f0a2e77

.field public static final vip_card_top_flag:I = 0x7f0a2e78

.field public static final vip_card_top_info:I = 0x7f0a2e79

.field public static final vip_card_top_value:I = 0x7f0a2e7a

.field public static final vip_card_typeimg:I = 0x7f0a2e7b

.field public static final vip_exchange_entrance_view:I = 0x7f0a2e7c

.field public static final vip_first_buy_tag:I = 0x7f0a2e7d

.field public static final vip_level_bg:I = 0x7f0a2e7e

.field public static final vip_new_tips:I = 0x7f0a2e81

.field public static final vip_origin_price:I = 0x7f0a2e82

.field public static final vip_tag:I = 0x7f0a2e83

.field public static final vip_text_name:I = 0x7f0a2e84

.field public static final vip_text_switcher:I = 0x7f0a2e85

.field public static final vip_top_space:I = 0x7f0a2e87

.field public static final vip_ui_btn:I = 0x7f0a2e88

.field public static final vip_ui_layout:I = 0x7f0a2e89

.field public static final visible:I = 0x7f0a2e8e

.field public static final visible_removing_fragment_view_tag:I = 0x7f0a2e8f

.field public static final voice_thinking:I = 0x7f0a2e90

.field public static final vote_select_count:I = 0x7f0a2e92

.field public static final vote_select_item_container:I = 0x7f0a2e93

.field public static final vote_select_title:I = 0x7f0a2e94

.field public static final vote_title_layout:I = 0x7f0a2e95

.field public static final vp_image:I = 0x7f0a2e98

.field public static final vp_month:I = 0x7f0a2e99

.field public static final wanna_2_see_icon:I = 0x7f0a2ea0

.field public static final want_card_container:I = 0x7f0a2ea4

.field public static final want_card_tour_city_view:I = 0x7f0a2ea5

.field public static final want_container:I = 0x7f0a2ea6

.field public static final want_guide_lottie:I = 0x7f0a2ea9

.field public static final want_lottie_icon:I = 0x7f0a2eaa

.field public static final want_see:I = 0x7f0a2eab

.field public static final want_see__bottombar_tip_subtitle:I = 0x7f0a2eac

.field public static final want_see__bottombar_tip_texttop:I = 0x7f0a2ead

.field public static final want_see_animate_icon:I = 0x7f0a2eae

.field public static final want_see_bottombar_tip_arrow:I = 0x7f0a2eb0

.field public static final want_see_bottombar_tip_bg:I = 0x7f0a2eb1

.field public static final want_see_bottombar_tip_close:I = 0x7f0a2eb2

.field public static final want_see_btn:I = 0x7f0a2eb3

.field public static final want_see_des:I = 0x7f0a2eb4

.field public static final want_see_fairy_lottie:I = 0x7f0a2eb6

.field public static final want_see_guide_close:I = 0x7f0a2eb7

.field public static final want_see_guide_subtitle:I = 0x7f0a2eb8

.field public static final want_see_guide_title:I = 0x7f0a2eba

.field public static final want_see_ll:I = 0x7f0a2ebc

.field public static final want_see_num_text:I = 0x7f0a2ebd

.field public static final want_see_poster:I = 0x7f0a2ec1

.field public static final want_see_poster_arrow:I = 0x7f0a2ec2

.field public static final want_see_poster_bg:I = 0x7f0a2ec3

.field public static final want_see_poster_close:I = 0x7f0a2ec4

.field public static final want_see_poster_img:I = 0x7f0a2ec5

.field public static final want_see_poster_subtitle:I = 0x7f0a2ec6

.field public static final want_see_poster_tips:I = 0x7f0a2ec7

.field public static final want_see_poster_title:I = 0x7f0a2ec8

.field public static final want_see_poster_title_suffix:I = 0x7f0a2ec9

.field public static final want_see_recommend_title:I = 0x7f0a2ed3

.field public static final want_see_tips:I = 0x7f0a2ed4

.field public static final want_see_tips_rank_square:I = 0x7f0a2ed9

.field public static final want_see_with_gift:I = 0x7f0a2edb

.field public static final want_see_with_gift_flash_view:I = 0x7f0a2edc

.field public static final want_see_with_gift_img:I = 0x7f0a2edd

.field public static final wantcount:I = 0x7f0a2ede

.field public static final wantcount_suffix:I = 0x7f0a2edf

.field public static final wanted_dialog_card:I = 0x7f0a2ee3

.field public static final wanted_film_btn_line:I = 0x7f0a2ee4

.field public static final wanted_film_buy_btn:I = 0x7f0a2ee5

.field public static final wanted_film_comment_count_title:I = 0x7f0a2ee6

.field public static final wanted_film_director:I = 0x7f0a2ee7

.field public static final wanted_film_horizontal_line:I = 0x7f0a2ee8

.field public static final wanted_film_name:I = 0x7f0a2ee9

.field public static final wanted_film_play_date:I = 0x7f0a2eea

.field public static final wanted_film_rating_container:I = 0x7f0a2eeb

.field public static final wanted_film_remark_title:I = 0x7f0a2eec

.field public static final wanted_film_tv_remark:I = 0x7f0a2eed

.field public static final wanted_film_tv_tips:I = 0x7f0a2eee

.field public static final wanted_film_vertical_line:I = 0x7f0a2eef

.field public static final wanted_film_want_container:I = 0x7f0a2ef0

.field public static final wanted_film_want_count:I = 0x7f0a2ef1

.field public static final wanted_film_want_count_title:I = 0x7f0a2ef2

.field public static final wanted_list_root:I = 0x7f0a2ef3

.field public static final wanted_pic_poster:I = 0x7f0a2ef4

.field public static final warning_tips:I = 0x7f0a2ef5

.field public static final watch_count:I = 0x7f0a2ef6

.field public static final watch_count_icon:I = 0x7f0a2ef7

.field public static final watch_count_ui:I = 0x7f0a2ef8

.field public static final watch_line:I = 0x7f0a2ef9

.field public static final water_mark_view_id:I = 0x7f0a2efb

.field public static final web_container:I = 0x7f0a2efd

.field public static final web_container_root:I = 0x7f0a2efe

.field public static final web_view_snapshot:I = 0x7f0a2eff

.field public static final webview:I = 0x7f0a2f00

.field public static final webview_container:I = 0x7f0a2f01

.field public static final webview_goback:I = 0x7f0a2f02

.field public static final webview_nav_bar:I = 0x7f0a2f03

.field public static final webview_share:I = 0x7f0a2f04

.field public static final webview_titile:I = 0x7f0a2f05

.field public static final wednesday:I = 0x7f0a2f07

.field public static final week:I = 0x7f0a2f08

.field public static final week_bg:I = 0x7f0a2f09

.field public static final welfare_desc:I = 0x7f0a2f0a

.field public static final welfare_desc_parent:I = 0x7f0a2f0b

.field public static final welfare_desc_right_icon:I = 0x7f0a2f0c

.field public static final welfare_img:I = 0x7f0a2f0d

.field public static final welfare_lottie:I = 0x7f0a2f0e

.field public static final west:I = 0x7f0a2f0f

.field public static final wheelView:I = 0x7f0a2f10

.field public static final white:I = 0x7f0a2f11

.field public static final white_mask_view:I = 0x7f0a2f12

.field public static final widget_abfl_detectaction:I = 0x7f0a2f13

.field public static final widget_abfl_detectactionresult:I = 0x7f0a2f14

.field public static final widget_abfl_guide:I = 0x7f0a2f15

.field public static final widget_abfl_privacy:I = 0x7f0a2f16

.field public static final widget_da_self_name:I = 0x7f0a2f17

.field public static final widget_da_self_name_parent:I = 0x7f0a2f18

.field public static final widget_title_bar:I = 0x7f0a2f19

.field public static final width:I = 0x7f0a2f1a

.field public static final width_1:I = 0x7f0a2f1b

.field public static final width_2:I = 0x7f0a2f1c

.field public static final window_height:I = 0x7f0a2f1d

.field public static final window_icon:I = 0x7f0a2f1e

.field public static final window_width:I = 0x7f0a2f1f

.field public static final wish_city_view_bg_bottom:I = 0x7f0a2f20

.field public static final wish_tour_city_view:I = 0x7f0a2f21

.field public static final withText:I = 0x7f0a2f22

.field public static final withinBounds:I = 0x7f0a2f26

.field public static final wrap:I = 0x7f0a2f27

.field public static final wrap_content:I = 0x7f0a2f28

.field public static final wrap_content_constrained:I = 0x7f0a2f29

.field public static final wrap_reverse:I = 0x7f0a2f2a

.field public static final wrapped_composition_tag:I = 0x7f0a2f2b

.field public static final x_left:I = 0x7f0a2f2c

.field public static final x_right:I = 0x7f0a2f2d

.field public static final x_spec_item_img:I = 0x7f0a2f2e

.field public static final xunyan_dynamic_flipper:I = 0x7f0a2f30

.field public static final xunyan_dynamic_flipper_title:I = 0x7f0a2f31

.field public static final xunyan_flipper_item_1:I = 0x7f0a2f32

.field public static final xunyan_flipper_item_2:I = 0x7f0a2f33

.field public static final xunyan_flipper_item_3:I = 0x7f0a2f34

.field public static final xunyan_item_laeblview1:I = 0x7f0a2f35

.field public static final xunyan_item_layout_1:I = 0x7f0a2f36

.field public static final xunyan_item_tv_1:I = 0x7f0a2f37

.field public static final xxx:I = 0x7f0a2f38

.field public static final yellow:I = 0x7f0a2f39

.field public static final yk_bf_all_time:I = 0x7f0a2f3a

.field public static final yk_bf_allready_time:I = 0x7f0a2f3b

.field public static final yk_bottom_bar_layout:I = 0x7f0a2f3c

.field public static final yk_pause_container:I = 0x7f0a2f3d

.field public static final yk_player_back_btn:I = 0x7f0a2f3e

.field public static final yk_player_bf_btn:I = 0x7f0a2f3f

.field public static final yk_player_bottom_padding:I = 0x7f0a2f40

.field public static final yk_player_error_refresh:I = 0x7f0a2f41

.field public static final yk_player_error_tips:I = 0x7f0a2f42

.field public static final yk_player_fullscreen_btn:I = 0x7f0a2f43

.field public static final yk_player_loading:I = 0x7f0a2f44

.field public static final yk_player_seekbar:I = 0x7f0a2f45

.field public static final yk_player_video_bofang_btn:I = 0x7f0a2f46

.field public static final yk_player_video_cover:I = 0x7f0a2f47

.field public static final yk_player_voice_btn:I = 0x7f0a2f48

.field public static final youjiantou:I = 0x7f0a2f49

.field public static final youku_benefit_view:I = 0x7f0a2f4a

.field public static final zero_corner_chip:I = 0x7f0a2f57

.field public static final zoomCtrl:I = 0x7f0a2f58

.field public static final zoomView:I = 0x7f0a2f59

.field public static final zoom_big_imageview:I = 0x7f0a2f5a

.field public static final zoom_imageview:I = 0x7f0a2f5b


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
