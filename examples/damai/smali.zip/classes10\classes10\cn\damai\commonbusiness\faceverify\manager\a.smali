.class public Lcn/damai/commonbusiness/faceverify/manager/a;
.super Ljava/lang/Object;
.source "Taobao"


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method static synthetic a(Lcn/damai/commonbusiness/faceverify/manager/a;Lcn/damai/commonbusiness/faceverify/bean/FaceVerifyTokenBean;)V
    .registers 2

    const/4 p0, 0x0

    .line 1
    throw p0
.end method

.method static synthetic b(Lcn/damai/commonbusiness/faceverify/manager/a;Landroid/content/Context;Lcn/damai/commonbusiness/faceverify/bean/FaceVerifyTokenBean;)V
    .registers 3

    const/4 p0, 0x0

    .line 1
    throw p0
.end method

.method static synthetic c(Lcn/damai/commonbusiness/faceverify/manager/a;Ljava/lang/String;Ljava/lang/String;)V
    .registers 3

    const/4 p0, 0x0

    .line 1
    throw p0
.end method
