.class public Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter$b;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter;->instantiateItem(Landroid/view/ViewGroup;I)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:I

.field final synthetic b:Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;

.field final synthetic c:Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter;ILcn/damai/commonbusiness/photoselect/imageselected/entry/Image;)V
    .registers 4

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter$b;->c:Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter;

    iput p2, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter$b;->a:I

    iput-object p3, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter$b;->b:Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter$b;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter$b;->c:Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter;

    invoke-static {p1}, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter;->a(Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter;)Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter$OnItemClickListener;

    move-result-object p1

    if-eqz p1, :cond_2c

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter$b;->c:Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter;

    invoke-static {p1}, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter;->a(Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter;)Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter$OnItemClickListener;

    move-result-object p1

    iget v0, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter$b;->a:I

    iget-object v1, p0, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter$b;->b:Lcn/damai/commonbusiness/photoselect/imageselected/entry/Image;

    invoke-interface {p1, v0, v1}, Lcn/damai/commonbusiness/photoselect/imageselected/adapter/ImagePagerAdapter$OnItemClickListener;->onItemClick(ILcn/damai/commonbusiness/photoselect/imageselected/entry/Image;)V

    :cond_2c
    return-void
.end method
