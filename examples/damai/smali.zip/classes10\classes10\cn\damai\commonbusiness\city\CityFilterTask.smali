.class public Lcn/damai/commonbusiness/city/CityFilterTask;
.super Landroid/os/AsyncTask;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/city/CityFilterTask$OnResultListener;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/String;",
        "Ljava/lang/Void;",
        "Ljava/util/List<",
        "Lcn/damai/commonbusiness/city/model/SitesBean;",
        ">;>;"
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/city/model/GroupsBean;",
            ">;"
        }
    .end annotation
.end field

.field private b:Lcn/damai/commonbusiness/city/CityFilterTask$OnResultListener;


# direct methods
.method public constructor <init>(Ljava/util/List;Lcn/damai/commonbusiness/city/CityFilterTask$OnResultListener;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/city/model/GroupsBean;",
            ">;",
            "Lcn/damai/commonbusiness/city/CityFilterTask$OnResultListener;",
            ")V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    .line 2
    iput-object p1, p0, Lcn/damai/commonbusiness/city/CityFilterTask;->a:Ljava/util/List;

    .line 3
    iput-object p2, p0, Lcn/damai/commonbusiness/city/CityFilterTask;->b:Lcn/damai/commonbusiness/city/CityFilterTask$OnResultListener;

    return-void
.end method


# virtual methods
.method protected varargs a([Ljava/lang/String;)Ljava/util/List;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/city/model/SitesBean;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/city/CityFilterTask;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1a

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/List;

    return-object p1

    .line 1
    :cond_1a
    aget-object p1, p1, v3

    .line 2
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_80

    iget-object v0, p0, Lcn/damai/commonbusiness/city/CityFilterTask;->a:Ljava/util/List;

    if-eqz v0, :cond_80

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_2d

    goto :goto_80

    .line 3
    :cond_2d
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    new-instance v1, Ljava/util/HashSet;

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    .line 5
    iget-object v2, p0, Lcn/damai/commonbusiness/city/CityFilterTask;->a:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_3d
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_7f

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcn/damai/commonbusiness/city/model/GroupsBean;

    .line 6
    invoke-virtual {v3}, Lcn/damai/commonbusiness/city/model/GroupsBean;->getSites()Ljava/util/List;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_51
    :goto_51
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_3d

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcn/damai/commonbusiness/city/model/SitesBean;

    .line 7
    invoke-virtual {v4}, Lcn/damai/commonbusiness/city/model/SitesBean;->getCityId()Ljava/lang/String;

    move-result-object v5

    invoke-interface {v1, v5}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_68

    goto :goto_51

    .line 8
    :cond_68
    invoke-virtual {p0, p1, v4}, Lcn/damai/commonbusiness/city/CityFilterTask;->b(Ljava/lang/String;Lcn/damai/commonbusiness/city/model/SitesBean;)Lcn/damai/commonbusiness/city/model/SitesBean;

    move-result-object v4

    if-eqz v4, :cond_51

    .line 9
    invoke-virtual {v4}, Lcn/damai/commonbusiness/city/model/SitesBean;->getCityId()Ljava/lang/String;

    move-result-object v5

    invoke-interface {v1, v5}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 10
    invoke-interface {v0, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_51

    .line 11
    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_51

    :cond_7f
    return-object v0

    :cond_80
    :goto_80
    const/4 p1, 0x0

    return-object p1
.end method

.method public b(Ljava/lang/String;Lcn/damai/commonbusiness/city/model/SitesBean;)Lcn/damai/commonbusiness/city/model/SitesBean;
    .registers 10

    sget-object v0, Lcn/damai/commonbusiness/city/CityFilterTask;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_1d

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/city/model/SitesBean;

    return-object p1

    :cond_1d
    const/4 v0, 0x0

    .line 1
    invoke-virtual {p2}, Lcn/damai/commonbusiness/city/model/SitesBean;->getCityName()Ljava/lang/String;

    move-result-object v1

    .line 2
    iget-object v2, p2, Lcn/damai/commonbusiness/city/model/PinYinBean;->alphabet:Ljava/lang/String;

    .line 3
    iget-object v5, p2, Lcn/damai/commonbusiness/city/model/PinYinBean;->pinYin:Ljava/lang/String;

    if-eqz v1, :cond_a6

    .line 4
    invoke-virtual {v1, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_49

    .line 5
    new-instance v0, Lcn/damai/commonbusiness/city/model/SitesBean;

    invoke-direct {v0}, Lcn/damai/commonbusiness/city/model/SitesBean;-><init>()V

    .line 6
    invoke-virtual {v0, v1}, Lcn/damai/commonbusiness/city/model/SitesBean;->setCityName(Ljava/lang/String;)V

    .line 7
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p1

    invoke-virtual {p0, v1, p1}, Lcn/damai/commonbusiness/city/CityFilterTask;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcn/damai/commonbusiness/city/model/SitesBean;->setCityNameWithStyle(Ljava/lang/String;)V

    .line 8
    invoke-virtual {p2}, Lcn/damai/commonbusiness/city/model/SitesBean;->getCityId()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcn/damai/commonbusiness/city/model/SitesBean;->setCityId(Ljava/lang/String;)V

    goto :goto_a6

    :cond_49
    if-eqz v2, :cond_74

    .line 9
    invoke-virtual {v2}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_74

    .line 10
    new-instance v0, Lcn/damai/commonbusiness/city/model/SitesBean;

    invoke-direct {v0}, Lcn/damai/commonbusiness/city/model/SitesBean;-><init>()V

    .line 11
    invoke-virtual {v0, v1}, Lcn/damai/commonbusiness/city/model/SitesBean;->setCityName(Ljava/lang/String;)V

    .line 12
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p1

    invoke-virtual {p0, v1, p1}, Lcn/damai/commonbusiness/city/CityFilterTask;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcn/damai/commonbusiness/city/model/SitesBean;->setCityNameWithStyle(Ljava/lang/String;)V

    .line 13
    invoke-virtual {p2}, Lcn/damai/commonbusiness/city/model/SitesBean;->getCityId()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcn/damai/commonbusiness/city/model/SitesBean;->setCityId(Ljava/lang/String;)V

    goto :goto_a6

    :cond_74
    if-eqz v5, :cond_a6

    .line 14
    invoke-virtual {v5}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_a6

    .line 15
    new-instance v0, Lcn/damai/commonbusiness/city/model/SitesBean;

    invoke-direct {v0}, Lcn/damai/commonbusiness/city/model/SitesBean;-><init>()V

    const/4 v2, 0x0

    .line 16
    :goto_8a
    iget-object v5, p2, Lcn/damai/commonbusiness/city/model/PinYinBean;->singleLegth:[I

    array-length v5, v5

    if-ge v2, v5, :cond_9f

    .line 17
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v5

    iget-object v6, p2, Lcn/damai/commonbusiness/city/model/PinYinBean;->singleLegth:[I

    aget v6, v6, v2

    if-gt v5, v6, :cond_9c

    add-int/lit8 v4, v2, 0x1

    goto :goto_9f

    :cond_9c
    add-int/lit8 v2, v2, 0x1

    goto :goto_8a

    .line 18
    :cond_9f
    :goto_9f
    invoke-virtual {p0, v1, v4}, Lcn/damai/commonbusiness/city/CityFilterTask;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcn/damai/commonbusiness/city/model/SitesBean;->setCityNameWithStyle(Ljava/lang/String;)V

    :cond_a6
    :goto_a6
    return-object v0
.end method

.method public c(Ljava/lang/String;I)Ljava/lang/String;
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/city/CityFilterTask;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_21

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    return-object p1

    .line 1
    :cond_21
    invoke-virtual {p1, v3, p2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p2

    .line 2
    sget-object v0, Ltb/oa;->INSTANCE:Ltb/oa;

    invoke-virtual {v0}, Ltb/oa;->getAppConfigProvider()Lcom/alibaba/pictures/cornerstone/common/IAppConfigProvider;

    move-result-object v1

    if-eqz v1, :cond_35

    .line 3
    invoke-virtual {v0}, Ltb/oa;->getAppConfigProvider()Lcom/alibaba/pictures/cornerstone/common/IAppConfigProvider;

    move-result-object v0

    invoke-interface {v0}, Lcom/alibaba/pictures/cornerstone/common/IAppConfigProvider;->getIsPioneerOpen()Z

    move-result v3

    .line 4
    :cond_35
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "<font color="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz v3, :cond_44

    const-string v1, "#ff5000"

    goto :goto_46

    :cond_44
    const-string v1, "#FF0000"

    .line 5
    :goto_46
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ">"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "</font>"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 6
    invoke-virtual {p1, p2, v0}, Ljava/lang/String;->replaceFirst(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected d(Ljava/util/List;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcn/damai/commonbusiness/city/model/SitesBean;",
            ">;)V"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/city/CityFilterTask;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iget-object v0, p0, Lcn/damai/commonbusiness/city/CityFilterTask;->b:Lcn/damai/commonbusiness/city/CityFilterTask$OnResultListener;

    if-eqz v0, :cond_1e

    .line 2
    invoke-interface {v0, p1}, Lcn/damai/commonbusiness/city/CityFilterTask$OnResultListener;->OnSearchResult(Ljava/util/List;)V

    :cond_1e
    return-void
.end method

.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 1
    check-cast p1, [Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/city/CityFilterTask;->a([Ljava/lang/String;)Ljava/util/List;

    move-result-object p1

    return-object p1
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .registers 2

    .line 1
    check-cast p1, Ljava/util/List;

    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/city/CityFilterTask;->d(Ljava/util/List;)V

    return-void
.end method
