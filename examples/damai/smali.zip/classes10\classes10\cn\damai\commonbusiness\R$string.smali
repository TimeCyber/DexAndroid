.class public final Lcn/damai/commonbusiness/R$string;
.super Ljava/lang/Object;
.source "Taobao"


# static fields
.field public static final COMMENT_SHARE_URL:I = 0x7f120000

.field public static final CTAP1_ERR_CHANNEL_BUSY:I = 0x7f120001

.field public static final CTAP1_ERR_INVALID_CHANNEL:I = 0x7f120002

.field public static final CTAP1_ERR_INVALID_COMMAND:I = 0x7f120003

.field public static final CTAP1_ERR_INVALID_LENGTH:I = 0x7f120004

.field public static final CTAP1_ERR_INVALID_PARAMETER:I = 0x7f120005

.field public static final CTAP1_ERR_INVALID_SEQ:I = 0x7f120006

.field public static final CTAP1_ERR_LOCK_REQUIRED:I = 0x7f120007

.field public static final CTAP1_ERR_OTHER:I = 0x7f120008

.field public static final CTAP1_ERR_TIMEOUT:I = 0x7f120009

.field public static final CTAP2_ERR_ACTION_TIMEOUT:I = 0x7f12000a

.field public static final CTAP2_ERR_CBOR_PARSING:I = 0x7f12000b

.field public static final CTAP2_ERR_CBOR_UNEXPECTED_TYPE:I = 0x7f12000c

.field public static final CTAP2_ERR_CREDENTIAL_EXCLUDED:I = 0x7f12000d

.field public static final CTAP2_ERR_INVALID_CBOR:I = 0x7f12000e

.field public static final CTAP2_ERR_INVALID_CBOR_TYPE:I = 0x7f12000f

.field public static final CTAP2_ERR_INVALID_CREDENTIAL:I = 0x7f120010

.field public static final CTAP2_ERR_INVALID_OPTION:I = 0x7f120011

.field public static final CTAP2_ERR_KEEPALIVE_CANCEL:I = 0x7f120012

.field public static final CTAP2_ERR_KEY_STORE_FULL:I = 0x7f120013

.field public static final CTAP2_ERR_LIMIT_EXCEEDED:I = 0x7f120014

.field public static final CTAP2_ERR_MISSING_PARAMETER:I = 0x7f120015

.field public static final CTAP2_ERR_NOT_ALLOWED:I = 0x7f120016

.field public static final CTAP2_ERR_NO_CREDENTIALS:I = 0x7f120017

.field public static final CTAP2_ERR_NO_OPERATIONS:I = 0x7f120018

.field public static final CTAP2_ERR_NO_OPERATION_PENDING:I = 0x7f120019

.field public static final CTAP2_ERR_OPERATION_DENIED:I = 0x7f12001a

.field public static final CTAP2_ERR_OPERATION_PENDING:I = 0x7f12001b

.field public static final CTAP2_ERR_PIN_AUTH_BLOCKED:I = 0x7f12001c

.field public static final CTAP2_ERR_PIN_AUTH_INVALID:I = 0x7f12001d

.field public static final CTAP2_ERR_PIN_BLOCKED:I = 0x7f12001e

.field public static final CTAP2_ERR_PIN_INVALID:I = 0x7f12001f

.field public static final CTAP2_ERR_PIN_NOT_SET:I = 0x7f120020

.field public static final CTAP2_ERR_PIN_POLICY_VIOLATION:I = 0x7f120021

.field public static final CTAP2_ERR_PIN_REQUIRED:I = 0x7f120022

.field public static final CTAP2_ERR_PIN_TOKEN_EXPIRED:I = 0x7f120023

.field public static final CTAP2_ERR_PROCESSING:I = 0x7f120024

.field public static final CTAP2_ERR_REQUEST_TOO_LARGE:I = 0x7f120025

.field public static final CTAP2_ERR_UNSUPPORTED_ALGORITHM:I = 0x7f120026

.field public static final CTAP2_ERR_UNSUPPORTED_EXTENSION:I = 0x7f120027

.field public static final CTAP2_ERR_UNSUPPORTED_OPTION:I = 0x7f120028

.field public static final CTAP2_ERR_UP_REQUIRED:I = 0x7f120029

.field public static final CTAP2_ERR_USER_ACTION_PENDING:I = 0x7f12002a

.field public static final CTAP2_ERR_USER_ACTION_TIMEOUT:I = 0x7f12002b

.field public static final CTAP2_ERR_USER_CANCEL:I = 0x7f12002c

.field public static final Cancel:I = 0x7f12002d

.field public static final Ensure:I = 0x7f12002e

.field public static final OK:I = 0x7f12002f

.field public static final abc_action_bar_home_description:I = 0x7f120030

.field public static final abc_action_bar_up_description:I = 0x7f120031

.field public static final abc_action_menu_overflow_description:I = 0x7f120032

.field public static final abc_action_mode_done:I = 0x7f120033

.field public static final abc_activity_chooser_view_see_all:I = 0x7f120034

.field public static final abc_activitychooserview_choose_application:I = 0x7f120035

.field public static final abc_capital_off:I = 0x7f120036

.field public static final abc_capital_on:I = 0x7f120037

.field public static final abc_menu_alt_shortcut_label:I = 0x7f120038

.field public static final abc_menu_ctrl_shortcut_label:I = 0x7f120039

.field public static final abc_menu_delete_shortcut_label:I = 0x7f12003a

.field public static final abc_menu_enter_shortcut_label:I = 0x7f12003b

.field public static final abc_menu_function_shortcut_label:I = 0x7f12003c

.field public static final abc_menu_meta_shortcut_label:I = 0x7f12003d

.field public static final abc_menu_shift_shortcut_label:I = 0x7f12003e

.field public static final abc_menu_space_shortcut_label:I = 0x7f12003f

.field public static final abc_menu_sym_shortcut_label:I = 0x7f120040

.field public static final abc_prepend_shortcut_label:I = 0x7f120041

.field public static final abc_search_hint:I = 0x7f120042

.field public static final abc_searchview_description_clear:I = 0x7f120043

.field public static final abc_searchview_description_query:I = 0x7f120044

.field public static final abc_searchview_description_search:I = 0x7f120045

.field public static final abc_searchview_description_submit:I = 0x7f120046

.field public static final abc_searchview_description_voice:I = 0x7f120047

.field public static final abc_shareactionprovider_share_with:I = 0x7f120048

.field public static final abc_shareactionprovider_share_with_application:I = 0x7f120049

.field public static final abc_toolbar_collapse_description:I = 0x7f12004a

.field public static final account_settings_nickname_hint:I = 0x7f12004c

.field public static final account_settings_nickname_title:I = 0x7f12004d

.field public static final accumulative_boxoffice:I = 0x7f12004f

.field public static final action_can_not_call:I = 0x7f120050

.field public static final activity_detail_title:I = 0x7f120051

.field public static final activity_joined:I = 0x7f120052

.field public static final add_contacts_hint_input_id_card_number:I = 0x7f120053

.field public static final add_contacts_hint_input_id_card_number_second:I = 0x7f120054

.field public static final add_contacts_hint_input_id_renewal_num:I = 0x7f120055

.field public static final add_contacts_hint_input_user_name:I = 0x7f120056

.field public static final add_contacts_id_card_num_tetxt:I = 0x7f120057

.field public static final add_contacts_id_card_number:I = 0x7f120058

.field public static final add_contacts_id_card_renewal_num_text:I = 0x7f120059

.field public static final add_contacts_id_card_type_tetxt:I = 0x7f12005a

.field public static final add_contacts_id_nationality:I = 0x7f12005b

.field public static final add_contacts_placeofissue:I = 0x7f12005c

.field public static final add_contacts_save_text:I = 0x7f12005d

.field public static final add_contacts_tip:I = 0x7f12005e

.field public static final add_contacts_title_text:I = 0x7f12005f

.field public static final add_contacts_user_name:I = 0x7f120060

.field public static final add_favor_cinema_fail:I = 0x7f120061

.field public static final add_image:I = 0x7f120062

.field public static final add_to_always_go:I = 0x7f120063

.field public static final addcustomer_limit_tips:I = 0x7f120064

.field public static final address_protocol_content:I = 0x7f120065

.field public static final address_protocol_title:I = 0x7f120066

.field public static final ak_alert_confirm:I = 0x7f120067

.field public static final alert_activity_seat_count:I = 0x7f120068

.field public static final alert_activity_seat_count_activity:I = 0x7f120069

.field public static final ali_fingerprint_iv:I = 0x7f12006a

.field public static final ali_fingerprint_other_iv:I = 0x7f12006b

.field public static final ali_ucc_login_title:I = 0x7f12006c

.field public static final ali_user_alipay_login:I = 0x7f12006d

.field public static final ali_user_alipay_quick_login:I = 0x7f12006e

.field public static final ali_user_wc_login:I = 0x7f12006f

.field public static final ali_vsdk_network_error:I = 0x7f120070

.field public static final ali_vsdk_refresh:I = 0x7f120071

.field public static final ali_vsdk_tips:I = 0x7f120072

.field public static final ali_vsdk_tips_finish:I = 0x7f120073

.field public static final ali_vsdk_tips_sub:I = 0x7f120074

.field public static final ali_vsdk_titlebar_back:I = 0x7f120075

.field public static final ali_vsdk_titlebar_name:I = 0x7f120076

.field public static final ali_vsdk_verify_call_calling:I = 0x7f120077

.field public static final ali_vsdk_verify_call_dialog_cancel:I = 0x7f120078

.field public static final ali_vsdk_verify_call_dialog_ok:I = 0x7f120079

.field public static final ali_vsdk_verify_call_goto_tips:I = 0x7f12007a

.field public static final ali_vsdk_verify_call_recall:I = 0x7f12007b

.field public static final ali_vsdk_verify_call_title:I = 0x7f12007c

.field public static final ali_vsdk_verify_code:I = 0x7f12007d

.field public static final ali_vsdk_verify_error:I = 0x7f12007e

.field public static final ali_vsdk_verify_error_call:I = 0x7f12007f

.field public static final ali_vsdk_verify_in_progress:I = 0x7f120080

.field public static final ali_vsdk_verify_no_code:I = 0x7f120081

.field public static final ali_vsdk_verify_number:I = 0x7f120082

.field public static final ali_vsdk_verify_sms_send_code:I = 0x7f120083

.field public static final ali_vsdk_verify_sms_subtitle:I = 0x7f120084

.field public static final ali_vsdk_verify_sms_timeout:I = 0x7f120085

.field public static final ali_vsdk_verify_sms_title:I = 0x7f120086

.field public static final ali_vsdk_verify_sms_use_call:I = 0x7f120087

.field public static final ali_vsdk_verify_submit:I = 0x7f120088

.field public static final alipay_not_install:I = 0x7f120089

.field public static final alipay_not_support_api:I = 0x7f12008a

.field public static final alipay_standard_sdk_loading:I = 0x7f12008b

.field public static final alipay_standard_sdk_loading_go_auth:I = 0x7f12008c

.field public static final alipay_standard_sdk_loading_go_pay:I = 0x7f12008d

.field public static final aliuser_SNS_auth_init_failed:I = 0x7f12008e

.field public static final aliuser_SNS_bind_alipay:I = 0x7f12008f

.field public static final aliuser_SNS_cancel:I = 0x7f120090

.field public static final aliuser_SNS_change_alipay:I = 0x7f120091

.field public static final aliuser_SNS_platform_auth_cancel:I = 0x7f120092

.field public static final aliuser_SNS_platform_auth_fail:I = 0x7f120093

.field public static final aliuser_SNS_platform_auth_not_init_ucc:I = 0x7f120094

.field public static final aliuser_SNS_platform_not_supported:I = 0x7f120095

.field public static final aliuser_account_login:I = 0x7f120096

.field public static final aliuser_account_remove_cancel:I = 0x7f120097

.field public static final aliuser_account_remove_delete:I = 0x7f120098

.field public static final aliuser_account_remove_info:I = 0x7f120099

.field public static final aliuser_account_remove_title:I = 0x7f12009a

.field public static final aliuser_agree:I = 0x7f12009b

.field public static final aliuser_agree_and_onekey_login:I = 0x7f12009c

.field public static final aliuser_agree_and_onekey_reg:I = 0x7f12009d

.field public static final aliuser_agree_and_reg:I = 0x7f12009e

.field public static final aliuser_alert_findpwd:I = 0x7f12009f

.field public static final aliuser_alipay_findpwd:I = 0x7f1200a0

.field public static final aliuser_alipay_protocal:I = 0x7f1200a1

.field public static final aliuser_alipay_protocal_url:I = 0x7f1200a2

.field public static final aliuser_allow:I = 0x7f1200a3

.field public static final aliuser_assist_clear:I = 0x7f1200a4

.field public static final aliuser_assist_password_hide:I = 0x7f1200a5

.field public static final aliuser_assist_password_show:I = 0x7f1200a6

.field public static final aliuser_bind_and_login_title:I = 0x7f1200a7

.field public static final aliuser_bind_other_phone:I = 0x7f1200a8

.field public static final aliuser_cancel:I = 0x7f1200a9

.field public static final aliuser_change_account:I = 0x7f1200aa

.field public static final aliuser_change_login_method:I = 0x7f1200ab

.field public static final aliuser_choose_region:I = 0x7f1200ac

.field public static final aliuser_code_input_hint:I = 0x7f1200ad

.field public static final aliuser_common_ok:I = 0x7f1200ae

.field public static final aliuser_common_region:I = 0x7f1200af

.field public static final aliuser_confirm:I = 0x7f1200b0

.field public static final aliuser_confirm_cancel:I = 0x7f1200b1

.field public static final aliuser_confirm_to_delete:I = 0x7f1200b2

.field public static final aliuser_continue_login:I = 0x7f1200b3

.field public static final aliuser_damai_book_policy_protocol_url:I = 0x7f1200b4

.field public static final aliuser_damai_book_protocal:I = 0x7f1200b5

.field public static final aliuser_damai_community_protocol_url:I = 0x7f1200b6

.field public static final aliuser_damai_policy_protocal:I = 0x7f1200b7

.field public static final aliuser_damai_policy_protocol_url_new:I = 0x7f1200b8

.field public static final aliuser_damai_protocal:I = 0x7f1200b9

.field public static final aliuser_damai_protocol_explain:I = 0x7f1200ba

.field public static final aliuser_damai_protocol_text:I = 0x7f1200bb

.field public static final aliuser_damai_protocol_url_new:I = 0x7f1200bc

.field public static final aliuser_debug_param_invalid:I = 0x7f1200bd

.field public static final aliuser_dingtalk_uninstalled:I = 0x7f1200be

.field public static final aliuser_direct_logout:I = 0x7f1200bf

.field public static final aliuser_disallow:I = 0x7f1200c0

.field public static final aliuser_email_format_error:I = 0x7f1200c1

.field public static final aliuser_error_scan_site:I = 0x7f1200c2

.field public static final aliuser_exit:I = 0x7f1200c3

.field public static final aliuser_exit_smscode_hint:I = 0x7f1200c4

.field public static final aliuser_find_account:I = 0x7f1200c5

.field public static final aliuser_find_pwd_phone_hint:I = 0x7f1200c6

.field public static final aliuser_finger_button_text:I = 0x7f1200c7

.field public static final aliuser_finger_fail:I = 0x7f1200c8

.field public static final aliuser_finger_go_set:I = 0x7f1200c9

.field public static final aliuser_finger_iv_changed:I = 0x7f1200ca

.field public static final aliuser_finger_login_changed:I = 0x7f1200cb

.field public static final aliuser_finger_login_failed:I = 0x7f1200cc

.field public static final aliuser_finger_not_roll:I = 0x7f1200cd

.field public static final aliuser_fingerprint_check:I = 0x7f1200ce

.field public static final aliuser_fingerprint_enable:I = 0x7f1200cf

.field public static final aliuser_fingerprint_enable_tips:I = 0x7f1200d0

.field public static final aliuser_fingerprint_iv_try_other:I = 0x7f1200d1

.field public static final aliuser_fingerprint_logging_in:I = 0x7f1200d2

.field public static final aliuser_fingerprint_login_tips:I = 0x7f1200d3

.field public static final aliuser_fingerprint_not_match:I = 0x7f1200d4

.field public static final aliuser_fingerprint_not_now:I = 0x7f1200d5

.field public static final aliuser_fingerprint_open_error:I = 0x7f1200d6

.field public static final aliuser_fingerprint_title:I = 0x7f1200d7

.field public static final aliuser_fingerprint_try_later:I = 0x7f1200d8

.field public static final aliuser_fingerprint_try_other:I = 0x7f1200d9

.field public static final aliuser_get_voice_code:I = 0x7f1200da

.field public static final aliuser_help:I = 0x7f1200db

.field public static final aliuser_hot_region_list:I = 0x7f1200dc

.field public static final aliuser_i_know:I = 0x7f1200dd

.field public static final aliuser_login2reg_protocal_text:I = 0x7f1200de

.field public static final aliuser_login2reg_protocol:I = 0x7f1200df

.field public static final aliuser_login_exception:I = 0x7f1200e0

.field public static final aliuser_login_mobile_verify_hint:I = 0x7f1200e1

.field public static final aliuser_login_more_func:I = 0x7f1200e2

.field public static final aliuser_login_more_login:I = 0x7f1200e3

.field public static final aliuser_login_pwd_login:I = 0x7f1200e4

.field public static final aliuser_login_sms_code_hint:I = 0x7f1200e5

.field public static final aliuser_login_sms_login:I = 0x7f1200e6

.field public static final aliuser_login_sms_login2:I = 0x7f1200e7

.field public static final aliuser_login_welcome:I = 0x7f1200e8

.field public static final aliuser_login_welcome_back:I = 0x7f1200e9

.field public static final aliuser_logout_message:I = 0x7f1200ea

.field public static final aliuser_logout_title:I = 0x7f1200eb

.field public static final aliuser_mobile_hint:I = 0x7f1200ec

.field public static final aliuser_mobile_register:I = 0x7f1200ed

.field public static final aliuser_mobile_register_tips:I = 0x7f1200ee

.field public static final aliuser_more:I = 0x7f1200ef

.field public static final aliuser_more_login_mode_title:I = 0x7f1200f0

.field public static final aliuser_multi_account_add:I = 0x7f1200f1

.field public static final aliuser_multi_account_choose_logout:I = 0x7f1200f2

.field public static final aliuser_multi_account_current_user:I = 0x7f1200f3

.field public static final aliuser_multi_account_delete_account_title:I = 0x7f1200f4

.field public static final aliuser_multi_account_delete_account_title_secondary:I = 0x7f1200f5

.field public static final aliuser_multi_account_delete_confirm:I = 0x7f1200f6

.field public static final aliuser_multi_account_delete_confirm_title:I = 0x7f1200f7

.field public static final aliuser_multi_account_delete_manager:I = 0x7f1200f8

.field public static final aliuser_multi_account_logout_all:I = 0x7f1200f9

.field public static final aliuser_multi_account_logout_current_user:I = 0x7f1200fa

.field public static final aliuser_multi_add:I = 0x7f1200fb

.field public static final aliuser_multi_change_account:I = 0x7f1200fc

.field public static final aliuser_multi_change_account_secondary_tip:I = 0x7f1200fd

.field public static final aliuser_network_error:I = 0x7f1200fe

.field public static final aliuser_nick_welcome:I = 0x7f1200ff

.field public static final aliuser_onekey_login_fail:I = 0x7f120100

.field public static final aliuser_onekey_login_fail_tip:I = 0x7f120101

.field public static final aliuser_onekey_reg_fail_tip:I = 0x7f120102

.field public static final aliuser_onekey_reg_retain_title:I = 0x7f120103

.field public static final aliuser_other_account:I = 0x7f120104

.field public static final aliuser_other_account_login:I = 0x7f120105

.field public static final aliuser_other_login_type:I = 0x7f120106

.field public static final aliuser_password_format_error:I = 0x7f120107

.field public static final aliuser_phone_number_invalidate:I = 0x7f120108

.field public static final aliuser_policy_protocal:I = 0x7f120109

.field public static final aliuser_policy_protocal_url:I = 0x7f12010a

.field public static final aliuser_protocal_text:I = 0x7f12010b

.field public static final aliuser_protocol_disagree:I = 0x7f12010c

.field public static final aliuser_protocol_title:I = 0x7f12010d

.field public static final aliuser_protocol_welcome:I = 0x7f12010e

.field public static final aliuser_qrlogin:I = 0x7f12010f

.field public static final aliuser_re_enter:I = 0x7f120110

.field public static final aliuser_recommend_login_hint:I = 0x7f120111

.field public static final aliuser_reg:I = 0x7f120112

.field public static final aliuser_reg_continue:I = 0x7f120113

.field public static final aliuser_reg_email_hint:I = 0x7f120114

.field public static final aliuser_reg_instant:I = 0x7f120115

.field public static final aliuser_reg_mobile_exist:I = 0x7f120116

.field public static final aliuser_reg_now:I = 0x7f120117

.field public static final aliuser_reg_potocol_content:I = 0x7f120118

.field public static final aliuser_reg_protocol_autoreg:I = 0x7f120119

.field public static final aliuser_reg_protocol_title:I = 0x7f12011a

.field public static final aliuser_reg_retain_title:I = 0x7f12011b

.field public static final aliuser_reg_tip_can_login:I = 0x7f12011c

.field public static final aliuser_region:I = 0x7f12011d

.field public static final aliuser_registNew:I = 0x7f12011e

.field public static final aliuser_register_enterprise:I = 0x7f12011f

.field public static final aliuser_register_password_hint:I = 0x7f120120

.field public static final aliuser_register_person:I = 0x7f120121

.field public static final aliuser_scan_alibaba_hint_info:I = 0x7f120122

.field public static final aliuser_scan_confirm:I = 0x7f120123

.field public static final aliuser_scan_hint_string:I = 0x7f120124

.field public static final aliuser_scan_login_fail:I = 0x7f120125

.field public static final aliuser_scan_login_text:I = 0x7f120126

.field public static final aliuser_scan_login_title:I = 0x7f120127

.field public static final aliuser_scan_success_tip:I = 0x7f120128

.field public static final aliuser_send_sms_first:I = 0x7f120129

.field public static final aliuser_sever_error:I = 0x7f12012a

.field public static final aliuser_sign_in_account_hint:I = 0x7f12012b

.field public static final aliuser_sign_in_forget_password:I = 0x7f12012c

.field public static final aliuser_sign_in_input_password:I = 0x7f12012d

.field public static final aliuser_sign_in_please_enter_password:I = 0x7f12012e

.field public static final aliuser_sign_in_title:I = 0x7f12012f

.field public static final aliuser_signup_page_title:I = 0x7f120130

.field public static final aliuser_signup_verification_getCode:I = 0x7f120131

.field public static final aliuser_signup_verification_reGetCode:I = 0x7f120132

.field public static final aliuser_signup_verification_reGetCode2:I = 0x7f120133

.field public static final aliuser_skip:I = 0x7f120134

.field public static final aliuser_sms_check_protocol_hint:I = 0x7f120135

.field public static final aliuser_sms_code_hint:I = 0x7f120136

.field public static final aliuser_sms_code_secondary_title:I = 0x7f120137

.field public static final aliuser_sms_code_success_hint:I = 0x7f120138

.field public static final aliuser_sms_code_success_hint2:I = 0x7f120139

.field public static final aliuser_sms_code_title:I = 0x7f12013a

.field public static final aliuser_sms_need_help:I = 0x7f12013b

.field public static final aliuser_sms_nick_login_tips:I = 0x7f12013c

.field public static final aliuser_sns_add_email_hint:I = 0x7f12013d

.field public static final aliuser_sns_add_email_title:I = 0x7f12013e

.field public static final aliuser_sns_already:I = 0x7f12013f

.field public static final aliuser_sns_email_already_reg:I = 0x7f120140

.field public static final aliuser_sns_email_invalid:I = 0x7f120141

.field public static final aliuser_sns_input_email:I = 0x7f120142

.field public static final aliuser_sns_login_with_tb:I = 0x7f120143

.field public static final aliuser_sns_reg_hint:I = 0x7f120144

.field public static final aliuser_sns_welcome_title:I = 0x7f120145

.field public static final aliuser_ssl_error_info:I = 0x7f120146

.field public static final aliuser_ssl_error_title:I = 0x7f120147

.field public static final aliuser_suggesst_bind_mobile_content:I = 0x7f120148

.field public static final aliuser_suggest_bind_mobile:I = 0x7f120149

.field public static final aliuser_switch_mobile_reg:I = 0x7f12014a

.field public static final aliuser_taobao_recommend_login_hint:I = 0x7f12014b

.field public static final aliuser_taobao_reg_tip:I = 0x7f12014c

.field public static final aliuser_taobaox_pwdlogin:I = 0x7f12014d

.field public static final aliuser_taobaox_quick_login:I = 0x7f12014e

.field public static final aliuser_taobaox_signup_verification_getCode:I = 0x7f12014f

.field public static final aliuser_taobaox_sms_code_success_hint:I = 0x7f120150

.field public static final aliuser_taobaox_smslogin:I = 0x7f120151

.field public static final aliuser_tb_login_exception:I = 0x7f120152

.field public static final aliuser_tb_protocal:I = 0x7f120153

.field public static final aliuser_tb_protocal_url:I = 0x7f120154

.field public static final aliuser_text_back:I = 0x7f120155

.field public static final aliuser_title_back:I = 0x7f120156

.field public static final aliuser_to_other_account:I = 0x7f120157

.field public static final aliuser_video_title:I = 0x7f120158

.field public static final aliuser_voice_code_hint:I = 0x7f120159

.field public static final aliuser_voice_code_success_hint:I = 0x7f12015a

.field public static final aliuser_voice_text:I = 0x7f12015b

.field public static final aliuser_wait_a_moment:I = 0x7f12015c

.field public static final aliuser_wechat_uninstalled:I = 0x7f12015d

.field public static final aliuser_yuyingshang:I = 0x7f12015e

.field public static final amap_map3d_app_name:I = 0x7f12015f

.field public static final android_credentials_TYPE_PASSWORD_CREDENTIAL:I = 0x7f120160

.field public static final androidx_credentials_TYPE_PUBLIC_KEY_CREDENTIAL:I = 0x7f120161

.field public static final androidx_startup:I = 0x7f120162

.field public static final app_bar_license:I = 0x7f120163

.field public static final app_name:I = 0x7f120165

.field public static final app_scheme_host:I = 0x7f120168

.field public static final app_scheme_hostbp:I = 0x7f120169

.field public static final appbar_background_behavior:I = 0x7f12016a

.field public static final appbar_layout_behavior:I = 0x7f12016b

.field public static final appbar_scrolling_view_behavior:I = 0x7f12016c

.field public static final appkey_debug:I = 0x7f12016d

.field public static final appkey_release:I = 0x7f12016e

.field public static final appstore_desc:I = 0x7f12016f

.field public static final artiste_blank:I = 0x7f120170

.field public static final artiste_relevant_cooperate_num:I = 0x7f120171

.field public static final artiste_relevant_title:I = 0x7f120172

.field public static final atlasdd_deploy_sucess_tip:I = 0x7f120173

.field public static final bank_reduce_time:I = 0x7f120175

.field public static final bind_another_yk_account:I = 0x7f120177

.field public static final bind_coupon_success:I = 0x7f120178

.field public static final bind_yk_and_buy:I = 0x7f120179

.field public static final birthday_dialog_close:I = 0x7f12017a

.field public static final black_diamond_line_content:I = 0x7f12017b

.field public static final black_diamond_show_name:I = 0x7f12017c

.field public static final bottom_sheet_behavior:I = 0x7f12017e

.field public static final bottomsheet_action_expand_halfway:I = 0x7f12017f

.field public static final bought_tickets:I = 0x7f120180

.field public static final bricks_artist_select_city_str:I = 0x7f120181

.field public static final bricks_coupon_comment:I = 0x7f120182

.field public static final bricks_coupon_comment_des:I = 0x7f120183

.field public static final bricks_coupon_order_cancel:I = 0x7f120184

.field public static final bricks_coupon_pay:I = 0x7f120185

.field public static final bricks_coupon_use:I = 0x7f120186

.field public static final bricks_damai_search_input_hint:I = 0x7f120187

.field public static final bricks_group_coupons_title:I = 0x7f120188

.field public static final bricks_home_notice:I = 0x7f120189

.field public static final bricks_home_top_search_btn:I = 0x7f12018a

.field public static final bricks_loading_text:I = 0x7f12018b

.field public static final bricks_normal_select_city_str:I = 0x7f12018c

.field public static final bricks_pull_to_refresh_text:I = 0x7f12018d

.field public static final bricks_release_to_refresh_text:I = 0x7f12018e

.field public static final bricks_search_sale_performance_unit:I = 0x7f12018f

.field public static final bricks_top_search_btn:I = 0x7f120190

.field public static final btn_add_copon_fcode:I = 0x7f120191

.field public static final btn_add_presale_fcode:I = 0x7f120192

.field public static final btn_buy:I = 0x7f120193

.field public static final btn_buy_pre:I = 0x7f120194

.field public static final btn_continue_buy:I = 0x7f120195

.field public static final btn_go_recharge:I = 0x7f120196

.field public static final btn_goto_video_list_text:I = 0x7f120197

.field public static final btn_reselect_seat:I = 0x7f120198

.field public static final btn_watch_film:I = 0x7f120199

.field public static final buy_ticket:I = 0x7f12019b

.field public static final calendar:I = 0x7f12019c

.field public static final calendar_tips_go_my_calendar:I = 0x7f12019d

.field public static final calendar_tips_title1:I = 0x7f12019e

.field public static final calendar_tips_title2:I = 0x7f12019f

.field public static final calendar_tips_title2_first:I = 0x7f1201a0

.field public static final camera_app_not_found_prompt:I = 0x7f1201a1

.field public static final cancel:I = 0x7f1201a4

.field public static final cancel_pay_card_result_info:I = 0x7f1201a7

.field public static final cancle:I = 0x7f1201a8

.field public static final candidate_refund_des:I = 0x7f1201ac

.field public static final candidate_refund_title:I = 0x7f1201ad

.field public static final canused_mcard_num:I = 0x7f1201b0

.field public static final canused_show_num:I = 0x7f1201b1

.field public static final canused_ticket_num:I = 0x7f1201b2

.field public static final canused_voucher_num:I = 0x7f1201b3

.field public static final card_result_dialog_button:I = 0x7f1201b4

.field public static final change_city:I = 0x7f1201b5

.field public static final change_city_tip:I = 0x7f1201b6

.field public static final character_counter_content_description:I = 0x7f1201b8

.field public static final character_counter_overflowed_content_description:I = 0x7f1201b9

.field public static final character_counter_pattern:I = 0x7f1201ba

.field public static final charge_card_use_tip:I = 0x7f1201bb

.field public static final check_goods:I = 0x7f1201bc

.field public static final check_order_status:I = 0x7f1201bd

.field public static final check_orders:I = 0x7f1201be

.field public static final chip_text:I = 0x7f1201bf

.field public static final cineam_reply_title:I = 0x7f1201c1

.field public static final cineam_search_tip:I = 0x7f1201c2

.field public static final cinema_can_not_buy_toast:I = 0x7f1201c3

.field public static final cinema_detail_3d_glass:I = 0x7f1201c4

.field public static final cinema_detail_4d:I = 0x7f1201c5

.field public static final cinema_detail_4dx:I = 0x7f1201c6

.field public static final cinema_detail_4k:I = 0x7f1201c7

.field public static final cinema_detail_busline:I = 0x7f1201c8

.field public static final cinema_detail_child:I = 0x7f1201c9

.field public static final cinema_detail_cinema_card:I = 0x7f1201ca

.field public static final cinema_detail_commodity:I = 0x7f1201cb

.field public static final cinema_detail_dmax:I = 0x7f1201cc

.field public static final cinema_detail_dolby:I = 0x7f1201cd

.field public static final cinema_detail_double_d:I = 0x7f1201ce

.field public static final cinema_detail_facility:I = 0x7f1201cf

.field public static final cinema_detail_food:I = 0x7f1201d0

.field public static final cinema_detail_gaiqian:I = 0x7f1201d1

.field public static final cinema_detail_glassfee:I = 0x7f1201d2

.field public static final cinema_detail_imax:I = 0x7f1201d3

.field public static final cinema_detail_love_seat:I = 0x7f1201d4

.field public static final cinema_detail_park:I = 0x7f1201d5

.field public static final cinema_detail_reald:I = 0x7f1201d6

.field public static final cinema_detail_refund:I = 0x7f1201d7

.field public static final cinema_detail_reset:I = 0x7f1201d8

.field public static final cinema_detail_slot_card:I = 0x7f1201d9

.field public static final cinema_detail_vip:I = 0x7f1201da

.field public static final cinema_detail_wifi:I = 0x7f1201db

.field public static final cinema_dont_support_member_filter:I = 0x7f1201dc

.field public static final cinema_evaluate_people_num:I = 0x7f1201dd

.field public static final cinema_evaluate_title:I = 0x7f1201de

.field public static final cinema_exchange_show_end:I = 0x7f1201df

.field public static final cinema_favorite_fail:I = 0x7f1201e0

.field public static final cinema_favorite_success:I = 0x7f1201e1

.field public static final cinema_favorite_tips:I = 0x7f1201e2

.field public static final cinema_no_exchange_schedule:I = 0x7f1201e3

.field public static final cinema_no_schedule:I = 0x7f1201e4

.field public static final cinema_presale_seat:I = 0x7f1201e5

.field public static final cinema_schedule_intro:I = 0x7f1201e6

.field public static final cinema_schedule_intro_today:I = 0x7f1201e7

.field public static final cinema_screeen:I = 0x7f1201e8

.field public static final cinema_show_end:I = 0x7f1201e9

.field public static final cinema_sort_filter_tips:I = 0x7f1201ea

.field public static final cinema_un_favorite_fail:I = 0x7f1201eb

.field public static final cinema_un_favorite_success:I = 0x7f1201ec

.field public static final city_pass_discount_desc:I = 0x7f1201ed

.field public static final clear_filter:I = 0x7f1201ee

.field public static final clear_search_histroy:I = 0x7f1201ef

.field public static final clear_text_end_icon_content_description:I = 0x7f1201f0

.field public static final close_drawer:I = 0x7f1201f1

.field public static final close_gesture:I = 0x7f1201f2

.field public static final close_schedule:I = 0x7f1201f3

.field public static final close_sheet:I = 0x7f1201f4

.field public static final close_window:I = 0x7f1201f5

.field public static final code_page_index_num:I = 0x7f1201f6

.field public static final comment_delete:I = 0x7f1201f8

.field public static final comment_edit_content_hint_high:I = 0x7f1201fa

.field public static final comment_edit_content_hint_low:I = 0x7f1201fb

.field public static final comment_reply_success:I = 0x7f120200

.field public static final commit_goods_register:I = 0x7f120201

.field public static final commit_kaishoudengji:I = 0x7f120202

.field public static final common_business_str_cancel:I = 0x7f120203

.field public static final common_business_str_completed:I = 0x7f120204

.field public static final common_business_str_consignee:I = 0x7f120205

.field public static final common_business_str_detail_address:I = 0x7f120206

.field public static final common_business_str_hint_address_upper_limited:I = 0x7f120207

.field public static final common_business_str_hint_detail_address:I = 0x7f120208

.field public static final common_business_str_hint_input_consignee_name:I = 0x7f120209

.field public static final common_business_str_hint_input_division:I = 0x7f12020a

.field public static final common_business_str_hint_input_phone_num:I = 0x7f12020b

.field public static final common_business_str_hint_input_right_phone:I = 0x7f12020c

.field public static final common_business_str_phone_num:I = 0x7f12020d

.field public static final common_business_str_region:I = 0x7f12020e

.field public static final common_business_str_save:I = 0x7f12020f

.field public static final common_business_str_street:I = 0x7f120210

.field public static final common_cancel:I = 0x7f120211

.field public static final common_city_wish_text:I = 0x7f120212

.field public static final common_confirm:I = 0x7f120213

.field public static final common_net_error_tip:I = 0x7f120214

.field public static final common_project_no_exist_tip:I = 0x7f120215

.field public static final common_share_status_error:I = 0x7f120216

.field public static final common_ticket_Limit_tip:I = 0x7f120217

.field public static final common_ticket_Limit_tip_toast:I = 0x7f120218

.field public static final common_ticket_empty_tip:I = 0x7f120219

.field public static final common_ticket_empty_tip_toast:I = 0x7f12021a

.field public static final common_tips_read_agree_service_terms:I = 0x7f12021b

.field public static final commonui_data_empty:I = 0x7f12021c

.field public static final commonui_exception:I = 0x7f12021d

.field public static final commonui_expand:I = 0x7f12021e

.field public static final commonui_nodata:I = 0x7f12021f

.field public static final commonui_refresh:I = 0x7f120220

.field public static final commonui_unexpand:I = 0x7f120221

.field public static final community_search_tip:I = 0x7f12022a

.field public static final con_ali_multi_account_change:I = 0x7f12022b

.field public static final confirm:I = 0x7f12022c

.field public static final confirm_forceupdate_cancel:I = 0x7f12022d

.field public static final confirm_forceupdate_install:I = 0x7f12022e

.field public static final confirm_install:I = 0x7f12022f

.field public static final confirm_install_hint:I = 0x7f120230

.field public static final confirm_install_hint1:I = 0x7f120231

.field public static final connect_server:I = 0x7f120232

.field public static final conpon_type_text:I = 0x7f120233

.field public static final corner:I = 0x7f120234

.field public static final coupon_add_title:I = 0x7f120235

.field public static final coupon_batch_to_be_activated:I = 0x7f120236

.field public static final coupon_bind_errer_retry:I = 0x7f120237

.field public static final coupon_call_app_alert:I = 0x7f120238

.field public static final coupon_code_errer_invalid:I = 0x7f120239

.field public static final coupon_dm_item_title:I = 0x7f12023a

.field public static final coupon_expire_date:I = 0x7f12023b

.field public static final coupon_get_title:I = 0x7f12023c

.field public static final coupon_input_code:I = 0x7f12023d

.field public static final coupon_input_hint:I = 0x7f12023e

.field public static final coupon_item_title:I = 0x7f12023f

.field public static final coupon_select_type:I = 0x7f120241

.field public static final coupon_success:I = 0x7f120242

.field public static final coupon_timer_text:I = 0x7f120243

.field public static final cube_ptr_hours_ago:I = 0x7f120244

.field public static final cube_ptr_last_update:I = 0x7f120245

.field public static final cube_ptr_minutes_ago:I = 0x7f120246

.field public static final cube_ptr_pull_down:I = 0x7f120247

.field public static final cube_ptr_pull_down_to_refresh:I = 0x7f120248

.field public static final cube_ptr_refresh_complete:I = 0x7f120249

.field public static final cube_ptr_refreshing:I = 0x7f12024a

.field public static final cube_ptr_release_to_refresh:I = 0x7f12024b

.field public static final cube_ptr_seconds_ago:I = 0x7f12024c

.field public static final customer_delete_tips:I = 0x7f12024d

.field public static final damai_add_image_count:I = 0x7f120251

.field public static final damai_add_video_count:I = 0x7f120252

.field public static final damai_addreceipt_beijing:I = 0x7f120253

.field public static final damai_addreceipt_card:I = 0x7f120254

.field public static final damai_addreceipt_hint_card:I = 0x7f120255

.field public static final damai_addreceipt_keep:I = 0x7f120256

.field public static final damai_addreceipt_name:I = 0x7f120257

.field public static final damai_addreceiptaddress_title:I = 0x7f120258

.field public static final damai_address_new_add:I = 0x7f12025b

.field public static final damai_address_select_receiving_address:I = 0x7f12025c

.field public static final damai_addresslist_del:I = 0x7f12025d

.field public static final damai_addresslist_del_failure_toast:I = 0x7f12025e

.field public static final damai_addresslist_del_success_toast:I = 0x7f12025f

.field public static final damai_addresslist_operation:I = 0x7f120260

.field public static final damai_alipay_payment_failed_toast:I = 0x7f120263

.field public static final damai_alipay_payment_results_toast:I = 0x7f120264

.field public static final damai_alipay_payment_success_toast:I = 0x7f120265

.field public static final damai_alipay_title:I = 0x7f120266

.field public static final damai_all_image:I = 0x7f120267

.field public static final damai_base_net_toast:I = 0x7f120269

.field public static final damai_channel_search_title:I = 0x7f12026a

.field public static final damai_choosemovie_no:I = 0x7f12026b

.field public static final damai_cinemaorder_01:I = 0x7f12026c

.field public static final damai_cinemaorder_commodity_amount:I = 0x7f12026d

.field public static final damai_cinemaorder_confirm_payment:I = 0x7f12026e

.field public static final damai_cinemaorder_coupons:I = 0x7f12026f

.field public static final damai_cinemaorder_order_amount2:I = 0x7f120270

.field public static final damai_cinemaorder_orders_cancel_toast:I = 0x7f120271

.field public static final damai_cinemaorder_orders_success_toast:I = 0x7f120272

.field public static final damai_cinemaorder_phone_number:I = 0x7f120273

.field public static final damai_cinemaorder_phone_number_toast:I = 0x7f120274

.field public static final damai_cinemaorder_phone_number_toast11:I = 0x7f120275

.field public static final damai_cinemaorder_total_y:I = 0x7f120276

.field public static final damai_cinemaorder_write_phone_number:I = 0x7f120277

.field public static final damai_cinemaseat_number:I = 0x7f120278

.field public static final damai_cinemaseat_row:I = 0x7f120279

.field public static final damai_cinemaseat_title:I = 0x7f12027a

.field public static final damai_citylist_whole_country:I = 0x7f12027b

.field public static final damai_coupondeail_add:I = 0x7f12027c

.field public static final damai_coupondeail_applicable_scope:I = 0x7f12027d

.field public static final damai_coupondeail_basic_information:I = 0x7f12027e

.field public static final damai_coupondeail_coupon_description:I = 0x7f12027f

.field public static final damai_coupondeail_coupon_name:I = 0x7f120280

.field public static final damai_coupondeail_coupon_number:I = 0x7f120281

.field public static final damai_coupondeail_coupon_validity_period:I = 0x7f120282

.field public static final damai_coupondeail_mycoupon:I = 0x7f120283

.field public static final damai_coupondeail_restricted_channel:I = 0x7f120284

.field public static final damai_coupondeail_to:I = 0x7f120285

.field public static final damai_damaicapture_selection:I = 0x7f120287

.field public static final damai_day1_01:I = 0x7f120288

.field public static final damai_day1_02:I = 0x7f120289

.field public static final damai_day1_03:I = 0x7f12028a

.field public static final damai_day1_04:I = 0x7f12028b

.field public static final damai_day1_05:I = 0x7f12028c

.field public static final damai_day1_06:I = 0x7f12028d

.field public static final damai_day1_07:I = 0x7f12028e

.field public static final damai_delete_image:I = 0x7f12028f

.field public static final damai_detail_wantsee_click_message:I = 0x7f120290

.field public static final damai_detail_wantsee_dialog_message:I = 0x7f120291

.field public static final damai_event_fine_recommendation:I = 0x7f120293

.field public static final damai_faq_feedback_title:I = 0x7f120297

.field public static final damai_faq_input_feedback_toast:I = 0x7f120298

.field public static final damai_faq_input_your_feedback_hint:I = 0x7f120299

.field public static final damai_faq_submit:I = 0x7f12029a

.field public static final damai_faq_submit_failure_toast:I = 0x7f12029b

.field public static final damai_faq_submit_success_toast:I = 0x7f12029c

.field public static final damai_filmdetail_share_text:I = 0x7f12029d

.field public static final damai_fission_chickensoup_default:I = 0x7f12029e

.field public static final damai_fission_maintitle_default:I = 0x7f12029f

.field public static final damai_fission_subtitle_default:I = 0x7f1202a0

.field public static final damai_goodregesiter_out_stock:I = 0x7f1202a1

.field public static final damai_goodregesiter_out_stock_fail:I = 0x7f1202a2

.field public static final damai_goodregesiter_out_stock_toast:I = 0x7f1202a3

.field public static final damai_homepage_comment_await_comment_tips:I = 0x7f1202a4

.field public static final damai_homepage_commented_tips:I = 0x7f1202a5

.field public static final damai_kaishoudengji_fail:I = 0x7f1202a6

.field public static final damai_know:I = 0x7f1202a7

.field public static final damai_login_log_using:I = 0x7f1202a8

.field public static final damai_main_quit_damai_toast:I = 0x7f1202a9

.field public static final damai_modifyuserdata_change_failed_toast:I = 0x7f1202ab

.field public static final damai_modifyuserdata_day:I = 0x7f1202ac

.field public static final damai_modifyuserdata_girl:I = 0x7f1202ad

.field public static final damai_modifyuserdata_male:I = 0x7f1202ae

.field public static final damai_modifyuserdata_month:I = 0x7f1202af

.field public static final damai_modifyuserdata_personal_data:I = 0x7f1202b0

.field public static final damai_modifyuserdata_year:I = 0x7f1202b1

.field public static final damai_more_about_barley:I = 0x7f1202b2

.field public static final damai_more_aboutintegral:I = 0x7f1202b3

.field public static final damai_more_check_update:I = 0x7f1202b4

.field public static final damai_more_empty_cache:I = 0x7f1202b5

.field public static final damai_more_empty_failure_toast:I = 0x7f1202b6

.field public static final damai_more_empty_success_toast:I = 0x7f1202b7

.field public static final damai_more_exit_sign:I = 0x7f1202b8

.field public static final damai_more_help_center:I = 0x7f1202b9

.field public static final damai_more_service_phone:I = 0x7f1202ba

.field public static final damai_movieprojectmap_time01:I = 0x7f1202bb

.field public static final damai_movieprojectmap_time02:I = 0x7f1202bc

.field public static final damai_movieprojectmap_time03:I = 0x7f1202bd

.field public static final damai_mycollect_delete_success:I = 0x7f1202be

.field public static final damai_no:I = 0x7f1202c1

.field public static final damai_orderdetailnew_reminder:I = 0x7f1202cb

.field public static final damai_orderdetailnew_time:I = 0x7f1202cd

.field public static final damai_orderregion_a_y:I = 0x7f1202d2

.field public static final damai_project_wantsee:I = 0x7f1202d5

.field public static final damai_projectdetail_damai_service_01:I = 0x7f1202d6

.field public static final damai_projectdetail_damai_service_02:I = 0x7f1202d7

.field public static final damai_projectdetail_tbd:I = 0x7f1202d8

.field public static final damai_real_name_notice_content:I = 0x7f1202d9

.field public static final damai_realname_authenticate_title:I = 0x7f1202da

.field public static final damai_register_service_terms:I = 0x7f1202dd

.field public static final damai_search_address:I = 0x7f1202df

.field public static final damai_search_browse:I = 0x7f1202e0

.field public static final damai_search_prize:I = 0x7f1202e2

.field public static final damai_search_review:I = 0x7f1202e3

.field public static final damai_search_ticket_price:I = 0x7f1202e4

.field public static final damai_search_time:I = 0x7f1202e5

.field public static final damai_search_title:I = 0x7f1202e6

.field public static final damai_search_venue_01:I = 0x7f1202e7

.field public static final damai_seat_package:I = 0x7f1202e9

.field public static final damai_share_01:I = 0x7f1202ec

.field public static final damai_share_02:I = 0x7f1202ed

.field public static final damai_share_03:I = 0x7f1202ee

.field public static final damai_share_alipay_friends:I = 0x7f1202ef

.field public static final damai_share_circle_friends:I = 0x7f1202f0

.field public static final damai_share_circle_load_toast:I = 0x7f1202f1

.field public static final damai_share_dingding:I = 0x7f1202f2

.field public static final damai_share_err_toast:I = 0x7f1202f3

.field public static final damai_share_micro_channel_friends:I = 0x7f1202f4

.field public static final damai_share_qq_friends:I = 0x7f1202f5

.field public static final damai_share_qq_space:I = 0x7f1202f6

.field public static final damai_share_sina_weibo:I = 0x7f1202f7

.field public static final damai_share_to:I = 0x7f1202f8

.field public static final damai_sharesina_get_share_success:I = 0x7f1202f9

.field public static final damai_sharesina_parameter_error_toast:I = 0x7f1202fa

.field public static final damai_sharesina_share_cancel:I = 0x7f1202fb

.field public static final damai_sharesina_share_failure:I = 0x7f1202fc

.field public static final damai_sharesina_share_sina_weibo:I = 0x7f1202fd

.field public static final damai_sharesina_share_success:I = 0x7f1202fe

.field public static final damai_usercenter_address_manager:I = 0x7f120300

.field public static final damai_usercenter_common_user:I = 0x7f120301

.field public static final damai_usercenter_electronic_purse:I = 0x7f120302

.field public static final damai_usercenter_login_password:I = 0x7f120303

.field public static final damai_usercenter_login_password_title:I = 0x7f120304

.field public static final damai_usercenter_my_subscription:I = 0x7f120305

.field public static final damai_usercenter_no_wallet:I = 0x7f120306

.field public static final damai_usercenter_order_all:I = 0x7f120307

.field public static final damai_usercenter_order_comment:I = 0x7f120308

.field public static final damai_usercenter_order_pay:I = 0x7f120309

.field public static final damai_usercenter_order_send:I = 0x7f12030a

.field public static final damai_usercenter_pay_password:I = 0x7f12030b

.field public static final damai_usercenter_pay_password_title:I = 0x7f12030c

.field public static final damai_usercenter_phone_number:I = 0x7f12030d

.field public static final damai_usercenter_security_center:I = 0x7f12030e

.field public static final damai_verificationcheck_query_times:I = 0x7f12030f

.field public static final damai_video_dur_limit_tip:I = 0x7f120310

.field public static final damai_video_size_limit_tip:I = 0x7f120311

.field public static final damai_webviewke_title_empty_toast:I = 0x7f120312

.field public static final damai_webviewkefu_activity_introduction_title:I = 0x7f120313

.field public static final damai_yes:I = 0x7f120314

.field public static final damai_yuyuexiangkan_fail:I = 0x7f120315

.field public static final data_string_001:I = 0x7f120316

.field public static final data_string_002:I = 0x7f120317

.field public static final data_string_003:I = 0x7f120318

.field public static final data_string_004:I = 0x7f120319

.field public static final data_string_005:I = 0x7f12031a

.field public static final data_string_006:I = 0x7f12031b

.field public static final data_string_007:I = 0x7f12031c

.field public static final data_string_008:I = 0x7f12031d

.field public static final data_string_009:I = 0x7f12031e

.field public static final data_string_010:I = 0x7f12031f

.field public static final data_string_011:I = 0x7f120320

.field public static final data_string_012:I = 0x7f120321

.field public static final data_string_013:I = 0x7f120322

.field public static final data_string_014:I = 0x7f120323

.field public static final data_string_015:I = 0x7f120324

.field public static final data_string_016:I = 0x7f120325

.field public static final data_string_017:I = 0x7f120326

.field public static final data_string_018:I = 0x7f120327

.field public static final data_string_019:I = 0x7f120328

.field public static final data_string_020:I = 0x7f120329

.field public static final data_string_021:I = 0x7f12032a

.field public static final data_string_022:I = 0x7f12032b

.field public static final data_string_023:I = 0x7f12032c

.field public static final data_string_024:I = 0x7f12032d

.field public static final data_string_025:I = 0x7f12032e

.field public static final data_string_026:I = 0x7f12032f

.field public static final data_string_027:I = 0x7f120330

.field public static final data_string_028:I = 0x7f120331

.field public static final data_string_029:I = 0x7f120332

.field public static final data_string_031:I = 0x7f120333

.field public static final data_string_044:I = 0x7f120334

.field public static final data_string_045:I = 0x7f120335

.field public static final dd_not_install:I = 0x7f120336

.field public static final dd_not_support_api:I = 0x7f120337

.field public static final default_error_message:I = 0x7f120338

.field public static final default_popup_window_title:I = 0x7f120339

.field public static final del:I = 0x7f12033a

.field public static final detail_page_http2_host:I = 0x7f12033c

.field public static final detail_page_http_host:I = 0x7f12033d

.field public static final detail_page_http_pathPrefix:I = 0x7f12033e

.field public static final detail_page_http_pathPrefix2:I = 0x7f12033f

.field public static final detail_page_http_pathPrefix3:I = 0x7f120340

.field public static final detail_page_http_scheme:I = 0x7f120341

.field public static final detail_page_https_scheme:I = 0x7f120342

.field public static final dialog_festival_title:I = 0x7f120348

.field public static final dialog_message_update_newversion:I = 0x7f12034b

.field public static final dialog_title_update_progress:I = 0x7f12034e

.field public static final dinamic_calendar_fri:I = 0x7f120354

.field public static final dinamic_calendar_mon:I = 0x7f120355

.field public static final dinamic_calendar_sat:I = 0x7f120356

.field public static final dinamic_calendar_sun:I = 0x7f120357

.field public static final dinamic_calendar_thu:I = 0x7f120358

.field public static final dinamic_calendar_tue:I = 0x7f120359

.field public static final dinamic_calendar_wed:I = 0x7f12035a

.field public static final dinamic_string:I = 0x7f12035b

.field public static final director_prefix:I = 0x7f12035c

.field public static final discount_button_coupon_exchange_rightnow:I = 0x7f12035d

.field public static final discount_button_coupon_getuse:I = 0x7f12035e

.field public static final discount_button_coupon_use:I = 0x7f12035f

.field public static final discount_button_coupon_use_rightnow:I = 0x7f120360

.field public static final discount_button_text1:I = 0x7f120361

.field public static final discount_button_text2:I = 0x7f120362

.field public static final discovery_selected:I = 0x7f120363

.field public static final discuss_count_text:I = 0x7f120364

.field public static final discuss_load_error:I = 0x7f120365

.field public static final discuss_load_error_reload:I = 0x7f120366

.field public static final discuss_title:I = 0x7f120367

.field public static final dm_asset_statements:I = 0x7f120369

.field public static final dm_privilege_empty_hint:I = 0x7f12036b

.field public static final dm_privilege_invalid_btn:I = 0x7f12036c

.field public static final dm_privilege_invalid_hint:I = 0x7f12036d

.field public static final dm_rank_project_ipuv:I = 0x7f12036e

.field public static final dm_rank_project_score:I = 0x7f12036f

.field public static final dm_rank_project_want_see:I = 0x7f120370

.field public static final dontremind:I = 0x7f120372

.field public static final double_layer:I = 0x7f120373

.field public static final dropdown_menu:I = 0x7f120374

.field public static final during_special:I = 0x7f120375

.field public static final easter_egg_default_label:I = 0x7f120376

.field public static final easter_egg_format_label:I = 0x7f120377

.field public static final easter_egg_format_label_long:I = 0x7f120378

.field public static final edit_back_tv:I = 0x7f120379

.field public static final edit_comment_tv:I = 0x7f12037a

.field public static final edit_contacts_title_text:I = 0x7f12037b

.field public static final edit_content_text:I = 0x7f12037c

.field public static final edit_hint_text:I = 0x7f12037d

.field public static final empty_filmcomment_by_want:I = 0x7f12037f

.field public static final empty_filmcomment_by_watched:I = 0x7f120380

.field public static final empty_user_phone_tip:I = 0x7f120382

.field public static final endorse_ticket:I = 0x7f120383

.field public static final endorsing:I = 0x7f120384

.field public static final err_abort:I = 0x7f120385

.field public static final err_constraint:I = 0x7f120386

.field public static final err_data:I = 0x7f120387

.field public static final err_encoding:I = 0x7f120388

.field public static final err_invalid_state:I = 0x7f120389

.field public static final err_network:I = 0x7f12038a

.field public static final err_not_allowed:I = 0x7f12038b

.field public static final err_not_supported:I = 0x7f12038c

.field public static final err_timeout:I = 0x7f12038d

.field public static final err_unknown:I = 0x7f12038e

.field public static final errcode_cancel:I = 0x7f12038f

.field public static final errcode_deny:I = 0x7f120390

.field public static final errcode_send_fail:I = 0x7f120391

.field public static final errcode_success:I = 0x7f120392

.field public static final errcode_unknown:I = 0x7f120393

.field public static final error_city_not_support_seat:I = 0x7f120394

.field public static final error_code_unknown_tip:I = 0x7f120395

.field public static final error_default_gateway:I = 0x7f120396

.field public static final error_dns1:I = 0x7f120397

.field public static final error_dns2:I = 0x7f120398

.field public static final error_gateway:I = 0x7f120399

.field public static final error_icon_content_description:I = 0x7f12039a

.field public static final error_ipaddress:I = 0x7f12039b

.field public static final error_ipcount:I = 0x7f12039c

.field public static final error_login_cancel:I = 0x7f12039d

.field public static final error_message_70003:I = 0x7f12039e

.field public static final error_name:I = 0x7f1203a1

.field public static final error_network_btn:I = 0x7f1203a2

.field public static final error_no_ranking:I = 0x7f1203a4

.field public static final error_system_cinema_51000:I = 0x7f1203a5

.field public static final error_system_failure:I = 0x7f1203a6

.field public static final error_tips:I = 0x7f1203a7

.field public static final error_tips_29:I = 0x7f1203a8

.field public static final error_tips_default:I = 0x7f1203a9

.field public static final error_unsupported_os_ver:I = 0x7f1203aa

.field public static final error_wifi_state:I = 0x7f1203ab

.field public static final evaluate_list_title_num:I = 0x7f1203b9

.field public static final evaluate_my_entry:I = 0x7f1203bc

.field public static final exception:I = 0x7f1203be

.field public static final exception_item:I = 0x7f1203bf

.field public static final exchange_ticket:I = 0x7f1203c0

.field public static final exit:I = 0x7f1203c1

.field public static final expire_date:I = 0x7f1203c2

.field public static final exposed_dropdown_menu_content_description:I = 0x7f1203c3

.field public static final fab_transformation_scrim_behavior:I = 0x7f1203c4

.field public static final fab_transformation_sheet_behavior:I = 0x7f1203c5

.field public static final face_auth_announce:I = 0x7f1203c6

.field public static final face_detect_abuse_security_photo:I = 0x7f1203c7

.field public static final face_detect_action_blink:I = 0x7f1203c8

.field public static final face_detect_action_face_in_screen:I = 0x7f1203c9

.field public static final face_detect_action_mirror:I = 0x7f1203ca

.field public static final face_detect_action_mounth:I = 0x7f1203cb

.field public static final face_detect_action_movein_circle:I = 0x7f1203cc

.field public static final face_detect_action_pitch_down_head:I = 0x7f1203cd

.field public static final face_detect_action_raise_head:I = 0x7f1203ce

.field public static final face_detect_action_turn_left:I = 0x7f1203cf

.field public static final face_detect_action_turn_right:I = 0x7f1203d0

.field public static final face_detect_action_turn_right_or_left:I = 0x7f1203d1

.field public static final face_detect_alert_dialog_msg_cancle_text:I = 0x7f1203d2

.field public static final face_detect_alert_dialog_msg_exit_text:I = 0x7f1203d3

.field public static final face_detect_alert_dialog_msg_light_enough:I = 0x7f1203d4

.field public static final face_detect_alert_dialog_msg_not_too_fast:I = 0x7f1203d5

.field public static final face_detect_alert_dialog_msg_ok_text:I = 0x7f1203d6

.field public static final face_detect_alert_dialog_msg_right_pose:I = 0x7f1203d7

.field public static final face_detect_alert_dialog_msg_timeout:I = 0x7f1203d8

.field public static final face_detect_auth_begin_cancel:I = 0x7f1203d9

.field public static final face_detect_auth_begin_ok:I = 0x7f1203da

.field public static final face_detect_auth_begin_text:I = 0x7f1203db

.field public static final face_detect_auth_begin_title:I = 0x7f1203dc

.field public static final face_detect_auth_pass:I = 0x7f1203dd

.field public static final face_detect_blink:I = 0x7f1203de

.field public static final face_detect_btn_text:I = 0x7f1203df

.field public static final face_detect_camera_configuration_cpu_low_title:I = 0x7f1203e0

.field public static final face_detect_camera_configuration_nofront_text:I = 0x7f1203e1

.field public static final face_detect_camera_configuration_nofront_title:I = 0x7f1203e2

.field public static final face_detect_camera_is_huawei_magic_window_text:I = 0x7f1203e3

.field public static final face_detect_camera_is_huawei_magic_window_title:I = 0x7f1203e4

.field public static final face_detect_camera_no_permission_text:I = 0x7f1203e5

.field public static final face_detect_camera_no_permission_title:I = 0x7f1203e6

.field public static final face_detect_camera_open_permission_text:I = 0x7f1203e7

.field public static final face_detect_camera_unconnect_cancle_text:I = 0x7f1203e8

.field public static final face_detect_camera_unconnect_ok_text:I = 0x7f1203e9

.field public static final face_detect_camera_unconnect_text:I = 0x7f1203ea

.field public static final face_detect_camera_unconnect_title:I = 0x7f1203eb

.field public static final face_detect_circle_process_dialog_success:I = 0x7f1203ec

.field public static final face_detect_circle_process_dialog_upload:I = 0x7f1203ed

.field public static final face_detect_device_not_support:I = 0x7f1203ee

.field public static final face_detect_dialog_algorithm_init_error:I = 0x7f1203ef

.field public static final face_detect_dialog_btn_cancel:I = 0x7f1203f0

.field public static final face_detect_dialog_btn_ok:I = 0x7f1203f1

.field public static final face_detect_dialog_btn_retry:I = 0x7f1203f2

.field public static final face_detect_dialog_btn_reupload:I = 0x7f1203f3

.field public static final face_detect_dialog_btn_sure:I = 0x7f1203f4

.field public static final face_detect_dialog_interrupt_error:I = 0x7f1203f5

.field public static final face_detect_dialog_network_error:I = 0x7f1203f6

.field public static final face_detect_dialog_preview_frame_error:I = 0x7f1203f7

.field public static final face_detect_dialog_quality_not_enough_error:I = 0x7f1203f8

.field public static final face_detect_dialog_too_much_error:I = 0x7f1203f9

.field public static final face_detect_error_upload_retry_text:I = 0x7f1203fa

.field public static final face_detect_face_id_inconsistent:I = 0x7f1203fb

.field public static final face_detect_face_inconsistent_with_security:I = 0x7f1203fc

.field public static final face_detect_id_blur:I = 0x7f1203fd

.field public static final face_detect_id_expired:I = 0x7f1203fe

.field public static final face_detect_id_illegal:I = 0x7f1203ff

.field public static final face_detect_identify:I = 0x7f120400

.field public static final face_detect_identity_not_exist:I = 0x7f120401

.field public static final face_detect_invalid_id_photo:I = 0x7f120402

.field public static final face_detect_mine:I = 0x7f120403

.field public static final face_detect_not_account_self:I = 0x7f120404

.field public static final face_detect_not_same_person:I = 0x7f120405

.field public static final face_detect_not_yourself:I = 0x7f120406

.field public static final face_detect_out_of_identity:I = 0x7f120407

.field public static final face_detect_recap_fail:I = 0x7f120408

.field public static final face_detect_reflect_fail:I = 0x7f120409

.field public static final face_detect_result_login:I = 0x7f12040a

.field public static final face_detect_sample:I = 0x7f12040b

.field public static final face_detect_security_abnormal:I = 0x7f12040c

.field public static final face_detect_security_not_exist_or_need_update:I = 0x7f12040d

.field public static final face_detect_self_action:I = 0x7f12040e

.field public static final face_detect_toast_action_too_small:I = 0x7f12040f

.field public static final face_detect_toast_face_light:I = 0x7f120410

.field public static final face_detect_toast_no_dectect_action:I = 0x7f120411

.field public static final face_detect_toast_not_in_region:I = 0x7f120412

.field public static final face_detect_toast_pitch_angle_not_suitable:I = 0x7f120413

.field public static final face_detect_toast_raise_phone:I = 0x7f120414

.field public static final face_detect_toast_too_close:I = 0x7f120415

.field public static final face_detect_toast_too_dark:I = 0x7f120416

.field public static final face_detect_toast_too_far:I = 0x7f120417

.field public static final face_detect_toast_too_shake:I = 0x7f120418

.field public static final face_detect_token_expired_or_invalid:I = 0x7f120419

.field public static final face_detect_token_repeate_submit:I = 0x7f12041a

.field public static final face_detect_top_back_text:I = 0x7f12041b

.field public static final face_detect_unkonwn_error:I = 0x7f12041c

.field public static final face_detect_upload_process_text:I = 0x7f12041d

.field public static final face_detect_uploading:I = 0x7f12041e

.field public static final face_detect_verify_not_match:I = 0x7f12041f

.field public static final face_detect_verify_not_pass:I = 0x7f120420

.field public static final face_detect_windows_close:I = 0x7f120421

.field public static final face_dialog_exit_button_cancel:I = 0x7f120422

.field public static final face_dialog_exit_button_confirm:I = 0x7f120423

.field public static final face_dialog_exit_message:I = 0x7f120424

.field public static final face_error_unsupported_os:I = 0x7f120425

.field public static final face_guide_click_start_verify:I = 0x7f120426

.field public static final face_guide_face_no_other_usage:I = 0x7f120427

.field public static final face_guide_face_small_tip:I = 0x7f120428

.field public static final face_guide_please:I = 0x7f120429

.field public static final face_guide_self_operation:I = 0x7f12042a

.field public static final face_init_activating:I = 0x7f12042b

.field public static final face_init_activating_warning:I = 0x7f12042c

.field public static final face_init_net_connecting_error:I = 0x7f12042d

.field public static final face_init_progress:I = 0x7f12042e

.field public static final face_liveness_action_fail:I = 0x7f12042f

.field public static final face_liveness_action_fail_msg:I = 0x7f120430

.field public static final face_liveness_action_fail_msg_timeout:I = 0x7f120431

.field public static final face_liveness_action_fail_tip_action_wrong:I = 0x7f120432

.field public static final face_liveness_action_fail_tip_common:I = 0x7f120433

.field public static final face_liveness_action_fail_tip_face_error:I = 0x7f120434

.field public static final face_liveness_action_fail_tip_occlusion:I = 0x7f120435

.field public static final face_liveness_adjust_fail:I = 0x7f120436

.field public static final face_liveness_adjust_fail_msg:I = 0x7f120437

.field public static final face_liveness_business_reach_retry_threshold_1:I = 0x7f120438

.field public static final face_liveness_env_too_bright:I = 0x7f120439

.field public static final face_liveness_file_upload_fail:I = 0x7f12043a

.field public static final face_liveness_nav_button_text:I = 0x7f12043b

.field public static final face_liveness_nav_hint_text:I = 0x7f12043c

.field public static final face_liveness_nav_tip_text:I = 0x7f12043d

.field public static final face_liveness_nav_title:I = 0x7f12043e

.field public static final face_liveness_ok:I = 0x7f12043f

.field public static final face_liveness_reach_retry_threshold:I = 0x7f120440

.field public static final face_liveness_recognize_fail:I = 0x7f120441

.field public static final face_liveness_recognize_fail_hint:I = 0x7f120442

.field public static final face_liveness_recognize_fail_msg:I = 0x7f120443

.field public static final face_liveness_recognize_fail_once_submitted:I = 0x7f120444

.field public static final face_liveness_remote_loading_fail:I = 0x7f120445

.field public static final face_liveness_retry:I = 0x7f120446

.field public static final face_liveness_success:I = 0x7f120447

.field public static final face_liveness_upload_fail:I = 0x7f120448

.field public static final face_liveness_upload_fail_msg:I = 0x7f120449

.field public static final face_nav_btn_video:I = 0x7f12044a

.field public static final faceverify_realname_auth_cardid_hint:I = 0x7f12044b

.field public static final faceverify_realname_auth_name_hint:I = 0x7f12044c

.field public static final faceverify_realname_title:I = 0x7f12044d

.field public static final faceverify_success:I = 0x7f12044e

.field public static final fail_liveness_exception:I = 0x7f12044f

.field public static final fail_liveness_failed:I = 0x7f120450

.field public static final fail_liveness_limited:I = 0x7f120451

.field public static final fail_upload_error_msg:I = 0x7f120452

.field public static final fans_list_empty:I = 0x7f120453

.field public static final feed_film_comment_evaluation_1:I = 0x7f120454

.field public static final feed_film_comment_evaluation_2:I = 0x7f120455

.field public static final feed_film_comment_evaluation_3:I = 0x7f120456

.field public static final feed_film_comment_evaluation_4:I = 0x7f120457

.field public static final feed_film_comment_evaluation_5:I = 0x7f120458

.field public static final festival_coupon:I = 0x7f120459

.field public static final film_comment_block_num:I = 0x7f12045a

.field public static final film_comment_dialog_guide_tip:I = 0x7f12045b

.field public static final film_comment_dialog_score:I = 0x7f12045c

.field public static final film_comment_dialog_title:I = 0x7f12045d

.field public static final film_comment_evaluation_1:I = 0x7f12045e

.field public static final film_comment_evaluation_1_v2:I = 0x7f12045f

.field public static final film_comment_evaluation_2:I = 0x7f120460

.field public static final film_comment_evaluation_2_v2:I = 0x7f120461

.field public static final film_comment_evaluation_3:I = 0x7f120462

.field public static final film_comment_evaluation_3_v2:I = 0x7f120463

.field public static final film_comment_evaluation_4:I = 0x7f120464

.field public static final film_comment_evaluation_4_v2:I = 0x7f120465

.field public static final film_comment_evaluation_5:I = 0x7f120466

.field public static final film_comment_evaluation_5_text:I = 0x7f120467

.field public static final film_comment_evaluation_5_v2:I = 0x7f120468

.field public static final film_comment_num:I = 0x7f120469

.field public static final film_comment_num3:I = 0x7f12046a

.field public static final film_comment_num_zore:I = 0x7f12046b

.field public static final film_detail_all_photo:I = 0x7f12046c

.field public static final film_detail_all_tag:I = 0x7f12046d

.field public static final film_detail_all_video:I = 0x7f12046e

.field public static final film_detail_article_list_title:I = 0x7f12046f

.field public static final film_detail_article_num:I = 0x7f120470

.field public static final film_detail_article_title:I = 0x7f120471

.field public static final film_detail_background_title:I = 0x7f120472

.field public static final film_detail_boxoffice_more:I = 0x7f120473

.field public static final film_detail_boxoffice_title:I = 0x7f120474

.field public static final film_detail_comment_add:I = 0x7f120475

.field public static final film_detail_comment_block_left:I = 0x7f120476

.field public static final film_detail_comment_done:I = 0x7f120477

.field public static final film_detail_comment_empty:I = 0x7f120478

.field public static final film_detail_comment_mine:I = 0x7f120479

.field public static final film_detail_comment_tip:I = 0x7f12047a

.field public static final film_detail_comment_user:I = 0x7f12047b

.field public static final film_detail_comment_want:I = 0x7f12047c

.field public static final film_detail_coupon_timer_text:I = 0x7f12047d

.field public static final film_detail_deep_article_num:I = 0x7f12047e

.field public static final film_detail_deep_article_title:I = 0x7f12047f

.field public static final film_detail_discuss_zone:I = 0x7f120480

.field public static final film_detail_dynamic_article_title:I = 0x7f120481

.field public static final film_detail_friend_comment_block_left:I = 0x7f120482

.field public static final film_detail_friend_list_title:I = 0x7f120483

.field public static final film_detail_friend_marker_desc:I = 0x7f120484

.field public static final film_detail_friend_remark_1:I = 0x7f120485

.field public static final film_detail_friend_remark_n:I = 0x7f120486

.field public static final film_detail_info_roles_num:I = 0x7f120487

.field public static final film_detail_info_title:I = 0x7f120488

.field public static final film_detail_info_trailers_num:I = 0x7f120489

.field public static final film_detail_info_video_num:I = 0x7f12048a

.field public static final film_detail_intro_title:I = 0x7f12048b

.field public static final film_detail_marker_desc:I = 0x7f12048c

.field public static final film_detail_no_comment_tip:I = 0x7f12048d

.field public static final film_detail_no_preschedule_remark:I = 0x7f12048e

.field public static final film_detail_preschedule_remark_desc:I = 0x7f12048f

.field public static final film_detail_preschedule_remark_desc_new:I = 0x7f120490

.field public static final film_detail_prize_title:I = 0x7f120491

.field public static final film_detail_pro_comment:I = 0x7f120492

.field public static final film_detail_pro_comment_num:I = 0x7f120493

.field public static final film_detail_profession_comment_title:I = 0x7f120494

.field public static final film_detail_profession_remark_desc:I = 0x7f120495

.field public static final film_detail_remark_count:I = 0x7f120496

.field public static final film_detail_tip_title:I = 0x7f120499

.field public static final film_detail_topic_list_title:I = 0x7f12049a

.field public static final film_detail_topic_num:I = 0x7f12049b

.field public static final film_detail_topic_title:I = 0x7f12049c

.field public static final film_detail_trailers:I = 0x7f12049d

.field public static final film_detail_video:I = 0x7f1204a9

.field public static final film_detail_want_desc:I = 0x7f1204aa

.field public static final film_detail_wow_subtitle:I = 0x7f1204ab

.field public static final film_detail_wow_title:I = 0x7f1204ac

.field public static final film_detail_youku_block_title:I = 0x7f1204ad

.field public static final film_detail_youku_desc:I = 0x7f1204ae

.field public static final film_detail_youku_dialog_button:I = 0x7f1204af

.field public static final film_detail_youku_dialog_desc1:I = 0x7f1204b0

.field public static final film_detail_youku_dialog_desc2:I = 0x7f1204b1

.field public static final film_detail_youku_dialog_title:I = 0x7f1204b2

.field public static final film_detail_youku_title:I = 0x7f1204b3

.field public static final film_detaler_error:I = 0x7f1204b4

.field public static final film_detaler_error_def:I = 0x7f1204b5

.field public static final film_duration_minute_postfix:I = 0x7f1204b6

.field public static final film_friend_comment_num1:I = 0x7f1204b7

.field public static final film_friend_comment_num2:I = 0x7f1204b8

.field public static final film_list_error_btn_52000_56003:I = 0x7f1204b9

.field public static final film_list_error_message_250009:I = 0x7f1204ba

.field public static final film_list_error_message_52000:I = 0x7f1204bb

.field public static final film_list_error_message_56003:I = 0x7f1204bc

.field public static final film_mark_zhoubian:I = 0x7f1204bd

.field public static final film_mark_zixun:I = 0x7f1204be

.field public static final film_open_day_list_title:I = 0x7f1204bf

.field public static final film_open_day_postfix:I = 0x7f1204c0

.field public static final film_open_day_postfix2:I = 0x7f1204c1

.field public static final film_open_day_postfix3:I = 0x7f1204c2

.field public static final film_open_day_postfix4:I = 0x7f1204c3

.field public static final film_open_day_postfix5:I = 0x7f1204c4

.field public static final film_poster_all_photo:I = 0x7f1204c5

.field public static final film_search_empty:I = 0x7f1204c6

.field public static final film_search_empty_desc:I = 0x7f1204c7

.field public static final film_search_empty_desc_format:I = 0x7f1204c8

.field public static final first_weekend_boxoffice:I = 0x7f1204c9

.field public static final flash_packet_atmosphere_lottie_url:I = 0x7f1204ca

.field public static final flash_packet_tag_lottie_url:I = 0x7f1204cb

.field public static final follow:I = 0x7f1204cc

.field public static final followed:I = 0x7f1204cd

.field public static final fontsize_item_text:I = 0x7f1204ce

.field public static final footer_item_01:I = 0x7f1204cf

.field public static final forward_success:I = 0x7f1204d0

.field public static final framework_on_refresh_release:I = 0x7f1204d1

.field public static final framework_pull_refresh:I = 0x7f1204d2

.field public static final framework_release_refresh:I = 0x7f1204d3

.field public static final framework_second:I = 0x7f1204d4

.field public static final framework_second_guide_tip:I = 0x7f1204d5

.field public static final framework_second_tip:I = 0x7f1204d6

.field public static final friend_comment_empty:I = 0x7f1204d7

.field public static final friend_watch_num1:I = 0x7f1204d8

.field public static final friend_watch_num2:I = 0x7f1204d9

.field public static final gen_text_all:I = 0x7f1204da

.field public static final generic_error_crypto_verify_failed:I = 0x7f1204db

.field public static final generic_error_sys_integrity_failed:I = 0x7f1204dc

.field public static final gesture_tips_hint:I = 0x7f1204dd

.field public static final gesture_tips_title:I = 0x7f1204de

.field public static final go_login:I = 0x7f1204df

.field public static final goods_pay_result_paying_desc:I = 0x7f1204e2

.field public static final goods_pay_result_title:I = 0x7f1204e3

.field public static final goto_buy_tip:I = 0x7f1204e4

.field public static final group_booking_timer_text:I = 0x7f1204e5

.field public static final group_movie_people_num:I = 0x7f1204e6

.field public static final h5_ic_arrow_back:I = 0x7f1204e8

.field public static final h5_ic_settings:I = 0x7f1204e9

.field public static final h5_ic_share:I = 0x7f1204ea

.field public static final half_length_portrait_hint:I = 0x7f1204eb

.field public static final half_length_portrait_title:I = 0x7f1204ec

.field public static final hall_tip_behavior:I = 0x7f1204ed

.field public static final happy_icon_need:I = 0x7f1204ee

.field public static final has_no_schedule:I = 0x7f1204ef

.field public static final has_no_schedule_for_show:I = 0x7f1204f0

.field public static final header_behavior:I = 0x7f1204f1

.field public static final hide_bottom_view_on_scroll_behavior:I = 0x7f1204f2

.field public static final hk_id_tips_hint:I = 0x7f1204f4

.field public static final hk_id_tips_title:I = 0x7f1204f5

.field public static final hms_apk_not_installed_hints:I = 0x7f1204f6

.field public static final hms_bindfaildlg_message:I = 0x7f1204f7

.field public static final hms_bindfaildlg_title:I = 0x7f1204f8

.field public static final hms_confirm:I = 0x7f1204f9

.field public static final hms_framework_error:I = 0x7f1204fa

.field public static final hms_is_spoof:I = 0x7f1204fb

.field public static final hms_push_channel:I = 0x7f1204fc

.field public static final hms_push_google:I = 0x7f1204fd

.field public static final hms_push_vmall:I = 0x7f1204fe

.field public static final hms_spoof_hints:I = 0x7f1204ff

.field public static final home_item_see_all:I = 0x7f120509

.field public static final home_search_tip:I = 0x7f12050b

.field public static final homepage_buy:I = 0x7f12050d

.field public static final homepage_eva_grade_tip:I = 0x7f12050f

.field public static final homepage_pre:I = 0x7f120510

.field public static final homepage_watch_film:I = 0x7f120511

.field public static final icon_content_description:I = 0x7f120515

.field public static final icon_font_add:I = 0x7f120516

.field public static final icon_font_add_fill:I = 0x7f120517

.field public static final icon_font_arrow_back:I = 0x7f120518

.field public static final icon_font_arrow_down:I = 0x7f120519

.field public static final icon_font_arrow_normal_down:I = 0x7f12051a

.field public static final icon_font_arrow_right:I = 0x7f12051b

.field public static final icon_font_arrow_right_fill:I = 0x7f12051c

.field public static final icon_font_arrow_up:I = 0x7f12051d

.field public static final icon_font_bank_special_offer:I = 0x7f12051e

.field public static final icon_font_billboard_down:I = 0x7f12051f

.field public static final icon_font_billboard_new:I = 0x7f120520

.field public static final icon_font_billboard_not_change:I = 0x7f120521

.field public static final icon_font_billboard_up:I = 0x7f120522

.field public static final icon_font_block_more:I = 0x7f120523

.field public static final icon_font_box_office:I = 0x7f120524

.field public static final icon_font_calendar:I = 0x7f120525

.field public static final icon_font_check_icon:I = 0x7f120526

.field public static final icon_font_check_icon_fill:I = 0x7f120527

.field public static final icon_font_checked:I = 0x7f120528

.field public static final icon_font_cinema_card:I = 0x7f120529

.field public static final icon_font_close:I = 0x7f12052a

.field public static final icon_font_close_bold:I = 0x7f12052b

.field public static final icon_font_close_line:I = 0x7f12052c

.field public static final icon_font_collect_fill:I = 0x7f12052d

.field public static final icon_font_collected:I = 0x7f12052e

.field public static final icon_font_colon_end:I = 0x7f12052f

.field public static final icon_font_colon_start:I = 0x7f120530

.field public static final icon_font_comment_icon:I = 0x7f120531

.field public static final icon_font_community_add:I = 0x7f120532

.field public static final icon_font_coupon:I = 0x7f120533

.field public static final icon_font_data_line:I = 0x7f120534

.field public static final icon_font_delete:I = 0x7f120535

.field public static final icon_font_down_small:I = 0x7f120536

.field public static final icon_font_edit_stroke:I = 0x7f120537

.field public static final icon_font_electronic_icon:I = 0x7f120538

.field public static final icon_font_eye:I = 0x7f120539

.field public static final icon_font_failed:I = 0x7f12053a

.field public static final icon_font_failed_90e:I = 0x7f12053b

.field public static final icon_font_favor_fill:I = 0x7f12053c

.field public static final icon_font_favor_unfill:I = 0x7f12053d

.field public static final icon_font_film_icon:I = 0x7f12053e

.field public static final icon_font_film_ticket:I = 0x7f12053f

.field public static final icon_font_filter:I = 0x7f120540

.field public static final icon_font_filter_selected:I = 0x7f120541

.field public static final icon_font_fire:I = 0x7f120542

.field public static final icon_font_flash_fill:I = 0x7f120543

.field public static final icon_font_flash_stroke:I = 0x7f120544

.field public static final icon_font_friend:I = 0x7f120545

.field public static final icon_font_gantanhao:I = 0x7f120546

.field public static final icon_font_gift_card:I = 0x7f120547

.field public static final icon_font_has_saw_film:I = 0x7f120548

.field public static final icon_font_header:I = 0x7f120549

.field public static final icon_font_heart_empty:I = 0x7f12054a

.field public static final icon_font_heart_favored:I = 0x7f12054b

.field public static final icon_font_heart_fill:I = 0x7f12054c

.field public static final icon_font_heart_unfavored:I = 0x7f12054d

.field public static final icon_font_help:I = 0x7f12054e

.field public static final icon_font_left_small:I = 0x7f12054f

.field public static final icon_font_like:I = 0x7f120550

.field public static final icon_font_link:I = 0x7f120551

.field public static final icon_font_loading:I = 0x7f120552

.field public static final icon_font_location:I = 0x7f120553

.field public static final icon_font_machine_tip:I = 0x7f120554

.field public static final icon_font_map:I = 0x7f120555

.field public static final icon_font_mark_fill:I = 0x7f120556

.field public static final icon_font_mark_line:I = 0x7f120557

.field public static final icon_font_money_save_card:I = 0x7f120558

.field public static final icon_font_movie_card:I = 0x7f120559

.field public static final icon_font_mute_off:I = 0x7f12055a

.field public static final icon_font_mute_on:I = 0x7f12055b

.field public static final icon_font_my_address:I = 0x7f12055c

.field public static final icon_font_my_audience:I = 0x7f12055d

.field public static final icon_font_my_coupons:I = 0x7f12055e

.field public static final icon_font_new:I = 0x7f12055f

.field public static final icon_font_news_center:I = 0x7f120560

.field public static final icon_font_no_selected:I = 0x7f120561

.field public static final icon_font_notice:I = 0x7f120562

.field public static final icon_font_notice_fill:I = 0x7f120563

.field public static final icon_font_order_recommend_film:I = 0x7f120564

.field public static final icon_font_personal_setting_icon:I = 0x7f120565

.field public static final icon_font_phone:I = 0x7f120566

.field public static final icon_font_play:I = 0x7f120567

.field public static final icon_font_play_next:I = 0x7f120568

.field public static final icon_font_plus:I = 0x7f120569

.field public static final icon_font_publish_icon:I = 0x7f12056a

.field public static final icon_font_ranking:I = 0x7f12056b

.field public static final icon_font_reduce_line:I = 0x7f12056c

.field public static final icon_font_refresh:I = 0x7f12056d

.field public static final icon_font_replay:I = 0x7f12056e

.field public static final icon_font_report:I = 0x7f12056f

.field public static final icon_font_reward:I = 0x7f120570

.field public static final icon_font_right_small:I = 0x7f120571

.field public static final icon_font_safe:I = 0x7f120572

.field public static final icon_font_safe_watch:I = 0x7f120573

.field public static final icon_font_save:I = 0x7f120574

.field public static final icon_font_scan_album:I = 0x7f120575

.field public static final icon_font_scan_flash:I = 0x7f120576

.field public static final icon_font_score_star:I = 0x7f120577

.field public static final icon_font_search:I = 0x7f120578

.field public static final icon_font_selected_no:I = 0x7f120579

.field public static final icon_font_share:I = 0x7f12057a

.field public static final icon_font_share_icon:I = 0x7f12057b

.field public static final icon_font_share_round:I = 0x7f12057c

.field public static final icon_font_show:I = 0x7f12057d

.field public static final icon_font_special_offer:I = 0x7f12057e

.field public static final icon_font_status_endorsed:I = 0x7f12057f

.field public static final icon_font_status_exchanged:I = 0x7f120580

.field public static final icon_font_status_expire:I = 0x7f120581

.field public static final icon_font_status_invalided:I = 0x7f120582

.field public static final icon_font_status_refunded:I = 0x7f120583

.field public static final icon_font_status_refundfail:I = 0x7f120584

.field public static final icon_font_status_robbed:I = 0x7f120585

.field public static final icon_font_status_showover:I = 0x7f120586

.field public static final icon_font_status_used:I = 0x7f120587

.field public static final icon_font_status_using:I = 0x7f120588

.field public static final icon_font_success:I = 0x7f120589

.field public static final icon_font_success_90d:I = 0x7f12058a

.field public static final icon_font_test:I = 0x7f12058b

.field public static final icon_font_three_point_more:I = 0x7f12058c

.field public static final icon_font_ticket:I = 0x7f12058d

.field public static final icon_font_ticket_call_phone:I = 0x7f12058e

.field public static final icon_font_ticket_location:I = 0x7f12058f

.field public static final icon_font_ticket_time_wait:I = 0x7f120590

.field public static final icon_font_time_fill:I = 0x7f120591

.field public static final icon_font_time_line:I = 0x7f120592

.field public static final icon_font_tip_icon:I = 0x7f120593

.field public static final icon_font_titlebar_back:I = 0x7f120594

.field public static final icon_font_to_top:I = 0x7f120595

.field public static final icon_font_topic_fill:I = 0x7f120596

.field public static final icon_font_topic_fuhao:I = 0x7f120597

.field public static final icon_font_tpp_secretary:I = 0x7f120598

.field public static final icon_font_up_small:I = 0x7f120599

.field public static final icon_font_wallet:I = 0x7f12059a

.field public static final icon_font_wheat_left:I = 0x7f12059b

.field public static final icon_font_wheat_right:I = 0x7f12059c

.field public static final icon_font_wifi:I = 0x7f12059d

.field public static final icon_font_write_fill:I = 0x7f12059e

.field public static final icon_font_write_stroke:I = 0x7f12059f

.field public static final icon_font_youku_choose:I = 0x7f1205a0

.field public static final icon_font_zoom:I = 0x7f1205a1

.field public static final icon_font_zoom_out:I = 0x7f1205a2

.field public static final icon_gantan:I = 0x7f1205a3

.field public static final iconf_3d_glass:I = 0x7f1205a4

.field public static final iconf_add:I = 0x7f1205a5

.field public static final iconf_add_favor:I = 0x7f1205a6

.field public static final iconf_add_focus:I = 0x7f1205a7

.field public static final iconf_add_focus_already:I = 0x7f1205a8

.field public static final iconf_add_focus_loading:I = 0x7f1205a9

.field public static final iconf_afternoon:I = 0x7f1205aa

.field public static final iconf_album:I = 0x7f1205ab

.field public static final iconf_androidcunchukongjianquanxian:I = 0x7f1205ac

.field public static final iconf_androidshebeixinxiquanxian:I = 0x7f1205ad

.field public static final iconf_androidweizhixinxiquanxian:I = 0x7f1205ae

.field public static final iconf_back:I = 0x7f1205af

.field public static final iconf_box_office:I = 0x7f1205b0

.field public static final iconf_boy:I = 0x7f1205b1

.field public static final iconf_card_close:I = 0x7f1205b2

.field public static final iconf_card_success:I = 0x7f1205b3

.field public static final iconf_card_waiting:I = 0x7f1205b4

.field public static final iconf_checked:I = 0x7f1205b5

.field public static final iconf_checked_yes:I = 0x7f1205b6

.field public static final iconf_cinema_card:I = 0x7f1205b7

.field public static final iconf_cinema_phone:I = 0x7f1205b8

.field public static final iconf_close:I = 0x7f1205b9

.field public static final iconf_close_broadcast:I = 0x7f1205ba

.field public static final iconf_comment_down_arrow:I = 0x7f1205bb

.field public static final iconf_comment_up_arrow:I = 0x7f1205bc

.field public static final iconf_community_close:I = 0x7f1205bd

.field public static final iconf_content_tips:I = 0x7f1205be

.field public static final iconf_damai_logo:I = 0x7f1205bf

.field public static final iconf_decorate_arrow_right:I = 0x7f1205c0

.field public static final iconf_delete_comment:I = 0x7f1205c1

.field public static final iconf_derivatives:I = 0x7f1205c2

.field public static final iconf_diamond:I = 0x7f1205c3

.field public static final iconf_disabled:I = 0x7f1205c4

.field public static final iconf_discover_film_detail:I = 0x7f1205c5

.field public static final iconf_discover_share:I = 0x7f1205c6

.field public static final iconf_discuss_subject:I = 0x7f1205c7

.field public static final iconf_do_reply:I = 0x7f1205c8

.field public static final iconf_do_write_comment:I = 0x7f1205c9

.field public static final iconf_done:I = 0x7f1205ca

.field public static final iconf_dont_support:I = 0x7f1205cb

.field public static final iconf_down_arrow:I = 0x7f1205cc

.field public static final iconf_down_arrow_73:I = 0x7f1205cd

.field public static final iconf_easter_egg:I = 0x7f1205ce

.field public static final iconf_easter_egg_arrow:I = 0x7f1205cf

.field public static final iconf_edit:I = 0x7f1205d0

.field public static final iconf_edit_comment:I = 0x7f1205d1

.field public static final iconf_edit_comment2:I = 0x7f1205d2

.field public static final iconf_empty_reply:I = 0x7f1205d3

.field public static final iconf_enabled:I = 0x7f1205d4

.field public static final iconf_endorse:I = 0x7f1205d5

.field public static final iconf_error:I = 0x7f1205d6

.field public static final iconf_exchanged:I = 0x7f1205d7

.field public static final iconf_exclamation:I = 0x7f1205d8

.field public static final iconf_extend:I = 0x7f1205d9

.field public static final iconf_favor_cinema:I = 0x7f1205da

.field public static final iconf_festival_date:I = 0x7f1205db

.field public static final iconf_festival_schedule_delete:I = 0x7f1205dc

.field public static final iconf_film_bg:I = 0x7f1205de

.field public static final iconf_filter:I = 0x7f1205e0

.field public static final iconf_filter_selected:I = 0x7f1205e1

.field public static final iconf_friend:I = 0x7f1205e2

.field public static final iconf_genghuanjuzhao:I = 0x7f1205e3

.field public static final iconf_gif_icon:I = 0x7f1205e4

.field public static final iconf_girl:I = 0x7f1205e5

.field public static final iconf_gou:I = 0x7f1205e6

.field public static final iconf_have_done:I = 0x7f1205e7

.field public static final iconf_hint:I = 0x7f1205e8

.field public static final iconf_home_tab_cinema:I = 0x7f1205e9

.field public static final iconf_home_tab_cinema_selected:I = 0x7f1205ea

.field public static final iconf_home_tab_discovery:I = 0x7f1205eb

.field public static final iconf_home_tab_discovery_selected:I = 0x7f1205ec

.field public static final iconf_home_tab_film:I = 0x7f1205ed

.field public static final iconf_home_tab_film_selected:I = 0x7f1205ee

.field public static final iconf_home_tab_performance:I = 0x7f1205ef

.field public static final iconf_home_tab_performance_selected:I = 0x7f1205f0

.field public static final iconf_home_tab_profile:I = 0x7f1205f1

.field public static final iconf_home_tab_profile_selected:I = 0x7f1205f2

.field public static final iconf_info:I = 0x7f1205f3

.field public static final iconf_invalid:I = 0x7f1205f4

.field public static final iconf_is_add_favor:I = 0x7f1205f5

.field public static final iconf_jianshao:I = 0x7f1205f6

.field public static final iconf_large:I = 0x7f1205f7

.field public static final iconf_left_arrow_bold:I = 0x7f1205f8

.field public static final iconf_live_show:I = 0x7f1205f9

.field public static final iconf_loc_info:I = 0x7f1205fa

.field public static final iconf_loc_info2:I = 0x7f1205fb

.field public static final iconf_locate:I = 0x7f1205fc

.field public static final iconf_long_video_brightness:I = 0x7f1205fd

.field public static final iconf_long_video_film_detail_entry:I = 0x7f1205fe

.field public static final iconf_long_video_full_screen:I = 0x7f1205ff

.field public static final iconf_long_video_next:I = 0x7f120600

.field public static final iconf_long_video_pause:I = 0x7f120601

.field public static final iconf_long_video_play:I = 0x7f120602

.field public static final iconf_long_video_try_see_again_icon:I = 0x7f120603

.field public static final iconf_long_video_try_see_again_text:I = 0x7f120604

.field public static final iconf_long_video_un_full_screen:I = 0x7f120605

.field public static final iconf_long_video_volume:I = 0x7f120606

.field public static final iconf_long_video_volume_silence:I = 0x7f120607

.field public static final iconf_machine_tip:I = 0x7f120608

.field public static final iconf_mall:I = 0x7f120609

.field public static final iconf_map:I = 0x7f12060a

.field public static final iconf_map2:I = 0x7f12060b

.field public static final iconf_member_tag:I = 0x7f12060c

.field public static final iconf_member_xp:I = 0x7f12060d

.field public static final iconf_messages:I = 0x7f12060e

.field public static final iconf_miracast_icon:I = 0x7f12060f

.field public static final iconf_miracast_wifi_connected:I = 0x7f120610

.field public static final iconf_miracast_wifi_disconnected:I = 0x7f120611

.field public static final iconf_morning:I = 0x7f120612

.field public static final iconf_muted:I = 0x7f120613

.field public static final iconf_my_coupons:I = 0x7f120614

.field public static final iconf_my_tickets:I = 0x7f120615

.field public static final iconf_my_tickets_new:I = 0x7f120616

.field public static final iconf_nearby:I = 0x7f120617

.field public static final iconf_next_video:I = 0x7f120618

.field public static final iconf_night:I = 0x7f120619

.field public static final iconf_no_discuss:I = 0x7f12061a

.field public static final iconf_notice:I = 0x7f12061b

.field public static final iconf_off_muted:I = 0x7f12061c

.field public static final iconf_off_single_close:I = 0x7f12061d

.field public static final iconf_off_single_dialog_close:I = 0x7f12061e

.field public static final iconf_overdue:I = 0x7f12061f

.field public static final iconf_phone:I = 0x7f120620

.field public static final iconf_phone2:I = 0x7f120621

.field public static final iconf_phone3:I = 0x7f120622

.field public static final iconf_phone_book:I = 0x7f120623

.field public static final iconf_play:I = 0x7f120624

.field public static final iconf_portrait_video_add_favor:I = 0x7f120625

.field public static final iconf_portrait_video_comment:I = 0x7f120626

.field public static final iconf_portrait_video_open_index:I = 0x7f120627

.field public static final iconf_portrait_video_open_index_arrow:I = 0x7f120628

.field public static final iconf_portrait_video_share:I = 0x7f120629

.field public static final iconf_question_mark:I = 0x7f12062a

.field public static final iconf_rank_watched_down:I = 0x7f12062b

.field public static final iconf_rank_watched_hold:I = 0x7f12062c

.field public static final iconf_rank_watched_icon:I = 0x7f12062d

.field public static final iconf_rank_watched_up:I = 0x7f12062e

.field public static final iconf_refresh:I = 0x7f12062f

.field public static final iconf_refund:I = 0x7f120630

.field public static final iconf_refund_step_1:I = 0x7f120631

.field public static final iconf_refund_step_2:I = 0x7f120632

.field public static final iconf_refund_step_3:I = 0x7f120633

.field public static final iconf_refund_step_4:I = 0x7f120634

.field public static final iconf_refunded:I = 0x7f120635

.field public static final iconf_refunded_fail:I = 0x7f120636

.field public static final iconf_refunding:I = 0x7f120637

.field public static final iconf_replay:I = 0x7f120638

.field public static final iconf_report:I = 0x7f120639

.field public static final iconf_right_arrow:I = 0x7f12063a

.field public static final iconf_right_arrow_73:I = 0x7f12063b

.field public static final iconf_right_arrow_bold:I = 0x7f12063c

.field public static final iconf_riqian:I = 0x7f12063d

.field public static final iconf_round_check_fill:I = 0x7f12063e

.field public static final iconf_round_close:I = 0x7f12063f

.field public static final iconf_route:I = 0x7f120640

.field public static final iconf_route_bus:I = 0x7f120641

.field public static final iconf_route_drive:I = 0x7f120642

.field public static final iconf_route_walk:I = 0x7f120643

.field public static final iconf_scan:I = 0x7f120644

.field public static final iconf_scan_flash:I = 0x7f120645

.field public static final iconf_scan_img:I = 0x7f120646

.field public static final iconf_schedule_close_broadcast:I = 0x7f120647

.field public static final iconf_search:I = 0x7f120648

.field public static final iconf_selected_no:I = 0x7f120649

.field public static final iconf_selected_yes:I = 0x7f12064a

.field public static final iconf_share:I = 0x7f12064b

.field public static final iconf_share_comment:I = 0x7f12064c

.field public static final iconf_shown:I = 0x7f12064d

.field public static final iconf_small:I = 0x7f12064e

.field public static final iconf_snack:I = 0x7f12064f

.field public static final iconf_state_fail:I = 0x7f120650

.field public static final iconf_state_success:I = 0x7f120651

.field public static final iconf_station:I = 0x7f120652

.field public static final iconf_subject_pound:I = 0x7f120653

.field public static final iconf_success_fill:I = 0x7f120654

.field public static final iconf_take_photo:I = 0x7f120655

.field public static final iconf_template_arrow_down:I = 0x7f120656

.field public static final iconf_template_checked:I = 0x7f120657

.field public static final iconf_template_download:I = 0x7f120658

.field public static final iconf_template_download_arrow:I = 0x7f120659

.field public static final iconf_template_download_bg:I = 0x7f12065a

.field public static final iconf_template_image:I = 0x7f12065b

.field public static final iconf_template_preview_close:I = 0x7f12065c

.field public static final iconf_template_refresh:I = 0x7f12065d

.field public static final iconf_template_select:I = 0x7f12065e

.field public static final iconf_template_share:I = 0x7f12065f

.field public static final iconf_ticket_tip:I = 0x7f120660

.field public static final iconf_time:I = 0x7f120661

.field public static final iconf_titlebar_map:I = 0x7f120662

.field public static final iconf_tuipiaowuyou:I = 0x7f120663

.field public static final iconf_un_favor_cinema:I = 0x7f120664

.field public static final iconf_up_arrow:I = 0x7f120665

.field public static final iconf_up_arrow_73:I = 0x7f120666

.field public static final iconf_used:I = 0x7f120667

.field public static final iconf_usersetting:I = 0x7f120668

.field public static final iconf_using:I = 0x7f120669

.field public static final iconf_valid_period:I = 0x7f12066a

.field public static final iconf_vertical_video_film_info:I = 0x7f12066b

.field public static final iconf_vertical_video_un_full_screen:I = 0x7f12066c

.field public static final iconf_video:I = 0x7f12066d

.field public static final iconf_video_play:I = 0x7f12066e

.field public static final iconf_vod_play:I = 0x7f12066f

.field public static final iconf_want:I = 0x7f120670

.field public static final iconf_want_icon:I = 0x7f120671

.field public static final iconf_want_watch:I = 0x7f120672

.field public static final iconf_wanted:I = 0x7f120673

.field public static final iconf_warning:I = 0x7f120674

.field public static final iconf_watched:I = 0x7f120675

.field public static final iconf_watched_icon:I = 0x7f120676

.field public static final iconf_weibo:I = 0x7f120677

.field public static final iconf_yianchu:I = 0x7f120678

.field public static final iconf_yianchu_new:I = 0x7f120679

.field public static final iconf_youku:I = 0x7f12067a

.field public static final iconf_zengjia:I = 0x7f12067b

.field public static final iconfont_Daohangguanbi18:I = 0x7f12067c

.field public static final iconfont_Dining:I = 0x7f12067d

.field public static final iconfont_Fucengguanbi18:I = 0x7f12067e

.field public static final iconfont_Gengduo18:I = 0x7f12067f

.field public static final iconfont_Inprocessing:I = 0x7f120680

.field public static final iconfont_Path:I = 0x7f120681

.field public static final iconfont_Path1:I = 0x7f120682

.field public static final iconfont_Successfulpayment:I = 0x7f120683

.field public static final iconfont_Zhuanzai16:I = 0x7f120684

.field public static final iconfont_a_bixinyoubangzhu2x:I = 0x7f120685

.field public static final iconfont_a_huaban2x:I = 0x7f120686

.field public static final iconfont_a_maizuoheyanguanli:I = 0x7f120687

.field public static final iconfont_a_maizuoxiaoshouguanli:I = 0x7f120688

.field public static final iconfont_a_saomaxin:I = 0x7f120689

.field public static final iconfont_ahuaban2x:I = 0x7f12068a

.field public static final iconfont_album:I = 0x7f12068b

.field public static final iconfont_arrow_down:I = 0x7f12068c

.field public static final iconfont_arrow_up:I = 0x7f12068d

.field public static final iconfont_back:I = 0x7f12068e

.field public static final iconfont_bangzhuzhongxin24:I = 0x7f12068f

.field public static final iconfont_banpingfenmian_24:I = 0x7f120690

.field public static final iconfont_baocuntupian32:I = 0x7f120691

.field public static final iconfont_bianji:I = 0x7f120692

.field public static final iconfont_bianji16:I = 0x7f120693

.field public static final iconfont_bianji18:I = 0x7f120694

.field public static final iconfont_bianji24:I = 0x7f120695

.field public static final iconfont_bianji_:I = 0x7f120696

.field public static final iconfont_biaoqian16:I = 0x7f120697

.field public static final iconfont_biaoqian_:I = 0x7f120698

.field public static final iconfont_biaoqing32:I = 0x7f120699

.field public static final iconfont_bofang22:I = 0x7f12069a

.field public static final iconfont_bofang32:I = 0x7f12069b

.field public static final iconfont_butongzhi16:I = 0x7f12069c

.field public static final iconfont_camera_plus:I = 0x7f12069d

.field public static final iconfont_chakandingdan:I = 0x7f12069e

.field public static final iconfont_changbingjiantou:I = 0x7f12069f

.field public static final iconfont_changciqiehuanhoujiantou:I = 0x7f1206a0

.field public static final iconfont_changyonggoupiaoren48:I = 0x7f1206a1

.field public static final iconfont_changyonglianxiren_:I = 0x7f1206a2

.field public static final iconfont_chenggong:I = 0x7f1206a3

.field public static final iconfont_chenggong1:I = 0x7f1206a4

.field public static final iconfont_chenggong16:I = 0x7f1206a5

.field public static final iconfont_chouti18:I = 0x7f1206a6

.field public static final iconfont_ciyuhaoping24:I = 0x7f1206a7

.field public static final iconfont_comment:I = 0x7f1206a8

.field public static final iconfont_comment_like:I = 0x7f1206a9

.field public static final iconfont_comment_more:I = 0x7f1206aa

.field public static final iconfont_comment_reply:I = 0x7f1206ab

.field public static final iconfont_dacha12:I = 0x7f1206ac

.field public static final iconfont_dagou12:I = 0x7f1206ad

.field public static final iconfont_daifukuan48:I = 0x7f1206ae

.field public static final iconfont_daipingjia48:I = 0x7f1206af

.field public static final iconfont_daishouhuo48:I = 0x7f1206b0

.field public static final iconfont_danxuan_weixuan_:I = 0x7f1206b1

.field public static final iconfont_danxuan_xuanzhong_:I = 0x7f1206b2

.field public static final iconfont_danxuanweixuanzhong24:I = 0x7f1206b3

.field public static final iconfont_danxuanxuanzhong16:I = 0x7f1206b4

.field public static final iconfont_danxuanxuanzhong24:I = 0x7f1206b5

.field public static final iconfont_dayi_:I = 0x7f1206b6

.field public static final iconfont_dengluzhanghao:I = 0x7f1206b7

.field public static final iconfont_detail_location:I = 0x7f1206b8

.field public static final iconfont_detail_seat:I = 0x7f1206b9

.field public static final iconfont_detail_share:I = 0x7f1206ba

.field public static final iconfont_dianhua:I = 0x7f1206bb

.field public static final iconfont_dianhua16:I = 0x7f1206bc

.field public static final iconfont_dianpupingfen_24:I = 0x7f1206bd

.field public static final iconfont_dianyingpiao:I = 0x7f1206be

.field public static final iconfont_dianzan:I = 0x7f1206bf

.field public static final iconfont_dianzan1:I = 0x7f1206c0

.field public static final iconfont_dianzan16:I = 0x7f1206c1

.field public static final iconfont_dianzan_:I = 0x7f1206c2

.field public static final iconfont_dianzan_dianjitai:I = 0x7f1206c3

.field public static final iconfont_dianzan_weidianjitai:I = 0x7f1206c4

.field public static final iconfont_dianzanmian_:I = 0x7f1206c5

.field public static final iconfont_dianzanmianxing:I = 0x7f1206c6

.field public static final iconfont_diliweizhi16:I = 0x7f1206c7

.field public static final iconfont_dingdan_:I = 0x7f1206c8

.field public static final iconfont_dingdanxiangqingyeerweima_:I = 0x7f1206c9

.field public static final iconfont_dingwei12:I = 0x7f1206ca

.field public static final iconfont_dingweichangguan_:I = 0x7f1206cb

.field public static final iconfont_dingyue12:I = 0x7f1206cc

.field public static final iconfont_dingyue48:I = 0x7f1206cd

.field public static final iconfont_ditu12:I = 0x7f1206ce

.field public static final iconfont_dizhi:I = 0x7f1206cf

.field public static final iconfont_dizhi12:I = 0x7f1206d0

.field public static final iconfont_dizhi_:I = 0x7f1206d1

.field public static final iconfont_dizhiguanli48:I = 0x7f1206d2

.field public static final iconfont_down_load:I = 0x7f1206d3

.field public static final iconfont_duihao_:I = 0x7f1206d4

.field public static final iconfont_duihaomian_:I = 0x7f1206d5

.field public static final iconfont_duihuan_:I = 0x7f1206d6

.field public static final iconfont_duoxuan_weixuan_:I = 0x7f1206d7

.field public static final iconfont_duoxuan_xuanzhong_:I = 0x7f1206d8

.field public static final iconfont_erweima:I = 0x7f1206d9

.field public static final iconfont_erweima24:I = 0x7f1206da

.field public static final iconfont_eye_hide:I = 0x7f1206db

.field public static final iconfont_eye_show:I = 0x7f1206dc

.field public static final iconfont_fabiao16:I = 0x7f1206dd

.field public static final iconfont_fabiao24:I = 0x7f1206de

.field public static final iconfont_fabu_24:I = 0x7f1206df

.field public static final iconfont_fabu_shipin_34:I = 0x7f1206e0

.field public static final iconfont_fabu_tupian_34:I = 0x7f1206e1

.field public static final iconfont_faceicon_:I = 0x7f1206e2

.field public static final iconfont_fangda22:I = 0x7f1206e3

.field public static final iconfont_fangdajing_:I = 0x7f1206e4

.field public static final iconfont_fanhui:I = 0x7f1206e5

.field public static final iconfont_fanhui18:I = 0x7f1206e6

.field public static final iconfont_fanhui24:I = 0x7f1206e7

.field public static final iconfont_fanhuishiqu:I = 0x7f1206e8

.field public static final iconfont_faxian28:I = 0x7f1206e9

.field public static final iconfont_faxian48:I = 0x7f1206ea

.field public static final iconfont_fenleiyebofang18:I = 0x7f1206eb

.field public static final iconfont_fensi12:I = 0x7f1206ec

.field public static final iconfont_fenxiang:I = 0x7f1206ed

.field public static final iconfont_fenxiang16:I = 0x7f1206ee

.field public static final iconfont_fenxiang18:I = 0x7f1206ef

.field public static final iconfont_fenxiang24:I = 0x7f1206f0

.field public static final iconfont_fenxiang44:I = 0x7f1206f1

.field public static final iconfont_fenxiang48:I = 0x7f1206f2

.field public static final iconfont_fenxiang_:I = 0x7f1206f3

.field public static final iconfont_fenxiang_pengyouquan_24:I = 0x7f1206f4

.field public static final iconfont_fenxiang_tupian_24:I = 0x7f1206f5

.field public static final iconfont_fenxiang_weibo_24:I = 0x7f1206f6

.field public static final iconfont_fenxiang_weixin_24:I = 0x7f1206f7

.field public static final iconfont_fenxiang_yinhao_35:I = 0x7f1206f8

.field public static final iconfont_fenxiangicon:I = 0x7f1206f9

.field public static final iconfont_fill_guanbi:I = 0x7f1206fa

.field public static final iconfont_fill_youhuiquan:I = 0x7f1206fb

.field public static final iconfont_fucengguanbi16:I = 0x7f1206fc

.field public static final iconfont_fuxuanweixuanzhong24:I = 0x7f1206fd

.field public static final iconfont_fuxuanxuanzhong24:I = 0x7f1206fe

.field public static final iconfont_gengduo16:I = 0x7f120700

.field public static final iconfont_gengduo24:I = 0x7f120701

.field public static final iconfont_gengduoshu:I = 0x7f120702

.field public static final iconfont_gengxin24:I = 0x7f120703

.field public static final iconfont_gerenshezhi24:I = 0x7f120704

.field public static final iconfont_gonggao:I = 0x7f120705

.field public static final iconfont_gongyi24:I = 0x7f120706

.field public static final iconfont_goupiaobaoyou72:I = 0x7f120707

.field public static final iconfont_goupiaoren24:I = 0x7f120708

.field public static final iconfont_gouxuan:I = 0x7f120709

.field public static final iconfont_gouxuanweixuanzhong28:I = 0x7f12070a

.field public static final iconfont_gouxuanxuanzhong28:I = 0x7f12070b

.field public static final iconfont_guanbi12:I = 0x7f12070c

.field public static final iconfont_guanbi16:I = 0x7f12070d

.field public static final iconfont_guanbi24:I = 0x7f12070e

.field public static final iconfont_guanbi_:I = 0x7f12070f

.field public static final iconfont_guanbi_28:I = 0x7f120710

.field public static final iconfont_guanbiyuan_:I = 0x7f120711

.field public static final iconfont_guanbiyuanxian_:I = 0x7f120712

.field public static final iconfont_guanyudamai24:I = 0x7f120713

.field public static final iconfont_guanzhongpingjia:I = 0x7f120714

.field public static final iconfont_guanzhuderen48:I = 0x7f120715

.field public static final iconfont_guanzhudeyanchu48:I = 0x7f120716

.field public static final iconfont_guanzhuhehuifu24:I = 0x7f120717

.field public static final iconfont_huabian:I = 0x7f120718

.field public static final iconfont_huabianfan:I = 0x7f120719

.field public static final iconfont_huanyihuan:I = 0x7f12071a

.field public static final iconfont_huidaoquanju:I = 0x7f12071b

.field public static final iconfont_huiyuan48:I = 0x7f12071c

.field public static final iconfont_huiyuan_:I = 0x7f12071d

.field public static final iconfont_huiyuanzhongxin24:I = 0x7f12071e

.field public static final iconfont_jiageyangjiaobiao:I = 0x7f12071f

.field public static final iconfont_jiahao16:I = 0x7f120720

.field public static final iconfont_jiahao24:I = 0x7f120721

.field public static final iconfont_jiahao_:I = 0x7f120722

.field public static final iconfont_jianpan32:I = 0x7f120723

.field public static final iconfont_jiantouxiangyou:I = 0x7f120724

.field public static final iconfont_jiantouxiangzuo:I = 0x7f120725

.field public static final iconfont_jiantouzuo:I = 0x7f120726

.field public static final iconfont_jiarujiahao24:I = 0x7f120727

.field public static final iconfont_jiazai:I = 0x7f120728

.field public static final iconfont_jingyin:I = 0x7f120729

.field public static final iconfont_jinzhi24:I = 0x7f12072a

.field public static final iconfont_jubao:I = 0x7f12072b

.field public static final iconfont_jubao1:I = 0x7f12072c

.field public static final iconfont_jubensha:I = 0x7f12072d

.field public static final iconfont_juhex:I = 0x7f12072e

.field public static final iconfont_kefu:I = 0x7f12072f

.field public static final iconfont_kefu_:I = 0x7f120730

.field public static final iconfont_kefu_16:I = 0x7f120731

.field public static final iconfont_kefudianhua24:I = 0x7f120732

.field public static final iconfont_liaotian24:I = 0x7f120733

.field public static final iconfont_light_off:I = 0x7f120734

.field public static final iconfont_light_on:I = 0x7f120735

.field public static final iconfont_line_guanbi:I = 0x7f120736

.field public static final iconfont_lingdang_:I = 0x7f120737

.field public static final iconfont_lingguangle:I = 0x7f120738

.field public static final iconfont_lishipiao16:I = 0x7f120739

.field public static final iconfont_maixiaomi24:I = 0x7f12073a

.field public static final iconfont_meibangzhu:I = 0x7f12073b

.field public static final iconfont_meinfo:I = 0x7f12073c

.field public static final iconfont_melook1:I = 0x7f12073d

.field public static final iconfont_memember1:I = 0x7f12073e

.field public static final iconfont_memoney1:I = 0x7f12073f

.field public static final iconfont_meorders1:I = 0x7f120740

.field public static final iconfont_mepublicbenefit1:I = 0x7f120741

.field public static final iconfont_meservice1:I = 0x7f120742

.field public static final iconfont_meset:I = 0x7f120743

.field public static final iconfont_mesite1:I = 0x7f120744

.field public static final iconfont_message_new:I = 0x7f120745

.field public static final iconfont_more:I = 0x7f120746

.field public static final iconfont_nan16:I = 0x7f120747

.field public static final iconfont_nv16:I = 0x7f120748

.field public static final iconfont_paixu_24:I = 0x7f120749

.field public static final iconfont_paizhao32:I = 0x7f12074a

.field public static final iconfont_parking:I = 0x7f12074b

.field public static final iconfont_peisongwuliu16:I = 0x7f12074c

.field public static final iconfont_piaojia24:I = 0x7f12074d

.field public static final iconfont_piaojia28:I = 0x7f12074e

.field public static final iconfont_piaojialishi64:I = 0x7f12074f

.field public static final iconfont_pingfen_:I = 0x7f120750

.field public static final iconfont_pingfenmian_:I = 0x7f120751

.field public static final iconfont_pingjia:I = 0x7f120752

.field public static final iconfont_pingjiadandu:I = 0x7f120753

.field public static final iconfont_pingjiajieshao:I = 0x7f120754

.field public static final iconfont_pinglun:I = 0x7f120755

.field public static final iconfont_pinglun1:I = 0x7f120756

.field public static final iconfont_pinglun16:I = 0x7f120757

.field public static final iconfont_pinglun_:I = 0x7f120758

.field public static final iconfont_pingwen12:I = 0x7f120759

.field public static final iconfont_pingzheng12:I = 0x7f12075a

.field public static final iconfont_qianbao_:I = 0x7f12075b

.field public static final iconfont_qingchu24:I = 0x7f12075c

.field public static final iconfont_qingchuhuancun24:I = 0x7f12075d

.field public static final iconfont_quanbudingdan48:I = 0x7f12075e

.field public static final iconfont_quanpingbofang:I = 0x7f12075f

.field public static final iconfont_qunliao24:I = 0x7f120760

.field public static final iconfont_qunliao32:I = 0x7f120761

.field public static final iconfont_qunshezhi24:I = 0x7f120762

.field public static final iconfont_rili:I = 0x7f120763

.field public static final iconfont_rili_:I = 0x7f120764

.field public static final iconfont_rili_24:I = 0x7f120765

.field public static final iconfont_rukoujiantou_16:I = 0x7f120766

.field public static final iconfont_saoma_:I = 0x7f120767

.field public static final iconfont_saoyisao18:I = 0x7f120768

.field public static final iconfont_saoyisao48:I = 0x7f120769

.field public static final iconfont_scan_back:I = 0x7f12076a

.field public static final iconfont_setting_new:I = 0x7f12076b

.field public static final iconfont_shaixuan16:I = 0x7f12076c

.field public static final iconfont_shaixuansanjiao:I = 0x7f12076d

.field public static final iconfont_shaixuanshang12:I = 0x7f12076e

.field public static final iconfont_shaixuanxia12:I = 0x7f12076f

.field public static final iconfont_shanchu:I = 0x7f120770

.field public static final iconfont_shanchu1:I = 0x7f120771

.field public static final iconfont_shanchu18:I = 0x7f120772

.field public static final iconfont_shanchu24:I = 0x7f120773

.field public static final iconfont_shanchu_:I = 0x7f120774

.field public static final iconfont_shangfan12:I = 0x7f120775

.field public static final iconfont_shangjiantou:I = 0x7f120776

.field public static final iconfont_shangjiantou12:I = 0x7f120777

.field public static final iconfont_shangsheng12:I = 0x7f120778

.field public static final iconfont_shenfenzheng:I = 0x7f120779

.field public static final iconfont_shengjibanben:I = 0x7f12077a

.field public static final iconfont_shengyin:I = 0x7f12077b

.field public static final iconfont_shengyin1:I = 0x7f12077c

.field public static final iconfont_shengyin16:I = 0x7f12077d

.field public static final iconfont_shengyin2:I = 0x7f12077e

.field public static final iconfont_shengyinguan22:I = 0x7f12077f

.field public static final iconfont_shengyinkai22:I = 0x7f120780

.field public static final iconfont_shezhi:I = 0x7f120781

.field public static final iconfont_shezhi18:I = 0x7f120782

.field public static final iconfont_shezhi48:I = 0x7f120783

.field public static final iconfont_shezhi_:I = 0x7f120784

.field public static final iconfont_shezhifengmian12:I = 0x7f120785

.field public static final iconfont_shibai:I = 0x7f120786

.field public static final iconfont_shibai1:I = 0x7f120787

.field public static final iconfont_shijian:I = 0x7f120788

.field public static final iconfont_shijian12:I = 0x7f120789

.field public static final iconfont_shijian16:I = 0x7f12078a

.field public static final iconfont_shijiandian8:I = 0x7f12078b

.field public static final iconfont_shipin_12:I = 0x7f12078c

.field public static final iconfont_shop:I = 0x7f12078d

.field public static final iconfont_shoudiantong24:I = 0x7f12078e

.field public static final iconfont_shoudiantong_guan:I = 0x7f12078f

.field public static final iconfont_shoudiantong_kai:I = 0x7f120790

.field public static final iconfont_shoudiantongkai24:I = 0x7f120791

.field public static final iconfont_shouhuodizhi16:I = 0x7f120792

.field public static final iconfont_shouji:I = 0x7f120793

.field public static final iconfont_shouqi32:I = 0x7f120794

.field public static final iconfont_shouqi8:I = 0x7f120795

.field public static final iconfont_shouye28:I = 0x7f120796

.field public static final iconfont_shouye_:I = 0x7f120797

.field public static final iconfont_shouyedingwei18:I = 0x7f120798

.field public static final iconfont_shouyefangzi28:I = 0x7f120799

.field public static final iconfont_shuoming12:I = 0x7f12079a

.field public static final iconfont_sixin12:I = 0x7f12079b

.field public static final iconfont_sixin16:I = 0x7f12079c

.field public static final iconfont_sixin24:I = 0x7f12079d

.field public static final iconfont_smartticket_copy:I = 0x7f12079e

.field public static final iconfont_sousuo:I = 0x7f12079f

.field public static final iconfont_sousuo16:I = 0x7f1207a0

.field public static final iconfont_sousuo22:I = 0x7f1207a1

.field public static final iconfont_sousuo24:I = 0x7f1207a2

.field public static final iconfont_sousuo_:I = 0x7f1207a3

.field public static final iconfont_sousuo_pioneer:I = 0x7f1207a4

.field public static final iconfont_store:I = 0x7f1207a5

.field public static final iconfont_tanhao:I = 0x7f1207a6

.field public static final iconfont_tequan16:I = 0x7f1207a7

.field public static final iconfont_thin_right_arrow:I = 0x7f1207a8

.field public static final iconfont_tianjia32:I = 0x7f1207a9

.field public static final iconfont_tianjiapiao16:I = 0x7f1207aa

.field public static final iconfont_tianjiatupian32:I = 0x7f1207ab

.field public static final iconfont_tianxie:I = 0x7f1207ac

.field public static final iconfont_ticket_leftarrows:I = 0x7f1207ad

.field public static final iconfont_ticket_phone:I = 0x7f1207ae

.field public static final iconfont_ticket_point:I = 0x7f1207af

.field public static final iconfont_ticket_rightarrows:I = 0x7f1207b0

.field public static final iconfont_ticket_time:I = 0x7f1207b1

.field public static final iconfont_timechange_:I = 0x7f1207b2

.field public static final iconfont_tishi:I = 0x7f1207b3

.field public static final iconfont_tishi_:I = 0x7f1207b4

.field public static final iconfont_tishimian_:I = 0x7f1207b5

.field public static final iconfont_tixing12:I = 0x7f1207b6

.field public static final iconfont_tixing16:I = 0x7f1207b7

.field public static final iconfont_tixing18:I = 0x7f1207b8

.field public static final iconfont_tixing24:I = 0x7f1207b9

.field public static final iconfont_tixing32:I = 0x7f1207ba

.field public static final iconfont_tixingmian_:I = 0x7f1207bb

.field public static final iconfont_tixingxian_:I = 0x7f1207bc

.field public static final iconfont_tongxunlu_:I = 0x7f1207bd

.field public static final iconfont_tongzhi24:I = 0x7f1207be

.field public static final iconfont_tongzhishezhi24:I = 0x7f1207bf

.field public static final iconfont_transportation:I = 0x7f1207c0

.field public static final iconfont_tuce_12:I = 0x7f1207c1

.field public static final iconfont_tuijian48:I = 0x7f1207c2

.field public static final iconfont_tuoyuansanjiao:I = 0x7f1207c3

.field public static final iconfont_tupian:I = 0x7f1207c4

.field public static final iconfont_tupian12:I = 0x7f1207c5

.field public static final iconfont_user_delete:I = 0x7f1207c6

.field public static final iconfont_user_edit:I = 0x7f1207c7

.field public static final iconfont_video_plus:I = 0x7f1207c8

.field public static final iconfont_voice_off:I = 0x7f1207c9

.field public static final iconfont_voice_on:I = 0x7f1207ca

.field public static final iconfont_wangluoxinhao48:I = 0x7f1207cb

.field public static final iconfont_washroom:I = 0x7f1207cc

.field public static final iconfont_weigouxuan:I = 0x7f1207cd

.field public static final iconfont_weiguan_:I = 0x7f1207ce

.field public static final iconfont_weixin:I = 0x7f1207cf

.field public static final iconfont_weixuan16:I = 0x7f1207d0

.field public static final iconfont_weizhi:I = 0x7f1207d1

.field public static final iconfont_wi_fi:I = 0x7f1207d2

.field public static final iconfont_wode28:I = 0x7f1207d3

.field public static final iconfont_wode48:I = 0x7f1207d4

.field public static final iconfont_wode_:I = 0x7f1207d5

.field public static final iconfont_wodedingdan_:I = 0x7f1207d6

.field public static final iconfont_wodepiao32:I = 0x7f1207d7

.field public static final iconfont_wodepiao48:I = 0x7f1207d8

.field public static final iconfont_wodeshouhuodizhi_:I = 0x7f1207d9

.field public static final iconfont_wuliu:I = 0x7f1207da

.field public static final iconfont_xf_NFT:I = 0x7f1207db

.field public static final iconfont_xf_anquan:I = 0x7f1207dc

.field public static final iconfont_xf_bofang:I = 0x7f1207dd

.field public static final iconfont_xf_changbingjiantou:I = 0x7f1207de

.field public static final iconfont_xf_changyongxinxi:I = 0x7f1207df

.field public static final iconfont_xf_dianziqianbao:I = 0x7f1207e0

.field public static final iconfont_xf_duigoubig:I = 0x7f1207e1

.field public static final iconfont_xf_erweima:I = 0x7f1207e2

.field public static final iconfont_xf_fangdajing:I = 0x7f1207e3

.field public static final iconfont_xf_fenxiang:I = 0x7f1207e4

.field public static final iconfont_xf_gongyi:I = 0x7f1207e5

.field public static final iconfont_xf_guanbi:I = 0x7f1207e6

.field public static final iconfont_xf_guanbibig:I = 0x7f1207e7

.field public static final iconfont_xf_guanyantuan:I = 0x7f1207e8

.field public static final iconfont_xf_hengping:I = 0x7f1207e9

.field public static final iconfont_xf_jiahaobig:I = 0x7f1207ea

.field public static final iconfont_xf_jiantoubig_shang:I = 0x7f1207eb

.field public static final iconfont_xf_jiantoubig_xia:I = 0x7f1207ec

.field public static final iconfont_xf_jiantoubig_you:I = 0x7f1207ed

.field public static final iconfont_xf_jiantoubig_zuo:I = 0x7f1207ee

.field public static final iconfont_xf_jiantousmall_shang:I = 0x7f1207ef

.field public static final iconfont_xf_jiantousmall_xia:I = 0x7f1207f0

.field public static final iconfont_xf_jiantousmall_xiangxia:I = 0x7f1207f1

.field public static final iconfont_xf_jiantousmall_xiangyou:I = 0x7f1207f2

.field public static final iconfont_xf_jiantousmall_you:I = 0x7f1207f3

.field public static final iconfont_xf_jiantousmall_zuo:I = 0x7f1207f4

.field public static final iconfont_xf_jieqian:I = 0x7f1207f5

.field public static final iconfont_xf_jingyin:I = 0x7f1207f6

.field public static final iconfont_xf_kefu:I = 0x7f1207f7

.field public static final iconfont_xf_kuaishanhongbao:I = 0x7f1207f8

.field public static final iconfont_xf_lajitong:I = 0x7f1207f9

.field public static final iconfont_xf_lipinka:I = 0x7f1207fa

.field public static final iconfont_xf_qiehuimoshi:I = 0x7f1207fb

.field public static final iconfont_xf_quanping:I = 0x7f1207fc

.field public static final iconfont_xf_sanjiaojiantou_shang:I = 0x7f1207fd

.field public static final iconfont_xf_sanjiaojiantou_xia:I = 0x7f1207fe

.field public static final iconfont_xf_sanjiaojiantou_you:I = 0x7f1207ff

.field public static final iconfont_xf_shaixuanzhankai:I = 0x7f120800

.field public static final iconfont_xf_shezhi:I = 0x7f120801

.field public static final iconfont_xf_shiming:I = 0x7f120802

.field public static final iconfont_xf_shouhuodizhi:I = 0x7f120803

.field public static final iconfont_xf_suofang:I = 0x7f120804

.field public static final iconfont_xf_taobao:I = 0x7f120805

.field public static final iconfont_xf_weixuanzhong:I = 0x7f120806

.field public static final iconfont_xf_xiaoxi:I = 0x7f120807

.field public static final iconfont_xf_xinSmall:I = 0x7f120808

.field public static final iconfont_xf_xinline:I = 0x7f120809

.field public static final iconfont_xf_xuanzhongchenggong:I = 0x7f12080a

.field public static final iconfont_xf_yingchengka:I = 0x7f12080b

.field public static final iconfont_xf_yonghufankui:I = 0x7f12080c

.field public static final iconfont_xf_youhuiquan:I = 0x7f12080d

.field public static final iconfont_xf_yunbaochang:I = 0x7f12080e

.field public static final iconfont_xiajiang12:I = 0x7f12080f

.field public static final iconfont_xiajiantou:I = 0x7f120810

.field public static final iconfont_xiajiantou12:I = 0x7f120811

.field public static final iconfont_xiajiantouxiao_:I = 0x7f120812

.field public static final iconfont_xiangce24:I = 0x7f120813

.field public static final iconfont_xiangce32:I = 0x7f120814

.field public static final iconfont_xiangji24:I = 0x7f120815

.field public static final iconfont_xiangkan24:I = 0x7f120816

.field public static final iconfont_xiangkan48:I = 0x7f120817

.field public static final iconfont_xiangkan_:I = 0x7f120818

.field public static final iconfont_xiangkanmian_:I = 0x7f120819

.field public static final iconfont_xiangmutixing32:I = 0x7f12081a

.field public static final iconfont_xiangqingkefu24:I = 0x7f12081b

.field public static final iconfont_xiangshangjiantou_:I = 0x7f12081c

.field public static final iconfont_xiangxiajiantou_:I = 0x7f12081d

.field public static final iconfont_xianshi:I = 0x7f12081e

.field public static final iconfont_xianxin24:I = 0x7f12081f

.field public static final iconfont_xiaoshi_:I = 0x7f120820

.field public static final iconfont_xiaoxi:I = 0x7f120821

.field public static final iconfont_xiaoxi18:I = 0x7f120822

.field public static final iconfont_xiaoxi48:I = 0x7f120823

.field public static final iconfont_xiaoxi_:I = 0x7f120824

.field public static final iconfont_xiazai32:I = 0x7f120825

.field public static final iconfont_xiegang:I = 0x7f120826

.field public static final iconfont_xiepinglun24:I = 0x7f120827

.field public static final iconfont_xin22:I = 0x7f120828

.field public static final iconfont_xinghao:I = 0x7f120829

.field public static final iconfont_xinxi:I = 0x7f12082a

.field public static final iconfont_xinxitishi36:I = 0x7f12082b

.field public static final iconfont_xitongshezhi3x:I = 0x7f12082c

.field public static final iconfont_xuanzhong16:I = 0x7f12082d

.field public static final iconfont_xuanzhongduihao_8:I = 0x7f12082e

.field public static final iconfont_xuanzuo:I = 0x7f12082f

.field public static final iconfont_yanchu32:I = 0x7f120830

.field public static final iconfont_yanchurili18:I = 0x7f120831

.field public static final iconfont_yiduihuan:I = 0x7f120832

.field public static final iconfont_yiguoqi:I = 0x7f120833

.field public static final iconfont_yijianfankui:I = 0x7f120834

.field public static final iconfont_yijianfankui48:I = 0x7f120835

.field public static final iconfont_yilingqu:I = 0x7f120836

.field public static final iconfont_yincang:I = 0x7f120837

.field public static final iconfont_yinhao_24:I = 0x7f120838

.field public static final iconfont_yinsishezhi:I = 0x7f120839

.field public static final iconfont_yiwen_24:I = 0x7f12083a

.field public static final iconfont_yonghuxieyi:I = 0x7f12083b

.field public static final iconfont_youjiantou12:I = 0x7f12083c

.field public static final iconfont_youjiantou16:I = 0x7f12083d

.field public static final iconfont_youjiantou24:I = 0x7f12083e

.field public static final iconfont_youjiantou_:I = 0x7f12083f

.field public static final iconfont_youjiantouxiao12:I = 0x7f120840

.field public static final iconfont_youkuohao18:I = 0x7f120841

.field public static final iconfont_youxianyuding72:I = 0x7f120842

.field public static final iconfont_yuangouxuanweixuanzhong:I = 0x7f120843

.field public static final iconfont_yuangouxuanxuanzhong:I = 0x7f120844

.field public static final iconfont_yushou16:I = 0x7f120845

.field public static final iconfont_yuyin32:I = 0x7f120846

.field public static final iconfont_zaixiankefu48:I = 0x7f120847

.field public static final iconfont_zan:I = 0x7f120848

.field public static final iconfont_zan24:I = 0x7f120849

.field public static final iconfont_zanting22:I = 0x7f12084a

.field public static final iconfont_zhanghaoanquan24:I = 0x7f12084b

.field public static final iconfont_zhankai32:I = 0x7f12084c

.field public static final iconfont_zhankai8:I = 0x7f12084d

.field public static final iconfont_zhiding_24:I = 0x7f12084e

.field public static final iconfont_zhifubao:I = 0x7f12084f

.field public static final iconfont_zhizhipiao_24:I = 0x7f120850

.field public static final iconfont_zhuanhuan:I = 0x7f120851

.field public static final iconfont_zhuanzai:I = 0x7f120852

.field public static final iconfont_zhuanzai_:I = 0x7f120853

.field public static final iconfont_zuojiantou_:I = 0x7f120854

.field public static final iconfont_zuokuohao18:I = 0x7f120855

.field public static final iconfont_zuowei:I = 0x7f120856

.field public static final iconfont_zuowei12:I = 0x7f120857

.field public static final iconfont_zuowei16:I = 0x7f120858

.field public static final iconfont_zuoweimingxiguanbi:I = 0x7f120859

.field public static final iconfont_zuoweitu18:I = 0x7f12085a

.field public static final id_hk_back_title:I = 0x7f12085b

.field public static final id_hk_front_title:I = 0x7f12085c

.field public static final id_hk_hint:I = 0x7f12085d

.field public static final id_tw_back_title:I = 0x7f12085e

.field public static final id_tw_front_title:I = 0x7f12085f

.field public static final id_tw_hint:I = 0x7f120860

.field public static final identity_back_title:I = 0x7f120861

.field public static final identity_fg_back_title:I = 0x7f120862

.field public static final identity_fg_front_title:I = 0x7f120863

.field public static final identity_fg_hint:I = 0x7f120864

.field public static final identity_front_title:I = 0x7f120865

.field public static final identity_guide_agree:I = 0x7f120866

.field public static final identity_guide_alert:I = 0x7f120867

.field public static final identity_guide_start:I = 0x7f120868

.field public static final identity_guide_tip:I = 0x7f120869

.field public static final identity_guide_welcome:I = 0x7f12086a

.field public static final identity_hint:I = 0x7f12086b

.field public static final identity_hk_back_title:I = 0x7f12086c

.field public static final identity_hk_front_title:I = 0x7f12086d

.field public static final identity_hk_hint:I = 0x7f12086e

.field public static final identity_privacy_authorization_statement:I = 0x7f12086f

.field public static final identity_privacy_authorization_statement_title:I = 0x7f120870

.field public static final identity_tw_back_title:I = 0x7f120871

.field public static final identity_tw_front_title:I = 0x7f120872

.field public static final identity_tw_hint:I = 0x7f120873

.field public static final image:I = 0x7f120874

.field public static final import_complete_dialog_desc:I = 0x7f120875

.field public static final import_complete_dialog_title:I = 0x7f120876

.field public static final import_fail_dialog_desc:I = 0x7f120877

.field public static final import_fail_dialog_title:I = 0x7f120878

.field public static final import_friend_title:I = 0x7f120879

.field public static final import_result_dialog_button:I = 0x7f12087a

.field public static final import_result_dialog_title:I = 0x7f12087b

.field public static final import_success_dialog_desc:I = 0x7f12087c

.field public static final import_tip_button:I = 0x7f12087d

.field public static final import_tip_desc:I = 0x7f12087e

.field public static final import_tip_item1:I = 0x7f12087f

.field public static final import_tip_item2:I = 0x7f120880

.field public static final import_tip_title:I = 0x7f120881

.field public static final importing_title:I = 0x7f120882

.field public static final in_progress:I = 0x7f120883

.field public static final include_coupon_none_view_01:I = 0x7f120884

.field public static final include_pay_method_01:I = 0x7f120885

.field public static final include_verify_code_01:I = 0x7f120886

.field public static final indeterminate:I = 0x7f120887

.field public static final init_price:I = 0x7f120888

.field public static final install:I = 0x7f120889

.field public static final issue:I = 0x7f12088a

.field public static final issue_success:I = 0x7f120896

.field public static final issue_title:I = 0x7f120899

.field public static final issue_to:I = 0x7f12089a

.field public static final item_circle_rule:I = 0x7f12089c

.field public static final item_feed_vote_title:I = 0x7f12089d

.field public static final item_view_role_description:I = 0x7f12089e

.field public static final join_discuss:I = 0x7f12089f

.field public static final jump_to_coupon:I = 0x7f1208a0

.field public static final known:I = 0x7f1208a1

.field public static final last_pub_time:I = 0x7f1208a3

.field public static final last_update:I = 0x7f1208a4

.field public static final leading_role_prefix:I = 0x7f1208ad

.field public static final let_her_go:I = 0x7f1208ae

.field public static final like_it:I = 0x7f1208af

.field public static final like_it_done:I = 0x7f1208b0

.field public static final link_copy_success:I = 0x7f1208b1

.field public static final link_long_video_history:I = 0x7f1208b2

.field public static final list_audience:I = 0x7f1208b3

.field public static final list_card:I = 0x7f1208b4

.field public static final list_coupons:I = 0x7f1208b5

.field public static final list_derivatives:I = 0x7f1208b6

.field public static final list_friends:I = 0x7f1208b7

.field public static final list_help_center_title:I = 0x7f1208b8

.field public static final list_item_movie_order_02:I = 0x7f1208b9

.field public static final list_item_movie_order_03:I = 0x7f1208ba

.field public static final list_liked_movies:I = 0x7f1208bb

.field public static final list_liked_movies_and_performance:I = 0x7f1208bc

.field public static final list_member:I = 0x7f1208bd

.field public static final list_my_art_castle:I = 0x7f1208be

.field public static final list_my_chargecard:I = 0x7f1208bf

.field public static final list_my_discuss:I = 0x7f1208c0

.field public static final list_my_group_movie:I = 0x7f1208c1

.field public static final list_settings:I = 0x7f1208c2

.field public static final list_settings_tip:I = 0x7f1208c3

.field public static final list_shipping_address:I = 0x7f1208c4

.field public static final list_show:I = 0x7f1208c5

.field public static final list_subscribe:I = 0x7f1208c6

.field public static final list_tickets:I = 0x7f1208c7

.field public static final list_watched_movies:I = 0x7f1208c8

.field public static final load_gesture_img_faild:I = 0x7f1208c9

.field public static final load_more_empty:I = 0x7f1208ca

.field public static final loading_text:I = 0x7f1208cb

.field public static final login_and_buy:I = 0x7f1208cc

.field public static final login_text:I = 0x7f1208cd

.field public static final login_thirdplatform_mobile:I = 0x7f1208ce

.field public static final login_thirdplatform_more:I = 0x7f1208cf

.field public static final login_thirdplatform_passkey:I = 0x7f1208d0

.field public static final login_thirdplatform_passkey_des:I = 0x7f1208d1

.field public static final login_thirdplatform_taobao:I = 0x7f1208d2

.field public static final login_thirdplatform_zhifubao:I = 0x7f1208d3

.field public static final login_tip:I = 0x7f1208d4

.field public static final long_video_buy_desc:I = 0x7f1208d5

.field public static final look_all_cinemas:I = 0x7f1208d6

.field public static final lottery_dialog_coin_not_enough:I = 0x7f1208d7

.field public static final lottery_discount_description:I = 0x7f1208d8

.field public static final lottery_draw_coin_not_enough:I = 0x7f1208d9

.field public static final lottery_draw_dialog_prompt:I = 0x7f1208da

.field public static final lottery_draw_dialog_prompt_without_happy_coin:I = 0x7f1208db

.field public static final lottery_draw_hint_with_happy_coin:I = 0x7f1208dc

.field public static final lottery_draw_hint_without_happy_coin:I = 0x7f1208dd

.field public static final luck_draw_coin_num_hint:I = 0x7f1208de

.field public static final luck_draw_hint:I = 0x7f1208df

.field public static final luck_draw_tag_hint:I = 0x7f1208e0

.field public static final luck_draw_tag_score_hint:I = 0x7f1208e1

.field public static final main_header_01:I = 0x7f1208f1

.field public static final material_clock_display_divider:I = 0x7f1208f2

.field public static final material_clock_toggle_content_description:I = 0x7f1208f3

.field public static final material_hour_selection:I = 0x7f1208f4

.field public static final material_hour_suffix:I = 0x7f1208f5

.field public static final material_minute_selection:I = 0x7f1208f6

.field public static final material_minute_suffix:I = 0x7f1208f7

.field public static final material_motion_easing_accelerated:I = 0x7f1208f8

.field public static final material_motion_easing_decelerated:I = 0x7f1208f9

.field public static final material_motion_easing_emphasized:I = 0x7f1208fa

.field public static final material_motion_easing_linear:I = 0x7f1208fb

.field public static final material_motion_easing_standard:I = 0x7f1208fc

.field public static final material_slider_range_end:I = 0x7f1208fd

.field public static final material_slider_range_start:I = 0x7f1208fe

.field public static final material_timepicker_am:I = 0x7f1208ff

.field public static final material_timepicker_clock_mode_description:I = 0x7f120900

.field public static final material_timepicker_hour:I = 0x7f120901

.field public static final material_timepicker_minute:I = 0x7f120902

.field public static final material_timepicker_pm:I = 0x7f120903

.field public static final material_timepicker_select_time:I = 0x7f120904

.field public static final material_timepicker_text_input_mode_description:I = 0x7f120905

.field public static final max_window:I = 0x7f120906

.field public static final mcard_button_coupon_getuse:I = 0x7f120907

.field public static final mcard_button_coupon_use:I = 0x7f120908

.field public static final mcard_coupon_item_title:I = 0x7f120909

.field public static final member_get_coupon_tip:I = 0x7f12090a

.field public static final member_prefix:I = 0x7f12090c

.field public static final member_score:I = 0x7f12090d

.field public static final member_sdk_authorize_title:I = 0x7f12090e

.field public static final member_sdk_cancel:I = 0x7f12090f

.field public static final member_sdk_continue_bind:I = 0x7f120910

.field public static final member_sdk_continue_upgrade:I = 0x7f120911

.field public static final member_sdk_iknow:I = 0x7f120912

.field public static final member_sdk_message_10003_message:I = 0x7f120913

.field public static final member_sdk_message_10003_name:I = 0x7f120914

.field public static final member_sdk_message_10004_message:I = 0x7f120915

.field public static final member_sdk_message_10004_name:I = 0x7f120916

.field public static final member_sdk_message_10005_message:I = 0x7f120917

.field public static final member_sdk_message_10005_name:I = 0x7f120918

.field public static final member_sdk_message_10010_message:I = 0x7f120919

.field public static final member_sdk_message_10010_name:I = 0x7f12091a

.field public static final member_sdk_message_10015_message:I = 0x7f12091b

.field public static final member_sdk_message_10015_name:I = 0x7f12091c

.field public static final member_sdk_message_10101_message:I = 0x7f12091d

.field public static final member_sdk_message_10101_name:I = 0x7f12091e

.field public static final member_sdk_message_1011_message:I = 0x7f12091f

.field public static final member_sdk_message_1011_name:I = 0x7f120920

.field public static final member_sdk_network_not_available_message:I = 0x7f120921

.field public static final member_sdk_system_exception:I = 0x7f120922

.field public static final member_template_tip:I = 0x7f120923

.field public static final message_center:I = 0x7f120924

.field public static final message_favor_to_content:I = 0x7f120926

.field public static final message_favor_to_discuss:I = 0x7f120927

.field public static final message_favor_to_discuss_replay:I = 0x7f120928

.field public static final message_favor_to_long_video:I = 0x7f120929

.field public static final message_favor_to_moviedate_replay:I = 0x7f12092a

.field public static final message_favor_to_preview_reply:I = 0x7f12092b

.field public static final message_favour_to_comment:I = 0x7f12092c

.field public static final message_replay_to_discuss:I = 0x7f120931

.field public static final message_replay_to_discuss_replay:I = 0x7f120932

.field public static final message_reply_to_article:I = 0x7f120933

.field public static final message_reply_to_comment:I = 0x7f120934

.field public static final message_reply_to_content:I = 0x7f120935

.field public static final message_reply_to_long_video:I = 0x7f120936

.field public static final message_reply_to_moviedate_replay:I = 0x7f120937

.field public static final message_reply_to_preview_reply:I = 0x7f120938

.field public static final message_reply_to_reply:I = 0x7f120939

.field public static final message_reply_to_topic:I = 0x7f12093a

.field public static final min_window:I = 0x7f12093b

.field public static final mine_grabbing_list_tip:I = 0x7f120942

.field public static final mine_header_tip:I = 0x7f120943

.field public static final mine_service_click_expand:I = 0x7f120964

.field public static final mine_service_click_fold:I = 0x7f120965

.field public static final mine_subscribe_empty:I = 0x7f12096c

.field public static final mine_subscribe_title:I = 0x7f12096d

.field public static final more_artiste_picture:I = 0x7f120981

.field public static final more_intro:I = 0x7f120983

.field public static final more_production:I = 0x7f120984

.field public static final movie_known:I = 0x7f120985

.field public static final movie_network_error:I = 0x7f120986

.field public static final movie_protocol:I = 0x7f120987

.field public static final movie_register:I = 0x7f120988

.field public static final movie_reopen:I = 0x7f120989

.field public static final movie_user_protocol_policy:I = 0x7f12098a

.field public static final movie_user_protocol_policy_url:I = 0x7f12098b

.field public static final movie_user_protocol_privacy:I = 0x7f12098c

.field public static final movie_user_protocol_privacy_url:I = 0x7f12098d

.field public static final movie_user_protocol_unchecked_tip:I = 0x7f12098e

.field public static final movie_user_register_protocol_unchecked_tip:I = 0x7f12098f

.field public static final mtrl_badge_numberless_content_description:I = 0x7f120991

.field public static final mtrl_chip_close_icon_content_description:I = 0x7f120992

.field public static final mtrl_exceed_max_badge_number_content_description:I = 0x7f120993

.field public static final mtrl_exceed_max_badge_number_suffix:I = 0x7f120994

.field public static final mtrl_picker_a11y_next_month:I = 0x7f120995

.field public static final mtrl_picker_a11y_prev_month:I = 0x7f120996

.field public static final mtrl_picker_announce_current_selection:I = 0x7f120997

.field public static final mtrl_picker_cancel:I = 0x7f120998

.field public static final mtrl_picker_confirm:I = 0x7f120999

.field public static final mtrl_picker_date_header_selected:I = 0x7f12099a

.field public static final mtrl_picker_date_header_title:I = 0x7f12099b

.field public static final mtrl_picker_date_header_unselected:I = 0x7f12099c

.field public static final mtrl_picker_day_of_week_column_header:I = 0x7f12099d

.field public static final mtrl_picker_invalid_format:I = 0x7f12099e

.field public static final mtrl_picker_invalid_format_example:I = 0x7f12099f

.field public static final mtrl_picker_invalid_format_use:I = 0x7f1209a0

.field public static final mtrl_picker_invalid_range:I = 0x7f1209a1

.field public static final mtrl_picker_navigate_to_year_description:I = 0x7f1209a2

.field public static final mtrl_picker_out_of_range:I = 0x7f1209a3

.field public static final mtrl_picker_range_header_only_end_selected:I = 0x7f1209a4

.field public static final mtrl_picker_range_header_only_start_selected:I = 0x7f1209a5

.field public static final mtrl_picker_range_header_selected:I = 0x7f1209a6

.field public static final mtrl_picker_range_header_title:I = 0x7f1209a7

.field public static final mtrl_picker_range_header_unselected:I = 0x7f1209a8

.field public static final mtrl_picker_save:I = 0x7f1209a9

.field public static final mtrl_picker_text_input_date_hint:I = 0x7f1209aa

.field public static final mtrl_picker_text_input_date_range_end_hint:I = 0x7f1209ab

.field public static final mtrl_picker_text_input_date_range_start_hint:I = 0x7f1209ac

.field public static final mtrl_picker_text_input_day_abbr:I = 0x7f1209ad

.field public static final mtrl_picker_text_input_month_abbr:I = 0x7f1209ae

.field public static final mtrl_picker_text_input_year_abbr:I = 0x7f1209af

.field public static final mtrl_picker_toggle_to_calendar_input_mode:I = 0x7f1209b0

.field public static final mtrl_picker_toggle_to_day_selection:I = 0x7f1209b1

.field public static final mtrl_picker_toggle_to_text_input_mode:I = 0x7f1209b2

.field public static final mtrl_picker_toggle_to_year_selection:I = 0x7f1209b3

.field public static final my_coupons:I = 0x7f1209b5

.field public static final my_follow:I = 0x7f1209b6

.field public static final my_invalid_coupons:I = 0x7f1209b7

.field public static final my_invalid_privileges:I = 0x7f1209b8

.field public static final my_tickets:I = 0x7f1209b9

.field public static final mycomment_comment_done:I = 0x7f1209bf

.field public static final mycomment_dialog_msg:I = 0x7f1209c0

.field public static final mycomment_want_can_buy:I = 0x7f1209c1

.field public static final mycomment_want_done:I = 0x7f1209c2

.field public static final mycomment_want_done2:I = 0x7f1209c3

.field public static final mycomment_want_no_opentime:I = 0x7f1209c4

.field public static final mycomment_want_no_start:I = 0x7f1209c5

.field public static final mycoupon_empty_hint:I = 0x7f1209c6

.field public static final mycoupon_empty_invalide_hint:I = 0x7f1209c7

.field public static final mycoupons_title_dm:I = 0x7f1209c8

.field public static final mycoupons_title_ext:I = 0x7f1209c9

.field public static final mycoupons_title_tpp:I = 0x7f1209ca

.field public static final myticket_empty_hint:I = 0x7f1209cb

.field public static final nav_schema:I = 0x7f1209cc

.field public static final navigation_menu:I = 0x7f1209cd

.field public static final net_error:I = 0x7f1209ce

.field public static final new_comment_success:I = 0x7f1209cf

.field public static final next:I = 0x7f1209d0

.field public static final no_cinema_list:I = 0x7f1209d2

.field public static final no_cinema_list_with_movie:I = 0x7f1209d3

.field public static final no_credential_id:I = 0x7f1209d4

.field public static final no_discuss:I = 0x7f1209d5

.field public static final no_discuss_text:I = 0x7f1209d6

.field public static final no_filter_cinema:I = 0x7f1209d7

.field public static final no_filter_cinema_in_city:I = 0x7f1209d8

.field public static final no_filter_cinema_in_city_sub:I = 0x7f1209d9

.field public static final no_map_cinema:I = 0x7f1209da

.field public static final no_more_cinema:I = 0x7f1209db

.field public static final no_net:I = 0x7f1209dc

.field public static final no_purchased_video_empty:I = 0x7f1209dd

.field public static final no_purchased_video_tip:I = 0x7f1209de

.field public static final no_remark:I = 0x7f1209df

.field public static final no_suitable_cinema_by_filter:I = 0x7f1209e0

.field public static final no_suitable_cinema_in_city:I = 0x7f1209e1

.field public static final nodata:I = 0x7f1209e2

.field public static final not_selected:I = 0x7f1209e3

.field public static final note_si_top:I = 0x7f1209e4

.field public static final notice_errorupdate:I = 0x7f1209e5

.field public static final notice_noupdate:I = 0x7f1209e6

.field public static final notice_undercapacity:I = 0x7f1209e7

.field public static final notice_update_app:I = 0x7f1209e8

.field public static final notice_update_checking:I = 0x7f1209e9

.field public static final notice_update_err_io:I = 0x7f1209ea

.field public static final notice_update_err_md5:I = 0x7f1209eb

.field public static final notice_update_err_network:I = 0x7f1209ec

.field public static final notice_update_err_nonetwork:I = 0x7f1209ed

.field public static final notice_update_err_url:I = 0x7f1209ee

.field public static final notice_update_service_err:I = 0x7f1209ef

.field public static final off:I = 0x7f1209f0

.field public static final off_single_head_tips:I = 0x7f1209f1

.field public static final off_single_head_tips_non:I = 0x7f1209f2

.field public static final ok:I = 0x7f1209f3

.field public static final on:I = 0x7f1209f4

.field public static final open_card:I = 0x7f1209f5

.field public static final open_card_again:I = 0x7f1209f6

.field public static final open_card_desc_1_1:I = 0x7f1209f7

.field public static final open_card_desc_1_2:I = 0x7f1209f8

.field public static final open_card_desc_1_3:I = 0x7f1209f9

.field public static final open_card_desc_2_1:I = 0x7f1209fa

.field public static final open_card_desc_2_2:I = 0x7f1209fb

.field public static final open_card_desc_2_3:I = 0x7f1209fc

.field public static final open_card_desc_3_1:I = 0x7f1209fd

.field public static final open_card_desc_3_2:I = 0x7f1209fe

.field public static final open_card_desc_4_1:I = 0x7f1209ff

.field public static final open_card_desc_4_2:I = 0x7f120a00

.field public static final open_card_desc_5:I = 0x7f120a01

.field public static final open_card_desc_6:I = 0x7f120a02

.field public static final open_card_guide:I = 0x7f120a03

.field public static final open_card_phone_tip:I = 0x7f120a04

.field public static final open_card_result_info_error:I = 0x7f120a05

.field public static final open_day_postfix:I = 0x7f120a06

.field public static final open_gesture:I = 0x7f120a07

.field public static final open_tip_cancel:I = 0x7f120a08

.field public static final open_tip_confirm:I = 0x7f120a09

.field public static final oppo_pantanal_auth_code_debug:I = 0x7f120a0a

.field public static final oppo_pantanal_auth_code_release:I = 0x7f120a0b

.field public static final order_complete:I = 0x7f120a0f

.field public static final order_confirm_vercode_activity_01:I = 0x7f120a11

.field public static final order_coupon_float_tip:I = 0x7f120a12

.field public static final order_coupon_gantan_tip:I = 0x7f120a13

.field public static final order_item_cancle_fail_toast:I = 0x7f120a21

.field public static final order_item_cancle_success_toast:I = 0x7f120a22

.field public static final order_list_empty_hint:I = 0x7f120a23

.field public static final order_previous_price:I = 0x7f120a2a

.field public static final order_recommend_title:I = 0x7f120a2b

.field public static final order_result_cash_back_unit:I = 0x7f120a2c

.field public static final order_sale_period_notice:I = 0x7f120a2d

.field public static final order_salegoods_list_empty_hint:I = 0x7f120a2e

.field public static final order_salegoodslist_empty_subhint:I = 0x7f120a2f

.field public static final order_ticket_left_time:I = 0x7f120a30

.field public static final order_ticket_v2_left_time:I = 0x7f120a31

.field public static final order_vip_exchange_base_score:I = 0x7f120a32

.field public static final order_vip_exchange_reduce_score:I = 0x7f120a33

.field public static final order_vip_exchange_scope:I = 0x7f120a34

.field public static final order_vip_exchange_score_discount:I = 0x7f120a35

.field public static final order_vip_exchange_user_integral:I = 0x7f120a36

.field public static final ordering_close_activity_switch_tips:I = 0x7f120a37

.field public static final ordering_detail_header_title:I = 0x7f120a38

.field public static final ordering_detail_header_title_coupon_package:I = 0x7f120a39

.field public static final ordering_detail_header_title_endorse:I = 0x7f120a3a

.field public static final ordering_detail_header_title_movie:I = 0x7f120a3b

.field public static final ordering_detail_header_title_product_sale:I = 0x7f120a3c

.field public static final ordering_detail_header_title_sale:I = 0x7f120a3d

.field public static final ordering_detail_title_movie_activity:I = 0x7f120a3e

.field public static final ordering_detail_title_movie_coupon:I = 0x7f120a3f

.field public static final ordering_detail_title_movie_not_activity:I = 0x7f120a40

.field public static final ordering_detail_title_movie_presalecode:I = 0x7f120a41

.field public static final ordering_detail_title_movie_sale_activity:I = 0x7f120a42

.field public static final ordering_detail_title_movie_sub_desc_mcard:I = 0x7f120a43

.field public static final ordering_dialog_btn:I = 0x7f120a44

.field public static final ordering_doing_tips:I = 0x7f120a45

.field public static final ordering_endorse_go:I = 0x7f120a46

.field public static final ordering_endorse_go_more:I = 0x7f120a47

.field public static final ordering_first_dialog_notips:I = 0x7f120a48

.field public static final ordering_first_dialog_notips_without_s:I = 0x7f120a49

.field public static final ordering_first_dialog_tips_refundable:I = 0x7f120a4a

.field public static final ordering_first_dialog_title:I = 0x7f120a4b

.field public static final ordering_go:I = 0x7f120a4c

.field public static final ordering_go_desc:I = 0x7f120a4d

.field public static final ordering_go_desc_title_tuipiao:I = 0x7f120a4e

.field public static final ordering_go_pay:I = 0x7f120a4f

.field public static final ordering_go_pay_more:I = 0x7f120a50

.field public static final ordering_go_refund:I = 0x7f120a51

.field public static final ordering_go_refund_alipay:I = 0x7f120a52

.field public static final ordering_has_sale:I = 0x7f120a53

.field public static final ordering_mcard_dialog_btn_clean_sale:I = 0x7f120a54

.field public static final ordering_mcard_dialog_btn_not_use_mcard:I = 0x7f120a55

.field public static final ordering_mcard_dialog_msg:I = 0x7f120a56

.field public static final ordering_mobile:I = 0x7f120a57

.field public static final ordering_payment_error_activity:I = 0x7f120a58

.field public static final ordering_payment_error_btn1:I = 0x7f120a59

.field public static final ordering_payment_error_btn2:I = 0x7f120a5a

.field public static final ordering_payment_error_mcard:I = 0x7f120a5b

.field public static final ordering_presalecode_go:I = 0x7f120a5c

.field public static final ordering_price_dialog_msg:I = 0x7f120a5d

.field public static final ordering_result_endorse_process_title:I = 0x7f120a5e

.field public static final ordering_result_endorse_success_title:I = 0x7f120a5f

.field public static final ordering_result_fail_dialog_btn_desc:I = 0x7f120a60

.field public static final ordering_result_fail_dialog_desc:I = 0x7f120a61

.field public static final ordering_result_film_name_and_ticket_num:I = 0x7f120a62

.field public static final ordering_result_page_title:I = 0x7f120a63

.field public static final ordering_result_success_drawing_btn:I = 0x7f120a64

.field public static final ordering_result_success_drawing_btn_endorse:I = 0x7f120a65

.field public static final ordering_result_success_drawing_desc:I = 0x7f120a66

.field public static final ordering_result_success_drawn_btn:I = 0x7f120a67

.field public static final ordering_result_success_drawn_title:I = 0x7f120a68

.field public static final ordering_result_success_my_schedule_btn:I = 0x7f120a69

.field public static final ordering_result_success_presalecode_title:I = 0x7f120a6a

.field public static final ordering_result_success_title:I = 0x7f120a6b

.field public static final ordering_selector_bank_not_use:I = 0x7f120a6c

.field public static final ordering_selector_block_available_coupon_count:I = 0x7f120a6d

.field public static final ordering_selector_block_bank_title:I = 0x7f120a6e

.field public static final ordering_selector_block_coupon_not_need_tips:I = 0x7f120a6f

.field public static final ordering_selector_block_coupon_reduce_title:I = 0x7f120a70

.field public static final ordering_selector_block_coupon_tips:I = 0x7f120a71

.field public static final ordering_selector_block_coupon_tips_sfee:I = 0x7f120a72

.field public static final ordering_selector_block_coupon_title:I = 0x7f120a73

.field public static final ordering_selector_block_endorse:I = 0x7f120a74

.field public static final ordering_selector_block_endorse_fee_title:I = 0x7f120a75

.field public static final ordering_selector_block_mcard_desc_cinema_error:I = 0x7f120a76

.field public static final ordering_selector_block_mcard_desc_expired:I = 0x7f120a77

.field public static final ordering_selector_block_mcard_desc_expired_can_recharge:I = 0x7f120a78

.field public static final ordering_selector_block_mcard_desc_no_balance:I = 0x7f120a79

.field public static final ordering_selector_block_mcard_desc_out_of_number:I = 0x7f120a7a

.field public static final ordering_selector_block_not_selected:I = 0x7f120a7b

.field public static final ordering_selector_block_not_used:I = 0x7f120a7c

.field public static final ordering_selector_block_notice_title_presalecode:I = 0x7f120a7d

.field public static final ordering_selector_block_notice_title_refund_endorse:I = 0x7f120a7e

.field public static final ordering_selector_block_notice_title_seat:I = 0x7f120a7f

.field public static final ordering_selector_block_ori_order_amount_title:I = 0x7f120a80

.field public static final ordering_selector_block_oriprice_title:I = 0x7f120a81

.field public static final ordering_selector_block_presalecode_desc:I = 0x7f120a82

.field public static final ordering_selector_block_presalecode_title:I = 0x7f120a83

.field public static final ordering_selector_block_presalecode_used:I = 0x7f120a84

.field public static final ordering_selector_block_real_tips:I = 0x7f120a85

.field public static final ordering_selector_block_real_tips_69:I = 0x7f120a86

.field public static final ordering_selector_block_reduce_title:I = 0x7f120a87

.field public static final ordering_selector_block_sale_endorse:I = 0x7f120a88

.field public static final ordering_selector_block_sale_endorse_desc:I = 0x7f120a89

.field public static final ordering_selector_block_sale_reduce_title:I = 0x7f120a8a

.field public static final ordering_selector_block_sale_select:I = 0x7f120a8b

.field public static final ordering_selector_block_sale_title:I = 0x7f120a8c

.field public static final ordering_selector_block_special_price_pop_tip:I = 0x7f120a8d

.field public static final ordering_selector_block_special_price_title:I = 0x7f120a8e

.field public static final ordering_selector_block_total_title:I = 0x7f120a8f

.field public static final ordering_selector_block_use_activity:I = 0x7f120a90

.field public static final ordering_selector_block_use_citypass:I = 0x7f120a91

.field public static final ordering_selector_block_use_mcard:I = 0x7f120a92

.field public static final ordering_selector_block_vip_coupon_title:I = 0x7f120a93

.field public static final ordering_selector_block_vip_reduce_title:I = 0x7f120a94

.field public static final ordering_selector_coupon_not_use:I = 0x7f120a95

.field public static final ordering_selector_expire_date:I = 0x7f120a96

.field public static final ordering_selector_header_desc_coupon:I = 0x7f120a97

.field public static final ordering_selector_header_desc_sale:I = 0x7f120a98

.field public static final ordering_selector_header_title_add_new_coupon:I = 0x7f120a99

.field public static final ordering_selector_header_title_bank:I = 0x7f120a9a

.field public static final ordering_selector_header_title_bank_new:I = 0x7f120a9b

.field public static final ordering_selector_header_title_coupon:I = 0x7f120a9c

.field public static final ordering_selector_header_title_coupon_new:I = 0x7f120a9d

.field public static final ordering_selector_header_title_mcard_recharge:I = 0x7f120a9e

.field public static final ordering_selector_header_title_presalecode:I = 0x7f120a9f

.field public static final ordering_selector_header_title_presalecode_new:I = 0x7f120aa0

.field public static final ordering_selector_header_title_sale:I = 0x7f120aa1

.field public static final ordering_selector_market_title:I = 0x7f120aa2

.field public static final ordering_selector_mcard_price:I = 0x7f120aa3

.field public static final ordering_selector_no_available_bank:I = 0x7f120aa4

.field public static final ordering_selector_no_available_coupon:I = 0x7f120aa5

.field public static final ordering_selector_presale_expire_date:I = 0x7f120aa6

.field public static final ordering_selector_presalecode_not_need_more:I = 0x7f120aa7

.field public static final ordering_selector_sale_not_refundable:I = 0x7f120aa8

.field public static final ordering_selector_sale_price:I = 0x7f120aa9

.field public static final ordering_selector_toast_no_mcard_balance:I = 0x7f120aaa

.field public static final ordering_timeout_dialog_tips:I = 0x7f120aab

.field public static final ordering_timer:I = 0x7f120aac

.field public static final ordering_timer_new:I = 0x7f120aad

.field public static final ordering_tips_138001:I = 0x7f120aae

.field public static final ordering_tips_138002:I = 0x7f120aaf

.field public static final ordering_tips_138003:I = 0x7f120ab0

.field public static final ordering_tips_138004:I = 0x7f120ab1

.field public static final ordering_tips_40002:I = 0x7f120ab2

.field public static final ordering_tips_55008_55015:I = 0x7f120ab3

.field public static final ordering_tips_55008_55015_btn1:I = 0x7f120ab4

.field public static final ordering_tips_55008_55015_btn2:I = 0x7f120ab5

.field public static final ordering_tips_55009:I = 0x7f120ab6

.field public static final ordering_tips_55011:I = 0x7f120ab7

.field public static final ordering_tips_55026:I = 0x7f120ab8

.field public static final ordering_tips_55026_btn1:I = 0x7f120ab9

.field public static final ordering_tips_55026_btn2:I = 0x7f120aba

.field public static final ordering_tips_55041_55044_btn1:I = 0x7f120abb

.field public static final ordering_tips_55041_55044_btn2:I = 0x7f120abc

.field public static final ordering_tips_55041_55044_t1:I = 0x7f120abd

.field public static final ordering_tips_55041_55044_t2:I = 0x7f120abe

.field public static final ordering_tips_55041_55044_t2_dm:I = 0x7f120abf

.field public static final ordering_tips_57001_btn1:I = 0x7f120ac0

.field public static final ordering_tips_57001_btn2:I = 0x7f120ac1

.field public static final ordering_tips_57001_t1:I = 0x7f120ac2

.field public static final ordering_tips_57001_t2:I = 0x7f120ac3

.field public static final ordering_tips_57001_t2_dm:I = 0x7f120ac4

.field public static final ordering_tips_70004_70009_900022:I = 0x7f120ac5

.field public static final ordering_tips_70005:I = 0x7f120ac6

.field public static final ordering_tips_70008:I = 0x7f120ac7

.field public static final ordering_tips_900003:I = 0x7f120ac8

.field public static final ordering_tips_address:I = 0x7f120ac9

.field public static final ordering_tips_btn_close:I = 0x7f120aca

.field public static final ordering_tips_btn_disable_mcard_flag:I = 0x7f120acb

.field public static final ordering_tips_unpaysize_more:I = 0x7f120acc

.field public static final ordering_tips_unpaysize_more_btn1:I = 0x7f120acd

.field public static final ordering_tips_unpaysize_more_btn2:I = 0x7f120ace

.field public static final ordering_tips_unpaysize_one:I = 0x7f120acf

.field public static final ordering_tips_unpaysize_one_btn1:I = 0x7f120ad0

.field public static final ordering_tips_unpaysize_one_btn1_result_fail:I = 0x7f120ad1

.field public static final ordering_tips_unpaysize_one_btn1_result_success:I = 0x7f120ad2

.field public static final ordering_tips_unpaysize_one_btn2:I = 0x7f120ad3

.field public static final ordering_title:I = 0x7f120ad4

.field public static final oscar_article_film_express_more:I = 0x7f120ad5

.field public static final oscar_done_list_empty:I = 0x7f120ad6

.field public static final oscar_done_list_empty_other:I = 0x7f120ad7

.field public static final oscar_done_list_empty_subtitle:I = 0x7f120ad8

.field public static final oscar_try_refresh_page:I = 0x7f120ada

.field public static final oscar_uncomment_num:I = 0x7f120adb

.field public static final oscar_wanted_list_empty:I = 0x7f120adc

.field public static final oscar_wanted_list_empty_other:I = 0x7f120add

.field public static final oscar_wanted_performance_empty:I = 0x7f120ade

.field public static final oscar_wanted_performance_list_empty_other:I = 0x7f120adf

.field public static final oscar_watched_num:I = 0x7f120ae0

.field public static final page_empty_text:I = 0x7f120ae2

.field public static final parse_template_error:I = 0x7f120ae3

.field public static final passport_appid:I = 0x7f120ae4

.field public static final passport_appscret:I = 0x7f120ae5

.field public static final passport_ott_op_icon:I = 0x7f120ae6

.field public static final passport_ott_re_gen_qr_code:I = 0x7f120ae7

.field public static final passport_ott_refresh_qr_code:I = 0x7f120ae8

.field public static final passport_tips_hint:I = 0x7f120ae9

.field public static final passport_tips_title:I = 0x7f120aea

.field public static final password_toggle_content_description:I = 0x7f120aeb

.field public static final path_password_eye:I = 0x7f120aec

.field public static final path_password_eye_mask_strike_through:I = 0x7f120aed

.field public static final path_password_eye_mask_visible:I = 0x7f120aee

.field public static final path_password_strike_through:I = 0x7f120aef

.field public static final pay_dialog_cancel:I = 0x7f120af0

.field public static final pay_dialog_content:I = 0x7f120af1

.field public static final pay_dialog_ensure:I = 0x7f120af2

.field public static final pay_dialog_title:I = 0x7f120af3

.field public static final pay_wx_not_support_toast:I = 0x7f120af4

.field public static final people_picture:I = 0x7f120af6

.field public static final permission_request_choose_pic_qrcode:I = 0x7f120af7

.field public static final permission_request_des_calender_add_remind:I = 0x7f120af8

.field public static final permission_request_des_calender_add_remind_festal:I = 0x7f120af9

.field public static final permission_request_des_calender_cancel_remind_festal:I = 0x7f120afa

.field public static final permission_request_des_camera_default:I = 0x7f120afb

.field public static final permission_request_des_camera_scan:I = 0x7f120afc

.field public static final permission_request_des_camera_user_portal:I = 0x7f120afd

.field public static final permission_request_des_contacts_choose:I = 0x7f120afe

.field public static final permission_request_des_location:I = 0x7f120aff

.field public static final permission_request_des_location_in_search:I = 0x7f120b00

.field public static final permission_request_des_storage_savepic:I = 0x7f120b01

.field public static final permission_request_des_storage_selectedpic:I = 0x7f120b02

.field public static final permission_request_des_storage_selectedpic_userportal:I = 0x7f120b03

.field public static final permission_request_title_calender:I = 0x7f120b04

.field public static final permission_request_title_camera:I = 0x7f120b05

.field public static final permission_request_title_contacts:I = 0x7f120b06

.field public static final permission_request_title_location:I = 0x7f120b07

.field public static final permission_request_title_storage:I = 0x7f120b08

.field public static final phone_bind_desc:I = 0x7f120b09

.field public static final phone_coupon_get_title:I = 0x7f120b0a

.field public static final phone_desc:I = 0x7f120b0b

.field public static final phone_number_input_hint:I = 0x7f120b0c

.field public static final phone_verify_input_hint:I = 0x7f120b0d

.field public static final pic_index_num:I = 0x7f120b0e

.field public static final pick_photo:I = 0x7f120b0f

.field public static final picture_number:I = 0x7f120b10

.field public static final pictureviewpage_release_goto_commentdetail:I = 0x7f120b11

.field public static final pictureviewpage_scroll_to_commentdetail:I = 0x7f120b12

.field public static final poplayer_version:I = 0x7f120b1b

.field public static final presale_bind_errer_common:I = 0x7f120b1c

.field public static final presale_bind_errer_large_number:I = 0x7f120b1d

.field public static final presale_bind_errer_not_exist:I = 0x7f120b1e

.field public static final presale_bind_title_approved:I = 0x7f120b1f

.field public static final presale_bind_title_double:I = 0x7f120b20

.field public static final presale_bind_title_expire:I = 0x7f120b21

.field public static final presale_bind_title_invalid:I = 0x7f120b22

.field public static final presale_bind_title_locked:I = 0x7f120b23

.field public static final presale_canceled:I = 0x7f120b24

.field public static final presale_detail_delete_confirm:I = 0x7f120b25

.field public static final presale_detail_delete_fail:I = 0x7f120b26

.field public static final presale_detail_delete_sucess:I = 0x7f120b27

.field public static final presale_detail_unbind_confirm:I = 0x7f120b28

.field public static final presale_detail_unbind_fail:I = 0x7f120b29

.field public static final presale_detail_unbind_sucess:I = 0x7f120b2a

.field public static final presale_exchange_des:I = 0x7f120b2b

.field public static final presale_exchange_help_des:I = 0x7f120b2c

.field public static final presale_exchange_help_title:I = 0x7f120b2d

.field public static final presale_exchange_hint:I = 0x7f120b2e

.field public static final presale_exchange_title:I = 0x7f120b2f

.field public static final presale_has_no_schedule:I = 0x7f120b30

.field public static final presale_has_no_schedule_for_show:I = 0x7f120b31

.field public static final presale_hint_msg:I = 0x7f120b32

.field public static final presale_hint_title:I = 0x7f120b33

.field public static final presale_locking:I = 0x7f120b34

.field public static final presale_noopen:I = 0x7f120b35

.field public static final presale_noschedule:I = 0x7f120b36

.field public static final presale_overdue:I = 0x7f120b37

.field public static final presale_success:I = 0x7f120b38

.field public static final presale_used:I = 0x7f120b39

.field public static final preview:I = 0x7f120b3a

.field public static final previous:I = 0x7f120b3b

.field public static final privileged_audience_already_set_text_first:I = 0x7f120b3e

.field public static final privileged_audience_already_set_text_second:I = 0x7f120b3f

.field public static final privileged_audience_change_set_button:I = 0x7f120b40

.field public static final privileged_audience_not_set_button:I = 0x7f120b41

.field public static final privileged_audience_not_set_text_first:I = 0x7f120b42

.field public static final privileged_audience_not_set_text_second:I = 0x7f120b43

.field public static final product_buyone_giveone:I = 0x7f120b44

.field public static final product_coupon_check_invalid_coupon:I = 0x7f120b45

.field public static final product_coupon_check_invalid_privilege:I = 0x7f120b46

.field public static final product_coupon_first_subtitle:I = 0x7f120b47

.field public static final product_coupon_first_title:I = 0x7f120b48

.field public static final product_coupon_first_title2:I = 0x7f120b49

.field public static final product_coupon_get_coupon:I = 0x7f120b4a

.field public static final product_detail_delete_confirm:I = 0x7f120b4b

.field public static final product_detail_delete_confirm2:I = 0x7f120b4c

.field public static final product_detail_delete_confirm3:I = 0x7f120b4d

.field public static final product_detail_delete_confirm4:I = 0x7f120b4e

.field public static final product_detail_delete_confirm_subtitle:I = 0x7f120b4f

.field public static final product_detail_endorse_dialog_title:I = 0x7f120b50

.field public static final product_detail_gp_count:I = 0x7f120b51

.field public static final product_detail_gp_pay_success:I = 0x7f120b52

.field public static final product_detail_gp_seller:I = 0x7f120b53

.field public static final product_detail_gp_title:I = 0x7f120b54

.field public static final product_detail_introduction:I = 0x7f120b55

.field public static final product_detail_no_endorse:I = 0x7f120b56

.field public static final product_detail_no_refund:I = 0x7f120b57

.field public static final product_detail_no_refund_or_no_endorse:I = 0x7f120b58

.field public static final product_detail_phone:I = 0x7f120b59

.field public static final product_detail_play_timer_text:I = 0x7f120b5a

.field public static final product_detail_ps_count:I = 0x7f120b5b

.field public static final product_detail_ps_locking:I = 0x7f120b5c

.field public static final product_detail_ps_pay_success:I = 0x7f120b5d

.field public static final product_detail_ps_title:I = 0x7f120b5e

.field public static final product_detail_refund_disable_alert:I = 0x7f120b5f

.field public static final product_detail_refund_failed_text:I = 0x7f120b60

.field public static final product_detail_refund_toast:I = 0x7f120b61

.field public static final product_detail_refunding_text:I = 0x7f120b62

.field public static final product_detail_refunding_toast:I = 0x7f120b63

.field public static final product_detail_reward_detail:I = 0x7f120b64

.field public static final product_detail_sale_goods_unpay_text:I = 0x7f120b65

.field public static final product_detail_sg_title:I = 0x7f120b66

.field public static final product_detail_suit_cinemas:I = 0x7f120b67

.field public static final product_detail_suit_films:I = 0x7f120b68

.field public static final product_detail_suit_mcard:I = 0x7f120b69

.field public static final product_detail_tk_add_cinema_comment:I = 0x7f120b6a

.field public static final product_detail_tk_add_comment:I = 0x7f120b6b

.field public static final product_detail_tk_cinema_comment:I = 0x7f120b6c

.field public static final product_detail_tk_comment_detail:I = 0x7f120b6d

.field public static final product_detail_tk_endorse_unpay:I = 0x7f120b6e

.field public static final product_detail_tk_endorsed:I = 0x7f120b6f

.field public static final product_detail_tk_endorsing:I = 0x7f120b70

.field public static final product_detail_tk_pay_success:I = 0x7f120b71

.field public static final product_detail_tk_pay_success_endorse_toast:I = 0x7f120b72

.field public static final product_detail_tk_pay_success_toast:I = 0x7f120b73

.field public static final product_detail_tk_play_end:I = 0x7f120b74

.field public static final product_detail_tk_playing:I = 0x7f120b75

.field public static final product_detail_tk_refund_success:I = 0x7f120b76

.field public static final product_detail_tk_refunded:I = 0x7f120b77

.field public static final product_detail_tk_request_endorsing:I = 0x7f120b78

.field public static final product_detail_tk_seller:I = 0x7f120b79

.field public static final product_detail_tk_title:I = 0x7f120b7a

.field public static final product_detail_tk_two_day_timer:I = 0x7f120b7b

.field public static final product_detail_tk_unpay:I = 0x7f120b7c

.field public static final product_detail_tk_unplay:I = 0x7f120b7d

.field public static final product_detail_unpay_text:I = 0x7f120b7e

.field public static final product_exchange_coupon:I = 0x7f120b7f

.field public static final product_message_unknow_dialog_cancel:I = 0x7f120b81

.field public static final product_message_unknow_dialog_ok:I = 0x7f120b82

.field public static final product_message_unknow_dialog_title:I = 0x7f120b83

.field public static final product_sale_goods_number:I = 0x7f120b84

.field public static final product_salegoods_coupon_belong2you_des:I = 0x7f120b85

.field public static final product_select_seat:I = 0x7f120b86

.field public static final product_ticket_festival:I = 0x7f120b87

.field public static final production:I = 0x7f120b88

.field public static final project_detail_perform_goodregesiter_prompt:I = 0x7f120b8a

.field public static final project_detail_perform_intput_phone_tip:I = 0x7f120b8b

.field public static final project_detail_perform_price:I = 0x7f120b8c

.field public static final project_detail_perform_seat_img:I = 0x7f120b8d

.field public static final project_detail_perform_select_price:I = 0x7f120b8e

.field public static final project_detail_perform_select_ticket:I = 0x7f120b8f

.field public static final project_detail_perform_submit:I = 0x7f120b90

.field public static final project_detail_perform_time:I = 0x7f120b91

.field public static final project_detail_perform_title:I = 0x7f120b92

.field public static final project_perform_cannot_chooseseat:I = 0x7f120b98

.field public static final project_perform_choose_date:I = 0x7f120b99

.field public static final project_perform_choose_price:I = 0x7f120b9a

.field public static final project_perform_choose_time:I = 0x7f120b9b

.field public static final project_perform_data_isnull:I = 0x7f120b9c

.field public static final project_perform_no_seat:I = 0x7f120b9d

.field public static final promotion_ticket:I = 0x7f120ba5

.field public static final pull_to_refresh_from_bottom_pull_label:I = 0x7f120baa

.field public static final pull_to_refresh_from_bottom_refreshing_label:I = 0x7f120bab

.field public static final pull_to_refresh_from_bottom_release_label:I = 0x7f120bac

.field public static final pull_to_refresh_pull_label:I = 0x7f120bad

.field public static final pull_to_refresh_refreshing_label:I = 0x7f120bae

.field public static final pull_to_refresh_release_label:I = 0x7f120baf

.field public static final pull_to_refresh_text:I = 0x7f120bb0

.field public static final purchased_video_want_title:I = 0x7f120bb1

.field public static final push_cat_body:I = 0x7f120bb2

.field public static final push_cat_head:I = 0x7f120bb3

.field public static final qq_not_install:I = 0x7f120bb4

.field public static final qrcode_check_info:I = 0x7f120bb5

.field public static final query_current_phone_number:I = 0x7f120bb6

.field public static final range_end:I = 0x7f120bb7

.field public static final range_start:I = 0x7f120bb8

.field public static final rank_it:I = 0x7f120bb9

.field public static final ranking_box_title:I = 0x7f120bba

.field public static final ranking_remark_title:I = 0x7f120bbb

.field public static final ranking_want_title:I = 0x7f120bbc

.field public static final real_price:I = 0x7f120bbd

.field public static final realname_error_reason:I = 0x7f120bc1

.field public static final realname_error_reason_detail:I = 0x7f120bc2

.field public static final recharge_card:I = 0x7f120bc5

.field public static final recharge_card_guide:I = 0x7f120bc6

.field public static final recharge_card_result_info_error:I = 0x7f120bc7

.field public static final recommend_num:I = 0x7f120bc8

.field public static final recommend_seat:I = 0x7f120bc9

.field public static final recommend_seat_btn:I = 0x7f120bca

.field public static final refresh:I = 0x7f120bcb

.field public static final refund_advice_count_left:I = 0x7f120bcd

.field public static final refund_advice_number_over_tip:I = 0x7f120bce

.field public static final refund_amount:I = 0x7f120bcf

.field public static final refund_amount_zero:I = 0x7f120bd0

.field public static final refund_apply_go_refund_result:I = 0x7f120bd1

.field public static final refund_apply_tips:I = 0x7f120bd2

.field public static final refund_apply_title:I = 0x7f120bd3

.field public static final refund_change_notice:I = 0x7f120bd4

.field public static final refund_change_title:I = 0x7f120bd5

.field public static final refund_commit_request:I = 0x7f120bd6

.field public static final refund_endorse_alert_not_checked:I = 0x7f120bd7

.field public static final refund_endorse_detail:I = 0x7f120bd8

.field public static final refund_endorse_tips:I = 0x7f120bd9

.field public static final refund_endorse_title:I = 0x7f120bda

.field public static final refund_error_zero:I = 0x7f120bdb

.field public static final refund_has_selected:I = 0x7f120bdc

.field public static final refund_offer_return_description:I = 0x7f120bdd

.field public static final refund_offer_return_description_tip:I = 0x7f120bde

.field public static final refund_please_select_one_reason:I = 0x7f120bdf

.field public static final refund_please_select_reason:I = 0x7f120be0

.field public static final refund_reason_none:I = 0x7f120be1

.field public static final refund_reason_research:I = 0x7f120be2

.field public static final refund_reasons:I = 0x7f120be3

.field public static final refund_request:I = 0x7f120be4

.field public static final refund_result_go_refund_detail:I = 0x7f120be5

.field public static final refund_result_text_failed:I = 0x7f120be6

.field public static final refund_result_text_success:I = 0x7f120be7

.field public static final refund_result_text_success2:I = 0x7f120be8

.field public static final refund_result_title:I = 0x7f120be9

.field public static final refund_return_rule:I = 0x7f120bea

.field public static final refund_return_rule_tip:I = 0x7f120beb

.field public static final refund_rules:I = 0x7f120bec

.field public static final refund_this_time_reason:I = 0x7f120bed

.field public static final refund_this_time_reason_must_select:I = 0x7f120bee

.field public static final refund_this_time_reason_tip:I = 0x7f120bef

.field public static final refund_user_right_result_text:I = 0x7f120bf0

.field public static final refund_user_right_result_title:I = 0x7f120bf1

.field public static final refund_user_right_used:I = 0x7f120bf2

.field public static final refund_user_right_will_use:I = 0x7f120bf3

.field public static final refunding:I = 0x7f120bf4

.field public static final region_list_load_fail:I = 0x7f120bf5

.field public static final release_to_refresh_text:I = 0x7f120bfc

.field public static final reload:I = 0x7f120bfd

.field public static final remark_title:I = 0x7f120bfe

.field public static final remark_title_lite:I = 0x7f120bff

.field public static final report_toast_memotolong:I = 0x7f120c00

.field public static final report_toast_noselect:I = 0x7f120c01

.field public static final reset:I = 0x7f120c02

.field public static final role_intro:I = 0x7f120c06

.field public static final rp_ctid_app_data_error_title:I = 0x7f120c07

.field public static final rp_ctid_app_sys_error_title:I = 0x7f120c08

.field public static final rp_ctid_no_binding_title:I = 0x7f120c09

.field public static final rp_ctid_no_cert_title:I = 0x7f120c0a

.field public static final rp_ctid_not_install_btn:I = 0x7f120c0b

.field public static final rp_ctid_not_install_msg:I = 0x7f120c0c

.field public static final rp_ctid_not_install_title:I = 0x7f120c0d

.field public static final rp_ctid_not_login_title:I = 0x7f120c0e

.field public static final rp_ctid_sys_error_title:I = 0x7f120c0f

.field public static final rp_ctid_unregister_title:I = 0x7f120c10

.field public static final rp_ctid_verify_retry:I = 0x7f120c11

.field public static final rp_guide_title:I = 0x7f120c12

.field public static final rp_privacy_title:I = 0x7f120c13

.field public static final rp_thanks_for_your_use:I = 0x7f120c14

.field public static final rpsdk_activating:I = 0x7f120c15

.field public static final rpsdk_activating_hint:I = 0x7f120c16

.field public static final safe_watch_text:I = 0x7f120c17

.field public static final sale_goods:I = 0x7f120c18

.field public static final sale_goods_amount_express:I = 0x7f120c19

.field public static final sale_goods_combo_type_title:I = 0x7f120c1a

.field public static final sale_goods_count:I = 0x7f120c1b

.field public static final sale_goods_count2:I = 0x7f120c1c

.field public static final sale_goods_detail_pay_success_alert:I = 0x7f120c1d

.field public static final sale_goods_exchange_time_formater:I = 0x7f120c1e

.field public static final sale_goods_exchange_time_formater_scene:I = 0x7f120c1f

.field public static final sale_goods_exchange_time_formater_v1:I = 0x7f120c20

.field public static final sale_goods_exchange_time_prefix:I = 0x7f120c21

.field public static final sale_goods_num:I = 0x7f120c22

.field public static final sale_goods_stub:I = 0x7f120c23

.field public static final sale_goods_tip2:I = 0x7f120c24

.field public static final sale_goods_tip3:I = 0x7f120c25

.field public static final sale_goods_tip4:I = 0x7f120c26

.field public static final sale_goods_tips_new2:I = 0x7f120c27

.field public static final sale_goods_tips_new3:I = 0x7f120c28

.field public static final sale_list_activity_tip:I = 0x7f120c29

.field public static final sale_list_tip:I = 0x7f120c2a

.field public static final sale_order_min_limit_prompt:I = 0x7f120c2b

.field public static final sale_price:I = 0x7f120c2c

.field public static final salegoods_detail_delete_confirm:I = 0x7f120c2d

.field public static final salegoods_detail_delete_confirm2:I = 0x7f120c2e

.field public static final salegoods_detail_delete_confirm3:I = 0x7f120c2f

.field public static final salegoods_detail_delete_confirm4:I = 0x7f120c30

.field public static final salegoods_detail_delete_confirm_subtitle:I = 0x7f120c31

.field public static final sales_out:I = 0x7f120c32

.field public static final save_image_fail:I = 0x7f120c33

.field public static final save_image_success:I = 0x7f120c34

.field public static final schdule_list_activity_coupon:I = 0x7f120c35

.field public static final schdule_list_activity_mcard:I = 0x7f120c36

.field public static final schedule_error_40003:I = 0x7f120c37

.field public static final schedule_error_40004:I = 0x7f120c38

.field public static final schedule_error_52000:I = 0x7f120c39

.field public static final schedule_error_52002:I = 0x7f120c3a

.field public static final schedule_error_53000:I = 0x7f120c3b

.field public static final schedule_error_53001:I = 0x7f120c3c

.field public static final schedule_stop_selling_tip:I = 0x7f120c3d

.field public static final scrolling_behavior:I = 0x7f120c3e

.field public static final search_btn_text:I = 0x7f120c3f

.field public static final search_fans:I = 0x7f120c40

.field public static final search_goto_home:I = 0x7f120c41

.field public static final search_hint:I = 0x7f120c42

.field public static final search_history_title:I = 0x7f120c43

.field public static final search_hot_title:I = 0x7f120c44

.field public static final search_menu_title:I = 0x7f120c45

.field public static final search_more_artiste:I = 0x7f120c46

.field public static final search_more_cinema:I = 0x7f120c47

.field public static final search_more_content:I = 0x7f120c48

.field public static final search_more_show:I = 0x7f120c49

.field public static final search_result_empty:I = 0x7f120c4a

.field public static final search_sale_performance:I = 0x7f120c4b

.field public static final search_sale_performance_unit:I = 0x7f120c4c

.field public static final search_title_all_artiste:I = 0x7f120c4d

.field public static final search_title_all_cinema:I = 0x7f120c4e

.field public static final search_title_all_default:I = 0x7f120c4f

.field public static final search_title_all_film:I = 0x7f120c50

.field public static final search_title_all_performance:I = 0x7f120c51

.field public static final seat_best_area:I = 0x7f120c52

.field public static final seat_buy_confirm:I = 0x7f120c53

.field public static final seat_can_select:I = 0x7f120c54

.field public static final seat_indicator_price_ext:I = 0x7f120c55

.field public static final seat_lock_failed:I = 0x7f120c56

.field public static final seat_selected:I = 0x7f120c58

.field public static final seat_sold:I = 0x7f120c59

.field public static final seat_tip_endorse:I = 0x7f120c5c

.field public static final seat_total_price:I = 0x7f120c5d

.field public static final see:I = 0x7f120c62

.field public static final see_discuss_zone:I = 0x7f120c63

.field public static final select:I = 0x7f120c64

.field public static final select_cinema:I = 0x7f120c65

.field public static final select_page_tips_num:I = 0x7f120c66

.field public static final selected:I = 0x7f120c67

.field public static final send_again_left_time:I = 0x7f120c68

.field public static final send_discuss_text:I = 0x7f120c69

.field public static final send_phone_verify_code:I = 0x7f120c6a

.field public static final server_error:I = 0x7f120c6b

.field public static final sg_app_store_not_exist:I = 0x7f120c70

.field public static final sg_app_store_select:I = 0x7f120c71

.field public static final sg_dialog_ok:I = 0x7f120c72

.field public static final sg_permission_failed:I = 0x7f120c73

.field public static final share:I = 0x7f120c74

.field public static final share_capture_not_support:I = 0x7f120c75

.field public static final share_delete_comment_des:I = 0x7f120c76

.field public static final share_delete_des:I = 0x7f120c77

.field public static final share_evaluate_rank_prefix:I = 0x7f120c78

.field public static final share_evaluate_rank_sufix:I = 0x7f120c79

.field public static final share_fail:I = 0x7f120c7a

.field public static final share_name_alipay:I = 0x7f120c7b

.field public static final share_schedule_tips:I = 0x7f120c7c

.field public static final share_seat_tips:I = 0x7f120c7d

.field public static final share_sina_fragment_01:I = 0x7f120c7e

.field public static final share_sina_fragment_02:I = 0x7f120c7f

.field public static final share_sina_fragment_03:I = 0x7f120c80

.field public static final share_sina_fragment_04:I = 0x7f120c81

.field public static final share_text:I = 0x7f120c82

.field public static final showTime:I = 0x7f120c83

.field public static final show_remark_title:I = 0x7f120c85

.field public static final single_layer:I = 0x7f120c87

.field public static final sku_buy:I = 0x7f120c88

.field public static final sku_goodregesiter_prompt:I = 0x7f120c89

.field public static final sku_goodregister_holding_ticket:I = 0x7f120c8a

.field public static final sku_kaishoudengji:I = 0x7f120c8b

.field public static final sku_schedule:I = 0x7f120c8c

.field public static final small_food_tickets:I = 0x7f120c8d

.field public static final some_one_join_discuss:I = 0x7f120c8e

.field public static final soon_guide_film_count:I = 0x7f120c8f

.field public static final spb_default_speed:I = 0x7f120c90

.field public static final special_price_time:I = 0x7f120c91

.field public static final spring_open_card_info_error:I = 0x7f120c97

.field public static final srl_component_falsify:I = 0x7f120c98

.field public static final srl_content_empty:I = 0x7f120c99

.field public static final srl_footer_failed:I = 0x7f120c9a

.field public static final srl_footer_finish:I = 0x7f120c9b

.field public static final srl_footer_loading:I = 0x7f120c9c

.field public static final srl_footer_nothing:I = 0x7f120c9d

.field public static final srl_footer_pulling:I = 0x7f120c9e

.field public static final srl_footer_refreshing:I = 0x7f120c9f

.field public static final srl_footer_release:I = 0x7f120ca0

.field public static final srl_header_failed:I = 0x7f120ca1

.field public static final srl_header_finish:I = 0x7f120ca2

.field public static final srl_header_loading:I = 0x7f120ca3

.field public static final srl_header_pulling:I = 0x7f120ca4

.field public static final srl_header_refreshing:I = 0x7f120ca5

.field public static final srl_header_release:I = 0x7f120ca6

.field public static final srl_header_secondary:I = 0x7f120ca7

.field public static final srl_header_update:I = 0x7f120ca8

.field public static final statemanager_network_error:I = 0x7f120ca9

.field public static final statemanager_network_error_404:I = 0x7f120caa

.field public static final statemanager_network_error_404_subtitle:I = 0x7f120cab

.field public static final statemanager_refresh:I = 0x7f120cac

.field public static final statemanager_unknown_error:I = 0x7f120cad

.field public static final status_bar_notification_info_overflow:I = 0x7f120cae

.field public static final subscription_child_item_01:I = 0x7f120cbf

.field public static final success:I = 0x7f120cc0

.field public static final suitable_film_list_empty:I = 0x7f120cc1

.field public static final surprise_red_coupon_exchange_left_time:I = 0x7f120cc2

.field public static final switch_gesture:I = 0x7f120cc3

.field public static final switch_gesture_hint:I = 0x7f120cc4

.field public static final switch_schedule:I = 0x7f120cc6

.field public static final sys_notify_setting_guide_tip_normal:I = 0x7f120cc9

.field public static final sys_notify_setting_guide_tip_reply:I = 0x7f120cca

.field public static final sys_notify_setting_guide_tip_wanted:I = 0x7f120ccb

.field public static final system_default_channel:I = 0x7f120ccc

.field public static final tab:I = 0x7f120ccd

.field public static final tag_film_detail_page_recyclerview:I = 0x7f120cce

.field public static final tag_film_detail_top_block:I = 0x7f120ccf

.field public static final tag_film_detail_top_video:I = 0x7f120cd0

.field public static final taiwan_id_tips_hint:I = 0x7f120cd1

.field public static final taiwan_id_tips_title:I = 0x7f120cd2

.field public static final template_download_fail_line1:I = 0x7f120cd3

.field public static final template_download_fail_line2:I = 0x7f120cd4

.field public static final template_download_mobile_tips:I = 0x7f120cd5

.field public static final template_percent:I = 0x7f120cd6

.field public static final text_main:I = 0x7f120cd9

.field public static final theme_rank_list_title:I = 0x7f120ce2

.field public static final theme_title:I = 0x7f120ce3

.field public static final third_party_comment:I = 0x7f120ce5

.field public static final ticket_amount:I = 0x7f120ce6

.field public static final ticket_count:I = 0x7f120ce7

.field public static final ticket_count2:I = 0x7f120ce8

.field public static final ticket_count3:I = 0x7f120ce9

.field public static final ticket_detail_alipay:I = 0x7f120cea

.field public static final ticket_detail_pay_success_alert:I = 0x7f120ceb

.field public static final ticket_detail_rights_tip:I = 0x7f120cec

.field public static final ticket_detail_rights_warming:I = 0x7f120ced

.field public static final ticket_nft_share_des:I = 0x7f120cee

.field public static final ticket_nft_share_des_sub:I = 0x7f120cef

.field public static final ticket_nft_user_title:I = 0x7f120cf0

.field public static final ticket_nft_yc_code_title:I = 0x7f120cf1

.field public static final ticket_remind_left_text:I = 0x7f120cf2

.field public static final ticket_remind_right_text:I = 0x7f120cf3

.field public static final ticket_see_refund_amount:I = 0x7f120cf4

.field public static final ticket_see_refund_statu_amount:I = 0x7f120cf5

.field public static final ticket_setting_machine_tip:I = 0x7f120cf6

.field public static final ticket_setting_ticket_tip:I = 0x7f120cf7

.field public static final ticket_share_count:I = 0x7f120cf8

.field public static final ticket_timer_text:I = 0x7f120cf9

.field public static final ticket_timer_youku:I = 0x7f120cfa

.field public static final ticket_tip_desc:I = 0x7f120cfb

.field public static final tickets_confirm:I = 0x7f120cfe

.field public static final ticklet_share_title:I = 0x7f120d43

.field public static final time_line_top:I = 0x7f120d7c

.field public static final title_cinema:I = 0x7f120d7e

.field public static final title_film:I = 0x7f120d81

.field public static final title_film_btn_nowplaying:I = 0x7f120d82

.field public static final title_film_btn_nowplaying_new:I = 0x7f120d83

.field public static final title_film_btn_online_video:I = 0x7f120d84

.field public static final title_film_btn_ranking:I = 0x7f120d85

.field public static final title_film_btn_upcoming:I = 0x7f120d86

.field public static final title_film_btn_video:I = 0x7f120d87

.field public static final title_rp_h5:I = 0x7f120d88

.field public static final title_rp_preview_photo:I = 0x7f120d89

.field public static final title_selectable_film_list:I = 0x7f120d8a

.field public static final title_suitable_cinema_list:I = 0x7f120d8b

.field public static final title_suitable_film_list:I = 0x7f120d8c

.field public static final toast_opening_third_h5:I = 0x7f120d8d

.field public static final today_boxoffice_ranking:I = 0x7f120d8e

.field public static final tpp_appstore_comment:I = 0x7f120d8f

.field public static final tpp_appstore_feedback:I = 0x7f120d90

.field public static final tpp_cancel:I = 0x7f120d91

.field public static final tpp_confirm:I = 0x7f120d93

.field public static final trade_project_push:I = 0x7f120da4

.field public static final trailers_number:I = 0x7f120db0

.field public static final ttid:I = 0x7f120db1

.field public static final uckey_debug:I = 0x7f120db2

.field public static final uckey_release:I = 0x7f120db3

.field public static final uik_load_more:I = 0x7f120db4

.field public static final uik_load_more_finished:I = 0x7f120db5

.field public static final uik_loading:I = 0x7f120db6

.field public static final uik_pull_to_refresh:I = 0x7f120db7

.field public static final uik_refresh_arrow:I = 0x7f120db8

.field public static final uik_refresh_finished:I = 0x7f120db9

.field public static final uik_refreshing:I = 0x7f120dba

.field public static final uik_release_to_load:I = 0x7f120dbb

.field public static final uik_release_to_refresh:I = 0x7f120dbc

.field public static final uik_save_image:I = 0x7f120dbd

.field public static final uik_save_image_fail:I = 0x7f120dbe

.field public static final uik_save_image_fail_full:I = 0x7f120dbf

.field public static final uik_save_image_fail_get:I = 0x7f120dc0

.field public static final uik_save_image_success:I = 0x7f120dc1

.field public static final uik_see_origin:I = 0x7f120dc2

.field public static final unit_name_city:I = 0x7f120dc3

.field public static final unpaid_orders:I = 0x7f120dc4

.field public static final updata_lephone_text:I = 0x7f120dc5

.field public static final updata_shakira_text:I = 0x7f120dc6

.field public static final update_btn_cancel:I = 0x7f120dc7

.field public static final update_btn_comfirm:I = 0x7f120dc8

.field public static final update_no_network:I = 0x7f120dc9

.field public static final update_no_sdcard:I = 0x7f120dca

.field public static final update_no_sdcard_space:I = 0x7f120dcb

.field public static final update_notification_downloading:I = 0x7f120dcc

.field public static final update_notification_error:I = 0x7f120dcd

.field public static final update_notification_fail:I = 0x7f120dce

.field public static final update_notification_finish:I = 0x7f120dcf

.field public static final update_notification_start:I = 0x7f120dd0

.field public static final update_title:I = 0x7f120dd1

.field public static final user_dna_part1:I = 0x7f120dd2

.field public static final user_no_remark:I = 0x7f120dd3

.field public static final user_phone_notip:I = 0x7f120dd4

.field public static final valid_period:I = 0x7f120dd5

.field public static final venue_release_goto_commentdetail:I = 0x7f120dd6

.field public static final venue_scroll_to_commentdetail:I = 0x7f120dd7

.field public static final vertical_point_text:I = 0x7f120dd9

.field public static final video_blank:I = 0x7f120ddb

.field public static final video_num:I = 0x7f120ddc

.field public static final view_all_instructions_text:I = 0x7f120ddd

.field public static final vip_coupon_hm_timer_text:I = 0x7f120dde

.field public static final vip_coupon_ms_timer_text:I = 0x7f120ddf

.field public static final vote_num_des:I = 0x7f120de0

.field public static final want_count_desc:I = 0x7f120de3

.field public static final want_delete_alert_comment:I = 0x7f120de4

.field public static final want_delete_alert_no_comment:I = 0x7f120de5

.field public static final want_dialog_btn:I = 0x7f120de6

.field public static final want_dialog_btn_go_detail:I = 0x7f120de7

.field public static final want_film_delete:I = 0x7f120de8

.field public static final want_see_tips_open_notification:I = 0x7f120de9

.field public static final want_title:I = 0x7f120dea

.field public static final wanted_dialog_btn_txt:I = 0x7f120ded

.field public static final wanted_tip:I = 0x7f120dee

.field public static final wanted_tip_already:I = 0x7f120def

.field public static final wanted_tip_msg:I = 0x7f120df0

.field public static final wanted_tip_msg2:I = 0x7f120df1

.field public static final wanted_tip_push:I = 0x7f120df2

.field public static final watch_all_discuss:I = 0x7f120df3

.field public static final watch_done:I = 0x7f120df4

.field public static final watched_tips:I = 0x7f120df7

.field public static final weibo_tips_bind:I = 0x7f120df8

.field public static final weibo_tips_first:I = 0x7f120df9

.field public static final weibosdk_demo_toast_auth_canceled:I = 0x7f120dfa

.field public static final weibosdk_demo_toast_auth_failed:I = 0x7f120dfb

.field public static final weibosdk_demo_toast_auth_success:I = 0x7f120dfc

.field public static final weixin_not_install:I = 0x7f120dfd

.field public static final weixin_not_support_api:I = 0x7f120dfe

.field public static final window_icon:I = 0x7f120dff

.field public static final write_comment:I = 0x7f120e00

.field public static final write_discuss:I = 0x7f120e01

.field public static final youku_gaia_x_name:I = 0x7f120e02

.field public static final youku_gaia_x_view_search:I = 0x7f120e03

.field public static final youku_gaia_x_view_search_dosearch:I = 0x7f120e04

.field public static final youku_gaia_x_view_search_input:I = 0x7f120e05

.field public static final youku_timer_text:I = 0x7f120e06


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
