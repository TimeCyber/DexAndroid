.class public Lcn/damai/commonbusiness/photoselect/photoview/a;
.super Ljava/lang/Object;
.source "Taobao"


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private a:I

.field private b:I

.field private final c:Landroid/view/ScaleGestureDetector;

.field private d:Landroid/view/VelocityTracker;

.field private e:Z

.field private f:F

.field private g:F

.field private final h:F

.field private final i:F

.field private j:Lcn/damai/commonbusiness/photoselect/photoview/OnGestureListener;


# direct methods
.method constructor <init>(Landroid/content/Context;Lcn/damai/commonbusiness/photoselect/photoview/OnGestureListener;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    .line 2
    iput v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->a:I

    const/4 v0, 0x0

    .line 3
    iput v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->b:I

    .line 4
    invoke-static {p1}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v0

    .line 5
    invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledMinimumFlingVelocity()I

    move-result v1

    int-to-float v1, v1

    iput v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->i:F

    .line 6
    invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result v0

    int-to-float v0, v0

    iput v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->h:F

    .line 7
    iput-object p2, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->j:Lcn/damai/commonbusiness/photoselect/photoview/OnGestureListener;

    .line 8
    new-instance p2, Lcn/damai/commonbusiness/photoselect/photoview/a$a;

    invoke-direct {p2, p0}, Lcn/damai/commonbusiness/photoselect/photoview/a$a;-><init>(Lcn/damai/commonbusiness/photoselect/photoview/a;)V

    .line 9
    new-instance v0, Landroid/view/ScaleGestureDetector;

    invoke-direct {v0, p1, p2}, Landroid/view/ScaleGestureDetector;-><init>(Landroid/content/Context;Landroid/view/ScaleGestureDetector$OnScaleGestureListener;)V

    iput-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->c:Landroid/view/ScaleGestureDetector;

    return-void
.end method

.method static synthetic a(Lcn/damai/commonbusiness/photoselect/photoview/a;)Lcn/damai/commonbusiness/photoselect/photoview/OnGestureListener;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->j:Lcn/damai/commonbusiness/photoselect/photoview/OnGestureListener;

    return-object p0
.end method

.method private b(Landroid/view/MotionEvent;)F
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Float;

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    return p1

    .line 1
    :cond_1e
    :try_start_1e
    iget v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->b:I

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    move-result p1
    :try_end_24
    .catch Ljava/lang/Exception; {:try_start_1e .. :try_end_24} :catch_25

    return p1

    .line 2
    :catch_25
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result p1

    return p1
.end method

.method private c(Landroid/view/MotionEvent;)F
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Float;

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    return p1

    .line 1
    :cond_1e
    :try_start_1e
    iget v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->b:I

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    move-result p1
    :try_end_24
    .catch Ljava/lang/Exception; {:try_start_1e .. :try_end_24} :catch_25

    return p1

    .line 2
    :catch_25
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    return p1
.end method

.method private g(Landroid/view/MotionEvent;)Z
    .registers 14

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v2, :cond_1e

    new-array v2, v3, [Ljava/lang/Object;

    aput-object p0, v2, v5

    aput-object p1, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    return p1

    .line 1
    :cond_1e
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    and-int/lit16 v0, v0, 0xff

    const/4 v1, -0x1

    if-eqz v0, :cond_fe

    const/4 v2, 0x0

    if-eq v0, v4, :cond_a9

    if-eq v0, v3, :cond_6a

    const/4 v3, 0x3

    if-eq v0, v3, :cond_5d

    const/4 v2, 0x6

    if-eq v0, v2, :cond_34

    goto/16 :goto_11d

    .line 2
    :cond_34
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    invoke-static {v0}, Lcn/damai/commonbusiness/photoselect/photoview/b;->b(I)I

    move-result v0

    .line 3
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v2

    .line 4
    iget v3, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->a:I

    if-ne v2, v3, :cond_11d

    if-nez v0, :cond_48

    const/4 v0, 0x1

    goto :goto_49

    :cond_48
    const/4 v0, 0x0

    .line 5
    :goto_49
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v2

    iput v2, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->a:I

    .line 6
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    move-result v2

    iput v2, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->f:F

    .line 7
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    move-result v0

    iput v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->g:F

    goto/16 :goto_11d

    .line 8
    :cond_5d
    iput v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->a:I

    .line 9
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->d:Landroid/view/VelocityTracker;

    if-eqz v0, :cond_11d

    .line 10
    invoke-virtual {v0}, Landroid/view/VelocityTracker;->recycle()V

    .line 11
    iput-object v2, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->d:Landroid/view/VelocityTracker;

    goto/16 :goto_11d

    .line 12
    :cond_6a
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/photoselect/photoview/a;->b(Landroid/view/MotionEvent;)F

    move-result v0

    .line 13
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/photoselect/photoview/a;->c(Landroid/view/MotionEvent;)F

    move-result v2

    .line 14
    iget v3, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->f:F

    sub-float v3, v0, v3

    iget v6, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->g:F

    sub-float v6, v2, v6

    .line 15
    iget-boolean v7, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->e:Z

    if-nez v7, :cond_94

    mul-float v7, v3, v3

    mul-float v8, v6, v6

    add-float/2addr v7, v8

    float-to-double v7, v7

    .line 16
    invoke-static {v7, v8}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v7

    iget v9, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->h:F

    float-to-double v9, v9

    cmpl-double v11, v7, v9

    if-ltz v11, :cond_91

    const/4 v7, 0x1

    goto :goto_92

    :cond_91
    const/4 v7, 0x0

    :goto_92
    iput-boolean v7, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->e:Z

    .line 17
    :cond_94
    iget-boolean v7, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->e:Z

    if-eqz v7, :cond_11d

    .line 18
    iget-object v7, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->j:Lcn/damai/commonbusiness/photoselect/photoview/OnGestureListener;

    invoke-interface {v7, v3, v6}, Lcn/damai/commonbusiness/photoselect/photoview/OnGestureListener;->onDrag(FF)V

    .line 19
    iput v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->f:F

    .line 20
    iput v2, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->g:F

    .line 21
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->d:Landroid/view/VelocityTracker;

    if-eqz v0, :cond_11d

    .line 22
    invoke-virtual {v0, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    goto :goto_11d

    .line 23
    :cond_a9
    iput v1, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->a:I

    .line 24
    iget-boolean v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->e:Z

    if-eqz v0, :cond_f4

    .line 25
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->d:Landroid/view/VelocityTracker;

    if-eqz v0, :cond_f4

    .line 26
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/photoselect/photoview/a;->b(Landroid/view/MotionEvent;)F

    move-result v0

    iput v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->f:F

    .line 27
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/photoselect/photoview/a;->c(Landroid/view/MotionEvent;)F

    move-result v0

    iput v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->g:F

    .line 28
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->d:Landroid/view/VelocityTracker;

    invoke-virtual {v0, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    .line 29
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->d:Landroid/view/VelocityTracker;

    const/16 v3, 0x3e8

    invoke-virtual {v0, v3}, Landroid/view/VelocityTracker;->computeCurrentVelocity(I)V

    .line 30
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->d:Landroid/view/VelocityTracker;

    invoke-virtual {v0}, Landroid/view/VelocityTracker;->getXVelocity()F

    move-result v0

    iget-object v3, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->d:Landroid/view/VelocityTracker;

    .line 31
    invoke-virtual {v3}, Landroid/view/VelocityTracker;->getYVelocity()F

    move-result v3

    .line 32
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v6

    invoke-static {v3}, Ljava/lang/Math;->abs(F)F

    move-result v7

    invoke-static {v6, v7}, Ljava/lang/Math;->max(FF)F

    move-result v6

    iget v7, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->i:F

    cmpl-float v6, v6, v7

    if-ltz v6, :cond_f4

    .line 33
    iget-object v6, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->j:Lcn/damai/commonbusiness/photoselect/photoview/OnGestureListener;

    iget v7, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->f:F

    iget v8, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->g:F

    neg-float v0, v0

    neg-float v3, v3

    invoke-interface {v6, v7, v8, v0, v3}, Lcn/damai/commonbusiness/photoselect/photoview/OnGestureListener;->onFling(FFFF)V

    .line 34
    :cond_f4
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->d:Landroid/view/VelocityTracker;

    if-eqz v0, :cond_11d

    .line 35
    invoke-virtual {v0}, Landroid/view/VelocityTracker;->recycle()V

    .line 36
    iput-object v2, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->d:Landroid/view/VelocityTracker;

    goto :goto_11d

    .line 37
    :cond_fe
    invoke-virtual {p1, v5}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v0

    iput v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->a:I

    .line 38
    invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;

    move-result-object v0

    iput-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->d:Landroid/view/VelocityTracker;

    if-eqz v0, :cond_10f

    .line 39
    invoke-virtual {v0, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    .line 40
    :cond_10f
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/photoselect/photoview/a;->b(Landroid/view/MotionEvent;)F

    move-result v0

    iput v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->f:F

    .line 41
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/photoselect/photoview/a;->c(Landroid/view/MotionEvent;)F

    move-result v0

    iput v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->g:F

    .line 42
    iput-boolean v5, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->e:Z

    .line 43
    :cond_11d
    :goto_11d
    iget v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->a:I

    if-eq v0, v1, :cond_122

    move v5, v0

    :cond_122
    invoke-virtual {p1, v5}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    move-result p1

    iput p1, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->b:I

    return v4
.end method


# virtual methods
.method public d()Z
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget-boolean v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->e:Z

    return v0
.end method

.method public e()Z
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->c:Landroid/view/ScaleGestureDetector;

    invoke-virtual {v0}, Landroid/view/ScaleGestureDetector;->isInProgress()Z

    move-result v0

    return v0
.end method

.method public f(Landroid/view/MotionEvent;)Z
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/photoselect/photoview/a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_1e

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    return p1

    .line 1
    :cond_1e
    :try_start_1e
    iget-object v0, p0, Lcn/damai/commonbusiness/photoselect/photoview/a;->c:Landroid/view/ScaleGestureDetector;

    invoke-virtual {v0, p1}, Landroid/view/ScaleGestureDetector;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 2
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/photoselect/photoview/a;->g(Landroid/view/MotionEvent;)Z

    move-result p1
    :try_end_27
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1e .. :try_end_27} :catch_28

    return p1

    :catch_28
    return v3
.end method
