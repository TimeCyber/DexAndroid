.class public Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$i;
.super Landroid/os/Handler;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "i"
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$i;->a:Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;

    invoke-direct {p0}, Landroid/os/Handler;-><init>()V

    return-void
.end method


# virtual methods
.method public dispatchMessage(Landroid/os/Message;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$i;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-super {p0, p1}, Landroid/os/Handler;->dispatchMessage(Landroid/os/Message;)V

    .line 2
    iget p1, p1, Landroid/os/Message;->what:I

    if-eqz p1, :cond_1f

    goto :goto_6d

    .line 3
    :cond_1f
    iget-object p1, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$i;->a:Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;->access$500(Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;)Landroid/widget/TextView;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/TextView;->getTag()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/faceverify/bean/CertificateTypeBean$ResultBean;

    if-nez p1, :cond_50

    .line 4
    iget-object p1, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$i;->a:Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;->access$600(Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;)Ljava/util/List;

    move-result-object p1

    invoke-static {p1}, Ltb/mw5;->f(Ljava/util/List;)I

    move-result p1

    if-lez p1, :cond_46

    iget-object p1, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$i;->a:Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;->access$600(Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;)Ljava/util/List;

    move-result-object p1

    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/faceverify/bean/CertificateTypeBean$ResultBean;

    goto :goto_47

    :cond_46
    const/4 p1, 0x0

    .line 5
    :goto_47
    iget-object v0, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$i;->a:Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;->access$500(Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTag(Ljava/lang/Object;)V

    :cond_50
    if-eqz p1, :cond_68

    .line 6
    iget-object v0, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$i;->a:Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;->access$500(Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {p1}, Lcn/damai/commonbusiness/faceverify/bean/CertificateTypeBean$ResultBean;->getIdentufyName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 7
    iget-object v0, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$i;->a:Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;

    invoke-virtual {p1}, Lcn/damai/commonbusiness/faceverify/bean/CertificateTypeBean$ResultBean;->getIdentifyCode()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;->access$402(Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;Ljava/lang/String;)Ljava/lang/String;

    .line 8
    :cond_68
    iget-object p1, p0, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity$i;->a:Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;->access$000(Lcn/damai/commonbusiness/faceverify/activity/IdentityInfoQueryActivity;)V

    :goto_6d
    return-void
.end method
