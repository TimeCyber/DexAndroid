.class public interface abstract Lcn/damai/commonbusiness/base/ResponseErrorPage$ErrorRefreshListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/base/ResponseErrorPage;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "ErrorRefreshListener"
.end annotation


# virtual methods
.method public abstract handleError(I)V
.end method
