.class public Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$c;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->m(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:Ljava/lang/String;

.field final synthetic d:Ljava/lang/String;

.field final synthetic e:Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 6

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$c;->e:Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;

    iput-object p2, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$c;->a:Landroid/content/Context;

    iput-object p3, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$c;->b:Ljava/lang/String;

    iput-object p4, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$c;->c:Ljava/lang/String;

    iput-object p5, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$c;->d:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$c;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    const/4 p1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1e
    iget-object p1, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$c;->e:Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;

    iget-object p2, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$c;->a:Landroid/content/Context;

    iget-object v0, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$c;->b:Ljava/lang/String;

    iget-object v1, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$c;->c:Ljava/lang/String;

    iget-object v2, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$c;->d:Ljava/lang/String;

    invoke-static {p1, p2, v0, v1, v2}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->a(Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager$c;->e:Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;

    invoke-static {p1}, Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;->i(Lcn/damai/commonbusiness/faceverify/manager/DMFaceVerifyManager;)V

    return-void
.end method
