.class public Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$c;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$c;->a:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .registers 8

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$c;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_21

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    const/4 p1, 0x2

    aput-object p2, v2, p1

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    return p1

    .line 1
    :cond_21
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result p1

    if-nez p1, :cond_35

    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$c;->a:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;->access$1200(Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;)Z

    move-result p1

    if-eqz p1, :cond_35

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$c;->a:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;->access$1300(Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;)V

    return v3

    :cond_35
    return v4
.end method
