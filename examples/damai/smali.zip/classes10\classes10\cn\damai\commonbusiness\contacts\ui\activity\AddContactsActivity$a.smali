.class public Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$a;
.super Landroid/os/Handler;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$a;->a:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;

    invoke-direct {p0}, Landroid/os/Handler;-><init>()V

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$a;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-super {p0, p1}, Landroid/os/Handler;->handleMessage(Landroid/os/Message;)V

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$a;->a:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;->access$600(Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;)Landroid/widget/TextView;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/TextView;->getTag()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/contacts/bean/CustomerType;

    if-nez p1, :cond_4b

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$a;->a:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;->access$700(Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;)Ljava/util/List;

    move-result-object p1

    invoke-static {p1}, Ltb/mw5;->f(Ljava/util/List;)I

    move-result p1

    if-lez p1, :cond_41

    iget-object p1, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$a;->a:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;

    invoke-static {p1}, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;->access$700(Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;)Ljava/util/List;

    move-result-object p1

    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/damai/commonbusiness/contacts/bean/CustomerType;

    goto :goto_42

    :cond_41
    const/4 p1, 0x0

    .line 4
    :goto_42
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$a;->a:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;

    invoke-static {v0}, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;->access$600(Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTag(Ljava/lang/Object;)V

    :cond_4b
    if-eqz p1, :cond_52

    .line 5
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity$a;->a:Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;

    invoke-static {v0, p1}, Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;->access$800(Lcn/damai/commonbusiness/contacts/ui/activity/AddContactsActivity;Lcn/damai/commonbusiness/contacts/bean/CustomerType;)V

    :cond_52
    return-void
.end method
