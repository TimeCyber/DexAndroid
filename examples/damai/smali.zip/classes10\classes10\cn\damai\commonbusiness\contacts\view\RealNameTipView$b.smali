.class public Lcn/damai/commonbusiness/contacts/view/RealNameTipView$b;
.super Landroid/text/style/ClickableSpan;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/contacts/view/RealNameTipView;->setText(Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Lcn/damai/commonbusiness/contacts/view/RealNameTipView;


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/contacts/view/RealNameTipView;Ljava/lang/String;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView$b;->b:Lcn/damai/commonbusiness/contacts/view/RealNameTipView;

    iput-object p2, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView$b;->a:Ljava/lang/String;

    invoke-direct {p0}, Landroid/text/style/ClickableSpan;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 6
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param

    sget-object v0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView$b;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    new-instance p1, Landroid/os/Bundle;

    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView$b;->a:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_31

    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView$b;->a:Ljava/lang/String;

    const-string v1, "\u8d26\u53f7\u5b9e\u540d\u8ba4\u8bc1\u534f\u8bae"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_31

    const-string v0, "https://terms.alicdn.com/legal-agreement/terms/c_end_product_protocol/20240110182703144/20240110182703144.html?bizpass_pioneer=1"

    goto :goto_33

    :cond_31
    const-string v0, "https://m.damai.cn/shows/mine/certificate-notice.html"

    :goto_33
    const-string v1, "url"

    .line 3
    invoke-virtual {p1, v1, v0}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 4
    sget-object v0, Ltb/yd3;->INSTANCE:Ltb/yd3;

    iget-object v1, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView$b;->b:Lcn/damai/commonbusiness/contacts/view/RealNameTipView;

    invoke-virtual {v1}, Landroid/widget/LinearLayout;->getContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "webview"

    invoke-static {v2}, Lcom/alibaba/pictures/picturesbiz/NavUri;->c(Ljava/lang/String;)Lcom/alibaba/pictures/picturesbiz/NavUri;

    move-result-object v2

    invoke-virtual {v2}, Lcom/alibaba/pictures/picturesbiz/NavUri;->a()Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v0, v1, v2, p1}, Ltb/yd3;->handleUri(Landroid/content/Context;Landroid/net/Uri;Landroid/os/Bundle;)Z

    return-void
.end method

.method public updateDrawState(Landroid/text/TextPaint;)V
    .registers 6
    .param p1    # Landroid/text/TextPaint;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param

    sget-object v0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView$b;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-super {p0, p1}, Landroid/text/style/ClickableSpan;->updateDrawState(Landroid/text/TextPaint;)V

    .line 2
    sget-object v0, Ltb/oa;->INSTANCE:Ltb/oa;

    invoke-virtual {v0}, Ltb/oa;->getAppConfigProvider()Lcom/alibaba/pictures/cornerstone/common/IAppConfigProvider;

    move-result-object v0

    invoke-interface {v0}, Lcom/alibaba/pictures/cornerstone/common/IAppConfigProvider;->getIsPioneerOpen()Z

    move-result v0

    if-eqz v0, :cond_36

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/contacts/view/RealNameTipView$b;->b:Lcn/damai/commonbusiness/contacts/view/RealNameTipView;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getContext()Landroid/content/Context;

    move-result-object v0

    sget v1, Lcom/alibaba/pictures/picturesbiz/R$color;->color_FF7600:I

    invoke-static {v0, v1}, Landroidx/core/content/ContextCompat;->getColor(Landroid/content/Context;I)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/text/TextPaint;->setColor(I)V

    goto :goto_3f

    :cond_36
    const-string v0, "#ff1268"

    .line 4
    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/text/TextPaint;->setColor(I)V

    .line 5
    :goto_3f
    invoke-virtual {p1, v3}, Landroid/text/TextPaint;->setUnderlineText(Z)V

    return-void
.end method
