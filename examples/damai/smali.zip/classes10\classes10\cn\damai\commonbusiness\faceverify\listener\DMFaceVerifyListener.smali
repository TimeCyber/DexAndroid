.class public interface abstract Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyListener;
.super Ljava/lang/Object;
.source "Taobao"


# virtual methods
.method public abstract onAuditResult(Lcn/damai/commonbusiness/faceverify/listener/DMFaceVerifyResult;)V
.end method
