.class public Lcn/damai/commonbusiness/discover/bean/TagBean;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public tagColor:I

.field public tagName:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lcn/damai/commonbusiness/discover/bean/TagBean;->tagName:Ljava/lang/String;

    .line 3
    iput p2, p0, Lcn/damai/commonbusiness/discover/bean/TagBean;->tagColor:I

    return-void
.end method
