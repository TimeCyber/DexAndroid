.class public interface abstract Lcn/damai/commonbusiness/faceverify/contract/IdentityInfoQueryContract;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/faceverify/contract/IdentityInfoQueryContract$Presenter;,
        Lcn/damai/commonbusiness/faceverify/contract/IdentityInfoQueryContract$View;,
        Lcn/damai/commonbusiness/faceverify/contract/IdentityInfoQueryContract$Model;
    }
.end annotation
