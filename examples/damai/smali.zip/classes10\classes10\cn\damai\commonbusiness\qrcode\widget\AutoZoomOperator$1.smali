.class public Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator$1;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;->d(II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field final synthetic this$0:Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;

.field final synthetic val$curIndex:I

.field final synthetic val$maxZoom:I


# direct methods
.method constructor <init>(Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;II)V
    .registers 4

    .line 1
    iput-object p1, p0, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator$1;->this$0:Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;

    iput p2, p0, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator$1;->val$curIndex:I

    iput p3, p0, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator$1;->val$maxZoom:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator$1;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget v0, p0, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator$1;->val$curIndex:I

    const/16 v1, 0xa

    if-ge v0, v1, :cond_2f

    .line 2
    iget-object v1, p0, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator$1;->this$0:Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;

    iget v2, p0, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator$1;->val$maxZoom:I

    int-to-float v3, v2

    const/high16 v4, 0x3f800000    # 1.0f

    mul-float v3, v3, v4

    const/high16 v4, 0x41200000    # 10.0f

    div-float/2addr v3, v4

    float-to-int v3, v3

    add-int/lit8 v4, v0, 0x1

    mul-int v3, v3, v4

    invoke-static {v1, v3, v0, v2}, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;->a(Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;III)V

    goto :goto_34

    .line 3
    :cond_2f
    iget-object v0, p0, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator$1;->this$0:Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;

    invoke-static {v0, v3}, Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;->b(Lcn/damai/commonbusiness/qrcode/widget/AutoZoomOperator;Z)Z

    :goto_34
    return-void
.end method
