.class public interface abstract Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView$OnProvinceDivisionChangedListener;
.super Ljava/lang/Object;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcn/damai/commonbusiness/address/view/AddressDivisionSelectView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnProvinceDivisionChangedListener"
.end annotation


# virtual methods
.method public abstract onProvinceDivisionChanged(Lcn/damai/commonbusiness/address/bean/DivisionBean;)V
.end method
