.class public Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;
.super Landroid/widget/FrameLayout;
.source "Taobao"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$b;
    }
.end annotation


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field private duration:J

.field private imageHandler:Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$b;

.field private imageList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private imageView:Lcn/damai/uikit/view/RoundImageView;

.field private index:I

.field private interval:J

.field private isAttachedToWindow:Z

.field private final mCacheDrawable:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Landroid/graphics/drawable/Drawable;",
            ">;"
        }
    .end annotation
.end field

.field private final runTask:Ljava/lang/Runnable;

.field private scaleInAnimation:Landroid/animation/AnimatorSet;

.field private scaleOutAnimation:Landroid/animation/AnimatorSet;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 4
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param

    .line 1
    invoke-direct {p0, p1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 2
    new-instance v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$b;

    invoke-direct {v0, p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$b;-><init>(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)V

    iput-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageHandler:Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$b;

    .line 3
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageList:Ljava/util/List;

    const-wide/16 v0, 0x1388

    .line 4
    iput-wide v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->interval:J

    const-wide/16 v0, 0x12c

    .line 5
    iput-wide v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->duration:J

    const/4 v0, 0x0

    .line 6
    iput-boolean v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->isAttachedToWindow:Z

    .line 7
    new-instance v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$3;

    invoke-direct {v0, p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$3;-><init>(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)V

    iput-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->runTask:Ljava/lang/Runnable;

    .line 8
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->mCacheDrawable:Ljava/util/HashMap;

    .line 9
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->initView(Landroid/content/Context;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 5
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .line 10
    invoke-direct {p0, p1, p2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 11
    new-instance p2, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$b;

    invoke-direct {p2, p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$b;-><init>(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)V

    iput-object p2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageHandler:Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$b;

    .line 12
    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    iput-object p2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageList:Ljava/util/List;

    const-wide/16 v0, 0x1388

    .line 13
    iput-wide v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->interval:J

    const-wide/16 v0, 0x12c

    .line 14
    iput-wide v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->duration:J

    const/4 p2, 0x0

    .line 15
    iput-boolean p2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->isAttachedToWindow:Z

    .line 16
    new-instance p2, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$3;

    invoke-direct {p2, p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$3;-><init>(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)V

    iput-object p2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->runTask:Ljava/lang/Runnable;

    .line 17
    new-instance p2, Ljava/util/HashMap;

    invoke-direct {p2}, Ljava/util/HashMap;-><init>()V

    iput-object p2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->mCacheDrawable:Ljava/util/HashMap;

    .line 18
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->initView(Landroid/content/Context;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .line 19
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 20
    new-instance p2, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$b;

    invoke-direct {p2, p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$b;-><init>(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)V

    iput-object p2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageHandler:Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$b;

    .line 21
    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    iput-object p2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageList:Ljava/util/List;

    const-wide/16 p2, 0x1388

    .line 22
    iput-wide p2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->interval:J

    const-wide/16 p2, 0x12c

    .line 23
    iput-wide p2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->duration:J

    const/4 p2, 0x0

    .line 24
    iput-boolean p2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->isAttachedToWindow:Z

    .line 25
    new-instance p2, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$3;

    invoke-direct {p2, p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$3;-><init>(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)V

    iput-object p2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->runTask:Ljava/lang/Runnable;

    .line 26
    new-instance p2, Ljava/util/HashMap;

    invoke-direct {p2}, Ljava/util/HashMap;-><init>()V

    iput-object p2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->mCacheDrawable:Ljava/util/HashMap;

    .line 27
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->initView(Landroid/content/Context;)V

    return-void
.end method

.method static synthetic access$000(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)Ljava/util/List;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageList:Ljava/util/List;

    return-object p0
.end method

.method static synthetic access$100(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->setImage(I)V

    return-void
.end method

.method static synthetic access$200(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)Landroid/animation/AnimatorSet;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->scaleOutAnimation:Landroid/animation/AnimatorSet;

    return-object p0
.end method

.method static synthetic access$300(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)Ljava/util/HashMap;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->mCacheDrawable:Ljava/util/HashMap;

    return-object p0
.end method

.method static synthetic access$400(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)Lcn/damai/uikit/view/RoundImageView;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageView:Lcn/damai/uikit/view/RoundImageView;

    return-object p0
.end method

.method static synthetic access$500(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)Z
    .registers 1

    .line 1
    iget-boolean p0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->isAttachedToWindow:Z

    return p0
.end method

.method static synthetic access$600(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)I
    .registers 1

    .line 1
    iget p0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->index:I

    return p0
.end method

.method static synthetic access$602(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;I)I
    .registers 2

    .line 1
    iput p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->index:I

    return p1
.end method

.method static synthetic access$608(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)I
    .registers 3

    .line 1
    iget v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->index:I

    add-int/lit8 v1, v0, 0x1

    iput v1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->index:I

    return v0
.end method

.method static synthetic access$700(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;)Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$b;
    .registers 1

    .line 1
    iget-object p0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageHandler:Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$b;

    return-object p0
.end method

.method static synthetic access$800(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->run(I)V

    return-void
.end method

.method private initScaleInAnimation()V
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "5"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_14

    new-array v2, v3, [Ljava/lang/Object;

    aput-object p0, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    new-instance v0, Landroid/animation/AnimatorSet;

    invoke-direct {v0}, Landroid/animation/AnimatorSet;-><init>()V

    iput-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->scaleInAnimation:Landroid/animation/AnimatorSet;

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageView:Lcn/damai/uikit/view/RoundImageView;

    const/4 v1, 0x2

    new-array v2, v1, [F

    fill-array-data v2, :array_54

    const-string v5, "scaleX"

    invoke-static {v0, v5, v2}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object v0

    .line 3
    iget-object v2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageView:Lcn/damai/uikit/view/RoundImageView;

    new-array v5, v1, [F

    fill-array-data v5, :array_5c

    const-string v6, "scaleY"

    invoke-static {v2, v6, v5}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object v2

    .line 4
    iget-object v5, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->scaleInAnimation:Landroid/animation/AnimatorSet;

    iget-wide v6, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->duration:J

    invoke-virtual {v5, v6, v7}, Landroid/animation/AnimatorSet;->setDuration(J)Landroid/animation/AnimatorSet;

    .line 5
    iget-object v5, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->scaleInAnimation:Landroid/animation/AnimatorSet;

    new-instance v6, Landroid/view/animation/LinearInterpolator;

    invoke-direct {v6}, Landroid/view/animation/LinearInterpolator;-><init>()V

    invoke-virtual {v5, v6}, Landroid/animation/AnimatorSet;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    .line 6
    iget-object v5, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->scaleInAnimation:Landroid/animation/AnimatorSet;

    new-array v1, v1, [Landroid/animation/Animator;

    aput-object v0, v1, v4

    aput-object v2, v1, v3

    invoke-virtual {v5, v1}, Landroid/animation/AnimatorSet;->playTogether([Landroid/animation/Animator;)V

    return-void

    nop

    :array_54
    .array-data 4
        0x3f800000    # 1.0f
        0x0
    .end array-data

    :array_5c
    .array-data 4
        0x3f800000    # 1.0f
        0x0
    .end array-data
.end method

.method private initScaleOutAnimation()V
    .registers 9

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "6"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_14

    new-array v2, v3, [Ljava/lang/Object;

    aput-object p0, v2, v4

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    new-instance v0, Landroid/animation/AnimatorSet;

    invoke-direct {v0}, Landroid/animation/AnimatorSet;-><init>()V

    iput-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->scaleOutAnimation:Landroid/animation/AnimatorSet;

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageView:Lcn/damai/uikit/view/RoundImageView;

    const/4 v1, 0x2

    new-array v2, v1, [F

    fill-array-data v2, :array_54

    const-string v5, "scaleX"

    invoke-static {v0, v5, v2}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object v0

    .line 3
    iget-object v2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageView:Lcn/damai/uikit/view/RoundImageView;

    new-array v5, v1, [F

    fill-array-data v5, :array_5c

    const-string v6, "scaleY"

    invoke-static {v2, v6, v5}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object v2

    .line 4
    iget-object v5, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->scaleOutAnimation:Landroid/animation/AnimatorSet;

    iget-wide v6, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->duration:J

    invoke-virtual {v5, v6, v7}, Landroid/animation/AnimatorSet;->setDuration(J)Landroid/animation/AnimatorSet;

    .line 5
    iget-object v5, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->scaleOutAnimation:Landroid/animation/AnimatorSet;

    new-instance v6, Landroid/view/animation/LinearInterpolator;

    invoke-direct {v6}, Landroid/view/animation/LinearInterpolator;-><init>()V

    invoke-virtual {v5, v6}, Landroid/animation/AnimatorSet;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    .line 6
    iget-object v5, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->scaleOutAnimation:Landroid/animation/AnimatorSet;

    new-array v1, v1, [Landroid/animation/Animator;

    aput-object v0, v1, v4

    aput-object v2, v1, v3

    invoke-virtual {v5, v1}, Landroid/animation/AnimatorSet;->playTogether([Landroid/animation/Animator;)V

    return-void

    nop

    :array_54
    .array-data 4
        0x0
        0x3f800000    # 1.0f
    .end array-data

    :array_5c
    .array-data 4
        0x0
        0x3f800000    # 1.0f
    .end array-data
.end method

.method private initView(Landroid/content/Context;)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v2, v4

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    new-instance v0, Lcn/damai/uikit/view/RoundImageView;

    invoke-direct {v0, p1}, Lcn/damai/uikit/view/RoundImageView;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageView:Lcn/damai/uikit/view/RoundImageView;

    .line 2
    invoke-virtual {v0, v3}, Lcom/alibaba/pictures/bricks/view/RoundImageView;->setType(I)V

    .line 3
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageView:Lcn/damai/uikit/view/RoundImageView;

    const/4 v0, 0x6

    invoke-virtual {p1, v0}, Lcom/alibaba/pictures/bricks/view/RoundImageView;->setBorderRadius(I)V

    .line 4
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageView:Lcn/damai/uikit/view/RoundImageView;

    sget v0, Lcom/alibaba/pictures/picturesbiz/R$drawable;->uikit_default_image_bg_gradient:I

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 5
    new-instance p1, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v0, -0x1

    invoke-direct {p1, v0, v0}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 6
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageView:Lcn/damai/uikit/view/RoundImageView;

    invoke-virtual {p0, v0, p1}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 7
    invoke-direct {p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->initScaleInAnimation()V

    .line 8
    invoke-direct {p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->initScaleOutAnimation()V

    return-void
.end method

.method private run(I)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "8"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    invoke-direct {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->setImage(I)V

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->scaleInAnimation:Landroid/animation/AnimatorSet;

    invoke-virtual {v0}, Landroid/animation/AnimatorSet;->start()V

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageView:Lcn/damai/uikit/view/RoundImageView;

    new-instance v1, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$1;

    invoke-direct {v1, p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$1;-><init>(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;I)V

    iget-wide v2, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->duration:J

    invoke-virtual {v0, v1, v2, v3}, Landroid/widget/ImageView;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method private setImage(I)V
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "9"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageList:Ljava/util/List;

    invoke-static {v0}, Ltb/mw5;->f(Ljava/util/List;)I

    move-result v0

    if-lt p1, v0, :cond_24

    const/4 p1, 0x0

    .line 2
    :cond_24
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageList:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->mCacheDrawable:Ljava/util/HashMap;

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_5a

    .line 4
    sget-object v1, Ltb/oa;->INSTANCE:Ltb/oa;

    invoke-virtual {v1}, Ltb/oa;->debugable()Z

    move-result v1

    if-eqz v1, :cond_54

    .line 5
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "use cache drawable "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v1, "DMDXScale"

    invoke-static {v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 6
    :cond_54
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageView:Lcn/damai/uikit/view/RoundImageView;

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_71

    .line 7
    :cond_5a
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageView:Lcn/damai/uikit/view/RoundImageView;

    sget v1, Lcom/alibaba/pictures/picturesbiz/R$drawable;->uikit_default_image_bg_gradient:I

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 8
    invoke-static {}, Lcom/alibaba/pictures/moimage/MoImageDownloader;->r()Lcom/alibaba/pictures/moimage/MoImageDownloader;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/alibaba/pictures/moimage/MoImageDownloader;->l(Ljava/lang/String;)Lcom/alibaba/pictures/moimage/MoImageDownloader;

    move-result-object v0

    new-instance v1, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$a;

    invoke-direct {v1, p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage$a;-><init>(Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Lcom/alibaba/pictures/moimage/MoImageDownloader;->e(Lcom/alibaba/pictures/moimage/DownloadImgListener;)V

    :goto_71
    return-void
.end method


# virtual methods
.method public delNoUseCache(Ljava/util/List;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "16"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    invoke-static {p1}, Ltb/ck5;->d(Ljava/util/Collection;)Z

    move-result v0

    if-eqz v0, :cond_23

    .line 2
    iget-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->mCacheDrawable:Ljava/util/HashMap;

    invoke-virtual {p1}, Ljava/util/HashMap;->clear()V

    return-void

    .line 3
    :cond_23
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->mCacheDrawable:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v0

    .line 4
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    .line 5
    :cond_2d
    :goto_2d
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_43

    .line 6
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 7
    invoke-interface {p1, v1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2d

    .line 8
    invoke-interface {v0}, Ljava/util/Iterator;->remove()V

    goto :goto_2d

    :cond_43
    return-void
.end method

.method public destoryScaleImagView()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "11"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    invoke-virtual {p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->stopAnimationV2()V

    return-void
.end method

.method protected onAttachedToWindow()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "12"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_14

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    invoke-super {p0}, Landroid/widget/FrameLayout;->onAttachedToWindow()V

    .line 2
    iput-boolean v3, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->isAttachedToWindow:Z

    .line 3
    sget-object v0, Ltb/oa;->INSTANCE:Ltb/oa;

    invoke-virtual {v0}, Ltb/oa;->debugable()Z

    move-result v0

    if-eqz v0, :cond_28

    const-string v0, "DMDXScale"

    const-string v1, "onAttachedToWindow"

    .line 4
    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 5
    :cond_28
    invoke-virtual {p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->startAnimationV2()V

    return-void
.end method

.method protected onDetachedFromWindow()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "13"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    invoke-super {p0}, Landroid/widget/FrameLayout;->onDetachedFromWindow()V

    .line 2
    iput-boolean v3, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->isAttachedToWindow:Z

    .line 3
    sget-object v0, Ltb/oa;->INSTANCE:Ltb/oa;

    invoke-virtual {v0}, Ltb/oa;->debugable()Z

    move-result v0

    if-eqz v0, :cond_28

    const-string v0, "DMDXScale"

    const-string v1, "onDetachedFromWindow"

    .line 4
    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 5
    :cond_28
    invoke-virtual {p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->stopAnimationV2()V

    return-void
.end method

.method public setDuration(J)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "3"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iput-wide p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->duration:J

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->scaleInAnimation:Landroid/animation/AnimatorSet;

    invoke-virtual {v0, p1, p2}, Landroid/animation/AnimatorSet;->setDuration(J)Landroid/animation/AnimatorSet;

    .line 3
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->scaleOutAnimation:Landroid/animation/AnimatorSet;

    invoke-virtual {v0, p1, p2}, Landroid/animation/AnimatorSet;->setDuration(J)Landroid/animation/AnimatorSet;

    return-void
.end method

.method public setImageList(Ljava/util/List;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "2"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_17

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v3

    const/4 v3, 0x1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_17
    iput-object p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageList:Ljava/util/List;

    .line 2
    invoke-virtual {p0, p1}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->delNoUseCache(Ljava/util/List;)V

    .line 3
    invoke-static {p1}, Ltb/mw5;->f(Ljava/util/List;)I

    move-result p1

    if-lez p1, :cond_25

    .line 4
    invoke-direct {p0, v3}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->setImage(I)V

    .line 5
    :cond_25
    invoke-virtual {p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->startAnimationV2()V

    return-void
.end method

.method public setInterval(J)V
    .registers 7

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "4"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1b

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    const/4 v3, 0x1

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    aput-object p1, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_1b
    iput-wide p1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->interval:J

    return-void
.end method

.method public startAnimation()V
    .registers 5
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "7"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    invoke-virtual {p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->startAnimationV2()V

    return-void
.end method

.method public startAnimationV2()V
    .registers 8

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "14"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_14

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->runTask:Ljava/lang/Runnable;

    invoke-virtual {p0, v0}, Landroid/widget/FrameLayout;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 2
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->imageList:Ljava/util/List;

    invoke-static {v0}, Ltb/ck5;->a(Ljava/util/Collection;)I

    move-result v0

    if-gt v0, v3, :cond_22

    return-void

    .line 3
    :cond_22
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->runTask:Ljava/lang/Runnable;

    iget-wide v1, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->interval:J

    iget-wide v3, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->duration:J

    const-wide/16 v5, 0x2

    mul-long v3, v3, v5

    add-long/2addr v1, v3

    invoke-virtual {p0, v0, v1, v2}, Landroid/widget/FrameLayout;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public stopAnimation()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "10"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    invoke-virtual {p0}, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->stopAnimationV2()V

    return-void
.end method

.method public stopAnimationV2()V
    .registers 5

    sget-object v0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "15"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1
    :cond_14
    iget-object v0, p0, Lcn/damai/commonbusiness/dynamicx/customwidget/scaleimage/DMDXScaleAnimationImage;->runTask:Ljava/lang/Runnable;

    invoke-virtual {p0, v0}, Landroid/widget/FrameLayout;->removeCallbacks(Ljava/lang/Runnable;)Z

    return-void
.end method
