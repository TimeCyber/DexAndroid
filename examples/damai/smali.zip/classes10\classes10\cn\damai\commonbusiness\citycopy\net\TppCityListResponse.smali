.class public Lcn/damai/commonbusiness/citycopy/net/TppCityListResponse;
.super Ljava/lang/Object;
.source "Taobao"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public returnCode:Ljava/lang/String;

.field public returnValue:Lcn/damai/commonbusiness/citycopy/net/CityListResponse;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
