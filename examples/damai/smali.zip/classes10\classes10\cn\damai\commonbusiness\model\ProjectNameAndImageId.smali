.class public Lcn/damai/commonbusiness/model/ProjectNameAndImageId;
.super Ljava/lang/Object;
.source "Taobao"


# static fields
.field private static transient synthetic $surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;


# instance fields
.field public stateImageId:I

.field public stateName:Ljava/lang/String;

.field public stateTextId:I


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public isAvailable()Z
    .registers 6

    sget-object v0, Lcn/damai/commonbusiness/model/ProjectNameAndImageId;->$surgeonFlag:Lcom/alibaba/surgeon/bridge/ISurgeon;

    const-string v1, "1"

    invoke-static {v0, v1}, Lcom/alibaba/surgeon/instrument/InstrumentAPI;->support(Lcom/alibaba/surgeon/bridge/ISurgeon;Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_1b

    new-array v2, v4, [Ljava/lang/Object;

    aput-object p0, v2, v3

    invoke-interface {v0, v1, v2}, Lcom/alibaba/surgeon/bridge/ISurgeon;->surgeon$dispatch(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    return v0

    .line 1
    :cond_1b
    iget v0, p0, Lcn/damai/commonbusiness/model/ProjectNameAndImageId;->stateImageId:I

    if-eqz v0, :cond_2c

    iget v0, p0, Lcn/damai/commonbusiness/model/ProjectNameAndImageId;->stateTextId:I

    if-eqz v0, :cond_2c

    iget-object v0, p0, Lcn/damai/commonbusiness/model/ProjectNameAndImageId;->stateName:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_2c

    const/4 v3, 0x1

    :cond_2c
    return v3
.end method
